#!/usr/bin/env python3
"""Portable snapshot58 source-only reproduction, including the verified0→2 chain."""
import argparse
import collections
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

HERE=Path(__file__).resolve().parent


def read(path):
    data=path.read_bytes()
    if path.suffix=='.gz':
        data=gzip.decompress(data)
    return json.loads(data)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()


def verify():
    manifest=read(HERE/'capsule-manifest.json');assert manifest['snapshot']==58
    for name,row in manifest['files'].items():
        relative=Path(name);assert not relative.is_absolute() and '..' not in relative.parts
        assert (HERE/name).is_file() and sha(HERE/name)==row['sha256'],name
    return manifest


def run(command,cwd=None,env=None):
    subprocess.run(list(map(str,command)),cwd=cwd,env=env,check=True)


def compose(output,stage='final'):
    composition=read(HERE/'composition.json');assert composition['snapshot']==58
    selected_stage=stage
    if stage=='upgrade':selected_stage='transition'
    selected=composition.get('stages',{}).get(selected_stage,composition)
    shutil.copytree(HERE/'parent-source',output)
    for name,member in composition['base_overlays'].items():
        target=output/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(HERE/member,target)
    for row in selected['patches']:
        patch=HERE/row['path'];assert sha(patch)==row['sha256']
        run(['patch','--fuzz=0','-p1','-i',patch],cwd=output)
    if stage=='upgrade':
        assert composition.get('upgrade_patches')
        for row in composition['upgrade_patches']:
            patch=HERE/row['path'];assert sha(patch)==row['sha256']
            run(['patch','--fuzz=0','-p1','-i',patch],cwd=output)
        selected=composition['stages']['final']
    assert not list(output.rglob('*.orig')) and not list(output.rglob('*.rej'))
    pin_file=selected.get('source_pins','source/source-pins.json')
    pins=read(HERE/pin_file)
    for name,expected in {**pins,**composition.get('composition_extra_sha256',{})}.items():
        assert sha(output/name)==expected,name
    (output/'source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')


def source_identity(source,report):
    for name,value in report['source_sha256'].items():assert sha(source/'selfhost'/name)==value,name
    for name,value in report['asset_sha256'].items():assert sha(source/name)==value,name
    for name,value in report['stdlib_sha256'].items():assert sha(source/'stdlib'/name)==value,name


def bootstrap(output,cc):
    source=HERE/'source';old_source=HERE/'transition-source'
    if not old_source.is_dir():old_source=source
    transition=output.with_name(output.name+'-transition-opt0')
    transition_seed=output.with_name(output.name+'-transition-seed-opt0');final_seed=output.with_name(output.name+'-seed-opt2')
    def invocation(tree):return [sys.executable,tree/'selfhost/bootstrap.py','--source-dir',tree/'selfhost','--stdlib',tree/'stdlib','--native-dir',tree/'native','--cc',cc,'--verify']
    assert Path(cc).name not in ('c++','g++','clang++')
    run([*invocation(old_source),'--seed-dir',HERE/'parent-seed','--output-dir',transition,'--optimization',0],cwd=old_source)
    report0=read(transition/'report.json');assert report0['goose_optimization']==0 and report0['fixed_point']
    source_identity(old_source,report0)
    freezer=HERE/'tools/freeze_seed.py'
    run([sys.executable,freezer,transition,transition_seed,old_source])
    assert read(transition_seed/'seed.json')['goose_optimization']==0
    run([*invocation(source),'--seed-dir',transition_seed,'--output-dir',output,'--optimization',2],cwd=source)
    report2=read(output/'report.json');assert report2['goose_optimization']==2 and report2['fixed_point']
    assert not report2.get('seed_matches_sources',False)
    source_identity(source,report2)
    assert report2['seed_c_sha256']==report0['executable_c_sha256']
    assert report2['bootstrap_source_sha256']==report0['source_sha256']
    assert report0['stdlib_sha256']==report2['stdlib_sha256']
    old_assets=report0['asset_sha256'];new_assets=report2['asset_sha256']
    delta={name:dict(transition=old_assets.get(name),final=new_assets.get(name)) for name in sorted(old_assets.keys()|new_assets.keys()) if old_assets.get(name)!=new_assets.get(name)}
    assert delta==read(HERE/'composition.json').get('stage_asset_delta',{}),'Unapproved stage asset change'
    run([sys.executable,freezer,output,final_seed,source])
    assert read(final_seed/'seed.json')['goose_optimization']==2
    print('Verified C-only transition0 and canonical2; optimized seed:',final_seed)


def public_bootstrap(output,cc):
    shutil.copytree(HERE/'source',output)
    env=dict(os.environ);env.pop('TMPDIR',None)
    run([sys.executable,output/'scripts/bootstrap.py','--verify','--cc',cc],cwd=output,env=env)
    report=read(output/'build/bootstrap/report.json');metadata=read(output/'build/toolchain.json')
    assert report['status']=='passed' and report['fixed_point'] and report['goose_optimization']==2
    assert metadata['compiler_sha256']==sha(output/'build/bin/goose')
    assert report['executable_c_sha256']==read(output/'bootstrap/seed.json')['c_sha256']
    supplied=(output/'bootstrap/profile.json').is_file()
    assert supplied==(output/'bootstrap/profile.profdata').is_file()
    assert report['profile_used']==metadata['profile_used']==supplied
    if supplied:
        profile=read(output/'bootstrap/profile.json')
        assert profile['c_sha256']==report['executable_c_sha256'] and profile['data_sha256']==sha(output/'bootstrap/profile.profdata')
        assert report['executable_build']['profile_sha256']==profile['data_sha256']
    print('Actual public compiler:',output/'build/bin/goose')


def contracts(args):
    source=HERE/'source';output=args.output_dir
    if output is None:
        output=HERE/('contracts-'+args.engine)
    command=[sys.executable,source/'tests/conformance.py','--compiler',args.compiler.resolve(),
             '--stdlib',source/'stdlib','--manifest',source/'tests/conformance/cases.json',
             '--output-dir',output.resolve(),'--cc',args.cc,'--engine',args.engine,'--timeout',args.timeout]
    if args.engine=='v8':
        assert shutil.which('node'),'Node is required for V8'
        command+=['--filter','corpus/']
    result=subprocess.run(list(map(str,command)),cwd=source)
    assert result.returncode in (0,1)
    current=read(output/'report.json');assert 'error' not in current
    assert current['input_sha256']==current['input_sha256_after']
    selected=read(source/'tests/conformance/cases.json')['cases']
    if args.engine=='v8':
        selected=[case for case in selected if 'corpus/' in case['id']]
    expected=collections.Counter((case['id'],level) for case in selected for level in case['levels'])
    actual=collections.Counter((row['case'],row['level']) for row in current['results'])
    assert expected==actual,'A contract/level was omitted or duplicated'
    parent=read(HERE/'qualification/parent-conformance.json.gz')
    old={(row['case'],row['level']):row for row in parent['results']}
    if args.engine=='v8':
        old={key:row for key,row in old.items() if 'corpus/' in row['case']}
    new={(row['case'],row['level']):row for row in current['results']}
    inherited={key for key,row in old.items() if row['status']!='pass'}
    failures={key for key,row in new.items() if row['status']!='pass'}
    assert old.keys()<=new.keys()
    passed=failures==inherited
    receipt=dict(status='failed',summary=current['summary'],inherited_gaps=len(inherited),
                 unexpected_failures=sorted(failures-inherited),changed_inherited_gaps=sorted(inherited-failures))
    if passed:
        receipt['status']='passed'
    (output/'parent-comparison.json').write_text(json.dumps(receipt,indent=2)+'\n');print(receipt)
    return int(not passed)


def main():
    parser=argparse.ArgumentParser(description=__doc__);commands=parser.add_subparsers(dest='action',required=True)
    commands.add_parser('verify')
    composing=commands.add_parser('compose');composing.add_argument('--output-dir',type=Path,default=HERE/'composed-58');composing.add_argument('--stage',choices=('transition','final','upgrade'),default='final')
    boot=commands.add_parser('bootstrap');boot.add_argument('--output-dir',type=Path,default=HERE/'built-58');boot.add_argument('--cc',default='clang')
    public=commands.add_parser('public-bootstrap');public.add_argument('--output-dir',type=Path,default=HERE/'public-built-58');public.add_argument('--cc',default='clang')
    checks=commands.add_parser('contracts');checks.add_argument('--compiler',type=Path,default=HERE/'public-built-58/build/bin/goose');checks.add_argument('--output-dir',type=Path);checks.add_argument('--engine',choices=('wasmtime','v8'),default='wasmtime');checks.add_argument('--cc',default='gcc');checks.add_argument('--timeout',type=float,default=15)
    native=commands.add_parser('native-runtime');native.add_argument('--output-dir',type=Path,default=HERE/'native-runtime-58');native.add_argument('--cc',default='clang')
    args=parser.parse_args();verify()
    if args.action=='verify':
        print('All capsule inputs match recorded hashes.');return 0
    if args.action=='compose':
        compose(args.output_dir.resolve(),args.stage);print('Stage source pins reproduced.');return 0
    if args.action=='bootstrap':
        bootstrap(args.output_dir.resolve(),args.cc);return 0
    if args.action=='public-bootstrap':
        public_bootstrap(args.output_dir.resolve(),args.cc);return 0
    if args.action=='native-runtime':
        env=dict(os.environ,CC=args.cc);run([sys.executable,HERE/'source/native/tests/check.py','--output',args.output_dir.resolve()],env=env);return 0
    return contracts(args)


if __name__=='__main__':
    raise SystemExit(main())
