from pathlib import Path
import json,hashlib
root=Path.cwd();here=Path(__file__).resolve().parent;source=root/'build/completion-runs/lifetime-facts-58'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sealed=json.loads((source/'sealed.json').read_text())
for name,digest in sealed.items():assert sha(source/name)==digest,name
proof=json.loads((source/'fixture-proof.json').read_text())
assert sha(source/'packed-facts-fixture.goose')==proof['source_sha256']
cases=[]
programs=[{'id':'packed-facts','source':'packed-facts-fixture.goose','expect':{'stdout':proof['expected_stdout'],'exit':proof['expected_runtime_exit']}}]
for trap in proof['invalid_positive_type_guards']:
 assert sha(source/trap['source'])==trap['source_sha256']
 programs.append({'id':trap['source'].removesuffix('.goose'),'source':trap['source'],'expect':{'stdout':trap['expected_stdout'],'exit':'nonzero'}})
for p in programs:
 for target in proof['matrix']['target']:
  for debug in proof['matrix']['debug']:
   cases.append({'id':f"lifetime-facts58/{p['id']}/{target}/debug-{debug}",'source':str((source/p['source']).relative_to(root)),'phase':'run','target':target,'levels':proof['matrix']['optimization'],'stdin':'','expect':p['expect'],'debug':debug,'provenance':'Frozen hand-expected fixture-proof.json before any execution; nonzero traps exclude SIGSEGV/SIGBUS/SIGILL through generic runner.'})
upstream=json.loads((root/'tests/conformance/cases.json').read_text())['upstream']
manifest={'schema':'goose-source-output-contracts-v1','upstream':upstream,'method':'Runner adaptation only from independently frozen packed-facts fixture-proof.json; no expected output capture, reference compiler or C++ oracle. Native/V8/Wasmtime admission across debug and O0/O2.','cases':cases}
(here/'cases.json').write_text(json.dumps(manifest,indent=2)+'\n')
(here/'preflight.json').write_text(json.dumps({'status':'frozen-inputs-verified','original_fixture_proof_sha256':sha(source/'fixture-proof.json'),'original_sealed_sha256':sha(source/'sealed.json'),'actual_source_sha256':sha(source/'checker_lifetimes.goose'),'source_helper_oracle':'five pure source helpers byte-identical per source audit','manifest_sha256':sha(here/'cases.json'),'case_rows':len(cases),'level_rows':sum(len(c['levels'])for c in cases),'hard_packed_words':[85,87,89,150,166],'source_policy':'All original sources and expected stdout/exit data remain unchanged. Stop candidate execution if baseline admission fails.'},indent=2)+'\n')
print('frozen',len(cases),'cases /',sum(len(c['levels'])for c in cases),'level rows')
