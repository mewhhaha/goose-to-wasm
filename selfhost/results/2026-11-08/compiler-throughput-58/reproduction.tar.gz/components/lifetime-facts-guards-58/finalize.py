from pathlib import Path
import json,hashlib
here=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
phases=['baseline','a11']
if (here/'a12-summary.json').exists():phases.append('a12')
counts={};trap_audit=[]
for phase in phases:
 summary=json.loads((here/f'{phase}-summary.json').read_text());assert summary['status']=='passed'
 runtime=traps=0
 for run in summary['runs']:
  report=json.loads(Path(run['report']).read_text());assert report['summary']=={'selected':40,'passed':40,'failed':0}
  for row in report['results']:
   observation=report['commands'][row['run_command']];runtime+=1
   if 'invalid-type'in row['case']:
    traps+=1
    diagnostic=observation['stderr'].splitlines()[0]if observation['stderr']else''
    assert observation['exit_code']==1 and 'index'in diagnostic.lower() and observation['stdout']=='',(row,observation)
    trap_audit.append({'phase':phase,'engine':run['engine'],'case':row['case'],'level':row['level'],'exit_code':observation['exit_code'],'checked_index_diagnostic':diagnostic})
 counts[phase]={'compiler':summary['compiler'],'compiler_sha256':summary['compiler_sha256'],'observations':runtime,'checked_index_traps':traps,'positive_runtime_observations':runtime-traps,'passed_per_engine_driver':40,'final_PGO_profile_sha256_before':summary['final_PGO_profile_sha256_before'],'final_PGO_profile_sha256_after':summary['final_PGO_profile_sha256_after']}
(here/'trap-audit.json').write_text(json.dumps({'status':'all-checked-index-traps','policy':'Read-only review of executed trap results, not an expected-output capture or change to frozen tests.','observations':trap_audit},indent=2)+'\n')
identity=json.loads((here/'pure-helper-identities.json').read_text())
delivery={'status':'passed','scope':'Frozen packed lifetime fact helper admission only; no whole compiler build, complete contracts or performance claim.','compilers':counts,'unique_case_level_checks':40,'total_observations':sum(v['observations']for v in counts.values()),'expected_policy':'Original sealed sources and all hand-expected data unchanged; no candidate capture or C++ oracle. Invalid-positive guards require traps rather than fabricated cached answers.','matrix':'native and wasm-direct; O0/O2; debug false/true. Wasm executes under both Wasmtime and V8 driver runs; native rows repeat under each driver.','pure_helpers':identity,'hard_packed_word_expectations':[85,87,89,150,166],'new_source_candidate':'compiler-facts-58 A12 remains pending binary announcement; same manifest is ready.'if'a12'not in phases else'compiler-facts-58 A12 admitted with the same frozen manifest.','manifest_sha256':sha(here/'cases.json'),'original_guard_proof_sha256':sha(here.parent/'lifetime-facts-58/fixture-proof.json')}
(here/'delivery.json').write_text(json.dumps(delivery,indent=2)+'\n')
(here/'sealed.json').write_text(json.dumps({p.name:sha(p)for p in sorted(here.iterdir())if p.is_file()and p.name!='sealed.json'},indent=2)+'\n')
print('admitted',phases,'observations',delivery['total_observations'],'traps',len(trap_audit))
