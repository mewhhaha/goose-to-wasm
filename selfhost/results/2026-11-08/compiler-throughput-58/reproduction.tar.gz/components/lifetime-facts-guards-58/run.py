from pathlib import Path
import hashlib,json,subprocess,sys,importlib.metadata,shutil
root=Path.cwd();here=Path(__file__).resolve().parent;r=root/'build/completion-runs';phase=sys.argv[1]
assert phase in ['baseline','a11','a12']
compiler={'baseline':r/'compiler-baseline-57/bin/goose','a11':r/'compiler-lean-format-58/goose','a12':r/'compiler-facts-58/goose'}[phase]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if phase!='baseline':assert json.loads((here/'baseline-summary.json').read_text())['status']=='passed'
profile=r/'compiler-pgo-58/compiler.profdata';frozen_profile=sha(profile)
manifest=here/'cases.json';expected=40
report={'status':'running','phase':phase,'compiler':str(compiler),'compiler_sha256':sha(compiler),'manifest_sha256':sha(manifest),'CPU':3,'scope':'Correctness admission only; no compiler build or timing claim. Both engine drivers also exercise native rows.','engine_identity':{'node':shutil.which('node'),'node_version':subprocess.check_output(['node','--version'],text=True).strip(),'wasmtime_python':importlib.metadata.version('wasmtime'),'wasmtime_host_sha256':sha(root/'build/bin/goose-wasmtime'),'gcc':shutil.which('gcc'),'gcc_sha256':sha(Path(shutil.which('gcc')))},'final_PGO_profile_sha256_before':frozen_profile,'runs':[]}
summary=here/f'{phase}-summary.json';summary.write_text(json.dumps(report,indent=2)+'\n')
for engine in ['wasmtime','v8']:
 output=here/f'{phase}-{engine}';command=['taskset','-c','3',sys.executable,str(root/'tests/conformance.py'),'--compiler',str(compiler),'--manifest',str(manifest),'--output-dir',str(output),'--engine',engine,'--cc','gcc','--timeout','30']
 with (here/f'{phase}-{engine}.log').open('x')as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,cwd=root)
 receipt={'engine':engine,'command':command,'exit_code':result.returncode,'report':str(output/'report.json')}
 if (output/'report.json').exists():
  actual=json.loads((output/'report.json').read_text());receipt.update(status=actual['status'],summary=actual.get('summary'),stable_inputs=actual.get('input_sha256')==actual.get('input_sha256_after'))
  receipt['failed_rows']=[dict(row,compile_stderr=actual['commands'][row['compile_command']]['stderr'],run=actual['commands'][row['run_command']]if 'run_command'in row else None)for row in actual.get('results',[])if row['status']!='pass']
 report['runs'].append(receipt);summary.write_text(json.dumps(report,indent=2)+'\n');print(phase,engine,receipt.get('summary'),flush=True)
 if result.returncode!=0:break
report['status']='passed'
if len(report['runs'])!=2 or any(x.get('summary')!={'selected':expected,'passed':expected,'failed':0}or not x.get('stable_inputs')or x['exit_code']!=0 for x in report['runs']):report['status']='failed'
report['final_PGO_profile_sha256_after']=sha(profile);assert report['final_PGO_profile_sha256_after']==frozen_profile
summary.write_text(json.dumps(report,indent=2)+'\n');raise SystemExit(report['status']!='passed')
