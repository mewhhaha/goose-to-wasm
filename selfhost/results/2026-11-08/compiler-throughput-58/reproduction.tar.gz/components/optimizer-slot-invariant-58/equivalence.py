from pathlib import Path
import hashlib, json, os, re, subprocess, time
ROOT = Path('/home/jacobt/src/goose-to-wasm')
TASK = ROOT / 'build/completion-runs/optimizer-slot-invariant-58'
MANIFEST = TASK / 'input-manifest.json'
OUT = TASK / 'equivalence'
OUT.mkdir(exist_ok=False)
os.sched_setaffinity(0, {1})
manifest = json.loads(MANIFEST.read_text())
compilers = {
    'released-a18': ROOT / manifest['A18_compiler']['path'],
    'instrumented': ROOT / manifest['instrumented_compiler']['path'],
}

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def save():
    (OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n')

def clean_stderr(text):
    lines=[]
    counters=[]
    for line in text.splitlines():
        match=re.fullmatch(r'OPT_SLOT_INVARIANTS clone=(\d+) temporary=(\d+)',line)
        if match:
            counters.append({'clone':int(match.group(1)),'temporary':int(match.group(2))})
        else:
            lines.append(line)
    return '\n'.join(lines) + ('\n' if text.endswith('\n') and lines else ''), counters

report={'status':'running','cpu':1,'manifest_sha256':digest(MANIFEST),'compilers':{k:{'path':str(v),'sha256':digest(v)} for k,v in compilers.items()},'configuration':{'targets':['native','wasm-direct'],'optimization':'-O2','standalone':True,'timeout_seconds':180},'runs':[],'comparisons':[]}
save()
for item in manifest['inputs']:
    source=ROOT/item['path']
    if digest(source) != item['sha256']:
        raise RuntimeError('frozen input changed: '+item['path'])
    slug=item['id'].replace('/','__')
    for backend in ('native','wasm-direct'):
        target=backend
        artifacts={}
        for label,compiler in compilers.items():
            directory=OUT/'artifacts'/label/slug/backend
            directory.mkdir(parents=True)
            artifact=directory/('program.c' if target=='native' else 'program.wasm')
            command=[str(compiler),str(source),'--stdlib',str(ROOT/'stdlib'),'--target',target,'-O2','--standalone','-o',str(artifact)]
            start=time.monotonic()
            try:
                proc=subprocess.run(command,cwd=ROOT,capture_output=True,timeout=180)
                exit_code=proc.returncode
                stdout=proc.stdout.decode(errors='replace')
                stderr=proc.stderr.decode(errors='replace')
                error=''
            except subprocess.TimeoutExpired as exc:
                exit_code=None
                stdout=(exc.stdout or b'').decode(errors='replace')
                stderr=(exc.stderr or b'').decode(errors='replace')
                error='timeout'
            except OSError as exc:
                exit_code=None; stdout=''; stderr=''; error=str(exc)
            elapsed=time.monotonic()-start
            clean,counters=clean_stderr(stderr)
            artifact_exists=artifact.is_file()
            row={'input_id':item['id'],'kind':item['kind'],'source':item['path'],'source_sha256':item['sha256'],'backend':backend,'compiler':label,'compiler_sha256':digest(compiler),'command':command,'exit_code':exit_code,'error':error,'stdout':stdout,'stderr':stderr,'stderr_without_instrumentation':clean,'slot_counter_lines':counters,'artifact':str(artifact),'artifact_exists':artifact_exists,'artifact_sha256':digest(artifact) if artifact_exists else None,'seconds':elapsed}
            report['runs'].append(row)
            artifacts[label]=row
            save()
        base=artifacts['released-a18']; candidate=artifacts['instrumented']
        expected_unsupported=(item['id']=='fixture/recursive_pool_default' and backend=='wasm-direct')
        comparison={'input_id':item['id'],'kind':item['kind'],'backend':backend,'expected_strict_unsupported_wasm_pool':expected_unsupported,
                    'exit_equal':base['exit_code']==candidate['exit_code'],'error_equal':base['stderr_without_instrumentation']==candidate['stderr_without_instrumentation'],
                    'stdout_equal':base['stdout']==candidate['stdout'],'artifact_presence_equal':base['artifact_exists']==candidate['artifact_exists'],
                    'artifact_hash_equal':(base['artifact_sha256']==candidate['artifact_sha256']) if base['artifact_exists'] and candidate['artifact_exists'] else None,
                    'equivalent':False}
        comparison['equivalent']=comparison['exit_equal'] and comparison['error_equal'] and comparison['stdout_equal'] and comparison['artifact_presence_equal'] and (comparison['artifact_hash_equal'] is not False)
        if expected_unsupported and base['exit_code'] not in (None,0):
            comparison['failure_phase']='backend-codegen-after-optimize' if base['slot_counter_lines'] else 'before-optimizer'
            comparison['preserved_diagnostic']=base['stderr_without_instrumentation']
        report['comparisons'].append(comparison)
        save()
report['input_sha256_after']={item['path']:digest(ROOT/item['path']) for item in manifest['inputs']}
report['inputs_unchanged']=all(report['input_sha256_after'][item['path']]==item['sha256'] for item in manifest['inputs'])
report['counter_summary']={}
for label in compilers:
    rows=[r for r in report['runs'] if r['compiler']==label]
    counters=[c for r in rows for c in r['slot_counter_lines']]
    report['counter_summary'][label]={'optimizer_invocations_with_line':len(counters),'clone_checks':sum(c['clone'] for c in counters),'temporary_checks':sum(c['temporary'] for c in counters),'runs_with_missing_counter_line':[r['input_id']+'/'+r['backend'] for r in rows if r['exit_code']==0 and not r['slot_counter_lines']]}
instrumented=[r for r in report['runs'] if r['compiler']=='instrumented']
report['assertion_failures']=[{'input_id':r['input_id'],'backend':r['backend'],'exit_code':r['exit_code'],'stderr':r['stderr']} for r in instrumented if r['exit_code'] not in (0,1) or 'assertion failed' in r['stderr'].lower() or 'assert(' in r['stderr'].lower()]
report['summary']={'inputs':len(manifest['inputs']),'benchmarks':sum(x['kind']!='public-fixture' for x in manifest['inputs']),'public_fixtures':sum(x['kind']=='public-fixture' for x in manifest['inputs']),'compiler_runs':len(report['runs']),'comparisons':len(report['comparisons']),'equivalent':sum(c['equivalent'] for c in report['comparisons']),'mismatches':sum(not c['equivalent'] for c in report['comparisons']),'successful_artifact_comparisons':sum(c['artifact_hash_equal'] is True for c in report['comparisons']),'expected_unsupported_pool_comparisons':sum(c['expected_strict_unsupported_wasm_pool'] for c in report['comparisons'])}
report['status']='passed' if report['summary']['mismatches']==0 and report['inputs_unchanged'] and not report['assertion_failures'] else 'failed'
save()
print(json.dumps({'status':report['status'],'summary':report['summary'],'counter_summary':report['counter_summary'],'assertion_failures':report['assertion_failures']},indent=2))
if report['status']!='passed': raise SystemExit(1)
