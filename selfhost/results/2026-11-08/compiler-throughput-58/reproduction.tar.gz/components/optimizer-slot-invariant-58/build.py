from pathlib import Path
import hashlib, json, shutil, subprocess, time
ROOT = Path('/home/jacobt/src/goose-to-wasm')
BASE = ROOT / 'build/completion-runs/compiler-record-paths-58'
TASK = ROOT / 'build/completion-runs/optimizer-slot-invariant-58'
OUT = TASK / 'candidate-build'
PRODUCER = BASE / 'goose'
SOURCE = TASK / 'selfhost/main.goose'
STDLIB = TASK / 'stdlib'
C_SOURCE = OUT / 'compiler-instrumented.c'
HOST = OUT / 'goose-instrumented'
CC = shutil.which('clang-23')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

commands = [
    ['taskset', '-c', '1', str(PRODUCER), str(SOURCE), '--stdlib', str(STDLIB), '--target', 'native', '-O0', '-o', str(C_SOURCE)],
]
report = {
    'status': 'running', 'cpu': 1, 'producer': str(PRODUCER), 'producer_sha256': digest(PRODUCER),
    'source_pins_sha256': digest(TASK / 'source-pins.json'), 'patch_sha256': digest(TASK / 'candidate.patch'),
    'goose_optimization': 0, 'native_compiler': CC, 'native_optimization': '-O2',
    'commands': [],
}
for index, command in enumerate(commands):
    start = time.monotonic()
    result = subprocess.run(command, cwd=ROOT, capture_output=True, timeout=900)
    (OUT / f'emit-{index}.stdout').write_bytes(result.stdout)
    (OUT / f'emit-{index}.stderr').write_bytes(result.stderr)
    report['commands'].append({'argv': command, 'exit_code': result.returncode,
                               'seconds': time.monotonic() - start,
                               'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(),
                               'stderr_sha256': hashlib.sha256(result.stderr).hexdigest()})
    if result.returncode:
        report.update(status='failed', error=result.stderr.decode(errors='replace')[-4000:])
        (OUT / 'build-report.json').write_text(json.dumps(report, indent=2) + '\n')
        raise SystemExit(1)
if not C_SOURCE.is_file():
    report.update(status='failed', error='A18 producer emitted no C source')
    (OUT / 'build-report.json').write_text(json.dumps(report, indent=2) + '\n')
    raise SystemExit(1)
report['compiler_c_sha256'] = digest(C_SOURCE)
command = ['taskset', '-c', '1', CC, '-std=gnu11', '-O2', str(C_SOURCE), '-lm', '-ldl', '-pthread', '-o', str(HOST)]
start = time.monotonic()
result = subprocess.run(command, cwd=ROOT, capture_output=True, timeout=900)
(OUT / 'cc.stdout').write_bytes(result.stdout)
(OUT / 'cc.stderr').write_bytes(result.stderr)
report['commands'].append({'argv': command, 'exit_code': result.returncode,
                           'seconds': time.monotonic() - start,
                           'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(),
                           'stderr_sha256': hashlib.sha256(result.stderr).hexdigest()})
if result.returncode:
    report.update(status='failed', error=result.stderr.decode(errors='replace')[-4000:])
    (OUT / 'build-report.json').write_text(json.dumps(report, indent=2) + '\n')
    raise SystemExit(1)
report.update(status='passed', instrumented_host=str(HOST), instrumented_host_sha256=digest(HOST))
(OUT / 'build-report.json').write_text(json.dumps(report, indent=2) + '\n')
print(HOST)
