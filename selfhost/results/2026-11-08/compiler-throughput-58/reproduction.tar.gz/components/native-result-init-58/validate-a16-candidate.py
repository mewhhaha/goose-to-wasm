from pathlib import Path
import json,hashlib,subprocess,os,shutil
R=Path('/home/jacobt/src/goose-to-wasm');H=Path(__file__).resolve().parent;G=H/'guards';O=H/'candidate-a16-runtime';O.mkdir();C=json.loads((G/'contract.json').read_text());source=R/C['source'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(source)==C['sha256'];host=R/'build/completion-runs/compiler-native-fields-58/goose';os.sched_setaffinity(0,{4});report=dict(status='running',compiler=str(host),compiler_sha256=sha(host),source_sha256=sha(source),contract_sha256=sha(G/'contract.json'),cpu=4,runs=[],commands=[])
def save():(O/'report.json').write_text(json.dumps(report,indent=2)+'\n')
def run(command):
 p=subprocess.run([str(x) for x in command],cwd=R,text=True,capture_output=True,timeout=60);report['commands'].append(dict(command=[str(x) for x in command],exit=p.returncode,stdout=p.stdout,stderr=p.stderr));save();assert p.returncode==0,report['commands'][-1];return p.stdout,len(report['commands'])-1
try:
 for level in C['levels']:
  for debug in C['debug']:
   D=O/('O'+str(level)+'-debug'+str(debug));D.mkdir();common=[host,source,'--stdlib',R/'stdlib','-O'+str(level),'--standalone']
   if debug:common.append('--debug')
   native=D/'program.c';binary=D/'program';run([*common,'--target','native','-o',native]);run(['/usr/bin/gcc','-std=gnu11','-O'+str(level),native,'-lm','-ldl','-pthread','-o',binary]);stdout,index=run([binary]);assert stdout==C['stdout'];report['runs'].append(dict(level=level,debug=debug,target='native',command=index,passed=True))
   wasm=D/'program.wasm';run([*common,'--target','wasm-direct','-o',wasm])
   for engine,command in [('wasmtime',[R/'build/bin/goose-wasmtime','--no-cache',wasm]),('v8',['node',R/'scripts/run_wasm.mjs',wasm])]:
    stdout,index=run(command);assert stdout==C['stdout'];report['runs'].append(dict(level=level,debug=debug,target='wasm-direct',engine=engine,command=index,passed=True))
   save();print('O'+str(level),debug,'passed',flush=True)
 assert sha(source)==report['source_sha256'];report['status']='passed';report['observations']=len(report['runs']);report['node_version']=subprocess.check_output(['node','--version'],text=True).strip()
except BaseException as error:report['status']='failed';report['error']=repr(error);raise
finally:save()
