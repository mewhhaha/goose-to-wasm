from pathlib import Path
import argparse,hashlib,json,os,re,subprocess
R=Path('/home/jacobt/src/goose-to-wasm');H=Path(__file__).resolve().parent;G=H/'guards';a=argparse.ArgumentParser();a.add_argument('--compiler',required=True);a.add_argument('--output-dir',required=True);a.add_argument('--candidate',action='store_true');a=a.parse_args();O=Path(a.output_dir).resolve();O.mkdir();os.sched_setaffinity(0,{4});sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[];commands=[]
def execute(cmd):
 p=subprocess.run([str(x) for x in cmd],cwd=R,text=True,capture_output=True,timeout=60);commands.append(dict(command=[str(x) for x in cmd],exit=p.returncode,stderr=p.stderr));assert p.returncode==0,commands[-1];return p.stdout
def body(text,identity):
 m=re.search(r'\bg_fn'+str(identity)+r'\([^;]*?\)\s*\{',text);assert m,identity
 at=m.end();start=at;depth=1
 while depth:
  if text.startswith('//',at):at=text.index('\n',at);continue
  if text.startswith('/*',at):at=text.index('*/',at+2)+2;continue
  ch=text[at]
  if ch in ['"',"'"]:
   quote=ch;at+=1
   while text[at]!=quote:
    if text[at]=='\\':at+=1
    at+=1
  elif ch=='{':depth+=1
  elif ch=='}':depth-=1
  at+=1
 return text[start:at-1]
for contract_name in ['contract.json','image-contract.json']:
 contract=G/contract_name;C=json.loads(contract.read_text());source=R/C['source'];assert sha(source)==C['sha256']
 for level in C['levels']:
  for debug in C['debug']:
   label=source.stem+'-O'+str(level)+'-debug'+str(debug);native=O/(label+'.c');base=[str(Path(a.compiler).resolve()),source,'--stdlib',R/'stdlib','--target','native','-O'+str(level)]
   if debug:base.append('--debug')
   execute([*base,'--standalone','-o',native]);raw=execute([*base,'--dump-ir']);(O/(label+'.json')).write_text(raw);ir=json.loads(raw);text=native.read_text();functions={}
   for n in ir['nodes']:
    if n['kind']==3 and ir['tokens'][n['token']]['source']==0:functions[ir['tokens'][n['token']]['text']]=n
   for name in C['eligible']+C['retained']:
    n=functions[name];type_id=ir['types'][n['type_id']]['element'];b=body(text,n['id']);decl=re.search(r'\bg_t'+str(type_id)+r'\s+g_result\s*([^;]*);',b);checks={};eligible=name in C['eligible']
    if eligible:
     if a.candidate:
      checks['entry_zero_omitted']=bool(decl) and decl.group(1).strip()=='';fallback='g_result=(g_t'+str(type_id)+'){};';required=C['fallback'][name];checks['fallback_presence']=(fallback in b)==required
      if required:
       gotos=[m.start() for m in re.finditer(r'goto g_return;',b)];checks['fallback_after_explicit_returns']=bool(gotos) and b.index(fallback)>max(gotos) and b.index(fallback)<b.index('g_return:;')
     else:checks['baseline_entry_zero']=bool(decl) and decl.group(1).strip()=='={}'
     checks['complete_result_store']=bool(re.search(r'g_store_'+str(type_id)+r'\(g_ref\(\(void\*\)&g_result\),g_v\d+\);',b));checks['full_store_helper']=bool(re.search(r'\bg_store_'+str(type_id)+r'\([^;]*?\)\{\s*memmove\(g_address\(p\),&v,sizeof v\);\}',text))
    else:
     form=C.get('retained_result_form',{}).get(name,'image')
     if form in ['indirect','image']:checks['receiving_alias_retained']='#define g_result (*g_into)' in b
     elif form=='channels':checks['channel_result_retained']=not decl and 'g_ref(g_into)' in b
     else:
      zero='={}'
      if form=='initialized-scalar':zero='={0}'
      checks['result_zero_retained']=bool(decl) and decl.group(1).strip()==zero
      if form=='initialized-volatile':checks['volatile_retained']='volatile g_t'+str(type_id)+' g_result' in b
    rows.append(dict(function=name,type=type_id,optimization=level,debug=debug,eligible=eligible,checks=checks,passed=all(checks.values()),C_sha256=sha(native),contract_sha256=sha(contract)))
status='failed'
if rows and all(r['passed'] for r in rows):status='passed'
report=dict(status=status,candidate=a.candidate,checks=len(rows),compiler_sha256=sha(Path(a.compiler)),rows=rows,commands=commands);(O/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(status,len(rows));assert status=='passed'
