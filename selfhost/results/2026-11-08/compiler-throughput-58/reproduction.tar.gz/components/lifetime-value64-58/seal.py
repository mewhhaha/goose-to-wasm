from pathlib import Path
import json,hashlib
h=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();receipt={'status':'passed','CPU':3,'compiler':'build/completion-runs/compiler-plain-58/goose','compiler_sha256':sha(h.parent/'compiler-plain-58/goose'),'source':json.loads((h/'source.json').read_text()),'observations':[],'scope':'Frozen hand-expected actual-helper guards compiled by unchanged A10; no candidate compiler execution, full compiler build, timing claim or candidate-generated golden outputs.'}
traps=[]
for engine in ['wasmtime','v8']:
 report=h/('final-'+engine)/'report.json';p=json.loads(report.read_text());assert p['summary']=={'selected':24,'passed':24,'failed':0};assert p['input_sha256']==p['input_sha256_after']
 receipt['observations'].append({'engine':engine,'summary':p['summary'],'stable_inputs':True,'report_sha256':sha(report),'report':str(report)})
 for row in p['results']:
  if '/bounds/' in row['case']:
   c=p['commands'][row['run_command']];assert c['exit_code']==1 and 'out of bounds'in c['stderr'];traps.append({'engine':engine,'case':row['case'],'level':row['level'],'exit_code':1,'stderr':c['stderr']})
receipt['checked_bounds_observations']=len(traps);receipt['initial_supported_v1']={'summary':json.loads((h/'parent-supported-wasmtime/report.json').read_text())['summary'],'scope':'Earlier supported fixture used weaker effect-equality assertion; strengthened fixture final receipts above supersede it. First unsupported spelling and failed admission remain preserved.'}
(h/'trap-observations.json').write_text(json.dumps(traps,indent=2)+'\n')
proof=json.loads((h/'guard-proof.json').read_text());old={x['function']:x['sha256']for x in proof['extractions']if x.get('tag')=='Old'and'function'in x};new={x['function']:x['sha256']for x in proof['extractions']if x.get('tag')=='New'and'function'in x};assert len(old)==7
receipt['unchanged_actual_helper_sha256']={name:identity for name,identity in old.items()if new[name]==identity};assert len(receipt['unchanged_actual_helper_sha256'])==6
c=h/'final-wasmtime/artifacts/0/program.c';t=c.read_text();assert 'typedef struct { unsigned char data[65]; } g_t18;'in t;assert 'typedef struct { unsigned char data[64]; } g_t26;'in t
receipt['parent_generated_layout']={'C_sha256':sha(c),'OldValue':'g_t18 unsigned char data[65]','NewValue':'g_t26 unsigned char data[64]','embedded_item':'g_t19 73→g_t27 72','embedded_effect':'g_t20 105→g_t28 104','embedded_hold':'g_t21 73→g_t29 72'}
(h/'delivery.json').write_text(json.dumps(receipt,indent=2)+'\n')
# Seal source/evidence, not redundant generated executables.
files=[p for p in h.iterdir()if p.is_file()and p.name!='sealed.json'];(h/'sealed.json').write_text(json.dumps({p.name:sha(p)for p in sorted(files)},indent=2)+'\n')
# Prior read-only scan evidence.py whitespace correction occurred after its first seal.
scan=h.parent/'cell-live-scan-58';saved=json.loads((scan/'sealed.json').read_text());saved['evidence.py']=sha(scan/'evidence.py');(scan/'sealed.json').write_text(json.dumps(saved,indent=2)+'\n')
print('passed48 observations,32 checked index traps; source',receipt['source']['candidate_sha256'])
