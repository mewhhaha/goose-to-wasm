from pathlib import Path
import hashlib,difflib,json
root=Path(__file__).resolve().parent;base=root.parent/'compiler-plain-58/selfhost/checker_lifetimes.goose'
old=base.read_text();assert hashlib.sha256(old.encode()).hexdigest()=='371d2614214a5b462040df235d078f2e772801a9dd638f38ec4ef3c8e4e9f7df'
new=old.replace(', in_elements: bool = false','',1)
new=new.replace(' && old.value.in_elements == effect.value.in_elements','',1)
new=new.replace('if value.in_elements ||','if value.element_array != -1 ||',1)
new=new.replace('var element_read = value.in_elements;','var element_read = value.element_array != -1;',1)
new=new.replace('if receiver.in_elements &&','if receiver.element_array != -1 &&',1)
new=new.replace('''        out.in_elements = base.in_elements || n.kind == N_INDEX || n.kind == N_SLICE;
        out.element_array = base.element_array;''','''        out.element_array = base.element_array;''',1)
needle='''            if out.element_array >= 0 && p.types[out.element_array].kind == TY_REF { out.element_array = p.types[out.element_array].element; }
        }
        if l.sequence_frame'''
replacement='''            if out.element_array >= 0 && p.types[out.element_array].kind == TY_REF { out.element_array = p.types[out.element_array].element; }
            if out.element_array < 0 { out.element_array = -2; }
        }
        if l.sequence_frame'''
assert new.count(needle)==1;new=new.replace(needle,replacement,1)
new=new.replace('struct LifeValue {','// Element owner: -1 none, -2 inside elements with unknown owner, otherwise type ID.\nstruct LifeValue {',1)
assert 'in_elements'not in new
(root/'checker_lifetimes.goose').write_text(new)
(root/'candidate.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/selfhost/checker_lifetimes.goose',tofile='b/selfhost/checker_lifetimes.goose')))
(root/'source.json').write_text(json.dumps({'baseline':str(base),'baseline_sha256':hashlib.sha256(old.encode()).hexdigest(),'candidate_sha256':hashlib.sha256(new.encode()).hexdigest(),'patch_sha256':hashlib.sha256((root/'candidate.patch').read_bytes()).hexdigest(),'LifeValue_bytes':{'old':65,'new':64},'element_array_offset':{'old':57,'new':56}},indent=2)+'\n')
