from pathlib import Path
import re,json,hashlib
h=Path(__file__).resolve().parent
base=Path(json.loads((h/'source.json').read_text())['baseline']).read_text();new=(h/'checker_lifetimes.goose').read_text()
sha=lambda x:hashlib.sha256(x.encode()).hexdigest()
def fn(src,name):
 m=re.search(r'(?:recursive |inline )?fn '+name+r'\(',src);assert m
 start=src.index('{',m.start());depth=1;end=start+1
 while depth:
  if src[end]=='{':depth+=1
  if src[end]=='}':depth-=1
  end+=1
 return src[m.start():end]
def block(src,start,end):return src[src.index(start):src.index(end,src.index(start))]
parts=['import std;\nlet TY_REF:i64=2; let TY_SLICE:i64=3; let TY_ARRAY:i64=4; let TYPE_VOID:i64=0; let S_GLOBAL:i64=1; let S_MUTABLE:i64=2; let N_MEMBER:i64=1; let N_INDEX:i64=2; let N_SLICE:i64=3;\nstruct Type { kind:i64=1, element:i64=-1 }\nstruct Symbol { flags:i64=0 }\nstruct Program { types:Type[>..]&, symbols:Symbol[>..]& }\n']
records=[]
for tag,src in [('Old',base),('New',new)]:
 val=re.search(r'struct LifeValue \{[^\n]+',src).group();parts.append(val.replace('LifeValue',tag+'Value')+'\n')
 parts.append('''struct TAGItem { value:TAGValue, next:i64=-1 }
struct TAGEffect { kind:i64=0,node:i64=-1,value:TAGValue,places:i64=0,field:i64=-1,cell:i64=-1 }
struct TAGHold { value:TAGValue,kind:i64=0 }
struct TAGSet { first:i64=-1 }
struct TAGAlt { root:i64=0,next:i64=-1,exact:bool=true,from:i64=-1,byteview:bool=false,target_type:i64=-1,bound:i64=0 }
struct TAGRoot { symbol:i64=-1 }
struct TAGL { items:TAGItem[>..]&, sets:TAGSet[>..]&, alts:TAGAlt[>..]&,roots:TAGRoot[>..]&,holds:TAGHold[>..]&, discovery:bool=false, reading_place:i64=0,hold_count:i64=0,errors:i64=0,effects:i64=0 }
fn TAG_life_join(l:TAGL&,a:i64,b:i64)->i64 { return a | b; }
fn TAG_life_equal(l:TAGL&,a:i64,b:i64)->bool { return a == b; }
fn TAG_life_contents(l:TAGL&,a:i64)->i64 { return 0; }
fn TAG_life_live_contents(l:TAGL&,a:i64)->i64 { return 0; }
fn TAG_life_readback(p:Program&,l:TAGL&,t:i64,a:i64)->i64 { return a; }
fn TAG_life_is_ref(p:Program&,t:i64)->bool { return t >= 0 && (p.types[t].kind == TY_REF || p.types[t].kind == TY_SLICE); }
fn TAG_life_holds(p:Program&,t:i64)->bool { return TAG_life_is_ref(p,t); }
fn TAG_life_single(l:TAGL&,r:i64,e:bool=true,f:i64=-1,s:bool=false,b:bool=false,t:i64=-1,z:i64=0)->i64 { return 1; }
fn TAG_life_interior(l:TAGL&,a:i64)->i64 { return a; }
fn TAG_life_clear_reads(l:TAGL&,a:i64)->i64 { return a; }
fn TAG_life_effect(l:TAGL&,e:TAGEffect) { l.effects += 1; }
fn TAG_life_error(p:Program&,l:TAGL&,n:i64,message:const u8[:]) { l.errors += 1; }
fn TAG_life_cached_size_class(p:Program&,l:TAGL&,t:i64)->i64 { if t >= 0 && p.types[t].kind == TY_ARRAY { return 2; } return 0; }
fn TAG_life_same(p:Program&,a:i64,b:i64)->bool { return a == b; }
fn TAG_life_contains(p:Program&,l:TAGL&,a:i64,b:i64)->bool { return a == b; }
fn TAG_life_overlaps(l:TAGL&,a:i64,b:i64)->bool { return (a & b) != 0; }
'''.replace('TAG',tag))
 def adapt(s):
  for a,b in [('LifeValue',tag+'Value'),('LifeItem',tag+'Item'),('LifeEffect',tag+'Effect'),('Lifetimes',tag+'L')]:s=s.replace(a,b)
  return re.sub(r'\blife_(\w+)',lambda m:tag+'_life_'+m[1],s)
 for name in ['life_load','life_coerce','life_item','life_append','life_merge','life_cycle_value','life_construct_read']:
  text=fn(src,name);parts.append(adapt(text)+'\n');records.append({'tag':tag,'function':name,'sha256':sha(text)})
 start='        out.element_array = base.element_array;'
 if tag=='Old':start='        out.in_elements = base.in_elements ||'
 text=block(src,start,'        if l.sequence_frame');text=text.replace('n.kind','kind')
 parts.append(adapt('fn '+tag+'_track(p:Program&,base:LifeValue,kind:i64)->LifeValue { var out = base;\n'+text+' return out; }')+'\n');records.append({'tag':tag,'fragment':'member/index/slice','sha256':sha(text)})
 pred=block(src,'                    if !l.discovery && old.kind == effect.kind','                        external = false; break;').strip()[3:].rsplit('{',1)[0]
 parts.append(adapt('fn '+tag+'_effect_equal(l:Lifetimes&,old:LifeEffect,effect:LifeEffect)->bool { return '+pred+'; }')+'\n')
 receiver='receiver.in_elements'
 if tag=='New':receiver='receiver.element_array != -1'
 parts.append('fn '+tag+'_receiver(receiver:'+tag+'Value,builtin:i64)->bool { return '+receiver+' && (builtin >= 24 || builtin == 2) || builtin == 16; }\n')
 parts.append(adapt('fn '+tag+'_call_normalize(p:Program&,out0:LifeValue,result_type:i64,place:i64)->LifeValue { var out=out0;\n'+block(src,'        out.type_id = n.type_id;','        var contents = out.contents;').replace('n.type_id','result_type')+'return out; }')+'\n')
parts.append('''fn compare(a:OldValue,b:NewValue,expected:i64) {
 assert(b.element_array == expected);
 if expected == -1 { assert(!a.in_elements && a.element_array == -1); }
 else if expected == -2 { assert(a.in_elements && a.element_array == -1); }
 else { assert(a.in_elements && a.element_array == expected); }
 assert(a.type_id == b.type_id && a.place == b.place && a.refs == b.refs && a.contents == b.contents && a.self_pools == b.self_pools && a.relative_roots == b.relative_roots);
}
fn main() {
 var types:Type[>..]=[Type {},Type {kind:TY_ARRAY,element:0},Type {kind:TY_REF,element:1},Type {kind:TY_REF},Type {kind:TY_SLICE,element:0},Type {kind:TY_ARRAY,element:1},Type {kind:TY_REF,element:5},Type {kind:TY_REF,element:4}];
 var symbols:Symbol[>..]=[]; var p=Program {types:types,symbols:symbols};
 var oi:OldItem[>..]=[];var os:OldSet[>..]=[];var oa:OldAlt[>..]=[];var oroot:OldRoot[>..]=[];var oh:OldHold[>..]=[];
 var ni:NewItem[>..]=[];var ns:NewSet[>..]=[];var na:NewAlt[>..]=[];var nr:NewRoot[>..]=[];var nh:NewHold[>..]=[];
 for index in 0..128 { os.push(OldSet {});ns.push(NewSet {}); }
 var ol=OldL {items:oi,sets:os,alts:oa,roots:oroot,holds:oh};var nl=NewL {items:ni,sets:ns,alts:na,roots:nr,holds:nh};
 let owners:i64[5]=[-1,-2,1,5,4];let ids:i64[7]=[-1,1,2,3,4,5,6];let resolved:i64[7]=[-2,1,1,-2,4,5,5];
 for state in 0..5 {
  let owner=owners[state];var a=OldValue {type_id:0,place:1,refs:2,contents:4,self_pools:8,relative_roots:16};var b=NewValue {type_id:0,place:1,refs:2,contents:4,self_pools:8,relative_roots:16,element_array:owner};
  if state > 0 { a.in_elements=true; } if owner >= 0 { a.element_array=owner; }
  compare(a,b,owner);
  for j in 0..7 { a.type_id=ids[j];b.type_id=ids[j];
   for kind in [N_MEMBER,N_INDEX,N_SLICE] { var expect=owner;if kind != N_MEMBER && owner < 0 { expect=resolved[j]; }compare(Old_track(p,a,kind),New_track(p,b,kind),expect); }
  }
  a.type_id=4;b.type_id=4;
  for target in [-1,0,1,2,4,7] { compare(Old_life_coerce(p,ol,a,target),New_life_coerce(p,nl,b,target),owner); }
  a.type_id=7;b.type_id=7;compare(Old_life_coerce(p,ol,a,4),New_life_coerce(p,nl,b,4),-1);
  a.type_id=0;b.type_id=0;
  for result in [0,2,4] { compare(Old_call_normalize(p,a,result,32),New_call_normalize(p,b,result,32),owner); }
  for builtin in [0,2,16,23,24,25,34] { var expected=builtin == 16 || state > 0 && (builtin == 2 || builtin >=24);assert(Old_receiver(a,builtin)==expected && New_receiver(b,builtin)==expected); }
  for second in 0..5 {
   let owner2=owners[second];var c=a;var d=b;c.in_elements=false;c.element_array=-1;d.element_array=owner2;if second>0 {c.in_elements=true;}if owner2>=0 {c.element_array=owner2;}
   compare(Old_life_merge(ol,a,c),New_life_merge(nl,b,d),owner);
   let oe=Old_effect_equal(ol,OldEffect {value:a},OldEffect {value:c});let ne=New_effect_equal(nl,NewEffect {value:b},NewEffect {value:d});assert(oe == (state == second) && ne == (state == second));
   assert(!Old_effect_equal(ol,OldEffect {value:a},OldEffect {value:c,field:2}) && !New_effect_equal(nl,NewEffect {value:b},NewEffect {value:d,field:2}));
  }
  let ot=Old_life_append(ol,-1,a);let nt=New_life_append(nl,-1,b);compare(Old_life_item(ol,ot,0),New_life_item(nl,nt,0),owner);
  var ta=OldValue {tuple:ot};var tb=NewValue {tuple:nt};let ca=Old_life_cycle_value(ol,ta);let cb=New_life_cycle_value(nl,tb);compare(Old_life_item(ol,ca.tuple,0),New_life_item(nl,cb.tuple,0),owner);
  let ma=Old_life_merge(ol,ta,ta);let mb=New_life_merge(nl,tb,tb);compare(Old_life_item(ol,ma.tuple,0),New_life_item(nl,mb.tuple,0),owner);
  // Unknown owner remains conservatively inside elements and never indexes types[-2].
  oh.push(OldHold {value:OldValue {type_id:5,place:1},kind:2});nh.push(NewHold {value:NewValue {type_id:5,place:1},kind:2});ol.hold_count=1;nl.hold_count=1;ol.errors=0;nl.errors=0;ol.effects=0;nl.effects=0;
  Old_life_construct_read(p,ol,0,a);New_life_construct_read(p,nl,0,b);
  var expected_error=0;if state>0 && owner!=4 {expected_error=1;}assert(ol.errors==expected_error && nl.errors==expected_error);
  var expected_effect=0;if state>0 {expected_effect=1;}assert(ol.effects==expected_effect && nl.effects==expected_effect);oh.clear();nh.clear();
 }
 var a=OldValue {};var b=NewValue {};a=Old_track(p,a,N_INDEX);b=New_track(p,b,N_INDEX);compare(a,b,-2);a=Old_track(p,a,N_MEMBER);b=New_track(p,b,N_MEMBER);compare(a,b,-2);a.type_id=2;b.type_id=2;a=Old_track(p,a,N_INDEX);b=New_track(p,b,N_INDEX);compare(a,b,1);a.type_id=6;b.type_id=6;a=Old_track(p,a,N_MEMBER);b=New_track(p,b,N_MEMBER);a=Old_track(p,a,N_SLICE);b=New_track(p,b,N_SLICE);compare(a,b,1);
 a.type_id=128;b.type_id=128;compare(Old_track(p,a,N_INDEX),New_track(p,b,N_INDEX),1);
 compare(Old_life_load(p,ol,0,0),New_life_load(p,nl,0,0),-1);compare(Old_life_item(ol,-1,0),New_life_item(nl,-1,0),-1);
 print("value64 guards passed");
}
''')
text=''.join(parts);(h/'fixture.goose').write_text(text)
manifest=json.loads((h.parent/'lifetime-single-58/cases.json').read_text());manifest['method']='Frozen hand-expected three-state encoding matrix plus actual A10/candidate extracted transitions, copy helpers and diagnostic predicates. Alias-set support is explicitly abstract bitsets; no full compiler build.'
for c in manifest['cases']:c['id']=c['id'].replace('singleton58','value64');c['source']='build/completion-runs/lifetime-value64-58/fixture.goose';c['expect']['stdout']='value64 guards passed\n'
(h/'cases.json').write_text(json.dumps(manifest,indent=2)+'\n')
(h/'guard-proof.json').write_text(json.dumps({'fixture_sha256':sha(text),'extractions':records,'hard_expectations':{'states':[-1,-2,1,5,4],'base_types':[-1,1,2,3,4,5,6],'unknown_index_resolves':[-2,1,1,-2,4,5,5],'known_owner_preserved':True,'none_unknown_known_diagnostic_expected':[0,1,1,1,0]},'scope':'Actual full load/coerce/item/append/merge/cycle/read helpers, actual tracking/effect/call-normalize fragments; bitset alias support stubs, fixed valid checked Type graph. No arbitrary corrupted IR equivalence claim.'},indent=2)+'\n')

# Checked bounds failures are independent guards: stdout after the actual helper must be unreachable.
prefix=text[:text.index('fn main()')]
for tag in ['Old','New']:
 trap=prefix+'fn main() { var types:Type[>..]=[Type {}];var symbols:Symbol[>..]=[];var p=Program {types:types,symbols:symbols};let result='+tag+'_track(p,'+tag+'Value {type_id:128},N_INDEX);print("unexpected",result.type_id); }\n'
 name='bounds-'+tag.lower()+'.goose';(h/name).write_text(trap)
 for target in ['native','wasm-direct']:
  for debug in [False,True]:
   manifest['cases'].append({'id':'value64/bounds/'+tag+'/'+target+'/'+str(debug),'source':'build/completion-runs/lifetime-value64-58/'+name,'phase':'run','target':target,'levels':[0,2],'debug':debug,'stdin':'','expect':{'stdout':'','exit':'nonzero'}})
(h/'cases.json').write_text(json.dumps(manifest,indent=2)+'\n')
