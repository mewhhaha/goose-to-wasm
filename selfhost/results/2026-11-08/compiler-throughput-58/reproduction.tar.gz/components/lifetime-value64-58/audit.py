from pathlib import Path
import json,re,hashlib
h=Path(__file__).resolve().parent;identity=json.loads((h/'source.json').read_text());base=Path(identity['baseline']);old=base.read_text();new=(h/'checker_lifetimes.goose').read_text();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
reads=[];constructors=[]
for file in sorted(base.parent.glob('*.goose')):
 s=file.read_text()
 for i,line in enumerate(s.splitlines(),1):
  if re.search(r'\b(in_elements|element_array)\b',line):reads.append({'file':file.name,'line':i,'source':line.strip()})
 for m in re.finditer(r'\bLifeValue\s*\{',s):
  prefix=s[max(0,m.start()-16):m.start()].strip()
  if prefix.endswith('struct') or prefix.endswith('->'):continue
  at=m.end();depth=1
  while depth:
   if s[at]=='{':depth+=1
   if s[at]=='}':depth-=1
   at+=1
  entry=s[m.start():at];assert not re.search(r'\b(in_elements|element_array)\s*:',entry)
  constructors.append({'file':file.name,'line':s.count('\n',0,m.start())+1,'source':entry})
assert {r['file']for r in reads}=={'checker_lifetimes.goose'}
assert not re.search(r'\b(?:type_id|element)\s*(?::|=)\s*-[2-9]', '\n'.join(p.read_text() for p in base.parent.glob('*.goose')))
expected={'in_elements':2,'element_array':4}
# Count assignment targets, ignoring equality comparison and declarations.
writes={name:len(re.findall(r'\.'+name+r'\s*=(?!=)',old)) for name in expected}
assert writes=={'in_elements':1,'element_array':3},writes
proof={'status':'source-approved by independent Astra exact review','baseline_sha256':sha(base),'candidate_sha256':sha(h/'checker_lifetimes.goose'),'patch_sha256':sha(h/'candidate.patch'),'valid_old_states':[[False,-1],[True,-1],[True,'nonnegative type ID']],'encoding':{'none':-1,'unknown elements':-2,'known elements':'unchanged nonnegative type ID'},'invariant':[
'All explicit LifeValue constructors omit both fields, using false/-1; default values embedded in frames/exits also do so.',
'The only direct field writes are adjacent in the member/index/slice branch: member inherits both; index/slice sets flag true and derives owner only while previous owner is negative.',
'Checked type IDs and reference element IDs use -1 as the only negative unknown. Thus every reachable old state is exactly one of the three listed states.',
'Copies of LifeValue, effects, holds, frame results, tuple items and exits copy the pair together. Merge deliberately retains a pair while joining alias sets; it does not merge owner tags.',
'The encoded state is a bijection; unknown is distinct from none. Element-array >=0 guard and subsequent owner-type reads remain unchanged.',
'Index/slice inherits a known owner unchanged; unknown may resolve to a known owner on any later index because the original <0 condition is retained. Unresolved negatives normalize to-2.',
'Coerce paths that copy preserve encoding; reference-to-slice load constructs a fresh default none. Call normalization changes result type/place/refs but preserves encoding.',
'Effect deduplication now compares the injective encoding instead of its two original components; no other filter changes.',
'The complete source inventory has no extra external read/write dependencies; arbitrary corrupted negative type IDs are outside this proof.'
], 'reads_and_writes':reads,'direct_write_counts':writes,'constructor_count':len(constructors),'constructors':constructors,'layout':{'old_bytes':65,'new_bytes':64,'old_final_i64_offset':57,'new_final_i64_offset':56,'basis':'Packed declaration order: seven i64 followed by bool+i64 becomes eight i64. Parent compiler fixture emits g_t18 data[65] and g_t26 data[64].'},'guards':{'actual_helpers':['load','coerce','item','append','merge','cycle_value','construct_read'],'actual_fragments':['member/index/slice tag transition','effect equality','normal call result normalization','receiver builtin hold predicate'],'abstract_support':'Alias sets are bitsets and readback/contains helpers use a fixed checked type graph; guards target representation and diagnostics, not the complete lifetime engine. Full compiler contract admission remains root work.','first_failure':'fixture-first-unsupported.goose used unknown type spelling string in stub; errors preserved in parent-wasmtime/report.json. Replaced by existing source spelling const u8[:] with hand expectations unchanged.'},'performance':'No timing claim or full compiler build. Removing one byte makes the frequently copied value exactly64 bytes; measurement admission remains required.'}
(h/'audit.json').write_text(json.dumps(proof,indent=2)+'\n')
print('inventory',len(reads),'lines;',len(constructors),'default-pair constructors;',writes)
