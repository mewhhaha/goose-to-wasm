from pathlib import Path
import subprocess,time,json,hashlib
root=Path.cwd();w=root/'build/completion-runs';out=w/'compiler-host-o0-58'
def run(cmd,name):
 start=time.monotonic();p=subprocess.run(list(map(str,cmd)),capture_output=True,text=True);(out/(name+'.stderr')).write_text(p.stderr);(out/(name+'.stdout')).write_text(p.stdout);r=dict(command=list(map(str,cmd)),exit_code=p.returncode,seconds=time.monotonic()-start);(out/(name+'.json')).write_text(json.dumps(r,indent=2)+'\n');assert not p.returncode,p.stderr;print(name,round(r['seconds'],2),flush=True)
args=[w/'compiler-plain-58/selfhost/main.goose','--stdlib',root/'stdlib','--target','native','-O0']
run(['taskset','-c','1',w/'compiler-plain-58/goose',*args,'--wasm-stats',out/'self-o2-stats.json','-o',out/'compiler.c'],'emit')
run(['taskset','-c','1','clang-23','-std=gnu11','-O2',out/'compiler.c','-lm','-ldl','-pthread','-o',out/'goose'],'cc')
run(['taskset','-c','1',out/'goose',*args,'-o',out/'verify.c'],'verify')
a=hashlib.sha256((out/'compiler.c').read_bytes()).hexdigest();b=hashlib.sha256((out/'verify.c').read_bytes()).hexdigest();(out/'fixedpoint.json').write_text(json.dumps(dict(matching=a==b,first=a,following=b),indent=2)+'\n');print('fixedpoint',a==b,flush=True)
