from pathlib import Path
import sys,json,shutil,subprocess
ROOT=Path('/home/jacobt/src/goose-to-wasm');WORK=ROOT/'build/completion-runs/wasm-emission-58';out=WORK/'pilot';sys.path.insert(0,str(ROOT/'bench'));import compare_compilers as compare
report=json.loads((out/'report.json').read_text());assert report['status']=='passed';report['pinned_engine_validations']=[]
report['pinned_engine_environment']=dict(python=sys.executable,node=shutil.which('node'),node_version=subprocess.check_output(['node','--version'],text=True).strip())
args=type('Args',(),dict(cc='/usr/bin/clang-23',cpu=1,timeout=120,node='node'))()
for case in report['workloads']:
 directory=out/f'validate-pinned-{case["name"]}-wasm';directory.mkdir();path=out/f'{case["name"]}.wasm-direct.candidate.4.wasm';result=compare.validate(path,case,'wasm-direct',args,directory);report['pinned_engine_validations'].append(dict(case=case['name'],**result));(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');assert result['status']=='passed',(case,result)
print(json.dumps(report['pinned_engine_environment']));print('Pinned engine checks passed',len(report['pinned_engine_validations'])*2)
