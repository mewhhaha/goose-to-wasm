from pathlib import Path
import hashlib,json,os,random,statistics,subprocess,sys,time
ROOT=Path('/home/jacobt/src/goose-to-wasm');WORK=ROOT/'build/completion-runs/wasm-emission-58'
sys.path.insert(0,str(ROOT/'bench'));import compare_compilers as compare
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
cases=compare.workloads(); cpu=7
compilers={'baseline':ROOT/'build/bin/goose','candidate':WORK/'goose'}
out=WORK/'pilot';out.mkdir(exist_ok=False)
report=dict(status='running',scope='Exploratory process compiler emission pilot; identical baseline/candidate input paths; one warmup plus 5 paired balanced randomized rounds; no C++ oracle; baseline output identity and independently checked golden outputs.',cpu=cpu,compilers={k:dict(path=str(v),sha256=sha(v)) for k,v in compilers.items()},workloads=cases,rows=[],identity=[],validations=[])
def save(): (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
save(); rng=random.Random(580057)
try:
 for rep in range(-1,5):
  cells=[(case,target) for case in cases for target in ('wasm-direct','native-c')];rng.shuffle(cells)
  for case,target in cells:
   tags=list(compilers);rng.shuffle(tags);paths={}
   for tag in tags:
    ext='wasm'
    if target=='native-c': ext='c'
    path=out/f'{case["name"]}.{target}.{tag}.{rep}.{ext}';paths[tag]=path
    cmd=list(map(str,compare.build_command(compilers[tag],tag,case,target,path,ROOT/'stdlib')))
    cmd=['taskset','-c',str(cpu),*cmd];t=time.perf_counter();r=subprocess.run(cmd,cwd=ROOT,capture_output=True,timeout=120);elapsed=time.perf_counter()-t
    row=dict(sample=rep,tag=tag,case=case['name'],target=target,command=cmd,seconds=elapsed,exit_code=r.returncode,stdout=r.stdout.decode(),stderr=r.stderr.decode());report['rows'].append(row);save();assert r.returncode==0,row
    row['sha256']=sha(path)
   assert paths['baseline'].read_bytes()==paths['candidate'].read_bytes(),(case,target,rep)
   report['identity'].append(dict(sample=rep,case=case['name'],target=target,sha256=sha(paths['baseline'])));save()
 # Execute one paired artifact (all outputs already proven identical) against each independent expected output.
 args=type('Args',(),dict(cc='/usr/bin/clang-23',cpu=cpu,timeout=120,node='node'))()
 for case in cases:
  for target in ('wasm-direct','native-c'):
   ext='wasm'
   if target=='native-c':ext='c'
   directory=out/f'validate-{case["name"]}-{target}';directory.mkdir()
   path=out/f'{case["name"]}.{target}.candidate.4.{ext}'
   result=compare.validate(path,case,target,args,directory);report['validations'].append(dict(case=case['name'],target=target,**result));save();assert result['status']=='passed',(case,target,result)
 summary=[]
 for case in cases:
  for target in ('wasm-direct','native-c'):
   med={tag:statistics.median(r['seconds'] for r in report['rows'] if r['sample']>=0 and r['tag']==tag and r['case']==case['name'] and r['target']==target) for tag in compilers}
   summary.append(dict(case=case['name'],target=target,**med,ratio=med['candidate']/med['baseline']))
 report['summary']=summary;report['status']='passed';print(json.dumps(summary,indent=2))
except BaseException as e:report.update(status='failed',error=repr(e));raise
finally:save()
