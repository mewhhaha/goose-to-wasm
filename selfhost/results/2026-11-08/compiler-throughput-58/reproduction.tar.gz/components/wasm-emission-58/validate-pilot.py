from pathlib import Path
import sys,json,statistics,hashlib
ROOT=Path('/home/jacobt/src/goose-to-wasm');WORK=ROOT/'build/completion-runs/wasm-emission-58';out=WORK/'pilot';sys.path.insert(0,str(ROOT/'bench'));import compare_compilers as compare
report=json.loads((out/'report.json').read_text());assert len(report['identity'])==132
(out/'report-rejected-default-python.json').write_text(json.dumps(report,indent=2)+'\n')
report['rejected_validation_attempt']=dict(report='report-rejected-default-python.json',reason='Default Python lacks Wasmtime50.0.1. Measurements and 132 byte-identity pairs complete; resumed deferred validation with project .venv interpreter.')
report['validations']=[];report['status']='validating';report.pop('error',None)
def save():(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
args=type('Args',(),dict(cc='/usr/bin/clang-23',cpu=1,timeout=120,node='node'))()
try:
 for case in report['workloads']:
  for target in ('wasm-direct','native-c'):
   ext='wasm'
   if target=='native-c':ext='c'
   directory=out/f'validate-resumed-{case["name"]}-{target}';directory.mkdir()
   path=out/f'{case["name"]}.{target}.candidate.4.{ext}';result=compare.validate(path,case,target,args,directory);report['validations'].append(dict(case=case['name'],target=target,**result));save();assert result['status']=='passed',(case,target,result)
 summary=[]
 for case in report['workloads']:
  for target in ('wasm-direct','native-c'):
   med={tag:statistics.median(r['seconds'] for r in report['rows'] if r['sample']>=0 and r['tag']==tag and r['case']==case['name'] and r['target']==target) for tag in report['compilers']}
   summary.append(dict(case=case['name'],target=target,**med,ratio=med['candidate']/med['baseline']))
 report['summary']=summary;report['status']='passed';print(json.dumps(summary,indent=2))
except BaseException as e:report.update(status='failed',error=repr(e));raise
finally:save()
