from pathlib import Path
import hashlib,json,subprocess,sys,time
ROOT=Path('/home/jacobt/src/goose-to-wasm');WORK=ROOT/'build/completion-runs/wasm-emission-58';b=ROOT/'build/completion-runs/astra-resolver-57';out=WORK/'guards-frame-padding';out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();report=dict(status='running',scope='Snapshot57 independent contracts, baseline output identity, debug/O0/O2; captures, defaults, scalar/fallback, pools and varint; expected outputs from frozen preexecution manifests.',rows=[],manifests={})
selected=[]
for m in [str(WORK/'frame-padding-manifest.json')]:
 p=b/m;manifest=json.loads(p.read_text());report['manifests'][m]=sha(p)
 for case in manifest['cases']:
  source=b/case['source'];assert sha(source)==case['source_sha256'];selected.append((case,source,manifest['profiles']))
def run(cmd,stdin=''):
 t=time.monotonic();r=subprocess.run(list(map(str,cmd)),input=stdin,text=True,capture_output=True,timeout=120,cwd=ROOT);return dict(command=list(map(str,cmd)),seconds=time.monotonic()-t,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr)
def save():(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
try:
 for case,source,profiles in selected:
  for profile in profiles:
   row=dict(case=case['id'],profile=profile['name'],compiles=[],executions=[]);report['rows'].append(row);artifacts=[]
   for tag,compiler in [('baseline',ROOT/'build/bin/goose'),('candidate',WORK/'goose')]:
    artifact=out/f'{case["id"]}-{profile["name"]}-{tag}.wasm';r=run(['taskset','-c','1',compiler,source,'--stdlib',ROOT/'stdlib','--target','wasm-direct',*profile['flags'],'-o',artifact]);row['compiles'].append(r);save();assert r['returncode']==0,r;artifacts.append(artifact)
   assert artifacts[0].read_bytes()==artifacts[1].read_bytes(),row;row['byte_identical']=True;row['wasm_sha256']=sha(artifacts[1])
   for engine in ['v8','wasmtime']:
    cmd=['node',ROOT/'scripts/run_wasm.mjs',artifacts[1]]
    if engine=='wasmtime':cmd=[sys.executable,ROOT/'scripts/run_wasmtime.py',artifacts[1]]
    r=run(['taskset','-c','1',*cmd],case['stdin']);row['executions'].append(r);save();assert r['returncode']==case['expected_exit_code'] and r['stdout']==case['expected_stdout'] and not r['stderr'],r
 report['status']='passed'
except BaseException as e:report.update(status='failed',error=repr(e));raise
finally:save()
print(json.dumps(dict(status=report['status'],byte_identical_cells=len(report['rows']),golden_engine_checks=sum(len(r['executions']) for r in report['rows']))))
