A4 is relative to the actual A3 checker in compiler-format-58/selfhost,
including its defensive symbol >= 0 check in owner invalidation. Only the
render_hooks append loop changes.

For a symbol to pass check_render_hook's first candidate filter it must have:

- owner < 0 and node >= 0;
- name "format";
- S_FUNCTION set and S_BUILTIN clear;
- the selected namespace/global scope.

The presence ledger asks for the first two conditions and S_BUILTIN clear,
without the function or scope restrictions. Every hook candidate is therefore
a presence witness. A false ledger result proves every candidate in both
namespace rounds will fail that first filter.

Before that filter, check_render_hook only reads a Type, walks namespace
parents, reads symbols and compares token text. There are no writes to p or
c, no diagnostics, and no calls that can append declarations. Its first
possibly mutating call, check_prepare_function, is after the filter. With
no witness, it returns -1 without reaching that call or check_operation_same.

The replacement checks the ledger immediately where the old call occurred,
after check_render_layout and after pushing the same initial -1 entry. It
does not reuse the earlier hooks_exist local: layout may append symbols.
If false, leaving the entry at -1 equals the old return value. If true, the
entire original hook scan still executes, including diagnostics and type or
symbol creation. The loop still observes p.types.len after every iteration.
Existing cached -1 entries are neither invalidated nor recomputed, preserving
the existing cache policy.

The A3 cases at checker-format-index-58/cases.json already freeze 52 checks
covering both paths, later declarations, namespace/overload selection,
nonfunctions, builtin/local shadowing, and unused-hook diagnostics. This A4
proposal adds no new expectation derived from a compiler run. Full conformance
and same-input output equivalence remain required before admission.

Static follow-on review: check_type, check_array_type, and check_type_const
can replace their value-copy foreach bindings with an integer index loop and
an explicit const Type&. Their scan bodies contain only scalar comparisons
and early returns: no calls, type writes, or array growth. Capturing the array
length in a range therefore preserves traversal order and the first matching
ID. add_type executes only after the loop/reference scope ends. Keep
check_type_const's `var copy = p.types[ty]` as a value: changing its flags must
not mutate the interned type. These optional loop changes are not in A4.

No compiler build or execution was performed for this review.
