from pathlib import Path
import argparse,hashlib,json,os,re,subprocess
R=Path('/home/jacobt/src/goose-to-wasm');H=Path(__file__).resolve().parent;G=H/'guards';a=argparse.ArgumentParser();a.add_argument('--runtime-report',required=True);a.add_argument('--output-dir',required=True);a.add_argument('--candidate',action='store_true');a=a.parse_args();O=Path(a.output_dir).resolve();O.mkdir();os.sched_setaffinity(0,{5});sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();proof=json.loads(Path(a.runtime_report).read_text());assert proof['status']=='passed';contracts={}
for name in ['contract.json','old-a14-runtime-v2-structure.json']:
 P=G/name;C=json.loads(P.read_text());assert sha(R/C['source'])==C['sha256'];contracts[C['source']]=(C,P)
rows=[];commands=[];seen=set()
def body(text,identity):
 m=re.search(r'\bg_fn'+str(identity)+r'\([^;]*?\)\s*\{',text)
 if not m:return None
 at=m.end();start=at;depth=1
 while depth:
  if text.startswith('//',at):at=text.index('\n',at);continue
  if text.startswith('/*',at):at=text.index('*/',at+2)+2;continue
  ch=text[at]
  if ch in ['"',"'"]:
   quote=ch;at+=1
   while text[at]!=quote:
    if text[at]=='\\':at+=1
    at+=1
  elif ch=='{':depth+=1
  elif ch=='}':depth-=1
  at+=1
 return text[start:at-1]
def declaration(b,type_id,identity):return re.search(r'\bg_t'+str(type_id)+r'\s+g_s'+str(identity)+r'\s*([^;]*);',b)
def check_local(b,native,type_id,identity,eligible,new_named):
 d=declaration(b,type_id,identity);fixed='g_fixed_g_s'+str(identity)+' __attribute__((cleanup(g_fixed_release)))=g_fixed_begin(sizeof(g_t'+str(type_id)+'),1);' in b;alias=bool(re.search(r'#define g_s'+str(identity)+r'\s',b));checks={}
 if eligible:
  if a.candidate:checks['entry_zero_omitted']=bool(d) and d.group(1).strip()==''
  elif new_named:checks['old_named_metadata_retains_zero']=bool(d) and d.group(1).strip()=='={}'
  else:checks['ordinary_storage_present']=bool(d) and d.group(1).strip() in ['','={}']
  refs=re.findall(r'g_v(\d+)=g_ref\(&g_s'+str(identity)+r'\);',b);checks['full_declaration_store']=any(re.search(r'g_store_'+str(type_id)+r'\(g_v'+ref+r',g_v\d+\);',b) for ref in refs);checks['complete_store_helper']=bool(re.search(r'\bg_store_'+str(type_id)+r'\([^;]*?\)\{\s*memmove\(g_address\(p\),&v,sizeof v\);\}',native))
 else:checks['fallback_storage_retained']=fixed or alias or bool(d) and d.group(1).strip()=='={}'
 return checks
for result in proof['results']:
 cmd=proof['commands'][result['compile_command']]['command']
 if cmd[cmd.index('--target')+1]!='native':continue
 artifact=Path(cmd[cmd.index('-o')+1])
 if str(artifact) in seen:continue
 seen.add(str(artifact));source=Path(cmd[1]);relative=str(source.relative_to(R));C,contract=contracts[relative];text=artifact.read_text();debug='--debug' in cmd;ircommand=[cmd[0],str(source),'--target','native','--stdlib',str(R/'stdlib'),'-O'+str(result['level']),'--dump-ir']
 if debug:ircommand.append('--debug')
 p=subprocess.run(ircommand,cwd=R,text=True,capture_output=True,timeout=60);assert p.returncode==0,p.stderr;ir=json.loads(p.stdout);(O/('ir-'+str(len(seen))+'.json')).write_text(p.stdout);commands.append(ircommand);functions={}
 for n in ir['nodes']:
  if n['kind']==3 and ir['tokens'][n['token']]['source']==0:functions[ir['tokens'][n['token']]['text']]=n['id']
 for eligible,key in [(True,'eligible'),(False,'retained')]:
  for fn,names in C[key].items():
   b=body(text,functions[fn]);assert b is not None,fn
   for name in names:
    syms=[s for s in ir['symbols'] if s['owner']==functions[fn] and s['name_token']>=0 and ir['tokens'][s['name_token']]['text']==name];expected=C.get('multiple_symbols',{}).get(fn+'/'+name,1);assert len(syms)==expected,(fn,name,syms)
    for s in syms:
     checks=check_local(b,text,s['type_id'],s['id'],eligible,(fn,name) in [('named','result'),('tuple_pair','named_pair'),('inline_pair','item')]);checks['source_scope_nonnegative']=s['scope']>=0
     if fn=='relative_return':checks['actual_receiving_alias']=bool(re.search(r'#define g_s'+str(s['id'])+r'\s',b))
     if fn=='owned_return':checks['actual_receiving_seed_copy']='memcpy(&g_s'+str(s['id'])+',g_address(' in b
     rows.append(dict(source=relative,function=fn,local=name,symbol=s['id'],scope=s['scope'],optimization=result['level'],debug=debug,eligible=eligible,checks=checks,passed=all(checks.values()),C_sha256=sha(artifact),contract_sha256=sha(contract)))
 if 'inline_use' in functions:
  b=body(text,functions['inline_use']);assert b is not None;pair=[s['type_id'] for s in ir['symbols'] if s['owner']==functions['inline_use'] and ir['tokens'][s['name_token']]['text']=='result'];assert len(pair)==1;clones=[int(x) for x in re.findall(r'\bg_t'+str(pair[0])+r'\s+g_s(\d+)\s*[^;]*;',b) if int(x)>=len(ir['symbols'])];expected=0
  if result['level']==2:expected=1
  assert len(clones)==expected,(result['level'],clones)
  for identity in clones:
   checks=check_local(b,text,pair[0],identity,True,False);d=declaration(b,pair[0],identity);checks['negative_scope_fallback_already_omits']=bool(d) and d.group(1).strip()=='';rows.append(dict(source=relative,function='inline_use',local='optimizer-cloned-item',symbol=identity,scope='-2 from opt_clone; id beyond preopt symbol count',optimization=result['level'],debug=debug,eligible=True,checks=checks,passed=all(checks.values()),C_sha256=sha(artifact)))
status='failed'
if rows and all(r['passed'] for r in rows):status='passed'
D=dict(status=status,candidate=a.candidate,checks=len(rows),runtime_report_sha256=sha(Path(a.runtime_report)),method='dump-ir is pre-optimizer. Original function/local IDs are stable; cloned Pair symbol IDs beyond that arena are scope=-2 by exact optimizer source, separately validated.',rows=rows,commands=commands);(O/'report.json').write_text(json.dumps(D,indent=2)+'\n');print(status,len(rows));assert status=='passed'
