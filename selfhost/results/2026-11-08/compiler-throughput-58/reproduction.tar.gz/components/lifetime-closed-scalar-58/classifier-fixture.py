from pathlib import Path
import re,json,hashlib
root=Path(__file__).resolve().parent;source=(root/'checker_lifetimes.goose').read_text();model=(root.parent/'compiler-lean-format-58/selfhost/model.goose').read_text()
def function(name):
 start=re.search(r'^(?:inline |recursive )?fn '+name+r'\(',source,re.M).start();return source[start:source.index('\n}',start)+3]
def struct(text,name):return re.search(r'struct '+name+r' \{.*?\}',text,re.S).group()
def node(**values):
 fields=['kind','token','first','last','next','left','right','third','type_id','symbol','integer','float_value','flags','scope','aux','origin','captures','named_results','coerced_type','expansion_binding']
 return 'Node { '+', '.join(key+': '+str(values[key])for key in fields if key in values)+' }'
constants='\n'.join(l for l in model.splitlines()if l.startswith('let '))
text='import std;\n'+constants+'\n'
for name in ['Node','Type','Symbol']:text+=struct(model,name)+'\n'
for name in ['LifeValue','LifeItem']:text+=struct(source,name)+'\n'
text+='struct Program { nodes: Node[>..]&, types: Type[>..]&, symbols: Symbol[>..]& }\nstruct Lifetimes { items: LifeItem[>..]& }\n'
for name in ['life_raw_scalar','life_scalar_symbol','life_closed_scalar','life_scalar_inputs']:text+=function(name)+'\n'
text+='''
fn main() -> i32 {
    var types: Type[>..] = [];
    for id in 0..13 { types.push(Type { kind: TY_INT }); }
    types[TYPE_VOID].kind=TY_VOID; types[TYPE_BOOL].kind=TY_BOOL;
    types[TYPE_F32].kind=TY_FLOAT; types[TYPE_F64].kind=TY_FLOAT;
    types[TYPE_STRING].kind=TY_SLICE;
    types.push(Type { kind: TY_FN, element: TYPE_I64, first: 1 });
    types.push(Type { kind: TY_INT, storage: 1 });
    var nodes: Node[>..] = []; nodes.resize(24, Node { kind: N_EMPTY });
'''
rows={0:node(kind='N_FUNCTION',first=1,right=2,type_id=13,symbol=0,flags='F_CHECKED'),1:node(kind='N_PARAM',type_id='TYPE_I64',symbol=1),2:node(kind='N_BLOCK',first=3,last=3,type_id='TYPE_VOID'),3:node(kind='N_RETURN',first=4,type_id='TYPE_VOID',symbol=0),4:node(kind='N_BINARY',left=5,right=6,type_id='TYPE_I64',integer='T_PLUS'),5:node(kind='N_NAME',type_id='TYPE_I64',symbol=1),6:node(kind='N_INTEGER',type_id='TYPE_I64',integer=1),7:node(kind='N_VARIABLE',right=8,type_id='TYPE_VOID',symbol=2),8:node(kind='N_INTEGER',type_id='TYPE_I64',integer=0),9:node(kind='N_NAME',type_id='TYPE_I64',symbol=2),10:node(kind='N_UNARY',left=5,type_id='TYPE_I64',integer='T_MINUS'),11:node(kind='N_CAST',left=5,right=12,type_id='TYPE_I64'),12:node(kind='N_TYPE_NAME',type_id='TYPE_I64'),17:node(kind='N_ASSIGN',left=9,right=5,type_id='TYPE_VOID',integer='T_PLUSEQ'),18:node(kind='N_RETURN',first=19,type_id='TYPE_VOID',symbol=0),19:node(kind='N_UNARY',left=9,type_id='TYPE_I64',integer='T_MINUS'),20:node(kind='N_NAME',type_id='TYPE_I64',symbol=3),23:node(kind='N_VARIABLE',type_id='TYPE_VOID',symbol=3)}
for i,value in rows.items():text+='    nodes['+str(i)+'] = '+value+';\n'
text+='''
    var symbols: Symbol[>..] = [
        Symbol { type_id: 13, node: 0, flags: S_FUNCTION },
        Symbol { type_id: TYPE_I64, node: 1, flags: S_PARAMETER, owner: 0 },
        Symbol { type_id: TYPE_I64, node: 7, flags: S_MUTABLE, owner: 0 },
        Symbol { type_id: TYPE_I64, node: 23, flags: S_GLOBAL }
    ];
    var p = Program { nodes: nodes, types: types, symbols: symbols }; var work: i64[>..] = [];
    if !life_closed_scalar(p,0,work) { return 1; }
    p.nodes[3].first=5; if !life_closed_scalar(p,0,work) { return 2; }
    p.nodes[3].first=10; if !life_closed_scalar(p,0,work) { return 3; }
    p.nodes[3].first=11; if !life_closed_scalar(p,0,work) { return 4; }
    p.nodes[3].first=4;
    p.nodes[2].first=7; p.nodes[2].last=18; p.nodes[7].next=17; p.nodes[17].next=18;
    if !life_closed_scalar(p,0,work) { return 5; }
    p.nodes[18].first=9; if life_closed_scalar(p,0,work) { return 6; }
    p.nodes[18].first=19;
    p.nodes[17].symbol=0; if life_closed_scalar(p,0,work) { return 7; } p.nodes[17].symbol=-1;
    p.symbols[2].flags|=S_CAPTURE; if life_closed_scalar(p,0,work) { return 8; } p.symbols[2].flags=S_MUTABLE;
    p.nodes[2].first=3; p.nodes[2].last=3;
    let flags: i64[9]=[F_EXTERN,F_GENERIC,F_RECURSIVE,F_THREAD,F_NONLOCAL,F_CAPTURE,F_DISPATCH,F_SYNTHETIC,F_DEFAULT];
    for flag in flags { p.nodes[0].flags=F_CHECKED|flag; if life_closed_scalar(p,0,work) { return 9; } }
    p.nodes[0].flags=F_CHECKED;
    p.nodes[0].named_results=0; if life_closed_scalar(p,0,work) { return 10; } p.nodes[0].named_results=-1;
    p.nodes[0].captures=0; if life_closed_scalar(p,0,work) { return 11; } p.nodes[0].captures=-1;
    p.symbols[0].owner=1; if life_closed_scalar(p,0,work) { return 12; } p.symbols[0].owner=-1;
    p.nodes[1].right=8; if life_closed_scalar(p,0,work) { return 13; } p.nodes[1].right=-1;
    p.nodes[1].type_id=14; if life_closed_scalar(p,0,work) { return 14; } p.nodes[1].type_id=TYPE_I64;
    p.types[13].element=14; if life_closed_scalar(p,0,work) { return 15; } p.types[13].element=TYPE_I64;
    p.nodes[4].coerced_type=14; if life_closed_scalar(p,0,work) { return 16; } p.nodes[4].coerced_type=-1;
    p.nodes[5].symbol=3; if life_closed_scalar(p,0,work) { return 17; } p.nodes[5].symbol=1;
    p.nodes[4].symbol=0; if life_closed_scalar(p,0,work) { return 18; } p.nodes[4].symbol=-1;
    p.nodes[3].symbol=3; if life_closed_scalar(p,0,work) { return 19; } p.nodes[3].symbol=0;
    p.nodes[4].flags=F_EARLY; if life_closed_scalar(p,0,work) { return 20; } p.nodes[4].flags=0;
    let kinds: i64[27]=[N_CALL,N_WHILE,N_FOR,N_LOOP,N_BREAK,N_CONTINUE,N_MEMBER,N_INDEX,N_SLICE,N_ARRAY,N_FILL,N_RECORD,N_MATCH,N_TUPLE,N_FUNCTION_VALUE,N_GUARD,N_RANGE,N_BINDING,N_TYPE_ARG,N_CONST_FOR,N_RESULT,N_SELF,N_TYPE_REF,N_TYPE_ARRAY,N_TYPE_FN,N_MULTI_ASSIGN,999];
    for kind in kinds { p.nodes[4].kind=kind; if life_closed_scalar(p,0,work) { return 21; } }
    p.nodes[4].kind=N_BINARY;
    p.nodes[3].first=10; p.nodes[10].integer=T_BITAND; if life_closed_scalar(p,0,work) { return 22; }
    p.nodes[10].integer=T_MUL; if life_closed_scalar(p,0,work) { return 23; }
    p.nodes[10].integer=T_MINUS; p.nodes[10].symbol=0; if life_closed_scalar(p,0,work) { return 24; } p.nodes[10].symbol=-1;
    p.nodes[3].first=11; p.nodes[11].symbol=0; if life_closed_scalar(p,0,work) { return 25; } p.nodes[11].symbol=-1;
    p.nodes[3].first=4;
    var items: LifeItem[>..]=[LifeItem { value: LifeValue { type_id: TYPE_I64, place: 99, in_elements: true, element_array: 13 } }];
    var l=Lifetimes { items: items };
    if !life_scalar_inputs(l,-1) || !life_scalar_inputs(l,0) { return 26; }
    l.items[0].value.refs=1; if life_scalar_inputs(l,0) { return 27; } l.items[0].value.refs=0;
    l.items[0].value.contents=1; if life_scalar_inputs(l,0) { return 28; } l.items[0].value.contents=0;
    l.items[0].value.self_pools=1; if life_scalar_inputs(l,0) { return 29; } l.items[0].value.self_pools=0;
    l.items[0].value.relative_roots=1; if life_scalar_inputs(l,0) { return 30; } l.items[0].value.relative_roots=0;
    l.items[0].value.tuple=0; if life_scalar_inputs(l,0) { return 31; } l.items[0].value.tuple=-1;
    l.items.push(LifeItem { value: LifeValue { type_id: TYPE_I64, contents: 1 } }); l.items[0].next=1;
    if life_scalar_inputs(l,0) { return 32; }
    print("closed scalar classifier and input boundary guards passed"); return 0;
}
'''
(root/'classifier-fixture.goose').write_text(text)
proof={'status':'frozen-before-execution','source_sha256':hashlib.sha256(text.encode()).hexdigest(),'expected_exit':0,'expected_stdout':'closed scalar classifier and input boundary guards passed\n','method':'Actual candidate classifier and input predicate, independent explicit accepted/rejected AST and value metadata cases. Rejected nodes include the loop counterexample kind. No mirror of classifier implementation.','precondition':'Positive cases describe valid checked metadata. Negative cases test whitelist boundaries with valid IDs; this is not a total validator for arbitrarily corrupt Program graphs.','matrix':{'targets':['native','wasm-direct'],'levels':[0,2],'debug':[False,True]},'packed_facts_retained':False}
(root/'classifier-fixture-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
