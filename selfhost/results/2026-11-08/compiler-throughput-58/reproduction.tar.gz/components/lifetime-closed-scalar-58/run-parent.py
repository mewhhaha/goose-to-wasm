from pathlib import Path
import json,subprocess,hashlib,sys
root=Path.cwd();here=Path(__file__).resolve().parent;compiler=root/'build/completion-runs/compiler-lean-format-58/goose';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
proof=json.loads((here/'guards-proof.json').read_text())
for c in proof['cases']:assert sha(here/c['source'])==c['source_sha256']
report={'status':'running','compiler':str(compiler),'compiler_sha256':sha(compiler),'guard_proof_sha256':sha(here/'guards-proof.json'),'manifest_sha256':sha(here/'cases.json'),'scope':'Parent A11 correctness observations recorded before candidate compiler build; no timing claim or new compiler build.','runs':[]}
for engine in ['wasmtime','v8']:
 output=here/('parent-'+engine);cmd=['taskset','-c','3',sys.executable,str(root/'tests/conformance.py'),'--compiler',str(compiler),'--manifest',str(here/'cases.json'),'--output-dir',str(output),'--engine',engine,'--cc','gcc','--timeout','30']
 with(here/('parent-'+engine+'.log')).open('x')as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,cwd=root)
 data=json.loads((output/'report.json').read_text());report['runs'].append({'engine':engine,'command':cmd,'exit_code':r.returncode,'summary':data['summary'],'stable_inputs':data['input_sha256']==data['input_sha256_after'],'report':str(output/'report.json')})
 (here/'parent-receipt.json').write_text(json.dumps(report,indent=2)+'\n');print(engine,data['summary'],flush=True)
 if r.returncode:break
report['status']='passed'
if len(report['runs'])!=2 or any(r['exit_code']or r['summary']['failed']or not r['stable_inputs']for r in report['runs']):report['status']='failed'
(here/'parent-receipt.json').write_text(json.dumps(report,indent=2)+'\n')
raise SystemExit(report['status']!='passed')
