from pathlib import Path
import difflib,json,hashlib
root=Path(__file__).resolve().parent;base=root.parent/'compiler-lean-format-58/selfhost/checker_lifetimes.goose'
old=base.read_text();assert hashlib.sha256(old.encode()).hexdigest()=='371d2614214a5b462040df235d078f2e772801a9dd638f38ec4ef3c8e4e9f7df'
helpers='''inline fn life_raw_scalar(ty: i64) -> bool {
    return ty >= TYPE_VOID && ty <= TYPE_F64;
}
fn life_scalar_symbol(p: Program&, symbol: i64, function_node: i64) -> bool {
    if symbol < 0 || symbol >= p.symbols.len { return false; }
    let s: const Symbol& = p.symbols[symbol];
    if s.owner != function_node || s.type_id <= TYPE_VOID || !life_raw_scalar(s.type_id) ||
       (s.flags & (S_GLOBAL | S_CAPTURE | S_FUNCTION | S_TYPE | S_BUILTIN | S_EXTERN)) != 0 { return false; }
    if s.node < 0 || s.node >= p.nodes.len { return false; }
    return p.nodes[s.node].kind == N_PARAM || p.nodes[s.node].kind == N_VARIABLE;
}
fn life_closed_scalar(p: Program&, function_node: i64, work: i64[>..]&) -> bool {
    let f: const Node& = p.nodes[function_node];
    if f.kind != N_FUNCTION || f.right < 0 || (f.flags & F_CHECKED) == 0 ||
       (f.flags & (F_EXTERN | F_GENERIC | F_RECURSIVE | F_THREAD | F_NONLOCAL | F_CAPTURE | F_DISPATCH | F_SYNTHETIC | F_DEFAULT)) != 0 ||
       f.third >= 0 || f.captures >= 0 || f.named_results >= 0 || f.symbol < 0 || f.symbol >= p.symbols.len { return false; }
    let symbol: const Symbol& = p.symbols[f.symbol];
    if symbol.owner >= 0 || symbol.node != function_node || (symbol.flags & S_FUNCTION) == 0 || (symbol.flags & (S_BUILTIN | S_EXTERN | S_CAPTURE)) != 0 { return false; }
    if f.type_id < 0 || f.type_id >= p.types.len || p.types[f.type_id].kind != TY_FN || p.types[f.type_id].first != f.first || !life_raw_scalar(p.types[f.type_id].element) { return false; }
    work.clear(); work.push(f.right);
    if f.left >= 0 { work.push(f.left); }
    var formal = f.first; var formals = 0;
    while formal >= 0 {
        formals += 1; if formals > p.nodes.len { return false; }
        if formal >= p.nodes.len || !life_scalar_symbol(p, p.nodes[formal].symbol, function_node) { return false; }
        let param: const Node& = p.nodes[formal];
        if param.kind != N_PARAM || param.type_id <= TYPE_VOID || !life_raw_scalar(param.type_id) || param.type_id != p.symbols[param.symbol].type_id || param.right >= 0 || p.symbols[param.symbol].node != formal || (p.symbols[param.symbol].flags & S_PARAMETER) == 0 { return false; }
        if param.left >= 0 { work.push(param.left); }
        formal = param.next;
        if work.len > p.nodes.len { return false; }
    }
    var at = 0;
    while at < work.len {
        if work.len > p.nodes.len { return false; }
        let id = work[at]; at += 1;
        if id < 0 || id >= p.nodes.len { return false; }
        let n: const Node& = p.nodes[id]; let kind = n.kind;
        let control = kind == N_BLOCK || kind == N_IF || kind == N_RETURN || kind == N_EXPR_STMT || kind == N_EMPTY;
        if !life_raw_scalar(n.type_id) && !(control && n.type_id < 0) { return false; }
        if n.coerced_type >= 0 && !life_raw_scalar(n.coerced_type) { return false; }
        if n.captures >= 0 || (n.flags & (F_NONLOCAL | F_CAPTURE | F_DISPATCH | F_EARLY | F_REFERENCE | F_REFERENCE_CONTEXT | F_INDEX_TYPE | F_BOUND_TYPE)) != 0 { return false; }
        if kind == N_NAME {
            if !life_scalar_symbol(p, n.symbol, function_node) { return false; }
        } else if kind == N_VARIABLE {
            if n.first >= 0 || !life_scalar_symbol(p, n.symbol, function_node) || p.symbols[n.symbol].node != id || (p.symbols[n.symbol].flags & S_PARAMETER) != 0 { return false; }
        } else if kind == N_RETURN {
            if n.symbol >= 0 && n.symbol != f.symbol { return false; }
            if n.first >= 0 {
                if p.nodes[n.first].next >= 0 { return false; }
                let value: const Node& = p.nodes[n.first];
                if value.kind == N_NAME && value.symbol >= 0 && (p.symbols[value.symbol].flags & S_PARAMETER) == 0 { return false; }
            }
        } else if kind == N_UNARY {
            if n.symbol >= 0 || n.integer != T_PLUS && n.integer != T_MINUS && n.integer != T_NOT && n.integer != T_BITNOT { return false; }
        } else if kind == N_BINARY {
            if n.symbol >= 0 || n.integer != T_PLUS && n.integer != T_MINUS && n.integer != T_MUL && n.integer != T_DIV && n.integer != T_MOD &&
               n.integer != T_EQ && n.integer != T_NEQ && n.integer != T_LT && n.integer != T_GT && n.integer != T_LTEQ && n.integer != T_GTEQ &&
               n.integer != T_SHL && n.integer != T_SHR && n.integer != T_BITAND && n.integer != T_BITOR && n.integer != T_XOR && n.integer != T_ANDAND && n.integer != T_OROR { return false; }
        } else if kind == N_ASSIGN {
            if n.symbol >= 0 || n.left < 0 || p.nodes[n.left].kind != N_NAME || !life_scalar_symbol(p, p.nodes[n.left].symbol, function_node) ||
               n.integer != T_ASSIGN && n.integer != T_PLUSEQ && n.integer != T_MINUSEQ && n.integer != T_MULEQ && n.integer != T_DIVEQ && n.integer != T_MODEQ &&
               n.integer != T_ANDEQ && n.integer != T_OREQ && n.integer != T_XOREQ && n.integer != T_SHLEQ && n.integer != T_SHREQ { return false; }
        } else if kind == N_CAST {
            if n.symbol >= 0 { return false; }
        } else if !control && kind != N_INTEGER && kind != N_FLOAT && kind != N_BOOL && kind != N_TYPE_NAME { return false; }
        if kind == N_BLOCK && n.last >= 0 && (p.nodes[n.last].flags & F_TAIL) != 0 && p.nodes[n.last].kind == N_NAME {
            let tail = p.nodes[n.last].symbol;
            if tail >= 0 && (p.symbols[tail].flags & S_PARAMETER) == 0 { return false; }
        }
        for child in [n.first, n.left, n.right, n.third, n.next] { if child >= 0 { work.push(child); } }
    }
    return true;
}
fn life_scalar_inputs(l: Lifetimes&, arguments: i64) -> bool {
    var at = arguments;
    while at >= 0 {
        let value = l.items[at].value;
        if value.refs != 0 || value.contents != 0 || value.self_pools != 0 || value.relative_roots != 0 || value.tuple >= 0 { return false; }
        at = l.items[at].next;
    }
    return true;
}

'''
source=old.replace('recursive fn life_function(',helpers+'recursive fn life_function(',1)
needle='''    if function_node < 0 || p.nodes[function_node].right < 0 { return LifeValue {}; }
    var lexical = 0;'''
replacement='''    if function_node < 0 || p.nodes[function_node].right < 0 { return LifeValue {}; }
    if l.types_frozen && l.function_frames[function_node] == -2 && life_scalar_inputs(l, arguments) {
        return LifeValue { type_id: p.types[p.nodes[function_node].type_id].element };
    }
    var lexical = 0;'''
assert source.count(needle)==1;source=source.replace(needle,replacement,1)
needle='''    while size_classes.len < p.types.len { size_classes.push(-1); }
    // Standalone argument synthesis is complete; evaluation only reads types.'''
replacement='''    while size_classes.len < p.types.len { size_classes.push(-1); }
    var scalar_work: i64[>..] = [];
    for id in 0..p.nodes.len {
        if p.nodes[id].kind == N_FUNCTION && life_closed_scalar(p, id, scalar_work) { l.function_frames[id] = -2; }
    }
    // Standalone argument synthesis is complete; evaluation only reads types.'''
assert source.count(needle)==1;source=source.replace(needle,replacement,1)
(root/'checker_lifetimes.goose').write_text(source)
(root/'candidate.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),source.splitlines(True),fromfile='a/selfhost/checker_lifetimes.goose',tofile='b/selfhost/checker_lifetimes.goose')))
(root/'identities.json').write_text(json.dumps({'baseline_path':str(base),'baseline_sha256':hashlib.sha256(old.encode()).hexdigest(),'candidate_sha256':hashlib.sha256(source.encode()).hexdigest(),'patch_sha256':hashlib.sha256((root/'candidate.patch').read_bytes()).hexdigest(),'rejected_loop_case_sha256':hashlib.sha256((root.parent/'lifetime-closed-scalar-review-58/caller-loop.goose').read_bytes()).hexdigest()},indent=2)+'\n')
