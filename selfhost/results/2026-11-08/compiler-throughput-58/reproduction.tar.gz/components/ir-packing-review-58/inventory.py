from collections import Counter
import hashlib
import json
from pathlib import Path
import re

root = Path.cwd()
source_root = root / "build/completion-runs/compiler-c-literals-58/selfhost"
out = root / "build/completion-runs/ir-packing-review-58"
model = source_root / "model.goose"
text = model.read_text()


def fields_of(name):
    match = re.search(rf"struct\s+{name}\s*\{{(.*?)\n\}}", text, re.S)
    fields = []
    for field in re.finditer(r"\b([A-Za-z_][A-Za-z0-9_]*)\s*:\s*(i64|f64)\b", match.group(1)):
        fields.append(field.group(1))
    return fields


struct_fields = {"Node": fields_of("Node"), "Token": fields_of("Token")}
sources = list(source_root.rglob("*.goose"))
all_source = "\n".join(path.read_text(errors="replace") for path in sources)
field_stats = {}
literal_stats = {}
alias_stats = {}
function_start = re.compile(r"^(?:(?:inline|recursive)\s+)*fn\s+\w+\s*\(")
function_blocks = []
for source in sources:
    lines = source.read_text(errors="replace").splitlines()
    starts = [index for index, line in enumerate(lines) if function_start.match(line)]
    for start_index, first in enumerate(starts):
        end_index = starts[start_index + 1] if start_index + 1 < len(starts) else len(lines)
        function_blocks.append((source, "\n".join(lines[first:end_index])))
for struct_name, fields in struct_fields.items():
    for field in fields:
        direct_access = len(re.findall(rf"\.\s*{field}\b", all_source))
        direct_write = len(
            re.findall(
                rf"\.\s*{field}\s*(?:=(?!=)|\+=|-=|\*=|/=|%=|\|=|&=|\^=|<<=|>>=)",
                all_source,
            )
        )
        member_pattern = r"\.\s*" + re.escape(field) + r"\b"
        vector_access = len(
            re.findall(rf"\b{struct_name.lower()}s\s*\[[^\]]+\]\s*{member_pattern}", all_source)
        )
        vector_write = len(
            re.findall(
                rf"\b{struct_name.lower()}s\s*\[[^\]]+\]\s*{member_pattern}\s*(?:=(?!=)|\+=|-=|\*=|/=|%=|\|=|&=|\^=|<<=|>>=)",
                all_source,
            )
        )
        field_stats.setdefault(struct_name, {})[field] = {
            "all_member_accesses_by_name_in_selfhost": direct_access,
            "all_direct_member_writes_by_name_in_selfhost": direct_write,
            "vector_index_member_accesses": vector_access,
            "vector_index_member_writes": vector_write,
        }
        alias_reads = 0
        alias_writes = 0
        array_reads = 0
        array_writes = 0
        for _source, block in function_blocks:
            aliases = set(
                re.findall(rf"\b([A-Za-z_][A-Za-z0-9_]*)\s*:\s*{struct_name}\b", block)
            )
            collection = "nodes" if struct_name == "Node" else "tokens"
            aliases.update(
                re.findall(
                    rf"\b(?:let|var)\s+([A-Za-z_][A-Za-z0-9_]*)\s*(?::\s*{struct_name})?\s*=\s*(?:(?:p\.)?{collection}\s*\[|{struct_name}\s*\{{)",
                    block,
                )
            )
            for alias in aliases:
                alias_reads += len(re.findall(rf"\b{alias}\s*\.\s*{field}\b", block))
                alias_writes += len(
                    re.findall(
                        rf"\b{alias}\s*\.\s*{field}\s*(?:=(?!=)|\+=|-=|\*=|/=|%=|\|=|&=|\^=|<<=|>>=)",
                        block,
                    )
                )
            array_reads += len(
                re.findall(rf"\b{collection}\s*\[[^\]]+\]\s*\.\s*{field}\b", block)
            )
            array_writes += len(
                re.findall(
                    rf"\b{collection}\s*\[[^\]]+\]\s*\.\s*{field}\s*(?:=(?!=)|\+=|-=|\*=|/=|%=|\|=|&=|\^=|<<=|>>=)",
                    block,
                )
            )
        alias_stats.setdefault(struct_name, {})[field] = {
            "typed_or_vector_initialized_alias_reads": alias_reads,
            "typed_or_vector_initialized_alias_writes": alias_writes,
            "direct_vector_reads": array_reads,
            "direct_vector_writes": array_writes,
        }
    literals = Counter()
    for match in re.finditer(rf"\b{struct_name}\s*\{{([^{{}}]*)\}}", all_source, re.S):
        for field in fields:
            literals[field] += len(re.findall(rf"\b{field}\s*:", match.group(1)))
    literal_stats[struct_name] = dict(literals)

constants = {}
for name in ("N", "T", "F", "TF"):
    matches = [
        int(value)
        for match_name, value in re.findall(rf"let ({name}_[A-Z0-9_]+): i64 = ([0-9]+);", text)
    ]
    constants[name] = {"count": len(matches), "max_decimal": max(matches, default=0)}

pins = {}
for path in sorted(sources):
    pins[str(path.relative_to(root))] = hashlib.sha256(path.read_bytes()).hexdigest()

report = {
    "source_snapshot": "build/completion-runs/compiler-c-literals-58/selfhost",
    "source_file_count": len(sources),
    "source_sha256": pins,
    "struct_fields": struct_fields,
    "field_reference_counts": field_stats,
    "field_access_counts_by_obvious_node_token_aliases": alias_stats,
    "struct_literal_initializer_counts": literal_stats,
    "model_constant_ranges": constants,
    "layout": {
        "current_node_bytes": len(struct_fields["Node"]) * 8,
        "current_token_bytes": len(struct_fields["Token"]) * 8,
        "proposed_node_bytes_if_nonwide_fields_are_i32": 4 * 8 + (len(struct_fields["Node"]) - 4) * 4,
        "proposed_token_bytes_if_integer_float_flags_stay_wide": 3 * 8 + (len(struct_fields["Token"]) - 3) * 4,
    },
}
(out / "inventory.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({key: report[key] for key in ("struct_fields", "field_reference_counts", "struct_literal_initializer_counts", "model_constant_ranges", "layout")}, indent=2))
