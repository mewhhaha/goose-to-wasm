# A13 Node and Token packing review

Read-only static review of `build/completion-runs/compiler-c-literals-58/selfhost` (21 Goose files). No source edits, compiler builds, or performance tests were run. `inventory.json` records per-field source counts and SHA-256 pins for the full selfhost snapshot; `inventory.py` documents the counting method.

## Layout opportunity

`model.goose:260-284` defines 11 Token and 20 Node scalar fields, all currently i64 except `float_value`. With natural 8-byte layout this is Token 88 B and Node 160 B. Reordering cannot shrink either struct: all current fields are 8-byte aligned and the totals already align to 8 bytes.

Keep Token `integer`, `float_value`, `flags`, and Node `integer`, `float_value`, `flags`, `aux` wide. `flags` reaches `F_RESULT_TEMP = 2,199,023,255,552` in `model.goose:236`, so it cannot fit i32. `integer` carries full-width integer literals and `float_value` carries f64 values. This leaves these plausible i32 fields:

- Node: `kind`, `token`, `first`, `last`, `next`, `left`, `right`, `third`, `type_id`, `symbol`, `scope`, `origin`, `captures`, `named_results`, `coerced_type`, `expansion_binding` (16 fields).
- Token: `kind`, `source`, `start`, `end`, `line`, `column`, `text_start`, `text_len` (8 fields).

That yields Node 96 B and Token 56 B, saving 40% and 36% of each element respectively. A13's `self-o2-stats.json` reports 576,795 Nodes for its self-host workload: Node storage alone is about 88.0 MiB at 160 B versus 52.8 MiB at 96 B, a 35.2 MiB reduction. The stats file does not report Token count. This is footprint arithmetic, not a measured speedup or evidence of a >20% throughput gain.

## Range and safety gaps

The declared N kinds max at 58 and T kinds at 100 (`model.goose:98-165`), so those enums fit i32. Negative sentinel values such as `-1` also fit. Dynamic node, token, type, source, and text offsets are i64 lengths/indices today. `new_node` stores `p.nodes.len` (`model.goose:350-354`); the lexer stores `p.tokens.len`, byte positions, and line/column (`lexer.goose:143-181`, `lexer.goose:109-120`); `load_sources` appends paths and source contents to the shared text array (`sources.goose:59-60,98-104,177-202`). I found no source-size, total-text, token-count, or node-count ceiling in those insertion paths.

Safe narrowing therefore needs checked signed-i32 bounds for every narrowed identifier and for the aggregate text offsets. Individual file size alone is not enough because `p.text` concatenates normalized paths, multiple source files, and embedded file contents. Add checks before every Node/Token append, and at source/embed append boundaries; otherwise an unchecked `as! i32` can silently wrap. Line/column also need the source-byte limit to imply their bounds.

## Mechanical scope

The static inventory found 108 narrowed-field labels in Node literals, 17 writes through obvious Node aliases, and 514 direct indexed Node-field writes; it found 20 narrowed Token literal labels and 24 writes through obvious Token aliases. It also found at least 6,591 Node field reads and 119 Token field reads through obvious aliases or direct vector indexing. These are syntactic counts, not compiler AST counts: same-named fields on other structs and unrecognized aliases make the broad-name counts noisy, while the alias/vector counts are lower bounds. Full per-field tables are in `inventory.json`.

The snapshot has 11 `nodes.push(...)` and 6 `tokens.push(...)` source sites. The main narrowing edits would touch `model.goose`, `lexer.goose`, `sources.goose`, and many parser/checker/optimizer/driver modules where Node literals and field writes occur. Goose's explicit `as! i32` usage confirms the cast syntax (`optimizer.goose:34-35`); every wide dynamic value stored into a narrow field needs an explicit conversion or a checked helper. The main review burden is proving bounds and consistently applying checked conversion at those write sites; reads and array indices may also need widening depending on type-checker conversion rules.

## Lower-risk alternatives

- Field reordering alone has no benefit.
- A compact parallel index/position side table preserves wide Node/Token fields but adds synchronization and lookup work; it is unlikely to be simpler than narrowing the struct fields.
- A targeted reduction of full Node/Token copies in hot checker passes could be safer than changing every field's type, but requires evidence that generated C materializes those copies. Start with copy-heavy hot functions and compiler output inspection; do not assume a whole-struct read is expensive after C optimization.
- The packed layout is a plausible memory-throughput experiment because the self-host Node array is large. It still needs separate correctness gates and before/after compiler-throughput measurements; this review makes no speedup claim.
