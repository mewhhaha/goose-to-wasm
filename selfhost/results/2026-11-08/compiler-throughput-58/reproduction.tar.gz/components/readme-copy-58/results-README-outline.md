# Compiler throughput · snapshot 58

[PENDING_SOURCE_AND_CHANGE: identify the final source revision and explain the measured changes, eligibility boundaries and tradeoffs. Link preserved rejected experiments.]

## Qualification

[PENDING_QUALIFICATION_LINKS: link final summary, raw reports, comparison, controls, bootstrap reports and reproduction capsule, including its manifest and verification receipt.]

The full frozen suite passed 7,955/8,055 rows. All 184 new rows passed; all 7,871 prior results and failure phases matched. The 100 unchanged gaps are six accepted invalid programs and 94 runtime contracts rejected during compilation. The curated corpus passed 3,370 Wasm checks per engine (Wasmtime and V8) and 1,410 native controls. All 45 native runtime checks and 16 stack-guard profiles passed. These checks cover selected programs and behaviors.

Two independent public output roots, one default and one explicit, passed C-only bootstrap `--verify` with `profile_used: true`; generated C SHA-256 `191a6b540a7c59ccdd0de5ac32199eea958bb19121cd98a1bfe269c13fc2aea6`, executable SHA-256 `9a0450a452f6dcc0c6ad698fdeb9af6be599c7e8ffdb2437364a6f360145489d`. Goose emission used `-O2`. The C build used Clang 23, target `x86_64-pc-linux-gnu`, and `-std=gnu11 -O2 -lm -ldl -pthread`. Profile data SHA-256 `52cc8e39bede489dd8388bd9ffd5a095846076a484eba1cf39880b5b71b57927`. The profile was trained on the compiler and two feature fixtures, excluding all eleven timed programs. Identity or checksum mismatch, missing data or failed profile compilation falls back to a recorded unprofiled build. The C++ reference was not used in bootstrap or contracts.

## Measurements

[PENDING_FINAL_IDENTITIES: source revision, each compiler executable and source identity, full compiler and engine versions, host, CPU affinity, exact flags, dates and workload hashes. Distinguish any separately collected reference runs.]

The public comparison timed fresh compiler processes for eleven programs at Goose `-O2`, with one unmeasured warmup per cell and 31 samples in shuffled balanced rounds; OS caches remained warm. Snapshot 58 / C++ geometric mean time ratios were 0.99819 for Wasm and 0.93447 for C: Wasm was at parity within noise and C emission took 6.55% less time. Snapshot 57 / C++ ratios were 2.93419 and 2.15797, respectively. Snapshot 58 was about 2.94× faster for Wasm and 2.31× faster for C than snapshot 57, and about 3.4% faster than C++ across all 22 cells. Source-to-C emission excludes downstream C compilation and linking; C compilation and golden-output execution followed the timed campaign. C++ source identity matched its pin. [PENDING_COMPILER_REPORT_LINK: link the full per-cell results, variability, compiler identities and raw data.]

For ten examples, five fresh cold builds gave median ranges of 50.1–68.9 ms for direct Wasm and 252.6–1,924.3 ms for native executables. Native builds include C compilation and linking. Process timings use five launch-to-exit samples; Wasmtime preparation uses five samples and includes host launch, compilation, serialization and file writing. [PENDING_EXAMPLE_REPORT_LINK: identify engines, flags, outputs and raw results.]

[PENDING_LANGBENCH_RESULTS: small, medium and official workloads, five builds and seven hot samples; identify warmups, controls, checksum and separately collected references. Hot guest timer excludes compilation, startup and fresh instantiation; Wasm module remains resident.]

[PENDING_RAW_DATA_AND_CHART_LINKS: link all six charts, raw measurements and commands.]
