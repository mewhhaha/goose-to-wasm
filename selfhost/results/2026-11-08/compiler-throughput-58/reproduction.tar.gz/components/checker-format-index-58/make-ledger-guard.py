#!/usr/bin/env python3
"""Extract the actual cache and invalidation into a small runtime contract."""
from pathlib import Path

root = Path(__file__).resolve().parent
source = (root / 'checker.goose').read_text()
start = source.index('fn check_has_format_hooks(')
end = source.index('recursive fn check_lower_rendering(', start)
helper = source[start:end]
start = source.index('            if symbol < c.format_scan_end &&')
end = source.index('            p.symbols[symbol].type_id = ty;', start)
invalidate = source[start:end]
head = '''const S_BUILTIN = 64;
struct Symbol { node: i64 = -1, owner: i64 = -1, name_token: i64 = 0, flags: i64 = 0 }
struct Program { symbols: Symbol[>..]& }
struct Checker { format_scan_end: i64 = 0, has_format_hooks: bool = false }
fn token_is(p: Program&, token: i64, text: u8[:]) -> bool { return token == 1; }
'''
owner = '''fn review_set_owner(p: Program&, c: Checker&, symbol: i64, owner: i64) {
''' + invalidate + '''    p.symbols[symbol].owner = owner;
}
'''
test = '''// This oracle is the contract's complete set predicate, independent of
// traversal position, cached booleans, or the incremental implementation.
fn expected(p: Program&) -> bool {
    for s in p.symbols {
        if s.node >= 0 && s.owner < 0 && s.name_token == 1 && (s.flags & S_BUILTIN) == 0 { return true; }
    }
    return false;
}
fn verify(p: Program&, c: Checker&) {
    assert(check_has_format_hooks(p, c) == expected(p));
    let end = c.format_scan_end;
    assert(check_has_format_hooks(p, c) == expected(p));
    assert(c.format_scan_end == end);
}
fn main() {
    var symbols: Symbol[>..] = [];
    var p = Program { symbols: symbols };
    var c = Checker {};
    verify(p, c);
    symbols.push(Symbol { node: -1, name_token: 1 });
    symbols.push(Symbol { node: 0, name_token: 1, flags: S_BUILTIN });
    symbols.push(Symbol { node: 0, name_token: 2 });
    symbols.push(Symbol { node: 0, owner: 4, name_token: 1 });
    verify(p, c);
    assert(!c.has_format_hooks && c.format_scan_end == 4);
    // An indexed negative becomes eligible, then stops being eligible.
    review_set_owner(p, c, 3, -1); verify(p, c);
    assert(c.has_format_hooks);
    review_set_owner(p, c, 3, 4); verify(p, c);
    assert(!c.has_format_hooks);
    // A late global named format qualifies even without S_FUNCTION.
    symbols.push(Symbol { node: 7, name_token: 1 });
    verify(p, c); assert(c.has_format_hooks);
    let positive_end = c.format_scan_end;
    for i in 5 { symbols.push(Symbol { node: i, name_token: 2 }); }
    verify(p, c); assert(c.format_scan_end == positive_end);
    review_set_owner(p, c, 4, 9); verify(p, c);
    assert(!c.has_format_hooks && c.format_scan_end == symbols.len);
    // Overloads give separate positive witnesses. Losing one leaves the other.
    symbols.push(Symbol { node: 8, name_token: 1 });
    symbols.push(Symbol { node: 9, name_token: 1 });
    verify(p, c);
    review_set_owner(p, c, 10, 3); verify(p, c);
    assert(c.has_format_hooks);
    review_set_owner(p, c, 11, 3); verify(p, c);
    assert(!c.has_format_hooks);
    // A new Checker starts with an empty summary of the same table.
    var fresh = Checker {}; verify(p, fresh);
    review_set_owner(p, fresh, 10, -1); verify(p, fresh);
    assert(fresh.has_format_hooks);
    print("format index ok");
}
'''
(root / 'ledger-guard.goose').write_text(head + helper + owner + test)
