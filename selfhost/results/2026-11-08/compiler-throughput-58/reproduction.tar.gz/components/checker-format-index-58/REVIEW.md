The cache preserves the existing rendering gate exactly. It does not choose a
formatter, skip layout validation, or change overload/namespace resolution.

Proof:

1. A fresh Checker has scan_end 0 and a false summary. Its prefix is empty.
2. Each helper iteration advances one index and applies the old predicate:
   node >= 0, owner < 0, name "format", and no S_BUILTIN flag. The scan calls
   token_is, which does not append symbols or call the checker.
3. A negative result has examined the entire current symbol table. The next
   call examines only appended rows. A positive result has a witness in the
   examined prefix, so appending rows cannot negate it.
4. During checking, symbols are only appended by check_declare,
   check_specialize_type, check_builtin_symbol, and check_specialize_function.
   No symbol arrays are truncated or replaced; no Symbol& aliases exist.
   Existing name_token and node fields are never reassigned. S_BUILTIN never
   changes; the only existing flags update adds S_CAPTURE.
5. The only existing eligibility mutation is Symbol.owner in
   check_layout_fields. Both callers provide nonnegative nominal/variant
   nodes. Nevertheless, the patch invalidates the prefix whenever an already
   indexed owner crosses zero, covering either direction without relying on
   declaration/layout call ordering. Other owner changes preserve the gate.
6. Token spelling remains stable: synthetic operation/render tokens are
   appended copies with fresh spans. They do not rename existing symbols.
   Optimizer symbol changes happen after this Checker's lifetime ends.

The field-owner reset is conservative: it can rescan unaffected symbols but
cannot produce a stale answer. Normal new fields are beyond scan_end and do
not reset it. The predicate deliberately includes nonfunctions and ignores
scope, matching the old gate; actual hook selection still applies all its
existing checks.

cases.json freezes 52 checks before execution. The small ledger fixture
extracts the actual helper and invalidation code and compares them with a
complete-table predicate after appended negatives, late positives, builtin
rows, nonfunction rows, owner transitions, multiple witnesses, and a fresh
Checker. Other fixtures cover ordinary source behavior, late default-body
declarations, namespaces, overloads, local/global shadowing, and an existing
independently specified unused-hook error. No compiler or reference oracle
has been run while preparing these expectations.

This is a private source proposal, not qualified performance evidence.
