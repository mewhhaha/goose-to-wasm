from pathlib import Path
p=Path('build/completion-runs/bootstrap-repro-profile-58/tree/tests/test_bootstrap_optimization.py')
s=p.read_text().replace('def stage(self, seed_level, requested=None, verify=False, converge=False, seed_only=False):', '''def stage(self, seed_level, requested=None, verify=False, converge=False, seed_only=False,
              profile=None, version='clang version 21.1.0', fail_profile=False, changed=False):''')
s=s.replace("            (seed / 'seed.json').write_text(json.dumps(pin))", """            (seed / 'seed.json').write_text(json.dumps(pin))
            if changed:
                (source / 'main.goose').write_text('fn main() { changed() }\\n')
            emitted = b'/* sources/main.goose stdlib */\\n'
            if profile is not None:
                data = b'profile data'
                (seed / 'profile.profdata').write_bytes(data)
                identity = dict(schema='goose-bootstrap-profile-v1', clang_major=21,
                                target='x86_64-unknown-linux-gnu',
                                base_flags=['-std=gnu11', '-O2', '-lm', '-ldl', '-pthread'],
                                c_basename='seed.c', c_sha256=sha(c), data_sha256=sha(data))
                if profile == 'emitted':
                    identity['c_sha256'] = sha(emitted)
                elif isinstance(profile, dict):
                    identity.update(profile)
                (seed / 'profile.json').write_text(json.dumps(identity))""")
s=s.replace("                        return subprocess.CompletedProcess(argv, 0, b'fake cc\\n', b'')\n                    Path(argv[argv.index('-o') + 1]).write_bytes(b'fake executable\\n')", """                        return subprocess.CompletedProcess(argv, 0, version.encode(), b'')
                    if argv[1:] == ['-dumpmachine']:
                        return subprocess.CompletedProcess(argv, 0, b'x86_64-unknown-linux-gnu\\n', b'')
                    self.assertEqual(argv[3], 'seed.c')
                    self.assertTrue(Path(kwargs['cwd']).name.startswith('cc-build-'))
                    staged = Path(kwargs['cwd']) / argv[3]
                    self.assertTrue(staged.is_file())
                    profiled = any(arg.startswith('-fprofile-instr-use=') for arg in argv)
                    if profiled:
                        self.assertIn('-Werror=profile-instr-out-of-date', argv)
                        self.assertIn('-Werror=profile-instr-unprofiled', argv)
                        if fail_profile:
                            return subprocess.CompletedProcess(argv, 1, b'', b'profile mismatch')
                    binary = b'plain:' + staged.read_bytes()
                    if profiled:
                        binary = b'profile:' + staged.read_bytes()
                    Path(argv[argv.index('-o') + 1]).write_bytes(binary)""")
s=s.replace("                    data = b'/* generated */\\n'", """                    self.assertEqual(argv[1], 'sources/main.goose')
                    self.assertEqual(argv[argv.index('--stdlib') + 1], 'stdlib')
                    self.assertEqual(Path(kwargs['cwd']), output)
                    self.assertTrue((Path(kwargs['cwd']) / argv[1]).is_file())
                    self.assertTrue((Path(kwargs['cwd']) / 'stdlib/base.goose').is_file())
                    data = ('/* ' + argv[1] + ' ' + argv[argv.index('--stdlib') + 1] + ' */\\n').encode()""")
s=s.replace("command[1:] != ['--version']", "command[1:] not in (['--version'], ['-dumpmachine'])")
s=s.replace("            return report, emissions", """            actual = report['executable_build']
            prefix = b'plain:'
            if actual['profile_used']:
                prefix = b'profile:'
            self.assertEqual((output / 'goose').read_bytes()[:len(prefix)], prefix)
            self.assertEqual(report['profile_used'], actual['profile_used'])
            self.assertEqual(report['executable_c_sha256'], actual['c_sha256'])
            self.assertEqual(report['goose_optimization'], actual['goose_optimization'])
            return report, emissions""")
insert='''    def test_emission_identity_is_independent_of_output_root(self):
        first, _ = self.stage(0)
        second, _ = self.stage(0)
        self.assertEqual(first['generated_c_sha256'], second['generated_c_sha256'])
        self.assertEqual(first['executable_sha256'], second['executable_sha256'])
        for command in first['commands']:
            if command['name'].startswith('build-'):
                self.assertEqual(command['command'][3], 'seed.c')

    def test_matching_profile_survives_verify_without_promotion(self):
        report, _ = self.stage(2, profile={}, verify=True)
        # This mock's seed C differs from its compiler's fixed point, so verify
        # correctly promotes the unprofiled following C instead of inheriting PGO.
        self.assertFalse(report['profile_used'])
        self.assertTrue(report['builds']['build-seed']['profile_used'])
        self.assertEqual(report['executable_build'], report['builds']['build-next-generation'])

    def test_promoted_stage_can_select_its_own_exact_profile(self):
        report, _ = self.stage(0, profile='emitted', verify=True, converge=True)
        self.assertTrue(report['profile_used'])
        self.assertFalse(report['builds']['build-seed']['profile_used'])
        self.assertFalse(report['builds']['build-goose']['profile_used'])
        self.assertTrue(report['builds']['build-next-generation']['profile_used'])
        self.assertEqual(report['executable_build'], report['builds']['build-next-generation'])

    def test_matching_seed_only_uses_profile(self):
        report, _ = self.stage(2, profile={}, seed_only=True)
        self.assertTrue(report['profile_used'])
        self.assertEqual(report['executable_build'], report['builds']['build-seed'])
        self.assertTrue(any(path.endswith('profile.json') for path in report['input_sha256']))
        self.assertTrue(any(path.endswith('profile.profdata') for path in report['input_sha256']))

    def test_changed_source_does_not_inherit_seed_profile(self):
        report, _ = self.stage(2, profile={}, changed=True)
        self.assertFalse(report['profile_used'])
        self.assertTrue(report['builds']['build-seed']['profile_used'])
        self.assertIn('c_sha256', report['executable_build']['profile_reason'])

    def test_profile_identity_and_integrity_fail_closed(self):
        for fields, reason in [({'clang_major': 20}, 'clang_major'),
                               ({'target': 'other'}, 'target'),
                               ({'base_flags': ['-O3']}, 'base_flags'),
                               ({'c_basename': 'compiler.c'}, 'c_basename'),
                               ({'c_sha256': 'wrong'}, 'c_sha256'),
                               ({'schema': 'wrong'}, 'schema'),
                               ({'data_sha256': 'wrong'}, 'checksum')]:
            with self.subTest(fields=fields):
                report, _ = self.stage(2, profile=fields, seed_only=True)
                self.assertFalse(report['profile_used'])
                self.assertIn(reason, report['executable_build']['profile_reason'])

    def test_non_clang_and_absent_profile_have_explicit_reasons(self):
        report, _ = self.stage(2, profile={}, version='gcc version 15', seed_only=True)
        self.assertFalse(report['profile_used'])
        self.assertIn('not Clang', report['executable_build']['profile_reason'])
        report, _ = self.stage(2, seed_only=True)
        self.assertIn('absent', report['executable_build']['profile_reason'])

    def test_profile_compile_failure_falls_back_with_failed_command(self):
        report, _ = self.stage(2, profile={}, seed_only=True, fail_profile=True)
        self.assertFalse(report['profile_used'])
        actual = report['executable_build']
        self.assertIn('failed', actual['profile_reason'])
        self.assertEqual(actual['profile_failed_command']['exit_code'], 1)
        self.assertEqual([row['name'] for row in report['commands']][-2:],
                         ['build-seed-profile', 'build-seed'])

'''
s=s.replace('    def test_installer_forwards_level_and_records_actual_report(self):',insert+'    def test_installer_forwards_level_and_records_actual_report(self):')
s=s.replace("                    if report_level is not None:\n                        report['goose_optimization'] = report_level", """                    report.update(profile_used=True, executable_c_sha256='actual C',
                                  executable_build={'profile_used': True, 'profile_sha256': 'actual profile'})
                    if report_level is not None:
                        report['goose_optimization'] = report_level""")
s=s.replace("                self.assertTrue((build / 'bin/goose').is_file())", """                self.assertTrue(metadata['profile_used'])
                self.assertEqual(metadata['executable_c_sha256'], 'actual C')
                self.assertEqual(metadata['executable_build']['profile_sha256'], 'actual profile')
                self.assertTrue((build / 'bin/goose').is_file())""")
p.write_text(s)
