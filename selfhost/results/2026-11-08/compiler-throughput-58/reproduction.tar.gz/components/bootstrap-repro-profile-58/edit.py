from pathlib import Path
p=Path('build/completion-runs/bootstrap-repro-profile-58/tree/selfhost/bootstrap.py')
s=p.read_text()
s=s.replace("    def command(argv, name):", "    def command(argv, name, cwd=out, allow_failure=False):")
s=s.replace("subprocess.run(argv, cwd=ROOT,", "subprocess.run(argv, cwd=cwd,")
s=s.replace("row = {'command': argv, 'exit_code': result.returncode,", "row = {'name': name, 'command': argv, 'cwd': str(cwd), 'exit_code': result.returncode,")
s=s.replace("        if result.returncode:\n            raise RuntimeError", "        if result.returncode and not allow_failure:\n            raise RuntimeError")
s=s.replace("        return result.stdout\n", "        return result\n")
s=s.replace("        report['cc_version'] = command([cc, '--version'], 'cc-version').decode(errors='replace')\n        seed_executable = out / 'seed'\n        command([cc, '-std=gnu11', '-O2', c_source, '-lm', '-ldl', '-pthread', '-o', seed_executable], 'build-seed')", """        report['cc_version'] = command([cc, '--version'], 'cc-version').stdout.decode(errors='replace')
        report['cc_target'] = command([cc, '-dumpmachine'], 'cc-target').stdout.decode().strip()
        base_flags = ['-std=gnu11', '-O2', '-lm', '-ldl', '-pthread']
        clang = re.search(r'\\bclang version (\\d+)\\.', report['cc_version'])
        identity = {'clang_major': None, 'target': report['cc_target'],
                    'base_flags': base_flags, 'c_basename': 'seed.c'}
        if clang:
            identity['clang_major'] = int(clang.group(1))
        report['profile_identity'] = identity
        profile = None
        profile_reason = 'optional profile metadata absent'
        metadata_path = seed / 'profile.json'
        data_path = seed / 'profile.profdata'
        if metadata_path.is_file():
            report['input_sha256'][str(metadata_path)] = digest(metadata_path)
            try:
                profile = json.loads(metadata_path.read_bytes())
                if not isinstance(profile, dict):
                    raise ValueError('metadata must be an object')
                if data_path.is_file():
                    report['input_sha256'][str(data_path)] = digest(data_path)
                else:
                    profile_reason = 'profile data absent'
                    profile = None
            except (ValueError, OSError) as error:
                profile_reason = 'invalid profile metadata: ' + str(error)
                profile = None
        report['builds'] = {}

        def build(source, executable, name, optimization):
            # LLVM keys internal functions by the translation unit basename.
            # Keep original inputs intact and compile each stage as seed.c.
            stage = out / ('cc-' + name)
            stage.mkdir()
            staged_c = stage / 'seed.c'
            shutil.copyfile(source, staged_c)
            c_hash = digest(staged_c)
            row = {'c_sha256': c_hash, 'goose_optimization': optimization,
                   'profile_used': False, 'profile_reason': profile_reason}
            report['builds'][name] = row
            matched = False
            if not clang:
                row['profile_reason'] = 'C compiler is not Clang'
            elif profile is not None:
                expected = dict(identity, schema='goose-bootstrap-profile-v1', c_sha256=c_hash)
                differing = [key for key, value in expected.items() if profile.get(key) != value]
                if differing:
                    row['profile_reason'] = 'profile identity differs: ' + ', '.join(differing)
                elif digest(data_path) != profile.get('data_sha256'):
                    row['profile_reason'] = 'profile data checksum differs'
                else:
                    matched = True
            argv = [cc, *base_flags[:2], 'seed.c', *base_flags[2:], '-o', executable]
            if matched:
                profile_flags = ['-fprofile-instr-use=' + str(data_path),
                                 '-Werror=profile-instr-out-of-date',
                                 '-Werror=profile-instr-unprofiled']
                result = command([*argv, *profile_flags], name + '-profile', cwd=stage, allow_failure=True)
                if result.returncode == 0:
                    row.update(profile_used=True, profile_reason='exact profile identity matched',
                               profile_sha256=digest(data_path))
                    return row
                row['profile_reason'] = 'profile compilation failed; compiled without profile'
                row['profile_failed_command'] = report['commands'][-1]
            command(argv, name, cwd=stage)
            return row

        seed_executable = out / 'seed'
        actual_build = build(c_source, seed_executable, 'build-seed', pin.get('goose_optimization', 0))""")
s=s.replace("invocation = [sources / 'main.goose', '--stdlib', library,", "invocation = ['sources/main.goose', '--stdlib', 'stdlib',")
s=s.replace("                command([cc, '-std=gnu11', '-O2', generated, '-lm', '-ldl', '-pthread', '-o', executable], 'build-goose')", "                actual_build = build(generated, executable, 'build-goose', args.optimization)")
s=s.replace("                    command([cc, '-std=gnu11', '-O2', following, '-lm', '-ldl', '-pthread', '-o', second], 'build-next-generation')", "                    actual_build = build(following, second, 'build-next-generation', args.optimization)")
s=s.replace("        report['input_sha256_after']", "        report['executable_build'] = actual_build\n        report['goose_optimization'] = actual_build['goose_optimization']\n        report['profile_used'] = actual_build['profile_used']\n        report['executable_c_sha256'] = actual_build['c_sha256']\n        report['input_sha256_after']", 1)
p.write_text(s)
p=Path('build/completion-runs/bootstrap-repro-profile-58/tree/scripts/bootstrap.py');s=p.read_text();s=s.replace("                    'goose_optimization': report.get('goose_optimization', 0),", "                    'goose_optimization': report.get('goose_optimization', 0),\n                    'executable_c_sha256': report.get('executable_c_sha256', report['seed_c_sha256']),\n                    'profile_used': report.get('profile_used', False),\n                    'executable_build': report.get('executable_build'),")
p.write_text(s)
