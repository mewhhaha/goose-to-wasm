# Private bootstrap reproducibility/profile candidate

No live product files changed. `candidate.patch` includes the prior bootstrap-opt-58
optimization-default change and replaces its test with 16 focused tests.

The bootstrap emits compiler C using `sources/main.goose --stdlib stdlib` with
cwd equal to its staged output root. Native embeds remain `native/...` alongside
sources. Every C compilation copies the original emitted/frozen C to its own
`cc-build-*/seed.c`, then passes the relative basename `seed.c` to Clang. The
original inputs remain pinned and available for comparison. This removes both
absolute Goose diagnostic paths and LLVM's absolute translation-unit path keys.

An optional `--seed-dir` contains `profile.json` and `profile.profdata`. The JSON
schema is `goose-bootstrap-profile-v1`, with these required exact fields:

```json
{
  "schema": "goose-bootstrap-profile-v1",
  "c_sha256": "sha256 of the exact canonical seed.c bytes",
  "clang_major": 23,
  "target": "x86_64-pc-linux-gnu",
  "base_flags": ["-std=gnu11", "-O2", "-lm", "-ldl", "-pthread"],
  "c_basename": "seed.c",
  "data_sha256": "sha256 of profile.profdata"
}
```

The effective target is queried from the actual selected CC with `-dumpmachine`;
the supported C driver scope remains GCC/Clang-compatible GNU C drivers.
base_flags are the actual ordered compile/link flags, excluding the staged C
basename and output filename. No compiler profiles are trained by bootstrap.
Missing, invalid or incompatible data uses plain O2 and records why. Matching
profile use enables fatal `profile-instr-out-of-date`, `profile-instr-unprofiled`
AND `profile-instr-missing` diagnostics. The last group is needed: Clang 23
silently accepts a partially missing-function profile without it. Failed profile
compilation records the failed command and stderr digest before plain O2 fallback.

Each stage records its exact C hash, Goose optimization level and profile-use
receipt. Verification promotion selects that stage's actual metadata. The
installer copies actual executable metadata to toolchain.json. Profile metadata
and data files enter the bootstrap's before/after input pins when present.
Old seeds without a Goose optimization level retain their actual level 0.

## Release training, deliberately outside product bootstrap

1. First freeze canonical compiler C using the exact public emission invocation,
   source snapshot, stdlib snapshot and optimization level. Qualify that C across
   two independent output roots and under `--verify`. Update the existing private
   freezer/qualification tools; there is no public freeze_seed.py to invoke.
2. In a dedicated training directory write those exact C bytes as `seed.c`.
   Compile with the same selected Clang, target and base_flags as bootstrap:

   ```sh
   clang -std=gnu11 -O2 seed.c -lm -ldl -pthread \
     -fprofile-instr-generate -o goose-train
   ```

3. Run a pinned, representative compiler workload with the instrumented binary;
   set `LLVM_PROFILE_FILE` explicitly to a private training output. Example for
   one workload (replace all uppercase paths with pinned absolute identities):

   ```sh
   LLVM_PROFILE_FILE=TRAINING_DIR/compiler-%p.profraw \
     TRAINING_DIR/goose-train PINNED_WORKLOAD/main.goose \
     --stdlib PINNED_STDLIB --target native -O2 -o TRAINING_DIR/workload.c
   llvm-profdata merge TRAINING_DIR/compiler-*.profraw -o SEED_DIR/profile.profdata
   ```

4. Write profile.json from exact C/data SHA256, selected Clang major, actual
   `clang -dumpmachine`, canonical basename and the ordered base_flags above.
   Preserve Clang/llvm-profdata executable hashes, full versions, source/bundle
   hashes, workload paths/content hashes, command argv/cwd and raw profiles in
   dated release evidence. Do not label a profile trained against another C hash
   compatible, even if only its paths appear different.
5. Run public default bootstrap with `--verify` in two output roots. Require its
   installed executable receipt to retain profile_used=true and the desired C
   hash; qualify the actual installed binary against C++, baseline and controls.
   Publish seed, source bundle, sidecars, README text/charts and dated evidence
   together only after performance and correctness gates pass.

## Evidence / limits

`tree/tests/test_bootstrap_optimization.py`: 16 focused integration tests use
filesystem snapshots and intercepted process creation to check actual cwd, argv,
staged source/native/C bytes, every profile identity field, metadata/data pins,
missing/malformed profiles, fatal flags, failure fallback, seed reuse, old seed
level, source changes, verification promotion and installer metadata propagation.
They do not prove real Goose fixed-point emission across output roots.

`tiny_profile_probe.py` / `tiny-probe-result.json`: actual Clang 23.1.4 tiny-C
profile training/use relocated to two bootstrap output roots; both retain profile
use and produce the same executable SHA. An unrelated partial-function profile
passes the JSON/hash gate deliberately, then Clang rejects missing-function data
and bootstrap reports plain-O2 fallback. A second real profile with the same
function names but changed CFG also triggers fatal mismatch rejection and fallback. Probe execution took under one second.
An earlier failed probe under `tiny-probe/` preserves why the additional missing
profile warning is essential; final qualified evidence uses `tiny-probe-final/`.

No full compiler build, compiler training or throughput claim was made here.
Parent agent must run the real two-root bootstrap and release qualification.
