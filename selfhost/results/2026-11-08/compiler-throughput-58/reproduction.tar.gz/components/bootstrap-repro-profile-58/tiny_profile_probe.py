"""Seconds-only integration probe; trains no Goose/compiler profiles."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile

root = Path(__file__).resolve().parent
probe = root / 'tiny-probe-final'
probe.mkdir(exist_ok=False)
cc = Path(shutil.which('clang')).resolve()
profdata = Path(shutil.which('llvm-profdata')).resolve()
def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(argv, cwd=probe, **kwargs):
    result = subprocess.run(list(map(str, argv)), cwd=cwd, capture_output=True, **kwargs)
    if result.returncode:
        raise RuntimeError(result.stderr.decode())
    return result
training = probe / 'train'; training.mkdir()
c = b'static int f(int n) { int sum=0; for(int i=0;i<n;i++) sum+=i%3; return sum; }\nint main(int argc,char **argv) { return f(argc*17)%2; }\n'
(training / 'seed.c').write_bytes(c)
base = ['-std=gnu11', '-O2', '-lm', '-ldl', '-pthread']
run([cc, *base[:2], 'seed.c', *base[2:], '-fprofile-instr-generate', '-o', 'train'], cwd=training)
env = dict(os.environ, LLVM_PROFILE_FILE=str(training / 'training.profraw'))
result = subprocess.run([str(training / 'train')], env=env, capture_output=True)
if result.returncode not in (0, 1):
    raise RuntimeError('training execution failed')
seed = probe / 'seed'; seed.mkdir()
run([profdata, 'merge', training / 'training.profraw', '-o', seed / 'profile.profdata'])
(seed / 'seed.c.gz').write_bytes(gzip.compress(c, mtime=0))
with tarfile.open(seed / 'sources.tar.gz', 'w:gz'):
    pass
pin = dict(c_sha256=sha(training / 'seed.c'), compressed_sha256=sha(seed / 'seed.c.gz'), source_bundle_sha256=sha(seed / 'sources.tar.gz'), source_sha256={}, goose_optimization=2)
(seed / 'seed.json').write_text(json.dumps(pin))
version = run([cc, '--version']).stdout.decode()
target = run([cc, '-dumpmachine']).stdout.decode().strip()
metadata = dict(schema='goose-bootstrap-profile-v1', c_sha256=pin['c_sha256'], clang_major=int(re.search(r'clang version (\d+)\.', version).group(1)), target=target, base_flags=base, c_basename='seed.c', data_sha256=sha(seed / 'profile.profdata'))
(seed / 'profile.json').write_text(json.dumps(metadata))
bootstrap = root / 'tree/selfhost/bootstrap.py'
reports=[]
for name in ('out-a', 'another-root/out-b'):
    output = probe / name
    run([sys.executable, bootstrap, '--seed-dir', seed, '--output-dir', output, '--cc', cc, '--seed-only'])
    report = json.loads((output / 'report.json').read_text())
    assert report['profile_used']
    reports.append(report)
assert reports[0]['executable_sha256'] == reports[1]['executable_sha256']
# Exact metadata with structurally unrelated profile data passes our identity gate,
# but Clang's unprofiled-function warning must reject use and trigger plain fallback.
other = probe / 'other'; other.mkdir()
(other / 'seed.c').write_text('int entirely_other(void) {return 3;} int main(void){return entirely_other();}\n')
run([cc, *base[:2], 'seed.c', *base[2:], '-fprofile-instr-generate', '-o', 'other'], cwd=other)
env['LLVM_PROFILE_FILE'] = str(other / 'other.profraw')
subprocess.run([str(other / 'other')], env=env, capture_output=True)
run([profdata, 'merge', other / 'other.profraw', '-o', seed / 'profile.profdata'])
metadata['data_sha256'] = sha(seed / 'profile.profdata')
(seed / 'profile.json').write_text(json.dumps(metadata))
fallback = probe / 'fallback'
run([sys.executable, bootstrap, '--seed-dir', seed, '--output-dir', fallback, '--cc', cc, '--seed-only'])
fallback_report = json.loads((fallback / 'report.json').read_text())
assert not fallback_report['profile_used']
assert fallback_report['executable_build']['profile_failed_command']['exit_code'] != 0
cfg = probe / 'cfg'; cfg.mkdir()
(cfg / 'seed.c').write_text('static int f(int n) {if(n<2)return n;return n*2;} int main(int argc,char **argv){return f(argc*17)%2;}\n')
run([cc, *base[:2], 'seed.c', *base[2:], '-fprofile-instr-generate', '-o', 'cfg'], cwd=cfg)
env['LLVM_PROFILE_FILE'] = str(cfg / 'cfg.profraw')
subprocess.run([str(cfg / 'cfg')], env=env, capture_output=True)
run([profdata, 'merge', cfg / 'cfg.profraw', '-o', seed / 'profile.profdata'])
metadata['data_sha256'] = sha(seed / 'profile.profdata')
(seed / 'profile.json').write_text(json.dumps(metadata))
cfg_fallback = probe / 'cfg-fallback'
run([sys.executable, bootstrap, '--seed-dir', seed, '--output-dir', cfg_fallback, '--cc', cc, '--seed-only'])
cfg_report = json.loads((cfg_fallback / 'report.json').read_text())
assert not cfg_report['profile_used']
assert cfg_report['executable_build']['profile_failed_command']['exit_code'] != 0
result = dict(status='passed', cc_version=version, cc_sha256=sha(cc), llvm_profdata_sha256=sha(profdata), canonical_c_sha256=pin['c_sha256'], target=target, relocated_executable_sha256=reports[0]['executable_sha256'], relocation_profile_used=[r['profile_used'] for r in reports], fallback_reason=fallback_report['executable_build']['profile_reason'], cfg_fallback_reason=cfg_report['executable_build']['profile_reason'], inputs={str(p):sha(p) for p in [Path(__file__),bootstrap,cc,profdata,training/'seed.c']})
(root / 'tiny-probe-result.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result, indent=2))
