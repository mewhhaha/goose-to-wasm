from pathlib import Path
import re,json,hashlib
root=Path.cwd();w=root/'build/completion-runs';out=w/'lifetime-single-58';old=(w/'compiler-plain-58/selfhost/checker_lifetimes.goose').read_text();new=(out/'checker_lifetimes.goose').read_text()
def function(s,name):
 m=re.search(r'^(?:recursive |inline )?fn '+name+r'\(',s,re.M);assert m
 tail=re.search(r'^\}',s[m.end():],re.M);assert tail
 return s[m.start():m.end()+tail.end()]+'\n'
parts=['import std;\n']
for name in ['LifeAlt','LifeSet','LifeRoot','LifeAtom']:
 parts.append(re.search(r'^struct '+name+r' .*$',old,re.M).group(0)+'\n')
parts.append('struct Lifetimes { roots: LifeRoot[>..]&, sets: LifeSet[>..]&, alts: LifeAlt[>..]&, atoms: LifeAtom[>..]& }\n')
for name in ['life_find','life_equal','life_insert','life_single','life_join','life_bound']:
 text=function(old,name);parts.append(re.sub(r'\blife_(find|equal|insert|single|join|bound)\b',r'old_life_\1',text))
for name in ['life_find','life_equal','life_insert','life_single','life_join','life_bound']:parts.append(function(new,name))
parts.append('''
fn compare(a: Lifetimes&, b: Lifetimes&) {
    assert(a.sets.len == b.sets.len && a.alts.len == b.alts.len && a.atoms.len == b.atoms.len);
    for x, i in a.sets {
        let y = b.sets[i];
        assert(x.first == y.first && x.count == y.count && x.bound_depth == y.bound_depth && x.bound_result == y.bound_result);
    }
    for x, i in a.alts {
        let y = b.alts[i];
        assert(x.root == y.root && x.exact == y.exact && x.from == y.from && x.slotread == y.slotread && x.byteview == y.byteview && x.target_type == y.target_type && x.bound == y.bound && x.next == y.next);
    }
    for x, i in a.atoms { assert(x.set == b.atoms[i].set); }
    for x, i in b.roots {
        var head = x.atoms; if head < -1 { head = -2 - head; }
        var visits = 0;
        while head >= 0 { visits += 1; assert(visits <= b.atoms.len); head = b.atoms[head].next; }
        var old_head = a.roots[i].atoms; var old_visits = 0;
        while old_head >= 0 { old_visits += 1; assert(old_visits <= a.atoms.len); old_head = a.atoms[old_head].next; }
        assert(visits == old_visits);
    }
}
fn test_order(rotation: i64) {
    var ar: LifeRoot[>..] = [LifeRoot {}, LifeRoot {}, LifeRoot {}]; var aset: LifeSet[>..] = [LifeSet {}]; var aa: LifeAlt[>..] = []; var ax: LifeAtom[>..] = [];
    var br: LifeRoot[>..] = [LifeRoot {}, LifeRoot {}, LifeRoot {}]; var bset: LifeSet[>..] = [LifeSet {}]; var ba: LifeAlt[>..] = []; var bx: LifeAtom[>..] = [];
    var a = Lifetimes { roots: ar, sets: aset, alts: aa, atoms: ax };
    var b = Lifetimes { roots: br, sets: bset, alts: ba, atoms: bx };
    for round in 0..4 {
        for key in 0..64 {
            let k = (key + rotation) % 64;
            let exact = (k & 1) == 0; var from = -1; if (k & 2) != 0 { from = 17; }
            let slot = (k & 4) != 0; let bytes = (k & 8) != 0;
            var target = -1; if (k & 16) != 0 { target = 23; }
            var bound = 0; if (k & 32) != 0 { bound = 5; }
            for root in 0..3 {
                let x = old_life_single(a, root, exact, from, slot, bytes, target, bound);
                let y = life_single(b, root, exact, from, slot, bytes, target, bound);
                assert(x == y); compare(a,b);
                if round == 0 { assert(x == 1 + key * 3 + root); }
                let ordinary = old_life_single(a, root); let ordinary2 = life_single(b, root);
                assert(ordinary == ordinary2); compare(a,b);
            }
        }
    }
    let x = old_life_single(a, 1); let y = life_single(b, 1); assert(x == y);
    let bound1 = old_life_bound(a,x,19); let bound2 = life_bound(b,y,19); assert(bound1 == bound2); compare(a,b);
    assert(old_life_bound(a,x,19) == life_bound(b,y,19)); compare(a,b);
    let other1 = old_life_single(a,1,false,9,true,true,17,23); let other2 = life_single(b,1,false,9,true,true,17,23); assert(other1 == other2);
    assert(old_life_join(a,x,other1) == life_join(b,y,other2)); compare(a,b);
    assert(old_life_single(a,1) == x && life_single(b,1) == y); compare(a,b);
}
fn main() {
    for rotation in 0..64 { test_order(rotation); }
    for index in [0,1,9223372036854775805,9223372036854775806] {
        let encoded = -2 - index; assert(encoded <= -2); assert(-2 - encoded == index);
    }
    print("singleton guards passed");
}
''')
# Hand-index formula is valid only without the intervening default calls: verify defaults separately after the first cycle.
parts[-1]=parts[-1].replace('                if round == 0 { assert(x == 1 + key * 3 + root); }','')
text=''.join(parts);(out/'fixture.goose').write_text(text)
(out/'fixture-seal.json').write_text(json.dumps(dict(old_source_sha256=hashlib.sha256(old.encode()).hexdigest(),new_source_sha256=hashlib.sha256(new.encode()).hexdigest(),fixture_sha256=hashlib.sha256(text.encode()).hexdigest(),expected_stdout='singleton guards passed\\n',algorithm='Extract actual six helpers from A10 and candidate; compare exact set IDs, immutable alt payloads, set and arena lengths, and root-list reachability after each operation; 64 rotations x4passes x64keys x3roots, plus default interleavings, bound/join and full-range arithmetic.'),indent=2)+'\n')
