from pathlib import Path
import re, hashlib, difflib, json
root = Path(__file__).resolve().parent
baseline_path = root.parent / 'compiler-recursive-58/selfhost/checker_lifetimes.goose'
base = baseline_path.read_text()
source = base.replace('    atoms: LifeAtom[>..]&,', '    size_classes: i64[>..]&, types_frozen: bool = false,\n    atoms: LifeAtom[>..]&,', 1)
# Only rewrite call sites in functions which already receive the phase state.
functions = list(re.finditer(r'^(?:(?:inline|recursive) )?fn (\w+)\(([^\n]*)', source, re.M))
replaced = []
for i in range(len(functions) - 1, -1, -1):
    match = functions[i]
    if 'l: Lifetimes&' not in match.group(2):
        continue
    end = len(source)
    if i + 1 < len(functions):
        end = functions[i + 1].start()
    old = source[match.start():end]
    new, count = re.subn(r'\blife_size_class\(p, ', 'life_cached_size_class(p, l, ', old)
    if count:
        replaced.append({'function': match.group(1), 'calls': count})
    source = source[:match.start()] + new + source[end:]
wrapper = '''inline fn life_cached_size_class(p: Program&, l: Lifetimes&, ty: i64) -> i64 {
    if ty < 0 { return 0; }
    if !l.types_frozen || ty >= l.size_classes.len { return life_size_class(p, ty); }
    let cached = l.size_classes[ty];
    if cached >= 0 { return cached; }
    let result = life_size_class(p, ty); l.size_classes[ty] = result;
    return result;
}
'''
source = source.replace('fn life_push_future(', wrapper + 'fn life_push_future(', 1)
source = source.replace('    var l = Lifetimes {', '    var size_classes: i64[>..] = []; size_classes.resize(p.types.len, -1);\n    var l = Lifetimes {', 1)
source = source.replace('kills: kills, atoms: atoms,', 'kills: kills, size_classes: size_classes, atoms: atoms,', 1)
source = source.replace('    // All equations only add alternatives', '    while size_classes.len < p.types.len { size_classes.push(-1); }\n    // Standalone argument synthesis is complete; evaluation only reads types.\n    l.types_frozen = true;\n    // All equations only add alternatives', 1)
source = source.replace('            return;\n        }\n        if l.revision == before', '            l.types_frozen = false;\n            return;\n        }\n        if l.revision == before', 1)
source = source.replace('    if p.diagnostics.len == 0 { life_export_provenance', '    l.types_frozen = false;\n    if p.diagnostics.len == 0 { life_export_provenance', 1)
def function(text, name):
    start = re.search(r'^(?:(?:inline|recursive) )?fn ' + name + r'\(', text, re.M).start()
    next_fn = re.search(r'^(?:(?:inline|recursive) )?fn ', text[start + 1:], re.M)
    end = len(text)
    if next_fn:
        end = start + 1 + next_fn.start()
    return text[start:end]
assert function(base, 'life_size_class') == function(source, 'life_size_class')
(root / 'checker_lifetimes.goose').write_text(source)
(root / 'candidate.patch').write_text(''.join(difflib.unified_diff(base.splitlines(True), source.splitlines(True), fromfile='a/selfhost/checker_lifetimes.goose', tofile='b/selfhost/checker_lifetimes.goose')))
(root / 'edits.json').write_text(json.dumps({'baseline': str(baseline_path), 'baseline_sha256': hashlib.sha256(base.encode()).hexdigest(), 'candidate_sha256': hashlib.sha256(source.encode()).hexdigest(), 'replaced': sorted(replaced, key=lambda v: v['function']), 'original_helper_unchanged': True}, indent=2) + '\n')
