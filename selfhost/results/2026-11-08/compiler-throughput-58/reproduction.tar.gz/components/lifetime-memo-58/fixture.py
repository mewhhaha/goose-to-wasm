from pathlib import Path
import re
root = Path(__file__).resolve().parent
source = (root / 'checker_lifetimes.goose').read_text()
model = (root.parent / 'compiler-recursive-58/selfhost/model.goose').read_text()
def function(name):
    start = re.search(r'^(?:inline )?fn ' + name + r'\(', source, re.M).start()
    end = source.index('\n}', start) + 3
    return source[start:end]
constants = '\n'.join(line for line in model.splitlines() if re.match(r'let (TY_|A_|F_VARIABLE_MODE)', line))
actual_type = re.search(r'struct Type \{.*?\n\}', model, re.S).group()
fixture = '''import std;
''' + constants + '\n' + actual_type + '''
struct Node { type_id: i64 = -1, next: i64 = -1 }
struct Program { types: Type[>..]&, nodes: Node[>..]& }
struct Lifetimes { size_classes: i64[>..]&, types_frozen: bool = false }
''' + function('life_size_class') + '\n' + function('life_cached_size_class') + '''
fn main() -> i32 {
    var nodes: Node[>..] = [
        Node { type_id: 6, next: 1 }, Node { type_id: 0 }, Node { type_id: 0 },
        Node { type_id: 16, next: 4 }, Node { type_id: 0 },
        Node { type_id: 17, next: 6 }, Node { type_id: 8 }
    ];
    var types: Type[>..] = [
        Type { kind: TY_INT }, Type { kind: TY_INT, storage: 1 },
        Type { kind: TY_REF, element: 6 }, Type { kind: TY_REF, element: 6, length_storage: 0 },
        Type { kind: TY_SLICE, element: 6 }, Type { kind: TY_ARRAY, element: 0 },
        Type { kind: TY_ARRAY, element: 0, array_kind: A_GROW },
        Type { kind: TY_ARRAY, element: 0, array_kind: A_GROWSHRINK },
        Type { kind: TY_ARRAY, element: 0, array_kind: A_VAR },
        Type { kind: TY_ARRAY, element: 0, count: -1, array_kind: A_LIMITED },
        Type { kind: TY_ARRAY, element: 0, count: 4, array_kind: A_LIMITED },
        Type { kind: TY_ARRAY, element: 12 }, Type { kind: TY_STRUCT, first: 0 },
        Type { kind: TY_ENUM, first: 0 }, Type { kind: TY_ENUM, first: 0, flags: F_VARIABLE_MODE },
        Type { kind: TY_ENUM, first: 2, flags: F_VARIABLE_MODE },
        Type { kind: TY_STRUCT, first: 3 }, Type { kind: TY_STRUCT, first: 5 },
        Type { kind: TY_TUPLE, first: 0 }, Type { kind: TY_ARRAY, element: 11 },
        Type { kind: TY_ARRAY, element: 2 }, Type { kind: TY_STRUCT, storage: 1 },
        Type { kind: TY_ARRAY, array_kind: A_GROW }
    ];
    var cache: i64[>..] = []; cache.resize(20, -1);
    var p = Program { types: types, nodes: nodes };
    var l = Lifetimes { size_classes: cache };
    if life_cached_size_class(p, l, 0) != 0 || cache[0] != -1 { return 1; }
    p.types[0].storage = 1;
    if life_cached_size_class(p, l, 0) != 1 || cache[0] != -1 { return 2; }
    p.types[0].storage = 0;
    // This is the production extension pattern after standalone synthesis.
    while cache.len < p.types.len - 1 { cache.push(-1); }
    l.types_frozen = true;
    let expected: i64[23] = [0, 1, 0, 1, 0, 0, 2, 2, 1, 1, 0, 2, 2, 0, 2, 1, 0, 1, 0, 2, 0, 1, 2];
    for pass in 0..10 {
        for answer, ty in expected {
            if life_size_class(p, ty) != answer { return 3; }
            if life_cached_size_class(p, l, ty) != answer { return 4; }
            if ty < cache.len && cache[ty] != answer { return 5; }
        }
    }
    if life_cached_size_class(p, l, -1) != 0 || cache.len != 22 { return 6; }
    // Once the phase ends, even populated entries must be bypassed.
    l.types_frozen = false; p.types[0].storage = 1;
    if life_cached_size_class(p, l, 0) != 1 || cache[0] != 0 { return 7; }
    print("size-class memo: 23 graph cases, 10 passes, phase and bounds fallbacks passed");
    return 0;
}
'''
(root / 'size-class-fixture.goose').write_text(fixture)
