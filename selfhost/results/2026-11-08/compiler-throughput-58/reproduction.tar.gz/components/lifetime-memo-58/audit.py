from pathlib import Path
import re, json, hashlib
root = Path(__file__).resolve().parent
source_root = root.parent / 'compiler-recursive-58/selfhost'
candidate = root / 'checker_lifetimes.goose'

def mask(text):
    return re.sub(r'//[^\n]*|/\*.*?\*/|"(?:\\.|[^"\\])*"', lambda m: re.sub(r'[^\n]', ' ', m.group()), text, flags=re.S)

def parse(path):
    text = path.read_text()
    masked = mask(text)
    found = {}
    for m in re.finditer(r'^(?:(?:inline|recursive|export|extern)\s+)*fn\s+(\w+)\s*(?:<[^>]+>)?\(', masked, re.M):
        opening = masked.find('{', m.end())
        if opening < 0:
            continue
        depth = 1
        end = opening + 1
        while depth:
            if masked[end] == '{': depth += 1
            if masked[end] == '}': depth -= 1
            end += 1
        found[m.group(1)] = {'path': str(path), 'line': text.count('\n', 0, m.start()) + 1, 'source': text[m.start():end], 'mask': masked[m.start():end]}
    return found
functions = {}
for path in source_root.glob('*.goose'):
    if path.name != candidate.name:
        functions.update(parse(path))
functions.update(parse(candidate))
closure = set()
work = ['life_eval', 'life_function', 'life_error']
while work:
    name = work.pop()
    if name in closure: continue
    closure.add(name)
    for call in re.findall(r'(?<![\w.])(\w+)\s*\(', functions[name]['mask']):
        if call in functions and call not in closure: work.append(call)
writes, aliases, methods = [], [], []
for name in sorted(closure):
    entry = functions[name]
    for offset, (line, masked) in enumerate(zip(entry['source'].splitlines(), entry['mask'].splitlines())):
        if not re.search(r'p\.(?:nodes|types|symbols)\b', masked): continue
        item = {'function': name, 'line': entry['line'] + offset, 'source': line.strip()}
        for access in re.finditer(r'p\.(?:nodes|types|symbols)\b', masked):
            at = access.end()
            while at < len(masked):
                while at < len(masked) and masked[at].isspace(): at += 1
                if at < len(masked) and masked[at] == '[':
                    depth = 1; at += 1
                    while at < len(masked) and depth:
                        if masked[at] == '[': depth += 1
                        if masked[at] == ']': depth -= 1
                        at += 1
                    continue
                field = re.match(r'\.\w+', masked[at:])
                if field:
                    at += field.end()
                    continue
                break
            if re.match(r'(?:[+*/|&^%-]?=(?!=)|(?:<<|>>)=)', masked[at:]): writes.append(item)
        if re.search(r'(?:var|let)\s+\w+\s*:\s*(?!const)(?:Node|Type|Symbol)\s*&\s*=\s*p\.', masked): aliases.append(item)
        if re.search(r'p\.(?:nodes|types|symbols)\.(?:push|pop|append|resize|clear|remove|insert)\s*\(', masked): methods.append(item)
assert not writes, writes
assert not aliases, aliases
assert not methods, methods
original = parse(source_root / candidate.name)['life_size_class']['source']
changed = parse(candidate)['life_size_class']['source']
assert original == changed
result = {
    'candidate_sha256': hashlib.sha256(candidate.read_bytes()).hexdigest(),
    'roots': ['life_eval', 'life_function', 'life_error'],
    'closure_count': len(closure), 'closure': sorted(closure),
    'arena_field_writes': writes, 'arena_mutable_record_aliases': aliases, 'arena_growth_or_shrink_methods': methods,
    'outside_lifetime_helpers': sorted(name for name in closure if not name.startswith('life_')),
    'original_helper_unchanged': True,
    'closure_source_sha256': {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted({Path(functions[name]['path']) for name in closure})},
    'phase_review': {
        'before_freeze': 'life_validate_pools may diagnose; life_standalone_arguments/life_standalone_type add nodes/types; cache initialized before Lifetimes binding and extended with push after all synthesis',
        'during_freeze': 'life_size_class depends only on Type metadata and nominal-field Node.type_id/Node.next, all immutable throughout discovery/live life_eval/life_function closure; life_error/diagnose append only messages and diagnostics; mutable Lifetimes cells/frames/roots/effects do not enter life_size_class computation',
        'failure_return': 'discovery failure reports diagnostics then clears types_frozen and returns; early returns inside helpers do not export or grow program arenas',
        'after_freeze': 'flag cleared before life_export_provenance (nodes/symbols writes) and life_refresh_named_results (node writes/growth)',
        'bound_guard': 'cached only when ty >= 0 and ty < cache length; original helper fallback otherwise; no weaker diagnostics or inference'
    },
    'tradeoff': 'one i64 per type, about 8 bytes/type plus grow-array capacity/metadata; lazy misses retain baseline graph walk and never precompute unused types; cache is released with check_lifetimes locals',
    'independent_review': 'compiler_ceiling_review reviewed candidate 0883c4063faccbfdf4a03db62f2484d01e9d0ef08c2e7bce3a44aa20e8360e1d: no blocker; both Type and nominal-field Node metadata remain immutable for the phase',
    'limits': 'source audit and extracted-helper fixture only; full self-bootstrap/contracts/performance qualification remains with parent'
}
(root / 'audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ('closure_count', 'outside_lifetime_helpers', 'arena_field_writes', 'arena_mutable_record_aliases', 'arena_growth_or_shrink_methods')}))
