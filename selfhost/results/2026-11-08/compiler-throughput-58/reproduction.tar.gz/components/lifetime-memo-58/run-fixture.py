from pathlib import Path
import hashlib, subprocess, json, time
root = Path(__file__).resolve().parent
repo = root.parents[2]
compiler = root.parent / 'compiler-recursive-58/goose'
command = [str(compiler), str(root / 'size-class-fixture.goose'), '--stdlib', str(repo / 'stdlib'), '--target', 'native', '--run', '-o', str(root / 'size-class-fixture.c')]
start = time.monotonic()
result = subprocess.run(command, cwd=repo, capture_output=True, text=True)
elapsed = time.monotonic() - start
(root / 'fixture.stdout').write_text(result.stdout)
(root / 'fixture.stderr').write_text(result.stderr)
proof = {'command': command, 'compiler_sha256': hashlib.sha256(compiler.read_bytes()).hexdigest(), 'source_sha256': hashlib.sha256((root / 'size-class-fixture.goose').read_bytes()).hexdigest(), 'exit_code': result.returncode, 'elapsed_seconds': elapsed, 'output': result.stdout, 'stderr': result.stderr, 'cases': 23, 'passes': 10, 'tests': ['explicit expected answers and uncached helper agreement', 'negative type returns zero', 'cycle and shared nested graph termination', 'reference and fixed enum stop traversal', 'lazy cache entries untouched outside frozen phase', 'grow-only cache extension after binding', 'out-of-cache valid type falls back unchanged', 'post-phase stale cached answer bypassed after type mutation'], 'limitations': 'Extracted actual helper/wrapper and Type definition; minimal Node/Program/Lifetimes fixture model. Compiler emitted a native g_empty_byte/stringop-overflow warning; fixture exited zero. No whole compiler self-bootstrap, contracts, or performance claim.'}
(root / 'fixture-proof.json').write_text(json.dumps(proof, indent=2) + '\n')
print(result.stdout, end='')
print(f'exit={result.returncode} elapsed={elapsed:.3f}s')
raise SystemExit(result.returncode)
