from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import subprocess

root = Path.cwd()
out = root / "build/completion-runs/pgo-code-review-58"
plain = root / "build/completion-runs/compiler-plain-58/goose"
pgo = root / "build/completion-runs/compiler-pgo-58/goose"
c_source = root / "build/completion-runs/compiler-plain-58/compiler.c"
source_root = root / "build/completion-runs/compiler-plain-58/selfhost"


def functions(binary):
    result = {}
    for line in subprocess.check_output(["nm", "-S", str(binary)], text=True).splitlines():
        parts = line.split()
        if len(parts) != 4 or parts[2].lower() != "t" or not parts[3].startswith("g_fn"):
            continue
        result[parts[3]] = {"address": int(parts[0], 16), "size": int(parts[1], 16)}
    return result


plain_fns = functions(plain)
pgo_fns = functions(pgo)
common = set(plain_fns) & set(pgo_fns)
changes = []
for name in common:
    before = plain_fns[name]["size"]
    after = pgo_fns[name]["size"]
    changes.append({"symbol": name, "plain_bytes": before, "pgo_bytes": after, "delta_bytes": after - before})
changes.sort(key=lambda row: row["delta_bytes"])

source_functions = {}
declaration = re.compile(r"^\s*(?:recursive\s+)?fn\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(")
for path in source_root.rglob("*.goose"):
    rows = []
    for number, line in enumerate(path.read_text(errors="replace").splitlines(), 1):
        match = declaration.match(line)
        if match:
            rows.append((number, match.group(1)))
    source_functions[str(path)] = rows

function_start = re.compile(r"^static .+\bg_fn(\d+)\(.*\) \{$")
location = re.compile(r'g_element_at\([^;\n]*?"((?:\\.|[^"\\])*)",(\d+)\)')
locations = {}
current_symbol = None
for number, line in enumerate(c_source.open(errors="replace"), 1):
    start = function_start.match(line)
    if start:
        current_symbol = "g_fn" + start.group(1)
        locations.setdefault(current_symbol, Counter())
    if current_symbol is None:
        continue
    for match in location.finditer(line):
        path = re.sub(r"\\([0-7]{1,3})", lambda item: chr(int(item.group(1), 8)), match.group(1))
        if not path.endswith(".goose"):
            continue
        source_line = int(match.group(2))
        funcs = source_functions.get(path, [])
        owner = None
        for decl_line, name in funcs:
            if decl_line > source_line:
                break
            owner = (Path(path).name, name, decl_line)
        if owner:
            locations[current_symbol][owner] += 1


def enrich(row):
    return {
        **row,
        "source_candidates": [
            {"file": path, "function": name, "line": line, "location_votes": votes}
            for (path, name, line), votes in locations.get(row["symbol"], Counter()).most_common(4)
        ],
    }


plain_text = sum(value["size"] for value in plain_fns.values())
pgo_text = sum(value["size"] for value in pgo_fns.values())
result = {
    "source_sha256": hashlib.sha256(c_source.read_bytes()).hexdigest(),
    "plain_executable_sha256": hashlib.sha256(plain.read_bytes()).hexdigest(),
    "pgo_executable_sha256": hashlib.sha256(pgo.read_bytes()).hexdigest(),
    "g_fn_symbols": {
        "plain_count": len(plain_fns),
        "pgo_count": len(pgo_fns),
        "common_count": len(common),
        "plain_sum_bytes": plain_text,
        "pgo_sum_bytes": pgo_text,
        "common_plain_sum_bytes": sum(plain_fns[name]["size"] for name in common),
        "common_pgo_sum_bytes": sum(pgo_fns[name]["size"] for name in common),
    },
    "largest_common_symbol_shrinks": [enrich(row) for row in changes[:20]],
    "largest_common_symbol_grows": [enrich(row) for row in reversed(changes[-20:])],
}
(out / "symbol-deltas.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({key: result[key] for key in ("g_fn_symbols", "largest_common_symbol_shrinks", "largest_common_symbol_grows")}, indent=2))
