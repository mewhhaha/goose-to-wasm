from pathlib import Path
import hashlib,json,subprocess,time,os,shutil,concurrent.futures
root=Path.cwd();w=root/'build/completion-runs';out=Path(__file__).resolve().parent

def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def run(cmd,name,cpu=2,env=None):
 start=time.monotonic();p=subprocess.run(['taskset','-c',str(cpu),*map(str,cmd)],cwd=out,capture_output=True,text=True,env=env)
 (out/(name+'.stdout')).write_text(p.stdout);(out/(name+'.stderr')).write_text(p.stderr);r={'command':list(map(str,cmd)),'cwd':str(out),'cpu':cpu,'seconds':time.monotonic()-start,'exit_code':p.returncode};(out/(name+'.json')).write_text(json.dumps(r,indent=2)+'\n');print(name,p.returncode,round(r['seconds'],2),flush=True);assert p.returncode==0,p.stderr
plan=json.loads((w/'compiler-ir-pgo-protocol-58/plan.json').read_text())
training=[{'name':'native','source':'sources/main.goose','target':'native','weight':1},{'name':'leaf','source':str(w/'compiler-subtractive-58/leaf-properties-fixture.goose'),'target':'wasm-direct','weight':64},{'name':'flow','source':str(w/'compiler-subtractive-58/flow-prefilter-fixture.goose'),'target':'wasm-direct','weight':64}]
run([w/'compiler-trimmed-58/goose','sources/main.goose','--stdlib','stdlib','--target','native','-O2','-o','seed.c'],'emit-canonical')
protocol={'schema':'goose-IR-pgo-training-v1','plan_sha256':sha(w/'compiler-ir-pgo-protocol-58/plan.json'),'c_sha256':sha(out/'seed.c'),'input_pins_sha256':sha(out/'input-pins.json'),'clang_sha256':sha(Path(shutil.which('clang-23')).resolve()),'profdata_sha256':sha(Path(shutil.which('llvm-profdata')).resolve()),'training':training,'training_source_sha256':{r['name']:sha(out/r['source']) for r in training},'base_flags':['-std=gnu11','-O2','-lm','-ldl','-pthread'],'c_basename':'seed.c','timed_inputs_used_for_training':False,'generation':'-fprofile-generate LLVM IR, _Exit wrapper training-only','canonical_C_bootstrap_linkage':'Pending exact canonical C-only-bootstrap-58 comparison; cannot ship without equality.'}
(out/'training-protocol.json').write_text(json.dumps(protocol,indent=2)+'\n');(out/'raw').mkdir()
(out/'profile-exit.c').write_text('#include <stdlib.h>\nint __llvm_profile_write_file(void);\n_Noreturn void __real__Exit(int);\n_Noreturn void __wrap__Exit(int code){__llvm_profile_write_file();__real__Exit(code);}\n')
base=['clang-23','-std=gnu11','-O2','seed.c','-lm','-ldl','-pthread']
with concurrent.futures.ThreadPoolExecutor(2) as pool:
 jobs=[pool.submit(run,[*base,'-o','goose-plain'],'plain-build',2),pool.submit(run,[*base,'-fprofile-generate','profile-exit.c','-Wl,--wrap=_Exit','-o','goose-train'],'instrumented-build',6)]
 for job in jobs:job.result()
run([out/'goose-plain','sources/main.goose','--stdlib','stdlib','--target','native','-O2','-o','verify-plain.c'],'verify-plain')
assert sha(out/'seed.c')==sha(out/'verify-plain.c')
raw=[]
for row in training:
 env=os.environ.copy();env['LLVM_PROFILE_FILE']=str(out/'raw'/(row['name']+'-%p.profraw'))
 run([out/'goose-train',row['source'],'--stdlib','stdlib','--target',row['target'],'-O2','-o',str(out/('training-'+row['name']+'.out'))],'train-'+row['name'],env=env)
 files=list((out/'raw').glob(row['name']+'-*.profraw'));assert len(files)==1;raw.append((row['weight'],files[0]))
 if row['target']=='wasm-direct':
  import wasmtime
  wasmtime.Module.validate(wasmtime.Engine(),(out/('training-'+row['name']+'.out')).read_bytes())
assert len(list((out/'raw').glob('*.profraw')))==3 and sha(out/'training-native.out')==sha(out/'seed.c')
run(['llvm-profdata','merge','-o','profile.profdata',*['-weighted-input='+str(weight)+','+str(path) for weight,path in raw]],'merge-profile')
run(['llvm-profdata','show','profile.profdata'],'profile-summary')
assert 'Instrumentation level: IR' in (out/'profile-summary.stdout').read_text()
meta={'schema':'goose-bootstrap-profile-v1','c_sha256':sha(out/'seed.c'),'clang_major':23,'target':subprocess.check_output(['clang-23','-dumpmachine'],text=True).strip(),'base_flags':protocol['base_flags'],'c_basename':'seed.c','data_sha256':sha(out/'profile.profdata')};(out/'profile.json').write_text(json.dumps(meta,indent=2)+'\n')
run([*base,'-fprofile-instr-use='+str(out/'profile.profdata'),'-Werror=profile-instr-out-of-date','-Werror=profile-instr-missing','-Werror=profile-instr-unprofiled','-o','goose-pgo'],'optimized-build')
run([out/'goose-pgo','sources/main.goose','--stdlib','stdlib','--target','native','-O2','-o','verify-pgo.c'],'verify-pgo')
assert sha(out/'verify-pgo.c')==sha(out/'seed.c')
for name,value in json.loads((out/'input-pins.json').read_text()).items():assert sha(out/name)==value,name
(out/'fixedpoint.json').write_text(json.dumps({'status':'passed','c_sha256':sha(out/'seed.c'),'plain_sha256':sha(out/'goose-plain'),'pgo_sha256':sha(out/'goose-pgo'),'profile_sha256':sha(out/'profile.profdata'),'IR':True,'strict_profile_use':True,'fixed_point':True,'construction_timing':'Concurrent private builds; not isolated timing comparison','canonical_C_bootstrap_linkage':'Still pending final C-only-bootstrap-58 equality'},indent=2)+'\n');print('A22 canonical IR-PGO fixedpoint PASS',flush=True)
