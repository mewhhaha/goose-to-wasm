from pathlib import Path
import argparse,hashlib,json,os,re,subprocess
R=Path('/home/jacobt/src/goose-to-wasm');H=Path(__file__).resolve().parent;G=H/'guards';a=argparse.ArgumentParser();a.add_argument('--compiler',required=True);a.add_argument('--output-dir',required=True);a.add_argument('--candidate',action='store_true');a=a.parse_args();O=Path(a.output_dir).resolve();O.mkdir();os.sched_setaffinity(0,{4});sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[];commands=[]
def execute(cmd):
 p=subprocess.run([str(x) for x in cmd],cwd=R,text=True,capture_output=True,timeout=60);commands.append(dict(command=[str(x) for x in cmd],exit=p.returncode,stderr=p.stderr));assert p.returncode==0,commands[-1];return p.stdout
def function_body(text,identity):
 m=re.search(r'\bg_fn'+str(identity)+r'\([^;]*?\)\s*\{',text);assert m,identity
 at=m.end();start=at;depth=1
 while depth:
  if text.startswith('//',at):at=text.index('\n',at);continue
  if text.startswith('/*',at):at=text.index('*/',at+2)+2;continue
  ch=text[at]
  if ch in ['"',"'"]:
   quote=ch;at+=1
   while text[at]!=quote:
    if text[at]=='\\':at+=1
    at+=1
  elif ch=='{':depth+=1
  elif ch=='}':depth-=1
  at+=1
 return text[start:at-1]
for contract_name in ['contract.json','padding-contract.json']:
 contract=G/contract_name;C=json.loads(contract.read_text());source=R/C['source'];assert sha(source)==C['sha256']
 expected={}
 for fn,names in C['eligible'].items():
  for name in names:expected[(fn,name)]=True
 for fn,names in C['retained'].items():
  for name in names:expected[(fn,name)]=False
 for level in C['levels']:
  for debug in C['debug']:
   label=source.stem+'-O'+str(level)+'-debug'+str(debug);native=O/(label+'.c');base=[str(Path(a.compiler).resolve()),source,'--stdlib',R/'stdlib','--target','native','-O'+str(level)]
   if debug:base.append('--debug')
   execute([*base,'--standalone','-o',native]);raw=execute([*base,'--dump-ir']);(O/(label+'.json')).write_text(raw);ir=json.loads(raw);text=native.read_text();functions={}
   for n in ir['nodes']:
    if n['kind']==3 and ir['tokens'][n['token']]['source']==0:functions[ir['tokens'][n['token']]['text']]=n['id']
   for (fn,name),eligible in expected.items():
    owner=functions[fn];symbols=[s for s in ir['symbols'] if s['owner']==owner and s['name_token']>=0 and ir['tokens'][s['name_token']]['text']==name];assert len(symbols)==1,(fn,name,symbols)
    symbol=symbols[0];identity=symbol['id'];type_id=symbol['type_id'];body=function_body(text,owner);declaration=re.search(r'\bg_t'+str(type_id)+r'\s+g_s'+str(identity)+r'\s*([^;]*);',body);fixed='g_fixed_g_s'+str(identity)+' __attribute__((cleanup(g_fixed_release)))=g_fixed_begin(sizeof(g_t'+str(type_id)+'),1);' in body
    checks={};uninitialized=False
    if declaration:uninitialized=declaration.group(1).strip()==''
    if a.candidate and eligible:checks['entry_initializer_omitted']=bool(declaration) and uninitialized
    else:checks['entry_initializer_retained']=fixed or bool(declaration) and declaration.group(1).strip()=='={}'
    if eligible:
     refs=re.findall(r'\bg_v(\d+)=g_ref\(&g_s'+str(identity)+r'\);',body);checks['later_full_store']=any(re.search(r'\bg_store_'+str(type_id)+r'\(g_v'+ref+r',g_v\d+\);',body) for ref in refs);checks['full_store_helper']=bool(re.search(r'\bg_store_'+str(type_id)+r'\([^;]*?\)\{\s*memmove\(g_address\(p\),&v,sizeof v\);\}',text))
    rows.append(dict(function=fn,local=name,symbol=identity,type=type_id,optimization=level,debug=debug,eligible=eligible,checks=checks,passed=all(checks.values()),C_sha256=sha(native),contract_sha256=sha(contract)))
status='failed'
if rows and all(r['passed'] for r in rows):status='passed'
report=dict(status=status,candidate=a.candidate,checks=len(rows),compiler_sha256=sha(Path(a.compiler)),rows=rows,commands=commands);(O/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(status,len(rows));assert status=='passed'
