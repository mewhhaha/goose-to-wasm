from pathlib import Path
import subprocess,json,time,hashlib,os
root=Path.cwd();base=root/'build/completion-runs/native-local-init-58';out=base/'candidate-memory-sanitizer';out.mkdir();os.sched_setaffinity(0,{5});runs=[]
for source in sorted((base/'candidate-wasmtime/artifacts').glob('*/program.c')):
 binary=out/('program-'+source.parent.name);cmd=['clang-23','-std=gnu11','-O1','-g','-fsanitize=memory','-fno-omit-frame-pointer','-fPIE','-pie',str(source),'-lm','-ldl','-pthread','-o',str(binary)]
 start=time.monotonic();p=subprocess.run(cmd,capture_output=True,text=True);row=dict(source=str(source),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),command=cmd,compile_exit=p.returncode,compile_seconds=time.monotonic()-start,compile_stderr=p.stderr);assert p.returncode==0,p.stderr
 p=subprocess.run([str(binary)],capture_output=True,text=True,timeout=30);row.update(exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr);runs.append(row);(out/'report.json').write_text(json.dumps(dict(status='running',runs=runs),indent=2)+'\n')
 assert p.returncode==0 and 'MemorySanitizer' not in p.stderr,row
 assert p.stdout in ['56 21 12 13 10 9 8 41 -3\n','89\n'],p.stdout
print(len(runs),'native MemorySanitizer executions passed',flush=True);assert len(runs)==8
(out/'report.json').write_text(json.dumps(dict(status='passed',runs=runs),indent=2)+'\n')
