# Strict explicit inlining inside recursive callers

Private proposal against `compiler-intern-58/selfhost/optimizer.goose` (A4), not qualified or measured. Candidate SHA256: `96019314823906364f95cd8c7f894db927d6008d195239765f73fab75de615d5`.

## Admission boundary

A recursive caller may now consider an explicitly `inline` callee. An ordinary unhinted callee remains barred. Recursive callees, currently active functions, dispatch at the call site, builtins/externs at the call site, argument-count mismatches, body-size limits and activation dependencies retain their existing rejection paths. Cloning, ordered argument temporaries, local-slot allocation, capture remapping, nonlocal return rewriting, exit retargeting and lifetime provenance copying are unchanged.

The newly reachable path supplies `strict=true` to the existing dependency graph. Every nested call propagates it. Strict dependency traversal rejects unknown/unbound/invalid targets, externs, any dispatch call, unknown builtin IDs, thread spawning (7/8), and reusable-slice allocation/reallocation (33/34). Spawn's worker target is in an argument rather than the builtin symbol. Slice default expressions live in `N_CALL.aux`, outside ordinary AST children. Those operations remain out of line rather than depending on an incomplete graph.

For existing nonrecursive callers, `strict=false`. The old symbol/extern/builtin outcomes, traversal order and activation-owner tests are unchanged. The extra expression-list traversal is disabled. No checks or diagnostics are bypassed.

## Callback and activation argument

The owner passed to `opt_inline_dependencies` is the callee being removed. This proof asks whether another activation can still require that callee's storage or nonlocal return target. It is not a general prohibition on calling a recursive function.

The checker binds formal function values before optimization: `check_call` resolves a `TY_FN.declaration`, specializes it and publishes the selected symbol on the call (`selfhost/checker.goose:4306-4356`). Specialization clears stale symbols and dispatch metadata and checks the cloned body again (`:672-699`). Compile-time function arguments are then removed from the runtime argument list (`:4380`). Thus a callback passed as the recursive caller is visible as a checked call edge in the specialized callee. No optimizer argument substitution is needed for this admitted checked AST.

For `r -> inline apply<F=r> -> r`, walking the checked body of `r` reaches the same specialized `apply` and rejects removal of that activation. A separately executing nested function that reads a binding owned by the candidate or returns nonlocally to it is also rejected by the original owner tests. Visited-function deduplication terminates the graph without hiding a first visit to a forbidden edge.

Dispatch needs a stronger rejection: `check_try_dispatch` stores alternatives in `N_BINDING.symbol`, while the old walker follows only `N_CALL.symbol`. Rejecting dispatch at every dependency depth prevents an unvisited alternative from invalidating the activation proof. Unknown/extern calls receive the same conservative treatment. Nested function declarations are skipped as declarations; their executable bodies are traversed when their resolved calls are reached.

The strict tree walk also follows all initializer siblings (`N_VARIABLE.right`) and all optimized break-result siblings (`N_BREAK.left`). `opt_clone` already recognizes these as linked expression lists. Only their first expression was visible to the previous dependency walker. Original child-list, left, right and third traversals remain in place.

The remaining accepted builtin IDs do not execute hidden user callbacks: formatting hooks are lowered into checked ordinary calls; default construction replaces the builtin call with checked AST; embedded files become literals; unsupported shader embedding diagnoses before optimization; queues/byte images/stored aggregates cannot carry callable function values. Their explicit arguments remain visited by the tree walker.

## Independent guards

`cases.json` freezes 116 checks across O0/O2, native/direct-Wasm and normal/debug modes. Fifteen source fixtures cover hinted versus automatic policy, recursive callees and cycles, tail-argument order, captured state, nonlocal targets, repeated owned cleanup, an undeclared recursive cycle diagnostic, callback reentry with owned results, captured callbacks with nonlocal return and owned cleanup, transitive extern/dispatch dependencies, initializer/break-result siblings, and hidden pool defaults.

New results were calculated from source before any compiler run:

- Owned callback reentry: each returned `[7, 8]` contributes `2+7+8`, repeated 1000 times = `17000`.
- Captured nonlocal callback: `target(2)=122`; `target(3)=40+122=162`; `target(4)=53+162=215`; `target(1)=14+1=15`. Output `215000 15`.
- Nested extern adds input 4 and 3: `7`.
- Dispatch branches add 3 to 11/22: `14 25`.
- Extra initializer/break sibling adds 1 to input 4 plus 3: `8`.
- Reusable slice defaults call input once: `4`.

`check-calls.py` independently inspects emitted C using named function IDs from checked IR, including specialized generic callees. It freezes 52 call-presence assertions: successful hinted inlining, retained automatic and activation-dependent calls, direct and callback recursive cycles, and every new conservative hidden-edge case. It compiles neither C nor C++ and uses no oracle. These assertions distinguish an optimization that genuinely activates from one that merely preserves outputs.

Only patch applicability, Python syntax, manifest uniqueness and source-path existence have been checked here. No Goose fixture or compiler has been executed by this review. Full qualification, resource/stack contracts, generated-code size and performance gates remain required. A host built by the old optimizer must self-emit at O2 and be rebuilt before measuring the new policy's effect on its own compilation speed. Keep automatic inlining inside recursive callers excluded from this batch.
