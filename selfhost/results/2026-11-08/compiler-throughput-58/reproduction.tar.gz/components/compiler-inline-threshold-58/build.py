from pathlib import Path
import subprocess,json,time,hashlib
root=Path.cwd();w=root/'build/completion-runs';out=w/'compiler-inline-threshold-58';source=w/'compiler-local-init-58/compiler.c'
cmd=['taskset','-c','6','clang-23','-std=gnu11','-O2','-mllvm','-inline-threshold=1000',str(source),'-lm','-ldl','-pthread','-o',str(out/'goose')]
t=time.monotonic();p=subprocess.run(cmd,capture_output=True,text=True);(out/'cc.stderr').write_text(p.stderr);r=dict(command=cmd,exit_code=p.returncode,seconds=time.monotonic()-t,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest());(out/'cc.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True);assert p.returncode==0
