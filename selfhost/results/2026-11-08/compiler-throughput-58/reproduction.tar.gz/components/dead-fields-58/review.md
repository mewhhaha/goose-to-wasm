# Private dead-field subtraction patch

Base: `build/completion-runs/native-member-global-58` (A19 + approved bounded member gate). The source tree and pin file advanced after this private copy was captured. The four touched original files were reconstructed by reversing only the intended edits; hashes match the captured pins. No live files were edited. No compiler/build/benchmark was run.

## Exact subtraction and inventory

- `Symbol.scope_next`: declaration in `selfhost/model.goose`; writes in `checker.goose` (scope-chain insertion) and `optimizer.goose` (clone initialization); **zero reads** across base `selfhost/*.goose`. Removed declaration and both writes. Kept `name_next` and `name_heads`, used by the live bucket lookup.
- `CheckScope.first_symbol`: declaration in `checker.goose`; write in `check_link_symbol`; its only field read supplied `Symbol.scope_next` above. Removed field and both ends of that chain. The checker’s local `first_symbol` in dispatch is preserved.
- `CheckScope.lifetime` → `scope_lifetimes` → `Lifetimes.lifetime`: base references are the field declaration, scope creation assignment, one scope-copy read/write, vector declaration/push, function parameter, struct member, and initializer. No algorithmic read of `scope.lifetime`, the vector argument, or `l.lifetime` exists. Removed the field, copy/assignment, vector, parameter, struct member, and initializer value. Kept scope parent/depth/function arrays.

The candidate audit confirms no remaining `scope_next`, field `.first_symbol`, `.lifetime`, `scope_lifetime`, or `scope_lifetimes` references. The only remaining `first_symbol` text is the unrelated live local dispatch variable and its two uses. Exactly four selfhost files changed; native files match pinned base.

## Before/after field access audit

| Field / transport | Base typed access count | Candidate |
|---|---:|---:|
| `Symbol.scope_next` (`i64`) | 0 reads, 2 writes | absent |
| `CheckScope.first_symbol` (`i64`) | 1 read (only to seed dead `scope_next`), 1 write | absent |
| `CheckScope.lifetime` (`i64`) | 2 reads (copy source and vector push), 2 writes (scope creation and copy destination) | absent |
| `scope_lifetimes` (`i64[]`) | 1 append site per scope; passed once | absent |
| `Lifetimes.lifetime` (`const i64[:]`) | initialized once; 0 reads | absent |

After the patch, exact-name search finds no `scope_next`, `.first_symbol` field access, `.lifetime`, `scope_lifetime`, or `scope_lifetimes` in the candidate sources. Remaining `first_symbol` matches are the independent dispatch local and its two active uses. `name_next` / `name_heads` accesses remain intact.

## Estimated payload change (not measured)

- `Symbol`: 13 scalar `i64` fields to 12; minus 8 bytes per symbol (104 B to 96 B scalar payload, about 7.7%).
- `CheckScope`: 9 scalar `i64` fields to 7; minus 16 bytes per scope, excluding its fixed `i64[16]` name buckets.
- The transported scope-lifetime vector also costs 8 bytes per scope while present; its allocation and fill are removed. One slice descriptor is removed from `Lifetimes`; exact native size depends on ABI/layout.

No throughput win is claimed. Parent should review/qualify before using this candidate.

## Pins

See `source-pins.json` for captured base candidate pins, touched-file candidate SHA256 values, native-tree equality, and patch hash.
