from pathlib import Path
import subprocess,time,json,hashlib
root=Path.cwd();r=root/'build/completion-runs';out=r/'compiler-native-o3-58';source=r/'compiler-native-58/compiler.c'
cmd=['taskset','-c','2','clang-23','-std=gnu11','-O3',str(source),'-lm','-ldl','-pthread','-o',str(out/'goose')]
start=time.monotonic();p=subprocess.run(cmd,capture_output=True,text=True);(out/'cc.stderr').write_text(p.stderr);record=dict(command=cmd,exit_code=p.returncode,seconds=time.monotonic()-start,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest());(out/'cc.json').write_text(json.dumps(record,indent=2)+'\n');assert not p.returncode,p.stderr;print(json.dumps(record),flush=True)
