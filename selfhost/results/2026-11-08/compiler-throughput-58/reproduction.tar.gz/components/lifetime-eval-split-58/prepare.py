from pathlib import Path
import hashlib,json,difflib,re
h=Path(__file__).resolve().parent;base=h.parent/'lifetime-value64-58/checker_lifetimes.goose';old=base.read_text();sha=lambda s:hashlib.sha256(s.encode()).hexdigest();assert sha(old)=='f25b736e69cf7f529249623f896aafba3902aa416f468d5e88b061619c05258b'
start=old.index('recursive fn life_eval(');suffix=old.index('    if n.kind == N_UNARY {',start);end=old.index('\nfn life_replay(',suffix)
head=old[start:suffix];body=old[suffix:end];assert body.endswith('}\n')
forward='    return life_eval_body(p, l, node, n, destination, selected_result);\n}\n\n'
new_head='recursive fn life_eval_body(p: Program&, l: Lifetimes&, node: i64, n: const Node&, destination: i64, selected_result: i64) -> LifeValue {\n    var out = LifeValue { type_id: n.type_id };\n'
new=old[:start]+head+forward+new_head+body+old[end:];assert new.count('recursive fn life_eval(')==1;assert new.count('recursive fn life_eval_body(')==1
(h/'checker_lifetimes.goose').write_text(new);(h/'candidate.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/selfhost/checker_lifetimes.goose',tofile='b/selfhost/checker_lifetimes.goose')))
identity={'baseline':str(base),'baseline_sha256':sha(old),'candidate_sha256':sha(new),'patch_sha256':sha((h/'candidate.patch').read_text()),'prefix_sha256':sha(head),'unchanged_suffix_sha256':sha(body),'suffix_lines':body.count('\n'),'scope':'Function factoring only; existing prefix remains byte-identical, suffix is byte-identical in new recursive helper after initializing same typed default value. Borrowed checked node forwarded, no duplicate checked lookup.'}
(h/'source.json').write_text(json.dumps(identity,indent=2)+'\n');print(json.dumps(identity,indent=2))
