from pathlib import Path
import json,re,hashlib
h=Path(__file__).resolve().parent;s=json.loads((h/'source.json').read_text());base=Path(s['baseline']).read_text();new=(h/'checker_lifetimes.goose').read_text();sha=lambda x:hashlib.sha256(x.encode()).hexdigest()
start=base.index('recursive fn life_eval(');stop=base.index('    if n.kind == N_UNARY {',start);head=base[start:stop]
newstart=new.index('recursive fn life_eval(');newend=new.index('recursive fn life_eval_body(',newstart);wrapper=new[newstart:newend]
value=re.search(r'struct LifeValue \{[^\n]+',base).group()
text='''import std;
let N_NAME:i64=1;let N_STRING:i64=2;let N_INTEGER:i64=3;let N_FLOAT:i64=4;let N_NULL:i64=5;let N_BOOL:i64=6;let N_EMPTY:i64=7;let N_FUNCTION:i64=8;let N_FUNCTION_VALUE:i64=9;let N_IMPORT:i64=10;let N_UNARY:i64=11;let N_MEMBER:i64=12;
let S_FUNCTION:i64=1;let S_TYPE:i64=2;let S_BUILTIN:i64=4;let S_GLOBAL:i64=8;let S_MUTABLE:i64=16;let TY_REF:i64=2;
struct Node {kind:i64=0,symbol:i64=-1,type_id:i64=-1}
struct Symbol {flags:i64=0}
struct Type {kind:i64=1}
struct Program {nodes:Node[>..]&,symbols:Symbol[>..]&,types:Type[>..]&}
struct Cell {root:i64=0,refs:i64=0,live_refs:i64=0}
struct Root {contents:i64=0,live_contents:i64=0}
'''+value+'''\nstruct Lifetimes { cells:Cell[>..]&,roots:Root[>..]&,discovery:bool=false,cellcalls:i64=0,singles:i64=0,reads:i64=0,contents_calls:i64=0,live_calls:i64=0,body_calls:i64=0,read_value:LifeValue=LifeValue {} }
fn life_cell(p:Program&,l:Lifetimes&,symbol:i64)->i64 {l.cellcalls+=1;return 0;}
fn life_single(l:Lifetimes&,root:i64)->i64 {l.singles+=1;return root+1;}
fn life_contents(l:Lifetimes&,refs:i64)->i64 {l.contents_calls+=1;return refs+100;}
fn life_live_contents(l:Lifetimes&,refs:i64)->i64 {l.live_calls+=1;return refs+200;}
fn life_holds(p:Program&,ty:i64)->bool {return ty>=0 && p.types[ty].kind>=2;}
fn life_construct_read(p:Program&,l:Lifetimes&,node:i64,value:LifeValue) {l.reads+=1;l.read_value=value;}
'''
# Both use the same explicit hand-oracle heavy suffix, never a partial lifetime implementation.
stub='''    l.body_calls += 1; out.place=destination;out.refs=selected_result;out.contents=node;out.self_pools=n.kind;out.relative_roots=n.symbol;return out;
}
'''
text+=head.replace('fn life_eval(','fn old_eval(')+stub
text+=wrapper.replace('fn life_eval(','fn new_eval(').replace('life_eval_body(', 'new_body(')
text+='recursive fn new_body(p:Program&,l:Lifetimes&,node:i64,n:const Node&,destination:i64,selected_result:i64)->LifeValue {\n var out=LifeValue {type_id:n.type_id};\n'+stub
text+='''fn equal(a:LifeValue,b:LifeValue) {assert(a.type_id==b.type_id && a.place==b.place && a.refs==b.refs && a.contents==b.contents && a.self_pools==b.self_pools && a.relative_roots==b.relative_roots && a.tuple==b.tuple && a.element_array==b.element_array);}
fn reset(l:Lifetimes&,discovery:bool) {l.discovery=discovery;l.cellcalls=0;l.singles=0;l.reads=0;l.contents_calls=0;l.live_calls=0;l.body_calls=0;l.read_value=LifeValue {};}
fn run(p:Program&,a:Lifetimes&,b:Lifetimes&,node:i64,discovery:bool) {
 reset(a,discovery);reset(b,discovery);let x=old_eval(p,a,node,41,43);let y=new_eval(p,b,node,41,43);equal(x,y);
 assert(a.cellcalls==b.cellcalls && a.singles==b.singles && a.reads==b.reads && a.contents_calls==b.contents_calls && a.live_calls==b.live_calls && a.body_calls==b.body_calls);equal(a.read_value,b.read_value);
 var expected=LifeValue {};var cells=0;var singles=0;var reads=0;var contents_calls=0;var live_calls=0;var bodies=0;
 if node>=0 {
  let n=p.nodes[node];expected.type_id=n.type_id;var name=false;if n.kind==N_NAME && n.symbol>=0 {name=(p.symbols[n.symbol].flags&7)==0;}
  if name {
   cells=1;singles=1;reads=1;expected.place=6;expected.refs=11;expected.contents=21;
   if !discovery {expected.contents=22;if (p.symbols[n.symbol].flags&24)!=24 {expected.refs=12;}}
   if n.type_id==1 {expected.contents=expected.refs+100;contents_calls=1;if !discovery {expected.contents=expected.refs+200;live_calls=1;}}
   if n.type_id<0 || n.type_id==0 {expected.contents=0;}
  } else if n.kind==N_STRING {singles=1;expected.place=1;expected.refs=1;}
  else if n.kind<N_INTEGER || n.kind>N_IMPORT {bodies=1;expected.place=41;expected.refs=43;expected.contents=node;expected.self_pools=n.kind;expected.relative_roots=n.symbol;}
 }
 equal(x,expected);assert(a.cellcalls==cells && a.singles==singles && a.reads==reads && a.contents_calls==contents_calls && a.live_calls==live_calls && a.body_calls==bodies);
 if reads==1 {equal(a.read_value,expected);}
}
fn main() {
 var nodes:Node[>..]=[];var symbols:Symbol[>..]=[];var types:Type[>..]=[Type {},Type {kind:TY_REF},Type {kind:3}];
 for flags in 0..32 {symbols.push(Symbol {flags:flags});for ty in [-1,0,1,2] {nodes.push(Node {kind:N_NAME,symbol:flags,type_id:ty});}}
 for kind in 1..13 {for ty in [-1,0,1,2] {nodes.push(Node {kind:kind,type_id:ty});}}
 var p=Program {nodes:nodes,symbols:symbols,types:types};var ca:Cell[>..]=[Cell {root:5,refs:11,live_refs:12}];var cb:Cell[>..]=[Cell {root:5,refs:11,live_refs:12}];var ra:Root[>..]=[];var rb:Root[>..]=[];
 for i in 0..6 {ra.push(Root {contents:21,live_contents:22});rb.push(Root {contents:21,live_contents:22});}
 var a=Lifetimes {cells:ca,roots:ra};var b=Lifetimes {cells:cb,roots:rb};
 for discovery in [false,true] {run(p,a,b,-1,discovery);run(p,a,b,-7,discovery);for node in 0..nodes.len {run(p,a,b,node,discovery);}}
 print("eval split guards passed");
}
'''
(h/'fixture.goose').write_text(text)
manifest=json.loads((h.parent/'lifetime-value64-58/cases.json').read_text());manifest['cases']=manifest['cases'][:4];manifest['method']='Unchanged actual prefix, candidate wrapper and exact forwarding signature; heavy remainder pinned byte-identical and replaced by same explicit forwarding witness for fixture only. Independent hand expectations for176 node rows plus2 negative IDs, each in discovery/live.'
for c in manifest['cases']:c['id']=c['id'].replace('value64','eval-split');c['source']='build/completion-runs/lifetime-eval-split-58/fixture.goose';c['expect']['stdout']='eval split guards passed\n'
prefix=text[:text.index('fn main()')]
for tag in ['old','new']:
 trap=prefix+'fn main() {var nodes:Node[>..]=[];var symbols:Symbol[>..]=[];var types:Type[>..]=[];var p=Program {nodes:nodes,symbols:symbols,types:types};var cells:Cell[>..]=[];var roots:Root[>..]=[];var l=Lifetimes {cells:cells,roots:roots};let value='+tag+'_eval(p,l,128);print("unexpected",value.type_id);}\n'
 name='bounds-'+tag+'.goose';(h/name).write_text(trap)
 for target in ['native','wasm-direct']:
  for debug in [False,True]:manifest['cases'].append({'id':'eval-split/bounds/'+tag+'/'+target+'/'+str(debug),'source':'build/completion-runs/lifetime-eval-split-58/'+name,'phase':'run','target':target,'levels':[0,2],'debug':debug,'stdin':'','expect':{'stdout':'','exit':'nonzero'}})
(h/'cases.json').write_text(json.dumps(manifest,indent=2)+'\n')
(h/'guard-proof.json').write_text(json.dumps({'fixture_sha256':sha(text),'source':s,'actual_prefix_sha256':sha(head),'actual_new_wrapper_sha256':sha(wrapper),'node_rows':176,'negative_ids':[-1,-7],'discovery_modes':[False,True],'hand_expected':'All32 name symbol-role masks×4 type classes; symbols missing for all12 kind IDs×4 types; exact refs/contents selection; holds clearing; exact effect/cell/single call counts; forwarded destination41/result43/node/kind/symbol. Known checked bounds remain trapping.','limitations':'Suffix is unchanged by source proof, but not executed by this targeted fixture. Supporting helpers expose deterministic state witnesses. Full compiler contracts and A17 assembly/performance remain mandatory.'},indent=2)+'\n')
