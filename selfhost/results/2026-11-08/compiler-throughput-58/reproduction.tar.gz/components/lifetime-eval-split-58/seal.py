from pathlib import Path
import json,hashlib,re
h=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();ids=json.loads((h/'source.json').read_text());base=Path(ids['baseline']).read_text();new=(h/'checker_lifetimes.goose').read_text()
insert='''    return life_eval_body(p, l, node, n, destination, selected_result);
}

recursive fn life_eval_body(p: Program&, l: Lifetimes&, node: i64, n: const Node&, destination: i64, selected_result: i64) -> LifeValue {
    var out = LifeValue { type_id: n.type_id };
'''
assert new.count(insert)==1 and new.replace(insert,'',1)==base
suffix=new[new.index('    if n.kind == N_UNARY {',new.index('recursive fn life_eval_body(')):new.index('\nfn life_replay(',new.index('recursive fn life_eval_body('))]
assert hashlib.sha256(suffix.encode()).hexdigest()==ids['unchanged_suffix_sha256']
receipt={'status':'passed','source':ids,'source_approval':'Astra exact-reviewed0d908e48; removing five inserted lines reproduces full parent byte-for-byte.','scope':'Private source factoring only. Unchanged A16 compiler executes actual-prefix forwarding/state witnesses; original heavy349-line suffix is pinned unchanged but not executed in helper fixture. Full contracts and candidate assembly/performance admission remain root work.','CPU':3,'runs':[],'traps':[]}
compiler=h.parent/'compiler-native-fields-58/goose';receipt['compiler_sha256']=sha(compiler)
for engine in ['wasmtime','v8']:
 report=h/('parent-'+engine)/'report.json';r=json.loads(report.read_text());assert r['summary']=={'selected':24,'passed':24,'failed':0};assert r['input_sha256']==r['input_sha256_after']
 receipt['runs'].append({'engine':engine,'summary':r['summary'],'stable_inputs':True,'report_sha256':sha(report)})
 for row in r['results']:
  if '/bounds/'in row['case']:
   c=r['commands'][row['run_command']];assert c['exit_code']==1 and 'out of bounds'in c['stderr'];receipt['traps'].append({'engine':engine,'case':row['case'],'level':row['level'],'exit_code':c['exit_code'],'stderr':c['stderr']})
asm=(h/'a16-life-eval.disassembly.txt').read_text();assert '<g_fn120059>:'in asm and 'sub    $0x968,%rsp'in asm
receipt['parent_assembly']={'compiler':'compiler-native-fields-58 A16','compiler_sha256':sha(compiler),'C_sha256':sha(h.parent/'compiler-native-fields-58/compiler.c'),'lifetime_source_sha256':sha(h.parent/'compiler-native-fields-58/selfhost/checker_lifetimes.goose'),'function':'g_fn120059','address':'0x11a510','stack_local_bytes':2408,'saved_registers':6,'entry_observation':'Unconditional prologue allocates2408 bytes and saves6 registers before node<0 test, then TLS/region checks and zeroing. No claim yet about candidate Clang inlining or stack savings.','disassembly_sha256':sha(h/'a16-life-eval.disassembly.txt')}
assert receipt['parent_assembly']['lifetime_source_sha256']==ids['baseline_sha256']
receipt['semantic_proof']=[
'No-node check still precedes p.nodes access; positive IDs still use checked array access.',
'Wrapper keeps exact original N_NAME predicate, cell/live-ref/contents reads, life_holds filtering and life_construct_read order; function/type/builtin names still fall through.',
'N_STRING still calls life_single root0 and sets place/refs; all eight prior no-effect kinds keep exact default typed return.',
'Heavy suffix receives same p,l,node,destination,selected_result and checked const Node borrow, already live across all original suffix paths. No new mutation or alias assumption.',
'Heavy out starts at same LifeValue type_id with unchanged defaults. Prefix allocation of its dead heavy-path out is semantically unobservable, but may be costly if backend retains it.',
'Every recursive suffix call still calls wrapper, and both declarations remain recursive; no state cache, inference bypass, node whitelist extension or analysis removal.',
'Extra helper call/parameter passing, duplicate stack/resource check and return copies may offset frame savings. Root must inspect candidate wrapper+body assembly before timing admission.'
]
(h/'delivery.json').write_text(json.dumps(receipt,indent=2)+'\n')
(h/'sealed.json').write_text(json.dumps({p.name:sha(p)for p in sorted(h.iterdir())if p.is_file()and p.name!='sealed.json'},indent=2)+'\n')
print('sealed48 observations with32 checked bounds traps; no product changes after source review')
