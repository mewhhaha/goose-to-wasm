from pathlib import Path
import os,subprocess,json,struct,collections,bisect
root=Path.cwd();out=root/'build/completion-runs/compiler-sampling-a10-58';compiler=root/'build/completion-runs/compiler-plain-58/goose';env=os.environ.copy();env['LD_PRELOAD']=str(out/'sample.so');rows=[];os.sched_setaffinity(0,{7})
for name in ['functions','mandelbrot']:
 env['COMPILER_SAMPLE_PREFIX']=str(out/('sample2-'+name))
 source=root/'examples'/f'{name}.goose'
 if name=='mandelbrot':source=root/'bench/langbench/mandelbrot.goose'
 for i in range(80):
  cmd=[str(compiler),str(source),'--stdlib',str(root/'stdlib'),'--target','wasm-direct','-O2','-o',str(out/'program.wasm')];p=subprocess.run(cmd,env=env,capture_output=True,text=True);assert not p.returncode,p.stderr
 symbols=[]
 for line in subprocess.check_output(['nm','-n','-S',str(compiler)],text=True).splitlines():
  parts=line.split()
  if len(parts)==4 and parts[2] in ['t','T']:symbols.append((int(parts[0],16),int(parts[1],16),parts[3]))
 starts=[x[0] for x in symbols];counter=collections.Counter();other=0;unknown=0
 for p in out.glob('sample2-'+name+'.*.bin'):
  data=p.read_bytes();base,end,n,external=struct.unpack('<4Q',data[:32]);assert len(data)==32+n*8
  other+=external
  for value in struct.unpack('<'+'Q'*n,data[32:]):
   i=bisect.bisect_right(starts,value)-1
   if i>=0 and value<symbols[i][0]+symbols[i][1]:counter[symbols[i][2]]+=1
   else:unknown+=1
 record=dict(workload=name,scope='Diagnostic instruction-pointer sampling of uninstrumented A10 host; 80 compiler processes, 1ms ITIMER_PROF, LD_PRELOAD only captures RIPs and writes at _Exit. No timings are performance claims. External-library samples separate; no stack attribution.',samples=sum(counter.values()),external=other,unknown=unknown,top=counter.most_common(25));rows.append(record);print(json.dumps(record),flush=True)
(out/'report.json').write_text(json.dumps(rows,indent=2)+'\n')
