from pathlib import Path
import re,difflib,hashlib,json
root=Path(__file__).resolve().parent;base=root.parent/'compiler-plain-58/selfhost/checker_lifetimes.goose'
old=base.read_text();source=old
# Only phase-aware functions receive cached queries; pure helpers remain unchanged.
functions=list(re.finditer(r'^(?:(?:inline|recursive) )?fn (\w+)\(([^\n]*)',source,re.M))
edits=[]
for i in range(len(functions)-1,-1,-1):
 m=functions[i]
 if 'l: Lifetimes&'not in m.group(2):continue
 end=len(source)
 if i+1<len(functions):end=functions[i+1].start()
 part=source[m.start():end];changed=part;calls={}
 for pure,cached in [('life_holds','life_cached_holds'),('life_relative_storage','life_cached_relative_storage')]:
  changed,count=re.subn(r'\b'+pure+r'\(p, ',cached+'(p, l, ',changed)
  if count:calls[pure]=count
 if calls:edits.append({'function':m.group(1),'calls':calls})
 source=source[:m.start()]+changed+source[end:]
source=source.replace('size_classes','type_facts')
source=source.replace('if !l.types_frozen || ty >= l.type_facts.len { return life_size_class(p, ty); }', 'if !l.types_frozen || ty >= l.type_facts.len || ty >= p.types.len { return life_size_class(p, ty); }', 1)
source=source.replace('var type_facts: i64[>..] = []; type_facts.resize(p.types.len, -1);','var type_facts: i64[>..] = []; type_facts.resize(p.types.len, 0);')
source=source.replace('while type_facts.len < p.types.len { type_facts.push(-1); }','while type_facts.len < p.types.len { type_facts.push(0); }')
source=source.replace('''    let cached = l.type_facts[ty];
    if cached >= 0 { return cached; }
    let result = life_size_class(p, ty); l.type_facts[ty] = result;''','''    let cached = l.type_facts[ty] & 3;
    if cached != 0 { return cached - 1; }
    let result = life_size_class(p, ty); l.type_facts[ty] |= result + 1;''',1)
wrappers='''// Two bits per completed fact: size is class+1; booleans are 1=false, 2=true.
// Zero means unknown. Slots: size 0, holds 2, relative 4, pooled relative 6.
inline fn life_cached_holds(p: Program&, l: Lifetimes&, ty: i64) -> bool {
    if ty < 0 { return false; }
    let t: const Type& = p.types[ty];
    if t.kind == TY_SLICE { return true; }
    if t.kind == TY_REF { return t.length_storage < 0; }
    if t.kind != TY_ARRAY && t.kind != TY_STRUCT && t.kind != TY_ENUM && t.kind != TY_TUPLE { return false; }
    if !l.types_frozen || ty >= l.type_facts.len { return life_holds_walk(p, ty); }
    let cached = (l.type_facts[ty] >> 2) & 3;
    if cached != 0 { return cached == 2; }
    let result = life_holds_walk(p, ty); var code = 1; if result { code = 2; }
    l.type_facts[ty] |= code << 2; return result;
}
inline fn life_cached_relative_storage(p: Program&, l: Lifetimes&, ty: i64, include_pool: bool = false) -> bool {
    if ty < 0 { return false; }
    let t: const Type& = p.types[ty];
    if t.kind == TY_REF { return t.length_storage >= 0 && (t.pool < 0 || include_pool); }
    if t.kind != TY_ARRAY && t.kind != TY_STRUCT && t.kind != TY_ENUM && t.kind != TY_TUPLE { return false; }
    if !l.types_frozen || ty >= l.type_facts.len { return life_relative_storage_walk(p, ty, include_pool); }
    var shift = 4; if include_pool { shift = 6; }
    let cached = (l.type_facts[ty] >> shift) & 3;
    if cached != 0 { return cached == 2; }
    let result = life_relative_storage_walk(p, ty, include_pool); var code = 1; if result { code = 2; }
    l.type_facts[ty] |= code << shift; return result;
}
'''
source=source.replace('inline fn life_cached_size_class(',wrappers+'inline fn life_cached_size_class(',1)
def function(text,name):
 start=re.search(r'^(?:(?:inline|recursive) )?fn '+name+r'\(',text,re.M).start();return text[start:text.index('\n}',start)+3]
for name in ['life_holds','life_holds_walk','life_relative_storage','life_relative_storage_walk','life_size_class']:
 assert function(old,name)==function(source,name)
assert 'type_facts.resize(p.types.len, 0)'in source
assert source.count('l.types_frozen = true;')==1
assert source.count('l.types_frozen = false;')==2
(root/'checker_lifetimes.goose').write_text(source)
(root/'candidate.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),source.splitlines(True),fromfile='a/selfhost/checker_lifetimes.goose',tofile='b/selfhost/checker_lifetimes.goose')))
(root/'identities.json').write_text(json.dumps({'baseline':str(base),'baseline_sha256':hashlib.sha256(old.encode()).hexdigest(),'candidate_sha256':hashlib.sha256(source.encode()).hexdigest(),'pure_helpers_unchanged':True,'callsite_edits':list(reversed(edits))},indent=2)+'\n')
