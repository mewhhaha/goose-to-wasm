from pathlib import Path
import re,json,hashlib,itertools
root=Path(__file__).resolve().parent;base=root.parent/'compiler-plain-58/selfhost'
source=(root/'checker_lifetimes.goose').read_text();model=(base/'model.goose').read_text()
def function(name):
 start=re.search(r'^(?:inline |recursive )?fn '+name+r'\(',source,re.M).start();return source[start:source.index('\n}',start)+3]
constants='\n'.join(l for l in model.splitlines()if re.match(r'let (TY_|A_|F_VARIABLE_MODE)',l))
type_def=re.search(r'struct Type \{.*?\n\}',model,re.S).group()
header='import std;\n'+constants+'\n'+type_def+'''
struct Node { type_id: i64 = -1, next: i64 = -1 }
struct Program { types: Type[>..]&, nodes: Node[>..]& }
struct Lifetimes { type_facts: i64[>..]&, types_frozen: bool = false }
'''
for name in ['life_holds','life_holds_walk','life_relative_storage','life_relative_storage_walk','life_size_class','life_cached_holds','life_cached_relative_storage','life_cached_size_class']:header+=function(name)+'\n'
orders=[v for p in itertools.permutations(range(4))for v in p]
fixture=header+'''
fn main() -> i32 {
    var types: Type[>..] = [
        Type { kind: TY_INT }, Type { kind: TY_BOOL }, Type { kind: TY_FLOAT }, Type { kind: TY_VOID },
        Type { kind: TY_SLICE }, Type { kind: TY_REF },
        Type { kind: TY_REF, length_storage: 0 }, Type { kind: TY_REF, length_storage: 8, pool: 5 },
        Type { kind: TY_REF, length_storage: 1, pool: 0 },
        Type { kind: TY_ARRAY, element: 5 }, Type { kind: TY_ARRAY, element: 6 }, Type { kind: TY_ARRAY },
        Type { kind: TY_STRUCT, first: 0 }, Type { kind: TY_ENUM, first: 1 }, Type { kind: TY_TUPLE, first: 2 },
        Type { kind: TY_STRUCT, first: 3 }, Type { kind: TY_STRUCT, first: 5 },
        Type { kind: TY_REF, element: 4, length_storage: 0 }, Type { kind: TY_REF, element: 6 },
        Type { kind: TY_SLICE, element: 6 }, Type { kind: TY_UNKNOWN, storage: 1 },
        Type { kind: TY_FN, first: 1 }, Type { kind: TY_GENERIC }, Type { kind: TY_NAME },
        Type { kind: TY_ARRAY, element: 13 }, Type { kind: TY_TUPLE },
        Type { kind: TY_ARRAY, array_kind: A_GROW }, Type { kind: TY_ARRAY, element: 5, array_kind: A_VAR },
        Type { kind: TY_ARRAY, element: 4, array_kind: A_GROWSHRINK },
        Type { kind: TY_STRUCT, first: 7 }, Type { kind: TY_ARRAY, element: 14 },
        Type { kind: TY_REF, length_storage: 0, pool: 5 }, Type { kind: TY_STRUCT, first: 9 },
        Type { kind: TY_ARRAY, element: 14 }
    ];
    var nodes: Node[>..] = [
        Node { type_id: 4 }, Node { type_id: 6 }, Node { type_id: 7 },
        Node { type_id: 15, next: 4 }, Node { type_id: 5 },
        Node { type_id: 16, next: 6 }, Node { type_id: 6 },
        Node { type_id: 29, next: 8 }, Node { type_id: 0 }, Node { type_id: 31 }
    ];
    var facts: i64[>..] = []; facts.resize(types.len - 3, 0);
    var p = Program { types: types, nodes: nodes };
    var l = Lifetimes { type_facts: facts };
    while facts.len < p.types.len - 1 { facts.push(0); }
    let holds: bool[34] = [false,false,false,false,true,true,false,false,false,true,false,false,true,false,false,true,false,false,true,true,false,false,false,false,false,false,false,true,true,false,false,false,false,false];
    let relative: bool[34] = [false,false,false,false,false,false,true,false,false,false,true,false,false,true,false,false,true,true,false,false,false,false,false,false,true,false,false,false,false,false,false,false,false,false];
    let pooled: bool[34] = [false,false,false,false,false,false,true,true,true,false,true,false,false,true,true,false,true,true,false,false,false,false,false,false,true,false,false,false,false,false,true,true,true,true];
    let size: i64[34] = [0,0,0,0,0,0,1,0,0,0,1,0,0,0,0,0,1,1,0,0,1,0,0,0,0,0,2,1,2,0,0,1,1,0];
    let graph: bool[34] = [false,false,false,false,false,false,false,false,false,true,true,true,true,true,true,true,true,false,false,false,false,false,false,false,true,true,true,true,true,true,true,false,true,true];
    let orders: i64[96] = ORDERS;
    for order in 0..24 {
        l.types_frozen = false;
        for ty in 0..facts.len { facts[ty] = 0; }
        if life_cached_holds(p, l, 15) != holds[15] || facts[15] != 0 { return 1; }
        if life_cached_relative_storage(p, l, 14, true) != pooled[14] || facts[14] != 0 { return 2; }
        if life_cached_size_class(p, l, 26) != size[26] || facts[26] != 0 { return 3; }
        l.types_frozen = true;
        for ty in 0..34 {
            for step in 0..4 {
                let query = orders[order * 4 + step]; var before = 0;
                if ty < facts.len { before = facts[ty]; }
                var expected = size[ty] + 1;
                if query == 0 {
                    if life_size_class(p, ty) != size[ty] || life_cached_size_class(p, l, ty) != size[ty] || life_cached_size_class(p, l, ty) != size[ty] { return 4; }
                } else {
                    var answer = holds[ty];
                    if query == 1 {
                        if life_holds(p, ty) != answer || life_cached_holds(p, l, ty) != answer || life_cached_holds(p, l, ty) != answer { return 5; }
                    } else {
                        var pool = false; answer = relative[ty]; if query == 3 { pool = true; answer = pooled[ty]; }
                        if life_relative_storage(p, ty, pool) != answer || life_cached_relative_storage(p, l, ty, pool) != answer || life_cached_relative_storage(p, l, ty, pool) != answer { return 6; }
                    }
                    expected = 1; if answer { expected = 2; }
                }
                if ty < facts.len {
                    let shift = query * 2; let mask = 3 << shift; let after = facts[ty];
                    if (after & ~mask) != (before & ~mask) { return 7; }
                    if query == 0 || graph[ty] { if ((after >> shift) & 3) != expected { return 8; } }
                    else if after != before { return 9; }
                }
            }
        }
        if life_cached_holds(p, l, -1) || life_cached_relative_storage(p, l, -1) || life_cached_relative_storage(p, l, -1, true) || life_cached_size_class(p, l, -1) != 0 { return 10; }
        if facts.len != 33 { return 11; }
        if facts[29] != 85 || facts[26] != 87 || facts[15] != 89 || facts[32] != 150 || facts[16] != 166 { return 14; }
    }
    l.types_frozen = false;
    let old = facts[29];
    p.types[29].kind = TY_ARRAY; p.types[29].element = 6; p.types[29].array_kind = A_GROW;
    if life_cached_size_class(p, l, 29) != 2 || life_cached_holds(p, l, 29) || !life_cached_relative_storage(p, l, 29) || !life_cached_relative_storage(p, l, 29, true) { return 12; }
    if facts[29] != old { return 13; }
    print("packed facts: 34 hand-expected graphs x 24 query orders, repeated reads, independent bits, phase and bounds fallbacks passed");
    return 0;
}
'''
fixture=fixture.replace('ORDERS','['+', '.join(map(str,orders))+']')
(root/'packed-facts-fixture.goose').write_text(fixture)
traps=[]
for query in ['holds','relative','pooled','size']:
 source=header+'''
fn main() -> i32 {
    var types: Type[>..] = [Type { kind: TY_INT }]; var nodes: Node[>..] = [];
    var facts: i64[>..] = [255, 255];
    var p = Program { types: types, nodes: nodes }; var l = Lifetimes { type_facts: facts, types_frozen: true };
    CALL;
    print("unexpected invalid positive type accepted"); return 0;
}
'''
 call={'holds':'life_cached_holds(p, l, 1)','relative':'life_cached_relative_storage(p, l, 1)','pooled':'life_cached_relative_storage(p, l, 1, true)','size':'life_cached_size_class(p, l, 1)'}[query]
 source=source.replace('CALL',call);name='invalid-type-'+query+'.goose';(root/name).write_text(source)
 traps.append({'source':name,'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'compile_exit':0,'runtime_must_trap':True,'expected_stdout':''})
proof={'status':'frozen-before-execution-unrun','source_sha256':hashlib.sha256(fixture.encode()).hexdigest(),'expected_runtime_exit':0,'expected_stdout':'packed facts: 34 hand-expected graphs x 24 query orders, repeated reads, independent bits, phase and bounds fallbacks passed\n','oracle':'Actual unchanged pure helpers plus independent hand-expected classification tables. All24 property evaluation permutations and lane independence are checked; two repeated cached reads each query. No C++ oracle.','graph_cases':34,'property_orders':24,'matrix':{'target':['native','wasm-direct'],'optimization':[0,2],'debug':[False,True]},'invalid_positive_type_guards':traps,'phase_contract':'Each test permutation clears words while thawed before refreeze; production creates fresh facts once and freezes once. Thawed metadata mutation must bypass prior facts without changing packed words.','limits':'Generated only. No compiler build or guard execution.'}
(root/'fixture-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
