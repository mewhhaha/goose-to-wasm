from pathlib import Path
import re,json,hashlib
root=Path(__file__).resolve().parent;base=root.parent/'compiler-plain-58/selfhost';candidate=root/'checker_lifetimes.goose'
def mask(t):
 return re.sub(r'//[^\n]*|/\*.*?\*/|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'',lambda m:re.sub(r'[^\n]',' ',m.group()),t,flags=re.S)
def parse(path):
 text=path.read_text();masked=mask(text);found={}
 for m in re.finditer(r'^(?:(?:inline|recursive|export|extern)\s+)*fn\s+(\w+)\s*(?:<[^>]+>)?\(',masked,re.M):
  opening=masked.find('{',m.end())
  if opening<0:continue
  depth=1;end=opening+1
  while depth:
   if masked[end]=='{':depth+=1
   if masked[end]=='}':depth-=1
   end+=1
  found[m.group(1)]={'path':str(path),'line':text.count('\n',0,m.start())+1,'source':text[m.start():end],'mask':masked[m.start():end]}
 return found
functions={}
for p in base.glob('*.goose'):
 if p.name!=candidate.name:functions.update(parse(p))
functions.update(parse(candidate));closure=set();work=['life_eval','life_function','life_error']
while work:
 name=work.pop()
 if name in closure:continue
 closure.add(name)
 for call in re.findall(r'(?<![\w.])(\w+)\s*\(',functions[name]['mask']):
  if call in functions and call not in closure:work.append(call)
writes=[];aliases=[];growth=[]
for name in sorted(closure):
 entry=functions[name]
 for offset,(line,masked)in enumerate(zip(entry['source'].splitlines(),entry['mask'].splitlines())):
  if not re.search(r'p\.(?:nodes|types|symbols)\b',masked):continue
  item={'function':name,'line':entry['line']+offset,'source':line.strip()}
  for access in re.finditer(r'p\.(?:nodes|types|symbols)\b',masked):
   at=access.end()
   while at<len(masked):
    while at<len(masked)and masked[at].isspace():at+=1
    if at<len(masked)and masked[at]=='[':
     depth=1;at+=1
     while at<len(masked)and depth:
      if masked[at]=='[':depth+=1
      if masked[at]==']':depth-=1
      at+=1
     continue
    field=re.match(r'\.\w+',masked[at:])
    if field:at+=field.end();continue
    break
   if re.match(r'(?:[+*/|&^%-]?=(?!=)|(?:<<|>>)=|\+\+|--)',masked[at:]):writes.append(item)
  if re.search(r'(?:var|let)\s+\w+\s*:\s*(?!const)(?:Node|Type|Symbol)\s*&\s*=\s*p\.',masked):aliases.append(item)
  if re.search(r'p\.(?:nodes|types|symbols)\.(?:push|pop|append|resize|clear|remove|insert)\s*\(',masked):growth.append(item)
assert not writes and not aliases and not growth,(writes,aliases,growth)
original=parse(base/candidate.name)
for name in ['life_holds','life_holds_walk','life_relative_storage','life_relative_storage_walk','life_size_class']:
 assert functions[name]['source']==original[name]['source']
phase=functions['check_lifetimes']['source'];old_phase=original['check_lifetimes']['source']
assert phase.replace('type_facts','size_classes').replace('size_classes.resize(p.types.len, 0)','size_classes.resize(p.types.len, -1)').replace('size_classes.push(0)','size_classes.push(-1)')==old_phase
assert candidate.read_text().count('l.types_frozen = true;')==1
assert candidate.read_text().count('l.types_frozen = false;')==2
result={'status':'source-approved-guards-unrun','candidate_sha256':hashlib.sha256(candidate.read_bytes()).hexdigest(),'patch_sha256':hashlib.sha256((root/'candidate.patch').read_bytes()).hexdigest(),'baseline_sha256':hashlib.sha256((base/candidate.name).read_bytes()).hexdigest(),'closure_count':len(closure),'closure':sorted(closure),'arena_field_writes':writes,'mutable_arena_aliases':aliases,'arena_growth_or_shrink':growth,'pure_helpers_byte_identical':True,'phase_boundaries_byte_identical_after_storage_rename_and_unknown_sentinel_normalization':True,'lanes':{'size':{'shift':0,'unknown':0,'encoding':'class + 1, class in0..2'},'holds':{'shift':2,'unknown':0,'false':1,'true':2},'relative_without_pool':{'shift':4,'unknown':0,'false':1,'true':2},'relative_with_pool':{'shift':6,'unknown':0,'false':1,'true':2}},'invariants':['Fresh zero buffer allocated before Lifetimes borrow; standalone synthesis may add types/nodes while facts disabled; grow-only pushes complete capacity before the single freeze.','Holds/relative leaf answers remain exact direct predicates; only ARRAY/STRUCT/ENUM/TUPLE use completed graph result trits.','Cache key is stable type ID plus property/pool mode. Relevant metadata Type.kind/element/first/length_storage/pool and Node.type_id/next remains immutable during discovery/live evaluation, including diagnostics/error paths.','Queries outside cache bounds or outside freeze call original pure walkers; negative IDs return original leaf result; invalid positive IDs retain checked original arena access.','Each miss writes only its unknown2-bit lane with OR into latest packed word after a pure walk; other lanes remain intact, no partial traversal result is cached.','No mutable cells/frames/roots/effects/holds/flow state enters facts. No second production freeze; flag clears on failure return and before provenance/named-result writes.'],'tradeoffs':['No extra array or capacity: same existing i64/type storage (8bytes/type plus spare capacity).','Packed reads add shifts/masks on graph queries and size cache queries. Benefit depends on repeated graph queries while frozen; diagnostics show substantial total graph call volume but do not measure cache hits or frozen-phase fraction.','New inline cached wrappers each have fallback+miss graph callsites, which may increase own-compiler inlining/C size and host build duration; record both alongside matched runtime comparisons.'],'count_evidence':'../lifetime-property-counts-58/property-counts.json','independent_review':'compiler_ceiling_review approved exact patch e4fa4b13 / source938da391: direct leaves, disjoint completed facts, latest-word OR, unchanged capacity/freeze, bounds fallback and17 existing l-bearing callsites.','limits':'No compiler/guard build or execution. Existing helper fixture frozen independently; full self-bootstrap/contracts and performance admission remain with root.'}
(root/'audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k]for k in ['closure_count','arena_field_writes','mutable_arena_aliases','arena_growth_or_shrink','pure_helpers_byte_identical']}))
