from pathlib import Path
import argparse,hashlib,json,os,re,subprocess
R=Path('/home/jacobt/src/goose-to-wasm');H=Path(__file__).resolve().parent;a=argparse.ArgumentParser();a.add_argument('--runtime-report',required=True);a.add_argument('--output-dir',required=True);a.add_argument('--candidate',action='store_true');a=a.parse_args();O=Path(a.output_dir).resolve();O.mkdir();os.sched_setaffinity(0,{5});sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();proof=json.loads(Path(a.runtime_report).read_text());assert proof['status']=='passed';rows=[];seen=set();commands=[]
def body(text,identity):
 m=re.search(r'\bg_fn'+str(identity)+r'\([^;]*?\)\s*\{',text);assert m,identity
 at=m.end();start=at;depth=1
 while depth:
  if text.startswith('//',at):at=text.index('\n',at);continue
  if text.startswith('/*',at):at=text.index('*/',at+2)+2;continue
  ch=text[at]
  if ch in ['"',"'"]:
   quote=ch;at+=1
   while text[at]!=quote:
    if text[at]=='\\':at+=1
    at+=1
  elif ch=='{':depth+=1
  elif ch=='}':depth-=1
  at+=1
 return text[start:at-1]
def symbols(ir,fn,name):return [s for s in ir['symbols'] if s['owner']==fn and s['name_token']>=0 and ir['tokens'][s['name_token']]['text']==name]
def zero_field(b,ir,fn,root,field_type):
 roots=symbols(ir,fn,root)
 if not roots:roots=[s for s in ir['symbols'] if s['name_token']>=0 and ir['tokens'][s['name_token']]['text']==root]
 assert len(roots)==1,(root,roots)
 bases=re.findall(r'g_v(\d+)=g_ref\(&g_s'+str(roots[0]['id'])+r'\);',b)
 for base in bases:
  pattern=r'g_v(\d+)=g_offset\(g_v'+base+r',0\);'
  if a.candidate:pattern=r'g_v(\d+)=g_v'+base+r';'
  for ref in re.findall(pattern,b):
   if 'g_load_'+str(field_type)+'(g_v'+ref+');' in b:return True
 return False
for result in proof['results']:
 cmd=proof['commands'][result['compile_command']]['command']
 if cmd[cmd.index('--target')+1]!='native':continue
 artifact=Path(cmd[cmd.index('-o')+1])
 if str(artifact) in seen:continue
 seen.add(str(artifact));source=Path(cmd[1]);text=artifact.read_text();debug='--debug' in cmd;ircommand=[cmd[0],str(source),'--target','native','--stdlib',str(R/'stdlib'),'-O'+str(result['level']),'--dump-ir']
 if debug:ircommand.append('--debug')
 p=subprocess.run(ircommand,cwd=R,text=True,capture_output=True,timeout=60);assert p.returncode==0,p.stderr;ir=json.loads(p.stdout);(O/('ir-'+str(len(seen))+'.json')).write_text(p.stdout);commands.append(ircommand);functions={}
 for n in ir['nodes']:
  if n['kind']==3 and ir['tokens'][n['token']]['source']==0:functions[ir['tokens'][n['token']]['text']]=n['id']
 positive={'local_read':1,'by_value':1,'global_read':4,'nested':1,'local_address':1}
 names=list(positive)+['by_reference','effect_once','indexed','owned','relative','image','large','zero_width']
 if source.stem!='values':names=['main']
 for name in names:
  b=body(text,functions[name]);fast=re.findall(r'g_v\d+=g_ref\(g_address\(g_v\d+\)\+(\d+)\);',b);checks={}
  if name in positive:
   if a.candidate:checks['value_root_pointer_address']=str(positive[name]) in fast
   else:checks['baseline_integer_address']=not fast and bool(re.search(r'g_offset\(g_v\d+,'+str(positive[name])+r'\)',b))
  else:checks['no_broad_reference_fastpath']=not fast
  if name in ['by_reference','effect_once','indexed','owned','relative','large']:checks['generic_offset_retained']='g_offset(' in b
  if name=='nested':checks['nested_member_fallback_retained']=bool(re.search(r'g_offset\(g_v\d+,1\)',b))
  if name=='image':checks['image_lowering_retained']='g_image_' in b
  if name=='indexed':checks['bounds_helper_retained']='g_element_at(' in b
  if name=='effect_once':checks['base_evaluated_once']=len(re.findall(r'\bg_fn'+str(functions['fetch'])+r'\(',b))==1
  if name=='local_read':checks['zero_offset_base_preserved']=zero_field(b,ir,functions[name],'value',1)
  if name=='global_read':checks['zero_offset_base_preserved']=zero_field(b,ir,functions[name],'global',6)
  if name=='zero_width':
   z=[t['id'] for t in ir['types'] if t['kind']==8 and t['declaration']>=0 and ir['tokens'][ir['nodes'][t['declaration']]['token']]['text']=='Zero'];assert len(z)==1;refs=re.findall(r'g_v(\d+)=g_offset\(g_v\d+,0\);',b);checks['zero_width_fallback_retained']=any('g_load_'+str(z[0])+'(g_v'+ref+');' in b for ref in refs);checks['nonzero_width_first_field_base_preserved']=zero_field(b,ir,functions[name],'value',5)
  if name=='local_address':
   refs=re.findall(r'g_v(\d+)=(?:g_ref\(g_address\(g_v\d+\)\+1\)|g_offset\(g_v\d+,1\));',b);checks['address_only_no_field_load']=bool(refs) and all('g_load_5(g_v'+ref+');' not in b for ref in refs)
  if name=='main':
   cast=symbols(ir,functions[name],'cast');assert len(cast)==1;ty=ir['types'][cast[0]['type_id']];checks['cast_binding_is_reference']=ty['kind']==7;wide=ty['element'];checks['no_implicit_aggregate_copy']='g_load_'+str(wide)+'(' not in b;offset=64
   if source.stem=='null-first':offset=0
   if source.stem=='null-last':offset=8
   checks['unsafe_or_null_address_keeps_integer_offset']=bool(re.search(r'g_offset\(g_v\d+,'+str(offset)+r'\)',b))
   reference_name='address'
   if source.stem=='owned-reference-cast-typed':reference_name='outside'
   address=symbols(ir,functions[name],reference_name);checks['address_binding_is_reference']=len(address)==1 and ir['types'][address[0]['type_id']]['kind']==7
   refs=re.findall(r'g_v(\d+)=g_offset\(g_v\d+,'+str(offset)+r'\);',b);checks['address_only_no_scalar_read']=bool(refs) and all('g_load_5(g_v'+ref+');' not in b for ref in refs)
  rows.append(dict(source=str(source.relative_to(R)),function=name,optimization=result['level'],debug=debug,checks=checks,passed=all(checks.values()),C_sha256=sha(artifact)))
status='failed'
if rows and all(r['passed'] for r in rows):status='passed'
D=dict(status=status,candidate=a.candidate,checks=len(rows),runtime_report_sha256=sha(Path(a.runtime_report)),rows=rows,commands=commands);(O/'report.json').write_text(json.dumps(D,indent=2)+'\n');print(status,len(rows));assert status=='passed'
