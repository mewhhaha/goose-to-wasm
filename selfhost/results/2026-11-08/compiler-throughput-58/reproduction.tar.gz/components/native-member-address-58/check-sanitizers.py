from pathlib import Path
import argparse,hashlib,json,os,re,subprocess
R=Path('/home/jacobt/src/goose-to-wasm');H=Path(__file__).resolve().parent;a=argparse.ArgumentParser();a.add_argument('--runtime-report',required=True);a.add_argument('--output-dir',required=True);a=a.parse_args();O=Path(a.output_dir).resolve();O.mkdir();os.sched_setaffinity(0,{5});sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();proof=json.loads(Path(a.runtime_report).read_text());assert proof['status']=='passed';M=json.loads((H/'guards/cases.json').read_text());cases={c['id']:c for c in M['cases']};rows=[];seen=set()
for r in proof['results']:
 c=cases[r['case']]
 if c['target']!='native':continue
 if (r['level'],c['debug']) not in [(0,False),(2,True)]:continue
 command=proof['commands'][r['compile_command']]['command'];source=Path(command[command.index('-o')+1])
 if str(source) in seen:continue
 seen.add(str(source));binary=O/('case-'+str(len(rows)));compile=['/usr/bin/clang-23','-std=gnu11','-O1','-g','-fsanitize=address,undefined,pointer-overflow','-fno-sanitize-recover=all','-fno-omit-frame-pointer',str(source),'-lm','-ldl','-pthread','-o',str(binary)];p=subprocess.run(compile,cwd=R,text=True,capture_output=True,timeout=60);assert p.returncode==0,p.stderr;p=subprocess.run([str(binary)],cwd=R,text=True,capture_output=True,timeout=60);E=c['expect'];exit_equal=p.returncode==E['exit']
 if E['exit']=='nonzero':exit_equal=p.returncode!=0
 passed=exit_equal and p.stdout==E['stdout'] and all(s in p.stderr for s in E.get('stderr_contains',[])) and not re.search(r'(ERROR: AddressSanitizer|SUMMARY: (AddressSanitizer|UndefinedBehaviorSanitizer)|[^\n]+:\d+:\d+: runtime error:)',p.stderr)
 if E['exit']==0:passed=passed and p.stderr==''
 rows.append(dict(case=c['id'],level=r['level'],debug=c['debug'],compile=compile,C_sha256=sha(source),exit=p.returncode,stdout=p.stdout,stderr=p.stderr,passed=passed));assert passed,rows[-1];print(c['id'],r['level'],'passed',flush=True)
assert len(rows)==8,len(rows);D=dict(status='passed',profiles=len(rows),cpu=5,clang_sha256=sha(Path('/usr/bin/clang-23')),runtime_report_sha256=sha(Path(a.runtime_report)),manifest_sha256=sha(H/'guards/cases.json'),rows=rows,limitation='Address-only out-of-object arithmetic may evade runtime sanitizers. The independent structural guard also requires integer g_offset fallback and no aggregate/scalar load on the typed unsafe cast.');(O/'report.json').write_text(json.dumps(D,indent=2)+'\n')
