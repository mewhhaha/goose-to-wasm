from pathlib import Path
import hashlib,json,subprocess,tarfile,os,stat,time
root=Path.cwd();work=root/'build/completion-runs';out=work/'artifact-archives-58'
names=['50','51','52','53','54-v3','54-v4','55','56']
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
for name in names:
 base=work/('c-only-conformance-'+name+'-qualified');paths=[];trees=sorted(base.glob('shard-*/artifacts'))
 for tree in trees:
  for p in sorted(tree.rglob('*')):
   if p.is_file():
    assert not p.is_symlink();paths.append(p)
 manifest={str(p.relative_to(work)):{'sha256':sha(p),'bytes':p.stat().st_size,'mode':stat.S_IMODE(p.stat().st_mode)} for p in paths}
 assert manifest
 receipt=out/(name+'.manifest.json');receipt.write_text(json.dumps(manifest,sort_keys=True)+'\n')
 archive=out/(name+'.tar.zst');verify={}
 with archive.open('wb') as f:
  proc=subprocess.Popen(['zstd','-q','-T2','-3','-c'],stdin=subprocess.PIPE,stdout=f)
  with tarfile.open(fileobj=proc.stdin,mode='w|') as t:
   for p in paths:t.add(p,arcname=str(p.relative_to(work)),recursive=False)
  proc.stdin.close();assert proc.wait()==0
 proc=subprocess.Popen(['zstd','-q','-d','-c',str(archive)],stdout=subprocess.PIPE)
 with tarfile.open(fileobj=proc.stdout,mode='r|') as t:
  for m in t:
   assert m.isfile();f=t.extractfile(m);verify[m.name]={'sha256':hashlib.file_digest(f,'sha256').hexdigest(),'bytes':m.size,'mode':m.mode}
 proc.stdout.close();assert proc.wait()==0;assert verify==manifest
 seal={'status':'verified-before-removal','archive':str(archive),'archive_sha256':sha(archive),'manifest_sha256':sha(receipt),'files':len(manifest),'original_bytes':sum(r['bytes'] for r in manifest.values()),'scope':'Regenerable generated conformance artifacts only; reports, upstream fixtures, source snapshots and compiler binaries retained outside archive.'}
 (out/(name+'.json')).write_text(json.dumps(seal,indent=2)+'\n')
 for p in paths:assert sha(p)==manifest[str(p.relative_to(work))]['sha256'];p.unlink()
 for tree in trees:
  for parent,dirs,files in os.walk(tree,topdown=False):
   assert not files
   Path(parent).rmdir()
 subprocess.run(['btrfs','filesystem','sync',str(out)],check=True)
 seal['status']='archived-and-verified';(out/(name+'.json')).write_text(json.dumps(seal,indent=2)+'\n');print(name,len(manifest),'archived and verified',flush=True)
