from pathlib import Path
import hashlib,json,os,stat,subprocess
root=Path.cwd();out=root/'build/completion-runs/dedup-artifacts-58';plan=json.load(open(out/'plan.json'))['rows'];selected=[r for r in plan if not r['mode']&0o111]
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
completed=0
for start in range(0,len(selected),500):
 batch=[]
 for row in selected[start:start+500]:
  p=Path(row['path']);canonical=Path(row['canonical']);assert canonical.is_file() and sha(canonical)==row['sha256']
  if p.exists():
   if p.stat().st_ino==canonical.stat().st_ino:continue
   assert sha(p)==row['sha256'];p.unlink()
  batch.append(row)
 # The canonical file retains every byte. Reclaim duplicate inodes before
 # creating hard links because an atomic overwrite needs extra Btrfs metadata.
 subprocess.run(['btrfs','filesystem','sync',str(out)],check=True)
 for row in batch:
  p=Path(row['path']);canonical=Path(row['canonical'])
  for attempt in range(3):
   try:os.link(canonical,p);break
   except OSError as e:
    if e.errno!=28 or attempt==2:raise
    subprocess.run(['btrfs','filesystem','sync',str(out)],check=True)
  assert sha(p)==row['sha256'] and stat.S_IMODE(p.stat().st_mode)==row['mode'];completed+=1
 subprocess.run(['btrfs','filesystem','sync',str(out)],check=True);print('restored verified paths',completed,flush=True)
for row in selected:
 p=Path(row['path']);assert p.exists() and sha(p)==row['sha256'] and stat.S_IMODE(p.stat().st_mode)==row['mode']
(out/'report.json').write_text(json.dumps(dict(status='passed',paths_preserved=len(selected),contents_and_modes_verified=True,logical_bytes_shared=sum(r['bytes'] for r in selected),scope='Owned58 nonexecutable generated artifacts only. Every pathname restored and verified; reports/source/frozen compiler binaries untouched. Batch plan retains canonical bytes during inode reclamation.'),indent=2)+'\n')
print('all nonexecutable artifact paths preserved',len(selected),flush=True)
