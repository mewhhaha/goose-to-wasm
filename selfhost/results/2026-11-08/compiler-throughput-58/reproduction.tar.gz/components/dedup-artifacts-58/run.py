from pathlib import Path
from collections import defaultdict
import hashlib,json,os,stat,subprocess,time
root=Path.cwd();base=root/'build/completion-runs';out=base/'dedup-artifacts-58';bins=defaultdict(list)
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
for folder in base.iterdir():
 if not folder.is_dir() or folder.is_symlink() or '58' not in folder.name or folder==out:continue
 for directory,dirs,files in os.walk(folder,followlinks=False):
  dirs[:]=[d for d in dirs if not (Path(directory)/d).is_symlink() and d not in ['selfhost','native','upstream','stdlib']]
  relative=Path(directory).relative_to(folder)
  if not any(x in ['builds','artifacts','validations'] for x in relative.parts):continue
  for name in files:
   p=Path(directory)/name
   if p.is_symlink() or not (p.suffix in ['.c','.wasm','.o'] or name=='program'):continue
   s=p.stat()
   if not stat.S_ISREG(s.st_mode):continue
   bins[(s.st_size,stat.S_IMODE(s.st_mode))].append(p)
plan=[];seenfiles=0
for (size,mode),paths in bins.items():
 if len(paths)<2:continue
 seen={}
 for p in paths:
  digest=sha(p);seenfiles+=1
  if digest not in seen:seen[digest]=p;continue
  canonical=seen[digest]
  if canonical.stat().st_ino==p.stat().st_ino:continue
  plan.append(dict(path=str(p),canonical=str(canonical),sha256=digest,bytes=size,mode=mode))
(out/'plan.json').write_text(json.dumps(dict(scope='Only generated58 benchmark/conformance artifacts. All source snapshots/reports/frozen compiler executables excluded; preserve every path, content and permission mode. Physical savings measured separately by Btrfs.',rows=plan),indent=2)+'\n')
print('candidates',len(plan),'logical duplicate GiB',round(sum(r['bytes'] for r in plan)/2**30,3),flush=True)
completed=0
for row in plan:
 p=Path(row['path']);canonical=Path(row['canonical']);assert sha(p)==row['sha256'] and sha(canonical)==row['sha256']
 pending=p.with_name(p.name+'.dedup-58-'+str(os.getpid()))
 for attempt in range(3):
  try:
   os.link(canonical,pending);os.replace(pending,p);break
  except OSError as e:
   if pending.exists():pending.unlink()
   if e.errno!=28 or attempt==2:raise
   subprocess.run(['btrfs','filesystem','sync',str(base)],check=True)
 assert sha(p)==row['sha256'] and stat.S_IMODE(p.stat().st_mode)==row['mode'];completed+=1
 if completed%1500==0:subprocess.run(['btrfs','filesystem','sync',str(base)],check=True);print('linked',completed,flush=True)
subprocess.run(['btrfs','filesystem','sync',str(base)],check=True)
(out/'report.json').write_text(json.dumps(dict(status='passed',paths_preserved=completed,contents_and_modes_verified=True,logical_bytes_shared=sum(r['bytes'] for r in plan),scope='Owned58 generated artifacts only, no reports/source/compiler executable deletion.'),indent=2)+'\n');print('completed',completed,flush=True)
