# Dead-field review (A19 source snapshot)

Read-only source inventory; no compiler, build, or benchmark was run. These are subtraction candidates, not measured speedups.

## High-confidence dead chains

| Owner / field | Source evidence | Writes / reads | Proposed subtraction |
|---|---|---|---|
| `Symbol.scope_next` | `selfhost/model.goose:292` | Writes only: `checker.goose:251`, `optimizer.goose:219` (clone reset). No read in `selfhost/*.goose`. | Remove field and both writes. `Symbol.name_next` is separate and is traversed by `check_lookup_scope` at `checker.goose:269`; keep it. |
| `CheckScope.first_symbol` | `selfhost/checker.goose:10` | Write only: `checker.goose:253`; its value is only consumed at line 251 to populate dead `Symbol.scope_next`. No field read. | Remove field and write. The local variable named `first_symbol` around lines 4174–4219 is unrelated and active; retain it. |
| `CheckScope.lifetime` | `selfhost/checker.goose:10` | Assigned at `checker.goose:111`, copied at `checker.goose:4688`, exported into temporary vector at `checker.goose:6621`; no other semantic read. | Remove field, initialization/copy, and vector collection. |
| scope lifetime vector / `Lifetimes.lifetime` | vector declared/filled at `checker.goose:6620–6621`, passed at `6629`; `Lifetimes` member at `checker_lifetimes.goose:28`, parameter and initializer at `2345`, `2357`. No `.lifetime` use in `checker_lifetimes.goose`. | Entire data path is write/pass/store only. `parents`, `depths`, and `functions` remain separately used. | Remove vector, parameter, `Lifetimes` slice member, and initializer entry. |

`CheckScope.first_symbol` plus `Symbol.scope_next` form an orphaned scope-wide chain. Lookup uses the independent 16-bucket `name_heads` / `name_next` chain, which is read in `check_lookup_scope`.

## Approximate storage effect

Source declarations show 13 `i64` scalar fields in `Symbol`; dropping `scope_next` removes 8 bytes of scalar payload per symbol (~7.7% of those scalar fields). `CheckScope` has nine `i64` scalar fields plus `i64[16]` bucket heads; dropping `first_symbol` and `lifetime` removes 16 bytes per scope. Dropping the temporary `scope_lifetimes` vector removes another 8 bytes per scope during checker-to-lifetime-pass setup. The `Lifetimes` slice descriptor also disappears. These are source-level payload estimates; native padding, allocation effects, and throughput impact were not measured.

## Scope checked

Inspected core `Program`, `Node`, `Type`, and `Symbol` records plus checker scope/lifetime plumbing. For the reviewed `Node` candidates (`expansion_binding`, `named_results`, `coerced_type`, `captures`), `Type` candidates (`length_explicit`, `index_type`, `length_storage`), and `Symbol` candidates (`provenance`, `name_next`), found active reads; no deletion proposed. This is a focused inventory, not proof that all compiler state is minimal.

## Source pins

- `selfhost/model.goose`: `edfd66d9cb49dad7bc84288894a1e8434cb7441732a8e204054b755b2881fd3c`
- `selfhost/checker.goose`: `221e4fae17a87c8e4db2bca46e21f1b0db55c12110aff442c5de35f60ce965ba`
- `selfhost/checker_lifetimes.goose`: `fec16d3ea36c9362b029d211a178c0ddd313841c2950824eb4abff40259788b7`
- `selfhost/optimizer.goose`: `96019314823906364f95cd8c7f894db927d6008d195239765f73fab75de615d5`
