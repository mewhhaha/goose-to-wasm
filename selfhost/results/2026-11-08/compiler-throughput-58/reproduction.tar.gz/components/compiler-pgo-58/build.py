from pathlib import Path
import subprocess,time,json,hashlib,os
root=Path.cwd();r=root/'build/completion-runs';out=r/'compiler-pgo-58';source=r/'compiler-plain-58/compiler.c';records=[]
def run(cmd,name,env=None):
    start=time.monotonic();p=subprocess.run(list(map(str,cmd)),capture_output=True,text=True,env=env);(out/(name+'.stderr')).write_text(p.stderr);(out/(name+'.stdout')).write_text(p.stdout);record=dict(command=list(map(str,cmd)),exit_code=p.returncode,seconds=time.monotonic()-start);records.append(record);(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(name,record['exit_code'],round(record['seconds'],2),flush=True);assert not p.returncode,p.stderr
run(['taskset','-c','1','clang-23','-std=gnu11','-O2','-fprofile-generate='+str(out/'raw'),source,out/'profile-exit.c','-Wl,--wrap=_Exit','-lm','-ldl','-pthread','-o',out/'training-goose'],'instrumented-build')
for target in ['native','wasm-direct']:
    env=os.environ.copy();env['LLVM_PROFILE_FILE']=str(out/(target+'-%p.profraw'))
    run(['taskset','-c','1',out/'training-goose',r/'compiler-plain-58/selfhost/main.goose','--stdlib',root/'stdlib','--target',target,'-O2','-o',out/('training-'+target+'.out')],'train-'+target,env)
profiles=sorted(out.glob('*.profraw'));assert len(profiles)==2,profiles
run(['llvm-profdata-23','merge','-output='+str(out/'compiler.profdata'),*profiles],'merge')
run(['taskset','-c','1','clang-23','-std=gnu11','-O2','-fprofile-use='+str(out/'compiler.profdata'),source,'-lm','-ldl','-pthread','-o',out/'goose'],'optimized-build')
(out/'inputs.json').write_text(json.dumps(dict(source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),profile_sha256=hashlib.sha256((out/'compiler.profdata').read_bytes()).hexdigest(),training_source=str(r/'compiler-plain-58/selfhost/main.goose'),timed_inputs_used_in_training=False),indent=2)+'\n')
