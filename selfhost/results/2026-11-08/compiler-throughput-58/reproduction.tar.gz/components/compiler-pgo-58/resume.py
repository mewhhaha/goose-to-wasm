from pathlib import Path
import subprocess,time,json,hashlib,os
root=Path.cwd();r=root/'build/completion-runs';out=r/'compiler-pgo-58';source=r/'compiler-plain-58/compiler.c';records=[]
def run(cmd,name,env=None):
    start=time.monotonic();p=subprocess.run(list(map(str,cmd)),capture_output=True,text=True,env=env);(out/(name+'.stderr')).write_text(p.stderr);(out/(name+'.stdout')).write_text(p.stdout);record=dict(command=list(map(str,cmd)),exit_code=p.returncode,seconds=time.monotonic()-start);records.append(record);(out/'resume-commands.json').write_text(json.dumps(records,indent=2)+'\n');print(name,record['exit_code'],round(record['seconds'],2),flush=True);assert not p.returncode,p.stderr
assert hashlib.sha256((out/'training-native.out').read_bytes()).hexdigest()==hashlib.sha256(source.read_bytes()).hexdigest()
protocol=json.loads((out/'resume-protocol.json').read_text())
for item in protocol['valid_wasm_helpers']:
    env=os.environ.copy();env['LLVM_PROFILE_FILE']=str(out/(item['name']+'-%p.profraw'))
    run(['taskset','-c','1',out/'training-goose',item['source'],'--stdlib',root/'stdlib','--target','wasm-direct','-O2','--wasm-stats',out/(item['name']+'.stats.json'),'-o',out/(item['name']+'.wasm')],'train-'+item['name'],env)
    import wasmtime
    wasmtime.Module.validate(wasmtime.Engine(),(out/(item['name']+'.wasm')).read_bytes())
native=list(out.glob('native-*.profraw'));assert len(native)==1
args=['llvm-profdata','merge','-output='+str(out/'compiler.profdata'),'-weighted-input=1,'+str(native[0])]
for item in protocol['valid_wasm_helpers']:
    profiles=list(out.glob(item['name']+'-*.profraw'));assert len(profiles)==1
    args.append('-weighted-input='+str(item['weight'])+','+str(profiles[0]))
run(args,'merge-valid-profiles')
run(['taskset','-c','1','clang-23','-std=gnu11','-O2','-fprofile-use='+str(out/'compiler.profdata'),source,'-lm','-ldl','-pthread','-o',out/'goose'],'optimized-build')
(out/'inputs.json').write_text(json.dumps(dict(source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),profile_sha256=hashlib.sha256((out/'compiler.profdata').read_bytes()).hexdigest(),protocol=protocol,timed_inputs_used_in_training=False),indent=2)+'\n')
