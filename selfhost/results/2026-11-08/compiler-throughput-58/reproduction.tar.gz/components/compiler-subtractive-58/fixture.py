from pathlib import Path
import re,json,hashlib
root=Path(__file__).resolve().parent
base=root.parent/'compiler-memo-58/selfhost'
source=(root/'checker_lifetimes.goose').read_text();original=(base/'checker_lifetimes.goose').read_text();model=(base/'model.goose').read_text()
def function(text,name):
 start=re.search(r'^(?:inline |recursive )?fn '+name+r'\(',text,re.M).start()
 return text[start:text.index('\n}',start)+3]
constants='\n'.join(l for l in model.splitlines() if re.match(r'let TY_',l))
type_def=re.search(r'struct Type \{.*?\n\}',model,re.S).group()
fixture='import std;\n'+constants+'\n'+type_def+'''
struct Node { type_id: i64 = -1, next: i64 = -1 }
struct Program { types: Type[>..]&, nodes: Node[>..]& }
'''
for name in ['life_holds','life_relative_storage']:
 fixture+=function(original,name).replace('fn '+name+'(', 'fn baseline_'+name+'(',1)+'\n'
 fixture+=function(source,name)+'\n'+function(source,name+'_walk')+'\n'
fixture+='''
fn main() -> i32 {
    var types: Type[>..] = [
        Type { kind: TY_INT }, Type { kind: TY_BOOL }, Type { kind: TY_FLOAT }, Type { kind: TY_VOID },
        Type { kind: TY_SLICE }, Type { kind: TY_REF },
        Type { kind: TY_REF, length_storage: 0 }, Type { kind: TY_REF, length_storage: 8, pool: 5 },
        Type { kind: TY_REF, length_storage: 1, pool: 0 },
        Type { kind: TY_ARRAY, element: 5 }, Type { kind: TY_ARRAY, element: 6 }, Type { kind: TY_ARRAY },
        Type { kind: TY_STRUCT, first: 0 }, Type { kind: TY_ENUM, first: 1 }, Type { kind: TY_TUPLE, first: 2 },
        Type { kind: TY_STRUCT, first: 3 }, Type { kind: TY_STRUCT, first: 5 },
        Type { kind: TY_REF, element: 4, length_storage: 0 }, Type { kind: TY_REF, element: 6 },
        Type { kind: TY_SLICE, element: 6 }, Type { kind: TY_UNKNOWN, storage: 1 },
        Type { kind: TY_FN, first: 1 }, Type { kind: TY_GENERIC }, Type { kind: TY_NAME },
        Type { kind: TY_ARRAY, element: 13 }, Type { kind: TY_TUPLE }
    ];
    var nodes: Node[>..] = [
        Node { type_id: 4 }, Node { type_id: 6 }, Node { type_id: 7 },
        Node { type_id: 15, next: 4 }, Node { type_id: 5 },
        Node { type_id: 16, next: 6 }, Node { type_id: 6 }
    ];
    var p = Program { types: types, nodes: nodes };
    let holds: bool[26] = [false, false, false, false, true, true, false, false, false, true, false, false, true, false, false, true, false, false, true, true, false, false, false, false, false, false];
    let relative: bool[26] = [false, false, false, false, false, false, true, false, false, false, true, false, false, true, false, false, true, true, false, false, false, false, false, false, true, false];
    let pooled: bool[26] = [false, false, false, false, false, false, true, true, true, false, true, false, false, true, true, false, true, true, false, false, false, false, false, false, true, false];
    for pass in 0..10 {
        for ty in 0..26 {
            if baseline_life_holds(p, ty) != holds[ty] || life_holds(p, ty) != holds[ty] { return 1; }
            if baseline_life_relative_storage(p, ty) != relative[ty] || life_relative_storage(p, ty) != relative[ty] { return 2; }
            if baseline_life_relative_storage(p, ty, true) != pooled[ty] || life_relative_storage(p, ty, true) != pooled[ty] { return 3; }
        }
    }
    if life_holds(p, -1) || life_relative_storage(p, -1) || life_relative_storage(p, -1, true) { return 4; }
    p.types[0].kind = TY_REF; p.types[0].length_storage = 0;
    if life_holds(p, 0) || !life_relative_storage(p, 0) { return 5; }
    p.types[0].kind = TY_SLICE;
    if !life_holds(p, 0) || life_relative_storage(p, 0, true) { return 6; }
    print("leaf properties: 26 hand-expected graph cases x 3 queries x 10 passes plus mutation/negative boundaries passed");
    return 0;
}
'''
(root/'leaf-properties-fixture.goose').write_text(fixture)
proof={'status':'frozen-before-execution-unrun','baseline':str(base),'fixture':str(root/'leaf-properties-fixture.goose'),'fixture_sha256':hashlib.sha256(fixture.encode()).hexdigest(),'expected_runtime_exit':0,'expected_stdout':'leaf properties: 26 hand-expected graph cases x 3 queries x 10 passes plus mutation/negative boundaries passed\n','oracle':'Hand-specified answer tables plus actual old helpers; no C++ oracle or copied candidate implementation. Includes old relative traversal stop on slice/ref, pooled vs unpooled mode, cyclic nominal and shared/array graphs.','graph_cases':26,'queries_per_case':3,'passes':10,'matrix':{'target':['native','wasm-direct'],'optimization':[0,2],'debug':[False,True]},'limitations':'Generated only. No compiler build or program compilation/execution yet.'}
(root/'fixture-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
