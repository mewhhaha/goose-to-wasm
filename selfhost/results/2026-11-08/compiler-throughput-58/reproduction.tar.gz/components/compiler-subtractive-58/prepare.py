from pathlib import Path
import re,difflib,json,hashlib
root=Path(__file__).resolve().parent
base=root.parent/'compiler-memo-58/selfhost'
life=(base/'checker_lifetimes.goose').read_text()
old=life
wrappers={
'life_holds':'''inline fn life_holds(p: Program&, ty: i64) -> bool {
    if ty < 0 { return false; }
    let t: const Type& = p.types[ty];
    if t.kind == TY_SLICE { return true; }
    if t.kind == TY_REF { return t.length_storage < 0; }
    if t.kind == TY_ARRAY || t.kind == TY_STRUCT || t.kind == TY_ENUM || t.kind == TY_TUPLE { return life_holds_walk(p, ty); }
    return false;
}
''',
'life_relative_storage':'''inline fn life_relative_storage(p: Program&, ty: i64, include_pool: bool = false) -> bool {
    if ty < 0 { return false; }
    let t: const Type& = p.types[ty];
    if t.kind == TY_REF { return t.length_storage >= 0 && (t.pool < 0 || include_pool); }
    if t.kind == TY_ARRAY || t.kind == TY_STRUCT || t.kind == TY_ENUM || t.kind == TY_TUPLE { return life_relative_storage_walk(p, ty, include_pool); }
    return false;
}
'''}
for name,wrapper in wrappers.items():
    life=life.replace('fn '+name+'(',wrapper+'fn '+name+'_walk(',1)
checker=(base/'checker.goose').read_text()
new_checker=checker
start=new_checker.index('fn check_flow_save(')
end=new_checker.index('\nfn check_flow_restore(',start)
flow=new_checker[start:end]
assert flow.count('let symbol = p.symbols[c.variables[index].symbol];')==1
flow=flow.replace('let symbol = p.symbols[c.variables[index].symbol];','let symbol: const Symbol& = p.symbols[c.variables[index].symbol];')
# Lift the existing pure eligibility filter unchanged into a cursor advance.
filter_start=flow.index('            var index = c.flow_cursors[cursor].index;')
filter_end=flow.index('            if index >= 0 && c.variables[index].symbol > greatest',filter_start)
filter_body=flow[filter_start:filter_end]
helper='fn check_flow_advance(p: Program&, c: Checker&, cursor: i64) {\n'+''.join(line[8:]+'\n' for line in filter_body.splitlines())+'}\n'
flow=flow[:filter_start]+'            let index = c.flow_cursors[cursor].index;\n'+flow[filter_end:]
flow=flow.replace('    // Each frame chain is in reverse declaration order.', '    for cursor in 0..cursor_count { check_flow_advance(p, c, cursor); }\n    // Each frame chain is in reverse declaration order.',1)
flow=flow.replace('        c.flow_cursors[selected].index = variable.next_frame;', '        c.flow_cursors[selected].index = variable.next_frame;\n        check_flow_advance(p, c, selected);',1)
new_checker=new_checker[:start]+helper+flow+new_checker[end:]
patch=[]
for name,a,b in [('checker_lifetimes.goose',old,life),('checker.goose',checker,new_checker)]:
    (root/name).write_text(b)
    patch.extend(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='a/selfhost/'+name,tofile='b/selfhost/'+name))
(root/'candidate.patch').write_text(''.join(patch))
(root/'identities.json').write_text(json.dumps({name:{'baseline_sha256':hashlib.sha256((base/name).read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256((root/name).read_bytes()).hexdigest()}for name in ('checker_lifetimes.goose','checker.goose')},indent=2)+'\n')
