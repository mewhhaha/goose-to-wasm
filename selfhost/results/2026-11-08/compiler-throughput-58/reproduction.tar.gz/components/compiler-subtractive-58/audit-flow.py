from pathlib import Path
import re,json,hashlib
r=Path(__file__).resolve().parent;b=r.parent/'compiler-memo-58/selfhost'
def function(text,name):
 start=re.search(r'^(?:inline |recursive )?fn '+name+r'\(',text,re.M).start();return text[start:text.index('\n}',start)+3]
old=(b/'checker.goose').read_text();new=(r/'checker.goose').read_text()
old_flow=function(old,'check_flow_save');new_flow=function(new,'check_flow_save');advance=function(new,'check_flow_advance')
start=old_flow.index('            var index = c.flow_cursors[cursor].index;');end=old_flow.index('            if index >= 0 && c.variables[index].symbol > greatest',start)
block=old_flow[start:end].replace('let symbol = p.symbols[c.variables[index].symbol];','let symbol: const Symbol& = p.symbols[c.variables[index].symbol];')
helper='fn check_flow_advance(p: Program&, c: Checker&, cursor: i64) {\n'+''.join(line[8:]+'\n'for line in block.splitlines())+'}\n'
assert advance==helper
expected=old_flow[:start]+'            let index = c.flow_cursors[cursor].index;\n'+old_flow[end:]
expected=expected.replace('    // Each frame chain is in reverse declaration order.','    for cursor in 0..cursor_count { check_flow_advance(p, c, cursor); }\n    // Each frame chain is in reverse declaration order.',1).replace('        c.flow_cursors[selected].index = variable.next_frame;','        c.flow_cursors[selected].index = variable.next_frame;\n        check_flow_advance(p, c, selected);',1)
assert new_flow==expected
life=(r/'checker_lifetimes.goose').read_text();original=(b/'checker_lifetimes.goose').read_text()
for name in ['life_holds','life_relative_storage']:
 assert function(life,name+'_walk').replace('fn '+name+'_walk(', 'fn '+name+'(',1)==function(original,name)
 assert '[>..]'not in function(life,name)
audit=json.loads((r/'audit.json').read_text());audit['flow_filter_exact_after_extraction_and_const_borrow']=True
audit['checker_only_changes_const_borrow']=False
audit['flow_other_behavior_exact_after_normalizing_two_advance_sites']=True
audit['flow_proof']={'invariant':'At merge entry every cursor points at its first remaining eligible item or -1. Eligibility depends only on p/scopes/variables/scope, never on cursor or flow_work state.','initialization':'Filtering all collected cursors establishes the invariant, including lexical-over-active deduplication precedence from unchanged check_flow_frame.','induction':'The selected head is appended exactly as before. Only its next pointer changes; advancing only that cursor restores the invariant. All unselected heads remain eligible. Max-symbol selection/tie order, snapshot fields, final reverse remain exact.','mutation_closure':'check_visible reads only c.scopes; check_flow_advance writes only c.flow_cursors[cursor].index; check_flow_save writes only out, cursors, and flow_work. Symbols, types, nodes, variables, scopes and c.scope remain unchanged during save.','invalid_states':'Negative scopes retain original filtering/absence behavior. Positive invalid scopes still enter identical original checked indexing before filter; separate baseline/candidate trap guards frozen.'}
audit['synthetic_work_counts']={'scope':'Pure-eligibility algorithm model, not compiler timing or actual helper execution. 10000 seeded traces identical.','rows':[{'eligible_symbols':256,'cursors':k,'old_predicate_checks':old,'new_predicate_checks':256}for k,old in[(1,256),(2,511),(4,1018),(8,2020),(16,3976)]],'remaining_cost':'Max-symbol merge still scans all cursor heads per emitted symbol; no heap/new index and no change to asymptotic merge cost.'}
audit['candidate_sha256']={n:hashlib.sha256((r/n).read_bytes()).hexdigest()for n in['checker_lifetimes.goose','checker.goose','candidate.patch']}
audit['independent_review']='compiler_ceiling_review approved exact combined flow prefilter: unchanged predicate, immutable eligibility, strict tie order/duplicates/data/reversal preserved; leaf wrappers and const borrow approved previously.'
audit['limits']='Frozen leaf/flow/invalid-scope fixtures unrun; no compiler builds/timing/execution. One-cursor prefilter adds helper-call cost; measure before accepting.'
(r/'audit.json').write_text(json.dumps(audit,indent=2)+'\n')
print('combined patch',audit['candidate_sha256']['candidate.patch'])
