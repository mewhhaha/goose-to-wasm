from pathlib import Path
import re,json,hashlib
root=Path(__file__).resolve().parent;base=root.parent/'compiler-memo-58/selfhost'
old=(base/'checker.goose').read_text();new=(root/'checker.goose').read_text();model=(base/'model.goose').read_text()
def function(t,n):
 s=re.search(r'^(?:inline |recursive )?fn '+n+r'\(',t,re.M).start();return t[s:t.index('\n}',s)+3]
def struct(t,n):return re.search(r'struct '+n+r' \{.*?\}',t,re.S).group()
constants='\n'.join(l for l in model.splitlines()if re.match(r'let (TY_|S_|N_VARIABLE\b)',l))
fixture='import std;\n'+constants+'\n'+struct(model,'Symbol')+'\n'+struct(model,'Type')+'\n'
for name in ['CheckScope','CheckVariable','CheckFlow','CheckSpan','CheckFlowCursor']:fixture+=struct(old,name)+'\n'
fixture+='''
struct Node { kind: i64 = 0, right: i64 = -1, scope: i64 = -1 }
struct Program { nodes: Node[>..]&, types: Type[>..]&, symbols: Symbol[>..]& }
struct Checker { scopes: CheckScope[>..]&, variables: CheckVariable[>..]&, flow_work: CheckFlow[>..]&, flow_cursors: CheckFlowCursor[>..]&, checking: i64[>..]&, checking_count: i64 = 0, scope: i64 = 0 }
'''
for name in ['check_visible','check_flow_frame','check_flow_advance','check_flow_save']:fixture+=function(new,name)+'\n'
fixture+=function(old,'check_flow_save').replace('fn check_flow_save(', 'fn baseline_check_flow_save(',1)+'\n'
fixture+='''
fn verify(p: Program&, c: Checker&, expected: const i64[:], active: bool = true) -> bool {
    var original = CheckSpan {}; baseline_check_flow_save(p, c, original, active);
    var actual = CheckSpan {}; check_flow_save(p, c, actual, active);
    if actual.count != expected.len || original.count != expected.len { return false; }
    for symbol, index in expected {
        let a = c.flow_work[actual.first + index]; let b = c.flow_work[original.first + index];
        if a.symbol != symbol || b.symbol != symbol || a.assigned != b.assigned || a.maybeassigned != b.maybeassigned || a.narrowed != b.narrowed { return false; }
        if a.assigned != (symbol % 2 == 0) || a.maybeassigned != (symbol % 3 == 0) || a.narrowed != 100 + symbol { return false; }
    }
    return true;
}
fn main() -> i32 {
    var scopes: CheckScope[>..] = [
        CheckScope { parent: -1, function_node: -1, frame_root: 0, first_variable: 0 },
        CheckScope { parent: 0, function_node: 10, frame_root: 1, first_variable: 3 },
        CheckScope { parent: 1, function_node: 10, frame_root: 1 },
        CheckScope { parent: 0, function_node: 20, frame_root: 3, first_variable: 8 },
        CheckScope { parent: 1, function_node: 10, frame_root: 1 },
        CheckScope { parent: 0, function_node: 30, frame_root: 5 }
    ];
    var types: Type[>..] = [Type { kind: TY_INT }, Type { kind: TY_STRUCT }, Type { kind: TY_REF }];
    var nodes: Node[>..] = [
        Node { kind: N_VARIABLE, right: 99 }, Node {}, Node {}, Node { kind: N_VARIABLE, right: 99 },
        Node {}, Node {}, Node { kind: N_VARIABLE, right: 99 }, Node { kind: N_VARIABLE }, Node {},
        Node {}, Node { scope: 3 }, Node { scope: 1 }, Node { scope: -1 }, Node { scope: 5 }, Node { scope: 3 }
    ];
    var symbols: Symbol[>..] = [
        Symbol { type_id: 0, node: 0, scope: 0, flags: S_GLOBAL | S_MUTABLE },
        Symbol { type_id: 0, node: 1, scope: 1, flags: S_PARAMETER },
        Symbol { type_id: 0, node: 2, scope: 4, flags: S_MUTABLE },
        Symbol { type_id: 0, node: 3, scope: 2 }, Symbol { type_id: 0, node: 4, scope: 3, flags: S_MUTABLE },
        Symbol { type_id: 0, node: 5, scope: 3, flags: S_PARAMETER }, Symbol { type_id: 1, node: 6, scope: 3 },
        Symbol { type_id: 0, node: 7, scope: 3 }, Symbol { type_id: 2, node: 8, scope: 3, flags: S_PARAMETER }
    ];
    var variables: CheckVariable[>..] = [];
    for symbol in 0..9 {
        var next = symbol - 1; if symbol == 0 || symbol == 1 || symbol == 4 { next = -1; }
        variables.push(CheckVariable { symbol: symbol, assigned: symbol % 2 == 0, maybeassigned: symbol % 3 == 0, narrowed: 100 + symbol, next_frame: next });
    }
    var work: CheckFlow[>..] = []; var cursors: CheckFlowCursor[>..] = []; var checking: i64[>..] = [10, 11, 12, 13, 14];
    var p = Program { nodes: nodes, types: types, symbols: symbols };
    var c = Checker { scopes: scopes, variables: variables, flow_work: work, flow_cursors: cursors, checking: checking, checking_count: 5, scope: 2 };
    // The lexical frame wins over its duplicate active-caller entry; its immutable parameter stays.
    if !verify(p, c, [0, 1, 3, 4, 7, 8]) { return 1; }
    if !verify(p, c, [0, 1, 3], false) { return 2; }
    c.scope = 1;
    if !verify(p, c, [0, 1, 4, 7, 8]) { return 3; }
    c.scope = 4;
    if !verify(p, c, [0, 1, 2, 4, 7, 8]) { return 4; }
    c.scope = -1;
    if !verify(p, c, [2, 4, 7, 8]) { return 5; }
    c.scope = -2;
    if !verify(p, c, [2, 4, 7, 8]) { return 6; }
    c.checking_count = 0;
    let empty: i64[0] = [];
    if !verify(p, c, empty) { return 7; }
    c.scope = 2;
    if !verify(p, c, [0, 1, 3]) { return 8; }
    c.checking_count = 5; p.symbols[3].scope = -2;
    if !verify(p, c, [0, 1, 4, 7, 8]) { return 9; }
    p.symbols[3].scope = 2; p.symbols[0].scope = -2;
    if !verify(p, c, [0, 1, 3, 4, 7, 8]) { return 10; }
    // Two distinct test frame chains deliberately share a symbol; the merge must preserve duplicates.
    c.scopes[5].first_variable = 0;
    if !verify(p, c, [0, 0, 1, 3, 4, 7, 8]) { return 11; }
    c.scopes[5].first_variable = -1;
    // A reference parameter does not qualify for the immutable scalar/aggregate omission.
    p.symbols[8].type_id = 0;
    if !verify(p, c, [0, 1, 3, 4, 7]) { return 12; }
    p.symbols[7].type_id = -1;
    if !verify(p, c, [0, 1, 3, 4, 7]) { return 13; }
    p.symbols[7].type_id = 0; p.nodes[7].right = 99;
    if !verify(p, c, [0, 1, 3, 4]) { return 14; }
    print("flow prefilter: 14 hand-expected snapshots preserve fields/order/roles/empty/duplicates/invalid-negative scopes");
    return 0;
}
'''
(root/'flow-prefilter-fixture.goose').write_text(fixture)
proof={'status':'frozen-before-execution-unrun','source_sha256':hashlib.sha256(fixture.encode()).hexdigest(),'expected_exit':0,'expected_stdout':'flow prefilter: 14 hand-expected snapshots preserve fields/order/roles/empty/duplicates/invalid-negative scopes\n','oracle':'14 explicit snapshot symbol lists and independent assigned/maybeassigned/narrowed formulas, compared with actual unchanged old helper and actual candidate helper; no C++ oracle.','matrix':{'target':['native','wasm-direct'],'optimization':[0,2],'debug':[False,True]},'covers':['lexical scope filtering and sibling exclusion','active-caller mutable/delayed/reference inclusion','immutable parameter/initialized aggregate skipping only for active callers','lexical-over-active precedence and duplicate callers','negative current/declaration/function scopes','empty cursor set and empty frame','duplicate symbols preserved across distinct synthetic frames','exact snapshot data and symbol order','eligibility changes between separate snapshots'], 'positive_invalid_scope':'All original c.scopes frame-indexing code remains exact; invalid positive root scope traps before either old/new filtering. No new bounds fallback is introduced.','limits':'Generated only; no program compilation or execution.'}
(root/'flow-fixture-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
