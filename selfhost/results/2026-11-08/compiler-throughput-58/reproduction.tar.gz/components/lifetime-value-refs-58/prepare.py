from pathlib import Path
import hashlib,json,re,difflib
h=Path(__file__).resolve().parent;base=h.parent/'lifetime-value64-58/checker_lifetimes.goose';old=base.read_text();sha=lambda s:hashlib.sha256(s.encode()).hexdigest();assert sha(old)=='f25b736e69cf7f529249623f896aafba3902aa416f468d5e88b061619c05258b'
new=old
for name in ['life_value_roots','life_hold','life_construct_value']:
 pattern=r'(fn '+name+r'\([^\n]*?)value: LifeValue';new,count=re.subn(pattern,r'\1value: const LifeValue&',new);assert count==1
new=new.replace('if builtin == 0 || builtin == 1 { life_hold(l, LifeValue {}, node, 6); }','if builtin == 0 || builtin == 1 { let held_value = LifeValue {}; life_hold(l, held_value, node, 6); }',1)
new=new.replace('{ life_hold(l, life_item(l, arguments, 1), node, 7); }','{ let held_value = life_item(l, arguments, 1); life_hold(l, held_value, node, 7); }',1)
(h/'checker_lifetimes.goose').write_text(new);(h/'candidate.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/selfhost/checker_lifetimes.goose',tofile='b/selfhost/checker_lifetimes.goose')))
(h/'source.json').write_text(json.dumps({'baseline':str(base),'baseline_sha256':sha(old),'candidate_sha256':sha(new),'patch_sha256':sha((h/'candidate.patch').read_text()),'helpers':['life_value_roots','life_hold','life_construct_value'],'scope':'Three signatures change to const LifeValue&; helper bodies unchanged. Exactly two existing hold rvalues bind explicit snapshots to satisfy current compiler reference admission; all later arguments are pure scalar reads.'},indent=2)+'\n')
