from pathlib import Path
import hashlib,json,subprocess,re
h=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();ids=json.loads((h/'source.json').read_text());old=Path(ids['baseline']).read_text();new=(h/'checker_lifetimes.goose').read_text();compiler=h.parent/'compiler-native-fields-58/goose'
def fnbody(s,name):
 m=re.search(r'fn '+name+r'\(',s);a=s.index('{',m.start());i=a+1;depth=1
 while depth:
  if s[i]=='{':depth+=1
  if s[i]=='}':depth-=1
  i+=1
 return s[a:i]
receipt={'status':'passed','source':ids,'source_approval':'Astra exact-approved cdcbaca210006d80; helper bodies unchanged and two explicit local bindings preserve original conditional/evaluation positions.','CPU':3,'compiler_sha256':sha(compiler),'runs':[],'traps':[],'helper_body_sha256':{},'scope':'Private source ABI experiment only. Frozen hand-expected actual-helper guards compiled by A16; no candidate compiler build/run, timing claim or candidate-captured golden. Full compiler qualification and actual ABI assembly remain required.'}
for name in ids['helpers']:
 a=fnbody(old,name);b=fnbody(new,name);assert a==b;receipt['helper_body_sha256'][name]=hashlib.sha256(a.encode()).hexdigest()
for engine in ['wasmtime','v8']:
 report=h/('parent-supported-'+engine)/'report.json';r=json.loads(report.read_text());assert r['summary']=={'selected':40,'passed':40,'failed':0};assert r['input_sha256']==r['input_sha256_after'];receipt['runs'].append({'engine':engine,'summary':r['summary'],'stable_inputs':True,'report_sha256':sha(report)})
 for row in r['results']:
  if '/bounds/'in row['case']:
   c=r['commands'][row['run_command']];assert c['exit_code']==1 and 'out of bounds'in c['stderr'];receipt['traps'].append({'engine':engine,'case':row['case'],'level':row['level'],'exit_code':1,'stderr':c['stderr']})
assert len(receipt['traps'])==64
receipt['callsite_counts']=json.loads((h/'audit.json').read_text())['call_counts']
receipt['rejected_draft']={'patch_sha256':sha(h/'candidate-signatures-only.patch'),'source_sha256':sha(h/'checker_lifetimes-signatures-only.goose'),'admission':json.loads((h/'admission-first/isolated.json').read_text()),'reason':'Compiler accepts lvalue constref, rejects record-literal and function-return temporaries. Revised source binds the two actual hold rvalues explicitly. Unsupported grows-array cap property was also removed from fixture;512 appends are stress coverage, not a measured relocation claim.'}
receipt['guard_limits']='Temporary/add_contents support are deterministic state witnesses. Early construct test records item length1→128 after snapshot; holds test records512 appended rows and preserved snapshots but does not infer physical relocation. Arbitrary side-effectful later arguments are outside present-callsite equivalence proof.'
nm=subprocess.run(['nm','-S','--defined-only',str(compiler)],capture_output=True,text=True,check=True).stdout;receipt['A16_parent_symbols']={}
for line in nm.splitlines():
 cols=line.split()
 if len(cols)==4 and cols[3]in ['g_fn106659','g_fn109124']:receipt['A16_parent_symbols'][cols[3]]={'address':cols[0],'size_bytes':int(cols[1],16)}
(h/'delivery.json').write_text(json.dumps(receipt,indent=2)+'\n')
(h/'sealed.json').write_text(json.dumps({str(p.relative_to(h)):sha(p)for p in sorted(h.rglob('*'))if p.is_file()and (p.parent==h or p.parent.name=='admission-first')and p.name!='sealed.json'},indent=2)+'\n')
print('passed80 observations,64 checked bounds traps; source',ids['candidate_sha256'])
