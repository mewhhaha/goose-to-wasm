from pathlib import Path
import re,json,hashlib
h=Path(__file__).resolve().parent;ids=json.loads((h/'source.json').read_text());old=Path(ids['baseline']).read_text();new=(h/'checker_lifetimes.goose').read_text();sha=lambda x:hashlib.sha256(x.encode()).hexdigest()
def fn(src,name):
 m=re.search(r'(?:inline )?fn '+name+r'\(',src);a=src.index('{',m.start());b=a+1;depth=1
 while depth:
  if src[b]=='{':depth+=1
  if src[b]=='}':depth-=1
  b+=1
 return src[m.start():b]
value=re.search(r'struct LifeValue \{[^\n]+',old).group()
text='''import std;
let TY_REF:i64=2;let TY_SLICE:i64=3;let TY_ARRAY:i64=4;let TY_STRUCT:i64=5;let TY_ENUM:i64=6;
struct Type {kind:i64=1,length_storage:i64=-1}
struct Program {types:Type[>..]&}
'''+value+'''\nstruct LifeHold {value:LifeValue,node:i64,kind:i64=0,frame:i64=-1}
struct LifeItem {value:LifeValue,next:i64=-1}
struct LifeSet {first:i64=-1}
struct LifeAlt {root:i64=0,next:i64=-1}
struct Lifetimes {holds:LifeHold[>..]&,items:LifeItem[>..]&,sets:LifeSet[>..]&,alts:LifeAlt[>..]&,frame:i64=17,hold_count:i64=0,temporary_calls:i64=0,add_calls:i64=0,add_sum:i64=0}
'''+fn(old,'life_is_ref')+'''
fn life_temporary(p:Program&,l:Lifetimes&,node:i64)->i64 {l.temporary_calls+=1;while l.items.len<128 {l.items.push(LifeItem {value:LifeValue {}});}return 1;}
fn life_add_contents(l:Lifetimes&,root:i64,contents:i64) {l.add_calls+=1;l.add_sum+=root*100+contents;}
fn make_value(ty:i64)->LifeValue {return LifeValue {type_id:ty,place:5,refs:7,contents:9,self_pools:11,relative_roots:13,tuple:15,element_array:-2};}
fn equal(a:LifeValue,b:LifeValue) {assert(a.type_id==b.type_id && a.place==b.place && a.refs==b.refs && a.contents==b.contents && a.self_pools==b.self_pools && a.relative_roots==b.relative_roots && a.tuple==b.tuple && a.element_array==b.element_array);}
'''
extractions=[]
for tag,src in [('old',old),('new',new)]:
 for name in ids['helpers']+['life_item']:
  s=fn(src,name);text+=s.replace('fn '+name+'(','fn '+tag+'_'+name+'(')+'\n';extractions.append({'tag':tag,'function':name,'sha256':sha(s)})
text+='''fn compare_holds(a:Lifetimes&,b:Lifetimes&) {assert(a.hold_count==b.hold_count && a.holds.len==b.holds.len);for i in 0..a.holds.len {let x=a.holds[i];let y=b.holds[i];equal(x.value,y.value);assert(x.node==y.node && x.kind==y.kind && x.frame==y.frame);}}
fn main() {
 var types:Type[>..]=[Type {},Type {kind:TY_REF},Type {kind:TY_REF,length_storage:0},Type {kind:TY_SLICE},Type {kind:TY_ARRAY},Type {kind:TY_STRUCT},Type {kind:TY_ENUM}];var p=Program {types:types};
 var ah:LifeHold[>..]=[];var bh:LifeHold[>..]=[];var ai:LifeItem[>..]=[LifeItem {value:make_value(4)}];var bi:LifeItem[>..]=[LifeItem {value:make_value(4)}];var sets:LifeSet[>..]=[LifeSet {},LifeSet {first:0},LifeSet {}];var alts:LifeAlt[>..]=[LifeAlt {root:3,next:1},LifeAlt {root:4}];
 var a=Lifetimes {holds:ah,items:ai,sets:sets,alts:alts};var b=Lifetimes {holds:bh,items:bi,sets:sets,alts:alts};
 let early=old_life_construct_value(p,a,77,a.items[0].value,0);let early2=new_life_construct_value(p,b,77,b.items[0].value,0);equal(early,early2);assert(a.items.len==128 && b.items.len==128 && early2.place==1 && early2.contents==9);\n let types_to_test:i64[8]=[-1,0,1,2,3,4,5,6];let roots_expected:i64[8]=[9,9,7,0,7,9,9,9];
 for i in 0..8 {
  let ty=types_to_test[i];var v=make_value(ty);let borrowed:const LifeValue& = v;
  assert(old_life_value_roots(p,v)==roots_expected[i]);assert(new_life_value_roots(p,v)==roots_expected[i]);assert(new_life_value_roots(p,borrowed)==roots_expected[i]);let returned=make_value(ty);assert(new_life_value_roots(p,returned)==roots_expected[i]);
  old_life_hold(a,v,ty);new_life_hold(b,borrowed,ty);compare_holds(a,b);assert(b.holds[b.hold_count-1].kind==0 && b.holds[b.hold_count-1].frame==17);equal(b.holds[b.hold_count-1].value,v);
  for destination in [0,1,2] {
   a.temporary_calls=0;b.temporary_calls=0;a.add_calls=0;b.add_calls=0;a.add_sum=0;b.add_sum=0;
   let x=old_life_construct_value(p,a,77,v,destination);let y=new_life_construct_value(p,b,77,borrowed,destination);equal(x,y);var expected=v;var temporary=0;var adds=0;var sum=0;
   if ty>=4 {expected.place=destination;if destination==0 {expected.place=1;temporary=1;}if expected.place==1 {adds=2;sum=718;}}
   equal(y,expected);equal(v,make_value(ty));assert(a.temporary_calls==temporary && b.temporary_calls==temporary && a.add_calls==adds && b.add_calls==adds && a.add_sum==sum && b.add_sum==sum);
   let returned=make_value(ty);equal(new_life_construct_value(p,b,77,returned,destination),expected);
  }
 }
 // Literal and function-return temporary admission, with default kind preserved.
 old_life_hold(a,LifeValue {},101);let empty_hold=LifeValue {};new_life_hold(b,empty_hold,101);compare_holds(a,b);
 old_life_hold(a,old_life_item(a,0,0),102,7);let item_return=new_life_item(b,0,0);new_life_hold(b,item_return,102,7);compare_holds(a,b);
 assert(new_life_value_roots(p,b.items[0].value)==9);let item_return2=new_life_item(b,0,0);equal(new_life_construct_value(p,b,77,item_return2,2),LifeValue {type_id:4,place:2,refs:7,contents:9,self_pools:11,relative_roots:13,tuple:15,element_array:-2});
 // Overwrite a preallocated row, including when source and destination are the same row.
 a.hold_count=0;b.hold_count=0;old_life_hold(a,a.holds[0].value,201,3);new_life_hold(b,b.holds[0].value,201,3);compare_holds(a,b);assert(b.holds[0].node==201 && b.holds[0].kind==3);
 // Repeated append stress from an arena-backed row; no public grows-array capacity API is assumed.
 a.hold_count=a.holds.len;b.hold_count=b.holds.len;
 for round in 0..512 {let saved=a.holds[0].value;old_life_hold(a,a.holds[0].value,401+round,6);new_life_hold(b,b.holds[0].value,401+round,6);compare_holds(a,b);equal(b.holds[b.hold_count-1].value,saved);}
 // Arena-backed input is copied before life_temporary can grow that same item arena.
 a.temporary_calls=0;b.temporary_calls=0;
 let x=old_life_construct_value(p,a,77,a.items[0].value,0);let y=new_life_construct_value(p,b,77,b.items[0].value,0);equal(x,y);assert(y.place==1 && y.contents==9 && y.element_array == -2 && a.items.len==128 && b.items.len==128);equal(a.items[0].value,make_value(4));equal(b.items[0].value,make_value(4));
 let empty_construct=LifeValue {};equal(new_life_construct_value(p,b,77,empty_construct,0),LifeValue {});
 print("value ref guards passed");
}
'''
(h/'fixture.goose').write_text(text)
manifest=json.loads((h.parent/'lifetime-value64-58/cases.json').read_text());manifest['cases']=manifest['cases'][:4];manifest['method']='Actual unchanged bodies of three ABI helpers compiled with parent and candidate signatures; hand expected roots/hold snapshots/constructed outputs, explicitly materialized rvalues and arena-backed append stress. Full compiler callsites separately pinned.'
for c in manifest['cases']:c['id']=c['id'].replace('value64','value-refs');c['source']='build/completion-runs/lifetime-value-refs-58/fixture.goose';c['expect']['stdout']='value ref guards passed\n'
prefix=text[:text.index('fn main()')]
for tag in ['old','new']:
 for helper in ['life_value_roots','life_construct_value']:
  call=tag+'_'+helper+'(p,value)'
  if helper=='life_construct_value':call=tag+'_'+helper+'(p,l,77,value,0)'
  trap=prefix+'fn main() {var types:Type[>..]=[Type {}];var p=Program {types:types};var holds:LifeHold[>..]=[];var items:LifeItem[>..]=[];var sets:LifeSet[>..]=[];var alts:LifeAlt[>..]=[];var l=Lifetimes {holds:holds,items:items,sets:sets,alts:alts};let value=LifeValue {type_id:128};let result='+call+';print("unexpected",result);}\n'
  name='bounds-'+tag+'-'+helper+'.goose';(h/name).write_text(trap)
  for target in ['native','wasm-direct']:
   for debug in [False,True]:manifest['cases'].append({'id':'value-refs/bounds/'+tag+'/'+helper+'/'+target+'/'+str(debug),'source':'build/completion-runs/lifetime-value-refs-58/'+name,'phase':'run','target':target,'levels':[0,2],'debug':debug,'stdin':'','expect':{'stdout':'','exit':'nonzero'}})
(h/'cases.json').write_text(json.dumps(manifest,indent=2)+'\n')
(h/'guard-proof.json').write_text(json.dumps({'fixture_sha256':sha(text),'extractions':extractions,'roots_hand_expected':{'types':[-1,0,1,2,3,4,5,6],'answers':[9,9,7,0,7,9,9,9]},'construct_hand_expected':'Unknown/scalar/ref/slice preserve full input; array/struct/enum replace place with destination or temporary1, only set1 adds contents9 to roots3/4 (sum718). Marker-2 and tuple15 preserved. Input stays unchanged even while temporary grows item arena.','hold_hand_expected':'Full input snapshot, node, default/explicit kind and frame17; append, overwrite, same-row overwrite and 512 append rounds from borrowed holds row preserve snapshot.','limitations':'Temporary and add_contents support are explicit deterministic witnesses, not complete lifetime analysis. Existing compiler callsites require pure later arguments; arbitrary callers with side-effectful later arguments are outside proof.'},indent=2)+'\n')
