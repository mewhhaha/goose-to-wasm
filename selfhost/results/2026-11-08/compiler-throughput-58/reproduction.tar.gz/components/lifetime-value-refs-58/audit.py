from pathlib import Path
import re,json,hashlib
h=Path(__file__).resolve().parent;ids=json.loads((h/'source.json').read_text());base=Path(ids['baseline']);src=base.read_text();sha=lambda x:hashlib.sha256(x.encode()).hexdigest();calls=[]
for p in sorted(base.parent.glob('*.goose')):
 s=p.read_text()
 for m in re.finditer(r'\b(life_value_roots|life_hold|life_construct_value)\(',s):
  if re.search(r'\bfn\s*$',s[max(0,m.start()-8):m.start()]):continue
  a=m.end();i=a;stack=['(']
  while stack:
   c=s[i]
   if c in '([{':stack.append(c)
   elif c in ')]}':stack.pop()
   i+=1
  body=s[a:i-1];args=[];last=0;stack=[]
  for j,c in enumerate(body):
   if c in '([{':stack.append(c)
   elif c in ')]}':stack.pop()
   elif c==','and not stack:args.append(body[last:j].strip());last=j+1
  args.append(body[last:].strip());name=m[1];value_index={'life_value_roots':1,'life_hold':1,'life_construct_value':3}[name];later=args[value_index+1:]
  assert all(re.fullmatch(r'(?:[A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*|-?\d+)',x)for x in later),(name,later)
  calls.append({'file':p.name,'line':s.count('\n',0,m.start())+1,'helper':name,'arguments':args,'value':args[value_index],'later_arguments':later,'later_arguments_pure':True})
assert {c['file']for c in calls}=={'checker_lifetimes.goose'}
proof={'baseline_sha256':sha(src),'source_identity':ids,'callsites':calls,'call_counts':{name:sum(c['helper']==name for c in calls)for name in ids['helpers']},'proof':[
'life_value_roots reads input and immutable types only; life_is_ref is pure, and input is the final argument. No body mutation or later argument can invalidate the borrow.',
'life_hold reads the entire input exactly once into LifeHold entry before holds push/overwrite. The input is never reread after arena mutation.',
'life_construct_value reads input exactly once into var out at entry; all calls and mutations use out thereafter.',
'Present later arguments after value are only scalar local IDs, field reads from existing n and integer/default values; they do not mutate or grow the source. This inventory is necessary: arbitrary side-effectful later arguments are outside proof.',
'Actual roots callers pass locals or item rows. Construct callers pass local out. Hold callers mostly locals, plus two unsupported rvalue forms (empty record and life_item return), independently isolated and preserved in admission-first.',
'Parent compiler admits const-reference locals, rejects const-reference literals and return temporaries; rejected signature-only draft is preserved. Revised candidate binds exactly the two actual hold rvalues to held_value inside the same original conditionals, then passes pure scalars.'
], 'bounds':'Negative type IDs retain exact original branch behavior; invalid positive type IDs retain checked p.types access. No inferred defaults or unchecked access added.', 'scope':'Only requested three helpers; no coerce/merge/construct_read/cycle signature widening.'}
candidate=(h/'checker_lifetimes.goose').read_text()
reconstructed=candidate
for name in ids['helpers']:
 reconstructed=re.sub(r'(fn '+name+r'\([^\n]*?)value: const LifeValue&',r'\1value: LifeValue',reconstructed)
reconstructed=reconstructed.replace('if builtin == 0 || builtin == 1 { let held_value = LifeValue {}; life_hold(l, held_value, node, 6); }','if builtin == 0 || builtin == 1 { life_hold(l, LifeValue {}, node, 6); }',1)
reconstructed=reconstructed.replace('{ let held_value = life_item(l, arguments, 1); life_hold(l, held_value, node, 7); }','{ life_hold(l, life_item(l, arguments, 1), node, 7); }',1)
assert reconstructed==src
proof['exact_source_reconstruction']='Reverting only three signatures and the two explicit rvalue local bindings reproduces baseline byte-for-byte.'
proof['rejected_signature_only_patch_sha256']=hashlib.sha256((h/'candidate-signatures-only.patch').read_bytes()).hexdigest()
proof['admission_first']=json.loads((h/'admission-first/isolated.json').read_text())
(h/'audit.json').write_text(json.dumps(proof,indent=2)+'\n');print(proof['call_counts'])
