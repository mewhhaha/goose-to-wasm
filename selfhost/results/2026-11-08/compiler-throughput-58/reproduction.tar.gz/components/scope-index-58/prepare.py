from pathlib import Path
import json, hashlib, difflib
root = Path(__file__).resolve().parent
base = root.parent / 'compiler-recursive-58/selfhost'
model = (base / 'model.goose').read_text()
checker = (base / 'checker.goose').read_text()
new_model = model.replace('    provenance: i64 = -1,\n}', '    provenance: i64 = -1,\n    name_next: i64 = -1,\n}', 1)
new_checker = checker.replace('outer_exits: i64 = -1 }', 'outer_exits: i64 = -1, name_heads: i64[16] = [-1; 16] }', 1)
helper = '''fn check_name_bucket(p: Program&, token: i64) -> i64 {
    var hash: u32 = 2166136261;
    for byte in token_text(p, token) { hash = (hash ^ (byte as u32)) * 16777619; }
    return (hash & 15) as i64;
}
fn check_link_symbol(p: Program&, c: Checker&, symbol: i64, scope: i64) {
    if scope < 0 { return; }
    let bucket = check_name_bucket(p, p.symbols[symbol].name_token);
    p.symbols[symbol].scope_next = c.scopes[scope].first_symbol;
    p.symbols[symbol].name_next = c.scopes[scope].name_heads[bucket];
    c.scopes[scope].first_symbol = symbol;
    c.scopes[scope].name_heads[bucket] = symbol;
}
'''
new_checker = new_checker.replace('fn check_lookup_scope(', helper + 'fn check_lookup_scope(', 1)
start = new_checker.index('fn check_lookup_scope(')
end = new_checker.index('\nfn check_global_value(', start)
lookup = new_checker[start:end].replace('var id = c.scopes[scope].first_symbol;', 'let bucket = check_name_bucket(p, token);\n    var id = c.scopes[scope].name_heads[bucket];').replace('let symbol = p.symbols[id];', 'let symbol: const Symbol& = p.symbols[id];').replace('id = symbol.scope_next;', 'id = symbol.name_next;')
new_checker = new_checker[:start] + lookup + new_checker[end:]
new_checker = new_checker.replace('    let id = p.symbols.len; var scope_next = -1;', '    let id = p.symbols.len;', 1)
new_checker = new_checker.replace('    if scope >= 0 { scope_next = c.scopes[scope].first_symbol; }\n', '', 1)
new_checker = new_checker.replace('scope: scope, slot: slot, flags: flags, next: previous, owner: owner, scope_next: scope_next });\n    if scope >= 0 { c.scopes[scope].first_symbol = id; }', 'scope: scope, slot: slot, flags: flags, next: previous, owner: owner });\n    check_link_symbol(p, c, id, scope);', 1)
new = {'model.goose':new_model, 'checker.goose':new_checker}
patch = []
for name, source in new.items():
    (root / name).write_text(source)
    old = (base / name).read_text()
    patch.extend(difflib.unified_diff(old.splitlines(True), source.splitlines(True), fromfile='a/selfhost/'+name, tofile='b/selfhost/'+name))
(root / 'candidate.patch').write_text(''.join(patch))
(root / 'identities.json').write_text(json.dumps({name:{'baseline':hashlib.sha256((base/name).read_bytes()).hexdigest(),'candidate':hashlib.sha256(source.encode()).hexdigest()} for name,source in new.items()},indent=2)+'\n')
