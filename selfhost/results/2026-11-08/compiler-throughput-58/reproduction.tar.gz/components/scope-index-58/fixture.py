from pathlib import Path
import re,json
root=Path(__file__).resolve().parent
base=root.parent/'compiler-recursive-58/selfhost'
model=(root/'model.goose').read_text()
checker=(root/'checker.goose').read_text()
old=(base/'checker.goose').read_text()
def function(text,name):
    start=re.search(r'^(?:inline |recursive )?fn '+name+r'\(',text,re.M).start()
    end=text.index('\n}',start)+3
    return text[start:end]
def struct(text,name):
    return re.search(r'struct '+name+r' \{.*?\}',text,re.S).group()
constants='\n'.join(line for line in model.splitlines() if re.match(r'let (N_|S_|T_COLONCOLON\b)',line))
fixture='import std;\n'+constants+'\n'+struct(model,'Token')+'\n'+struct(model,'Symbol')+'\n'+struct(checker,'CheckScope')+'''
struct Node { kind: i64, token: i64 = -1, scope: i64 = -1, aux: i64 = 0, integer: i64 = -1 }
struct Program { text: u8[>..]&, tokens: Token[>..]&, nodes: Node[>..]&, symbols: Symbol[>..]& }
struct Checker { scopes: CheckScope[>..]&, scope: i64 = 0 }
'''
for name in ['same_bytes','token_text','same_name']:
    fixture+=function(model,name)+'\n'
for name in ['check_name_bucket','check_link_symbol','check_lookup_scope','check_global_value','check_lookup','check_lookup_name']:
    fixture+=function(checker,name)+'\n'
for name in ['check_lookup_scope','check_global_value','check_lookup','check_lookup_name']:
    body=function(old,name)
    for called in ['check_lookup_scope','check_global_value','check_lookup_name','check_lookup']:
        body=re.sub(r'\b'+called+r'\b','baseline_'+called,body)
    fixture+=body+'\n'
fixture+='''
fn token(p: Program&, text: const u8[:]) -> i64 {
    let start = p.text.len; p.text.append(text);
    let id = p.tokens.len; p.tokens.push(Token { kind: 1, start: start, end: p.text.len }); return id;
}
fn declaration(p: Program&, c: Checker&, token: i64, scope: i64, flags: i64, kind: i64, previous: i64 = -1, member_scope: i64 = -1) -> i64 {
    let node = p.nodes.len; p.nodes.push(Node { kind: kind, token: token, scope: member_scope });
    let id = p.symbols.len;
    p.symbols.push(Symbol { name_token: token, node: node, scope: scope, flags: flags, next: previous });
    check_link_symbol(p, c, id, scope); return id;
}
fn main() -> i32 {
    var text: u8[>..] = []; var tokens: Token[>..] = []; var nodes: Node[>..] = []; var symbols: Symbol[>..] = [];
    var scopes: CheckScope[>..] = [
        CheckScope { parent: -1, function_node: -1 }, CheckScope { parent: 0, function_node: 10 },
        CheckScope { parent: 1, function_node: 10 }, CheckScope { parent: 0, function_node: -1, namespace_node: 99 },
        CheckScope { parent: 2, function_node: 20 }
    ];
    var p = Program { text: text, tokens: tokens, nodes: nodes, symbols: symbols };
    var c = Checker { scopes: scopes };
    for scope in c.scopes { for head in scope.name_heads { if head != -1 { return 1; } } }
    let shade = token(p, "shade"); let shade_copy = token(p, "shade"); let call = token(p, "call");
    let argument = token(p, "argument"); let empty = token(p, ""); let a = token(p, "a"); let q = token(p, "q"); let upper = token(p, "A"); let absent = token(p, "absent");
    let global = declaration(p, c, shade, 0, S_GLOBAL, N_VARIABLE);
    let outer_function = declaration(p, c, shade, 1, S_FUNCTION, N_FUNCTION);
    let inner_type = declaration(p, c, shade_copy, 2, S_TYPE, N_STRUCT);
    if check_lookup(p, c, shade, 2) != outer_function { return 2; }
    let local = declaration(p, c, shade, 2, S_PARAMETER, N_PARAM, inner_type);
    if check_lookup(p, c, shade, 2) != local || check_lookup(p, c, shade, 0) != global { return 3; }
    let generic = declaration(p, c, call, 1, S_TYPE, N_TYPE_PARAM);
    let function = declaration(p, c, call, 2, S_FUNCTION, N_FUNCTION);
    if check_lookup(p, c, call, 2) != generic { return 4; }
    let parameter = declaration(p, c, argument, 2, S_PARAMETER, N_PARAM);
    if check_lookup_scope(p, c, argument, 2, S_FUNCTION) != parameter { return 5; }
    let type_parameter = declaration(p, c, argument, 1, S_TYPE, N_TYPE_PARAM);
    if check_lookup_scope(p, c, argument, 1, S_FUNCTION) != type_parameter { return 6; }
    let first = declaration(p, c, a, 0, S_FUNCTION, N_FUNCTION);
    let second = declaration(p, c, a, 0, S_FUNCTION, N_FUNCTION, first);
    let collision = declaration(p, c, q, 0, S_TYPE, N_STRUCT);
    let case_collision = declaration(p, c, upper, 0, S_GLOBAL, N_VARIABLE);
    if check_name_bucket(p, a) != check_name_bucket(p, q) || check_name_bucket(p, a) != check_name_bucket(p, upper) { return 7; }
    if check_lookup_scope(p, c, a, 0) != second || p.symbols[second].next != first { return 8; }
    if check_lookup_scope(p, c, q, 0) != collision || check_lookup_scope(p, c, upper, 0) != case_collision { return 9; }
    if check_lookup_scope(p, c, a, 0, S_TYPE) != -1 || check_lookup_scope(p, c, absent, 0) != -1 { return 10; }
    let third = declaration(p, c, a, 0, S_FUNCTION, N_FUNCTION, second);
    if check_lookup_scope(p, c, a, 0) != third || p.symbols[third].next != second { return 19; }
    var collision_queries: i64[>..] = []; var collision_answers: i64[>..] = []; var bucket_seen: bool[16] = [false; 16];
    for offset in 0..16 {
        let suffix = ('a' as i64 + offset) as u8;
        let left: u8[2] = ['a', suffix]; let right: u8[2] = ['q', suffix];
        let left_token = token(p, left); let right_token = token(p, right);
        let bucket = check_name_bucket(p, left_token);
        if bucket_seen[bucket] || bucket != check_name_bucket(p, right_token) { return 20; }
        bucket_seen[bucket] = true;
        collision_queries.push(left_token); collision_answers.push(declaration(p, c, left_token, 0, S_TYPE, N_STRUCT));
        declaration(p, c, right_token, 0, S_FUNCTION, N_FUNCTION);
    }
    for query, index in collision_queries { if check_lookup_scope(p, c, query, 0) != collision_answers[index] { return 21; } }
    let unnamed = declaration(p, c, -1, 0, S_TYPE, N_TYPE_PARAM);
    if check_lookup_scope(p, c, empty, 0) != unnamed || check_lookup_scope(p, c, 100000, 0) != unnamed { return 11; }
    let detached = declaration(p, c, a, -2, S_FUNCTION, N_FUNCTION);
    if p.symbols[detached].scope_next != -1 || p.symbols[detached].name_next != -1 || check_lookup_scope(p, c, a, 0) != third { return 12; }
    let namespace_token = token(p, "ns"); let separator = token(p, "::"); let member_token = token(p, "member");
    p.tokens[separator].kind = T_COLONCOLON;
    let namespace_symbol = declaration(p, c, namespace_token, 0, 0, N_NAMESPACE, -1, 3);
    let member = declaration(p, c, member_token, 3, S_GLOBAL, N_VARIABLE);
    let qualified = p.nodes.len; p.nodes.push(Node { kind: N_NAME, token: member_token, aux: 2, integer: namespace_token });
    if check_lookup_name(p, c, qualified) != member || baseline_check_lookup_name(p, c, qualified) != member { return 13; }
    if check_lookup_scope(p, c, namespace_token, 0, S_FUNCTION) != -1 { return 14; }
    let merged_namespace = declaration(p, c, namespace_token, 0, 0, N_NAMESPACE, namespace_symbol, 3);
    if check_lookup_scope(p, c, namespace_token, 0) != merged_namespace || p.symbols[merged_namespace].next != namespace_symbol { return 15; }
    let roles: i64[7] = [0, S_FUNCTION, S_TYPE, S_GLOBAL, S_PARAMETER, S_FUNCTION | S_BUILTIN, S_TYPE | S_PARAMETER];
    var comparisons = 0;
    for scope in -2..c.scopes.len + 2 {
        for query in -2..p.tokens.len + 2 {
            for role in roles {
                if check_lookup_scope(p, c, query, scope, role) != baseline_check_lookup_scope(p, c, query, scope, role) { return 16; }
                comparisons += 1;
                if scope >= 0 && scope < c.scopes.len {
                    if check_lookup(p, c, query, scope, role) != baseline_check_lookup(p, c, query, scope, role) { return 17; }
                    comparisons += 1;
                }
            }
        }
    }
    // Exact linear-list order survives separately from bucket and overload links.
    var previous = p.symbols.len; var at = c.scopes[0].first_symbol;
    while at >= 0 { if at >= previous || p.symbols[at].scope != 0 { return 18; } previous = at; at = p.symbols[at].scope_next; }
    print("scope index: explicit shadowing/overload/namespace/generic/parameter/collision cases and ", comparisons, " baseline comparisons passed");
    return 0;
}
'''
(root/'scope-index-fixture.goose').write_text(fixture)
