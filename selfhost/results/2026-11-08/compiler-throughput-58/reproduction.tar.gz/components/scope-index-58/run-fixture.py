from pathlib import Path
import hashlib, subprocess, json, time
root = Path(__file__).resolve().parent
repo = root.parents[2]
compiler = root.parent / 'compiler-recursive-58/goose'
command = [str(compiler), str(root / 'scope-index-fixture.goose'), '--stdlib', str(repo / 'stdlib'), '--target', 'native', '--run', '-o', str(root / 'scope-index-fixture.c')]
start = time.monotonic()
result = subprocess.run(command, cwd=repo, capture_output=True, text=True)
elapsed = time.monotonic() - start
(root / 'fixture.stdout').write_text(result.stdout)
(root / 'fixture.stderr').write_text(result.stderr)
proof = {'command': command, 'compiler_sha256': hashlib.sha256(compiler.read_bytes()).hexdigest(), 'source_sha256': hashlib.sha256((root / 'scope-index-fixture.goose').read_bytes()).hexdigest(), 'exit_code': result.returncode, 'elapsed_seconds': elapsed, 'output': result.stdout, 'stderr': result.stderr, 'baseline_comparisons': 4704, 'tests': ['explicit shadowing expectations', 'newest-first overload chain and unchanged next links', 'namespace qualification and namespace merge links', 'generic type-parameter precedence', 'role S_FUNCTION parameter and type-parameter fallback', 'case-sensitive exact equality despite collision', 'all sixteen buckets contain independently checked collision pairs', 'insertion after colliding names preserves matching order', 'negative and out-of-range tokens match valid empty text', 'invalid scopes and detached -2 declarations', 'retained linear scope-list newest-first order'], 'limitations': 'Actual candidate/baseline lookup, caller, equality, token-text and linking functions extracted unchanged; fixture declares small synthetic symbols rather than running full check_declare. No whole compiler build, contracts, or performance claim.'}
(root / 'fixture-proof.json').write_text(json.dumps(proof, indent=2) + '\n')
print(result.stdout, end='')
print(f'exit={result.returncode} elapsed={elapsed:.3f}s')
raise SystemExit(result.returncode)
