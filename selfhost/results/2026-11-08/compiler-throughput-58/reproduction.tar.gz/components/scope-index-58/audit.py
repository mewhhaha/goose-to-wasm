from pathlib import Path
import re,json,hashlib
root=Path(__file__).resolve().parent
base=root.parent/'compiler-recursive-58/selfhost'
def mask(text):
    return re.sub(r'//[^\n]*|/\*.*?\*/|"(?:\\.|[^"\\])*"',lambda m:re.sub(r'[^\n]',' ',m.group()),text,flags=re.S)
def accesses(text):
    masked=mask(text)
    for m in re.finditer(r'(?:p\.(?:symbols|tokens|text)|c\.scopes)\b',masked):
        at=m.end(); parts=[]
        while at<len(masked):
            while at<len(masked) and masked[at].isspace():at+=1
            if at<len(masked) and masked[at]=='[':
                start=at;depth=1;at+=1
                while at<len(masked) and depth:
                    if masked[at]=='[':depth+=1
                    if masked[at]==']':depth-=1
                    at+=1
                parts.append(masked[start:at]);continue
            field=re.match(r'\.\w+',masked[at:])
            if field:parts.append(field.group());at+=field.end();continue
            break
        if re.match(r'(?:[+*/|&^%-]?=(?!=)|(?:<<|>>)=)',masked[at:]):
            yield {'arena':m.group(),'parts':parts,'line':text.count('\n',0,m.start())+1,'source':text.splitlines()[text.count('\n',0,m.start())].strip()}
def function(text,name):
    start=re.search(r'^(?:inline |recursive )?fn '+name+r'\(',text,re.M).start()
    return text[start:text.index('\n}',start)+3]
old_checker=(base/'checker.goose').read_text();checker=(root/'checker.goose').read_text()
old_model=(base/'model.goose').read_text();model=(root/'model.goose').read_text()
# The full exact-match/role block and its order are the lookup contract.
old_lookup=function(old_checker,'check_lookup_scope')
new_lookup=function(checker,'check_lookup_scope')
normalized=new_lookup.replace('    let bucket = check_name_bucket(p, token);\n','').replace('c.scopes[scope].name_heads[bucket]','c.scopes[scope].first_symbol').replace('let symbol: const Symbol& =','let symbol =').replace('symbol.name_next','symbol.scope_next')
assert normalized==old_lookup
old_declare=function(old_checker,'check_declare')
new_declare=function(checker,'check_declare')
normalized=old_declare.replace('    let id = p.symbols.len; var scope_next = -1;','    let id = p.symbols.len;').replace('    if scope >= 0 { scope_next = c.scopes[scope].first_symbol; }\n','').replace('owner: owner, scope_next: scope_next','owner: owner').replace('    if scope >= 0 { c.scopes[scope].first_symbol = id; }','    check_link_symbol(p, c, id, scope);')
assert normalized==new_declare
assert model==old_model.replace('    provenance: i64 = -1,\n}', '    provenance: i64 = -1,\n    name_next: i64 = -1,\n}',1)
files={path.name:path.read_text() for path in base.glob('*.goose')}
files.update({'checker.goose':checker,'model.goose':model})
inventory=[]
for name,text in sorted(files.items()):
    for entry in accesses(text):entry['file']=name;inventory.append(entry)
key_writes=[w for w in inventory if w['arena']=='p.symbols' and (not w['parts'] or len(w['parts'])==1 or w['parts'][-1]=='.name_token')]
assert not key_writes,key_writes
scope_writes=[w for w in inventory if w['arena']=='c.scopes' and (len(w['parts'])==1 or w['parts'][-1]=='.first_symbol')]
assert len(scope_writes)==1 and scope_writes[0]['file']=='checker.goose' and scope_writes[0]['source']=='c.scopes[scope].first_symbol = symbol;'
token_writes=[w for w in inventory if w['arena']=='p.tokens']
assert len(token_writes)==1 and token_writes[0]['file']=='lexer.goose' and token_writes[0]['source']=='p.tokens[token_id] = t;'
text_writes=[w for w in inventory if w['arena']=='p.text']
assert not text_writes,text_writes
scope_link_writes=[w for w in inventory if w['arena']=='p.symbols' and w['parts'][-1]=='.scope_next']
assert len(scope_link_writes)==1
constructors=[]
for name,text in sorted(files.items()):
    for match in re.finditer(r'p\.symbols\.push\(',text):
        start=match.start();end=text.index(';',start)+1
        constructors.append({'file':name,'line':text.count('\n',0,start)+1,'source':text[start:end]})
assert len(constructors)==6
result={
 'candidate_sha256':{n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in ('model.goose','checker.goose','candidate.patch')},
 'exact_role_predicate_and_order_preserved':True,'declare_other_behavior_exactly_preserved':True,'model_only_adds_Symbol_name_next':True,
 'direct_published_symbol_key_or_whole_record_writes':key_writes,'direct_text_byte_writes':text_writes,
 'all_scope_first_symbol_writes':scope_writes,'all_direct_symbol_scope_next_writes':scope_link_writes,'all_token_record_writes':token_writes,
 'all_symbol_append_sites':constructors,
 'manual_review':[
  'check_declare is the only lexical scope insertion, formerly writing first_symbol and scope_next; single check_link_symbol atomically updates old and new links. Existing node.symbol early return prevents duplicate insertion.',
  'Both CheckScope constructors omit first_symbol/name_heads, retaining -1 defaults. No whole-scope replacements or arena resets. Scope parent/namespace metadata changes do not change the name index.',
  'All three other checker Symbol constructors (generic nominal, builtin, function specialization) use scope=-2 and default both links to -1. Bound generic parameters subsequently use check_declare.',
  'The two optimizer append sites use scope=-2. opt_clone copies Symbol then resets scope_next; its copied name_next is unreachable from checker heads and optimizer runs after check_program. Linear scope and overload chains remain available unchanged.',
  'Published Symbol.name_token is never mutated. Program tokens are finalized by lex_source before source parsing/registration. Its token_id is newly appended in the same loop, not an existing linked symbol key. Synthetic operation/render/name/source tokens copy metadata into new token IDs and append raw bytes.',
  'No existing p.text byte is overwritten or removed. Synthetic/imported text appends can move owners but raw token offsets remain stable. Existing linked name_token is valid or negative; production node tokens come from parsed/finalized tokens, copied nodes, or -1 defaults, never future positive token IDs.',
  'Role flags and node kinds are consulted live with the original exact predicate. Same-name symbols occupy a newest-first subsequence of the full scope list, so collisions only add rejected exact comparisons and do not change shadowing/overload order.',
  'Invalid query scope still returns -1 before hashing; declaration scope=-2 remains detached. Invalid token_text returns empty, matching same_name empty semantics. u32 FNV multiplication wraps in both debug backends; lookup masks 0..15.',
  'const Symbol& in lookup crosses only pure same_name reads, no program arena growth or mutation.'
 ],
 'independent_review':'compiler_ceiling_review found no source blocker and independently audited publication, immutable keys, ordering, role filters, and unsigned hash behavior',
 'tradeoff':'128 bytes per CheckScope plus 8 bytes per Symbol (before grow-array spare capacity); one raw text hash per scope lookup and one per publication; fixed 16 buckets can still degenerate into linear scans under heavy collisions',
 'limits':'Private source audit and extracted-source fixture only. No whole compiler build, contracts, benchmark, or performance claim.',
 'source_sha256':{n:hashlib.sha256(t.encode()).hexdigest() for n,t in sorted(files.items())}
}
(root/'audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'symbol_append_sites':len(constructors),'published_key_writes':len(key_writes),'scope_list_writers':len(scope_writes),'predicate_unchanged':True,'declare_other_behavior_unchanged':True}))
