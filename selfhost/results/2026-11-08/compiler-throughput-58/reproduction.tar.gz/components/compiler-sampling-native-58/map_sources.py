from collections import Counter
import json
from pathlib import Path
import re

root = Path.cwd()
out = root / "build/completion-runs/compiler-sampling-native-58"
compiler = root / "build/completion-runs/compiler-c-literals-58/goose"
c_source = root / "build/completion-runs/compiler-c-literals-58/compiler.c"

symbols = []
for line in __import__("subprocess").check_output(
    ["nm", "-n", "-S", str(compiler)], text=True
).splitlines():
    parts = line.split()
    if len(parts) == 4 and parts[2] in {"t", "T"}:
        symbols.append((int(parts[0], 16), int(parts[1], 16), parts[3]))

counts = {}
for name in ("functions", "mandelbrot"):
    counter = Counter()
    for sample in out.glob(f"sample2-{name}.*.bin"):
        data = sample.read_bytes()
        _base, _end, used, external = __import__("struct").unpack("<4Q", data[:32])
        ips = __import__("struct").unpack("<" + "Q" * used, data[32:])
        for ip in ips:
            address = ip
            low = 0
            high = len(symbols)
            while low < high:
                middle = (low + high) // 2
                if symbols[middle][0] <= address:
                    low = middle + 1
                else:
                    high = middle
            index = low - 1
            if index >= 0 and address < symbols[index][0] + symbols[index][1]:
                counter[symbols[index][2]] += 1
    counts[name] = counter

source_functions = {}
source_decl = re.compile(r"^\s*(?:recursive\s+)?fn\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(")
for source in (root / "build/completion-runs/compiler-c-literals-58/selfhost").rglob("*.goose"):
    declarations = []
    for number, line in enumerate(source.read_text(errors="replace").splitlines(), 1):
        match = source_decl.match(line)
        if match:
            declarations.append((number, match.group(1)))
    source_functions[str(source)] = declarations

function_start = re.compile(r"^static .+\bg_fn(\d+)\(.*\) \{$")
location = re.compile(r'g_element_at\([^;\n]*?"([^"\n]+\.goose)",(\d+)\)')
locations = {}
current_symbol = None
for number, line in enumerate(c_source.open(errors="replace"), 1):
    start = function_start.match(line)
    if start:
        current_symbol = "g_fn" + start.group(1)
        locations.setdefault(current_symbol, Counter())
    if current_symbol is None:
        continue
    for match in location.finditer(line):
        path = match.group(1)
        source_line = int(match.group(2))
        declarations = source_functions.get(path)
        if declarations is None:
            continue
        containing = None
        for declaration_line, name in declarations:
            if declaration_line > source_line:
                break
            containing = (Path(path).name, name, declaration_line)
        if containing:
            locations[current_symbol][containing] += 1

rows = []
primary_totals = {}
target_symbols = {}
for name in ("functions", "mandelbrot"):
    total = sum(counts[name].values())
    for rank, (symbol, samples) in enumerate(counts[name].most_common(), 1):
        candidates = locations.get(symbol, Counter()).most_common(5)
        if candidates:
            primary = candidates[0][0][1]
            primary_totals.setdefault(name, Counter())[primary] += samples
            target_symbols.setdefault(name, {}).setdefault(primary, []).append(
                {"symbol": symbol, "samples": samples, "votes": candidates[0][1]}
            )
        if rank > 20:
            continue
        rows.append(
            {
                "workload": name,
                "symbol": symbol,
                "samples": samples,
                "percent_of_main_samples": round(samples * 100 / total, 2) if total else 0,
                "source_candidates": [
                    {"file": key[0], "function": key[1], "declaration_line": key[2], "location_votes": votes}
                    for key, votes in candidates
                ],
            }
        )

result = {
    "method": "Uninstrumented ITIMER_PROF RIP samples mapped by ELF symbol, then emitted-C g_element_at source locations to nearest Goose fn declaration. Location votes can reflect inlining and are shown for ambiguity; this is a diagnostic profile, not a timing claim.",
    "top_symbols": rows,
    "target_helper_candidates": {
        name: {
            target: [
                {
                    "symbol": symbol,
                    "samples": counts[name].get(symbol, 0),
                    "location_votes": locations[symbol][key],
                }
                for symbol in (set(counts[name]) | set(locations))
                for key in locations.get(symbol, {})
                if key[1] == target
            ]
            for target in ("cc_frame_size", "cc_region_width", "cc_frame_borrows", "cc_field_offset", "cc_needs_clone", "cc_emit_function", "generate_c")
        }
        for name in counts
    },
    "primary_mapped_samples": {
        name: {
            function: {
                "samples": count,
                "percent_of_mapped_main_samples": round(count * 100 / sum(counts[name].values()), 2),
                "symbols": target_symbols[name][function],
            }
            for function, count in primary_totals[name].most_common()
        }
        for name in counts
    },
}
(out / "mapped.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result["primary_mapped_samples"], indent=2))
