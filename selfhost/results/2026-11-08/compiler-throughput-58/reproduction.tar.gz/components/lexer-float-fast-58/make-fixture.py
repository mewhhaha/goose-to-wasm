from pathlib import Path
from fractions import Fraction
from decimal import Decimal
import json,random,re,hashlib
w=Path('build/completion-runs/lexer-float-fast-58');s=(w/'lexer.goose').read_text()
def fraction(text):
 if text.lower().startswith('0x'):
  body,exponent=text[2:].lower().split('p');a,_,b=body.partition('.');n=int(a+b,16);e=int(exponent)-4*len(b)
  if e>=0:return Fraction(n<<e)
  return Fraction(n,1<<-e)
 return Fraction(Decimal(text))
def round_ratio(n,d):
 q,r=divmod(n,d)
 if r*2>d or (r*2==d and q&1):q+=1
 return q
def ieee(text):
 value=fraction(text);n,d=value.numerator,value.denominator
 if n==0:return 0
 e=n.bit_length()-d.bit_length()
 if e>=0:
  if n<d<<e:e-=1
 elif n<<-e<d:e-=1
 if e>1023:return 0x7ff0000000000000
 if e < -1022:
  q=round_ratio(n<<1074,d)
  return q
 shift=52-e
 if shift>=0:q=round_ratio(n<<shift,d)
 else:q=round_ratio(n,d<<-shift)
 if q==1<<53:q>>=1;e+=1
 if e>1023:return 0x7ff0000000000000
 return ((e+1023)<<52)|(q-(1<<52))
def quick(text):
 if text.lower().startswith('0x'):return False
 mantissa,_,exponent=text.lower().partition('e');a,_,b=mantissa.partition('.');significand=int(a+b);power=int(exponent or '0')-len(b)
 # Helper conservatively rejects a huge explicit exponent even if a zero mantissa.
 return significand<=2**53 and -22<=power<=22 and abs(int(exponent or '0'))<=10009
cases=['0.0','0e10000','0e-10000','1.25','0.1','1e-22','1e22','1e-23','1e23','9007199254740992e0','9007199254740993e0','9007199254740991e-22','9007199254740992e22','9007199254740992.0','1.00000000000000011102230246251565404236316680908203125','1.00000000000000033306690738754696212708950042724609375','5e-324','2e-324','3e-324','2.2250738585072014e-308','1.7976931348623157e308','1e309','1e-9999','0x1.00000000000008p0','0x1.00000000000018p0','0x1p-1074','0x1p-1075','0x1p1024']
for power in range(-23,24):
 for significand in [0,1,3,10,1234567,2**52-1,2**53-1,2**53,2**53+1]:cases.append(str(significand)+'e'+str(power))
r=random.Random(580058)
for _ in range(96):cases.append(str(r.randrange(1,2**54))+'e'+str(r.randrange(-25,26)))
cases=list(dict.fromkeys(cases));expected=[dict(text=t,radix=10,bits=ieee(t),quick=quick(t)) for t in cases]
for row in expected:
 if row['text'].startswith('0x'):row['radix']=16
parts=['import std;\n',next(line+'\n' for line in s.splitlines() if line.startswith('inline fn lex_digit(')),s[s.index('fn lex_hex('):s.index('\nfn lex_equal(')],s[s.index('fn lex_big_trim('):]]
parts.append('''
struct Case { text: const u8[:], radix: i64, bits: u64, quick: bool }
fn bits(value: f64) -> u64 {
    let values: f64[1] = [value]; let bytes = bytes_of(values); var result: u64 = 0;
    for byte, i in bytes { result |= (byte as u64) << (i * 8); }
    return result;
}
fn main() {
    let cases = [
''')
for row in expected:parts.append('        Case { text: '+json.dumps(row['text'])+', radix: '+str(row['radix'])+', bits: 0x'+format(row['bits'],'016x')+', quick: '+str(row['quick']).lower()+' },\n')
parts.append('''    ];
    for test in cases {
        var value = 123.25;
        let accepted = lex_float_quick(test.text, value);
        assert(accepted == test.quick);
        if accepted { assert(bits(value) == test.bits); } else { assert(value == 123.25); }
        assert(bits(lex_float(test.text, test.radix)) == test.bits);
        assert(bits(lex_float_slow(test.text, test.radix)) == test.bits);
    }
    for text in ["", "1e", "1e-", "1e-+2", "12.3.4", "+1.0", "-0.0", "nan", "0x1p0"] {
        var value = 123.25; assert(!lex_float_quick(text, value)); assert(value == 123.25);
    }
    print("decimal integer-RNE guards passed");
}
''')
text=''.join(parts);(w/'fixture.goose').write_text(text);(w/'expected.json').write_text(json.dumps(expected,indent=2)+'\n');(w/'fixture-seal.json').write_text(json.dumps(dict(status='frozen-before-any-execution',lexer_sha256=hashlib.sha256(s.encode()).hexdigest(),fixture_sha256=hashlib.sha256(text.encode()).hexdigest(),expected_sha256=hashlib.sha256((w/'expected.json').read_bytes()).hexdigest(),cases=len(expected),stdout='decimal integer-RNE guards passed\n',method='Independent Python Fraction integer ratio and quotient/remainder round-to-nearest-even IEEE754 bit construction; no native float conversion, compiler output capture, C++ oracle, or source expectation updates. Actual original slow and candidate helper/wrapper extracted unchanged.'),indent=2)+'\n');print(len(expected),'frozen cases')
