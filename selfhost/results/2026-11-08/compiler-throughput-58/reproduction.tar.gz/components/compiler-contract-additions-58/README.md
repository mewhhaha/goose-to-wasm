# Compiler contract additions 58

Private strict-recursion-only proposal. `proposal.patch` adds 15 portable fixtures under `tests/fixtures/` and 58 independently frozen cases to `tests/conformance/cases.json`. The canonical tree remains untouched.

Activation additions are intentionally pending the repaired source SHA because the first frozen activation fixture read an uninitialized fixed-array element. The private plain-record structural fixture is excluded.

See `metadata.json` for original manifest and patch fingerprints, fixture source hashes, and every frozen-to-canonical ID/path mapping. No compiler, build, or golden update was run.
