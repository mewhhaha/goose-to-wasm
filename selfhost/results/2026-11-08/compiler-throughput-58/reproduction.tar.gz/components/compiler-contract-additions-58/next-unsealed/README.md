# Strict compiler contract proposal

This private proposal carries the resealed strict-recursion manifest only: 58 rows across 15 fixtures. The three repaired sources are policy, callback-capture-nonlocal, and dispatch-depth. Existing expected outputs are unchanged. Pool default has two Wasm frontend-only `check` rows across levels 0 and 2; it has no Wasm runtime claim.

Baseline57 and candidate A10 both passed all 116 admission checks. Activation and plain-record additions remain pending Sol's CPU3 final report and refreshed pins. The live canonical manifest is unchanged.

See `metadata.json` for exact hashes, report receipts, and old-to-new IDs and paths.
