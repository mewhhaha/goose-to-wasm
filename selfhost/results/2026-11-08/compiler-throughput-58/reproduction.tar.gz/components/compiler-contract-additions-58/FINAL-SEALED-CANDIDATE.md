# Final sealed candidate contract patch

`final-sealed-candidate.patch` adds 74 cases and 18 plain-named fixtures. It combines the admitted strict recursion, native activation, and plain-record language cases. The 4,925 existing case objects remain byte-for-byte unchanged. The patch has not been applied to the canonical manifest.

The two pool Wasm rows are frontend-only `check` cases; the fixture has no Wasm runtime claim. Native structural C-call assertions remain separate backend evidence.

Native rows whose Goose fixture declares `bench_input` carry `native_sources: ["bench/host_input.c"]`. The conformance runner pins those ROOT-relative C sources and links them with `-rdynamic`; rows without the field keep the original link command.

`final-sealed-candidate.json` records source pins, admission receipts, source hashes, all frozen-to-canonical mappings, and the patch SHA256.
