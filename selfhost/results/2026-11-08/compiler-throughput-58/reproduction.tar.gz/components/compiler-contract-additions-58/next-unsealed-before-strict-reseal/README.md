# Next contract proposal (unsealed)

This draft combines 58 strict-recursion cases, 12 repaired activation cases, and 4 plain-record language boundary cases (74 total). It adds 18 portable Goose fixtures.

The old strict-only proposal and metadata remain preserved under `../strict-only-receipt/`. Do not treat this draft as admitted or seal until Sol reports the full CPU3 baseline runtime gate result.

C activation structure assertions are intentionally absent; the plain-record source is included as a language test and its structural assertions remain separate.
