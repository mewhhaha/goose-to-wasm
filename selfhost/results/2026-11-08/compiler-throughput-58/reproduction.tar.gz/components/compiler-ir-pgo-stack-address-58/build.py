from pathlib import Path
import hashlib,json,subprocess,time,os,shutil,concurrent.futures
root=Path.cwd();w=root/'build/completion-runs';out=Path(__file__).resolve().parent

def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def run(cmd,name,cpu=2,env=None):
 start=time.monotonic();p=subprocess.run(['taskset','-c',str(cpu),*map(str,cmd)],cwd=out,capture_output=True,text=True,env=env)
 (out/(name+'.stdout')).write_text(p.stdout);(out/(name+'.stderr')).write_text(p.stderr);r={'command':list(map(str,cmd)),'cwd':str(out),'cpu':cpu,'seconds':time.monotonic()-start,'exit_code':p.returncode};(out/(name+'.json')).write_text(json.dumps(r,indent=2)+'\n');print(name,p.returncode,round(r['seconds'],2),flush=True);assert p.returncode==0,p.stderr
plan=json.loads((w/'compiler-ir-pgo-protocol-58/plan.json').read_text())
training=[{'name':'native','source':'sources/main.goose','target':'native','weight':1},{'name':'leaf','source':str(w/'compiler-subtractive-58/leaf-properties-fixture.goose'),'target':'wasm-direct','weight':64},{'name':'flow','source':str(w/'compiler-subtractive-58/flow-prefilter-fixture.goose'),'target':'wasm-direct','weight':64}]
parent=w/'c-only-bootstrap-58-stack-address'
started=time.monotonic()
while True:
 assert time.monotonic()-started<1200,'Timed out waiting for canonical bootstrap emission'
 report_path=parent/'report.json'
 if report_path.is_file():
  baseline=json.loads(report_path.read_text())
  assert baseline['status']!='failed',baseline
  if any(r.get('name')=='verify-selfhost' and r['exit_code']==0 for r in baseline['commands']):break
 time.sleep(1)
shutil.copyfile(parent/'next-generation.c',out/'seed.c')
print('Canonical new-runtime C available for IR training',sha(out/'seed.c'),flush=True)
protocol={'schema':'goose-IR-pgo-training-v1','plan_sha256':sha(w/'compiler-ir-pgo-protocol-58/plan.json'),'c_sha256':sha(out/'seed.c'),'input_pins_sha256':sha(out/'input-pins.json'),'clang_sha256':sha(Path(shutil.which('clang-23')).resolve()),'profdata_sha256':sha(Path(shutil.which('llvm-profdata')).resolve()),'training':training,'training_source_sha256':{r['name']:sha(out/r['source']) for r in training},'base_flags':['-std=gnu11','-O2','-lm','-ldl','-pthread'],'c_basename':'seed.c','timed_inputs_used_for_training':False,'generation':'-fprofile-generate LLVM IR, _Exit wrapper training-only','canonical_C_bootstrap_linkage':'Pending final public stack-address bootstrap fixedpoint; equality required before training.'}
(out/'training-protocol.json').write_text(json.dumps(protocol,indent=2)+'\n');(out/'raw').mkdir()
(out/'profile-exit.c').write_text('#include <stdlib.h>\nint __llvm_profile_write_file(void);\n_Noreturn void __real__Exit(int);\n_Noreturn void __wrap__Exit(int code){__llvm_profile_write_file();__real__Exit(code);}\n')
base=['clang-23','-std=gnu11','-O2','seed.c','-lm','-ldl','-pthread']
run([*base,'-fprofile-generate','profile-exit.c','-Wl,--wrap=_Exit','-o','goose-train'],'instrumented-build',6)
# Reuse the exact public bootstrap's plain executable and fixedpoint receipt,
# rather than rebuilding or repeating its already-required self verification.
started=time.monotonic()
while True:
 baseline=json.loads((parent/'report.json').read_text())
 assert baseline['status']!='failed',baseline
 if baseline['status']=='passed':break
 assert time.monotonic()-started<1200
 time.sleep(1)
assert baseline['fixed_point'] and baseline['executable_c_sha256']==sha(out/'seed.c')
assert baseline['executable_sha256']==sha(parent/'goose')
shutil.copy2(parent/'goose',out/'goose-plain')
(out/'plain-bootstrap-linkage.json').write_text(json.dumps({'status':'passed','bootstrap_report_sha256':sha(parent/'report.json'),'C_sha256':sha(out/'seed.c'),'executable_sha256':sha(out/'goose-plain'),'method':'Exact completed public C-only bootstrap fixedpoint and plain ELF reused; no redundant rebuild/selfverify.'},indent=2)+'\n')
raw=[]
for row in training:
 env=os.environ.copy();env['LLVM_PROFILE_FILE']=str(out/'raw'/(row['name']+'-%p.profraw'))
 run([out/'goose-train',row['source'],'--stdlib','stdlib','--target',row['target'],'-O2','-o',str(out/('training-'+row['name']+'.out'))],'train-'+row['name'],env=env)
 files=list((out/'raw').glob(row['name']+'-*.profraw'));assert len(files)==1;raw.append((row['weight'],files[0]))
 if row['target']=='wasm-direct':
  import wasmtime
  wasmtime.Module.validate(wasmtime.Engine(),(out/('training-'+row['name']+'.out')).read_bytes())
assert len(list((out/'raw').glob('*.profraw')))==3 and sha(out/'training-native.out')==sha(out/'seed.c')
run(['llvm-profdata','merge','-o','profile.profdata',*['-weighted-input='+str(weight)+','+str(path) for weight,path in raw]],'merge-profile')
run(['llvm-profdata','show','profile.profdata'],'profile-summary')
assert 'Instrumentation level: IR' in (out/'profile-summary.stdout').read_text()
meta={'schema':'goose-bootstrap-profile-v1','c_sha256':sha(out/'seed.c'),'clang_major':23,'target':subprocess.check_output(['clang-23','-dumpmachine'],text=True).strip(),'base_flags':protocol['base_flags'],'c_basename':'seed.c','data_sha256':sha(out/'profile.profdata')};(out/'profile.json').write_text(json.dumps(meta,indent=2)+'\n')
run([*base,'-fprofile-instr-use='+str(out/'profile.profdata'),'-Werror=profile-instr-out-of-date','-Werror=profile-instr-missing','-Werror=profile-instr-unprofiled','-o','goose-pgo'],'optimized-build')
run([out/'goose-pgo','sources/main.goose','--stdlib','stdlib','--target','native','-O2','-o','verify-pgo.c'],'verify-pgo')
assert sha(out/'verify-pgo.c')==sha(out/'seed.c')
for name,value in json.loads((out/'input-pins.json').read_text()).items():assert sha(out/name)==value,name
(out/'fixedpoint.json').write_text(json.dumps({'status':'passed','c_sha256':sha(out/'seed.c'),'plain_sha256':sha(out/'goose-plain'),'pgo_sha256':sha(out/'goose-pgo'),'profile_sha256':sha(out/'profile.profdata'),'IR':True,'strict_profile_use':True,'fixed_point':True,'construction_timing':'Training compiler overlapped public plain bootstrap; construction wall times are not isolated comparisons','canonical_C_bootstrap_linkage':{'status':'passed','bootstrap_report_sha256':sha(parent/'report.json'),'exact_C':sha(out/'seed.c')==baseline['executable_c_sha256']}},indent=2)+'\n');print('A22 canonical IR-PGO fixedpoint PASS',flush=True)
