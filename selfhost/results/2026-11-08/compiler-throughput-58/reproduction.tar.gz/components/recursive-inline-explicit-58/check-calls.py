#!/usr/bin/env python3
"""Check frozen inlining-policy contracts in emitted C, without a C++ oracle."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--compiler', type=Path, required=True)
parser.add_argument('--stdlib', type=Path, required=True)
parser.add_argument('--output-dir', type=Path, required=True)
args = parser.parse_args()
args.output_dir.mkdir(parents=True, exist_ok=False)
report = {'method': 'Inspect actual emitted C calls using function IDs from the checked IR; no reference compiler.',
          'compiler_sha256': hashlib.sha256(args.compiler.read_bytes()).hexdigest(), 'commands': [], 'results': []}

def run(command):
    result = subprocess.run(list(map(str, command)), capture_output=True, text=True, timeout=60)
    report['commands'].append({'command': list(map(str, command)), 'exit': result.returncode,
                               'stderr': result.stderr})
    if result.returncode:
        raise RuntimeError(result.stderr)
    return result.stdout

def function_ids(ir):
    tokens = {item['id']: item['text'] for item in ir['tokens']}
    nodes = {item['id']: item for item in ir['nodes']}
    result = {}
    for symbol in ir['symbols']:
        if symbol['flags'] & 1 and symbol['node'] >= 0 and nodes[symbol['node']]['origin'] < 0:
            result[tokens[symbol['name_token']]] = symbol['node']
    return result

def bodies(text):
    starts = list(re.finditer(r'(?m)^static[^\n]* g_fn(\d+)\([^\n]*\) \{', text))
    result = {}
    for index, match in enumerate(starts):
        end = len(text)
        if index + 1 < len(starts):
            end = starts[index + 1].start()
        result[int(match[1])] = text[match.end():end]
    return result

contracts = {
    'policy': [('driver', 'hinted', False), ('driver', 'automatic', True), ('driver', 'separate', True)],
    'direct-recursion': [('driver', 'recur', True), ('recur', 'recur', True)],
    'indirect-cycle': [('cycle', 'bridge', True), ('bridge', 'cycle', True)],
}
try:
    for name, checks in contracts.items():
        source = ROOT / (name + '.goose')
        command = [args.compiler.resolve(), source, '--stdlib', args.stdlib.resolve(), '--target', 'native']
        ir = json.loads(run([*command, '--dump-ir']))
        names = function_ids(ir)
        for level in (0, 2):
            for debug in (False, True):
                output = args.output_dir / f'{name}-O{level}-debug{debug}.c'
                flags = []
                if debug:
                    flags.append('--debug')
                run([*command, f'-O{level}', *flags, '-o', output])
                generated = bodies(output.read_text())
                for caller, callee, optimized in checks:
                    expected = True
                    if level == 2:
                        expected = optimized
                    actual = re.search(r'\bg_fn' + str(names[callee]) + r'\(', generated[names[caller]]) is not None
                    row = {'fixture': name, 'level': level, 'debug': debug, 'caller': caller,
                           'callee': callee, 'expected_call': expected, 'actual_call': actual,
                           'passed': actual == expected}
                    report['results'].append(row)
                    if actual != expected:
                        raise AssertionError(row)
    report['status'] = 'passed'
except BaseException as error:
    report['status'] = 'failed'
    report['error'] = str(error)
    raise
finally:
    (args.output_dir / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
