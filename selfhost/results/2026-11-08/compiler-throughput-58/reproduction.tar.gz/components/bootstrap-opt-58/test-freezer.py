from pathlib import Path
import hashlib,json,subprocess,sys,tempfile
here=Path(__file__).resolve().parent;rows=[]
for level in [None,0,2]:
 with tempfile.TemporaryDirectory() as directory:
  root=Path(directory);stage=root/'stage';stage.mkdir();sources=stage/'sources';sources.mkdir();stdlib=stage/'stdlib';stdlib.mkdir()
  (sources/'main.goose').write_text('fn main() {}\n');(stdlib/'base.goose').write_text('// stdlib\n');c=b'/* frozen C */\n';(stage/'compiler.c').write_bytes(c);sha=lambda b:hashlib.sha256(b).hexdigest()
  report=dict(status='passed',fixed_point=True,executable_c_sha256=sha(c),source_sha256={'main.goose':sha((sources/'main.goose').read_bytes())},stdlib_sha256={'base.goose':sha((stdlib/'base.goose').read_bytes())},seed_c_sha256='parent',generated_c_sha256=sha(c))
  if level is not None:report['goose_optimization']=level
  (stage/'report.json').write_text(json.dumps(report));output=root/'seed';command=[sys.executable,str(here/'durable-tools/freeze_seed.py'),str(stage),str(output)];r=subprocess.run(command,capture_output=True,text=True);assert r.returncode==0,r.stderr
  pin=json.loads((output/'seed.json').read_text());expected=level
  if expected is None:expected=0
  assert pin['goose_optimization']==expected,pin;assert pin['c_sha256']==sha(c);rows.append(dict(input_level=level,output_level=pin['goose_optimization'],passed=True))
(here/'freezer-tests.json').write_text(json.dumps(dict(status='passed',rows=rows),indent=2)+'\n');print(rows)
