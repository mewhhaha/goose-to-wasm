from pathlib import Path
import gzip,hashlib,io,json,tarfile,sys
stage=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(exist_ok=False)
r=json.loads((stage/'report.json').read_text());assert r['status']=='passed' and r['fixed_point']
def sha(data):return hashlib.sha256(data).hexdigest()
candidates=[stage/n for n in ('third-generation.c','next-generation.c','compiler.c')]
c=next(p.read_bytes() for p in candidates if p.is_file() and sha(p.read_bytes())==r['executable_c_sha256'])
compressed=gzip.compress(c,mtime=0);(out/'seed.c.gz').write_bytes(compressed)
files={}
for p in (stage/'sources').glob('*.goose'):files['compiler/'+p.name]=p
for p in (stage/'stdlib').rglob('*.goose'):files['stdlib/'+str(p.relative_to(stage/'stdlib'))]=p
for name in r.get('asset_sha256',{}):files[name]=stage/name
files['LICENSE']=Path('/home/jacobt/src/goose-to-wasm/LICENSE')
for name in ('LICENSE','NOTICE'):files['native/runtime/'+name]=Path('/home/jacobt/src/goose-to-wasm/native/runtime')/name
raw=io.BytesIO()
with tarfile.open(fileobj=raw,mode='w') as archive:
 for name,p in sorted(files.items()):
  data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;archive.addfile(info,io.BytesIO(data))
bundle=gzip.compress(raw.getvalue(),mtime=0);(out/'sources.tar.gz').write_bytes(bundle)
pin={'schema':'goose-bootstrap-seed-v1','language':'C11','producer':'Goose-written compiler through C-only bootstrap','c_sha256':sha(c),'compressed_sha256':sha(compressed),'source_bundle_sha256':sha(bundle),'source_sha256':r['source_sha256'],'stdlib_sha256':r['stdlib_sha256'],'asset_sha256':r.get('asset_sha256',{}),'goose_optimization':r.get('goose_optimization',0),'proof':{'fixed_point':True,'parent_seed_c_sha256':r['seed_c_sha256'],'stage1_c_sha256':r['generated_c_sha256'],'stage2_c_sha256':r.get('next_generation_c_sha256'),'stage3_c_sha256':r.get('third_generation_c_sha256')},'note':'Final two C generations match. This seed is generated without a C++ compiler.'}
(out/'seed.json').write_text(json.dumps(pin,indent=2)+'\n');(out/'proof.json').write_text(json.dumps(r,indent=2)+'\n');print(out,sha(c))
