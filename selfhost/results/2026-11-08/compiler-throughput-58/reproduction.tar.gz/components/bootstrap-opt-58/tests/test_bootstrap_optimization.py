#!/usr/bin/env python3
"""Bootstrap optimization must describe emitted C, including old seeds."""
import contextlib
import gzip
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]


def load(relative):
    spec = importlib.util.spec_from_file_location('bootstrap_under_test', ROOT / relative)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def sha(data):
    return hashlib.sha256(data).hexdigest()


class BootstrapOptimizationTests(unittest.TestCase):
    def stage(self, seed_level, requested=None, verify=False, converge=False, seed_only=False):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / 'selfhost'; source.mkdir()
            (source / 'main.goose').write_text('fn main() {}\n')
            stdlib = root / 'stdlib'; stdlib.mkdir()
            (stdlib / 'base.goose').write_text('// library\n')
            seed = root / 'seed'; seed.mkdir()
            c = b'/* seed */\n'
            compressed = gzip.compress(c, mtime=0)
            (seed / 'seed.c.gz').write_bytes(compressed)
            raw = io.BytesIO()
            with tarfile.open(fileobj=raw, mode='w') as archive:
                data = (stdlib / 'base.goose').read_bytes()
                info = tarfile.TarInfo('stdlib/base.goose'); info.size = len(data)
                archive.addfile(info, io.BytesIO(data))
            bundle = gzip.compress(raw.getvalue(), mtime=0)
            (seed / 'sources.tar.gz').write_bytes(bundle)
            pin = dict(c_sha256=sha(c), compressed_sha256=sha(compressed),
                       source_bundle_sha256=sha(bundle),
                       source_sha256={'main.goose': sha((source / 'main.goose').read_bytes())})
            if seed_level is not None:
                pin['goose_optimization'] = seed_level
            (seed / 'seed.json').write_text(json.dumps(pin))
            cc = root / 'cc'; cc.write_bytes(b'fake C compiler\n'); cc.chmod(0o755)
            output = root / 'output'
            module = load('selfhost/bootstrap.py'); module.ROOT = root
            commands = []; emissions = []

            def run(argv, **kwargs):
                argv = list(map(str, argv)); commands.append(argv)
                if argv[0] == str(cc):
                    if argv[1:] == ['--version']:
                        return subprocess.CompletedProcess(argv, 0, b'fake cc\n', b'')
                    Path(argv[argv.index('-o') + 1]).write_bytes(b'fake executable\n')
                else:
                    emissions.append(argv)
                    data = b'/* generated */\n'
                    if converge and len(emissions) == 1:
                        data = b'/* first generation */\n'
                    Path(argv[argv.index('-o') + 1]).write_bytes(data)
                return subprocess.CompletedProcess(argv, 0, b'', b'')

            args = ['bootstrap', '--source-dir', str(source), '--seed-dir', str(seed),
                    '--stdlib', str(stdlib), '--native-dir', str(root / 'native'),
                    '--output-dir', str(output), '--cc', str(cc)]
            if requested is not None:
                args += ['--optimization', str(requested)]
            if verify:
                args += ['--verify']
            if seed_only:
                args += ['--seed-only']
            with patch.object(sys, 'argv', args), patch.object(module.subprocess, 'run', run), contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(module.main(), 0)
            report = json.loads((output / 'report.json').read_text())
            self.assertEqual(report['status'], 'passed')
            self.assertEqual(report['input_sha256'], report['input_sha256_after'])
            for command in commands:
                if command[0] == str(cc) and command[1:] != ['--version']:
                    self.assertIn('-O2', command)
            return report, emissions

    def test_zero_seed_requested_two_reemits_and_verifies_every_generation(self):
        report, commands = self.stage(0, verify=True, converge=True)
        self.assertFalse(report.get('seed_matches_sources', False))
        self.assertEqual(report['goose_optimization'], 2)
        self.assertTrue(report['fixed_point'])
        self.assertEqual(len(commands), 3)
        for command in commands:
            self.assertIn('-O2', command)
            self.assertNotIn('-O0', command)

    def test_matching_optimized_seed_reuses_c(self):
        report, commands = self.stage(2)
        self.assertTrue(report['seed_matches_sources'])
        self.assertEqual(report['goose_optimization'], 2)
        self.assertEqual(commands, [])

    def test_old_seed_missing_level_is_zero(self):
        for seed_level in (None, 0):
            with self.subTest(seed_level=seed_level):
                report, commands = self.stage(seed_level, requested=0)
                self.assertTrue(report['seed_matches_sources'])
                self.assertEqual(report['goose_optimization'], 0)
                self.assertEqual(commands, [])
        report, commands = self.stage(None)
        self.assertEqual(report['goose_optimization'], 2)
        self.assertEqual(len(commands), 1)
        self.assertFalse(report.get('seed_matches_sources', False))

    def test_level_one_is_forwarded(self):
        report, commands = self.stage(0, requested=1, verify=True)
        self.assertEqual(report['goose_optimization'], 1)
        self.assertEqual(len(commands), 2)
        self.assertTrue(all('-O1' in command for command in commands))

    def test_seed_only_reports_actual_seed_level(self):
        for seed_level, expected in [(None, 0), (2, 2)]:
            with self.subTest(seed_level=seed_level):
                report, commands = self.stage(seed_level, seed_only=True)
                self.assertEqual(report['goose_optimization'], expected)
                self.assertEqual(report['requested_goose_optimization'], 2)
                self.assertEqual(commands, [])

    def test_installer_forwards_level_and_records_actual_report(self):
        for requested, report_level in [(None, 2), (0, 0), (1, 1), (None, None)]:
            with self.subTest(requested=requested, report_level=report_level), tempfile.TemporaryDirectory() as directory:
                root = Path(directory); library = root / 'stdlib'; library.mkdir()
                (library / 'base.goose').write_text('// stdlib\n')
                build = root / 'build'; module = load('scripts/bootstrap.py'); module.ROOT = root
                captured = []

                def run(argv, **kwargs):
                    captured.append(argv)
                    stage = Path(argv[argv.index('--output-dir') + 1]); stage.mkdir(parents=True)
                    (stage / 'goose').write_bytes(b'fake executable\n')
                    report = dict(executable_sha256=sha(b'fake executable\n'), source_sha256={},
                                  stdlib_sha256={}, asset_sha256={}, cc='fake cc', cc_sha256='cc hash', seed_c_sha256='seed hash')
                    if report_level is not None:
                        report['goose_optimization'] = report_level
                    (stage / 'report.json').write_text(json.dumps(report))
                    return subprocess.CompletedProcess(argv, 0)

                args = ['bootstrap', '--build-dir', str(build)]
                if requested is not None:
                    args += ['--optimization', str(requested)]
                with patch.object(sys, 'argv', args), patch.object(module.subprocess, 'run', run), contextlib.redirect_stdout(io.StringIO()):
                    self.assertEqual(module.main(), 0)
                expected = requested
                if expected is None:
                    expected = 2
                self.assertEqual(captured[0][captured[0].index('--optimization') + 1], str(expected))
                expected_metadata = report_level
                if expected_metadata is None:
                    expected_metadata = 0
                metadata = json.loads((build / 'toolchain.json').read_text())
                self.assertEqual(metadata['goose_optimization'], expected_metadata)
                self.assertTrue((build / 'bin/goose').is_file())
                self.assertTrue((build / 'bin/stdlib/base.goose').is_file())


if __name__ == '__main__':
    unittest.main()
