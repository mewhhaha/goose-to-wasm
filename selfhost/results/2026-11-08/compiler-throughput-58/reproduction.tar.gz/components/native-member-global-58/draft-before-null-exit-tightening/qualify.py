#!/usr/bin/env python3
"""Private native-member guards; fixed expectations, no update mode."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

ROOT = Path('/home/jacobt/src/goose-to-wasm')
HERE = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def body(text, identity):
    match = re.search(r'\bg_fn' + str(identity) + r'\([^;]*?\)\s*\{', text)
    assert match, identity
    start = match.end()
    at = start
    depth = 1
    while depth:
        if text.startswith('//', at):
            at = text.index('\n', at)
            continue
        if text.startswith('/*', at):
            at = text.index('*/', at + 2) + 2
            continue
        char = text[at]
        if char in ['"', "'"]:
            quote = char
            at += 1
            while text[at] != quote:
                if text[at] == '\\':
                    at += 1
                at += 1
        elif char == '{':
            depth += 1
        elif char == '}':
            depth -= 1
        at += 1
    return text[start:at - 1]


def functions(ir):
    return {ir['tokens'][n['token']]['text']: n['id'] for n in ir['nodes']
            if n['kind'] == 3 and n['token'] >= 0 and ir['tokens'][n['token']]['source'] == 0}


def gate(ir, library):
    nodes = ir['nodes']
    types = ir['types']
    exports = []
    casts = []
    relative = []
    malformed = []
    for n in nodes:
        if n['kind'] in [3, 43] and n['flags'] & 4:
            exports.append(n['id'])
        if n['kind'] == 45:
            left = n['left']
            if left < 0 or left >= len(nodes):
                malformed.append(n['id'])
                continue
            source = nodes[left]['type_id']
            target = n['type_id']
            if target >= 0 and types[target]['kind'] == 7 or source >= 0 and types[source]['kind'] == 7:
                casts.append(n['id'])
    for t in types:
        if t['kind'] == 7 and t['length_storage'] >= 0:
            relative.append(t['id'])
    return {'enabled': not (library or exports or casts or relative or malformed),
            'export_function_ids': exports, 'ref_cast_ids': casts,
            'relative_type_ids': relative, 'malformed_cast_ids': malformed}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--compiler', type=Path, default=ROOT / 'build/completion-runs/compiler-native-members-v2-58/goose')
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--stage', choices=['all', 'runtime', 'structure', 'sanitizers'], default='all')
    parser.add_argument('--expect-old', action='store_true', help='Validate structural guard on frozen parent emission only')
    args = parser.parse_args()
    os.sched_setaffinity(0, {1})
    compiler = args.compiler.resolve()
    assert compiler.is_file(), compiler
    output = args.output_dir.resolve()
    output.mkdir(exist_ok=False)
    plan = json.loads((HERE / 'guard-plan.json').read_text())
    extension = json.loads((HERE / 'qualification-protocol.json').read_text())
    for relative, digest in extension['input_sha256'].items():
        assert sha(ROOT / relative) == digest, relative
    report = {'status': 'running', 'compiler': str(compiler), 'compiler_sha256': sha(compiler),
              'expect_old': args.expect_old, 'stage': args.stage, 'commands': [],
              'runtime': [], 'gate_rows': [], 'structure': [], 'sanitizers': [], 'null_harness': []}
    save(output / 'report.json', report)

    def execute(name, command, expected_exit=0):
        command = list(map(str, command))
        result = subprocess.run(command, cwd=ROOT, stdin=subprocess.DEVNULL,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=120)
        (output / (name + '.stdout')).write_bytes(result.stdout)
        (output / (name + '.stderr')).write_bytes(result.stderr)
        row = {'name': name, 'command': command, 'exit_code': result.returncode,
               'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(),
               'stderr_sha256': hashlib.sha256(result.stderr).hexdigest()}
        report['commands'].append(row)
        save(output / 'report.json', report)
        if expected_exit == 0:
            assert result.returncode == 0, (name, result.stderr.decode(errors='replace'))
        return result

    try:
        if args.stage in ['all', 'runtime']:
            for number, case in enumerate(extension['runtime_campaigns']):
                destination = output / case['name']
                command = ['python', '-B', ROOT / 'tests/conformance.py', '--compiler', compiler,
                           '--manifest', HERE / case['manifest'], '--output-dir', destination,
                           '--engine', case['engine'], '--timeout', '60']
                execute('runtime-' + str(number), command)
                receipt = json.loads((destination / 'report.json').read_text())
                assert receipt['status'] == 'passed', case['name']
                report['runtime'].append({'name': case['name'], 'summary': receipt['summary'],
                                          'report_sha256': sha(destination / 'report.json')})
            # The old kit's values source contains an encoded relative type, so all its
            # member expressions must retain OLD lowering. Reuse old baseline-mode
            # per-expression checks, never old N_NAME-only candidate predictions.
            execute('old-kit-structure', ['python', '-B', HERE / 'check-existing-structure.py',
                    '--runtime-report', output / 'existing-wasmtime/report.json',
                    '--output-dir', output / 'existing-structure'])
            old = json.loads((output / 'existing-structure/report.json').read_text())
            assert old['status'] == 'passed' and old['checks'] == 64
            report['existing_structural_checks'] = old['checks']

        emitted = []
        if args.stage in ['all', 'structure', 'sanitizers']:
            for case in plan['structural_expectations']:
                source = HERE / 'guards' / case['source']
                for level in [0, 2]:
                    for debug in [False, True]:
                        label = source.stem + '-O' + str(level) + '-debug-' + str(debug)
                        flags = list(case.get('compiler_flags', []))
                        if debug:
                            flags.append('--debug')
                        command = [compiler, source, '--target', 'native', '--stdlib', ROOT / 'stdlib', '-O' + str(level), *flags]
                        ir_result = execute('ir-' + label, command + ['--dump-ir'])
                        ir = json.loads(ir_result.stdout)
                        census = gate(ir, '--library' in flags)
                        gate_row = {'source': case['source'], 'level': level, 'debug': debug,
                                    'expected': case['gate'], **census}
                        report['gate_rows'].append(gate_row)
                        assert census['enabled'] == case['gate'], gate_row
                        artifact = output / (label + '.c')
                        execute('emit-' + label, command + ['--standalone', '-o', artifact])
                        text = artifact.read_text()
                        fn = functions(ir)
                        emitted.append({'source': source, 'level': level, 'debug': debug,
                                        'artifact': artifact, 'ir': ir, 'functions': fn, 'case': case})
                        for name, prediction in case['functions'].items():
                            if prediction.get('kind') == 'unused_body_not_emitted':
                                checks = {'parent_confirmed_unused_body_not_emitted': not re.search(r'\bg_fn' + str(fn[name]) + r'\(', text),
                                          'unused_ref_cast_still_disables_gate': not census['enabled'] and bool(census['ref_cast_ids'])}
                                structural = {'source': case['source'], 'function': name, 'level': level,
                                              'debug': debug, 'C_sha256': sha(artifact), 'checks': checks,
                                              'passed': all(checks.values())}
                                report['structure'].append(structural)
                                save(output / 'report.json', report)
                                assert structural['passed'], structural
                                continue
                            part = body(text, fn[name])
                            fast = re.findall(r'g_v(\d+)=g_ref\(g_address\(g_v(\d+)\)\+(\d+)\);', part)
                            old = re.findall(r'g_v(\d+)=g_offset\(g_v(\d+),(\d+)\);', part)
                            active = fast
                            if args.expect_old:
                                active = old
                            checks = {}
                            kind = prediction.get('kind')
                            if kind in ['fast_positive', 'g_ref(g_address(saved_base)+1), no scalar field load']:
                                offset = str(prediction['offset'])
                                addresses = [(result, base) for result, base, off in active if off == offset]
                                checks['attributed_member_address'] = bool(addresses)
                                if name == 'owner':
                                    checks['both_owned_header_member_addresses'] = len(addresses) == 2
                                if name in ['owner', 'indexed', 'fixed']:
                                    checks['array_bounds_helper_retained'] = 'g_element_at(' in part
                                if name == 'indexed':
                                    elements = re.findall(r'g_v(\d+)=g_element_at\(', part)
                                    checks['member_uses_checked_element_saved_address'] = any(base in elements for result, base in addresses)
                                if name == 'effect_once':
                                    checks['base_call_exactly_once'] = len(re.findall(r'\bg_fn' + str(fn['fetch']) + r'\(', part)) == 1
                                if name == 'later_address':
                                    checks['address_only_no_scalar_field_read'] = all('g_load_5(g_v' + result + ');' not in part for result, base in addresses)
                            elif kind == 'fast_positive_each_attributed_member':
                                links = [([], None)]
                                for offset in prediction['offsets']:
                                    links = [(chain + [result], result) for chain, previous in links
                                             for result, base, off in active
                                             if off == str(offset) and (previous is None or base == previous)]
                                checks['nested_member_chain_exact_offsets'] = bool(links)
                            elif kind == 'copy_saved_base_no_g_address':
                                if args.expect_old:
                                    checks['parent_zero_offset_address'] = any(off == '0' for result, base, off in old)
                                else:
                                    checks['zero_offset_saved_base_copy'] = bool(re.search(r'g_v\d+=g_v\d+;', part))
                                    checks['no_zero_offset_g_address_null_check'] = 'g_address(' not in part
                            elif kind and kind.startswith('old_g_offset'):
                                offsets = [result for result, base, off in old if off == str(prediction['offset'])]
                                checks['attributed_old_offset_retained'] = bool(offsets)
                                checks['no_fast_replacement_for_same_offset'] = not any(off == str(prediction['offset']) for result, base, off in fast)
                                if prediction['offset'] == 64:
                                    checks['address_only_no_scalar_load'] = all('g_load_5(g_v' + result + ');' not in part for result in offsets)
                                    wide = [t['id'] for t in ir['types'] if t['kind'] == 8 and t['declaration'] >= 0 and ir['tokens'][ir['nodes'][t['declaration']]['token']]['text'] == 'Wide']
                                    checks['no_inferred_wide_aggregate_copy'] = bool(wide) and all('g_load_' + str(t) + '(' not in part for t in wide)
                            elif kind == 'unchanged_CC_IMAGE_branch':
                                checks['image_helpers_retained'] = 'g_image_' in part
                            elif name == 'zero_width':
                                zero = [t['id'] for t in ir['types'] if t['kind'] == 8 and t['declaration'] >= 0 and ir['tokens'][ir['nodes'][t['declaration']]['token']]['text'] == 'Zero']
                                assert len(zero) == 1
                                oldzero = [result for result, base, off in old if off == '0']
                                checks['zero_width_member_keeps_old_offset'] = any('g_load_' + str(zero[0]) + '(g_v' + result + ');' in part for result in oldzero)
                                copies = re.findall(r'g_v(\d+)=g_v\d+;', part)
                                if args.expect_old:
                                    copies = oldzero
                                checks['nonzero_width_zero_offset_member'] = any('g_load_5(g_v' + result + ');' in part for result in copies)
                            else:
                                raise AssertionError(prediction)
                            structural = {'source': case['source'], 'function': name, 'level': level,
                                          'debug': debug, 'C_sha256': sha(artifact), 'checks': checks,
                                          'passed': all(checks.values())}
                            report['structure'].append(structural)
                            save(output / 'report.json', report)
                            assert structural['passed'], structural
                        # Independently fixed source geometry; compare actual native C object frames.
                        if case['source'] == 'positive.goose':
                            dimensions = {'Packed': 9, 'Owned': 25, 'Inner': 10, 'Outer': 18, 'Large': 264, 'WithZero': 8}
                            for type_name, size in dimensions.items():
                                ids = [t['id'] for t in ir['types'] if t['kind'] == 8 and t['declaration'] >= 0 and ir['tokens'][ir['nodes'][t['declaration']]['token']]['text'] == type_name]
                                assert len(ids) == 1, (type_name, ids)
                                assert re.search(r'typedef struct \{ unsigned char data\[' + str(size) + r'\]; \} g_t' + str(ids[0]) + r';', text), (type_name, size)
            assert len(report['gate_rows']) == 36 and len(report['structure']) == 80

        if args.stage in ['all', 'sanitizers']:
            manifest = json.loads((HERE / 'guards/cases.json').read_text())
            expectations = {Path(c['source']).name: c['expect'] for c in manifest['cases']}
            for item in emitted:
                if item['source'].name == 'library.goose' or (item['level'], item['debug']) not in [(0, False), (2, True)]:
                    continue
                label = 'sanitize-' + item['artifact'].stem
                binary = output / label
                command = ['clang-23', '-std=gnu11', '-O1', '-g', '-fsanitize=address,undefined,pointer-overflow',
                           '-fno-sanitize-recover=all', '-fno-omit-frame-pointer', item['artifact'], '-lm', '-ldl', '-pthread', '-o', binary]
                execute(label + '-cc', command)
                result = execute(label, [binary])
                expected = expectations[item['source'].name]
                assert result.stdout.decode() == expected['stdout'] and result.stderr == b''
                report['sanitizers'].append({'source': item['source'].name, 'level': item['level'], 'debug': item['debug'], 'passed': True})
            # The old sanitizer kit includes typed Wide address-only and both null controls.
            if (output / 'existing-wasmtime/report.json').exists():
                execute('existing-sanitizers', ['python', '-B', HERE / 'check-existing-sanitizers.py',
                        '--runtime-report', output / 'existing-wasmtime/report.json', '--output-dir', output / 'existing-sanitizers'])
                report['existing_sanitizer_profiles'] = 8
            c_profiles = [('clang-O0', ['clang-23', '-std=gnu11', '-O0']),
                          ('clang-O2', ['clang-23', '-std=gnu11', '-O2']),
                          ('gcc-O2', ['gcc', '-std=gnu11', '-O2']),
                          ('clang-SAN', ['clang-23', '-std=gnu11', '-O1', '-g', '-fsanitize=address,undefined,pointer-overflow', '-fno-sanitize-recover=all'])]
            for item in emitted:
                if item['source'].name != 'positive.goose':
                    continue
                label = 'null-O' + str(item['level']) + '-debug-' + str(item['debug'])
                wrapper = output / (label + '.c')
                first = item['functions']['first_address']
                later = item['functions']['later_address']
                wrapper.write_text('#define main member_original_main\n#include ' + json.dumps(str(item['artifact'])) + '\n#undef main\n' +
                    'int main(int argc,char **argv){g_argc=argc;g_argv=argv;g_initialize();\n' +
                    'if(argc>1){(void)g_fn' + str(later) + '(NULL,g_global_regions,(GRef)0);return 0;}\n' +
                    'GRef value=g_fn' + str(first) + '(NULL,g_global_regions,(GRef)0);if(value)return 1;puts("true");return 0;}\n')
                for profile, flags in c_profiles:
                    binary = output / (label + '-' + profile)
                    execute(label + '-' + profile + '-cc', flags + [wrapper, '-lm', '-ldl', '-pthread', '-o', binary])
                    zero = execute(label + '-' + profile + '-zero', [binary])
                    assert zero.stdout == b'true\n' and zero.stderr == b''
                    positive = execute(label + '-' + profile + '-positive', [binary, 'positive'], expected_exit='nonzero')
                    assert positive.returncode != 0 and positive.stdout == b'' and b'null reference' in positive.stderr
                    assert not re.search(rb'(AddressSanitizer|UndefinedBehaviorSanitizer|runtime error:)', positive.stderr)
                    report['null_harness'].append({'level': item['level'], 'debug': item['debug'], 'C_profile': profile, 'zero_passed': True, 'positive_trap_passed': True, 'wrapper_sha256': sha(wrapper)})
            assert len(report['sanitizers']) == 16 and len(report['null_harness']) == 16
        for relative, digest in extension['input_sha256'].items():
            assert sha(ROOT / relative) == digest, relative
        assert sha(compiler) == report['compiler_sha256']
        report['status'] = 'passed'
    except BaseException as error:
        report['status'] = 'failed'
        report['error'] = repr(error)
        raise
    finally:
        save(output / 'report.json', report)
    print(json.dumps({'status': report['status'], 'runtime_campaigns': len(report['runtime']),
                      'gate_checks': len(report['gate_rows']), 'new_structure_checks': len(report['structure']),
                      'new_sanitizer_profiles': len(report['sanitizers']), 'null_harness_profiles': len(report['null_harness'])}))


if __name__ == '__main__':
    main()
