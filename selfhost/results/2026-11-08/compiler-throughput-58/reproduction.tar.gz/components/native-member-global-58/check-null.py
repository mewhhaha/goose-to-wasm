#!/usr/bin/env python3
"""Finish frozen null matrix from existing, structurally checked emitted C."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess

ROOT = Path('/home/jacobt/src/goose-to-wasm')
HERE = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, data):
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    os.sched_setaffinity(0, {1})
    seal = json.loads((HERE / 'null-continuation-protocol.json').read_text())
    for name, digest in seal['input_sha256'].items():
        assert sha(ROOT / name) == digest, name
    output = args.output_dir.resolve()
    output.mkdir(exist_ok=False)
    report = {'status': 'running', 'commands': [], 'rows': [], 'protocol_sha256': sha(HERE / 'null-continuation-protocol.json')}

    def run(label, command):
        command = list(map(str, command))
        result = subprocess.run(command, cwd=ROOT, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60)
        (output / (label + '.stdout')).write_bytes(result.stdout)
        (output / (label + '.stderr')).write_bytes(result.stderr)
        report['commands'].append({'command': command, 'exit_code': result.returncode, 'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(), 'stderr_sha256': hashlib.sha256(result.stderr).hexdigest()})
        save(output / 'report.json', report)
        return result

    try:
        for item in seal['profiles']:
            artifact = ROOT / item['C']
            label = item['label']
            wrapper = output / (label + '.c')
            wrapper.write_text('#define main member_original_main\n#include ' + json.dumps(str(artifact)) + '\n#undef main\n' +
                'int main(int argc,char **argv){g_argc=argc;g_argv=argv;g_initialize();\n' +
                'if(argc>1){(void)g_fn' + str(item['later']) + '(NULL,g_global_regions,(GRef)0);return 0;}\n' +
                'GRef value=g_fn' + str(item['first']) + '(NULL,g_global_regions,(GRef)0);if(value)return 1;puts("true");return 0;}\n')
            for name, flags in seal['C_profiles']:
                binary = output / (label + '-' + name)
                compile_result = run(label + '-' + name + '-cc', flags + [str(wrapper), '-lm', '-ldl', '-pthread', '-o', str(binary)])
                assert compile_result.returncode == 0, compile_result.stderr
                zero = run(label + '-' + name + '-zero', [binary])
                assert zero.returncode == 0 and zero.stdout == b'true\n' and zero.stderr == b''
                positive = run(label + '-' + name + '-positive', [binary, 'positive'])
                assert positive.returncode == 1 and positive.stdout == b'' and positive.stderr == b'goose runtime error: null reference (<native>:0)\n', positive.stderr
                report['rows'].append({'Goose_level': item['level'], 'Goose_debug': item['debug'], 'C_profile': name, 'C_sha256': sha(artifact), 'wrapper_sha256': sha(wrapper), 'null_zero_exit': zero.returncode, 'null_positive_exit': positive.returncode, 'null_positive_exact_checked_panic': True, 'passed': True})
                save(output / 'report.json', report)
        for name, digest in seal['input_sha256'].items():
            assert sha(ROOT / name) == digest, name
        assert len(report['rows']) == 16
        report['status'] = 'passed'
        report['null_child_observations'] = 32
    except BaseException as error:
        report['status'] = 'failed'
        report['error'] = repr(error)
        raise
    finally:
        save(output / 'report.json', report)
    print(json.dumps({'status': report['status'], 'C_profiles': len(report['rows']), 'null_children': 32}))


if __name__ == '__main__':
    main()
