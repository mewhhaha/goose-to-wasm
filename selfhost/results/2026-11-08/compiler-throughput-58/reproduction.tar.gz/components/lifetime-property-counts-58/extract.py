from pathlib import Path
import struct,hashlib,re,json,subprocess
root=Path.cwd();out=Path(__file__).resolve().parent;binary=root/'build/completion-runs/compiler-pgo-58/training-goose';elf=binary.read_bytes()
shoff=struct.unpack_from('<Q',elf,40)[0];entsize,num,strings=struct.unpack_from('<HHH',elf,58)
sections=[struct.unpack_from('<IIQQQQIIQQ',elf,shoff+i*entsize)for i in range(num)]
s=sections[strings];names=elf[s[4]:s[4]+s[5]]
sections={names[s[0]:].split(b'\0')[0].decode():s for s in sections}
records=sections['__llvm_prf_data'];source='/home/jacobt/src/goose-to-wasm/build/completion-runs/compiler-plain-58/compiler.c'
queries={
 'holds':{'symbol':'g_fn104776','normal_return_address':0x90a870,'leaf_return_addresses':[0x90a880,0x90a8c8,0x90a8d0,0x90a8d8],'array_struct_enum_addresses':[0x90a7f0,0x90a7f8,0x90a800],'jump_table':0x844828,'slow_initializer':0x1ef1e6},
 'relative':{'symbol':'g_fn107231','normal_return_address':0x90c7a0,'leaf_return_addresses':[0x90c7b8,0x90c808,0x90c810],'array_struct_enum_addresses':[0x90c730,0x90c738,0x90c740],'jump_table':0x84484c,'slow_initializer':0x1f70ab}}
for entry in queries.values():
 namehash=int.from_bytes(hashlib.md5((source+';'+entry['symbol']).encode()).digest()[:8],'little')
 matches=[]
 for offset in range(0,records[5],72):
  pos=records[4]+offset
  if struct.unpack_from('<Q',elf,pos)[0]==namehash:matches.append((offset,pos))
 assert len(matches)==1,matches
 offset,pos=matches[0];counter=records[3]+offset+struct.unpack_from('<q',elf,pos+16)[0];entry['counter_base']=counter
 entry['counter_count']=struct.unpack_from('<I',elf,pos+56)[0]
 for group in ['normal_return','leaf_return','array_struct_enum']:
  key=group+'_addresses'
  if group=='normal_return':entry[group+'_index']=(entry[group+'_address']-counter)//8
  else:entry[group+'_indices']=[(a-counter)//8 for a in entry[key]]
 # These pinned PIE static addresses belong to a file segment with equal VMA/file offsets.
 table=entry['jump_table'];entry['kind_branch_targets']={5+i:table+struct.unpack_from('<i',elf,table+4*i)[0]for i in range(9)}
 assert entry['kind_branch_targets'][13]==entry['slow_initializer']
 disassembly=subprocess.check_output(['objdump','-d','--no-show-raw-insn','--disassemble='+entry['symbol'],str(binary)],text=True)
 (out/(entry['symbol']+'.disassembly.txt')).write_text(disassembly)
rows=[]
for path in sorted(out.glob('*.counts.txt')):
 row={'input':path.name.removesuffix('.counts.txt'),'properties':{}}
 for name,entry in queries.items():
  m=re.search(r'(?m)^  [^\n]*;'+entry['symbol']+r':\n((?:    [^\n]*\n)+)',path.read_text());assert m
  counts=[int(x)for x in re.search(r'Block counts: \[([^]]*)\]',m.group(1)).group(1).split(', ')];assert len(counts)==entry['counter_count']
  normal=counts[entry['normal_return_index']];leaves=sum(counts[i]for i in entry['leaf_return_indices']);graph=normal-leaves
  named=sum(counts[i]for i in entry['array_struct_enum_indices']);tuples=graph-named;assert tuples>=0
  row['properties'][name]={'normal_calls':normal,'leaf_calls':leaves,'graph_walk_setups':graph,'array_struct_enum_setups':named,'tuple_setups_by_conservation':tuples}
 rows.append(row)
result={'scope':'Diagnostic IR-profile CFG reconstruction on successful compiler calls, no timing claim. Counts cover standalone wrappers only; property logic inlined into other profile owners is excluded.','method':'Map __llvm_prf_data name MD5/relative counter pointer to raw counter indices. Pinned disassembly shows all normal returns use a common completion counter. Exact scalar/reference/negative return branch counters account for every non-graph type; subtract them to obtain slow walk setup count. Three direct graph-kind branch counters plus remaining tuple jump (kind13 goes directly to initializer) independently partition setup counts. Never use counter0 as entry.','pin':{'training_binary_sha256':hashlib.sha256(elf).hexdigest(),'source_C_sha256':hashlib.sha256(Path(source).read_bytes()).hexdigest()},'queries':queries,'rows':rows,'limits':['Profiles cannot identify per-type reuse rates without more instrumentation; graph call count is a conservative lower bound on total graph work, not a cache hit measurement.','Counters include phase and non-phase calls, whose split is not directly exposed; prospective cached wrappers fall back outside types_frozen.','No graph snapshots or mutable lifetime state is inferred from these counts. No raw diagnostic profile was merged into final PGO profile.']}
(out/'property-counts.json').write_text(json.dumps(result,indent=2)+'\n')
for row in rows:print(row['input'],row['properties'])
