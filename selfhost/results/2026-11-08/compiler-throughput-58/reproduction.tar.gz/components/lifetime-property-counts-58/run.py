from pathlib import Path
import subprocess,hashlib,json,os
root=Path.cwd();out=root/'build/completion-runs/lifetime-property-counts-58';pgo=root/'build/completion-runs/compiler-pgo-58';compiler=pgo/'training-goose'
profile=pgo/'compiler.profdata';before=hashlib.sha256(profile.read_bytes()).hexdigest()
report=json.loads((root/'build/completion-runs/compiler-plain-58/comparison/report.json').read_text())
workloads={x['name']:x for x in report['workloads']};rows=[]
source_c=root/'build/completion-runs/compiler-plain-58/compiler.c'
assert hashlib.sha256(source_c.read_bytes()).hexdigest()==json.loads((pgo/'inputs.json').read_text())['source_sha256']
for name in ['functions','mandelbrot','tour']:
 for target in ['wasm-direct','native']:
  env=os.environ.copy();env['LLVM_PROFILE_FILE']=str(out/'diag'/f'{name}-{target}-%p.profraw')
  source=Path(workloads[name]['source']);assert hashlib.sha256(source.read_bytes()).hexdigest()==workloads[name]['source_sha256']
  command=['taskset','-c','3',str(compiler),str(source),'--stdlib',str(root/'stdlib'),'--target',target,'-O2','-o',str(out/f'{name}-{target}.out')]
  result=subprocess.run(command,env=env,capture_output=True,text=True)
  (out/f'{name}-{target}.stdout').write_text(result.stdout);(out/f'{name}-{target}.stderr').write_text(result.stderr)
  assert result.returncode==0,(command,result.stderr)
  raw=list((out/'diag').glob(f'{name}-{target}-*.profraw'));assert len(raw)==1,raw
  shown=subprocess.run(['llvm-profdata','show','--all-functions','--counts',str(raw[0])],capture_output=True,text=True)
  assert shown.returncode==0,shown.stderr
  (out/f'{name}-{target}.counts.txt').write_text(shown.stdout)
  rows.append({'workload':name,'target':target,'source':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'command':command,'LLVM_PROFILE_FILE':env['LLVM_PROFILE_FILE'],'profile':str(raw[0]),'profile_sha256':hashlib.sha256(raw[0].read_bytes()).hexdigest(),'exit_code':0})
  print(name,target,'diagnostic profile recorded',flush=True)
after=hashlib.sha256(profile.read_bytes()).hexdigest();assert before==after
(out/'runs.json').write_text(json.dumps({'scope':'Diagnostic instrumented execution counts only; no elapsed timing claims. Raw profiles remain isolated and are never merged into final PGO inputs.','training_compiler':str(compiler),'training_compiler_sha256':hashlib.sha256(compiler.read_bytes()).hexdigest(),'A10_C_sha256':hashlib.sha256(source_c.read_bytes()).hexdigest(),'final_profile_sha256_before':before,'final_profile_sha256_after':after,'runs':rows},indent=2)+'\n')
