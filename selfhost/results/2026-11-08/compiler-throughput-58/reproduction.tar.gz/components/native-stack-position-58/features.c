#ifndef __has_builtin
#define __has_builtin(x) 0
#endif
stack_save=__has_builtin(__builtin_stack_save)
stack_address=__has_builtin(__builtin_stack_address)
read_register=__has_builtin(__builtin_read_register)
frame_address=__has_builtin(__builtin_frame_address)
dwarf_cfa=__has_builtin(__builtin_dwarf_cfa)
alloca=__has_builtin(__builtin_alloca)
