#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>
#ifndef __has_builtin
#define __has_builtin(x) 0
#endif
#if __has_builtin(__builtin_stack_save)
#define HAS_STACK_SAVE 1
#else
#define HAS_STACK_SAVE 0
#endif
static _Thread_local uintptr_t low;
static __attribute__((noinline,cold)) void initialize(void) { low = 1; }
static __attribute__((noinline,noreturn,cold)) void panic(void) { abort(); }
static __attribute__((always_inline)) inline void old_check(void) {
    unsigned char here;
    if (!low) initialize();
    if ((uintptr_t)&here-low < 131072) panic();
}
static __attribute__((always_inline)) inline void new_check(void) {
    if (!low) initialize();
    uintptr_t here = (uintptr_t)__builtin_stack_save();
    if (here-low < 131072) panic();
}
__attribute__((noinline)) int old_plain(int n) { old_check(); return n+1; }
__attribute__((noinline)) int new_plain(int n) { new_check(); return n+1; }
__attribute__((noinline)) int old_buffer(int n) { volatile unsigned char buf[256]; old_check(); buf[0]=1; buf[255]=(unsigned char)n; return buf[0]+buf[255]; }
__attribute__((noinline)) int new_buffer(int n) { volatile unsigned char buf[256]; new_check(); buf[0]=1; buf[255]=(unsigned char)n; return buf[0]+buf[255]; }
__attribute__((noinline)) intptr_t same_frame_position(int n) { volatile unsigned char buf[8192]; unsigned char marker; buf[0]=(unsigned char)n; buf[8191]=(unsigned char)n; uintptr_t sp=(uintptr_t)__builtin_stack_save(); return (intptr_t)(uintptr_t)&marker-(intptr_t)sp+buf[0]-buf[8191]; }
int main(void) { if(old_plain(1)!=2||new_plain(1)!=2||old_buffer(2)!=3||new_buffer(2)!=3)return 1; printf("has_builtin=%d marker_minus_sp=%ld\n",HAS_STACK_SAVE,(long)same_frame_position(3)); }
