from pathlib import Path
import subprocess,json,os,time,hashlib,re
root=Path.cwd();r=root/'build/completion-runs/native-stack-position-58';base=root/'build/completion-runs/snapshot-58/native';seal=json.loads((r/'guard-seal.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(r/'whole-header.c')==seal['whole_header_fixture_sha256'] and sha(r/'storage.h')==seal['source_sha256']
profiles=[('clang-O0','clang-23',['-O0'],False),('clang-O2','clang-23',['-O2'],False),('gcc-O0','gcc',['-O0'],False),('gcc-O2','gcc',['-O2'],False),('clang-SAN','clang-23',['-O1','-g','-fsanitize=address,undefined,pointer-overflow','-fno-sanitize-recover=all'],False),('gcc-SAN','gcc',['-O1','-g','-fsanitize=address,undefined,pointer-overflow','-fno-sanitize-recover=all'],False),('clang-Tiny','clang-23',['-O2','-D__TINYC__=1'],True),('gcc-Tiny','gcc',['-O2','-D__TINYC__=1'],True)]
report={'status':'running','rows':[],'seal_sha256':sha(r/'guard-seal.json')}
for label,header in [('parent',base/'storage.h'),('candidate',r/'storage.h')]:
 for name,cc,flags,fallback in profiles:
  fast=int(label=='candidate' and not fallback);prefix=label+'-'+name;binary=r/prefix
  cmd=['taskset','-c','1',cc,'-std=gnu11','-fstack-protector-strong',*flags,'-I',str(base),'-DSTORAGE_HEADER='+json.dumps(str(header)),'-DEXPECT_FAST='+str(fast),str(r/'whole-header.c'),'-lm','-ldl','-pthread','-o',str(binary)]
  start=time.monotonic();p=subprocess.run(cmd,capture_output=True,text=True);row={'label':label,'profile':name,'compile':{'command':cmd,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'seconds':time.monotonic()-start}}
  report['rows'].append(row)
  if p.returncode==0:
   env=os.environ.copy();env['ASAN_OPTIONS']='detect_stack_use_after_return=0:detect_leaks=0';q=subprocess.run(['taskset','-c','1',str(binary)],capture_output=True,text=True,env=env,timeout=20);row['run']={'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr};row['passed']=q.returncode==0 and q.stdout=='native stack position ok\n' and q.stderr==''
   if row['passed'] and 'SAN' not in name:
    asm=subprocess.check_output(['objdump','-d','--no-show-raw-insn','-Mintel',str(binary)],text=True);checks={}
    for fn in ['scalar_guard','real_buffer','g_stack_check_init']:
     m=re.search(r'^[0-9a-f]+ <'+fn+r'(?:\.constprop\.\d+)?>:\n(.*?)(?=\n[0-9a-f]+ <|\Z)',asm,re.S|re.M)
     assert m,fn
     body=m[1];checks[fn]={'canary':'fs:0x28' in body,'assembly':body}
    expected_scalar=not bool(fast);row['structure']={'scalar_canary_matches_expected':checks['scalar_guard']['canary']==expected_scalar,'real_escaped_buffer_canary_retained':checks['real_buffer']['canary'],'cold_pthread_initializer_canary_retained':checks['g_stack_check_init']['canary']};row['passed'] &= all(row['structure'].values());(r/(prefix+'-structure.json')).write_text(json.dumps(checks,indent=2)+'\n')
  else:row['passed']=False
  (r/'whole-header-report.json').write_text(json.dumps(report,indent=2)+'\n');print(prefix,row['passed'],flush=True)
  if not row['passed']:print(json.dumps(row,indent=2),flush=True);raise SystemExit(1)
report['status']='passed';report['profiles']=len(report['rows']);report['trap_children']=sum(3 if row['label']=='candidate' and 'Tiny' not in row['profile'] else 2 for row in report['rows']);report['normal_children']=sum(3 if row['label']=='candidate' and 'Tiny' not in row['profile'] else 2 for row in report['rows']);(r/'whole-header-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='rows'}))
