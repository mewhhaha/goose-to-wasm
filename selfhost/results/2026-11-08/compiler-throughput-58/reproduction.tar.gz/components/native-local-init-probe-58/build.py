from pathlib import Path
import subprocess,time,json,hashlib,re
root=Path.cwd();w=root/'build/completion-runs';out=w/'native-local-init-probe-58';source=w/'compiler-plain-58/compiler.c';original=source.read_text()
head='static g_t33 g_fn120061(';start=original.index(head);start=original.index(head,start+1);end=original.find('\nstatic ',start+1);body=original[start:end]
pattern=r'(g_t\d+ g_s\d+)=\{\};';matches=re.findall(pattern,body);assert len(matches)==37
new_body=re.sub(pattern,r'\1;',body);text=original[:start]+new_body+original[end:];p=out/'compiler.c';p.write_text(text)
command=['taskset','-c','2','clang-23','-std=gnu11','-O2',str(p),'-lm','-ldl','-pthread','-o',str(out/'goose')]
t=time.monotonic();result=subprocess.run(command,capture_output=True,text=True);(out/'cc.stderr').write_text(result.stderr)
receipt=dict(command=command,exit_code=result.returncode,seconds=time.monotonic()-t,parent_C_sha256=hashlib.sha256(original.encode()).hexdigest(),candidate_C_sha256=hashlib.sha256(text.encode()).hexdigest(),removed_entry_initializers=matches,lineage='Private magnitude diagnostic in A10 life_eval only; all source record declarations have complete executed initialization and no source self-initializer/captured locals. Generic emission patch proof and full qualification remain separate. Embedded compiler/runtime and emitted app code unchanged.')
(out/'cc.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True);assert not result.returncode
