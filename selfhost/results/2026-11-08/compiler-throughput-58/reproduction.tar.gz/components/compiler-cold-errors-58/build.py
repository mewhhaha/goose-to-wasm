from pathlib import Path
import subprocess,time,json,hashlib
root=Path.cwd();w=root/'build/completion-runs';out=w/'compiler-cold-errors-58';original=w/'compiler-plain-58/compiler.c';text=original.read_text()
for name in ['g_panic','g_panic_at','g_index_fail']:
 old='static GS_NORETURN void '+name+'('
 assert text.count(old)==1
 text=text.replace(old,'static GS_NORETURN GS_NOINLINE __attribute__((cold)) void '+name+'(')
source=out/'compiler.c';source.write_text(text)
cmd=['taskset','-c','2','clang-23','-std=gnu11','-O2',str(source),'-lm','-ldl','-pthread','-o',str(out/'goose')]
start=time.monotonic();p=subprocess.run(cmd,capture_output=True,text=True);(out/'cc.stderr').write_text(p.stderr);record=dict(command=cmd,exit_code=p.returncode,seconds=time.monotonic()-start,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),parent_C_sha256=hashlib.sha256(original.read_bytes()).hexdigest(),lineage='Diagnostic generated-C-only attribute change; not product/source fixed point. Embedded runtime text remains the parent.')
(out/'cc.json').write_text(json.dumps(record,indent=2)+'\n');assert not p.returncode,p.stderr;print(json.dumps(record),flush=True)
