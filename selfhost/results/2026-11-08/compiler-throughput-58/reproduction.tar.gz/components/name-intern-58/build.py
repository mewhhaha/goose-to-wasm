from pathlib import Path
import hashlib,json,os,subprocess,time
ROOT=Path('/home/jacobt/src/goose-to-wasm');OUT=Path(__file__).resolve().parent;HOST=ROOT/'build/completion-runs/compiler-recursive-58/goose'
commands=[('emit',['taskset','-c','2',str(HOST),str(OUT/'selfhost/main.goose'),'--stdlib',str(ROOT/'stdlib'),'--target','native','-O2','--wasm-stats',str(OUT/'self-o2-stats.json'),'-o',str(OUT/'compiler.c')]),('cc',['taskset','-c','2','/usr/bin/clang-23','-std=gnu11','-O2',str(OUT/'compiler.c'),'-lm','-ldl','-pthread','-o',str(OUT/'goose')])]
for label,command in commands:
 started=time.monotonic();r=subprocess.run(command,capture_output=True,text=True);(OUT/f'{label}.stdout').write_text(r.stdout);(OUT/f'{label}.stderr').write_text(r.stderr);report=dict(command=command,exit_code=r.returncode,seconds=time.monotonic()-started,TMPDIR=os.environ.get('TMPDIR'),host_sha256=hashlib.sha256(HOST.read_bytes()).hexdigest());(OUT/f'{label}.json').write_text(json.dumps(report,indent=2)+'\n');print(label,r.returncode,report['seconds'],flush=True);assert r.returncode==0,r.stderr
