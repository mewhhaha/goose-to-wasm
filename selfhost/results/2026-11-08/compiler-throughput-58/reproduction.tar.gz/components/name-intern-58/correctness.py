from pathlib import Path
import hashlib,importlib.metadata,json,os,shutil,subprocess,sys,time
ROOT=Path('/home/jacobt/src/goose-to-wasm');HERE=Path(__file__).resolve().parent;OUT=HERE/'correctness';OUT.mkdir(exist_ok=False);os.sched_setaffinity(0,{3})
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();compilers={'baseline':ROOT/'build/completion-runs/compiler-recursive-58/goose','candidate':HERE/'goose'}
report=dict(status='running',scope='Correctness only; no timing evidence. Compare A5 host and identifier-intern host on identical source paths, then run byte-identical candidate artifacts against independent goldens.',compilers={tag:dict(path=str(path),sha256=sha(path)) for tag,path in compilers.items()},commands=[],guard=[],examples=[],token_dumps=[],environment=dict(cpu=3,node=shutil.which('node'),node_version=subprocess.check_output(['node','--version'],text=True).strip(),wasmtime=importlib.metadata.version('wasmtime'),gcc=shutil.which('gcc'),gcc_sha256=sha(Path(shutil.which('gcc')))),input_sha256={})
assert report['environment']['node_version'].startswith('v24.') and report['environment']['wasmtime']=='50.0.1'
def save():(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
def run(command,stdin=''):
 command=list(map(str,command));started=time.monotonic();r=subprocess.run(command,input=stdin,text=True,capture_output=True,cwd=ROOT,timeout=120);row=dict(command=command,exit_code=r.returncode,seconds=time.monotonic()-started,stdout=r.stdout,stderr=r.stderr);report['commands'].append(row);save();assert r.returncode==0,row;return row

def emit_pair(source,label,target,flags):
 extension='wasm'
 if target=='native':extension='c'
 artifacts=[]
 for tag,compiler in compilers.items():
  artifact=OUT/f'{label}-{tag}.{extension}';run([compiler,source,'--stdlib',ROOT/'stdlib','--target',target,*flags,'-o',artifact]);artifacts.append(artifact)
 assert artifacts[0].read_bytes()==artifacts[1].read_bytes(),(label,'emitted byte mismatch')
 return artifacts[1]

def execute(artifact,label,target,stdin='',level=2,host_input=False):
 rows=[]
 if target=='native':
  binary=OUT/f'{label}-program';command=['gcc','-std=gnu11',f'-O{level}','-fno-strict-aliasing','-rdynamic',artifact]
  if host_input:command.append(ROOT/'bench/host_input.c')
  command+=['-lm','-ldl','-pthread','-o',binary];run(command);rows.append(run([binary],stdin))
 else:
  rows.append(run(['node',ROOT/'scripts/run_wasm.mjs',artifact],stdin));rows.append(run([sys.executable,ROOT/'scripts/run_wasmtime.py',artifact],stdin))
 return rows
try:
 contract=json.loads((HERE/'name-guard-contract.json').read_text());assert sha(HERE/'name-guard.goose')==contract['source_sha256']
 for level in [0,2]:
  for debug in [False,True]:
   flags=[f'-O{level}'];profile=f'O{level}'
   if debug:flags+=['--debug'];profile+='-debug'
   for target in ['native','wasm-direct']:
    label='guard-'+profile+'-'+target;artifact=emit_pair(HERE/'name-guard.goose',label,target,flags);rows=execute(artifact,label,target,level=level)
    assert all(row['stdout']==contract['expected_stdout'] and not row['stderr'] for row in rows),(label,rows)
    report['guard'].append(dict(profile=profile,target=target,byte_identical=True,sha256=sha(artifact),golden_checks=len(rows)));save()
 cases=[]
 for case in json.loads((ROOT/'examples/manifest.json').read_text())['examples']:
  source=ROOT/'examples'/case['file'];expected=ROOT/'examples'/case['expected'];cases.append(dict(name=case['name'],source=source,expected=expected.read_text(),stdin='',host_input=False));report['input_sha256'][str(expected)]=sha(expected)
 cases.append(dict(name='mandelbrot',source=ROOT/'bench/langbench/mandelbrot.goose',stdin='8 25 1\n',checksum='636',host_input=True))
 for case in cases:
  report['input_sha256'][str(case['source'])]=sha(case['source'])
  for target in ['native','wasm-direct']:
   label=case['name']+'-'+target;artifact=emit_pair(case['source'],label,target,['-O2']);rows=execute(artifact,label,target,case['stdin'],host_input=case['host_input'])
   for row in rows:
    assert not row['stderr'],row
    if 'checksum' in case:
     tokens=row['stdout'].split();assert len(tokens)==2 and tokens[0]==case['checksum'] and int(tokens[1])>=0,row
    else:assert row['stdout']==case['expected'],row
   report['examples'].append(dict(case=case['name'],target=target,byte_identical=True,sha256=sha(artifact),golden_checks=len(rows)));save()
 for source in [HERE/'name-guard.goose',*(case['source'] for case in cases),ROOT/'tests/fixtures/float_operations.goose',ROOT/'tests/fixtures/contracts/render/unused_hook_error.goose']:
  results=[]
  for compiler in compilers.values():results.append(run([compiler,source,'--stdlib',ROOT/'stdlib','--tokens']))
  assert results[0]['stdout']==results[1]['stdout'] and results[0]['stderr']==results[1]['stderr'],source
  report['token_dumps'].append(dict(source=str(source),source_sha256=sha(source),byte_identical=True,stdout_sha256=hashlib.sha256(results[0]['stdout'].encode()).hexdigest()));save()
 for tag,path in compilers.items():assert sha(path)==report['compilers'][tag]['sha256']
 for path,identity in report['input_sha256'].items():assert sha(Path(path))==identity
 report['status']='passed';print(dict(guard_pairs=len(report['guard']),guard_golden_checks=sum(x['golden_checks'] for x in report['guard']),example_pairs=len(report['examples']),example_golden_checks=sum(x['golden_checks'] for x in report['examples']),token_dumps=len(report['token_dumps'])))
except BaseException as error:report.update(status='failed',error=repr(error));raise
finally:save()
