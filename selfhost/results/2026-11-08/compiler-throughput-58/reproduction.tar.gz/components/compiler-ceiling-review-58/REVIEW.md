The combined58 slot counter and bootstrap optimization metadata patches have
no source-review blocker. Existing owner slots are scanned once per function;
the saved counter and current owner are restored together. Callee discovery
precedes initialization, and recursive/visited exits preserve both scalars.
The two allocation sites both allocate for the active function.

The bootstrap patch consistently forwards one optimization level to all C
emission generations. Seed reuse also compares that level; missing old seed
metadata means O0. Seed-only metadata reports the actual seed level. Freezing
and installation preserve it. Fixed-point proof still needs independent
semantic qualification and output equivalence across host builds.

cases.json freezes 24 source-derived runtime checks for nested captured
inlining, tail-call argument permutations at two tail sites, mutual recursion,
and multiple caller owners. No compiler was run to derive expected output.

Symbol.slot is not consumed by either backend after optimization, so runtime
output cannot establish its uniqueness. instrument.py copies a frozen source
tree and adds slot-guard.goose after optimization. The guard preserves old
identities and requires every appended local to have a valid function owner,
synthetic scope, and a slot greater than all earlier slots of that owner.
Compile the instrumented compiler privately and use it on the fixtures; its
timings must never enter performance evidence.

lifetime-readonly/candidate.patch changes 48 Node/Type/Symbol copies to const
references inside 26 helpers. audit.json records the 94-function life_eval
call closure and zero direct mutation/growth of those three tables there.
Standalone synthetic node/type creation occurs before evaluation; provenance
and named-result writes occur after evaluation. Mutable lifetime-state
snapshots are unchanged. This proposal has not been compiled or measured.
