#!/usr/bin/env python3
"""Copy frozen compiler sources and add a private optimizer invariant guard."""
import argparse
from pathlib import Path
import shutil

HERE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source-dir', type=Path, required=True)
parser.add_argument('--native-dir', type=Path, required=True)
parser.add_argument('--output-dir', type=Path, required=True)
args = parser.parse_args()
args.output_dir.mkdir(parents=True, exist_ok=False)
sources = args.output_dir / 'selfhost'
sources.mkdir()
for path in args.source_dir.glob('*.goose'):
    shutil.copyfile(path, sources / path.name)
shutil.copytree(args.native_dir, args.output_dir / 'native')
path = sources / 'driver.goose'
text = path.read_text()
old = '    optimize_program(p); let optimized = clock_ns();'
new = '''    var review_old_slots: i64[>..] = [];
    var review_old_owners: i64[>..] = [];
    for symbol in p.symbols {
        review_old_slots.push(symbol.slot); review_old_owners.push(symbol.owner);
    }
    optimize_program(p); let optimized = clock_ns();
    review_slot_guard(p, review_old_slots, review_old_owners);'''
if text.count(old) != 1:
    raise SystemExit('driver optimizer boundary changed')
path.write_text(text.replace(old, new) + '\n' + (HERE / 'slot-guard.goose').read_text())
print(sources / 'main.goose')
