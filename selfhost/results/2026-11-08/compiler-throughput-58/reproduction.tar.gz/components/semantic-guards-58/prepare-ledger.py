from pathlib import Path
import hashlib,json
ROOT=Path('/home/jacobt/src/goose-to-wasm');WORK=ROOT/'build/completion-runs';HERE=Path(__file__).resolve().parent
original=WORK/'checker-format-index-58/ledger-guard.goose';actual=WORK/'compiler-format-58/selfhost/checker.goose';text=original.read_text();source=actual.read_text()
start=source.index('fn check_has_format_hooks(');end=source.index('recursive fn check_lower_rendering(',start);helper=source[start:end]
start=source.index('            if symbol >= 0 && symbol < c.format_scan_end &&');end=source.index('            p.symbols[symbol].type_id = ty;',start);invalidate=source[start:end]
first=text.index('fn check_has_format_hooks(');last=text.index('fn review_set_owner(',first);text=text[:first]+helper+text[last:]
first=text.index('fn review_set_owner(');last=text.index('// This oracle',first)
text=text[:first]+'fn review_set_owner(p: Program&, c: Checker&, symbol: i64, owner: i64) {\n'+invalidate+'    p.symbols[symbol].owner = owner;\n}\n'+text[last:]
output=HERE/'ledger-guard-a3.goose';output.write_text(text)
manifest=json.loads((WORK/'checker-format-index-58/cases.json').read_text());changed=[]
for case in manifest['cases']:
 if case['source'].endswith('/ledger-guard.goose'):
  case['source']=output.relative_to(ROOT).as_posix();changed.append(case['id'])
(HERE/'format-cases-a3.json').write_text(json.dumps(manifest,indent=2)+'\n');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(HERE/'ledger-adaptation.json').write_text(json.dumps(dict(status='prepared-before-baseline-suite-and-candidate-execution',reason='Frozen ledger harness remains identical. Extract actual A3 helper plus actual owner invalidation; A3 adds symbol>=0 guard relative to proposal checker. No expected output or oracle logic changed.',original_source_sha256=sha(original),actual_checker_sha256=sha(actual),helper_sha256=hashlib.sha256(helper.encode()).hexdigest(),invalidation_sha256=hashlib.sha256(invalidate.encode()).hexdigest(),adapted_source_sha256=sha(output),manifest_sha256=sha(HERE/'format-cases-a3.json'),changed_source_entries=changed),indent=2)+'\n')
