from pathlib import Path
import concurrent.futures,hashlib,importlib.metadata,json,os,shutil,subprocess,sys,time
ROOT=Path('/home/jacobt/src/goose-to-wasm');WORK=ROOT/'build/completion-runs';HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();phase=sys.argv[1];assert phase in ('baseline','candidate')
compiler=ROOT/'build/bin/goose'
if phase=='candidate':
 compiler=WORK/'compiler-format-58/goose'
 baseline=json.loads((HERE/'baseline-summary.json').read_text());assert baseline['status']=='passed'
report=dict(status='running',phase=phase,compiler=str(compiler),compiler_sha256=sha(compiler),bounded_workers=2,cpu_affinity=[2,3],timing_scope='Correctness only; CPU1 root compiler build may overlap. No benchmark measurements.',environment=dict(python=sys.executable,node=shutil.which('node'),node_version=subprocess.check_output(['node','--version'],text=True).strip(),gcc=shutil.which('gcc'),gcc_sha256=sha(Path(shutil.which('gcc'))),gcc_version=subprocess.check_output(['gcc','--version'],text=True).splitlines()[0],wasmtime_python=importlib.metadata.version('wasmtime'),wasmtime_native_host=str(ROOT/'build/bin/goose-wasmtime'),wasmtime_native_host_sha256=sha(ROOT/'build/bin/goose-wasmtime'),wasmtime_native_metadata_sha256=sha(ROOT/'build/bin/goose-wasmtime.json')),runs=[])
assert report['environment']['node_version'].startswith('v24.') and report['environment']['wasmtime_python']=='50.0.1'
assert json.loads((ROOT/'build/bin/goose-wasmtime.json').read_text())['version']=='50.0.1'
def run(cell):
 name,manifest,engine=cell;output=HERE/f'{phase}-{name}-{engine}'
 cc='gcc'
 if name=='ceiling':
  cc=str(HERE/'native-gcc.py')
 cmd=['taskset','-c','2,3',sys.executable,str(ROOT/'tests/conformance.py'),'--compiler',str(compiler),'--manifest',str(manifest),'--output-dir',str(output),'--engine',engine,'--cc',cc,'--timeout','30'];started=time.monotonic()
 with (HERE/f'{phase}-{name}-{engine}.log').open('x') as stream:r=subprocess.run(cmd,stdout=stream,stderr=subprocess.STDOUT,cwd=ROOT)
 receipt=dict(suite=name,engine=engine,command=cmd,exit_code=r.returncode,seconds=time.monotonic()-started,manifest_sha256=sha(manifest),report=str(output/'report.json'))
 if (output/'report.json').exists():
  proof=json.loads((output/'report.json').read_text());receipt['summary']=proof.get('summary');receipt['status']=proof['status'];receipt['stable_inputs']=proof.get('input_sha256')==proof.get('input_sha256_after');receipt['failed_rows']=[dict(row,compile_stderr=proof['commands'][row['compile_command']]['stderr']) for row in proof.get('results',[]) if row['status']!='pass']
 return receipt
cells=[(name,manifest,engine) for name,manifest in [('format',HERE/'format-cases-a3.json'),('ceiling',WORK/'compiler-ceiling-review-58/cases.json')] for engine in ('wasmtime','v8')]
try:
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  for receipt in pool.map(run,cells):
   report['runs'].append(receipt);(HERE/f'{phase}-summary.json').write_text(json.dumps(report,indent=2)+'\n');print(receipt['suite'],receipt['engine'],receipt.get('summary'),flush=True)
 report['status']='passed'
 for receipt in report['runs']:
  expected=52
  if receipt['suite']=='ceiling':expected=24
  if receipt['exit_code']!=0 or receipt.get('status')!='passed' or not receipt.get('stable_inputs') or receipt.get('summary')!=dict(selected=expected,passed=expected,failed=0):report['status']='failed'
finally:
 (HERE/f'{phase}-summary.json').write_text(json.dumps(report,indent=2)+'\n')
assert report['status']=='passed',report
