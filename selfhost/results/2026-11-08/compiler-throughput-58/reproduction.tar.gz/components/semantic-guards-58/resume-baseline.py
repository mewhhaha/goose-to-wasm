from pathlib import Path
import concurrent.futures,json,hashlib,subprocess,sys,time
ROOT=Path('/home/jacobt/src/goose-to-wasm');HERE=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report=json.loads((HERE/'baseline-summary-prerequisite-rejected.json').read_text());assert report['status']=='failed';report['runs']=[r for r in report['runs'] if r['suite']=='format'];assert all(r['status']=='passed' and r['stable_inputs'] for r in report['runs'])
report['status']='running';report['resumed_prerequisite']=json.loads((HERE/'native-host-prerequisite.json').read_text());manifest=ROOT/'build/completion-runs/compiler-ceiling-review-58/cases.json'
def run(engine):
 output=HERE/f'baseline-ceiling-{engine}-with-host';cmd=['taskset','-c','2,3',sys.executable,str(ROOT/'tests/conformance.py'),'--compiler',report['compiler'],'--manifest',str(manifest),'--output-dir',str(output),'--engine',engine,'--cc',str(HERE/'native-gcc.py'),'--timeout','30'];started=time.monotonic()
 with (HERE/f'baseline-ceiling-{engine}-with-host.log').open('x') as stream:r=subprocess.run(cmd,cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT)
 proof=json.loads((output/'report.json').read_text());return dict(suite='ceiling',engine=engine,command=cmd,exit_code=r.returncode,seconds=time.monotonic()-started,manifest_sha256=sha(manifest),report=str(output/'report.json'),summary=proof['summary'],status=proof['status'],stable_inputs=proof.get('input_sha256')==proof.get('input_sha256_after'),failed_rows=[row for row in proof['results'] if row['status']!='pass'])
try:
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  for receipt in pool.map(run,['wasmtime','v8']):report['runs'].append(receipt);print(receipt['engine'],receipt['summary'],flush=True)
 assert all(r['exit_code']==0 and r['status']=='passed' and r['stable_inputs'] for r in report['runs'])
 assert all(r['summary']==dict(selected=24,passed=24,failed=0) for r in report['runs'] if r['suite']=='ceiling');report['status']='passed'
finally:(HERE/'baseline-summary.json').write_text(json.dumps(report,indent=2)+'\n')
assert report['status']=='passed'
