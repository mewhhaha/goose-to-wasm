#!/usr/bin/env python3
"""Supply the independently specified stdin host ABI for native guard programs."""
import os
import sys
os.execv('/usr/bin/gcc',['/usr/bin/gcc',*sys.argv[1:],'-rdynamic','/home/jacobt/src/goose-to-wasm/bench/host_input.c'])
