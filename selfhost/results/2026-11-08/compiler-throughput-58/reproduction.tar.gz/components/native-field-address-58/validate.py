from pathlib import Path
import argparse,hashlib,json,os,subprocess
R=Path('/home/jacobt/src/goose-to-wasm');H=Path(__file__).resolve().parent;G=H/'guards';a=argparse.ArgumentParser();a.add_argument('--compiler',required=True);a.add_argument('--output-dir',required=True);a=a.parse_args();O=Path(a.output_dir).resolve();O.mkdir();host=Path(a.compiler).resolve();os.sched_setaffinity(0,{4});sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();contracts=[json.loads((G/'contract.json').read_text()),json.loads((G/'default-path-contract.json').read_text())]
for item in json.loads((G/'reused-contracts.json').read_text()):
 p=R/item['contract'];assert sha(p)==item['sha256'];contracts.append(json.loads(p.read_text()))
contracts.extend(json.loads((G/'negative-contracts.json').read_text()));pins={}
for c in contracts:
 source=R/c['source'];assert sha(source)==c['sha256'];pins[c['source']]=sha(source)
report=dict(status='running',compiler_sha256=sha(host),source_sha256=pins,cpu=4,commands=[],runs=[])
def save():(O/'report.json').write_text(json.dumps(report,indent=2)+'\n')
def execute(cmd,expect_success=True):
 p=subprocess.run([str(x) for x in cmd],cwd=R,text=True,capture_output=True,timeout=60);row=dict(command=[str(x) for x in cmd],exit=p.returncode,stdout=p.stdout,stderr=p.stderr);report['commands'].append(row);save()
 if expect_success:assert p.returncode==0,row
 return p,len(report['commands'])-1
try:
 for c in contracts:
  source=R/c['source'];label=source.stem
  for level in c['levels']:
   for debug in c['debug']:
    D=O/(label+'-O'+str(level)+'-debug'+str(debug));D.mkdir();common=[host,source,'--stdlib',R/'stdlib','-O'+str(level),'--standalone']
    if debug:common.append('--debug')
    expected=c.get('expect')
    if expected is None:expected=dict(stdout=c['stdout'],exit=c['exit'])
    for target in c['targets']:
     artifact=D/'program.wasm';commands=[]
     if target=='native':
      artifact=D/'program.c';binary=D/'program';execute([*common,'--target',target,'-o',artifact]);execute(['/usr/bin/gcc','-std=gnu11','-O'+str(level),artifact,'-lm','-ldl','-pthread','-o',binary]);commands=[('native',[binary])]
     else:
      execute([*common,'--target',target,'-o',artifact]);commands=[('wasmtime',[R/'build/bin/goose-wasmtime','--no-cache',artifact]),('v8',['node',R/'scripts/run_wasm.mjs',artifact])]
     for engine,cmd in commands:
      p,index=execute(cmd,False);checks=dict(stdout=p.stdout==expected['stdout'],diagnostic=all(t in p.stderr for t in expected.get('stderr_contains',[])))
      checks['exit']=p.returncode==expected['exit']
      if expected['exit']=='nonzero':checks['exit']=p.returncode!=0
      row=dict(source=c['source'],level=level,debug=debug,target=target,engine=engine,checks=checks,passed=all(checks.values()),command=index);report['runs'].append(row);save();assert row['passed'],row
  print(label,'passed',flush=True)
 for p,pin in pins.items():assert sha(R/p)==pin
 report['status']='passed';report['observations']=len(report['runs'])
except BaseException as error:report['status']='failed';report['error']=repr(error);raise
finally:save()
