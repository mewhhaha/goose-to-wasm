from pathlib import Path
import argparse,hashlib,json,os,re,subprocess
R=Path('/home/jacobt/src/goose-to-wasm');H=Path(__file__).resolve().parent;G=H/'guards';a=argparse.ArgumentParser();a.add_argument('--compiler',required=True);a.add_argument('--output-dir',required=True);a.add_argument('--candidate',action='store_true');a=a.parse_args();O=Path(a.output_dir).resolve();O.mkdir();os.sched_setaffinity(0,{4});sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[];commands=[]
configs=[dict(source=G/'construction.goose',positive={'constructed':[0,1,3,12],'defaulted':[0,1,3,12],'zero_field':[0]},old=['enumeration','selected'],zero='zero_field'),dict(source=G/'default-path.goose',positive={'default_path':[0,1]},default_path='default_path'),dict(source=R/'build/completion-runs/native-local-init-58/guards/padding.goose',positive={'padded':[0,4]}),dict(source=R/'build/completion-runs/native-result-init-58/guards/returns.goose',positive={'packed':[0,1]},old=['owned','large']),dict(source=R/'build/completion-runs/native-result-init-58/guards/image.goose',positive={},image=['image']),dict(source=G/'bounds.goose',positive={'index_at':[0,1]},bounds='index_at')]
def execute(cmd):
 p=subprocess.run([str(x) for x in cmd],cwd=R,text=True,capture_output=True,timeout=60);commands.append(dict(command=[str(x) for x in cmd],exit=p.returncode,stderr=p.stderr));assert p.returncode==0,commands[-1];return p.stdout
def body(text,identity):
 m=re.search(r'\bg_fn'+str(identity)+r'\([^;]*?\)\s*\{',text);assert m,identity
 at=m.end();start=at;depth=1
 while depth:
  if text.startswith('//',at):at=text.index('\n',at);continue
  if text.startswith('/*',at):at=text.index('*/',at+2)+2;continue
  ch=text[at]
  if ch in ['"',"'"]:
   quote=ch;at+=1
   while text[at]!=quote:
    if text[at]=='\\':at+=1
    at+=1
  elif ch=='{':depth+=1
  elif ch=='}':depth-=1
  at+=1
 return text[start:at-1]
def enum_payload_checks(ir, text, candidate):
 # The source constructs a fresh Choice.Some record, then converts it to Choice...
 # Keep the enum-image address rule separate from the record-field rule.
 nodes=ir['nodes'];types=ir['types'];tokens=ir['tokens']
 payloads=[t for t in types if t['kind']==8 and t['pool']>=0 and types[t['pool']]['kind']==9 and t['declaration']>=0 and tokens[nodes[t['declaration']]['token']]['text']=='Some' and tokens[nodes[types[t['pool']]['declaration']]['token']]['text']=='Choice']
 assert len(payloads)==1,payloads
 payload=payloads[0];assert payload['size']==9
 fields=[];field=payload['first']
 while field>=0:
  fields.append(nodes[field]);field=nodes[field]['next']
 assert [tokens[f['token']]['text'] for f in fields]==['flag','value']
 assert [types[f['type_id']]['size'] for f in fields]==[1,8]
 declarations={int(v):int(t) for t,v in re.findall(r'\bg_t(\d+)\s+g_v(\d+)\s*=',text)}
 addresses=[tuple(map(int,row)) for row in re.findall(r'g_v(\d+)=g_ref\(\(unsigned char\*\)&g_v(\d+)\+(\d+)\);',text)]
 checks={}
 if candidate:
  checks['only_fresh_payload_fields_use_fast_addresses']=len(addresses)==2 and {offset for ref,base,offset in addresses}=={0,1} and len({base for ref,base,offset in addresses})==1 and all(declarations.get(base)==payload['id'] for ref,base,offset in addresses)
  stores=True
  for ref,base,offset in addresses:
   field_type=fields[0]['type_id']
   if offset==1:field_type=fields[1]['type_id']
   if not re.search(r'g_store_'+str(field_type)+r'\(g_v'+str(ref)+r',g_v\d+\);',text):stores=False
  checks['payload_fields_keep_exact_bool_i64_stores']=stores and len(addresses)==2
 else:checks['baseline_payload_fastpath_absent']=not addresses
 payload_temps=[v for v,t in declarations.items() if t==payload['id']]
 checks['exact_nine_byte_payload_copy_retained']=any(re.search(r'memcpy\(g_image_cursor\d+,&g_v'+str(v)+r',9\);',text) for v in payload_temps)
 checks['enum_tag_and_image_allocation_retained']=bool(re.search(r'g_write_length\(g_enum\d+,1,1\);',text)) and 'g_image_space(' in text and 'g_image_finish(' in text
 switches=re.findall(r'switch\(g_read_length\(g_address\(g_v(\d+)\),1\)\)',text)
 checks['both_enum_dispatch_arms_keep_integer_payload_offset']=len(switches)==1
 if len(switches)==1:
  enum_base=switches[0]
  for variant in [0,1]:
   arm=re.search(r'case '+str(variant)+r':\{(.*?)break;\}',text,re.S)
   valid=False
   if arm:
    refs=re.findall(r'g_v(\d+)=g_offset\(g_v'+enum_base+r',1\);',arm.group(1))
    valid=len(refs)==1 and bool(re.search(r'g_fn\d+\([^;\n]*\bg_v'+refs[0]+r'\);',arm.group(1)))
   checks['both_enum_dispatch_arms_keep_integer_payload_offset'] &= valid
 return checks
for config in configs:
 source=config['source']
 for level in [0,2]:
  for debug in [False,True]:
   label=source.stem+'-O'+str(level)+'-debug'+str(debug);native=O/(label+'.c');base=[str(Path(a.compiler).resolve()),source,'--stdlib',R/'stdlib','--target','native','-O'+str(level)]
   if debug:base.append('--debug')
   execute([*base,'--standalone','-o',native]);raw=execute([*base,'--dump-ir']);(O/(label+'.json')).write_text(raw);ir=json.loads(raw);text=native.read_text();functions={}
   for n in ir['nodes']:
    if n['kind']==3 and ir['tokens'][n['token']]['source']==0:functions.setdefault(ir['tokens'][n['token']]['text'],[]).append(n['id'])
   names=list(config['positive'])+config.get('old',[])+config.get('image',[])
   for name in names:
    b='\n'.join(body(text,identity) for identity in functions[name]);fast=re.findall(r'g_v\d+=g_ref\(\(unsigned char\*\)&g_v\d+\+(\d+)\);',b);offsets={int(x) for x in fast};checks={}
    if name in config['positive']:
     if a.candidate:checks['proved_field_addresses']=set(config['positive'][name])<=offsets
     else:checks['baseline_integer_offsets']=not fast and 'g_offset(' in b
    elif name=='enumeration':
     checks.update(enum_payload_checks(ir,b,a.candidate))
    else:
     checks['fastpath_absent']=not fast
     if name in config.get('image',[]):checks['image_path_retained']='g_image_' in b
     else:checks['integer_offsets_retained']='g_offset(' in b
    if name==config.get('zero'):
     zero_types=[t['id'] for t in ir['types'] if t['kind']==8 and t['declaration']>=0 and ir['tokens'][ir['nodes'][t['declaration']]['token']]['text']=='Zero'];assert len(zero_types)==1
     refs=re.findall(r'g_v(\d+)=g_offset\(g_v\d+,0\);',b);checks['zero_width_field_keeps_offset']=any(re.search(r'g_store_'+str(zero_types[0])+r'\(g_v'+ref+r',g_v\d+\);',b) for ref in refs)
    if name==config.get('default_path'):
     count=len(re.findall(r'g_v\d+=g_offset\(g_ref\(&g_v\d+\),[01]\);',b));checks['default_branch_fields']=count>=4
     if a.candidate:checks['default_branch_fields']=count==0 and len(fast)>=8
    if name==config.get('bounds'):checks['dynamic_bounds_helper_retained']='g_element_at(' in b
    rows.append(dict(source=str(source.relative_to(R)),function=name,optimization=level,debug=debug,fast_offsets=sorted(offsets),checks=checks,passed=all(checks.values()),source_sha256=sha(source),C_sha256=sha(native)))
status='failed'
if rows and all(r['passed'] for r in rows):status='passed'
report=dict(schema='field-address-structure-v2',predecessor_validator_sha256='7920f5719699c798f8c36b57e23e50f4f1a5b4868ed9c6305730365008dd1cef',status=status,candidate=a.candidate,checks=len(rows),compiler_sha256=sha(Path(a.compiler)),rows=rows,commands=commands);(O/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(status,len(rows));assert status=='passed'
