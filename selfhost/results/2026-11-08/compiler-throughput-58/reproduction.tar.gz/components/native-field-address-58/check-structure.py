from pathlib import Path
import argparse,hashlib,json,os,re,subprocess
R=Path('/home/jacobt/src/goose-to-wasm');H=Path(__file__).resolve().parent;G=H/'guards';a=argparse.ArgumentParser();a.add_argument('--compiler',required=True);a.add_argument('--output-dir',required=True);a.add_argument('--candidate',action='store_true');a=a.parse_args();O=Path(a.output_dir).resolve();O.mkdir();os.sched_setaffinity(0,{4});sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[];commands=[]
configs=[dict(source=G/'construction.goose',positive={'constructed':[0,1,3,12],'defaulted':[0,1,3,12],'zero_field':[0]},old=['enumeration','selected'],zero='zero_field'),dict(source=G/'default-path.goose',positive={'default_path':[0,1]},default_path='default_path'),dict(source=R/'build/completion-runs/native-local-init-58/guards/padding.goose',positive={'padded':[0,4]}),dict(source=R/'build/completion-runs/native-result-init-58/guards/returns.goose',positive={'packed':[0,1]},old=['owned','large']),dict(source=R/'build/completion-runs/native-result-init-58/guards/image.goose',positive={},image=['image']),dict(source=G/'bounds.goose',positive={'index_at':[0,1]},bounds='index_at')]
def execute(cmd):
 p=subprocess.run([str(x) for x in cmd],cwd=R,text=True,capture_output=True,timeout=60);commands.append(dict(command=[str(x) for x in cmd],exit=p.returncode,stderr=p.stderr));assert p.returncode==0,commands[-1];return p.stdout
def body(text,identity):
 m=re.search(r'\bg_fn'+str(identity)+r'\([^;]*?\)\s*\{',text);assert m,identity
 at=m.end();start=at;depth=1
 while depth:
  if text.startswith('//',at):at=text.index('\n',at);continue
  if text.startswith('/*',at):at=text.index('*/',at+2)+2;continue
  ch=text[at]
  if ch in ['"',"'"]:
   quote=ch;at+=1
   while text[at]!=quote:
    if text[at]=='\\':at+=1
    at+=1
  elif ch=='{':depth+=1
  elif ch=='}':depth-=1
  at+=1
 return text[start:at-1]
for config in configs:
 source=config['source']
 for level in [0,2]:
  for debug in [False,True]:
   label=source.stem+'-O'+str(level)+'-debug'+str(debug);native=O/(label+'.c');base=[str(Path(a.compiler).resolve()),source,'--stdlib',R/'stdlib','--target','native','-O'+str(level)]
   if debug:base.append('--debug')
   execute([*base,'--standalone','-o',native]);raw=execute([*base,'--dump-ir']);(O/(label+'.json')).write_text(raw);ir=json.loads(raw);text=native.read_text();functions={}
   for n in ir['nodes']:
    if n['kind']==3 and ir['tokens'][n['token']]['source']==0:functions.setdefault(ir['tokens'][n['token']]['text'],[]).append(n['id'])
   names=list(config['positive'])+config.get('old',[])+config.get('image',[])
   for name in names:
    b='\n'.join(body(text,identity) for identity in functions[name]);fast=re.findall(r'g_v\d+=g_ref\(\(unsigned char\*\)&g_v\d+\+(\d+)\);',b);offsets={int(x) for x in fast};checks={}
    if name in config['positive']:
     if a.candidate:checks['proved_field_addresses']=set(config['positive'][name])<=offsets
     else:checks['baseline_integer_offsets']=not fast and 'g_offset(' in b
    else:
     checks['fastpath_absent']=not fast
     if name in config.get('image',[]):checks['image_path_retained']='g_image_' in b
     else:checks['integer_offsets_retained']='g_offset(' in b
    if name==config.get('zero'):
     zero_types=[t['id'] for t in ir['types'] if t['kind']==8 and t['declaration']>=0 and ir['tokens'][ir['nodes'][t['declaration']]['token']]['text']=='Zero'];assert len(zero_types)==1
     refs=re.findall(r'g_v(\d+)=g_offset\(g_v\d+,0\);',b);checks['zero_width_field_keeps_offset']=any(re.search(r'g_store_'+str(zero_types[0])+r'\(g_v'+ref+r',g_v\d+\);',b) for ref in refs)
    if name==config.get('default_path'):
     count=len(re.findall(r'g_v\d+=g_offset\(g_ref\(&g_v\d+\),[01]\);',b));checks['default_branch_fields']=count>=4
     if a.candidate:checks['default_branch_fields']=count==0 and len(fast)>=8
    if name==config.get('bounds'):checks['dynamic_bounds_helper_retained']='g_element_at(' in b
    rows.append(dict(source=str(source.relative_to(R)),function=name,optimization=level,debug=debug,fast_offsets=sorted(offsets),checks=checks,passed=all(checks.values()),source_sha256=sha(source),C_sha256=sha(native)))
status='failed'
if rows and all(r['passed'] for r in rows):status='passed'
report=dict(status=status,candidate=a.candidate,checks=len(rows),compiler_sha256=sha(Path(a.compiler)),rows=rows,commands=commands);(O/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(status,len(rows));assert status=='passed'
