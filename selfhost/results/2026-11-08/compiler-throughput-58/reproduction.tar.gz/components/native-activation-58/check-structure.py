from pathlib import Path
import argparse,hashlib,json,re,subprocess,os
ROOT=Path('/home/jacobt/src/goose-to-wasm');W=ROOT/'build/completion-runs'
parser=argparse.ArgumentParser();parser.add_argument('--runtime-report',required=True);parser.add_argument('--output-dir',required=True);parser.add_argument('--suite',choices=['a9','plain-record','format'],required=True);a=parser.parse_args();H=Path(a.output_dir).resolve();H.mkdir();os.sched_setaffinity(0,{3})
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
contracts={}
if a.suite=='a9':
 p=W/'native-activation-58/guards/structure.json';c=json.loads(p.read_text());expected={n:False for n in c['empty']};expected.update({n:True for n in c['retained']});contracts[c['source']]=(expected,p,sha(p))
 p=W/'native-activation-review-58/contract.json';c=json.loads(p.read_text());contracts[c['source']]=({n:v['g_activation_enter'] for n,v in c['native_structural'].items()},p,sha(p))
elif a.suite=='plain-record':
 for n in ['contract.json','mutations-contract.json']:
  p=W/'native-activation-review-58/plain-record'/n;c=json.loads(p.read_text());contracts[c['source']]=(c['native_structural'],p,sha(p))
else:
 p=W/'native-activation-format-58/guards/contract.json';c=json.loads(p.read_text());contracts[c['source']]=(c['native_structural'],p,sha(p))
proof=json.loads(Path(a.runtime_report).read_text());assert proof['status']=='passed';rows=[];seen=set()
def body(c,identity):
 m=re.search(r'\bg_fn'+str(identity)+r'\([^;]*?\)\s*\{',c);assert m,identity
 begin=m.end();at=begin;depth=1
 while depth:
  if c.startswith('//',at):at=c.index('\n',at);continue
  if c.startswith('/*',at):at=c.index('*/',at+2)+2;continue
  ch=c[at]
  if ch in ['"',"'"]:
   quote=ch;at+=1
   while c[at]!=quote:
    if c[at]=='\\':at+=1
    at+=1
  elif ch=='{':depth+=1
  elif ch=='}':depth-=1
  at+=1
 return c[begin:at-1]
for result in proof['results']:
 command=proof['commands'][result['compile_command']]['command']
 if '--target' not in command or command[command.index('--target')+1]!='native':continue
 artifact=Path(command[command.index('-o')+1])
 if str(artifact) in seen:continue
 seen.add(str(artifact));source=Path(command[1]);relative=str(source.relative_to(ROOT));expected,contract,pin=contracts[relative]
 ircommand=[command[0],str(source),'--target','native','--stdlib',str(ROOT/'stdlib'),'-O'+str(result['level']),'--dump-ir']
 if '--debug' in command:ircommand.append('--debug')
 p=subprocess.run(ircommand,cwd=ROOT,text=True,capture_output=True);assert p.returncode==0,p.stderr
 irpath=H/('ir-'+str(len(rows))+'.json');irpath.write_text(p.stdout);ir=json.loads(p.stdout);native=artifact.read_text();functions={}
 for node in ir['nodes']:
  if node['kind']==3:
   token=ir['tokens'][node['token']]
   if token['source']==0 and token['text'] in expected:functions[token['text']]=node['id']
 assert functions.keys()==expected.keys(),(functions.keys(),expected.keys())
 for name,activation in expected.items():
  b=body(native,functions[name]);checks=dict(stack='g_stack_check();' in b,enter=('g_activation_enter(' in b)==activation,leave=('g_activation_leave(' in b)==activation)
  if not activation:checks.update(zero='g_mark_regions(g_base,0,NULL);' in b,no_frame='GActivation g_activation' not in b,no_watermark='GWatermark g_watermarks' not in b)
  rows.append(dict(source=relative,function=name,node=functions[name],level=result['level'],debug='--debug' in command,activation=activation,checks=checks,passed=all(checks.values()),c_sha256=sha(artifact),contract_sha256=pin,ir_command=ircommand))
status='failed'
if rows and all(r['passed'] for r in rows):status='passed'
report=dict(status=status,checks=len(rows),rows=rows,runtime_report=a.runtime_report,runtime_report_sha256=sha(Path(a.runtime_report)))
(H/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(report['status'],report['checks']);assert report['status']=='passed'
