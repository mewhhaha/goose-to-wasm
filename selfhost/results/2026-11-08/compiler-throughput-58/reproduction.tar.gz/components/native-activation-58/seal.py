from pathlib import Path
import hashlib,json,subprocess,shutil
ROOT=Path('/home/jacobt/src/goose-to-wasm');WORK=ROOT/'build/completion-runs';OUT=Path(__file__).resolve().parent;BASE=WORK/'compiler-recursive-58'
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
for name in ['candidate.patch','cold-stack.patch','activation-and-cold.patch']:
    r=subprocess.run(['patch','--dry-run','--fuzz=0','-p1','-i',str(OUT/name)],cwd=BASE,capture_output=True,text=True)
    assert r.returncode==0,(name,r.stdout,r.stderr)
combined=OUT/'combined'
for folder in ['selfhost','native']:
    shutil.copytree(OUT/folder,combined/folder)
shutil.copy2(OUT/'cold-stack-only/native/storage.h',combined/'native/storage.h')
pins={p.relative_to(combined).as_posix():sha(p) for p in sorted(combined.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}
(OUT/'combined-source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
audit={
    'status':'source-reviewed-only-no-build',
    'base':str(BASE),
    'cleanup_state':['Owned GRegion watermark state','g_fixed_region.stack.top','g_publication_top'],
    'condition':'nonlocal || f.activation_required || f.region_peak>0 || f.indirect.len>0',
    'preserved_entry_checks':'Ordinary g_fn bodies retain g_stack_check. Elided frames still call g_mark_regions(g_base,0,NULL), preserving exact zero-width base/count validation.',
    'actual_effects':{
        'fixed':{'cc_temp':'cc_indirect values call cc_fixed and monotonically push f.indirect; never shortened.',
                 'local_symbols':'Local cc_fixed explicitly marks activation_required.',
                 'typed_clone':'All five actual body g_clone emissions mark activation_required; cc_emit_clone is the other generated g_fixed_alloc site.',
                 'wrappers':'Export/global/worker wrappers unchanged; worker argument g_fixed_begin is outside rewritten g_fn prelude.'},
        'publication':{'cc_map_value':'Marks only when width>0 emits GPublication/g_map.',
                       'result_links':'Direct result GPublication/g_map marks the flag.',
                       'scope_snapshots':'Saved publication pointers alone create no links.'},
        'calls':{'direct_goose':'Callees independently balance own fixed/publication/regions. Empty caller adds no cleanup.',
                 'unsafe':'Extern/indirect/dispatch calls and captured closure creation retain conservatively.',
                 'builtins':'Only21/22/23 and24/25 plain fixed-width int/bool/float push/append allowed. Storage-class checks exclude varint/image elements.'}},
    'nonlocal':'F_NONLOCAL remains conservative, including propagated flags on relays. Throw emission retains the thrower. Cleanup walk between retained activations is unchanged.',
    'signatures':'All aggregate by-value params/results retain in A9; future clone-safe relaxation is separate.',
    'runtime_helper_scan':'Native fixed allocation is reached through g_fixed_begin or generated g_clone_value. New publication links enter through the two marked g_map sites. Store/image/run helpers may mutate receiving regions but do not allocate fixed arena or links.',
    'cold_split':'Exact pthread attribute initialization moved to static noinline/cold helper. Hot GS_INLINE function retains TLS0 branch and identical uintptr here-low<131072 trap. Foreign threads and explicit reset preserve lazy initialization.',
    'remaining':'No compilation/runtime/timing executed for this prototype. Frozen guards must pass baseline first, then final source.',
    'source_pins':{str(p.relative_to(BASE)):sha(p) for p in [BASE/'native/storage.h',BASE/'selfhost/codegen_c.goose',BASE/'selfhost/codegen_c_storage.goose',BASE/'selfhost/codegen_c_images.goose',BASE/'selfhost/codegen_c_threads.goose']}}
(OUT/'source-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
review=WORK/'native-activation-review-58'
report=dict(status='sealed-source-prototype-awaiting-root-build-and-gates',base=str(BASE),
    patches={name:dict(path=str(OUT/name),sha256=sha(OUT/name),dry_run='passed against A5') for name in ['candidate.patch','cold-stack.patch','activation-and-cold.patch']},
    combined_source=str(combined),combined_pins=dict(path=str(OUT/'combined-source-pins.json'),sha256=sha(OUT/'combined-source-pins.json')),
    review=dict(agent='/root/compiler_ceiling_review',activation_approved_sha256=sha(OUT/'candidate.patch'),cold_approved_sha256=sha(OUT/'cold-stack.patch'),amendment='Explicit zero-width g_mark_regions preserves base validation.',no_remaining_source_blocker=True),
    audit=str(OUT/'source-audit.json'),
    guards=dict(manifest=str(OUT/'guards/cases.json'),manifest_sha256=sha(OUT/'guards/cases.json'),contract_rows=24,
                profiles='O0/O2 normal/debug native+Wasm; native stdin ABI needs bench/host_input.c with-rdynamic.',
                structure=str(OUT/'guards/structure.json'),nonlocal_source=str(review/'nonlocal-relay.goose'),nonlocal_source_sha256=sha(review/'nonlocal-relay.goose'),nonlocal_contract=str(review/'contract.json'),
                stack_tls=str(OUT/'guards/stack-tls-contract.json'),status='Frozen before execution; not a gate pass.'),
    build_plan='Root combines into A8/A9: G1 emit->clang->G2 emit->clang->G3 C fixedpoint before compiler-host timing.',no_live_edits=True,no_git_mutations=True)
(OUT/'delivery.json').write_text(json.dumps(report,indent=2)+'\n')
print(report['patches'])
