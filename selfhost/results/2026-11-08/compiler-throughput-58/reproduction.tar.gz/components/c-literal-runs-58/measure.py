from pathlib import Path
import hashlib,json,re
R=Path('/home/jacobt/src/goose-to-wasm');H=Path(__file__).resolve().parent;P=R/'build/completion-runs/compiler-lean-format-58/compiler.c';text=P.read_text();literals=[]
# C lexical tokens keep comment and character contents out of string accounting.
pattern=re.compile(r'//[^\n]*|/\*.*?\*/|\'(?:\\.|[^\'\\])*\'|"(?:\\.|[^"\\])*"',re.S)
for m in pattern.finditer(text):
 raw=m.group()
 if not raw.startswith('"'):continue
 body=raw[1:-1]
 if not re.fullmatch(r'(?:\\[0-3][0-7]{2})+',body):continue
 decoded=bytes(int(body[i+1:i+4],8) for i in range(0,len(body),4));safe=0;runs=0;inside=False
 for b in decoded:
  ordinary=32<=b<=126 and b not in (34,92,63)
  if ordinary:
   safe+=1
   if not inside:runs+=1
  inside=ordinary
 path=decoded.endswith(b'.goose') and b'/' in decoded and all(32<=b<=126 for b in decoded)
 literals.append(dict(encoded_bytes=len(raw),decoded_bytes=len(decoded),safe_bytes=safe,runs=runs,path=path))
def total(items):
 d={k:sum(x[k] for x in items) for k in ['encoded_bytes','decoded_bytes','safe_bytes','runs']};d['literals']=len(items);d['unsafe_bytes']=d['decoded_bytes']-d['safe_bytes'];d['predicted_saved_C_bytes']=d['safe_bytes']*3;d['old_writer_appends']=d['decoded_bytes']*4+2*len(items);d['new_writer_appends']=d['unsafe_bytes']*4+d['runs']+2*len(items);return d
all_literals=total(literals);paths=total([x for x in literals if x['path']]);result=dict(input=str(P.relative_to(R)),sha256=hashlib.sha256(P.read_bytes()).hexdigest(),C_bytes=len(P.read_bytes()),method='Lexical census of nonempty string tokens entirely fixed-width octal, the exact existing cc_bytes output. Excludes comments/chars and empty literals. Source path subset requires printable ASCII, a slash and .goose suffix. Predicted transformed lengths/calls, not a performance measurement.',octal_literals=all_literals,source_path_literals=paths)
result['predicted_C_bytes']=result['C_bytes']-all_literals['predicted_saved_C_bytes'];(H/'census.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
