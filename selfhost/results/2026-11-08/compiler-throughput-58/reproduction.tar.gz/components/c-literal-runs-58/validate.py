from pathlib import Path
import hashlib,json,os,subprocess,sys
R=Path('/home/jacobt/src/goose-to-wasm');H=Path(__file__).resolve().parent;G=H/'guards';O=H/'validation';O.mkdir();os.sched_setaffinity(0,{4});C=json.loads((G/'contract.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();host=R/'build/completion-runs/compiler-lean-format-58/goose'
pins={str((G/'contract.json').relative_to(R)):sha(G/'contract.json'),str(host.relative_to(R)):sha(host)}
for label in ['baseline','candidate']:pins[str((G/(label+'.goose')).relative_to(R))]=sha(G/(label+'.goose'))
for v in C['vectors']:
 p=R/v['path'];assert sha(p)==v['sha256'] and p.read_bytes()==bytes.fromhex(v['expected_hex']);pins[v['path']]=sha(p)
report=dict(status='running',method='Exact extracted helper source, same A11 host; independent frozen raw bytes vs C consumer numeric arrays. All baseline helper profiles pass before any candidate execution. No full compiler build, C++ oracle or timing claims.',cpu=4,input_sha256=pins,commands=[],runs=[])
def save():(O/'report.json').write_text(json.dumps(report,indent=2)+'\n')
def execute(command,stdin=None):
 p=subprocess.run([str(x) for x in command],cwd=R,input=stdin,capture_output=True,timeout=60);row=dict(command=[str(x) for x in command],exit=p.returncode,stdout=p.stdout.decode('utf8','replace'),stderr=p.stderr.decode('utf8','replace'));report['commands'].append(row);save();assert p.returncode==0,row;return p.stdout,len(report['commands'])-1
def validate_literals(literals,directory):
 lines=literals.decode('ascii').splitlines();assert len(lines)==len(C['vectors']),len(lines);text='#include <string.h>\n#include <stdio.h>\n'
 for i,(literal,v) in enumerate(zip(lines,C['vectors'])):
  assert literal.startswith('"') and literal.endswith('"');data=bytes.fromhex(v['expected_hex']);nums=','.join(str(x) for x in data)
  if not nums:nums='0'
  text+='static const unsigned char got'+str(i)+'[]='+literal+';\nstatic const unsigned char expected'+str(i)+'[]={'+nums+'};\n'
  text+='_Static_assert(sizeof(got'+str(i)+')=='+str(len(data)+1)+',"literal size");\n'
 text+='int main(void){\n'
 for i,v in enumerate(C['vectors']):
  text+='if(memcmp(got'+str(i)+',expected'+str(i)+','+str(v['length'])+') || got'+str(i)+'['+str(v['length'])+']!=0)return '+str(i+1)+';\n'
 text+='puts("literal bytes ok");return 0;}\n';source=directory/'consumer.c';source.write_text(text);profiles=[]
 for index,profile in enumerate(C['c_profiles']):
  binary=directory/('consumer-'+str(index));execute([profile['cc'],*profile['flags'],str(source),'-o',str(binary)]);stdout,command=execute([str(binary)]);assert stdout==b'literal bytes ok\n';profiles.append(dict(profile=profile,command=command,passed=True))
 return profiles
try:
 for label in ['baseline','candidate']:
  for profile in C['helper_profiles']:
   n=label+'-O'+str(profile['optimization'])+'-debug'+str(profile['debug']);D=O/n;D.mkdir();source=G/(label+'.goose');c=D/'helper.c';binary=D/'helper';command=[host,source,'--target','native','--stdlib',R/'stdlib','-O'+str(profile['optimization']),'--standalone','-o',c]
   if profile['debug']:command.append('--debug')
   execute(command);execute(['/usr/bin/gcc','-std=gnu11','-O2',c,'-lm','-ldl','-pthread','-o',binary]);literals,run=execute([binary]);(D/'literals.txt').write_bytes(literals);consumers=validate_literals(literals,D)
   wasm=D/'helper.wasm';command=[host,source,'--target','wasm-direct','--stdlib',R/'stdlib','-O'+str(profile['optimization']),'--standalone','-o',wasm]
   if profile['debug']:command.append('--debug')
   execute(command);engines=[]
   for engine,cmd in [('wasmtime',[R/'build/bin/goose-wasmtime','--no-cache',wasm]),('v8',['node',R/'scripts/run_wasm.mjs',wasm])]:
    data,j=execute(cmd);assert data==literals,engine;engines.append(dict(engine=engine,command=j,exact_output=True))
   report['runs'].append(dict(label=label,profile=profile,helper_run=run,consumer_profiles=consumers,engine_runs=engines,literals_sha256=sha(D/'literals.txt'),passed=True));save();print(n,'passed',flush=True)
  if label=='baseline':report['baseline_admission']='passed';save()
 for p,h in pins.items():assert sha(R/p)==h
 report['status']='passed';report['helper_executions']=len(report['runs'])*3;report['C_consumer_executions']=len(report['runs'])*len(C['c_profiles']);report['decoded_vector_checks']=report['C_consumer_executions']*len(C['vectors'])
except BaseException as error:report['status']='failed';report['error']=repr(error);raise
finally:save()
