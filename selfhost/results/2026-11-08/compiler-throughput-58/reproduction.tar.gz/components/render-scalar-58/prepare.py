from pathlib import Path
import difflib,hashlib,json
root=Path(__file__).resolve().parent
baseline=root.parent/'compiler-memo-58/selfhost/checker.goose'
old=baseline.read_text()
needle='''    var first = 0; if builtin == 2 { first = 1; }
    for index in first..args.count { let argument = check_list_at(c, args, index); if !check_render_layout(p, c, p.nodes[argument].type_id, p.nodes[argument].token) { return -1; } }
'''
replacement='''    var first = 0; if builtin == 2 { first = 1; }
    if !hooks_exist {
        var scalar = true;
        for index in first..args.count {
            let ty = p.nodes[check_list_at(c, args, index)].type_id;
            if ty < 0 { scalar = false; break; }
            let kind = p.types[ty].kind;
            if kind != TY_BOOL && kind != TY_INT && kind != TY_FLOAT { scalar = false; break; }
        }
        if scalar {
            while c.render_hooks.len < p.types.len { c.render_hooks.push(-1); }
            return -2;
        }
    }
    for index in first..args.count { let argument = check_list_at(c, args, index); if !check_render_layout(p, c, p.nodes[argument].type_id, p.nodes[argument].token) { return -1; } }
'''
assert old.count(needle)==1
new=old.replace(needle,replacement)
(root/'checker.goose').write_text(new)
(root/'candidate.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/selfhost/checker.goose',tofile='b/selfhost/checker.goose')))
(root/'identities.json').write_text(json.dumps({'baseline_path':str(baseline),'baseline_sha256':hashlib.sha256(old.encode()).hexdigest(),'candidate_sha256':hashlib.sha256(new.encode()).hexdigest()},indent=2)+'\n')
