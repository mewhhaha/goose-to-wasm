from pathlib import Path
import hashlib,importlib.metadata,json,os,shutil,subprocess,sys,time
ROOT=Path('/home/jacobt/src/goose-to-wasm');WORK=ROOT/'build/completion-runs';HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();os.sched_setaffinity(0,{3})
review=WORK/'native-activation-review-58';contracts=[review/'plain-record/contract.json',review/'plain-record/mutations-contract.json'];cases=[];pins={}
for path in contracts:
 contract=json.loads(path.read_text());source=ROOT/contract['source'];assert sha(source)==contract['sha256'];pins[str(path)]=sha(path);pins[str(source)]=sha(source)
 for target in contract['targets']:
  for debug in contract['debug']:
   cases.append(dict(id='activation58/plain-record/'+source.stem+'/'+target+'/debug-'+str(debug),source=contract['source'],phase='run',target=target,levels=contract['levels'],stdin=contract['stdin'],expect=dict(stdout=contract['stdout'],exit=contract['exit']),debug=debug,provenance=contract['method']))
manifest=dict(schema='goose-source-output-contracts-v1',upstream=json.loads((ROOT/'tests/conformance/cases.json').read_text())['upstream'],cases=cases,source_sha256=pins)
new_manifest=HERE/'plain-record-cases.json';new_manifest.write_text(json.dumps(manifest,indent=2)+'\n');assert sum(len(c['levels']) for c in cases)==16
old_manifest=WORK/'native-activation-58/guards/cases.json';assert sha(old_manifest)=='766b5dfb25d7da67aa5cdb01e4e183c2f98ee2ba68af0beee0e32f0de1dd3f38'
report=dict(status='running',scope='Repaired source prerequisites; baseline57 fully admits frozen independent controls before any A9 candidate guard run. No goldens changed.',environment=dict(cpu=3,workers=1,node=shutil.which('node'),node_version=subprocess.check_output(['node','--version'],text=True).strip(),wasmtime=importlib.metadata.version('wasmtime'),gcc='/usr/bin/gcc',gcc_sha256=sha(Path('/usr/bin/gcc')),native_host_sha256=sha(ROOT/'build/bin/goose-wasmtime')),input_sha256=pins,runs=[])
assert report['environment']['node_version'].startswith('v24.') and report['environment']['wasmtime']=='50.0.1'
def save():(HERE/'report.json').write_text(json.dumps(report,indent=2)+'\n')
def run(label,compiler,suite,manifest,engine,expected):
 directory=HERE/(label+'-'+suite+'-'+engine);command=['taskset','-c','3',sys.executable,str(ROOT/'tests/conformance.py'),'--compiler',str(compiler),'--manifest',str(manifest),'--output-dir',str(directory),'--engine',engine,'--cc',str(WORK/'semantic-guards-58/native-gcc.py'),'--timeout','60'];started=time.monotonic()
 with (HERE/(directory.name+'.log')).open('x') as stream:r=subprocess.run(command,cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT)
 proof=json.loads((directory/'report.json').read_text());row=dict(label=label,suite=suite,engine=engine,command=command,exit_code=r.returncode,seconds=time.monotonic()-started,report=str(directory/'report.json'),compiler_sha256=sha(compiler),manifest_sha256=sha(manifest),status=proof['status'],summary=proof.get('summary'),stable_inputs=proof.get('input_sha256')==proof.get('input_sha256_after'));report['runs'].append(row);save();print(label,suite,engine,row['summary'],flush=True)
 assert r.returncode==0 and proof['status']=='passed' and row['stable_inputs'] and proof['summary']==dict(selected=expected,passed=expected,failed=0),row
try:
 prior=WORK/'native-activation-gates-58-admitted'
 for engine in ['wasmtime','v8']:
  proof=json.loads((prior/('baseline57-a9-'+engine)/'report.json').read_text())
  assert proof['status']=='passed' and proof['summary']==dict(selected=24,passed=24,failed=0) and proof['input_sha256']==proof['input_sha256_after']
  report.setdefault('prior_baseline_receipts',[]).append(str(prior/('baseline57-a9-'+engine)/'report.json'))
 for engine in ['wasmtime','v8']:run('baseline57',ROOT/'build/bin/goose','plain-record',new_manifest,engine,16)
 report['baseline_admission']='passed';save()
 for engine in ['wasmtime','v8']:run('a9',WORK/'compiler-native-58/goose','a9',old_manifest,engine,24)
 for path,identity in pins.items():assert sha(Path(path))==identity
 assert sha(old_manifest)=='766b5dfb25d7da67aa5cdb01e4e183c2f98ee2ba68af0beee0e32f0de1dd3f38'
 report['status']='passed'
except BaseException as error:report.update(status='failed',error=repr(error));raise
finally:save()
