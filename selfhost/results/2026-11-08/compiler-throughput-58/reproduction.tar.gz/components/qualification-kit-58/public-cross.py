#!/usr/bin/env python3
"""Public installed compiler must reproduce canonical2 C on identical paths."""
import argparse
import os
from pathlib import Path
import subprocess
import time
from common import WORK, config, paths, read, save, sha
parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--config',required=True)
args=parser.parse_args();data=config(args.config,sealed=True);p=paths(data);proof=read(p['canonical']/'report.json')
assert proof['status']=='passed' and proof['goose_optimization']==2
out=p['cross'];out.mkdir(exist_ok=False);compiler=p['public']/'build/bin/goose';artifact=out/'compiler.c'
emissions=[row for row in proof['commands'] if row.get('name') in ('verify-selfhost','verify-next-generation')]
assert emissions,'Canonical verification command is required for exact source-path identity'
command=list(emissions[-1]['command']);command[0]=str(compiler);command[command.index('-o')+1]=str(artifact)
cwd=Path(emissions[-1]['cwd']);assert cwd==p['canonical']
inputs={str(compiler):sha(compiler),str(Path(__file__)):sha(Path(__file__)),str(p['canonical']/'report.json'):sha(p['canonical']/'report.json')}
for name,value in proof['source_sha256'].items():inputs[str(cwd/'sources'/name)]=value
for name,value in proof['stdlib_sha256'].items():inputs[str(cwd/'stdlib'/name)]=value
for name,value in proof['asset_sha256'].items():inputs[str(cwd/name)]=value
env=dict(os.environ,PATH='/usr/bin:/bin');env.pop('TMPDIR',None);started=time.monotonic();result=subprocess.run(command,cwd=cwd,capture_output=True,text=True,env=env)
report=dict(status='failed',command=command,cwd=str(cwd),exit_code=result.returncode,seconds=time.monotonic()-started,stdout=result.stdout,stderr=result.stderr,compiler_sha256=sha(compiler),expected_c_sha256=proof['executable_c_sha256'],goose_optimization=2,input_sha256=inputs,input_sha256_after={name:sha(Path(name)) for name in inputs})
assert report['input_sha256']==report['input_sha256_after']
if result.returncode==0:
    report['c_sha256']=sha(artifact)
    if report['c_sha256']==report['expected_c_sha256']:
        report['status']='passed'
save(out/'report.json',report);assert report['status']=='passed',report;print(report['status'])
