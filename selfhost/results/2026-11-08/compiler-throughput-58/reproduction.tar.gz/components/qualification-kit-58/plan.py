#!/usr/bin/env python3
"""Read-only inventory and deferred public-artifact commands; executes no gate."""
import argparse
import collections
import sys
from common import HERE, ROOT, WORK, config, paths, read, row_keys, save, sha

parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--config',default=HERE/'config.pending.json');parser.add_argument('--output',default=HERE/'plan.json');args=parser.parse_args();data=config(args.config);p=paths(data)
manifest_path=ROOT/'tests/conformance/cases.json';manifest=read(manifest_path);parent_manifest=read(WORK/'public-57/tests/conformance/cases.json')
assert manifest['cases'][:len(parent_manifest['cases'])]==parent_manifest['cases']
parent=read(WORK/data['parent_full_dir']/'report.json');old=row_keys(parent)
expected={(case['id'],level) for case in manifest['cases'] for level in case['levels']};assert len(expected)==sum(len(case['levels']) for case in manifest['cases']);assert old.keys()<=expected
curated=collections.Counter()
for case in manifest['cases']:
    if 'corpus/' in case['id']:curated[case['target']]+=len(case['levels'])
commands=[]
def add(label,command,note='',cwd=None):
    row=dict(label=label,command=list(map(str,command)),note=note)
    if cwd is not None:row['cwd']=str(cwd)
    commands.append(row)
python=sys.executable;public_compiler=p['public']/'build/bin/goose'
def controls(label,compiler):
    if data['new_controls_manifest'] is not None:
        for engine in ('wasmtime','v8'):
            directory=data.get('control_report_dirs',{}).get(label+'-'+engine,'qualify58-'+label+'-'+engine)
            add(label+'-new-controls-'+engine,[python,ROOT/'tests/conformance.py','--compiler',compiler,'--manifest',WORK/data['new_controls_manifest'],'--output-dir',WORK/directory,'--engine',engine],
                'Run both baseline engines before candidate controls; every new case object and expectation is unchanged.')
controls('baseline',p['parent_compiler'])
for stage,name in [('transition','snapshot-58-A19-reproduced'),('final','snapshot-58-reproduced')]:
    add('reproduce-'+stage+'-source',[python,HERE/'assemble.py','--config',args.config,'--stage',stage,'--output-dir',WORK/name],
        'Stage-specific unified patch from verified57; preserve A19 intermediate rather than pretending its sources equal A22.')
if not data.get('reuse_native_runtime',False):
    add('native-runtime',['/usr/bin/env','CC='+data['cc'],python,p['source']/'native/tests/check.py','--output',p['native']],
        'Run only if no exact reusable receipt is configured. Different headers/driver/pack require a fresh gate.')
for index,root in enumerate((p['public'],p['public_second'])):
    add('public-source-export-'+str(index+1),[python,HERE/'prepare.py','--config',args.config,'--output-dir',root],
        'Independent source-only export; optional selected profile pair and all native_sources must appear in export.json.')
    bootstrap=['/usr/bin/env','-u','TMPDIR','PATH=/usr/bin:/bin','/usr/bin/python3',root/'scripts/bootstrap.py','--verify','--cc',data['cc']]
    if index:bootstrap+=['--optimization',2]
    add('clean-public-bootstrap-'+str(index+1),bootstrap,
        'First root proves default2, second explicit2; profile supplied means actual profile_used true, exactC/data/flags, no silent fallback.',cwd=root)
add('public-smoke',[python,HERE/'public-smoke.py','--config',args.config])
add('public-cross-opt2',[python,HERE/'public-cross.py','--config',args.config],
    'Reuse canonical relative source arguments and cwd exactly; validate public ELF output against canonical C2.')
controls('candidate',public_compiler)
add('full-contracts',[python,HERE/'durable-tools/conformance_shards.py','--compiler',public_compiler,'--output-dir',p['full'],'--jobs',4],
    'Qualify the actual public ELF, not the independent plain canonical compiler. Preserve all100 inherited gaps and every7871 parent row.')
add('curated-v8',[python,HERE/'v8.py','--compiler',public_compiler,'--output-dir',p['v8'],'--jobs',2])
for command in data['independent_guard_commands']:add('independent-guard',command,'Use the actual selected public compiler and immutable guard expectations.')
add('compare-parent',[python,HERE/'compare.py','--config',args.config])
add('audit-final-gates',[python,HERE/'audit.py','--config',args.config])
report=dict(status='prepared-only-no-gates-run',root_seal=data['status'],source_mutable=data['status']!='sealed-for-composition',parent_summary=parent['summary'],parent_rows=len(old),inherited_gaps=sum(row['status']!='pass' for row in old.values()),current_manifest_sha256=sha(manifest_path),current_rows=len(expected),new_rows=len(expected-old.keys()),curated=dict(curated),curated_rows=sum(curated.values()),commands=commands)
report['recorded_chain']=dict(parent_seed=str(p['parent_seed']),transition_source=str(p['transition_source']),transition_stage=str(p['transition']),transition_seed=str(p['transition_seed']),final_source=str(p['source']),canonical_plain_stage=str(p['canonical']),final_seed=str(p['seed']),note='Existing verified reports are audited stage-to-own-source. Do not rerun bootstrap into occupied directories; portable REPRODUCE.py recreates the full0→2 chain in new roots.')
report['native_receipt']=dict(path=str(p['native']/'report.json'),reuse_configured=data.get('reuse_native_runtime',False),rule='Exact45 receipt can be reused only after header/runtime/fixture/driver/pack identity checks; no repeat for Goose-only changes.')
report['pending']=['Root profile winner/policy and final seal; current pending config makes no final qualification claim.','Two independent public-root bootstrap proofs and exact profile-use truth when a profile is supplied.','184 new rows: baseline and actual public candidate under both public runner engines.','Complete8055 full rows,4780 curated rows,100 unchanged gaps, actual public ELF identity.','Independent guard receipts, source-only inventory including A19 intermediate and profile pair, capsule pin coverage.','Final benchmarks/README/charts/evidence and delivery remain root-owned.']
report['rules']=['Source build/performance-env.sh in every shell; no runtime gates during matched timings.','Bootstrap/correctness never invokes C++ or uses C++ output as an oracle.','Keep separate A19opt0 and A22opt2 source maps, both unified patches against57 and explicit approved upgrade patch link.','Canonical plain fixedpoint is independent evidence; full/V8/new controls must pin the real public compiler.','Profile is optional as a complete pair; selected profile must be used with exactC hash,Clang identity,flags and data SHA in both public roots.']
save(args.output,report);print('Prepared only:',len(old),'parent rows;',len(expected),'current;',len(expected-old.keys()),'new; commands',len(commands))
