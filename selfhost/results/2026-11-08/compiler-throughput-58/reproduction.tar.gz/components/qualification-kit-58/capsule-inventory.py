#!/usr/bin/env python3
"""Prepare source-only capsule paths; no hashing bulk payloads or archive writes."""
import argparse
import json
import os
from pathlib import Path
from common import HERE, ROOT, WORK, paths, read, save

SUFFIXES={'.goose','.py','.json','.md','.patch','.c','.h','.s','.sh','.stdout','.stderr','.txt','.log','.wat','.mjs'}
PRUNE={'artifacts','upstream','__pycache__','build','node_modules','.git','raw','objects'}
CLONED_TREES={'sources','selfhost','stdlib','native','scripts','tests','examples','bench'}


def inventory(data):
    selected={};hazards=[];large=[];pending=[];bulk_skipped={};p=paths(data)
    def add(name,source,role,expected=None):
        relative=Path(name)
        assert not relative.is_absolute() and '..' not in relative.parts
        source=Path(source)
        if source.is_symlink():
            hazards.append(dict(source=str(source),reason='Symlink requires explicit review; not followed.'));return
        if not source.is_file():
            pending.append(dict(source=str(source),capsule_path=name,role=role));return
        assert source.resolve().is_relative_to(ROOT.resolve()),source
        row=dict(source=str(source),bytes=source.stat().st_size,role=role)
        if expected is not None:row['expected_sha256']=expected
        if name in selected:
            previous=selected[name]
            if previous['source']!=row['source']:
                assert expected is not None and previous.get('expected_sha256')==expected,name
                previous.setdefault('equivalent_sources',[]).append(row['source'])
            if expected is not None:
                assert previous.get('expected_sha256',expected)==expected,name
                previous['expected_sha256']=expected
            previous.setdefault('additional_roles',[]).append(role)
            return
        selected[name]=row
    export=read(p['public']/'export.json')
    for name,value in export['source_sha256'].items():add('source/'+name,p['public']/name,'frozen-public-source',value)
    for name,value in read(p['parent_source']/'source-pins.json').items():add('parent-source/'+name,p['parent_source']/name,'parent57-source',value)
    add('parent-source/source-pins.json',p['parent_source']/'source-pins.json','parent-source-manifest')
    prior=ROOT/'selfhost/results/2026-11-08/scalar-wasm-locals'
    prior_receipt=read(prior/'reproduction-manifest.json')
    add('qualification/parent57-reproduction.tar.gz',prior/'reproduction.tar.gz','previously-qualified-parent-source-byte-coverage',prior_receipt['capsule_sha256'])
    add('qualification/parent57-reproduction-manifest.json',prior/'reproduction-manifest.json','parent-capsule-fingerprint')
    from composition import core_pins
    for name,value in core_pins(p['transition_source']).items():add('transition-source/'+name,p['transition_source']/name,'transition-A19-core-source',value)
    add('transition-source/source-pins.json',HERE/'transition-core-source-pins.sealed-v3.json','projected74-transition-manifest')
    add('qualification/transition-original-source-pins.json',p['transition_source']/'source-pins.json','original448-provenance-not-input-report')
    for key,prefix in [('parent_seed','parent-seed'),('transition_seed','transition-seed')]:
        for name in ('seed.json','seed.c.gz','sources.tar.gz','proof.json'):add(prefix+'/'+name,p[key]/name,'C-only-seed')
    composition=read(HERE/'capsule-composition.sealed-v3.json')
    for name,member in composition['base_overlays'].items():
        source=WORK/'capsule-inventory-58'/member
        if source.is_file():add(member,source,'exact-base-overlay',composition['base_overlay_sha256'][name])
        else:pending.append(dict(capsule_path=member,role='exact-base-overlay',source='git:'+data['base_commit']+':'+name))
    add('composition.json',HERE/'capsule-composition.sealed-v3.json','portable-stage-composition')
    add('REPRODUCE.py',HERE/'REPRODUCE.py','portable-reproduction-helper')
    add('tools/freeze_seed.py',HERE/'durable-tools/freeze_seed.py','portable-C-only-freezer')
    roots=[]
    for directory in WORK.iterdir():
        if directory.is_dir() and '58' in directory.name and directory.name not in ('capsule-inventory-58','benchmark-campaign-58'):
            if directory.name.startswith(('public-','snapshot-','bench-snapshot-')):continue
            roots.append(directory)
    for directory in roots:
        for base,folders,names in os.walk(directory,followlinks=False):
            base=Path(base)
            kept=[]
            for name in folders:
                child=base/name
                if child.is_symlink():hazards.append(dict(source=str(child),reason='Directory symlink not traversed.'));continue
                if name in PRUNE or (name=='results' and base.name=='selfhost'):continue
                if base==directory and directory.name.startswith('compiler-') and name in CLONED_TREES:continue
                kept.append(name)
            folders[:]=kept
            for name in names:
                source=base/name
                if source.suffix not in SUFFIXES:continue
                if source.is_symlink():
                    add('components/'+source.relative_to(WORK).as_posix(),source,'retained58-source-report-or-attempt');continue
                if source.suffix in ('.c','.s') and directory.name not in ('native-runtime-58-stack-address','native-stack-position-58'):
                    group=bulk_skipped.setdefault(directory.name,dict(files=0,bytes=0));group['files']+=1;group['bytes']+=source.stat().st_size
                    continue
                relative=source.relative_to(WORK)
                if source.stat().st_size>2*1024*1024:
                    large.append(dict(source=str(source),bytes=source.stat().st_size,reason='Large generated/text payload deferred. Include only if pin closure lacks exact seed/archive/source coverage.'));continue
                add('components/'+relative.as_posix(),source,'retained58-source-report-or-attempt')
    reports=[]
    for label,directory in [('transition',p['transition']),('canonical',p['canonical']),('full',p['full']),('v8',p['v8']),('parent-full',WORK/data['parent_full_dir']),('native45',p['native'])]:
        source=directory/'report.json';name='qualification/reports/'+label+'.json';add(name,source,'required-input-pin-report');reports.append(str(source))
        if label in ('full','v8'):
            for child in sorted(directory.glob('shard-*/report.json')):
                add('qualification/shards/'+label+'-'+child.parent.name+'.json',child,'required-raw-shard');reports.append(str(child))
            for child in sorted(directory.glob('cases-*.json')):add('qualification/partitions/'+label+'-'+child.name,child,'partition-manifest')
    for label,root in [('first',p['public']),('second',p['public_second'])]:
        for name in ('build/bootstrap/report.json','build/toolchain.json','export.json'):
            add('qualification/public-'+label+'/'+name,root/name,'public-two-root-proof')
        reports.append(str(root/'build/bootstrap/report.json'))
    for label,directory in data['control_report_dirs'].items():
        source=WORK/directory/'report.json';add('qualification/controls/'+label+'.json',source,'new184-baseline-or-public-candidate');reports.append(str(source))
    for name in ('audit.final.json','config.sealed-v3.json','sealed-v3-reference.json','profile-copied-extra.json'):
        add('qualification/'+name,HERE/name,'selected-final-receipt')
    for source in (p['public']/'build/smoke/report.json',p['cross']/'report.json'):
        add('qualification/'+source.parent.name+'-report.json',source,'public-smoke-or-same-path-cross');reports.append(str(source))
    for name in data['profile_receipt_sha256']:
        source=WORK/name;add('components/'+name,source,'selected-strict-IR-profile-receipt',data['profile_receipt_sha256'][name])
        if source.name=='input-pins.json':reports.append(str(source))
    for name in ('profile.json','profile.profdata'):
        add('source/bootstrap/'+name,p['seed']/name,'selected-profile-pair',export['source_sha256']['bootstrap/'+name])
    extra=HERE/'profile-copied-extra/pack.cpython-314.pyc'
    add('profile-evidence/copied-extra/pack.cpython-314.pyc',extra,'nonsemantic-unused-copied-bytecode-evidence-only')
    pending.extend([dict(role='final-benchmark-receipts',source='benchmark-campaign-58/*/report.json',reason='Wait for timing completion and immutable final benchmark selection.'),dict(role='all-component-input-pin-closure',reason='After quiet timing window, inspect retained JSON input_sha256/inputs_sha256/direct input maps, map every digest to exact source/archive bytes or fingerprint-verified excluded ELF.'),dict(role='large-report-pin-closure',reason='Load required merged/raw report JSONs after timings, include all referenced helpers/goldens/generated tiny native C. Do not copy per-case artifacts or upstream extraction trees.')])
    candidates=sorted({row['source'] for row in selected.values() if Path(row['source']).suffix=='.json' and row['role'] not in ('frozen-public-source','original448-provenance-not-input-report')})
    return dict(status='inventory-prepared-no-pack-or-coverage-audit-run',config='config.sealed-v3.json',files=selected,required_pin_reports=sorted(set(reports)),candidate_report_JSON_paths=candidates,large_payloads_deferred=large,bulk_generated_C_skipped=bulk_skipped,pending=pending,symlink_hazards=hazards,archive_strategy={'source_layout':'Portable meaningful capsule paths for REPRODUCE.py. Reuse snapshot57 archive() SHA deduplication and tar hardlinks; optionally benchmark57 object layout with its restore helper.','existing_helpers':['build/completion-runs/qualify57-publish.py:archive','build/completion-runs/compact-benchmark57.py','build/completion-runs/restore-benchmark57.py'],'canonical_C':'FinalC191a is provided as decoded bytes of source/bootstrap/seed.c.gz; no redundant40MB standalone C. Parent/transition C similarly covered by their gz seeds.','excluded':'All ELF binaries, compiler objects/caches, per-case artifact trees, extracted upstream copies and raw profile intermediate outputs. Preserve exact command/engine/compiler fingerprints and proof of ELF exclusion.','bytecode':'Unused pinnedpyc is evidence only, outside portable product/source/bootstrap trees.','deferred_check':'Run capsule-audit.py against final file map and every actual input-pin report after timings; require exact non-ELF coverage and exact excluded-ELF hashes before archive.','output_rule':'Only a new private WORK path; no root/data or delivered evidence writes, compression or symlink traversal is authorized by inventory mode.'})


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--config',type=Path,default=HERE/'config.sealed-v3.json');parser.add_argument('--output',type=Path,default=WORK/'capsule-inventory-58/plan.pending.json');args=parser.parse_args()
    data=read(args.config);assert data['status']=='sealed-for-composition'
    output=args.output.resolve();assert output.is_relative_to(WORK.resolve()) and not args.output.is_symlink()
    output.parent.mkdir(parents=True,exist_ok=True);result=inventory(data);save(output,result)
    print('Prepared',len(result['files']),'paths;',len(result['required_pin_reports']),'core input-pin reports;',len(result['large_payloads_deferred']),'large payloads deferred; no compression/copy/coverage gate.')
