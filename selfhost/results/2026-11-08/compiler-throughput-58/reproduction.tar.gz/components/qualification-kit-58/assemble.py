#!/usr/bin/env python3
"""Reproduce the separately pinned transition or final compiler source stage."""
import argparse
from pathlib import Path
from common import HERE, config, paths, save
from composition import compose

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--config',required=True);parser.add_argument('--output-dir',type=Path)
parser.add_argument('--stage',choices=('transition','final'),default='final')
args=parser.parse_args();data=config(args.config,sealed=True);p=paths(data)
output=args.output_dir
if output is None:
    output=p['source']
    if args.stage=='transition':output=p['transition_source']
output=output.resolve();pins=compose(data,output,args.stage)
save(output/'source-pins.json',pins)
save(HERE/('reproduction-'+args.stage+'-58.json'),dict(status='passed',stage=args.stage,output=str(output),verified_sha256=pins,method='Verified57 source plus the stage-specific sealed unified patch; extra public test helper is independently pinned.'))
print('Reproduced',args.stage,len(pins),'source inputs at',output)
