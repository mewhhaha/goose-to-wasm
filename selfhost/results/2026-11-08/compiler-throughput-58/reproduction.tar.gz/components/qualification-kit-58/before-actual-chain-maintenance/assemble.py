#!/usr/bin/env python3
"""Compose sealed58 source, including bootstrap entrypoints, from verified57."""
import argparse
from pathlib import Path
import subprocess
from common import ROOT, WORK, config, paths, read, save, sha

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--config',required=True)
parser.add_argument('--output-dir',type=Path)
args=parser.parse_args(); data=config(args.config,sealed=True); p=paths(data)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==data['base_commit']
proof=read(p['parent_proof']/'report.json'); assert proof['status']=='passed' and proof['fixed_point']
expected={'selfhost/'+name:value for name,value in proof['source_sha256'].items()}; expected.update(proof['asset_sha256'])
expected.update({'stdlib/'+name:value for name,value in proof['stdlib_sha256'].items()})
names=set(expected)
for path in (p['parent_source']/'native').rglob('*'):
    if path.is_file() and '__pycache__' not in path.parts:
        names.add(path.relative_to(p['parent_source']).as_posix())
names.update(('selfhost/bootstrap.py','scripts/bootstrap.py','LICENSE'))
patches=[]
for item in data['patches']:
    patch=WORK/item['path']; assert sha(patch)==item['sha256']
    for line in patch.read_text().splitlines():
        if not line.startswith(('--- a/','+++ b/')):
            continue
        name=line[6:].split('\t',1)[0]
        relative=Path(name)
        assert not relative.is_absolute() and '..' not in relative.parts,name
        names.add(name)
    patches.append((item,patch))
output=args.output_dir
if output is None:
    output=p['source']
output=output.resolve(); output.mkdir(parents=True,exist_ok=False)
for name in sorted(names):
    target=output/name; target.parent.mkdir(parents=True,exist_ok=True)
    source=p['parent_source']/name
    if name.startswith('stdlib/'):
        source=WORK/'public-57'/name
    if source.is_file():
        content=source.read_bytes()
    else:
        result=subprocess.run(['git','show',data['base_commit']+':'+name],cwd=ROOT,capture_output=True)
        if result.returncode:
            assert name not in expected,name
            continue  # A new file must be supplied by a sealed patch.
        content=result.stdout
    if name in expected:
        import hashlib
        assert hashlib.sha256(content).hexdigest()==expected[name],name
    target.write_bytes(content)
commands=[]
for item,patch in patches:
    result=subprocess.run(['patch','--fuzz=0','-p1','-i',str(patch)],cwd=output,text=True,capture_output=True)
    commands.append(dict(**item,stdout=result.stdout,stderr=result.stderr,exit_code=result.returncode))
    assert result.returncode==0,commands[-1]
assert not list(output.rglob('*.orig')) and not list(output.rglob('*.rej'))
for name,identity in data['bootstrap_scripts'].items():
    assert sha(output/name)==identity,name
pins={path.relative_to(output).as_posix():sha(path) for path in sorted(output.rglob('*')) if path.is_file()}
save(output/'source-pins.json',pins)
if output==p['source']:
    save(WORK/'snapshot-58-assembly.json',dict(status='sealed private composition',base_commit=data['base_commit'],patches=commands,sha256=pins))
else:
    assert pins==read(p['source']/'source-pins.json'),'Recomposition changed source'
    save(WORK/'reproduction-58.json',dict(status='passed',verified_sha256=pins,method='Verified parent57 plus sealed ordered patches, including bootstrap CLIs and frozen stdlib.'))
print('Composed',len(pins),'source inputs at',output)
