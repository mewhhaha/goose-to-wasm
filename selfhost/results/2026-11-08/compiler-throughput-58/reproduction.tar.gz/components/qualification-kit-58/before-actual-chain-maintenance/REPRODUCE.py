#!/usr/bin/env python3
"""Portable snapshot58 source-only reproduction, including the verified0→2 chain."""
import argparse
import collections
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

HERE=Path(__file__).resolve().parent


def read(path):
    data=path.read_bytes()
    if path.suffix=='.gz':
        data=gzip.decompress(data)
    return json.loads(data)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()


def verify():
    manifest=read(HERE/'capsule-manifest.json');assert manifest['snapshot']==58
    for name,row in manifest['files'].items():
        relative=Path(name);assert not relative.is_absolute() and '..' not in relative.parts
        assert (HERE/name).is_file() and sha(HERE/name)==row['sha256'],name
    return manifest


def run(command,cwd=None,env=None):
    subprocess.run(list(map(str,command)),cwd=cwd,env=env,check=True)


def compose(output):
    composition=read(HERE/'composition.json');assert composition['snapshot']==58
    shutil.copytree(HERE/'parent-source',output)
    for name,member in composition['base_overlays'].items():
        target=output/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(HERE/member,target)
    for row in composition['patches']:
        patch=HERE/row['path'];assert sha(patch)==row['sha256']
        run(['patch','--fuzz=0','-p1','-i',patch],cwd=output)
    assert not list(output.rglob('*.orig')) and not list(output.rglob('*.rej'))
    for name,expected in read(HERE/'source/source-pins.json').items():
        assert sha(output/name)==expected,name
    shutil.copyfile(HERE/'source/source-pins.json',output/'source-pins.json')


def bootstrap(output,cc):
    source=HERE/'source';transition=output.with_name(output.name+'-transition-opt0')
    transition_seed=output.with_name(output.name+'-transition-seed-opt0');final_seed=output.with_name(output.name+'-seed-opt2')
    invocation=[sys.executable,source/'selfhost/bootstrap.py','--source-dir',source/'selfhost',
                '--stdlib',source/'stdlib','--native-dir',source/'native','--cc',cc,'--verify']
    run([*invocation,'--seed-dir',HERE/'parent-seed','--output-dir',transition,'--optimization',0],cwd=source)
    report0=read(transition/'report.json');assert report0['goose_optimization']==0 and report0['fixed_point']
    freezer=HERE/'tools/freeze_seed.py'
    run([sys.executable,freezer,transition,transition_seed,source])
    assert read(transition_seed/'seed.json')['goose_optimization']==0
    run([*invocation,'--seed-dir',transition_seed,'--output-dir',output,'--optimization',2],cwd=source)
    report2=read(output/'report.json');assert report2['goose_optimization']==2 and report2['fixed_point']
    assert not report2.get('seed_matches_sources',False)
    for field in ('source_sha256','asset_sha256','stdlib_sha256'):
        assert report0[field]==report2[field],field
    run([sys.executable,freezer,output,final_seed,source])
    assert read(final_seed/'seed.json')['goose_optimization']==2
    print('Verified C-only transition0 and canonical2; optimized seed:',final_seed)


def contracts(args):
    source=HERE/'source';output=args.output_dir
    if output is None:
        output=HERE/('contracts-'+args.engine)
    command=[sys.executable,source/'tests/conformance.py','--compiler',args.compiler.resolve(),
             '--stdlib',source/'stdlib','--manifest',source/'tests/conformance/cases.json',
             '--output-dir',output.resolve(),'--cc',args.cc,'--engine',args.engine,'--timeout',args.timeout]
    if args.engine=='v8':
        assert shutil.which('node'),'Node is required for V8'
        command+=['--filter','corpus/']
    result=subprocess.run(list(map(str,command)),cwd=source)
    assert result.returncode in (0,1)
    current=read(output/'report.json');assert 'error' not in current
    assert current['input_sha256']==current['input_sha256_after']
    selected=read(source/'tests/conformance/cases.json')['cases']
    if args.engine=='v8':
        selected=[case for case in selected if 'corpus/' in case['id']]
    expected=collections.Counter((case['id'],level) for case in selected for level in case['levels'])
    actual=collections.Counter((row['case'],row['level']) for row in current['results'])
    assert expected==actual,'A contract/level was omitted or duplicated'
    parent=read(HERE/'qualification/parent-conformance.json.gz')
    old={(row['case'],row['level']):row for row in parent['results']}
    if args.engine=='v8':
        old={key:row for key,row in old.items() if 'corpus/' in row['case']}
    new={(row['case'],row['level']):row for row in current['results']}
    inherited={key for key,row in old.items() if row['status']!='pass'}
    failures={key for key,row in new.items() if row['status']!='pass'}
    assert old.keys()<=new.keys()
    passed=failures==inherited
    receipt=dict(status='failed',summary=current['summary'],inherited_gaps=len(inherited),
                 unexpected_failures=sorted(failures-inherited),changed_inherited_gaps=sorted(inherited-failures))
    if passed:
        receipt['status']='passed'
    (output/'parent-comparison.json').write_text(json.dumps(receipt,indent=2)+'\n');print(receipt)
    return int(not passed)


def main():
    parser=argparse.ArgumentParser(description=__doc__);commands=parser.add_subparsers(dest='action',required=True)
    commands.add_parser('verify')
    composing=commands.add_parser('compose');composing.add_argument('--output-dir',type=Path,default=HERE/'composed-58')
    boot=commands.add_parser('bootstrap');boot.add_argument('--output-dir',type=Path,default=HERE/'built-58');boot.add_argument('--cc',default='clang')
    checks=commands.add_parser('contracts');checks.add_argument('--compiler',type=Path,default=HERE/'built-58/goose');checks.add_argument('--output-dir',type=Path);checks.add_argument('--engine',choices=('wasmtime','v8'),default='wasmtime');checks.add_argument('--cc',default='gcc');checks.add_argument('--timeout',type=float,default=15)
    native=commands.add_parser('native-runtime');native.add_argument('--output-dir',type=Path,default=HERE/'native-runtime-58');native.add_argument('--cc',default='clang')
    args=parser.parse_args();verify()
    if args.action=='verify':
        print('All capsule inputs match recorded hashes.');return 0
    if args.action=='compose':
        compose(args.output_dir.resolve());print('All qualified source pins reproduced.');return 0
    if args.action=='bootstrap':
        bootstrap(args.output_dir.resolve(),args.cc);return 0
    if args.action=='native-runtime':
        env=dict(os.environ,CC=args.cc);run([sys.executable,HERE/'source/native/tests/check.py','--output',args.output_dir.resolve()],env=env);return 0
    return contracts(args)


if __name__=='__main__':
    raise SystemExit(main())
