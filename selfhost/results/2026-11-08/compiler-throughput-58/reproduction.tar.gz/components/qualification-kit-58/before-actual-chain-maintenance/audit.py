#!/usr/bin/env python3
"""Validate the completed58 proof chain and exact frozen contract inventory."""
import argparse
import collections
from pathlib import Path
from common import HERE, ROOT, WORK, config, paths, read, row_keys, save, sha


def bootstrap(report, level):
    assert report['status']=='passed' and report['fixed_point']
    assert report['goose_optimization']==level
    assert report['input_sha256']==report['input_sha256_after']
    if 'third_generation_c_sha256' in report:
        assert report['next_generation_c_sha256']==report['third_generation_c_sha256']==report['executable_c_sha256']
    else:
        assert report['generated_c_sha256']==report['next_generation_c_sha256']==report['executable_c_sha256']
    for row in report['commands']:
        command=row['command']; assert row['exit_code']==0
        assert not any(Path(value).name in ('c++','g++','clang++') for value in command)
        if '--target' in command:
            assert '-O'+str(level) in command,command


def chain(data):
    p=paths(data); transition=read(p['transition']/'report.json'); proof=read(p['canonical']/'report.json')
    bootstrap(transition,0); bootstrap(proof,2)
    for field in ('source_sha256','asset_sha256','stdlib_sha256'):
        assert transition[field]==proof[field],field
    for name,identity in proof['source_sha256'].items():
        assert sha(p['source']/'selfhost'/name)==identity,name
    for name,identity in proof['asset_sha256'].items():
        assert sha(p['source']/name)==identity,name
    for name,identity in proof['stdlib_sha256'].items():
        assert sha(p['source']/'stdlib'/name)==identity,name
    parent_seed=read(p['parent_seed']/'seed.json'); transition_seed=read(p['transition_seed']/'seed.json'); final_seed=read(p['seed']/'seed.json')
    parent_proof=read(p['parent_proof']/'report.json')
    assert parent_proof['status']=='passed' and parent_proof['fixed_point']
    assert parent_seed['c_sha256']==parent_proof['executable_c_sha256']
    for field in ('source_sha256','asset_sha256','stdlib_sha256'):
        assert parent_seed[field]==parent_proof[field],field
    assert transition['seed_c_sha256']==parent_seed['c_sha256']
    assert parent_seed.get('goose_optimization',0)==0
    assert transition_seed['goose_optimization']==0 and final_seed['goose_optimization']==2
    assert transition_seed['c_sha256']==transition['executable_c_sha256']==proof['seed_c_sha256']
    assert final_seed['c_sha256']==proof['executable_c_sha256']
    assert not proof.get('seed_matches_sources',False),'Optimization mismatch must force re-emission'
    for seed in (transition_seed,final_seed):
        for field in ('source_sha256','asset_sha256','stdlib_sha256'):
            assert seed[field]==proof[field],field
    for name,identity in data['bootstrap_scripts'].items():
        assert sha(p['source']/name)==identity,name
    return proof


def audit(data):
    p=paths(data); proof=chain(data)
    manifest=read(ROOT/'tests/conformance/cases.json'); parent_manifest=read(WORK/'public-57/tests/conformance/cases.json')
    assert manifest['cases'][:len(parent_manifest['cases'])]==parent_manifest['cases']
    full=read(p['full']/'report.json'); v8=read(p['v8']/'report.json'); parent=read(WORK/data['parent_full_dir']/'report.json')
    compiler_path=str(p['canonical']/'goose')
    assert sha(Path(compiler_path))==proof['executable_sha256']
    for report in (full,v8):
        assert 'error' not in report and report['input_sha256']==report['input_sha256_after']
        assert report['configuration']['compiler']==compiler_path
        assert report['input_sha256'][compiler_path]==proof['executable_sha256']
        assert report['input_sha256'][str(ROOT/'tests/conformance/cases.json')]==sha(ROOT/'tests/conformance/cases.json')
    old=row_keys(parent); new=row_keys(full); current=row_keys(v8)
    expected={(case['id'],level) for case in manifest['cases'] for level in case['levels']}
    curated={(case['id'],level) for case in manifest['cases'] if 'corpus/' in case['id'] for level in case['levels']}
    assert new.keys()==expected and current.keys()==curated
    assert old.keys()<=new.keys()
    if new.keys()-old.keys():
        assert data['new_controls_manifest'] is not None
        controls=read(WORK/data['new_controls_manifest'])
        control_keys={(case['id'],level) for case in controls['cases'] for level in case['levels']}
        assert control_keys==new.keys()-old.keys()
        for engine in ('wasmtime','v8'):
            baseline=read(WORK/('qualify58-baseline-'+engine)/'report.json')
            assert baseline['status']=='passed' and baseline['input_sha256']==baseline['input_sha256_after']
            assert row_keys(baseline).keys()==control_keys
            assert all(row['status']=='pass' for row in baseline['results'])
    inherited={key for key,row in old.items() if row['status']!='pass'}
    actual_gaps={key for key,row in new.items() if row['status']!='pass'}
    assert actual_gaps==inherited, 'Inherited gaps changed, or new/previously passing rows failed'
    assert len(inherited)==100
    assert full['summary']==dict(selected=len(expected),passed=len(expected)-100,failed=100)
    assert v8['summary']==dict(selected=len(curated),passed=len(curated),failed=0)
    assert v8['status']=='passed' and all(row['status']=='pass' for row in current.values())
    native=read(p['native']/'report.json')
    assert len(native['runs'])==data['native_runtime_checks']
    assert all(row['returncode']==0 for row in native['runs'])
    assert native['driver_sha256']==sha(p['source']/'native/tests/check.py')
    assert native['pack_sha256']==sha(p['source']/'native/pack.py')
    for name in ('storage.h','pools.h','relative.h','images.h','runs.h','threads.h'):
        assert native['inputs_sha256'][name]==proof['asset_sha256']['native/'+name],name
    public=read(p['public']/'build/bootstrap/report.json'); bootstrap(public,2)
    metadata=read(p['public']/'build/toolchain.json')
    assert metadata['goose_optimization']==2 and public.get('seed_matches_sources') is True
    profile_json=p['public']/'bootstrap/profile.json';profile_data=p['public']/'bootstrap/profile.profdata'
    assert profile_json.is_file()==profile_data.is_file(), 'Optional profile must be exported as a complete pair'
    if profile_json.is_file():
        profile=read(profile_json);profile_sha=sha(profile_data)
        assert profile.get('data_sha256')==profile_sha
        assert public.get('profile_used') is True
        assert metadata.get('profile_used') is True
        executable_build=public.get('executable_build',{})
        assert executable_build.get('profile_used') is True
        assert executable_build.get('profile_sha256')==profile_sha
    else:
        assert public.get('profile_used') is False
        assert metadata.get('profile_used') is False
    assert public['generated_c_sha256']==proof['executable_c_sha256']
    assert metadata['compiler_sha256']==sha(p['public']/'build/bin/goose')
    assert read(p['public']/'bootstrap/seed.json')['goose_optimization']==2
    for name,identity in data['bootstrap_scripts'].items():
        assert sha(p['public']/name)==identity,name
    smoke=read(p['public']/'build/smoke/report.json')
    assert smoke['status']=='passed' and len(smoke['commands'])==8
    assert smoke['compiler_sha256']==metadata['compiler_sha256']
    cross=read(WORK/'public-cross-58/report.json')
    assert cross['status']=='passed' and cross['c_sha256']==proof['executable_c_sha256']
    assert '-O2' in cross['command'] and cross['compiler_sha256']==metadata['compiler_sha256']
    targets={case['id']:case['target'] for case in manifest['cases']}
    counts=collections.Counter(targets[row['case']] for row in v8['results'])
    return dict(status='passed',source_optimization=2,transition_optimization=0,
                parent_rows=len(old),new_rows=len(new)-len(old),full_summary=full['summary'],
                inherited_gaps=100,curated_summary=v8['summary'],curated_by_target=dict(counts),
                fresh_native_runtime_commands=len(native['runs']),canonical_c_sha256=proof['executable_c_sha256'],
                public_compiler_sha256=metadata['compiler_sha256'],
                scope='Independent guard receipts and capsule pin coverage are separate mandatory checks listed in plan.json.')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--config',required=True);parser.add_argument('--output',default=HERE/'audit.json')
    args=parser.parse_args(); result=audit(config(args.config,sealed=True));save(args.output,result);print(result)
