#!/usr/bin/env python3
"""Read-only inventory and deferred commands; never freezes or executes a gate."""
import argparse
import collections
import sys
from common import HERE, ROOT, WORK, config, paths, read, row_keys, save, sha

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--config', default=HERE/'config.pending.json')
parser.add_argument('--output', default=HERE/'plan.json')
args = parser.parse_args()
data = config(args.config); p = paths(data)
manifest_path = ROOT/'tests/conformance/cases.json'; manifest = read(manifest_path)
parent_manifest = read(WORK/'public-57/tests/conformance/cases.json')
assert manifest['cases'][:len(parent_manifest['cases'])] == parent_manifest['cases'], 'Existing contracts changed'
parent = read(WORK/data['parent_full_dir']/'report.json'); old = row_keys(parent)
expected = {(case['id'], level) for case in manifest['cases'] for level in case['levels'] if level in (0, 2)}
assert len(expected) == sum(len(case['levels']) for case in manifest['cases'])
assert old.keys() <= expected
curated = collections.Counter()
for case in manifest['cases']:
    if 'corpus/' in case['id']:
        curated[case['target']] += len(case['levels'])

commands = []
def add(label, command, note=''):
    commands.append(dict(label=label, command=list(map(str, command)), note=note))
python = sys.executable
if data['new_controls_manifest'] is not None:
    for engine in ('wasmtime','v8'):
        add('baseline-new-controls-'+engine,[python,ROOT/'tests/conformance.py','--compiler',p['parent_proof']/'goose',
            '--manifest',WORK/data['new_controls_manifest'],'--output-dir',WORK/('qualify58-baseline-'+engine),'--engine',engine],
            'Frozen independent expectations must pass baseline before admission; preserve every original7871 contract row.')
add('assemble-after-root-seal', [python, HERE/'assemble.py', '--config', args.config])
bootstrap = p['source']/'selfhost/bootstrap.py'
for label, seed, output, level in [('transition-opt0',p['parent_seed'],p['transition'],0),
                                   ('canonical-opt2',p['transition_seed'],p['canonical'],2)]:
    add(label, [python,bootstrap,'--source-dir',p['source']/'selfhost','--seed-dir',seed,
                '--stdlib',p['source']/'stdlib','--native-dir',p['source']/'native','--output-dir',output,
                '--optimization',level,'--cc',data['cc'],'--verify'],
        'C-only verified transition avoids running old57 quadratic optimizer on -O2 compiler input.')
    target = p['transition_seed']
    if level == 2:
        target = p['seed']
    add('freeze-'+label,[python,HERE/'durable-tools/freeze_seed.py',output,target,p['source']])
add('fresh-native-runtime',['/usr/bin/env','CC='+data['cc'],python,p['source']/'native/tests/check.py','--output',p['native']],
    'Run against frozen headers, with CC set explicitly; changed storage.h forbids reuse of runtime49.')
add('public-source-export',[python,HERE/'prepare.py','--config',args.config])
add('source-reproduction',[python,HERE/'assemble.py','--config',args.config,'--output-dir',WORK/'snapshot-58-reproduced'])
add('full-contracts',[python,HERE/'durable-tools/conformance_shards.py','--compiler',p['canonical']/'goose','--output-dir',p['full'],'--jobs',4],
    'Exit1 is expected from inherited gaps; require report completeness and separate parent comparison.')
add('curated-v8-driver',[python,HERE/'v8.py','--compiler',p['canonical']/'goose','--output-dir',p['v8'],'--jobs',2],
    'Includes independently specified native controls as well as Wasm rows, as in57.')
add('clean-public-bootstrap',['/usr/bin/env','-u','TMPDIR','PATH=/usr/bin:/bin','/usr/bin/python3',p['public']/'scripts/bootstrap.py','--verify','--optimization',2,'--cc',data['cc']],
    'Execute with cwd=public-58, PATH=/usr/bin:/bin and TMPDIR unset. Final seed2 may reuse C only at matching2.')
add('public-smoke',[python,HERE/'public-smoke.py','--config',args.config])
add('public-cross-opt2',[python,HERE/'public-cross.py','--config',args.config])
for command in data['independent_guard_commands']:
    add('independent-guard',command,'Must point to canonical C-seed compiler, with immutable predeclared expectations.')
add('compare-parent',[python,HERE/'compare.py','--config',args.config])
add('audit-final-gates',[python,HERE/'audit.py','--config',args.config])
report = dict(status='prepared-only-no-gates-run',root_seal=data['status'],source_mutable=data['status']!='sealed-for-composition',
              parent_summary=parent['summary'],parent_rows=len(old),inherited_gaps=sum(row['status']!='pass' for row in old.values()),
              current_manifest_sha256=sha(manifest_path),current_rows=len(expected),new_rows=len(expected-old.keys()),
              curated=dict(curated),curated_rows=sum(curated.values()),commands=commands,
              pending=['Final source/patch/CLI hashes and source seal.','New Astra contracts and guard commands; baseline qualification before admission.',
                       'Final capsule file mapping, report list and dated evidence destination; use capsule-audit.py before compression.',
                       'Matched compiler/runtime benchmark campaign and README/charts/evidence alignment after correctness gates.'],
              rules=['Source build/performance-env.sh in every shell; native runtime gate CC must be explicit.',
                     'Do not run runtime qualification during matched timing windows.',
                     'Keep both transition0 and canonical2 bootstrap proofs, both seed metadata files and final public proof; profiles are optional as a complete validated pair.',
                     'Public native_sources dependencies must be ROOT-relative and exported explicitly.',
                     'No C++ compiler or C++ output oracle participates in correctness or bootstrap.'])
save(args.output,report)
print('Parent:',report['parent_rows'],'rows;',report['inherited_gaps'],'gaps. Current:',len(expected),'rows. Curated:',dict(curated))
print('Deferred commands:',len(commands),'; no gate executed.')
