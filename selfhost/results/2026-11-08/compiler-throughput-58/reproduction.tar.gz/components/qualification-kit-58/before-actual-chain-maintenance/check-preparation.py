"""Small prerequisite checks only; no Goose/C compilation or runtime gates."""
from pathlib import Path
import gzip
import hashlib
import json
import subprocess
import sys
import tarfile
import tempfile

HERE=Path(__file__).resolve().parent
commands=[]
for argv in [[sys.executable,HERE/'plan.py'],[sys.executable,HERE/'capsule-audit.py','--self-test']]:
    result=subprocess.run(list(map(str,argv)),capture_output=True,text=True);commands.append(dict(command=list(map(str,argv)),exit_code=result.returncode,stdout=result.stdout,stderr=result.stderr));assert result.returncode==0,commands[-1]
result=subprocess.run([sys.executable,str(HERE/'assemble.py'),'--config',str(HERE/'config.pending.json')],capture_output=True,text=True)
assert result.returncode!=0 and 'Final root seal is required' in result.stderr
commands.append(dict(command='assemble.py with pending config',exit_code=result.returncode,expected_rejection=True))
for level in (None,0,2):
    with tempfile.TemporaryDirectory() as directory:
        root=Path(directory);stage=root/'stage';stage.mkdir();licenses=root/'licenses';(licenses/'native/runtime').mkdir(parents=True)
        (licenses/'LICENSE').write_text('root license\n');(licenses/'native/runtime/LICENSE').write_text('runtime license\n');(licenses/'native/runtime/NOTICE').write_text('runtime notice\n')
        (stage/'sources').mkdir();(stage/'stdlib').mkdir();(stage/'sources/main.goose').write_text('fn main() {}\n');(stage/'stdlib/base.goose').write_text('// stdlib\n')
        c=b'/* C seed */\n';(stage/'compiler.c').write_bytes(c);sha=lambda data:hashlib.sha256(data).hexdigest()
        report=dict(status='passed',fixed_point=True,executable_c_sha256=sha(c),source_sha256={'main.goose':sha((stage/'sources/main.goose').read_bytes())},stdlib_sha256={'base.goose':sha((stage/'stdlib/base.goose').read_bytes())},seed_c_sha256='parent',generated_c_sha256=sha(c))
        if level is not None:
            report['goose_optimization']=level
        (stage/'report.json').write_text(json.dumps(report));seed=root/'seed'
        argv=[sys.executable,HERE/'durable-tools/freeze_seed.py',stage,seed,licenses]
        result=subprocess.run(list(map(str,argv)),capture_output=True,text=True);assert result.returncode==0,result.stderr
        expected=level
        if expected is None:
            expected=0
        assert json.loads((seed/'seed.json').read_text())['goose_optimization']==expected
        with tarfile.open(seed/'sources.tar.gz') as archive:
            assert archive.extractfile('LICENSE').read()==b'root license\n'
            assert archive.extractfile('native/runtime/NOTICE').read()==b'runtime notice\n'
        commands.append(dict(command='Portable private freezer tiny fixture',input_optimization=level,actual_optimization=expected,passed=True))
(HERE/'preparation-checks.json').write_text(json.dumps(dict(status='passed',scope='No compiler builds, runtime qualification, source58 freeze, benchmark, live write or Git mutation.',commands=commands),indent=2)+'\n')
print('Read-only inventory, pending-seal rejection, capsule pin guards and portable freezer metadata checks passed.')
