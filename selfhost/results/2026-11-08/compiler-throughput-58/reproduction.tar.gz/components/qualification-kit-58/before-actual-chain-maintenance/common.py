from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
WORK = ROOT / 'build/completion-runs'


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n')


def config(path, sealed=False):
    data = read(path)
    assert data['snapshot'] == 58 and data['parent'] == 57
    assert data['goose_optimization'] == 2 and data['transition_goose_optimization'] == 0
    if sealed:
        assert data['status'] == 'sealed-for-composition', 'Final root seal is required.'
        assert data['patches'] and data['slug']
        assert set(data['bootstrap_scripts']) == {'selfhost/bootstrap.py', 'scripts/bootstrap.py'}
        for item in data['patches']:
            assert sha(WORK / item['path']) == item['sha256'], item
    return data


def paths(data):
    return dict(source=WORK/'snapshot-58', parent_source=WORK/data['parent_source_dir'],
                parent_proof=WORK/data['parent_proof_dir'], parent_seed=WORK/data['parent_seed_dir'],
                transition=WORK/'c-only-bootstrap-58-opt0', transition_seed=WORK/'verified-transition-58-opt0',
                canonical=WORK/'c-only-bootstrap-58', seed=WORK/'verified-seed-58',
                public=WORK/'public-58', full=WORK/'c-only-conformance-58-qualified',
                v8=WORK/'c-only-v8-58-qualified', native=WORK/'native-runtime-58-final')


def row_keys(report):
    result = {(row['case'], row['level']): row for row in report['results']}
    assert len(result) == len(report['results']), 'Duplicate contract rows'
    return result
