#!/usr/bin/env python3
"""Independent squares/float contracts through clean public build entrypoints."""
import argparse
import os
from pathlib import Path
import shutil
import subprocess
import time
from common import HERE, WORK, config, paths, save, sha

parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--config',required=True)
args=parser.parse_args();data=config(args.config,sealed=True);p=paths(data);public=p['public']
node=Path(shutil.which('node')).resolve();assert subprocess.check_output([node,'--version'],text=True).startswith('v24.')
env=dict(os.environ,PATH='/usr/bin:/bin:'+str(node.parent));env.pop('TMPDIR',None)
out=public/'build/smoke';out.mkdir(exist_ok=False);shutil.copyfile(HERE/'public-smoke-float.goose',out/'float.goose')
report=dict(status='running',scope='Clean public wrapper and runtime smoke; fixed independently specified sums/float outputs, no reference compiler.',node=str(node),node_sha256=sha(node),compiler_sha256=sha(public/'build/bin/goose'),input_sha256={str(HERE/'public-smoke-float.goose'):sha(HERE/'public-smoke-float.goose')},commands=[])
try:
    for name,source,expected in [('squares',public/'examples/squares.goose','sum=140\n'),('float',out/'float.goose','0.1/1.25\n')]:
        for backend in ('direct','native'):
            artifact=out/(name+'-'+backend)
            if backend=='direct':
                artifact=artifact.with_suffix('.wasm')
            commands=[['/usr/bin/python3',public/'scripts/goose_wasm.py','build',source,'--backend',backend,'--no-cache','--cc',data['cc'],'-O2','-o',artifact]]
            if backend=='direct':
                commands.append([node,public/'scripts/run_wasm.mjs',artifact])
            else:
                commands.append([artifact])
            for index,command in enumerate(commands):
                command=list(map(str,command));started=time.monotonic();result=subprocess.run(command,cwd=public,env=env,capture_output=True,text=True)
                row=dict(command=command,exit_code=result.returncode,seconds=time.monotonic()-started,stdout=result.stdout,stderr=result.stderr);report['commands'].append(row);save(out/'report.json',report);assert result.returncode==0,row
                if index==1:
                    assert result.stdout==expected and not result.stderr,row
    report['status']='passed'
except BaseException as error:
    report.update(status='failed',error=repr(error));raise
finally:
    save(out/'report.json',report)
print('Public smoke passed:4 independent runtime outputs.')
