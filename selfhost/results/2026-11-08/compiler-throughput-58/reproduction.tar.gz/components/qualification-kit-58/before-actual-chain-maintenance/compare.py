#!/usr/bin/env python3
"""Compare every completed58 contract row with its immutable57 parent."""
import argparse
from common import WORK, config, paths, read, row_keys, save
parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--config',required=True)
args=parser.parse_args();data=config(args.config,sealed=True);p=paths(data)
parent=read(WORK/data['parent_full_dir']/'report.json');candidate=read(p['full']/'report.json');old=row_keys(parent);new=row_keys(candidate);shared=old.keys()&new.keys()
report=dict(baseline=57,candidate=58,baseline_summary=parent['summary'],candidate_summary=candidate['summary'],
            shared_gains=[new[key] for key in sorted(shared) if old[key]['status']!='pass' and new[key]['status']=='pass'],
            shared_regressions=[new[key] for key in sorted(shared) if old[key]['status']=='pass' and new[key]['status']!='pass'],
            new_rows=[new[key] for key in sorted(new.keys()-old.keys())],
            new_failures=[new[key] for key in sorted(new.keys()-old.keys()) if new[key]['status']!='pass'],
            removed_rows=[old[key] for key in sorted(old.keys()-new.keys())])
save(WORK/'comparison-58.json',report)
assert not report['shared_regressions'] and not report['new_failures'] and not report['removed_rows']
print(candidate['summary'],'gains',len(report['shared_gains']),'new',len(report['new_rows']))
