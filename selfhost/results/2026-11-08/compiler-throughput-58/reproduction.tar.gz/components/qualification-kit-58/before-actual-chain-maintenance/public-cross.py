#!/usr/bin/env python3
"""Public installed compiler must reproduce canonical2 C on identical paths."""
import argparse
import os
import subprocess
import time
from common import WORK, config, paths, read, save, sha
parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--config',required=True)
args=parser.parse_args();data=config(args.config,sealed=True);p=paths(data);proof=read(p['canonical']/'report.json')
assert proof['status']=='passed' and proof['goose_optimization']==2
out=WORK/'public-cross-58';out.mkdir(exist_ok=False);compiler=p['public']/'build/bin/goose';artifact=out/'compiler.c'
command=list(map(str,[compiler,p['canonical']/'sources/main.goose','--stdlib',p['canonical']/'stdlib','--target','native','-O2','-o',artifact]))
env=dict(os.environ,PATH='/usr/bin:/bin');env.pop('TMPDIR',None);started=time.monotonic();result=subprocess.run(command,capture_output=True,text=True,env=env)
report=dict(status='failed',command=command,exit_code=result.returncode,seconds=time.monotonic()-started,stdout=result.stdout,stderr=result.stderr,compiler_sha256=sha(compiler),expected_c_sha256=proof['executable_c_sha256'],goose_optimization=2)
if result.returncode==0:
    report['c_sha256']=sha(artifact)
    if report['c_sha256']==report['expected_c_sha256']:
        report['status']='passed'
save(out/'report.json',report);assert report['status']=='passed',report;print(report['status'])
