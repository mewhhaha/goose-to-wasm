#!/usr/bin/env python3
"""Require exact source pin coverage; only prebuilt ELF files may be excluded."""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile
import tempfile


def read(path):
    data=Path(path).read_bytes()
    if str(path).endswith('.gz'):
        data=gzip.decompress(data)
    return json.loads(data)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def coverage(files,reports):
    provided={}
    for name,path in files.items():
        relative=Path(name)
        assert not relative.is_absolute() and '..' not in relative.parts,name
        path=Path(path);data=path.read_bytes()
        assert data[:4]!=b'\x7fELF',('Executable in source-only capsule',name)
        provided[digest(data)]=dict(file=name)
        if name.endswith('.gz'):
            provided[digest(gzip.decompress(data))]=dict(gzip=name)
        if name.endswith('.tar.gz'):
            with tarfile.open(fileobj=io.BytesIO(data)) as archive:
                for member in archive:
                    if member.isfile() or member.islnk():
                        content=archive.extractfile(member).read()
                        provided[digest(content)]=dict(archive=name,member=member.name)
    covered={};binaries={}
    for report_path in reports:
        report=read(report_path)
        pins={}
        for field in ('input_sha256','inputs_sha256'):
            pins.update(report.get(field,{}))
        for name,identity in pins.items():
            key=str(report_path)+'::'+name
            if identity in provided:
                covered[key]=dict(sha256=identity,provided_by=provided[identity])
                continue
            original=Path(name)
            assert original.is_file(),('Pinned source/helper missing from capsule',name)
            with original.open('rb') as stream:
                assert stream.read(4)==b'\x7fELF',('Non-binary pinned input omitted from capsule',name)
            binaries[key]=dict(sha256=identity,reason='Prebuilt ELF excluded; original fingerprint retained.')
    return dict(status='passed',covered_source_pins=covered,excluded_executables=binaries)


def self_test():
    with tempfile.TemporaryDirectory() as directory:
        root=Path(directory);source=root/'example.goose';source.write_bytes(b'fn main() {}\n')
        zipped=root/'source.gz';zipped.write_bytes(gzip.compress(source.read_bytes(),mtime=0))
        raw=io.BytesIO()
        with tarfile.open(fileobj=raw,mode='w') as archive:
            entry=tarfile.TarInfo('fixture.goose');entry.size=source.stat().st_size;archive.addfile(entry,io.BytesIO(source.read_bytes()))
        bundle=root/'sources.tar.gz';bundle.write_bytes(gzip.compress(raw.getvalue(),mtime=0))
        binary=root/'compiler';binary.write_bytes(b'\x7fELFfake')
        report=root/'report.json';report.write_text(json.dumps(dict(input_sha256={str(source):digest(source.read_bytes()),str(binary):digest(binary.read_bytes())})))
        result=coverage({'archive.tar.gz':bundle},[report]);assert len(result['covered_source_pins'])==1 and len(result['excluded_executables'])==1
        assert coverage({'source.gz':zipped},[report])['status']=='passed'
        failed=False
        try:
            coverage({},[report])
        except AssertionError:
            failed=True
        assert failed,'Missing example source must be rejected'
    print('Capsule source/archive/gzip/ELF exclusion checks passed.')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--files',type=Path);parser.add_argument('--reports',type=Path,nargs='+');parser.add_argument('--output',type=Path);parser.add_argument('--self-test',action='store_true')
    args=parser.parse_args()
    if args.self_test:
        self_test()
    else:
        assert args.files and args.reports and args.output
        inventory=read(args.files);files={}
        for name,row in inventory.items():
            if isinstance(row,dict):
                files[name]=row['source']
            else:
                files[name]=row
        result=coverage(files,args.reports);args.output.write_text(json.dumps(result,indent=2)+'\n');print('Source pin coverage passed:',len(result['covered_source_pins']))
