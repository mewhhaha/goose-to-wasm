#!/usr/bin/env python3
"""Validate stage-specific bootstrap sources and the actual public58 artifact."""
import argparse
import collections
import gzip
import io
from pathlib import Path
import tarfile
from common import HERE, ROOT, WORK, config, paths, read, row_keys, save, sha, sha_bytes
from composition import verify as verify_composition

MAPS=('source_sha256','asset_sha256','stdlib_sha256')


def bootstrap(report,level):
    assert report['status']=='passed' and report['fixed_point']
    assert report['goose_optimization']==level
    assert report['input_sha256']==report['input_sha256_after']
    if 'third_generation_c_sha256' in report:
        assert report['next_generation_c_sha256']==report['third_generation_c_sha256']==report['executable_c_sha256']
    else:assert report['generated_c_sha256']==report['next_generation_c_sha256']==report['executable_c_sha256']
    assert report['executable_build']['c_sha256']==report['executable_c_sha256']
    for row in report['commands']:
        assert row['exit_code']==0,row
        assert not any(Path(value).name in ('c++','g++','clang++') for value in row['command'])
        if '--target' in row['command']:assert '-O'+str(level) in row['command'],row['command']
        if row.get('name','').startswith('build-'):
            assert row['command'][0]==report['cc']
            assert '-std=gnu11' in row['command'] and '-O2' in row['command']


def source_identity(source,report):
    pins=read(source/'source-pins.json')
    sources={Path(name).name:value for name,value in pins.items() if Path(name).parent==Path('selfhost') and name.endswith('.goose')}
    library={name[7:]:value for name,value in pins.items() if name.startswith('stdlib/') and name.endswith('.goose')}
    assert report['source_sha256']==sources,'Stage compiler source map is incomplete or belongs to a different source stage'
    assert report['stdlib_sha256']==library,'Stage stdlib source map is incomplete or belongs to a different source stage'
    wanted={'selfhost/'+name:value for name,value in report['source_sha256'].items()}
    wanted.update(report['asset_sha256']);wanted.update({'stdlib/'+name:value for name,value in report['stdlib_sha256'].items()})
    for name,value in wanted.items():assert pins[name]==sha(source/name)==value,name


def seed_identity(directory,report,level):
    seed=read(directory/'seed.json');assert seed.get('goose_optimization',0)==level
    assert seed['c_sha256']==report['executable_c_sha256']
    for field in MAPS:assert seed[field]==report[field],field
    assert sha(directory/'seed.c.gz')==seed['compressed_sha256']
    assert sha_bytes(gzip.decompress((directory/'seed.c.gz').read_bytes()))==seed['c_sha256']
    assert sha(directory/'sources.tar.gz')==seed['source_bundle_sha256']
    members={'compiler/'+name:value for name,value in seed['source_sha256'].items()}
    members.update({'stdlib/'+name:value for name,value in seed['stdlib_sha256'].items()});members.update(seed['asset_sha256'])
    with tarfile.open(fileobj=io.BytesIO((directory/'sources.tar.gz').read_bytes()),mode='r:gz') as archive:
        for name,value in members.items():assert sha_bytes(archive.extractfile(name).read())==value,('Seed source bundle differs',name)
    saved=read(directory/'proof.json')
    for field in (*MAPS,'executable_c_sha256','seed_c_sha256','fixed_point'):assert saved[field]==report[field],field
    assert seed['proof']==dict(fixed_point=True,parent_seed_c_sha256=report['seed_c_sha256'],stage1_c_sha256=report['generated_c_sha256'],stage2_c_sha256=report.get('next_generation_c_sha256'),stage3_c_sha256=report.get('third_generation_c_sha256'))
    return seed


def chain(data):
    p=paths(data);transition=read(p['transition']/'report.json');proof=read(p['canonical']/'report.json')
    bootstrap(transition,0);bootstrap(proof,2)
    source_identity(p['transition_source'],transition);source_identity(p['source'],proof)
    assert transition['stdlib_sha256']==proof['stdlib_sha256']
    old_assets=transition['asset_sha256'];new_assets=proof['asset_sha256']
    asset_delta={name:dict(transition=old_assets.get(name),final=new_assets.get(name)) for name in sorted(old_assets.keys()|new_assets.keys()) if old_assets.get(name)!=new_assets.get(name)}
    assert asset_delta==data.get('stage_asset_delta',{}),'Unapproved stage asset difference'
    if data.get('canonical_c_sha256'):assert proof['executable_c_sha256']==data['canonical_c_sha256']
    for directory,report in [(p['transition'],transition),(p['canonical'],proof)]:
        assert sha(directory/'goose')==report['executable_sha256']
    parent_proof=read(p['parent_proof']/'report.json');parent=seed_identity(p['parent_seed'],parent_proof,0)
    assert parent_proof['status']=='passed' and parent_proof['fixed_point']
    assert parent.get('goose_optimization',0)==0 and parent['c_sha256']==parent_proof['executable_c_sha256']
    for field in MAPS:assert parent[field]==parent_proof[field],field
    assert transition['seed_c_sha256']==parent['c_sha256']
    assert transition['bootstrap_source_sha256']==parent['source_sha256']
    old=seed_identity(p['transition_seed'],transition,0);final=seed_identity(p['seed'],proof,2)
    assert proof['seed_c_sha256']==old['c_sha256']
    assert proof['bootstrap_source_sha256']==old['source_sha256']
    assert not proof.get('seed_matches_sources',False),'Source/optimization change must re-emit'
    for name,value in data['bootstrap_scripts'].items():
        assert sha(p['source']/name)==value,name
        assert sha(p['transition_source']/name)==value,name
    for name,value in data.get('stage_receipt_sha256',{}).items():assert sha(WORK/name)==value,name
    verify_composition(data)
    return proof


def public_artifact(root,proof,final_seed,data):
    public=read(root/'build/bootstrap/report.json');metadata=read(root/'build/toolchain.json');bootstrap(public,2)
    binary=root/'build/bin/goose';identity=sha(binary)
    assert public.get('seed_matches_sources') is True
    assert public['seed_c_sha256']==public['generated_c_sha256']==public['executable_c_sha256']==proof['executable_c_sha256']
    assert metadata['goose_optimization']==2 and metadata['fixed_point']
    assert metadata['compiler']==str(binary)
    assert metadata['compiler_sha256']==public['executable_sha256']==identity
    assert metadata['executable_c_sha256']==metadata['seed_c_sha256']==proof['executable_c_sha256']
    assert metadata['executable_build']==public['executable_build']
    assert metadata['cc_sha256']==public['cc_sha256']==sha(Path(public['cc']))
    if data.get('cc_sha256'):assert public['cc_sha256']==data['cc_sha256']
    for field in MAPS:assert public[field]==metadata[field]==proof[field],field
    assert read(root/'bootstrap/seed.json')==final_seed
    for name,value in data['bootstrap_scripts'].items():assert sha(root/name)==value,name
    profile_json=root/'bootstrap/profile.json';profile_data=root/'bootstrap/profile.profdata'
    assert profile_json.is_file()==profile_data.is_file(),'Profile requires both metadata and data'
    if 'profile_required' in data:assert profile_json.is_file()==data['profile_required']
    export=read(root/'export.json')
    assert export['source_only'] and export['source_sha256']['tests/conformance/cases.json']==sha(ROOT/'tests/conformance/cases.json')
    if data.get('source_dir'):assert export['source_sha256']['source-pins.json']==sha(paths(data)['source']/'source-pins.json')
    if profile_json.is_file():
        profile=read(profile_json);profile_sha=sha(profile_data)
        if data.get('profile_required'):
            assert sha(profile_json)==data['profile_metadata_sha256'] and profile_sha==data['profile_sha256']
            for name,value in data['profile_receipt_sha256'].items():assert sha(WORK/name)==value,name
            linkage=read(WORK/data['profile_linkage_report'])
            assert linkage['status']=='passed'
            assert linkage['C_sha256']==proof['executable_c_sha256']
            if data.get('profile_fixedpoint_report'):
                assert linkage['bootstrap_report_sha256']==sha(paths(data)['canonical']/'report.json')
                assert linkage['executable_sha256']==proof['executable_sha256']
                fixed=read(WORK/data['profile_fixedpoint_report']);pins=read(WORK/data['profile_input_pins_report'])
                assert fixed['status']=='passed' and fixed['fixed_point'] and fixed['strict_profile_use'] is True
                assert fixed['c_sha256']==proof['executable_c_sha256'] and fixed['profile_sha256']==profile_sha
                assert fixed['plain_sha256']==proof['executable_sha256']
                assert fixed['canonical_C_bootstrap_linkage']==dict(status='passed',bootstrap_report_sha256=sha(paths(data)['canonical']/'report.json'),exact_C=True)
                sources={name[8:]:value for name,value in pins.items() if name.startswith('sources/') and name.endswith('.goose')}
                library={name[7:]:value for name,value in pins.items() if name.startswith('stdlib/') and name.endswith('.goose')}
                assert sources==proof['source_sha256'] and library==proof['stdlib_sha256']
                for name,value in proof['asset_sha256'].items():assert pins[name]==value,name
            else:
                assert linkage['fixed_point'] and linkage['source_metadata_matches']
                assert linkage['C_only_bootstrap_report_sha256']==sha(paths(data)['canonical']/'report.json')
        assert profile['schema']=='goose-bootstrap-profile-v1'
        assert profile['c_sha256']==proof['executable_c_sha256'] and profile['data_sha256']==profile_sha
        for key in ('clang_major','target','base_flags','c_basename'):assert profile[key]==public['profile_identity'][key],key
        assert public['profile_used'] is True and metadata['profile_used'] is True
        build=public['executable_build'];assert build['profile_used'] is True and build['profile_sha256']==profile_sha
        assert build['c_sha256']==profile['c_sha256']
        matching=[]
        fatal=['-Werror=profile-instr-out-of-date','-Werror=profile-instr-missing','-Werror=profile-instr-unprofiled']
        for row in public['commands']:
            command=row['command']
            if '-fprofile-instr-use='+str(profile_data) not in command:continue
            assert all(flag in command for flag in profile['base_flags']+fatal),command
            assert 'seed.c' in command and row['exit_code']==0,command
            matching.append(row)
        assert matching,'Actual profiled Clang command missing'
        for name in ('profile.json','profile.profdata'):
            assert export['source_sha256']['bootstrap/'+name]==sha(root/'bootstrap'/name)
            assert sha(root/'bootstrap'/name)==sha(paths(data)['seed']/name)
    else:
        assert public['profile_used'] is False and metadata['profile_used'] is False
        assert public['executable_build']['profile_used'] is False
        assert not data.get('profile_required',False)
    return metadata,public


def report_inputs(report,compiler,manifest):
    assert 'error' not in report and report['input_sha256']==report['input_sha256_after']
    assert report['configuration']['compiler']==str(compiler)
    assert report['input_sha256'][str(compiler)]==sha(compiler)
    expected=Path(manifest).resolve();configured=report['configuration']['manifest'];actual=Path(configured)
    if not actual.is_absolute():
        assert '..' not in actual.parts,'Manifest must be ROOT-relative'
        actual=ROOT/actual
    assert actual.resolve()==expected,'Configured manifest points to a different file'
    identity=sha(expected)
    assert report['input_sha256'][configured]==identity,'Configured manifest fingerprint differs'
    aliases={str(expected),expected.relative_to(ROOT.resolve()).as_posix()}
    for name in aliases:
        if name in report['input_sha256']:assert report['input_sha256'][name]==identity,'Conflicting manifest alias fingerprint'


def native_runtime(data,p,proof):
    native=read(p['native']/'report.json')
    assert len(native['runs'])==data['native_runtime_checks'] and all(row['returncode']==0 for row in native['runs'])
    assert native['driver_sha256']==sha(p['source']/'native/tests/check.py')
    assert native['pack_sha256']==sha(p['source']/'native/pack.py')
    for name in ('storage.h','pools.h','relative.h','images.h','runs.h','threads.h'):
        assert native['inputs_sha256'][name]==proof['asset_sha256']['native/'+name],name
    for name,row in native['runtime']['files'].items():assert row['sha256']==sha(p['source']/'native/runtime'/name),name
    for name,row in native['fixtures']['files'].items():assert row['sha256']==sha(p['source']/'native/tests'/name),name
    for name,value in native['inputs_sha256'].items():
        fixture=p['source']/'native/tests'/name
        if fixture.is_file():assert sha(fixture)==value,name
    return native


def audit(data):
    p=paths(data);proof=chain(data);final_seed=read(p['seed']/'seed.json')
    metadata,public=public_artifact(p['public'],proof,final_seed,data)
    second,second_proof=public_artifact(p['public_second'],proof,final_seed,data)
    assert p['public'].resolve()!=p['public_second'].resolve()
    assert second['compiler_sha256']==metadata['compiler_sha256'],'Two-root public ELF differs'
    assert read(p['public']/'export.json')['source_sha256']==read(p['public_second']/'export.json')['source_sha256']
    manifest_path=ROOT/'tests/conformance/cases.json';manifest=read(manifest_path);parent_manifest=read(WORK/'public-57/tests/conformance/cases.json')
    assert manifest['cases'][:len(parent_manifest['cases'])]==parent_manifest['cases']
    full=read(p['full']/'report.json');v8=read(p['v8']/'report.json');parent=read(WORK/data['parent_full_dir']/'report.json')
    compiler=p['public']/'build/bin/goose'
    for report in (full,v8):report_inputs(report,compiler,manifest_path)
    old=row_keys(parent);new=row_keys(full);current=row_keys(v8)
    expected={(case['id'],level) for case in manifest['cases'] for level in case['levels']}
    assert len(expected)==sum(len(case['levels']) for case in manifest['cases'])
    curated={(case['id'],level) for case in manifest['cases'] if 'corpus/' in case['id'] for level in case['levels']}
    assert new.keys()==expected and current.keys()==curated and old.keys()<=new.keys()
    parent_ids={case['id'] for case in parent_manifest['cases']}
    added=[case for case in manifest['cases'] if case['id'] not in parent_ids]
    controls_path=WORK/data['new_controls_manifest'];controls=read(controls_path)
    assert controls['cases']==added,'New controls changed cases or expectations'
    control_keys={(case['id'],level) for case in controls['cases'] for level in case['levels']}
    assert control_keys==new.keys()-old.keys()
    for field,value in [('expected_parent_rows',len(old)),('expected_full_rows',len(expected)),('expected_new_rows',len(control_keys))]:
        if field in data:assert data[field]==value,field
    for label,target in [('baseline',p['parent_compiler']),('candidate',compiler)]:
        for engine in ('wasmtime','v8'):
            directory=data.get('control_report_dirs',{}).get(label+'-'+engine,'qualify58-'+label+'-'+engine)
            report=read(WORK/directory/'report.json');report_inputs(report,target,controls_path)
            assert report['status']=='passed' and row_keys(report).keys()==control_keys
            assert all(row['status']=='pass' for row in report['results'])
    inherited={key for key,row in old.items() if row['status']!='pass'}
    assert {key for key,row in new.items() if row['status']!='pass'}==inherited
    assert len(inherited)==100
    assert full['summary']==dict(selected=len(expected),passed=len(expected)-100,failed=100)
    assert v8['status']=='passed' and v8['summary']==dict(selected=len(curated),passed=len(curated),failed=0)
    assert all(row['status']=='pass' for row in current.values())
    native=native_runtime(data,p,proof)
    smoke=read(p['public']/'build/smoke/report.json')
    assert smoke['status']=='passed' and len(smoke['commands'])==8 and smoke['compiler_sha256']==metadata['compiler_sha256']
    cross=read(p['cross']/'report.json')
    assert cross['status']=='passed' and cross['c_sha256']==proof['executable_c_sha256']
    assert '-O2' in cross['command'] and cross['compiler_sha256']==metadata['compiler_sha256']
    assert cross['command'][0]==str(compiler) and cross['input_sha256']==cross['input_sha256_after']
    targets={case['id']:case['target'] for case in manifest['cases']}
    counts=collections.Counter(targets[row['case']] for row in v8['results'])
    return dict(status='passed',source_optimization=2,transition_optimization=0,parent_rows=len(old),new_rows=len(control_keys),full_summary=full['summary'],inherited_gaps=100,curated_summary=v8['summary'],curated_by_target=dict(counts),native_runtime_commands=len(native['runs']),native_runtime_receipt=str(p['native']/'report.json'),canonical_c_sha256=proof['executable_c_sha256'],public_compiler_sha256=metadata['compiler_sha256'],public_profile_used=public['profile_used'],two_public_roots=[str(p['public']),str(p['public_second'])],scope='Independent guards and complete source-only capsule pin coverage remain separate mandatory checks.')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--config',required=True);parser.add_argument('--output',default=HERE/'audit.json')
    args=parser.parse_args();result=audit(config(args.config,sealed=True));save(args.output,result);print(result)
