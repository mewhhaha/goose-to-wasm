from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
WORK = ROOT / 'build/completion-runs'


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def sha_bytes(content):
    return hashlib.sha256(content).hexdigest()


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n')


def config(path, sealed=False):
    data = read(path)
    assert data['snapshot'] == 58 and data['parent'] == 57
    assert data['goose_optimization'] == 2 and data['transition_goose_optimization'] == 0
    if sealed:
        assert data['status'] == 'sealed-for-composition', 'Final root seal is required.'
        assert not data.get('required_receipts_pending') and not data.get('native_receipt_pending'), 'Stage receipts are still pending.'
        assert data['patches'] and data['slug']
        assert set(data['bootstrap_scripts']) == {'selfhost/bootstrap.py', 'scripts/bootstrap.py'}
        if 'canonical_c_sha256' in data:
            assert isinstance(data['canonical_c_sha256'], str) and len(data['canonical_c_sha256'])==64, 'Final canonical C identity is still pending.'
        if data.get('manifest_sha256'):assert sha(ROOT/'tests/conformance/cases.json')==data['manifest_sha256']
        if data.get('new_controls_sha256'):assert sha(WORK/data['new_controls_manifest'])==data['new_controls_sha256']
        if data.get('cc_sha256'):assert sha(Path(data['cc']))==data['cc_sha256']
        for item in data['patches'] + data.get('transition_patches', []) + data.get('upgrade_patches', []):
            assert sha(WORK / item['path']) == item['sha256'], item
        if 'profile_required' in data:
            assert isinstance(data['profile_required'], bool), 'Root must choose the public profile policy before sealing.'
            if data['profile_required']:
                assert data.get('profile_metadata_sha256') and data.get('profile_sha256')
                assert data.get('profile_linkage_report') and data.get('profile_receipt_sha256')
    return data


def paths(data):
    return dict(source=WORK/data.get('source_dir', 'snapshot-58'), parent_source=WORK/data['parent_source_dir'],
                parent_proof=WORK/data['parent_proof_dir'], parent_seed=WORK/data['parent_seed_dir'],
                parent_compiler=WORK/data.get('parent_compiler', data['parent_proof_dir']+'/goose'),
                transition=WORK/data.get('transition_dir', 'c-only-bootstrap-58-opt0'),
                transition_seed=WORK/data.get('transition_seed_dir', 'verified-transition-58-opt0'),
                transition_source=WORK/data.get('transition_source_dir', data.get('source_dir', 'snapshot-58')),
                canonical=WORK/data.get('canonical_dir', 'c-only-bootstrap-58'),
                seed=WORK/data.get('seed_dir', 'verified-seed-58'),
                public=WORK/data.get('public_dir', 'public-58'),
                public_second=WORK/data.get('public_second_dir', 'public-58-second-root'),
                full=WORK/data.get('full_dir', 'c-only-conformance-58-qualified'),
                v8=WORK/data.get('v8_dir', 'c-only-v8-58-qualified'),
                cross=WORK/data.get('public_cross_dir', 'public-cross-58'),
                native=WORK/data.get('native_runtime_dir', 'native-runtime-58-final'))


def row_keys(report):
    result = {(row['case'], row['level']): row for row in report['results']}
    assert len(result) == len(report['results']), 'Duplicate contract rows'
    return result
