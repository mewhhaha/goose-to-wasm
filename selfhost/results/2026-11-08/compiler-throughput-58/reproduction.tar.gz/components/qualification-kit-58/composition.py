"""Reproduce each compiler stage from57, and the explicit A19→A22 upgrade."""
from pathlib import Path
import shutil
import subprocess
import tempfile
from common import ROOT, WORK, paths, read, sha


def core_name(name):
    path=Path(name)
    return name=='LICENSE' or path.parts[0] in ('native','stdlib','scripts') or (path.parts[0]=='selfhost' and len(path.parts)==2 and path.suffix in ('.goose','.py'))


def core_pins(source):
    return {name:value for name,value in read(source/'source-pins.json').items() if core_name(name)}


def patch_names(rows):
    names=set()
    for row in rows:
        patch=WORK/row['path'];assert sha(patch)==row['sha256'],row
        for line in patch.read_text().splitlines():
            if line.startswith(('--- a/','+++ b/')):
                name=line[6:].split('\t',1)[0];relative=Path(name)
                assert not relative.is_absolute() and '..' not in relative.parts,name
                names.add(name)
    return names


def apply(rows,output):
    for row in rows:
        result=subprocess.run(['patch','--batch','--forward','--fuzz=0','-p1','-i',str(WORK/row['path'])],cwd=output,text=True,capture_output=True)
        assert result.returncode==0,(row,result.stdout,result.stderr)
    assert not list(output.rglob('*.orig')) and not list(output.rglob('*.rej'))


def compose(data,output,stage='final'):
    p=paths(data);source=p['source'];rows=data['patches']
    if stage=='transition':
        source=p['transition_source'];rows=data.get('transition_patches',data['patches'])
    expected=core_pins(source);extras=data.get('composition_extra_sha256',{})
    parent_pins=read(p['parent_source']/'source-pins.json')
    library_pins=read(p['parent_proof']/'report.json')['stdlib_sha256']
    parent_export=read(WORK/'public-57/export.json')['source_sha256']
    names=set(expected)|patch_names(rows)
    assert names<=set(expected)|set(extras),('Unpinned patch outputs',names-set(expected)-set(extras))
    output.mkdir(parents=True,exist_ok=False)
    for name in sorted(names):
        original=p['parent_source']/name
        if name.startswith('stdlib/'):
            original=WORK/'public-57'/name
        content=None
        if original.is_file():
            if name.startswith('stdlib/'):
                value=library_pins.get(name[7:],parent_export.get(name));assert value is not None and sha(original)==value,name
            elif name in parent_pins:assert sha(original)==parent_pins[name],name
            content=original.read_bytes()
        else:
            result=subprocess.run(['git','show',data['base_commit']+':'+name],cwd=ROOT,capture_output=True)
            if result.returncode==0:content=result.stdout
        if content is not None:
            target=output/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(content)
    apply(rows,output)
    for name,value in {**expected,**extras}.items():
        assert sha(output/name)==value,(stage,name)
    return {**expected,**extras}


def verify(data):
    p=paths(data)
    assert data.get('composition_base_commit',data['base_commit'])==data['base_commit']
    if p['source']==p['transition_source'] and not data.get('transition_patches'):
        return dict(mode='legacy-same-source',source_pins=sha(p['source']/'source-pins.json'))
    assert data.get('transition_patches') and data.get('upgrade_patches'),'Different stage sources need both unified patches and the approved upgrade patches'
    with tempfile.TemporaryDirectory(prefix='qualify58-composition-',dir=WORK) as directory:
        directory=Path(directory);old=compose(data,directory/'transition','transition');new=compose(data,directory/'final')
        upgraded=directory/'upgraded';shutil.copytree(directory/'transition',upgraded);apply(data['upgrade_patches'],upgraded)
        for name,value in new.items():assert sha(upgraded/name)==value,('Upgrade does not reproduce final source',name)
    delta={name:dict(transition=old.get(name),final=new.get(name)) for name in sorted(old.keys()|new.keys()) if old.get(name)!=new.get(name)}
    assert delta==data['stage_source_delta'],'A19→A22 source difference changed'
    return dict(mode='separate-stages-with-explicit-patch-link',base_commit=data['base_commit'],transition_patches=data['transition_patches'],final_patches=data['patches'],upgrade_patches=data['upgrade_patches'],source_delta=delta)
