#!/usr/bin/env python3
"""Export source-only58 using frozen CLIs and final optimized seed; no build."""
import argparse
import gzip
from pathlib import Path
import shutil
import subprocess
from common import ROOT, WORK, config, paths, read, save, sha, sha_bytes
from composition import patch_names
from audit import chain

parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--config',required=True)
parser.add_argument('--output-dir',type=Path)
args=parser.parse_args();data=config(args.config,sealed=True);p=paths(data);proof=chain(data)
if args.output_dir is not None:p['public']=args.output_dir.resolve()
selected=set(subprocess.check_output(['git','ls-files','-z'],cwd=ROOT,text=True).split('\0'))
selected.update(read(p['source']/'source-pins.json'))
selected.update(patch_names(data['patches']))
manifest=read(ROOT/'tests/conformance/cases.json')
native_sources=set()
root=ROOT.resolve()
for case in manifest['cases']:
    for source in case.get('native_sources', []):
        relative=Path(source)
        if relative.is_absolute() or '..' in relative.parts:
            raise SystemExit('Cannot export native_sources path outside repository: '+source)
        normalized=relative.as_posix()
        original=(ROOT/relative)
        try:
            resolved=original.resolve(strict=True)
            resolved.relative_to(root)
        except (OSError, ValueError):
            raise SystemExit('Cannot export missing or non-repository native_sources dependency: '+source)
        if not resolved.is_file():
            raise SystemExit('Cannot export missing native_sources dependency: '+source)
        native_sources.add(normalized)
selected.update(case['source'] for case in manifest['cases'] if not case['source'].startswith('upstream:'))
selected.update(native_sources)
seed=read(p['seed']/'seed.json')
proof=read(p['seed']/'proof.json')
seed_files={'seed.c.gz':'compressed_sha256','sources.tar.gz':'source_bundle_sha256'}
for name,field in seed_files.items():
    if sha(p['seed']/name)!=seed[field]:
        raise SystemExit('Final seed checksum mismatch: '+name)
if sha_bytes(gzip.decompress((p['seed']/'seed.c.gz').read_bytes()))!=seed['c_sha256']:
    raise SystemExit('Final seed C checksum mismatch after decompression')
if proof.get('status')!='passed' or not proof.get('fixed_point') or proof.get('executable_c_sha256')!=seed['c_sha256']:
    raise SystemExit('Final seed proof does not match seed metadata')
for field in ('source_sha256','stdlib_sha256','asset_sha256'):
    if proof.get(field)!=seed.get(field):
        raise SystemExit('Final seed proof input map differs from seed metadata: '+field)
proof_chain={'fixed_point':proof['fixed_point'],'parent_seed_c_sha256':proof['seed_c_sha256'],
             'stage1_c_sha256':proof['generated_c_sha256'],'stage2_c_sha256':proof.get('next_generation_c_sha256'),
             'stage3_c_sha256':proof.get('third_generation_c_sha256')}
if proof_chain!=seed.get('proof'):
    raise SystemExit('Final seed proof chain differs from seed metadata')
profile_names=('profile.json','profile.profdata')
profile_present=[(p['seed']/name).is_file() for name in profile_names]
if any(profile_present) and not all(profile_present):
    raise SystemExit('Optional profile is incomplete; provide both profile.json and profile.profdata, or neither')
if 'profile_required' in data and all(profile_present)!=data['profile_required']:
    raise SystemExit('Final seed profile pair differs from the sealed public profile choice')
if all(profile_present):
    profile=read(p['seed']/'profile.json')
    if not isinstance(profile,dict) or profile.get('c_sha256')!=seed['c_sha256'] or profile.get('data_sha256')!=sha(p['seed']/'profile.profdata'):
        raise SystemExit('Optional profile metadata does not match final seed C and profile data')
    if profile.get('schema')!='goose-bootstrap-profile-v1' or any(profile.get(key)!=value for key,value in proof['profile_identity'].items()):
        raise SystemExit('Optional profile compiler identity/flags/basename do not match canonical C build')
    if data.get('profile_required') and (sha(p['seed']/'profile.json')!=data['profile_metadata_sha256'] or sha(p['seed']/'profile.profdata')!=data['profile_sha256']):
        raise SystemExit('Optional profile differs from the sealed winner')
p['public'].mkdir(exist_ok=False);copied=[]
for name in sorted(selected):
    if not name:
        continue
    relative=Path(name);top=relative.parts[0]
    if top=='bootstrap' and relative.name in profile_names:
        continue
    include=name in ('README.md','LICENSE','AGENTS.md','requirements.txt') or name in native_sources or top in ('scripts','stdlib','examples','bootstrap','native','tests','docs')
    if top=='selfhost' and len(relative.parts)==2:
        include=True
    if not include:
        continue
    original=ROOT/relative
    if (p['source']/relative).is_file():
        original=p['source']/relative
    if top=='bootstrap' and relative.name in ('proof.json','seed.c.gz','seed.json','sources.tar.gz'):
        original=p['seed']/relative.name
    if original.is_file():
        target=p['public']/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(original,target);copied.append(name)
seed_names=['proof.json','seed.c.gz','seed.json','sources.tar.gz']
if all(profile_present):
    seed_names.extend(profile_names)
for name in seed_names:
    target=p['public']/'bootstrap'/name;target.parent.mkdir(exist_ok=True);shutil.copyfile(p['seed']/name,target)
    if sha(target)!=sha(p['seed']/name):
        raise SystemExit('Exported seed file changed during copy: '+name)
    copied.append('bootstrap/'+name)
shutil.copyfile(p['source']/'source-pins.json',p['public']/'source-pins.json')
copied.append('source-pins.json')
for name,identity in data['bootstrap_scripts'].items():
    assert sha(p['public']/name)==identity
for name,identity in proof['stdlib_sha256'].items():
    assert sha(p['public']/'stdlib'/name)==identity
assert read(p['public']/'bootstrap/seed.json')['goose_optimization']==2
save(p['public']/'export.json',dict(source_only=True,files=sorted(set(copied)),source_sha256={file.relative_to(p['public']).as_posix():sha(file) for file in sorted(p['public'].rglob('*')) if file.is_file()}))
print('Source-only public export ready:',p['public'])
