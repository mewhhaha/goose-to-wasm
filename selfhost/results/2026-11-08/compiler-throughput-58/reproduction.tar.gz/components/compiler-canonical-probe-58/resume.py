from pathlib import Path
import subprocess,time,json,hashlib,shutil
root=Path.cwd();out=root/'build/completion-runs/compiler-canonical-probe-58'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
protocol=json.loads((out/'training-protocol.json').read_text());assert sha(out/'seed.c')==protocol['source_c_sha256']==sha(out/'training-native.out')==sha(out/'verify.c')
for name,value in json.loads((out/'input-pins.json').read_text()).items():assert sha(out/name)==value,name
merge=['llvm-profdata','merge','-o','profile.profdata'];raw={}
for case in protocol['training']:
 files=list(out.glob(case['name']+'-*.profraw'));assert len(files)==1
 merge.append('-weighted-input='+str(case['weight'])+','+str(files[0]));raw[str(files[0])]=sha(files[0])
(out/'resume-protocol.json').write_text(json.dumps({'reason':'llvm-profdata-23 does not exist; actual installed llvm-profdata is version23.1.4','training_unchanged':True,'raw_sha256':raw,'merge_tool_sha256':sha(Path(shutil.which('llvm-profdata')).resolve()),'merge_version':subprocess.check_output(['llvm-profdata','--version'],text=True)},indent=2)+'\n')
def run(cmd,name):
 start=time.monotonic();p=subprocess.run(['taskset','-c','2',*map(str,cmd)],cwd=out,capture_output=True,text=True)
 (out/(name+'.stdout')).write_text(p.stdout);(out/(name+'.stderr')).write_text(p.stderr);r={'command':list(map(str,cmd)),'cwd':str(out),'cpu':2,'seconds':time.monotonic()-start,'exit_code':p.returncode};(out/(name+'.json')).write_text(json.dumps(r,indent=2)+'\n');print(name,p.returncode,round(r['seconds'],2),flush=True);assert p.returncode==0,p.stderr
run(merge,'merge-profile-resumed')
meta={'schema':'goose-bootstrap-profile-v1','c_sha256':sha(out/'seed.c'),'clang_major':23,'target':protocol['target'],'base_flags':protocol['base_flags'],'c_basename':'seed.c','data_sha256':sha(out/'profile.profdata')};(out/'profile.json').write_text(json.dumps(meta,indent=2)+'\n')
run(['clang-23','-std=gnu11','-O2','seed.c','-lm','-ldl','-pthread','-fprofile-instr-use='+str(out/'profile.profdata'),'-Werror=profile-instr-out-of-date','-Werror=profile-instr-unprofiled','-Werror=profile-instr-missing','-o','goose-pgo'],'optimized-build')
run([out/'goose-pgo','sources/main.goose','--stdlib','stdlib','--target','native','-O2','-o','verify-pgo.c'],'verify-profile-canonical')
assert sha(out/'verify-pgo.c')==sha(out/'seed.c');(out/'fixedpoint.json').write_text(json.dumps({'status':'passed','c_sha256':sha(out/'seed.c'),'plain_sha256':sha(out/'goose-plain'),'pgo_sha256':sha(out/'goose-pgo'),'profile_sha256':sha(out/'profile.profdata'),'fixed_point':True,'same_canonical_C_plain_and_profiled':True,'performance_claim':None},indent=2)+'\n');print('canonical PGO fixed point passed',flush=True)
