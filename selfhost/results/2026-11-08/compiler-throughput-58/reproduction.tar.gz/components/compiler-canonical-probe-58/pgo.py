from pathlib import Path
import subprocess,time,json,hashlib,os,concurrent.futures
root=Path.cwd();out=root/'build/completion-runs/compiler-canonical-probe-58';w=root/'build/completion-runs'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
protocol={'schema':'goose-canonical-pgo-training-v1','source_c_sha256':sha(out/'seed.c'),'goose_optimization':2,'base_flags':['-std=gnu11','-O2','-lm','-ldl','-pthread'],'c_basename':'seed.c','target':subprocess.check_output(['clang-23','-dumpmachine'],text=True).strip(),'clang_sha256':sha(Path('/usr/bin/clang-23').resolve()),'training':[{'name':'native','source':'./sources/main.goose','target':'native','weight':1},{'name':'leaf','source':str(w/'compiler-subtractive-58/leaf-properties-fixture.goose'),'target':'wasm-direct','weight':64},{'name':'flow','source':str(w/'compiler-subtractive-58/flow-prefilter-fixture.goose'),'target':'wasm-direct','weight':64}],'timed_benchmarks_used_for_training':False,'generation':'frontend-instrumented profile; _Exit wrapper flushes profile only in training build'}
(out/'training-protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
(out/'profile-exit.c').write_text('#include <stdlib.h>\nint __llvm_profile_write_file(void);\n_Noreturn void __real__Exit(int);\n_Noreturn void __wrap__Exit(int code){__llvm_profile_write_file();__real__Exit(code);}\n')
def run(cmd,name,cpu=2,env=None):
 start=time.monotonic();p=subprocess.run(['taskset','-c',str(cpu),*map(str,cmd)],cwd=out,capture_output=True,text=True,env=env)
 (out/(name+'.stdout')).write_text(p.stdout);(out/(name+'.stderr')).write_text(p.stderr)
 r={'command':list(map(str,cmd)),'cwd':str(out),'cpu':cpu,'seconds':time.monotonic()-start,'exit_code':p.returncode}
 (out/(name+'.json')).write_text(json.dumps(r,indent=2)+'\n');print(name,p.returncode,round(r['seconds'],2),flush=True);assert p.returncode==0,p.stderr
base=['clang-23','-std=gnu11','-O2','seed.c','-lm','-ldl','-pthread']
with concurrent.futures.ThreadPoolExecutor(2) as pool:
 jobs=[pool.submit(run,[*base,'-o','goose-plain'],'plain-build',2),pool.submit(run,[*base,'-fprofile-instr-generate','profile-exit.c','-Wl,--wrap=_Exit','-o','goose-train'],'instrumented-build',6)]
 for job in jobs:job.result()
run([out/'goose-plain','./sources/main.goose','--stdlib','stdlib','--target','native','-O2','-o','verify.c'],'verify-canonical')
assert sha(out/'seed.c')==sha(out/'verify.c')
for case in protocol['training']:
 env=os.environ.copy();env['LLVM_PROFILE_FILE']=str(out/(case['name']+'-%p.profraw'))
 run([out/'goose-train',case['source'],'--stdlib','stdlib','--target',case['target'],'-O2','-o',str(out/('training-'+case['name']+'.out'))],'train-'+case['name'],env=env)
 if case['target']=='wasm-direct':
  import wasmtime
  wasmtime.Module.validate(wasmtime.Engine(),(out/('training-'+case['name']+'.out')).read_bytes())
assert sha(out/'training-native.out')==sha(out/'seed.c')
merge=['llvm-profdata-23','merge','-o','profile.profdata']
for case in protocol['training']:
 files=list(out.glob(case['name']+'-*.profraw'));assert len(files)==1
 merge.append('-weighted-input='+str(case['weight'])+','+str(files[0]))
run(merge,'merge-profile')
meta={'schema':'goose-bootstrap-profile-v1','c_sha256':sha(out/'seed.c'),'clang_major':23,'target':protocol['target'],'base_flags':protocol['base_flags'],'c_basename':'seed.c','data_sha256':sha(out/'profile.profdata')}
(out/'profile.json').write_text(json.dumps(meta,indent=2)+'\n')
run([*base,'-fprofile-instr-use='+str(out/'profile.profdata'),'-Werror=profile-instr-out-of-date','-Werror=profile-instr-unprofiled','-Werror=profile-instr-missing','-o','goose-pgo'],'optimized-build')
run([out/'goose-pgo','./sources/main.goose','--stdlib','stdlib','--target','native','-O2','-o','verify-pgo.c'],'verify-profile-canonical')
assert sha(out/'verify-pgo.c')==sha(out/'seed.c')
(out/'fixedpoint.json').write_text(json.dumps({'status':'passed','c_sha256':sha(out/'seed.c'),'plain_sha256':sha(out/'goose-plain'),'pgo_sha256':sha(out/'goose-pgo'),'profile_sha256':sha(out/'profile.profdata'),'fixed_point':True,'same_canonical_C_plain_and_profiled':True,'performance_claim':None},indent=2)+'\n')
print('canonical PGO fixed point passed',flush=True)
