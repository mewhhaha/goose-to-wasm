#!/usr/bin/env python3
"""Tiny helper-contract checks; no compiler, bootstrap or real qualification gate."""
import copy
import gzip
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import audit
import common


class MaintenanceChecks(unittest.TestCase):
    def test_stage_path_overrides_and_old_defaults(self):
        data=dict(parent_source_dir='parent-source',parent_proof_dir='parent-proof',parent_seed_dir='parent-seed')
        old=common.paths(data)
        self.assertEqual(old['transition'],common.WORK/'c-only-bootstrap-58-opt0')
        self.assertEqual(old['transition_source'],old['source'])
        for key in ('source','transition','transition_source','transition_seed','canonical','seed','native_runtime'):
            data[key+'_dir']='selected-'+key
        selected=common.paths(data)
        for key in ('source','transition','transition_source','transition_seed','canonical','seed'):
            self.assertEqual(selected[key],common.WORK/('selected-'+key))
        self.assertEqual(selected['native'],common.WORK/'selected-native_runtime')

    def test_each_stage_owns_its_complete_source_map(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            reports=[]
            for stage in ('transition','final'):
                tree=root/stage
                contents={'selfhost/main.goose':stage.encode(),'selfhost/model.goose':b'model','stdlib/std.goose':b'std','native/storage.h':stage.encode()}
                pins={}
                for name,content in contents.items():
                    target=tree/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(content);pins[name]=common.sha(target)
                common.save(tree/'source-pins.json',pins)
                report=dict(source_sha256={name[9:]:value for name,value in pins.items() if name.startswith('selfhost/')},stdlib_sha256={'std.goose':pins['stdlib/std.goose']},asset_sha256={'native/storage.h':pins['native/storage.h']})
                audit.source_identity(tree,report);reports.append(report)
            with self.assertRaises(AssertionError):audit.source_identity(root/'final',reports[0])
            incomplete=copy.deepcopy(reports[1]);del incomplete['source_sha256']['model.goose']
            with self.assertRaises(AssertionError):audit.source_identity(root/'final',incomplete)

    def test_public_receipt_pins_installed_binary_and_actual_profile_use(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);public=root/'public';binary=public/'build/bin/goose'
            binary.parent.mkdir(parents=True);binary.write_bytes(b'public compiler')
            cc=root/'clang';cc.write_bytes(b'pinned cc')
            manifest=root/'tests/conformance/cases.json';manifest.parent.mkdir(parents=True);manifest.write_text('{}')
            c_sha='a'*64
            build=dict(c_sha256=c_sha,goose_optimization=2,profile_used=False)
            identity=dict(clang_major=23,target='test-target',base_flags=['-std=gnu11','-O2'],c_basename='seed.c')
            report=dict(status='passed',fixed_point=True,goose_optimization=2,input_sha256={},input_sha256_after={},generated_c_sha256=c_sha,next_generation_c_sha256=c_sha,executable_c_sha256=c_sha,executable_sha256=common.sha(binary),seed_c_sha256=c_sha,executable_build=build,commands=[],seed_matches_sources=True,cc=str(cc),cc_sha256=common.sha(cc),profile_used=False,profile_identity=identity)
            for field in audit.MAPS:report[field]={}
            metadata={key:copy.deepcopy(report[key]) for key in ('goose_optimization','fixed_point','executable_c_sha256','seed_c_sha256','executable_build','cc_sha256','profile_used',*audit.MAPS)}
            metadata.update(compiler=str(binary),compiler_sha256=common.sha(binary))
            (public/'build/bootstrap').mkdir();common.save(public/'build/bootstrap/report.json',report);common.save(public/'build/toolchain.json',metadata)
            (public/'bootstrap').mkdir();common.save(public/'bootstrap/seed.json',{})
            common.save(public/'export.json',dict(source_only=True,source_sha256={'tests/conformance/cases.json':common.sha(manifest)}))
            data=dict(bootstrap_scripts={},cc_sha256=common.sha(cc),profile_required=False)
            with patch.object(audit,'ROOT',root):
                audit.public_artifact(public,report,{},data)
                metadata['compiler_sha256']='b'*64;common.save(public/'build/toolchain.json',metadata)
                with self.assertRaises(AssertionError):audit.public_artifact(public,report,{},data)
                metadata['compiler_sha256']=common.sha(binary);common.save(public/'build/toolchain.json',metadata)
                (public/'bootstrap/profile.profdata').write_bytes(b'profile')
                with self.assertRaises(AssertionError):audit.public_artifact(public,report,{},data)
                profile=dict(schema='goose-bootstrap-profile-v1',c_sha256=c_sha,data_sha256=common.sha(public/'bootstrap/profile.profdata'),**identity)
                common.save(public/'bootstrap/profile.json',profile)
                data.pop('profile_required')
                with self.assertRaises(AssertionError):audit.public_artifact(public,report,{},data)

    def test_direct_profile_maps_and_relative_binary_fingerprints(self):
        path=Path(__file__).with_name('capsule-audit.py')
        spec=importlib.util.spec_from_file_location('capsule_audit',path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);source=root/'fixture.goose';source.write_bytes(b'fixture')
            binary=root/'compiler';binary.write_bytes(b'\x7fELFfixture')
            report=root/'input-pins.json';common.save(report,{'fixture.goose':common.sha(source),'compiler':common.sha(binary)})
            result=module.coverage({'source/fixture.goose':source},[report])
            self.assertEqual(len(result['covered_source_pins']),1);self.assertEqual(len(result['excluded_executables']),1)
            binary.write_bytes(b'\x7fELFchanged')
            with self.assertRaises(AssertionError):module.coverage({'source/fixture.goose':source},[report])
            common.save(report,{'fixture.goose':common.sha(source)})
            with self.assertRaises(AssertionError):module.coverage({},[report])
            compressed=root/'compiler.gz';compressed.write_bytes(gzip.compress(binary.read_bytes(),mtime=0))
            with self.assertRaises(AssertionError):module.coverage({'compiler.gz':compressed},[report])


if __name__=='__main__':unittest.main()
