from pathlib import Path
import hashlib,json,re,subprocess,time,os
os.sched_setaffinity(0,{3})
R=Path('/home/jacobt/src/goose-to-wasm');H=R/'build/completion-runs/native-offset-bos-review-58/actual-header';H.mkdir(exist_ok=False)
parent=R/'build/completion-runs/compiler-record-paths-58/native/storage.h';candidate=R/'build/completion-runs/native-offset-bos-58/storage.h';C=R/'build/completion-runs/compiler-record-paths-58/compiler.c';probe=R/'build/completion-runs/native-offset-bos-review-58/probe.c'
old=parent.read_text();new=candidate.read_text();whole=C.read_text();assert whole.count(old)==1;prefix=whole[:whole.index(old)];(H/'pristine-runtime-prefix.c').write_text(prefix)
def offset(s):
 a=s.index('static ',s.index('static GRegion *g_array_region'))
 a=s.index('static ',a+1);b=s.index('\nstatic GRef g_owner',a);return s[a:b]
old_fn=offset(old);new_fn=offset(new);assert 'g_offset(' in old_fn and 'g_offset(' in new_fn;assert new.replace(new_fn,old_fn)==old
assert '__builtin_object_size(base,2)' in new_fn and new_fn.endswith('return ref+(uintptr_t)offset;\n}')
body=probe.read_text();body=body.replace('typedef uintptr_t GRef;\n','');a=body.index('static void panic(');b=body.index('AI size_t extent(',a)
body=body[:a]+old_fn.replace('g_offset(','original(')+'\n#define candidate g_offset\n'+body[b:]
body=body.replace('panic("null reference")','g_panic("null reference")').replace('"null reference\\n"','"goose runtime error: null reference (<native>:0)\\n"').replace('"negative reference offset\\n"','"goose runtime error: negative reference offset (<native>:0)\\n"')
(H/'probe-body.c').write_text(body)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest={'schema':'actual-offset-header-guards-v1','inputs':{str(p.relative_to(R)):sha(p) for p in [parent,candidate,C,probe]},'prefix_sha256':sha(H/'pristine-runtime-prefix.c'),'body_sha256':sha(H/'probe-body.c'),'contract':'Original integer result equality for fixed and runtime offsets including beyond-object addresses without loads; NULL0; uintptr wrap; unknown0; Small/Large minimum<=24;6 exact normal-exit1 panic cases; no runtime initialization or source/expectation adaptation from candidate output.'}
for tag,s in [('parent',old),('candidate',new)]:
 (H/(tag+'.c')).write_text(prefix+s+'\n'+body)
manifest['translation_units']={tag:sha(H/(tag+'.c')) for tag in ['parent','candidate']};(H/'frozen-input.json').write_text(json.dumps(manifest,indent=2)+'\n')
rows=[]
for tag in ['parent','candidate']:
 for cc in ['clang','gcc']:
  for flags,label in [(['-O0'],'O0'),(['-O2'],'O2'),(['-O1','-fsanitize=address,undefined,pointer-overflow'],'san')]:
   output=H/(tag+'-'+cc+'-'+label);cmd=[cc,'-std=gnu11',*flags,str(H/(tag+'.c')),'-lm','-ldl','-pthread','-o',str(output)];start=time.monotonic();r=subprocess.run(cmd,capture_output=True,text=True);row={'tag':tag,'cc':cc,'profile':label,'command':cmd,'build_exit':r.returncode,'build_stderr':r.stderr}
   if not r.returncode:
    run=subprocess.run([str(output)],capture_output=True,text=True,timeout=15);row.update(exit=run.returncode,stdout=run.stdout,stderr=run.stderr)
   row['seconds']=time.monotonic()-start;rows.append(row)
   (H/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
   assert row.get('exit')==0 and not row.get('stderr'),row
for tag in ['parent','candidate']:
 cmd=['clang','-std=gnu11','-O2','-S','-emit-llvm',str(H/(tag+'.c')),'-o',str(H/(tag+'-O2.ll'))];r=subprocess.run(cmd,capture_output=True,text=True);assert r.returncode==0,r.stderr
print(json.dumps([{k:r[k] for k in ['tag','cc','profile','exit','stdout','seconds']} for r in rows],indent=2))
