from pathlib import Path
import json,re,collections,hashlib
root=Path('build/completion-runs/lifetime-closed-scalar-review-58')
model=Path('build/completion-runs/compiler-facts-58/selfhost/model.goose').read_text();K={m[1]:int(m[2]) for m in re.finditer(r'let (\w+): i64 = (\d+);',model)}
allowed={K['N_'+x] for x in ['VARIABLE','BLOCK','INTEGER','FLOAT','BOOL','NAME','UNARY','BINARY','CALL','IF','WHILE','FOR','LOOP','RETURN','BREAK','CONTINUE','ASSIGN','EXPR_STMT','TYPE_NAME','CAST','RANGE','EMPTY','BINDING']}
loopkinds={K['N_'+x] for x in ['WHILE','FOR','LOOP']};structural={K['N_'+x] for x in ['BLOCK','RETURN','BREAK','CONTINUE','EXPR_STMT','EMPTY','IF','WHILE','FOR','LOOP']}
reports=[]
for workload in ['mandelbrot','functions']:
 d=json.loads((root/(workload+'-ir.json')).read_text());nodes={x['id']:x for x in d['nodes']};types={x['id']:x for x in d['types']};syms={x['id']:x for x in d['symbols']};tokens={x['id']:x for x in d['tokens']};owners=collections.defaultdict(list)
 for s in syms.values():owners[s['owner']].append(s)
 memo={};details={};reason=collections.Counter()
 def raw(t):return 0<=t<=11
 def linked(n):
  seen=set()
  while n>=0 and n not in seen:
   seen.add(n);yield n;n=nodes[n]['next']
 def check(fn):
  if fn in memo:return memo[fn]
  memo[fn]=False
  f=nodes.get(fn)
  def reject(why):details[fn]={'reason':why};return False
  if not f or f['kind']!=K['N_FUNCTION'] or f['right']<0 or not f['flags']&K['F_CHECKED']:return reject('not checked ordinary body')
  if f['flags']&(K['F_EXTERN']|K['F_GENERIC']|K['F_RECURSIVE']|K['F_NONLOCAL']|K['F_THREAD']) or f['captures']>=0:return reject('function flags/capture')
  ft=types.get(f['type_id'],{});result=ft.get('element',-1)
  if ft.get('kind')!=K['TY_FN'] or not raw(result):return reject('noncanonical scalar result')
  if f['symbol']<0 or syms[f['symbol']]['owner']>=0:return reject('nested function')
  for p in linked(f['first']):
   if not raw(nodes[p]['type_id']):return reject('noncanonical scalar formal')
  for s in owners[fn]:
   if s['flags']&(K['S_GLOBAL']|K['S_CAPTURE']|K['S_FUNCTION']|K['S_TYPE']|K['S_BUILTIN']|K['S_EXTERN']) or not raw(s['type_id']):return reject('nonclosed scalar local')
  todo=[f['right']];seen=set();calls=set();has_loop=False
  while todo:
   i=todo.pop()
   if i<0 or i in seen:continue
   seen.add(i);n=nodes[i];kind=n['kind'];ty=n['type_id']
   if kind not in allowed:return reject('node kind '+str(kind))
   if not raw(ty) and not (ty<0 and kind in structural):return reject('noncanonical node type')
   if n['coerced_type']>=0 and not raw(n['coerced_type']):return reject('noncanonical coercion')
   if n['captures']>=0 or n['flags']&K['F_NONLOCAL']:return reject('node capture/nonlocal')
   if kind==K['N_NAME']:
    s=syms.get(n['symbol'])
    if not s or s['owner']!=fn or s['flags']&(K['S_GLOBAL']|K['S_CAPTURE']|K['S_FUNCTION']|K['S_TYPE']|K['S_BUILTIN']|K['S_EXTERN']) or not raw(s['type_id']):return reject('nonlocal name')
   if kind==K['N_UNARY'] and n['integer'] in (K['T_BITAND'],K['T_MUL']):return reject('address/dereference')
   if kind==K['N_RETURN'] and n['symbol'] not in (-1,f['symbol']):return reject('nonlocal return')
   if kind in loopkinds:has_loop=True
   if kind==K['N_CALL']:
    s=syms.get(n['symbol']);head=nodes.get(n['left'],{})
    if n['flags']&K['F_DISPATCH'] or not s or not s['flags']&K['S_FUNCTION'] or s['flags']&(K['S_BUILTIN']|K['S_EXTERN']) or head.get('kind')!=K['N_NAME'] or head.get('symbol')!=n['symbol']:return reject('indirect/builtin/extern call')
    callee=s['node'];calls.add(callee)
    if not check(callee):return reject('callee rejected/cycle')
    has_loop|=details[callee]['has_loop']
    todo.extend(linked(n['first']));continue
   todo.extend(linked(n['first']))
   todo.extend(n[x] for x in ['left','right','third'])
   if kind==K['N_VARIABLE']:todo.extend(linked(n['right']))
  memo[fn]=True;details[fn]={'reason':'eligible','function':tokens.get(f['token'],{}).get('text','?'),'node':fn,'nodes':len(seen),'has_loop':has_loop,'calls':sorted(calls),'source':tokens.get(f['token'],{}).get('source'),'line':tokens.get(f['token'],{}).get('line')};return True
 funcs=[n['id'] for n in nodes.values() if n['kind']==K['N_FUNCTION'] and n['right']>=0 and n['flags']&K['F_CHECKED'] and not n['flags']&K['F_GENERIC']]
 for fn in funcs:check(fn)
 good=[details[fn] for fn in funcs if memo[fn]]
 report={'workload':workload,'checked_ordinary_functions':len(funcs),'eligible_including_loop_counterexample':len(good),'eligible_body_nodes_including_loops':sum(r['nodes'] for r in good),'eligible_without_transitive_loops':sum(not r['has_loop'] for r in good),'eligible_body_nodes_without_loops':sum(r['nodes'] for r in good if not r['has_loop']),'functions':good,'rejections':dict(collections.Counter(details[fn]['reason'] for fn in funcs if not memo[fn]))};reports.append(report);print(json.dumps(report,indent=2))
(root/'eligibility-counts.json').write_text(json.dumps({'method':'Source-only conservative typed-IR census, not compiler implementation. Only builtin primitive type IDs0..11 accepted because dump omits index_type; nested functions and unsupported node forms rejected. Dump occurs after lifetime export but before optimizer; named_results omitted, so explicit named-result eligibility requires implementation-level review. Loop-containing candidates are NOT sound for type-only bypass under current checker behavior.','reports':reports},indent=2)+'\n')
