Snapshot58 source reproduction

Run python REPRODUCE.py verify, compose --stage transition, compose --stage final, and compose --stage upgrade in separate new directories. Run bootstrap --cc clang to reproduce the verified57→A19opt0→SPopt2 C-only chain. public-bootstrap uses the finalC2 seed and exact optional profile. contracts exercises frozen expectations without a C++ oracle.

source/ is the frozen qualification export, including its original README and export inventory. documentation/current-product/ holds the final noncompiler documentation refresh separately; overlaying those four README files changes no compiler input.

The raw reports preserve commands, source/engine/compiler hashes and failed attempts. Prebuilt ELF tools/compilers, benchmark prebuilt engine containers and derived benchmark modules are excluded with verified hashes/provenance. Rebuild them using recorded commands; Wasmtime50.0.1, Node24 and native toolchain prerequisites are not silently claimed portable. The unused Python bytecode is evidence only under profile-evidence/.
