#define _GNU_SOURCE 1
#include "runtime/runtime.h"
#include "runtime/runtime_impl.h"
#include "runtime/runtime_threads.h"
#include "storage.h"
#include <assert.h>
#include <sys/wait.h>
int main(int argc,char **argv) {
    g_runtime_start(argc,argv,0,0);
    assert(g_offset(0,0)==0);
    for(int mode=0;mode<2;mode++) {
        pid_t child=fork();assert(child>=0);
        if(!child) { if(mode==0)g_offset(0,1);else g_address(0);_exit(0); }
        int status;assert(waitpid(child,&status,0)==child);
        assert(WIFEXITED(status) && WEXITSTATUS(status)!=0);
    }
    puts("null offset checks ok");return 0;
}
