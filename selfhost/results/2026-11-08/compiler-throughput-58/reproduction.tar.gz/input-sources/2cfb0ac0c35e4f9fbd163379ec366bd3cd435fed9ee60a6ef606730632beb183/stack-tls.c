#define _GNU_SOURCE 1
#include "runtime/runtime.h"
#include "runtime/runtime_impl.h"
#include "runtime/runtime_threads.h"
#include "storage.h"
#include <assert.h>
#include <sys/wait.h>

static void *fresh_thread(void *unused) {
    (void)unused;assert(g_native_stack_low==0);
    g_stack_check();uintptr_t first=g_native_stack_low;assert(first);
    g_stack_check();assert(g_native_stack_low==first);
    g_native_stack_low=0;g_stack_check();assert(g_native_stack_low==first);
    return NULL;
}
int main(int argc,char **argv) {
    g_runtime_start(argc,argv,0,0);
    assert(g_native_stack_low==0);g_stack_check();uintptr_t first=g_native_stack_low;
    assert(first);g_stack_check();assert(g_native_stack_low==first);
    for(int i=0;i<2;i++) { pthread_t thread;assert(!pthread_create(&thread,NULL,fresh_thread,NULL));assert(!pthread_join(thread,NULL)); }
    assert(g_native_stack_low==first);g_mark_regions(0,0,NULL);
    pid_t child=fork();assert(child>=0);
    if(!child) { unsigned char here;g_native_stack_low=(uintptr_t)&here-65536;g_stack_check();_exit(0); }
    int status;assert(waitpid(child,&status,0)==child);
    assert(WIFEXITED(status) && WEXITSTATUS(status)!=0);
    puts("native stack TLS ok");return 0;
}
