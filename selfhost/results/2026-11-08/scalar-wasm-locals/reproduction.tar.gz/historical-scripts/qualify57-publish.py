"""Build only snapshot57 qualification evidence; never stage git or edit live inputs.

Default is inventory preparation. Run --write after the quiet timing window.
"""
from pathlib import Path
import argparse
import collections
import gzip
import hashlib
import io
import json
import tarfile

ROOT = Path('/home/jacobt/src/goose-to-wasm')
WORK = ROOT / 'build/completion-runs'
DESTINATION = ROOT / 'selfhost/results/2026-11-08/scalar-wasm-locals'
META = WORK / 'qualify57-capsule-meta'
CODEGEN = 'fbc56870acf7551a43797cb4605c9fe49b5d976f65ffed0a7b3c8a215531dbae'
CANONICAL_C = 'b03232d61bed94dea5ffa30d408930993654ce8b5a4ad45acbaa160e0f89a3ae'
PUBLIC_COMPILER = '8b33754483aed2a04c8be11ac9c42a062f6c6720cbd58316d3c4b4f236803eb9'


def read(path):
    return json.loads(path.read_text())


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n')


def collect():
    files = {}

    def add(name, path):
        assert path.is_file(), path
        assert name not in files, name
        assert not Path(name).is_absolute() and '..' not in Path(name).parts
        files[name] = path

    def tree(folder, prefix):
        for path in sorted(folder.rglob('*')):
            if path.is_file() and '__pycache__' not in path.parts:
                add(prefix + '/' + path.relative_to(folder).as_posix(), path)

    for folder, prefix in [('snapshot-57', 'source'), ('snapshot-56', 'parent-source')]:
        tree(WORK / folder, prefix)
    for folder, prefix in [('verified-seed-56', 'parent-seed'), ('verified-seed-57', 'source/bootstrap')]:
        tree(WORK / folder, prefix)
    public = WORK / 'public-57'
    for folder in ('stdlib', 'tests/fixtures', 'tests/conformance', 'examples'):
        tree(public / folder, 'source/' + folder)
    for name in ('LICENSE', 'AGENTS.md', 'selfhost/bootstrap.py', 'scripts/bootstrap.py',
                 'scripts/goose_wasm.py', 'scripts/run_wasm.mjs', 'scripts/run_wasmtime.py', 'tests/conformance.py'):
        add('source/' + name, public / name)
    add('source/requirements.txt', ROOT / 'requirements.txt')
    add('qualification/public-smoke-float.goose', public / 'build/smoke/float.goose')
    for name in ('assemble_delivery_v3.py', 'prepare_delivery_v3.py', 'reproduce_delivery_v4.py',
                 'compare_delivery_v2.py'):
        add('historical-scripts/' + name, WORK / name)
    for path in sorted(WORK.glob('qualify57-*.py')):
        add('historical-scripts/' + path.name, path)
    for name in ('freeze_seed.py', 'conformance_shards.py'):
        add('historical-scripts/durable-tools/' + name, WORK / 'durable-tools' / name)
    for path in sorted(WORK.glob('qualify57-*.json')):
        if path.name not in ('qualify57-capsule-plan.json', 'qualify57-stage-source-plan.json'):
            add('qualification/receipts/' + path.name, path)
    for name in ('delivery-57.json', 'delivery-57-controls-ready.json', 'new-controls-57.json',
                 'snapshot-57-assembly.json', 'reproduction-57.json', 'comparison-57.json',
                 'remaining-phases-57.json', 'public-smoke-context-57.json'):
        add('qualification/receipts/' + name, WORK / name)
    for folder, prefix in [('c-only-conformance-57-qualified', 'wasmtime'), ('c-only-v8-57-qualified', 'v8')]:
        for path in sorted((WORK / folder).glob('cases-*.json')):
            add('qualification/partitions/' + prefix + '-' + path.name, path)
    for folder in ('resolver-demand-57', 'resolver-scalars-57', 'astra-resolver-57'):
        for path in sorted((WORK / folder).rglob('*')):
            relative = path.relative_to(WORK / folder)
            if not path.is_file() or '__pycache__' in relative.parts or 'artifacts' in relative.parts:
                continue
            if path.suffix not in ('.goose', '.py', '.json', '.md', '.patch', '.stdout', '.stderr', '.txt', '.log', '.wat'):
                continue
            if 'selfhost' in relative.parts and path.name != 'codegen.goose':
                continue
            add('components/' + folder + '/' + relative.as_posix(), path)
    for name in ('assemble-57', 'canonical-57', 'freeze-57', 'prepare-57', 'reproduce-57',
                 'conformance-57', 'v8-57', 'public-bootstrap-57', 'public-smoke-57', 'public-cross-57',
                 'astra-canonical57', 'astra-canonical57-scalar', 'compare-57',
                 'qualify57-controls', 'qualify57-controls-admitted'):
        add('qualification/logs/' + name + '.log', WORK / (name + '.log'))
    add('qualification/native-emission.json', WORK / 'qualify57-native-emission/report.json')
    add('REPRODUCE.py', WORK / 'qualify57-reproduce.py')
    return files


def validate():
    proof = read(WORK / 'c-only-bootstrap-57/report.json')
    parent = read(WORK / 'c-only-bootstrap-56/report.json')
    full = read(WORK / 'c-only-conformance-57-qualified/report.json')
    v8 = read(WORK / 'c-only-v8-57-qualified/report.json')
    comparison = read(WORK / 'comparison-57.json')
    cross = read(WORK / 'public-cross-57/report.json')
    manifest = read(WORK / 'public-57/tests/conformance/cases.json')
    assert read(WORK / 'qualify57-run.json')['status'] == 'passed'
    assert proof['status'] == parent['status'] == 'passed' and proof['fixed_point']
    assert proof['source_sha256']['codegen.goose'] == CODEGEN
    assert proof['executable_c_sha256'] == proof['generated_c_sha256'] == proof['next_generation_c_sha256'] == CANONICAL_C
    assert cross['status'] == 'passed' and cross['compiler_sha256'] == PUBLIC_COMPILER
    assert cross['c_sha256'] == CANONICAL_C
    assert proof['asset_sha256'] == parent['asset_sha256']
    assert full['summary'] == dict(selected=7871, passed=7771, failed=100)
    assert v8['status'] == 'passed' and v8['summary'] == dict(selected=4780, passed=4780, failed=0)
    assert len(comparison['new_rows']) == 84
    assert not comparison['shared_regressions'] and not comparison['new_failures'] and not comparison['removed_rows']
    for report in (proof, full, v8):
        assert report['input_sha256'] == report['input_sha256_after']
    for name, expected in proof['source_sha256'].items():
        assert sha(WORK / 'snapshot-57/selfhost' / name) == expected
    for name, expected in proof['asset_sha256'].items():
        assert sha(WORK / 'snapshot-57' / name) == expected
    for name, expected in proof['stdlib_sha256'].items():
        assert sha(WORK / 'public-57/stdlib' / name) == expected
    for name, expected in read(WORK / 'new-controls-57.json')['sources'].items():
        assert sha(WORK / 'public-57' / name) == expected
    assert sha(WORK / 'public-57/tests/conformance/cases.json') == read(WORK / 'new-controls-57.json')['combined_manifest_sha256']
    targets = {case['id']: case['target'] for case in manifest['cases']}
    curated = collections.Counter(targets[row['case']] for row in v8['results'])
    assert curated == dict(native=1410, **{'wasm-direct': 3370})
    guards = [read(WORK / 'astra-resolver-57/canonical57.json'), read(WORK / 'astra-resolver-57/canonical57-scalar.json')]
    assert sum(report['passed'] for report in guards) == sum(report['total'] for report in guards) == 50
    assert all(report['complete'] and report['compiler_sha256'] == proof['executable_sha256'] for report in guards)
    native = read(WORK / 'native-runtime-49-final/report.json')
    assert len(native['runs']) == 45 and all(row['returncode'] == 0 for row in native['runs'])
    for name in ('storage.h', 'pools.h', 'relative.h', 'images.h', 'runs.h'):
        assert native['inputs_sha256'][name] == proof['asset_sha256']['native/' + name]
    assert native['inputs_sha256']['bounded_cells.c'] == sha(WORK / 'snapshot-57/native/tests/bounded_cells.c')
    return proof, full, v8, comparison, cross, curated


def stage_plan(proof):
    files = {}
    for name, expected in proof['source_sha256'].items():
        files['selfhost/' + name] = dict(source=str(WORK / 'snapshot-57/selfhost' / name), sha256=expected)
    for path in sorted((WORK / 'snapshot-57/native').rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:
            files['native/' + path.relative_to(WORK / 'snapshot-57/native').as_posix()] = dict(source=str(path), sha256=sha(path))
    for name in ('proof.json', 'seed.c.gz', 'seed.json', 'sources.tar.gz'):
        path = WORK / 'verified-seed-57' / name
        files['bootstrap/' + name] = dict(source=str(path), sha256=sha(path))
    path = WORK / 'public-57/tests/conformance/cases.json'
    files['tests/conformance/cases.json'] = dict(source=str(path), sha256=sha(path))
    for name, expected in read(WORK / 'new-controls-57.json')['sources'].items():
        files[name] = dict(source=str(WORK / 'public-57' / name), sha256=expected)
    return dict(status='private source staging inventory only; no live writes or git actions', files=files,
                expected_codegen_sha256=CODEGEN, canonical_c_sha256=CANONICAL_C,
                public_compiler_sha256=PUBLIC_COMPILER)


def report_sources():
    reports = {
        'bootstrap.json.gz': WORK / 'c-only-bootstrap-57/report.json',
        'parent-bootstrap.json.gz': WORK / 'c-only-bootstrap-56/report.json',
        'conformance.json.gz': WORK / 'c-only-conformance-57-qualified/report.json',
        'v8.json.gz': WORK / 'c-only-v8-57-qualified/report.json',
        'public-bootstrap.json.gz': WORK / 'public-57/build/bootstrap/report.json',
        'baseline-new-wasmtime.json.gz': WORK / 'qualify57-baseline-wasmtime/report.json',
        'baseline-new-v8.json.gz': WORK / 'qualify57-baseline-v8/report.json',
        'independent-guards.json.gz': WORK / 'astra-resolver-57/canonical57.json',
        'independent-scalar-guard.json.gz': WORK / 'astra-resolver-57/canonical57-scalar.json',
        'native-runtime.json.gz': WORK / 'native-runtime-49-final/report.json',
    }
    return reports


def summary(proof, full, v8, comparison, cross, curated):
    failures = [row for row in full['results'] if row['status'] != 'pass']
    threads = [row for row in full['results'] if row['case'].startswith('upstream/threads/')]
    assert len(threads) == 52 and all(row['status'] == 'pass' for row in threads)
    return dict(schema='goose-compiler-qualification-v1', snapshot='57', complete=False,
        qualification_gates='passed', bootstrap_status=proof['status'], bootstrap_c_sha256=CANONICAL_C,
        source_sha256=proof['source_sha256'], asset_sha256=proof['asset_sha256'], stdlib_sha256=proof['stdlib_sha256'],
        compiler_sha256=proof['executable_sha256'], public_compiler_sha256=PUBLIC_COMPILER,
        public_same_path_c_sha256=cross['c_sha256'], fixed_point_scope='G1 equals G2 using verified snapshot56 C seed; no C++ reference compiler.',
        contracts=full['summary'], parent_contract_rows=7787, original_contract_rows=7787,
        original_contract_scope='Immediate parent snapshot56: every existing case and expectation preserved.',
        curated_v8_driver=v8['summary'], curated_wasm_per_engine=curated['wasm-direct'], curated_native_controls=curated['native'],
        native_thread_checks=52, existing_contract_gains=len(comparison['shared_gains']), existing_contract_regressions=0,
        new_contract_rows=84, new_contract_failures=0, independent_canonical_guards=dict(selected=50, passed=50, failed=0),
        remaining_failure_phases=dict(collections.Counter(row['phase'] for row in failures)),
        remaining_runtime_failure_detail=read(WORK / 'remaining-phases-57.json'),
        remaining_failure_groups=dict(collections.Counter('/'.join(row['case'].split('/')[:2]) for row in failures)),
        permanent_controls=read(WORK / 'new-controls-57.json'), scope=read(WORK / 'delivery-57.json')['scope'],
        native_runtime_reference='Unchanged native headers and permanent C controls retain the snapshot49 45-command qualification, already reused by snapshot56; it is a separately collected reference.',
        native_emission_control='Functions source emits byte-identical native C on canonical56 and57 at O0/O2.',
        measured_performance='Published separately; this capsule records source and correctness qualification, not a new timing campaign.')


def compress(source, target):
    with target.open('xb') as raw:
        with gzip.GzipFile(fileobj=raw, mode='wb', compresslevel=6, mtime=0, filename='') as zipped:
            with source.open('rb') as stream:
                while block := stream.read(1024 * 1024):
                    zipped.write(block)


def archive(path, files):
    seen = {}
    with path.open('xb') as raw:
        with gzip.GzipFile(fileobj=raw, mode='wb', compresslevel=6, mtime=0, filename='') as zipped:
            with tarfile.open(fileobj=zipped, mode='w|') as bundle:
                for name, source in sorted(files.items()):
                    identity = sha(source)
                    item = tarfile.TarInfo(name)
                    item.mode = 0o644
                    if identity in seen:
                        item.type = tarfile.LNKTYPE
                        item.linkname = seen[identity]
                        bundle.addfile(item)
                    else:
                        item.size = source.stat().st_size
                        with source.open('rb') as stream:
                            bundle.addfile(item, stream)
                        seen[identity] = name


def pin_coverage(files):
    provided = {}
    for name, source in sorted(files.items()):
        provided[sha(source)] = dict(file=name)
        if name.endswith('.gz'):
            provided[hashlib.sha256(gzip.decompress(source.read_bytes())).hexdigest()] = dict(gzip=name)
        if name.endswith('.tar.gz'):
            with tarfile.open(source) as bundle:
                for member in bundle:
                    if member.isfile():
                        data = bundle.extractfile(member).read()
                        provided[hashlib.sha256(data).hexdigest()] = dict(archive=name, member=member.name)
    checked, binaries = {}, {}
    reports = ['c-only-bootstrap-57/report.json', 'c-only-conformance-57-qualified/report.json',
               'c-only-v8-57-qualified/report.json', 'qualify57-baseline-wasmtime/report.json',
               'qualify57-baseline-v8/report.json', 'public-57/build/bootstrap/report.json']
    for name in reports:
        for original, expected in read(WORK / name)['input_sha256'].items():
            if expected in provided:
                checked[original] = dict(sha256=expected, provided_by=provided[expected])
                continue
            path = Path(original)
            assert path.is_file(), ('Pinned input missing', original)
            with path.open('rb') as stream:
                assert stream.read(4) == b'\x7fELF', ('Non-binary pinned input omitted from capsule', original)
            binaries[original] = dict(sha256=expected, reason='Executable excluded from source-only capsule; raw fingerprint retained.')
    return dict(status='passed', covered_source_and_report_pins=checked, excluded_executables=binaries,
                scope='All source, fixture, expected-output, bundle, helper and report input pins are represented exactly; only prebuilt executables are excluded.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--write', action='store_true')
    args = parser.parse_args()
    proof, full, v8, comparison, cross, curated = validate()
    files = collect()
    save(WORK / 'qualify57-stage-source-plan.json', stage_plan(proof))
    plan = dict(status='ready; compression/publication not executed', destination=str(DESTINATION),
                files={name: dict(source=str(path), bytes=path.stat().st_size) for name, path in sorted(files.items())},
                report_sources={name: str(path) for name, path in report_sources().items()},
                exclusions=['Temporary compiler executables, generated compiler C, native code caches and per-case generated artifacts are excluded; their original fingerprints/commands remain in raw reports.',
                            'Upstream extraction copies are represented by the unchanged upstream.tar.gz; its contents and hash remain pinned.',
                            'Performance datasets and charts are separate deliverables, not folded into source qualification.'])
    save(WORK / 'qualify57-capsule-plan.json', plan)
    if not args.write:
        print('Prepared', len(files), 'archive paths; no compression, dated writes, live changes or git actions.')
        return 0
    DESTINATION.mkdir(parents=True, exist_ok=True)
    targets = [*report_sources(), 'summary.json', 'public-smoke.json', 'public-cross.json', 'comparison.json',
               'new-controls.json', 'qualification-sequence.json', 'reproduction.tar.gz', 'reproduction-manifest.json']
    assert not [name for name in targets if (DESTINATION / name).exists()], 'Publication outputs already exist; never overwrite delivered evidence.'
    META.mkdir(exist_ok=False)
    for name, source in report_sources().items():
        compress(source, DESTINATION / name)
        files['qualification/' + name] = DESTINATION / name
    for label, prefix, count in [('c-only-conformance-57-qualified', 'wasmtime', 4), ('c-only-v8-57-qualified', 'v8', 2)]:
        for index in range(count):
            target = META / (prefix + '-shard-' + str(index) + '.json.gz')
            compress(WORK / label / ('shard-' + str(index)) / 'report.json', target)
            files['qualification/shards/' + target.name] = target
    parent_report = META / 'parent-conformance.json.gz'
    compress(WORK / 'c-only-conformance-56-qualified/report.json', parent_report)
    files['qualification/parent-conformance.json.gz'] = parent_report
    for source, name in [('public-57/build/smoke/report.json', 'public-smoke.json'),
                         ('public-cross-57/report.json', 'public-cross.json'), ('comparison-57.json', 'comparison.json'),
                         ('new-controls-57.json', 'new-controls.json'), ('qualify57-run.json', 'qualification-sequence.json')]:
        data = (WORK / source).read_bytes()
        with (DESTINATION / name).open('xb') as stream:
            stream.write(data)
        files['qualification/' + name] = DESTINATION / name
    save(DESTINATION / 'summary.json', summary(proof, full, v8, comparison, cross, curated))
    files['qualification/summary.json'] = DESTINATION / 'summary.json'
    guide = META / 'REPRODUCE.md'
    guide.write_text('# Snapshot57 source and qualification\n\n'
        'Run `python REPRODUCE.py verify`, then `python REPRODUCE.py compose`. '
        'Run `python REPRODUCE.py bootstrap --cc clang` to build from the verified snapshot56 C seed and require a C fixed point. '
        'This requires Python, a C compiler, libc/libm/libdl/pthreads; no C++ reference compiler is used.\n\n'
        'For runtime contracts install `source/requirements.txt` (Wasmtime 50.0.1); V8 additionally needs Node. '
        'Run `python REPRODUCE.py contracts --engine wasmtime` and `python REPRODUCE.py contracts --engine v8`. '
        'The full runner retains 100 inherited gaps. The separate parent comparison requires every new and previously passing row to pass. '
        'Use `--timeout` when reproducing on a slower host; it is recorded by the runner.\n\n'
        'Source hashes are portable. Generated C and executable hashes depend on source paths and toolchain; '
        'the recorded same-path cross-emission proves the delivered public compiler reproduces canonical C. '
        'Historical helper scripts preserve exact commands and absolute paths as evidence; use REPRODUCE.py outside the original checkout.\n\n'
        'Intermediate resolver-only/scalar pilots, rejected authoring drafts, source patches and qualification corrections remain under components/ and qualification/. '
        'They are exploratory evidence, not additional accepted changes or timing claims. '
        'Only the combined patch changes codegen.goose; all native inputs remain unchanged.\n')
    files['REPRODUCE.md'] = guide
    coverage_path = META / 'pin-coverage.json'
    save(coverage_path, pin_coverage(files))
    files['qualification/pin-coverage.json'] = coverage_path
    inventory = {name: dict(sha256=sha(path), bytes=path.stat().st_size) for name, path in sorted(files.items())}
    manifest = dict(schema='goose-source-qualification-capsule-v1', snapshot=57,
                    codegen_sha256=CODEGEN, canonical_c_sha256=CANONICAL_C,
                    public_compiler_sha256=PUBLIC_COMPILER, files=inventory, exclusions=plan['exclusions'])
    manifest_path = META / 'capsule-manifest.json'
    save(manifest_path, manifest)
    files['capsule-manifest.json'] = manifest_path
    archive_path = DESTINATION / 'reproduction.tar.gz'
    archive(archive_path, files)
    receipt = dict(status='passed', capsule_sha256=sha(archive_path), capsule_bytes=archive_path.stat().st_size,
                   capsule_manifest_sha256=sha(manifest_path), files=len(files), capsule_manifest=manifest)
    save(DESTINATION / 'reproduction-manifest.json', receipt)
    plan.update(status='written; archive verification pending', archive_sha256=receipt['capsule_sha256'], archive_bytes=receipt['capsule_bytes'])
    save(WORK / 'qualify57-capsule-plan.json', plan)
    print('Published qualification evidence:', DESTINATION)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
