"""Full frozen qualification; existing parent gaps remain visible and compared."""
from pathlib import Path
import concurrent.futures
import hashlib
import json
import os
import subprocess
import sys
import time

root = Path('/home/jacobt/src/goose-to-wasm')
work = root / 'build/completion-runs'
output = work / 'qualify57-run.json'
assert not output.exists()
assert json.loads((work / 'qualify57-prepare.json').read_text())['status'] == 'passed'
controls = json.loads((work / 'new-controls-57.json').read_text())
assert controls['status'] == 'passed' and controls['rows'] == 84 and controls['total_rows'] == 7871
manifest = root / 'tests/conformance/cases.json'
assert hashlib.sha256(manifest.read_bytes()).hexdigest() == controls['combined_manifest_sha256']
report = dict(status='running', commands=[], expected_full_rows=7871, expected_curated_rows=4780,
              expected_new_rows=84, compiler=str(work / 'c-only-bootstrap-57/goose'))

def save():
    output.write_text(json.dumps(report, indent=2) + '\n')

def run(label, command, env=None, allowed=(0,)):
    command = list(map(str, command))
    started = time.monotonic()
    with (work / (label + '.log')).open('x') as log:
        result = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    row = dict(label=label, command=command, exit_code=result.returncode, seconds=time.monotonic() - started,
               log=str(work / (label + '.log')))
    assert result.returncode in allowed, row
    return row

def public():
    env = dict(os.environ, PATH='/usr/bin:/bin')
    env.pop('TMPDIR', None)
    rows = [run('public-bootstrap-57', ['/usr/bin/python3', work / 'public-57/scripts/bootstrap.py', '--verify'], env)]
    rows.append(run('public-smoke-57', [sys.executable, work / 'qualify57-public-smoke.py']))
    rows.append(run('public-cross-57', [sys.executable, work / 'qualify57-public-cross.py']))
    return rows

save()
try:
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        futures = [pool.submit(run, 'conformance-57', [sys.executable, work / 'durable-tools/conformance_shards.py',
                    '--compiler', work / 'c-only-bootstrap-57/goose', '--output-dir', work / 'c-only-conformance-57-qualified', '--jobs', '4'], None, (0, 1)),
                   pool.submit(run, 'v8-57', [sys.executable, work / 'qualify57-v8.py',
                    '--compiler', work / 'c-only-bootstrap-57/goose', '--output-dir', work / 'c-only-v8-57-qualified', '--jobs', '2']),
                   pool.submit(public)]
        for future in concurrent.futures.as_completed(futures):
            row = future.result()
            if isinstance(row, list):
                report['commands'].extend(row)
            else:
                report['commands'].append(row)
            save()
    # These independent controls run the actual C-seed-built compiler, never a private pilot binary.
    for label, contract in [('canonical57', 'valid-manifest.json'), ('canonical57-scalar', 'scalar-supplement-manifest.json')]:
        report['commands'].append(run('astra-' + label, [sys.executable, work / 'astra-resolver-57/check.py',
            work / 'c-only-bootstrap-57/goose', label, contract]))
        guard = json.loads((work / 'astra-resolver-57' / (label + '.json')).read_text())
        assert guard['complete'] and guard['passed'] == guard['total']
    report['commands'].append(run('compare-57', [sys.executable, work / 'compare_delivery_v2.py', '57']))
    comparison = json.loads((work / 'comparison-57.json').read_text())
    assert not comparison['shared_regressions'] and not comparison['new_failures'] and not comparison['removed_rows']
    assert len(comparison['new_rows']) == 84
    full = json.loads((work / 'c-only-conformance-57-qualified/report.json').read_text())
    v8 = json.loads((work / 'c-only-v8-57-qualified/report.json').read_text())
    assert full['summary']['selected'] == 7871
    assert v8['status'] == 'passed' and v8['summary'] == dict(selected=4780, passed=4780, failed=0)
    assert hashlib.sha256(manifest.read_bytes()).hexdigest() == controls['combined_manifest_sha256']
    counts = dict(compiler_refusal=0, c_compiler_failure=0, executed_mismatch=0)
    for row in full['results']:
        if row['status'] == 'pass' or row['phase'] != 'run':
            continue
        if full['commands'][row['compile_command']]['exit_code'] != 0:
            counts['compiler_refusal'] += 1
        elif 'run_command' not in row:
            counts['c_compiler_failure'] += 1
        else:
            counts['executed_mismatch'] += 1
    (work / 'remaining-phases-57.json').write_text(json.dumps(counts, indent=2) + '\n')
    report.update(status='passed', full_summary=full['summary'], curated_v8_summary=v8['summary'], remaining_phases=counts)
except BaseException as error:
    report.update(status='failed', error=repr(error))
    raise
finally:
    save()
