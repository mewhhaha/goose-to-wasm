"""Check unchanged native lowering on the same functions source and input paths."""
from pathlib import Path
import hashlib
import json
import subprocess

root = Path('/home/jacobt/src/goose-to-wasm')
work = root / 'build/completion-runs'
out = work / 'qualify57-native-emission'
out.mkdir(exist_ok=False)
source = root / 'examples/functions.goose'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
report = dict(status='running', scope='Correctness/emission identity control, not timing evidence.',
              source=str(source), source_sha256=sha(source), commands=[], levels=[])
try:
    for level in (0, 2):
        artifacts = []
        for version in (56, 57):
            compiler = work / f'c-only-bootstrap-{version}/goose'
            artifact = out / f'functions-{version}-O{level}.c'
            command = list(map(str, [compiler, source, '--target', 'native', '--stdlib', root / 'stdlib',
                                    f'-O{level}', '-o', artifact]))
            result = subprocess.run(command, cwd=root, text=True, capture_output=True, timeout=30)
            row = dict(command=command, exit_code=result.returncode, stdout=result.stdout, stderr=result.stderr,
                       compiler_sha256=sha(compiler))
            report['commands'].append(row)
            assert result.returncode == 0 and artifact.is_file(), row
            artifacts.append(artifact)
        assert artifacts[0].read_bytes() == artifacts[1].read_bytes(), (level, artifacts)
        report['levels'].append(dict(level=level, byte_identical=True, c_sha256=sha(artifacts[0])))
    assert sha(source) == report['source_sha256']
    report['status'] = 'passed'
except BaseException as error:
    report.update(status='failed', error=repr(error))
    raise
finally:
    (out / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
