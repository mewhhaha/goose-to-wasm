from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import time

root = Path('/home/jacobt/src/goose-to-wasm')
work = root / 'build/completion-runs'
output = work / 'qualify57-prepare.json'
assert not output.exists()
proof = json.loads((work / 'c-only-bootstrap-57/report.json').read_text())
assert proof['status'] == 'passed' and proof['fixed_point']
assert json.loads((work / 'delivery-57-controls-ready.json').read_text())['status'] == 'passed'
assert proof['source_sha256']['codegen.goose'] == 'fbc56870acf7551a43797cb4605c9fe49b5d976f65ffed0a7b3c8a215531dbae'
report = dict(status='running', commands=[])

def save():
    output.write_text(json.dumps(report, indent=2) + '\n')

try:
    for label, command in [
        ('freeze-57', [sys.executable, work / 'durable-tools/freeze_seed.py', work / 'c-only-bootstrap-57', work / 'verified-seed-57']),
        ('prepare-57', [sys.executable, work / 'prepare_delivery_v3.py', '57']),
        ('reproduce-57', [sys.executable, work / 'reproduce_delivery_v4.py', '57']),
    ]:
        command = list(map(str, command))
        row = dict(command=command, cwd=str(root), log=str(work / (label + '.log')))
        report['commands'].append(row)
        save()
        started = time.monotonic()
        with (work / (label + '.log')).open('x') as log:
            result = subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT)
        row.update(exit_code=result.returncode, seconds=time.monotonic() - started)
        save()
        assert result.returncode == 0, row
    install = work / 'install-57/bin'
    install.mkdir(parents=True, exist_ok=False)
    shutil.copyfile(work / 'c-only-bootstrap-57/goose', install / 'goose')
    (install / 'goose').chmod(0o755)
    shutil.copytree(root / 'stdlib', install / 'stdlib')
    report.update(status='passed', compiler_sha256=hashlib.sha256((install / 'goose').read_bytes()).hexdigest(),
                  source_sha256=proof['source_sha256'], asset_sha256=proof['asset_sha256'])
except BaseException as error:
    report.update(status='failed', error=repr(error))
    raise
finally:
    save()
