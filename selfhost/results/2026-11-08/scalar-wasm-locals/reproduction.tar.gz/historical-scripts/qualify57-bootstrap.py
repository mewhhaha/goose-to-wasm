from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

root = Path('/home/jacobt/src/goose-to-wasm')
work = root / 'build/completion-runs'
output = work / 'qualify57-bootstrap.json'
assert not output.exists(), output
config = json.loads((work / 'delivery-57.json').read_text())
assert config['status'] == 'sealed-for-composition'
assert config['base_commit'] == '414540e0a8b83a9ab23d38ce30017ebf3fe9cdad'
assert config['patches'] == [{'path': 'resolver-scalars-57/combined.patch', 'sha256': '27cc1a9bd93f7b6094d591cc0f6e9c7326eda56430fea819823fff25d40291c2'}]
report = dict(status='running', commands=[], parent_source='snapshot-56', parent_seed='verified-seed-56', native_changes=[])

def save():
    output.write_text(json.dumps(report, indent=2) + '\n')

def run(label, command):
    log = work / (label + '.log')
    command = list(map(str, command))
    row = dict(command=command, cwd=str(root), log=str(log))
    report['commands'].append(row)
    save()
    started = time.monotonic()
    with log.open('x') as stream:
        result = subprocess.run(command, cwd=root, stdout=stream, stderr=subprocess.STDOUT)
    row.update(exit_code=result.returncode, seconds=time.monotonic() - started)
    save()
    assert result.returncode == 0, row

try:
    run('assemble-57', [sys.executable, work / 'assemble_delivery_v3.py', '57'])
    before = work / 'snapshot-56'
    after = work / 'snapshot-57'
    changed = []
    for source in sorted(before.rglob('*')):
        if source.is_file() and source.name != 'source-pins.json':
            relative = source.relative_to(before)
            if source.read_bytes() != (after / relative).read_bytes():
                changed.append(relative.as_posix())
    assert changed == ['selfhost/codegen.goose'], changed
    digest = hashlib.sha256((after / 'selfhost/codegen.goose').read_bytes()).hexdigest()
    assert digest == 'fbc56870acf7551a43797cb4605c9fe49b5d976f65ffed0a7b3c8a215531dbae', digest
    report.update(changed_sources=changed, codegen_sha256=digest)
    save()
    run('canonical-57', [sys.executable, root / 'selfhost/bootstrap.py',
        '--source-dir', after / 'selfhost', '--seed-dir', work / 'verified-seed-56',
        '--stdlib', root / 'stdlib', '--native-dir', after / 'native',
        '--output-dir', work / 'c-only-bootstrap-57', '--verify', '--cc', '/usr/bin/clang-23'])
    proof = json.loads((work / 'c-only-bootstrap-57/report.json').read_text())
    assert proof['status'] == 'passed' and proof['fixed_point']
    report.update(status='passed', executable_c_sha256=proof['executable_c_sha256'])
except BaseException as error:
    report.update(status='failed', error=repr(error))
    raise
finally:
    save()
