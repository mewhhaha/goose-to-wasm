from pathlib import Path
import hashlib,json,subprocess,sys
root=Path('/home/jacobt/src/goose-to-wasm');work=root/'build/completion-runs';version=int(sys.argv[1]);config=json.loads((work/f'delivery-{version}.json').read_text());parent=version-1
assert config['status']=='sealed-for-composition'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==config['base_commit']
proof=json.loads((work/config.get('parent_proof_dir',f'c-only-bootstrap-{parent}')/'report.json').read_text());base=work/config.get('parent_source_dir',f'snapshot-{parent}');out=work/f'snapshot-{version}';out.mkdir(exist_ok=False)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
pins={'selfhost/'+name:value for name,value in proof['source_sha256'].items()};pins.update(proof['asset_sha256'])
names=[name for name in subprocess.check_output(['git','ls-files','-z','selfhost','native'],cwd=root).decode().split('\0') if name and ((name.startswith('selfhost/') and name.count('/')==1 and name.endswith('.goose')) or name.startswith('native/'))]
for name in names:
 source=base/name
 if not source.is_file():
  data=subprocess.check_output(['git','show',config['base_commit']+':'+name],cwd=root)
 else:data=source.read_bytes()
 if name in pins:assert hashlib.sha256(data).hexdigest()==pins[name],name
 target=out/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
patches=[]
for item in config['patches']:
 path=work/item['path'];assert sha(path)==item['sha256'],path
 result=subprocess.run(['patch','--fuzz=0','-p1','-i',str(path)],cwd=out,text=True,capture_output=True);assert result.returncode==0,(result.stdout,result.stderr)
 patches.append(dict(**item,stdout=result.stdout,stderr=result.stderr))
assert not list(out.rglob('*.orig')) and not list(out.rglob('*.rej'))
final_names=[p.relative_to(out).as_posix() for p in out.rglob('*') if p.is_file() and '__pycache__' not in p.parts]
final={name:sha(out/name) for name in sorted(final_names)};(out/'source-pins.json').write_text(json.dumps(final,indent=2)+'\n')
(work/f'snapshot-{version}-assembly.json').write_text(json.dumps(dict(status='sealed private composition; canonical qualification pending',base_commit=config['base_commit'],patches=patches,sha256=final),indent=2)+'\n');print('Frozen',version,len(names),'tracked compiler/native files')
