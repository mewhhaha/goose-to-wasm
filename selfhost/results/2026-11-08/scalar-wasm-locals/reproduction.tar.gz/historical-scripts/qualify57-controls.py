"""Freeze predeclared guards, qualify baseline, then append without changing old cases."""
from pathlib import Path
import concurrent.futures
import copy
import hashlib
import json
import subprocess
import sys
import time

root = Path('/home/jacobt/src/goose-to-wasm')
work = root / 'build/completion-runs'
manifest_path = root / 'tests/conformance/cases.json'
resume = sys.argv[1:] == ['--admit-frozen-baseline']
assert not sys.argv[1:] or resume, sys.argv
baseline_bytes = subprocess.check_output(['git', 'show', 'HEAD:tests/conformance/cases.json'], cwd=root)
assert manifest_path.read_bytes() == baseline_bytes
base = json.loads(baseline_bytes)
assert sum(len(case['levels']) for case in base['cases']) == 7787
added, sources, origins = [], {}, {}
groups = [
    ('resolver-demand-57', 'controls/contracts.json', 'resolver-demand-57'),
    ('resolver-scalars-57', 'controls/contracts.json', 'resolver-scalars-57'),
    ('astra-resolver-57', 'valid-manifest.json', 'resolver-review-57'),
    ('astra-resolver-57', 'scalar-supplement-manifest.json', 'resolver-review-57'),
]
ids = {case['id'] for case in base['cases']}

def sha(data):
    return hashlib.sha256(data).hexdigest()

for component, name, prefix in groups:
    origin = work / component / name
    original = json.loads(origin.read_text())
    origins[str(origin.relative_to(root))] = sha(origin.read_bytes())
    contracts = original.get('cases')
    if contracts is None:
        contracts = []
        for label, contract in original.items():
            contract = dict(contract, id=label, source='controls/' + label + '.goose')
            if 'expected_stdout' not in contract:
                contract['expected_stdout'] = contract['stdout']
            contracts.append(contract)
    for contract in contracts:
        original_source = work / component / contract['source']
        data = original_source.read_bytes()
        assert sha(data) == contract['source_sha256'], original_source
        destination = root / 'tests/fixtures/contracts' / prefix / original_source.name
        destination.parent.mkdir(parents=True, exist_ok=True)
        if destination.exists():
            assert destination.read_bytes() == data, destination
        else:
            with destination.open('xb') as stream:
                stream.write(data)
        relative = destination.relative_to(root).as_posix()
        sources[relative] = sha(data)
        expected = dict(stdout=contract['expected_stdout'], exit=contract.get('expected_exit_code', 0))
        case = dict(id='corpus/contracts/' + prefix + '/' + contract['id'] + '/wasm-direct',
                    source=relative, phase='run', target='wasm-direct', levels=[0, 2], expect=expected,
                    provenance=dict(manifest=origin.relative_to(root).as_posix(), source_sha256=sha(data),
                                    expectations='Authored independently before candidate execution; baseline qualification required before admission.'))
        assert case['id'] not in ids, case['id']
        ids.add(case['id'])
        added.append(case)
        debug = copy.deepcopy(case)
        debug.update(id=case['id'] + '/debug', levels=[0], debug=True)
        if component == 'resolver-scalars-57' and contract['id'] in ('narrow', 'overflow'):
            # Both signed overflows occur before any print. Unsigned narrowing wraps.
            debug['expect'] = dict(stdout='', exit='nonzero', stderr_contains=['signed integer overflow'])
            debug['provenance']['debug_contract'] = 'Predeclared signed overflow guard; fail before output in checked O0.'
        assert debug['id'] not in ids, debug['id']
        ids.add(debug['id'])
        added.append(debug)

assert len(sources) == 28 and len(added) == 56
rows = sum(len(case['levels']) for case in added)
assert rows == 84
new = dict(base, cases=added)
frozen_path = work / 'qualify57-new-cases.json'
frozen_text = json.dumps(new, indent=2) + '\n'
if resume:
    assert frozen_path.read_text() == frozen_text
else:
    with frozen_path.open('x') as stream:
        stream.write(frozen_text)
seal = dict(status='frozen-before-baseline-execution', original_manifest_sha256=sha(baseline_bytes),
            original_cases=len(base['cases']), original_rows=7787, added_cases=len(added), added_rows=rows,
            new_manifest_sha256=sha(frozen_path.read_bytes()), origins=origins, sources=sources,
            expectation_policy='Original contract stdout remains unchanged; debug signed-overflow diagnostics are declared before baseline executes. No outputs are inferred from the candidate.')
seal_path = work / 'qualify57-controls-seal.json'
if resume:
    assert json.loads(seal_path.read_text()) == seal
else:
    with seal_path.open('x') as stream:
        stream.write(json.dumps(seal, indent=2) + '\n')

def run(engine):
    output = work / ('qualify57-baseline-' + engine)
    command = [sys.executable, root / 'tests/conformance.py', '--compiler', root / 'build/bin/goose',
               '--manifest', frozen_path, '--output-dir', output, '--engine', engine]
    if resume:
        report = json.loads((output / 'report.json').read_text())
        assert report['input_sha256'] == report['input_sha256_after']
        for name, digest in report['input_sha256'].items():
            assert sha(Path(name).read_bytes()) == digest, name
        receipt = dict(command=list(map(str, command)), exit_code=0, reused_unchanged_passed_report=True,
                       report=str(output / 'report.json'), summary=report.get('summary'))
    else:
        started = time.monotonic()
        with (work / ('qualify57-baseline-' + engine + '.log')).open('x') as stream:
            result = subprocess.run(list(map(str, command)), cwd=root, stdout=stream, stderr=subprocess.STDOUT)
        report = json.loads((output / 'report.json').read_text())
        receipt = dict(command=list(map(str, command)), exit_code=result.returncode,
                       seconds=time.monotonic() - started, report=str(output / 'report.json'), summary=report.get('summary'))
    assert receipt['exit_code'] == 0 and report['status'] == 'passed', receipt
    assert report['summary'] == dict(selected=rows, passed=rows, failed=0), receipt
    return engine, receipt

with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    baseline = dict(pool.map(run, ('wasmtime', 'v8')))
assert frozen_path.read_bytes() == (json.dumps(new, indent=2) + '\n').encode()
assert manifest_path.read_bytes() == baseline_bytes
for name, digest in sources.items():
    assert sha((root / name).read_bytes()) == digest
# Keep every byte of the old case objects and every expectation in place.
text = baseline_bytes.decode()
insertion = text.rfind('\n  ]')
assert insertion != -1 and text[insertion:].startswith('\n  ],\n  "legacy_math_capture":')
extra = '\n'.join('  ' + line for line in json.dumps(added, indent=2).splitlines()[1:-1])
final = text[:insertion] + ',\n' + extra + text[insertion:]
parsed = json.loads(final)
assert parsed['cases'][:len(base['cases'])] == base['cases']
assert parsed['cases'][len(base['cases']):] == added
manifest_path.write_text(final)
seal.update(status='passed', baseline=baseline, combined_manifest_sha256=sha(manifest_path.read_bytes()),
            combined_cases=len(parsed['cases']), combined_rows=7787 + rows)
seal_path.write_text(json.dumps(seal, indent=2) + '\n')
meta = dict(status='passed', cases=len(added), rows=rows, sources=sources,
            baseline_rows_per_engine=rows, original_rows=7787, total_rows=7787 + rows,
            new_manifest_sha256=sha(frozen_path.read_bytes()), combined_manifest_sha256=sha(manifest_path.read_bytes()))
(work / 'new-controls-57.json').write_text(json.dumps(meta, indent=2) + '\n')
(work / 'delivery-57-controls-ready.json').write_text(json.dumps(dict(status='passed', scope='All84 predeclared new rows passed baseline Wasmtime and V8 before appending; all original7787 row expectations preserved.'), indent=2) + '\n')
print(json.dumps(meta, indent=2), flush=True)
