# Independent resolver guards

Eight valid sources passed the frozen handwritten stdout contracts under baseline Goose snapshot 56: debug (`-O0 --debug`), O0, O2, each on V8 and Wasmtime (48 executions). `baseline-summary.json` verifies exact case/profile/engine coverage against `valid-manifest.json`; raw receipts are `baseline.json` and `baseline-supplement.json`. No C++ oracle was used.

Expected output and source hashes were recorded before each source's first execution. The first authored draft called output-producing formatting `format` rather than `str`; that spelling was corrected from checker source before any execution, with the original preserved. Two subsequently baseline-rejected controls remain unchanged in `manifest.json`: alias use after a shrink-capable resize, and direct indexing of variable-width arrays. They are not runtime coverage. Their valid alternatives have separately authored contracts in `supplemental-manifest.json`.

To execute the valid controls with a candidate, from repository root:

```sh
source build/performance-env.sh
python build/completion-runs/astra-resolver-57/check.py PATH_TO_CANDIDATE candidate valid-manifest.json
```

The fixed scalar table should omit the resolver with candidate 57; all seven other valid guards conservatively retain it. Every growth guard includes a reusable pool to force the legacy forwarding path. Baseline globals are eight for the fixed table/scalar-reference cases and nine for the pool cases. Guards cover old slices and references across push/append, independent resize, variable-width growth, global initialization, field and parameter defaults, temporary `str`/`to_bytes`, formatting append, and nested owner captures.

The private narrow compiler proof in `resolver-demand-57/selfhost/codegen.goose` has no source-review blocker: every current forwarding publisher requires a growable owner, while the proof admits only scalar and fixed scalar-array values. It preserves the old grow-type and region gates and does not activate the separate scalar frame-free backend. Full compiler fixed point and conformance qualification remain separate requirements.

The scalar follow-up adds `scalar-supplement-manifest.json`: one nonlocal-return/captured-mutation source at O2 on both engines. Baseline passed both checks; combined independent execution coverage is 50 checks/compiler. `scalar-review.md` records the source review and exact candidate hash.
