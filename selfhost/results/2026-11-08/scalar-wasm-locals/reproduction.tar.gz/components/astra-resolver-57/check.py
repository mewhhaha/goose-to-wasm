#!/usr/bin/env python3
"""Run the already-frozen independent resolver contracts; never infer expectations."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
MANIFEST = HERE / 'manifest.json'
if len(sys.argv) > 3:
    MANIFEST = HERE / sys.argv[3]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def run(command, stdin=''):
    started = time.monotonic()
    try:
        result = subprocess.run(command, cwd=ROOT, input=stdin, text=True, capture_output=True, timeout=20)
        return dict(command=command, returncode=result.returncode, stdout=result.stdout, stderr=result.stderr,
                    wall_seconds=time.monotonic()-started)
    except subprocess.TimeoutExpired:
        return dict(command=command, returncode=None, stdout='', stderr='timeout after 20 seconds', wall_seconds=time.monotonic()-started)

def globals_count(data):
    position = 8
    def leb():
        nonlocal position
        value = shift = 0
        while True:
            byte = data[position]; position += 1
            value |= (byte & 127) << shift
            if byte < 128:
                return value
            shift += 7
    while position < len(data):
        section = data[position]; position += 1
        length = leb(); end = position + length
        if section == 6:
            return leb()
        position = end
    return 0

compiler = Path(sys.argv[1]).resolve()
label = sys.argv[2]
manifest = json.loads(MANIFEST.read_text())
report = dict(schema='goose-resolver-independent-run-v1', compiler=str(compiler), compiler_sha256=sha(compiler),
              manifest_sha256=sha(MANIFEST), host_sources={str(path.relative_to(ROOT)):sha(path) for path in
              [ROOT/'scripts/run_wasm.mjs', ROOT/'scripts/run_wasmtime.py']}, rows=[])
output = HERE / f'{label}.json'
for case in manifest['cases']:
    source = HERE / case['source']
    if sha(source) != case['source_sha256']:
        raise SystemExit(f'source changed: {source}')
    for profile in manifest['profiles']:
        directory = HERE/'artifacts'/label/case['id']/profile['name']; directory.mkdir(parents=True, exist_ok=True)
        wasm = directory/'program.wasm'
        compile_result = run([str(compiler), str(source), '--stdlib', str(ROOT/'stdlib'), '--target', 'wasm-direct',
                              *profile['flags'], '-o', str(wasm)])
        common = dict(case=case['id'], profile=profile['name'], compile=compile_result, source_sha256=sha(source))
        if compile_result['returncode'] == 0:
            common.update(wasm_sha256=sha(wasm), wasm_bytes=wasm.stat().st_size, globals_count=globals_count(wasm.read_bytes()))
        for engine in manifest['engines']:
            row = dict(common, engine=engine, passed=False)
            if compile_result['returncode'] == 0:
                command = ['node', str(ROOT/'scripts/run_wasm.mjs'), str(wasm)]
                if engine == 'wasmtime':
                    command = [sys.executable, str(ROOT/'scripts/run_wasmtime.py'), str(wasm)]
                row['execution'] = run(command, case['stdin'])
                result = row['execution']
                row['passed'] = result['returncode'] == case['expected_exit_code'] and result['stdout'] == case['expected_stdout'] and not result['stderr']
            report['rows'].append(row)
        output.write_text(json.dumps(report, indent=2)+'\n')
report['passed'] = sum(row['passed'] for row in report['rows'])
report['total'] = len(report['rows'])
report['complete'] = report['passed'] == manifest['checks_per_compiler'] == report['total']
output.write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps({key:report[key] for key in ['passed','total','complete']}))
for row in report['rows']:
    if not row['passed']:
        print(row['case'], row['profile'], row['engine'], row.get('execution', row['compile']))
raise SystemExit(0 if report['complete'] else 1)
