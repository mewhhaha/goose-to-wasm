# Resolver demand hill 57

Baseline: frozen snapshot 56. Workload bench/langbench/mandelbrot.goose unchanged.
Candidate proof: omit forwarding resolver only when every emitted value type is scalar or a fixed array of scalar elements. Reject refs, slices, records, tuples, enums, owners, reusable pools, closures and dynamic calls. Traverse complete emitted function nodes including parameters/defaults, every emitted global initializer, and reachable non-function symbols. Static function/builtin names are code references, not runtime compound values.

Publication audit: cg_forward_span has only two callers, cg_array_reserve and cg_varint_array_builtin. Reserve publishes only for grow/growshrink arrays; varint builtin requires A_GROW. Neither can arise in the accepted type subset. Fixed scalar arrays are needed for imported std::parse_flt_pow10.

Frozen control contracts (source authored before first candidate build):
- scalar-import: std import plus scalar helper call prints 42.
- fixed-array: fixed scalar array lookup prints 42.
- forwarded-view: retained slice before owner growth must print 7, 9, 257.
- capture-growth: closure grows captured array; retained slice prints 7, resulting count prints 257.
- default-growth: scalar default expression grows a global array; print 257, 7.
- aggregate-temp: discarded aggregate containing owner must preserve side effect print 7.

No official 35-second workload runs before pre-review and code gates.

Control syntax correction before candidate exists: storing function values is forbidden. capture-growth now calls nested capturing grow directly; expected output unchanged. Rejected source preserved as capture-growth.rejected-source.txt.

Additional pre-candidate contract: pool-forwarded-view forces general forwarding using reusable alloc_index, then retains slice through growth. Expected 0,7,9,257. Existing forwarding controls may select regions; this specifically tests fallback.

## Outcome

Candidate native C bootstrap used installed snapshot56 compiler, no C++ compiler oracle. Native C emission 55.613 s, Clang -std=gnu11 -O2 31.180 s; generated C has four preexisting tautological slice warnings. /usr/bin/time is unavailable; first timing invocation failed before compiler launch, then Python monotonic timing used.

Mandelbrot original source unchanged: baseline Wasm 4341 bytes sha256 b2338da428272b85fc4425bc24b9a0e80976530c25e8281fe85d53c49070fb76 (8 globals,8 defined funcs); candidate 3924 bytes sha256 c2bf955675c107ed07fed2d981c4aa8e6c517bb0cbbe79bfd826b5d9a8b0198a (5 globals,7 defined funcs). Resolver helper and forwarding globals omitted. Five compound/fallback control modules are byte-identical, including reusable pool + retained slice forwarding; scalar/fixed control modules change. 28/28 source-authored contract executions pass (two compilers, two engines), plus 8x25 Mandelbrot checksum636 on both compilers/engines.

Exploratory 512x500x1 pilot: exact source, CPU7, resident/prepared modules, one warmup plus four alternating paired samples; checksum33209574 everywhere. V8 median1492.5084 ms baseline vs217.320626 ms candidate, ratio0.14560764. Wasmtime median1383.1512265 ms baseline vs220.178438 ms candidate, ratio0.15918609. pilot.json preserves all observations. This pilot is not the official full-size measurement. Root owns full qualification and publication.

## Alternatives and limits

Rejected before implementation: blanket scalar-only proof would retain the resolver because imported std contributes fixed scalar parse_flt_pow10 global. Narrow proof admits fixed arrays whose elements pass existing cg_scalar_type and rejects every other compound type.

Not implemented: operation-only builtin demand scanner (format1/2,bytes16/17,mutation23..29,pools30..32). It could admit a broader useful set, but the narrow type proof gives an explicit no-forwarding subset without maintaining builtin coverage. Record defaults are cloned into constructor bindings by checker, so a later scanner can cover them if desired.

Tradeoff: harmless references, slices, aggregates, closures, encoded/indexed scalars, and owner programs deliberately keep existing resolver decision. No per-function resolver elimination, array fastpath, scalar local promotion, semantics changes, source workload edits, or benchmark harness changes.
