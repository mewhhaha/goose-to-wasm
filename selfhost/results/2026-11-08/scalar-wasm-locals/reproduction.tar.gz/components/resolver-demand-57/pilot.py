from pathlib import Path
import sys,os,json,statistics,hashlib,time
ROOT=Path.cwd();sys.path.insert(0,str(ROOT/'bench'));import langbench_hot as hot
b=ROOT/'build/completion-runs/resolver-demand-57';os.sched_setaffinity(0,{7})
input_text='512 500 1\n';rows=[]
for engine in ('node','wasmtime'):
    prepared={};workers={};data={}
    for tag in ('baseline','candidate'):
        artifact=b/f'mandelbrot.{tag}.wasm';data[tag]=artifact.read_bytes()
        if engine=='node':workers[tag]=hot.V8Worker(artifact,hashlib.sha256(data[tag]).hexdigest(),7,timeout=30)
        else:prepared[tag]=hot.host.prepare_module(data[tag],b/f'mandelbrot.{tag}.pilot.cwasm')
    for sample in range(-1,4):
        order=('baseline','candidate')
        if sample%2==0:order=('candidate','baseline')
        for tag in order:
            t=time.monotonic()
            if engine=='node':r=workers[tag].run(input_text);stdout=r['stdout'];code=r['exit_code']
            else:r=hot.host.run_module(data[tag],input_text,prepared=prepared[tag],timing=False);stdout=r['stdout'].decode();code=r['exit_code']
            tokens=stdout.split();assert code==0 and len(tokens)==2,(r,stdout)
            rows.append(dict(engine=engine,tag=tag,sample=sample,warmup=sample<0,checksum=tokens[0],kernel_ns=int(tokens[1]),wall_seconds=time.monotonic()-t))
    for worker in workers.values():worker.close()
assert len({x['checksum'] for x in rows})==1,rows
summary={}
for engine in ('node','wasmtime'):
    med={tag:statistics.median(x['kernel_ns'] for x in rows if x['engine']==engine and x['tag']==tag and not x['warmup']) for tag in ('baseline','candidate')}
    summary[engine]=dict(baseline_ms=med['baseline']/1e6,candidate_ms=med['candidate']/1e6,ratio=med['candidate']/med['baseline'])
r=dict(scope='Exploratory pilot only, unchanged Mandelbrot source, smaller runtime inputs; CPU7; prepared module execution; one warmup+four ABBA samples; no full official workload',input=[512,500,1],checksum=rows[0]['checksum'],rows=rows,summary=summary)
(b/'pilot.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(summary,indent=2));print('checksum',r['checksum'])
