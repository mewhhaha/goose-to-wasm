from pathlib import Path
p=Path('build/completion-runs/resolver-scalars-57/selfhost/codegen.goose');s=p.read_text()
s=s.replace('scalar: bool = false, resolver:', 'scalar: bool = false, scalar_slots: bool = false, resolver:')
s=s.replace('struct CgBody {','struct CgSlot { local: i64 = -1, value: bool = false }\nstruct CgBody {')
s=s.replace('slots: i64[>..]&','slots: CgSlot[>..]&',1)
s=s.replace('var slots: i64[>..] = [];','var slots: CgSlot[>..] = [];')
# Every prior access represents the storage local, except the new value flag.
import re
s=re.sub(r'f\.slots\[([^\]]+)\]',r'f.slots[\1].local',s)
s=s.replace('f.slots.push(-1);','f.slots.push(CgSlot {});')
s=s.replace('    cg_get(f, f.slots[symbol].local);\n}\nfn cg_field_place', '    if f.slots[symbol].value { cg_fail(p, node, "wasm: scalar local unexpectedly requires an address"); return; }\n    cg_get(f, f.slots[symbol].local);\n}\nfn cg_field_place')
# Read promoted values through the two name read paths.
s=s.replace('        cg_symbol_address(p, m, f, n.symbol, node);\n        let stored', '        if n.symbol >= 0 && n.symbol < f.slots.len && f.slots[n.symbol].value { cg_get(f, f.slots[n.symbol].local); return; }\n        cg_symbol_address(p, m, f, n.symbol, node);\n        let stored',1)
s=s.replace('        let stored = p.symbols[n.symbol].type_id;\n        cg_symbol_address(p, m, f, n.symbol, item.node);', '        let stored = p.symbols[n.symbol].type_id;\n        if !item.address && f.slots[n.symbol].value { cg_get(f, f.slots[n.symbol].local); cg_convert(p, m, f, stored, n.type_id, item.node); return; }\n        cg_symbol_address(p, m, f, n.symbol, item.node);',1)
# Keep the same frame allocation even for promoted bindings.
old='''            f.slots[i].local = cg_local(f, 0x7f); f.offsets[i] = cg_frame(f, size, p.types[symbol.type_id].align);'''
new='''            var value = false;
            if m.scalar_slots && function >= 0 && symbol.node >= 0 && cg_scalar_slot_type(p, symbol.type_id) {
                let binding = p.nodes[symbol.node];
                value = binding.kind == N_PARAM || binding.kind == N_VARIABLE && binding.first < 0 && !cg_decl_diverges(p, symbol.node);
                for capture in m.captures { if capture.symbol == i { value = false; } }
            }
            var wasm_type = 0x7f; if value { wasm_type = cg_wasm_type(p, symbol.type_id); }
            f.slots[i] = CgSlot { local: cg_local(f, wasm_type), value: value }; f.offsets[i] = cg_frame(f, size, p.types[symbol.type_id].align);'''
assert old in s;s=s.replace(old,new)
s=s.replace('if offset >= 0 { cg_frame_address(f, offset); cg_set(f, f.slots[symbol].local); }','if offset >= 0 && !f.slots[symbol].value { cg_frame_address(f, offset); cg_set(f, f.slots[symbol].local); }')
s=s.replace('''        if m.regions_enabled && cg_region_value(p, id) { cg_get(f, f.slots[symbol].local);''','''        if f.slots[symbol].value { cg_get(f, index); cg_scalar_slot_store(p, f, symbol); }
        else if m.regions_enabled && cg_region_value(p, id) { cg_get(f, f.slots[symbol].local);''',1)
# Simple declarations only are eligible.
old='''    cg_symbol_address(p, m, f, symbol, node); let address = cg_save(f, 0x7f);
    if n.right < 0 { cg_default_storage(p, m, f, n.type_id, address, node); return; }
    cg_to(p, m, f, n.right, n.type_id); cg_write_value(p, m, f, n.type_id, address, node);'''
new='''    if symbol < f.slots.len && f.slots[symbol].value {
        if n.right < 0 { cg_zero(f.code, cg_wasm_type(p, n.type_id)); } else { cg_to(p, m, f, n.right, n.type_id); }
        cg_scalar_slot_store(p, f, symbol); return;
    }
'''+old
assert old in s;s=s.replace(old,new,1)
# Share all numeric/checked-overflow emission between address and value assignments.
old='''    if cg_type_kind(p, id) == TY_REF && n.integer != T_DOTASSIGN { cg_expr(p, m, f, n.left); id = p.types[id].element; }
    else { cg_address(p, m, f, n.left); }
    let address = cg_save(f, 0x7f);'''
new='''    var symbol = -1;
    if p.nodes[n.left].kind == N_NAME { symbol = p.nodes[n.left].symbol; }
    var value = false; if symbol >= 0 && symbol < f.slots.len { value = f.slots[symbol].value; }
    var address = -1;
    if !value {
        if cg_type_kind(p, id) == TY_REF && n.integer != T_DOTASSIGN { cg_expr(p, m, f, n.left); id = p.types[id].element; }
        else { cg_address(p, m, f, n.left); }
        address = cg_save(f, 0x7f);
    }'''
assert old in s;s=s.replace(old,new,1)
s=s.replace('''        cg_get(f, address); cg_load(p, m, f, id, 0);
        if n.integer == T_INC''','''        if value { cg_get(f, f.slots[symbol].local); } else { cg_get(f, address); cg_load(p, m, f, id, 0); }
        if n.integer == T_INC''',1)
s=s.replace('''    cg_write_value(p, m, f, id, address, node);
}
fn cg_mark_publications''','''    if value { cg_scalar_slot_store(p, f, symbol); } else { cg_write_value(p, m, f, id, address, node); }
}
fn cg_mark_publications''',1)
# Explicit narrow selection avoids any store/load truncation changes. Bool stores retain their old low byte.
loc='fn cg_body_tables(p: Program&, f: CgBody&) {'
new='''fn cg_scalar_slot_type(p: Program&, id: i64) -> bool {
    if !cg_scalar_type(p, id) { return false; }
    let kind = cg_type_kind(p, id);
    return kind == TY_BOOL || kind == TY_FLOAT || kind == TY_INT && (p.types[id].count == 32 || p.types[id].count == 64);
}
fn cg_scalar_slot_store(p: Program&, f: CgBody&, symbol: i64) {
    if cg_type_kind(p, p.symbols[symbol].type_id) == TY_BOOL { wb_i32(f.code, 255); wb_byte(f.code, 0x71); }
    cg_set(f, f.slots[symbol].local);
}
'''
assert loc in s;s=s.replace(loc,new+loc)
s=s.replace('''    if grows && !m.regions_enabled && !cg_unforwarded_module(p, m) {''','''    m.scalar_slots = cg_unforwarded_module(p, m);
    if grows && !m.regions_enabled && !m.scalar_slots {''',1)
p.write_text(s)
