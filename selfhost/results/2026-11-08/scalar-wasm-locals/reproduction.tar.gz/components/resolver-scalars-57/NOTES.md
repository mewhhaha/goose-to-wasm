# Scalar slots candidate57

Resolver-only tree remains untouched and sealed by resolver-only-seal.json. Candidate copied first hill sources/native.

Plan: explicit CgSlot { local, value }. Promote only ordinary one-binding N_VARIABLE locals and N_PARAM full-width bool/i32/u32/i64/u64/f32/f64 under accepted module no-forwarding proof; any symbol listed in m.captures keeps memory storage. Fixed arrays/globals, all other bindings, and all fallback modules retain memory. Source-authored expected contracts frozen above before compilation. Test all at O0/O2 and debug; narrow overflow uses expected debug trap rather than wrapped stdout.

Astra review follow-up, added while candidate C emission is in progress and before candidate executable exists: nonlocal-capture freezes expected 2,5,42, combining promoted unrelated scalar with addressable capture mutation and nonlocal effect result. Expected authored before baseline execution.

## Implementation and proof

Explicit CgSlot distinguishes a typed value local from an address local. cg_symbol_address diagnoses unexpected promoted-slot address demand. Ordinary single N_VARIABLE and N_PARAM only; N_BINDING, loops/destructuring/match binders remain memory, as do globals/fixed arrays/every symbol present in m.captures. The cached module proof rejects refs, slices, aggregates, closure values, dynamic calls, indexed/encoded scalars and reusable pools. Scalar captures may coexist but remain memory-backed.

All original frame allocations/offsets/reservations and effect mailboxes retained, including holes for promoted values; parameter initialization stores into typed local instead of memory. BOOL writes mask255 to preserve prior store8/load8_u semantics even for noncanonical foreign ABI bool inputs. Typed f32 local writes naturally preserve f32 rounding; cg_to/cg_numeric unchanged for conversions and checked arithmetic. Narrow i8/i16 remain unpromoted. No frame size/resource-contract optimization attempted.

## Validation

Native C build succeeded: emission48.4738s;ClangO2 30.1977s. 144/144 independently authored source control executions pass (12cases×O0/O2/debug×baseline/candidate×V8/Wasmtime). Debug narrow/overflow contracts trap with the same signed overflow text; other outputs match frozen expected values. Includes fixed array assignment, byref fallback, direct nested captures, captured params, nonlocal captured mutation with unrelated scalar promotion, full-width wrap/f32/bool/for bindings. Baseline8x25 smoke checksums636 match candidate and resolver-only.

Mandelbrot bytes4341→3924→2796 (baseline/resolver/combined), global counts8→5→5, defined functions8→7→7. Wholemodule WAT memory load/store mentions160→155→33. Frame reservation constants remain128,200,200 for all three variants. Combined Wasm sha256cd7e4ff2aed97d25f32b12989ff015a375eedb9b2ec9dadc46d582d4f320986c.

Exploratory512x500 pilot only, CPU7 prepared/resident modules, one warmup+four ABBA observations: checksum33209574. Resolver-only→combined V8 median207.743213→81.132646ms ratio0.39054294; Wasmtime205.8517575→82.4684355ms ratio0.40062051. This is a distinct later measurement from the first pilot; do not combine medians across windows as a matched claim. Raw rows/commands in pilot.py and pilot.json. Full-size qualification, docs, evidence publication and remote delivery root-owned.

Astra reviewed actual combined source hashfbc56870…531dbae: no blocker. Independent source supplement/guards live in astra-resolver-57 and are root-owned for candidate execution. Resolver-only existing files match every SHA in resolver-only-seal.json after this work.
