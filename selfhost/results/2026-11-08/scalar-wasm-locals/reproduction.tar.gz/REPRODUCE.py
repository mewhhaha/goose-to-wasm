#!/usr/bin/env python3
"""Portable source-only reproduction entry point, copied to the capsule root."""
from pathlib import Path
import argparse
import collections
import gzip
import hashlib
import json
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent


def read(path):
    if path.suffix == '.gz':
        return json.loads(gzip.decompress(path.read_bytes()))
    return json.loads(path.read_text())


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def verify():
    manifest = read(HERE / 'capsule-manifest.json')
    for name, record in manifest['files'].items():
        path = HERE / name
        if not path.is_file() or sha(path) != record['sha256']:
            raise RuntimeError('Capsule input changed: ' + name)
    if manifest['snapshot'] != 57:
        raise RuntimeError('Wrong snapshot')
    return manifest


def compose(output):
    shutil.copytree(HERE / 'parent-source', output)
    patch = HERE / 'components/resolver-scalars-57/combined.patch'
    subprocess.run(['patch', '--fuzz=0', '-p1', '-i', str(patch)], cwd=output, check=True)
    pins = read(HERE / 'source/source-pins.json')
    for name, expected in pins.items():
        if sha(output / name) != expected:
            raise RuntimeError('Composition differs from qualified source: ' + name)
    shutil.copyfile(HERE / 'source/source-pins.json', output / 'source-pins.json')
    print('Parent source plus sealed patch reproduces all snapshot57 compiler/native inputs.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='action', required=True)
    commands.add_parser('verify')
    composing = commands.add_parser('compose')
    composing.add_argument('--output-dir', type=Path, default=HERE / 'composed-57')
    boot = commands.add_parser('bootstrap')
    boot.add_argument('--output-dir', type=Path, default=HERE / 'built-57')
    boot.add_argument('--cc', default='clang')
    checks = commands.add_parser('contracts')
    checks.add_argument('--compiler', type=Path, default=HERE / 'built-57/goose')
    checks.add_argument('--output-dir', type=Path)
    checks.add_argument('--engine', choices=('wasmtime', 'v8'), default='wasmtime')
    checks.add_argument('--cc', default='gcc')
    checks.add_argument('--timeout', type=float, default=15)
    args = parser.parse_args()
    verify()
    if args.action == 'verify':
        print('All archived inputs match their recorded hashes.')
        return 0
    if args.action == 'compose':
        compose(args.output_dir.resolve())
        return 0
    source = HERE / 'source'
    if args.action == 'bootstrap':
        command = [sys.executable, source / 'selfhost/bootstrap.py', '--source-dir', source / 'selfhost',
                   '--seed-dir', HERE / 'parent-seed', '--stdlib', source / 'stdlib',
                   '--native-dir', source / 'native', '--output-dir', args.output_dir.resolve(),
                   '--cc', args.cc, '--verify']
        return subprocess.run(list(map(str, command)), cwd=source).returncode
    output = args.output_dir
    if output is None:
        output = HERE / ('contracts-' + args.engine)
    output = output.resolve()
    if args.engine == 'wasmtime':
        import wasmtime
    if args.engine == 'v8' and shutil.which('node') is None:
        raise RuntimeError('Node is required for the V8 contract run')
    command = [sys.executable, source / 'tests/conformance.py', '--compiler', args.compiler.resolve(),
               '--stdlib', source / 'stdlib', '--manifest', source / 'tests/conformance/cases.json',
               '--output-dir', output, '--cc', args.cc, '--engine', args.engine, '--timeout', str(args.timeout)]
    if args.engine == 'v8':
        command += ['--filter', 'corpus/']
    result = subprocess.run(list(map(str, command)), cwd=source)
    if result.returncode not in (0, 1):
        return result.returncode
    current = read(output / 'report.json')
    if 'error' in current or current['input_sha256'] != current['input_sha256_after']:
        raise RuntimeError('Contract execution did not complete with stable inputs')
    manifest = read(source / 'tests/conformance/cases.json')
    selected = manifest['cases']
    if args.engine == 'v8':
        selected = [case for case in selected if 'corpus/' in case['id']]
    expected = collections.Counter((case['id'], level) for case in selected for level in case['levels'])
    actual = collections.Counter((row['case'], row['level']) for row in current['results'])
    if expected != actual:
        raise RuntimeError('A case or optimization level was omitted or duplicated')
    parent = read(HERE / 'qualification/parent-conformance.json.gz')
    old = {(row['case'], row['level']): row for row in parent['results']}
    if args.engine == 'v8':
        old = {key: row for key, row in old.items() if 'corpus/' in row['case']}
    new = {(row['case'], row['level']): row for row in current['results']}
    regressions = [new[key] for key in old.keys() & new.keys()
                   if old[key]['status'] == 'pass' and new[key]['status'] != 'pass']
    failures = [new[key] for key in new.keys() - old.keys() if new[key]['status'] != 'pass']
    removed = sorted(old.keys() - new.keys())
    passed = not regressions and not failures and not removed
    receipt = dict(status='failed', summary=current['summary'], inherited_gaps=current['summary']['failed'],
                   shared_regressions=regressions, new_failures=failures, removed_rows=removed,
                   note='The full runner reports all inherited gaps; this separate comparison requires every new row and every previously passing row to pass.')
    if passed:
        receipt['status'] = 'passed'
    (output / 'parent-comparison.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({key: receipt[key] for key in ('status', 'summary', 'inherited_gaps')}, indent=2))
    return int(not passed)


if __name__ == '__main__':
    raise SystemExit(main())
