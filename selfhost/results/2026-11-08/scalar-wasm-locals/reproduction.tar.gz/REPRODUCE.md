# Snapshot57 source and qualification

Run `python REPRODUCE.py verify`, then `python REPRODUCE.py compose`. Run `python REPRODUCE.py bootstrap --cc clang` to build from the verified snapshot56 C seed and require a C fixed point. This requires Python, a C compiler, libc/libm/libdl/pthreads; no C++ reference compiler is used.

For runtime contracts install `source/requirements.txt` (Wasmtime 50.0.1); V8 additionally needs Node. Run `python REPRODUCE.py contracts --engine wasmtime` and `python REPRODUCE.py contracts --engine v8`. The full runner retains 100 inherited gaps. The separate parent comparison requires every new and previously passing row to pass. Use `--timeout` when reproducing on a slower host; it is recorded by the runner.

Source hashes are portable. Generated C and executable hashes depend on source paths and toolchain; the recorded same-path cross-emission proves the delivered public compiler reproduces canonical C. Historical helper scripts preserve exact commands and absolute paths as evidence; use REPRODUCE.py outside the original checkout.

Intermediate resolver-only/scalar pilots, rejected authoring drafts, source patches and qualification corrections remain under components/ and qualification/. They are exploratory evidence, not additional accepted changes or timing claims. Only the combined patch changes codegen.goose; all native inputs remain unchanged.
