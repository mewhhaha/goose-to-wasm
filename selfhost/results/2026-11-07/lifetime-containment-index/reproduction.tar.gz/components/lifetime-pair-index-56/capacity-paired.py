from pathlib import Path
import hashlib,json,subprocess,time
root=Path('/home/jacobt/src/goose-to-wasm');w=root/'build/completion-runs/lifetime-pair-index-56';out=w/'capacity-paired';out.mkdir();source=w/'controls/capacity.goose';base=root/'build/completion-runs/c-only-bootstrap-55/goose';candidate=w/'build/goose';rows=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(cmd):
 cmd=list(map(str,cmd));r=subprocess.run(cmd,cwd=root,capture_output=True,timeout=30);return dict(command=cmd,exit_code=r.returncode,stdout=r.stdout.decode(),stderr=r.stderr.decode())
for budget in ('default','64MiB'):
 for target in ('wasm-direct','native'):
  if budget=='default' and target=='native':continue
  for level in (0,2):
   pair=[]
   for label,compiler in [('baseline55',base),('indexed56',candidate)]:
    artifact=out/(label+'-'+budget+'-'+target+'-'+str(level)+('.c' if target=='native' else '.wasm'));cmd=[compiler,source,'--stdlib',root/'stdlib','--target',target,'--standalone','-O'+str(level),'-o',artifact]
    if budget=='64MiB' and target=='wasm-direct':cmd+=['--wasm-initial-pages','1024','--wasm-max-pages','1024']
    compiled=run(cmd);assert compiled['exit_code']==0,compiled
    runner=[root/'build/bin/goose-wasmtime','--no-cache',artifact]
    if target=='native':
     binary=artifact.with_suffix('.bin');cc=run(['clang','-std=gnu11','-O'+str(level),artifact,'-lm','-ldl','-pthread','-o',binary]);assert cc['exit_code']==0,cc;runner=[binary]
    observed=run(runner);row=dict(compiler=label,source_sha256=sha(source),budget=budget,target=target,level=level,compile=compiled,artifact_sha256=sha(artifact),runtime=observed)
    if budget=='default':assert observed['exit_code']!=0 and 'data region exhausted' in observed['stderr']
    else:assert observed['exit_code']==0 and observed['stdout']=='2 16384 131072\n'
    pair.append(row);rows.append(row)
   assert pair[0]['artifact_sha256']==pair[1]['artifact_sha256'];assert all(pair[0]['runtime'][k]==pair[1]['runtime'][k] for k in ('exit_code','stdout','stderr'))
   (w/'capacity-paired-report.json').write_text(json.dumps(dict(method='Same frozen oversized Type graph and identical memory options across canonical55/indexed56. Default-budget rejection retained;64MiB is only the capacity control budget, not a production retention/memory improvement claim.',rows=rows),indent=2)+'\n')
print('paired rows',len(rows),flush=True)
