from pathlib import Path
import hashlib,json,shutil
root=Path('/home/jacobt/src/goose-to-wasm');w=root/'build/completion-runs/lifetime-pair-index-56'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
# Fixed ordinary benchmark closure, frozen before compiler execution on it.
shutil.copytree(root/'build/completion-runs/bench-snapshot-55/examples',w/'inputs/examples')
m=json.loads((root/'tests/conformance/cases.json').read_text());catalog=json.loads((w/'inputs/examples/manifest.json').read_text());cases=[]
for c in catalog['examples']:
 for target in ('native','wasm-direct'):
  cases.append(dict(id='examples/'+c['name']+'/'+target,source=str((w/'inputs/examples'/c['file']).relative_to(root)),phase='run',target=target,levels=[0,2],expect=dict(stdout_file=str((w/'inputs/examples'/c['expected']).relative_to(root)),exit=0),provenance='existing canonical55 ten-example source/output contract frozen unchanged'))
assert len(catalog['examples'])==10
(w/'examples-manifest.json').write_text(json.dumps(dict(schema=m['schema'],upstream=m['upstream'],cases=cases),indent=2)+'\n')
# Add counters only to exact-function private direct controls, never production source.
for label in ('baseline','candidate'):
 p=w/'controls'/(label+'-direct.goose');s=p.read_text().replace('pair_heads: i64[>..]& }','pair_heads: i64[>..]&, probes: i64 = 0, misses: i64 = 0 }')
 if label=='baseline':s=s.replace('for q in l.pairs { if q.owner','for q in l.pairs { l.probes += 1; if q.owner')
 else:s=s.replace('        let q = l.pairs[pair];','        l.probes += 1; let q = l.pairs[pair];')
 s=s.replace('    var work: i64[>..] = [owner];','    l.misses += 1; var work: i64[>..] = [owner];')
 s=s.rstrip()[:-1]+'    print("METRICS ", l.probes, " ", l.misses, " ", l.pairs.len, " ", l.pair_heads.len);\n}\n'
 (w/'controls'/(label+'-instrumented.goose')).write_text(s)
# Exact candidate functions, separate maximum-bucket/growing-type graph.
s=(w/'controls/candidate-direct.goose').read_text();s=s[:s.index('fn query(')]
s+='''fn main() {
    var types: Type[>..] = []; for i in 0..20000 { types.push(Type { kind: TY_INT, count: 64 }); }
    var nodes: Node[>..] = []; var p = Program { types: types, nodes: nodes };
    var pairs: LifePair[>..] = []; var heads: i64[>..] = []; var l = Lifetimes { pairs: pairs, pair_heads: heads };
    assert(life_contains(p, l, 0, 0)); assert(heads.len == 16384);
    for i in 20000..40000 { p.types.push(Type { kind: TY_INT, count: 64 }); }
    assert(life_contains(p, l, 39999, 0)); assert(heads.len == 16384);
    print(l.pairs.len, " ", l.pair_heads.len, " ", l.pair_heads.len * 8);
}
'''
(w/'controls/capacity.goose').write_text(s)
(w/'probe-expected-before-execution.json').write_text(json.dumps(dict(method='Private derived exact-function counters only; not part of compiler candidate and not used for timing comparisons.',instrumented_prefix='expected-before-execution.json direct_expected stdout',misses_each=13,pairs_each=13,baseline_probes_min=6000,candidate_probes_max=3000,candidate_bucket_count=16,capacity_stdout='2 16384 131072\n',capacity_exit=0,source_sha256={p.name:sha(p) for p in (w/'controls').glob('*instrumented.goose')}),indent=2)+'\n')
paths=[*list((w/'inputs/examples').rglob('*')),w/'examples-manifest.json',w/'probe-expected-before-execution.json',*list((w/'controls').glob('*.goose'))]
(w/'gate-pins-before.json').write_text(json.dumps({str(p):sha(p) for p in paths if p.is_file()},indent=2)+'\n')
print('Frozen ten examples, private probe controls, capped-table growth control')
