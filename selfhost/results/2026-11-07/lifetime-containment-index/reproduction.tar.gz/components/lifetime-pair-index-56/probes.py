from pathlib import Path
import hashlib,json,resource,subprocess,time
root=Path('/home/jacobt/src/goose-to-wasm');w=root/'build/completion-runs/lifetime-pair-index-56';compiler=w/'build/goose';out=w/'probes-v2';out.mkdir();expected=json.loads((w/'expected-before-execution.json').read_text())['direct_expected']['stdout'];contracts=json.loads((w/'probe-expected-before-execution.json').read_text());rows=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(cmd):
 start=resource.getrusage(resource.RUSAGE_CHILDREN);wall=time.perf_counter();r=subprocess.run(list(map(str,cmd)),capture_output=True,timeout=30);end=resource.getrusage(resource.RUSAGE_CHILDREN);return r,dict(wall_seconds=time.perf_counter()-wall,cpu_seconds=(end.ru_utime+end.ru_stime)-(start.ru_utime+start.ru_stime))
for label in ('baseline','candidate','capacity'):
 source=w/'controls'/('capacity.goose' if label=='capacity' else label+'-instrumented.goose')
 for target in ('native','wasm-direct'):
  for level in (0,2):
   artifact=out/(label+'-'+target+'-'+str(level)+('.c' if target=='native' else '.wasm'));cmd=[compiler,source,'--stdlib',root/'stdlib','--target',target,'--standalone','-O'+str(level),'-o',artifact];
   if label=='capacity' and target=='wasm-direct':cmd += ['--wasm-initial-pages','1024','--wasm-max-pages','1024']
   r,stats=run(cmd);assert r.returncode==0,r.stderr.decode()
   runners=[('wasmtime',[root/'build/bin/goose-wasmtime','--no-cache',artifact]),('v8',['node',root/'scripts/run_wasm.mjs',artifact])]
   if target=='native':
    binary=artifact.with_suffix('.bin');r,_=run(['clang','-std=gnu11','-O'+str(level),artifact,'-lm','-ldl','-pthread','-o',binary]);assert r.returncode==0,r.stderr.decode();runners=[('native',[binary])]
   for engine,command in runners:
    r,stats=run(command);text=r.stdout.decode();assert r.returncode==0,(label,target,r.stderr.decode())
    row=dict(control=label,target=target,level=level,engine=engine,source_sha256=sha(source),artifact_sha256=sha(artifact),command=list(map(str,command)),exit_code=r.returncode,stdout=text,stderr=r.stderr.decode(),observations=stats)
    if label=='capacity':assert text==contracts['capacity_stdout']
    else:
     prefix,metrics=text.split('METRICS ');assert prefix==expected;probes,misses,pairs,buckets=map(int,metrics.split());row.update(probes=probes,misses=misses,pairs=pairs,buckets=buckets,logical_bucket_bytes=buckets*8);assert misses==pairs==13
     if label=='baseline':assert probes>=contracts['baseline_probes_min'] and buckets==0
     else:assert probes<=contracts['candidate_probes_max'] and buckets==16
    rows.append(row);(w/'probe-report-v2.json').write_text(json.dumps(dict(method='Separately pinned private direct-function instrumentation only; not production compiler instrumentation or a timing comparison.',contracts=contracts,rows=rows),indent=2)+'\n')
print('probe rows',len(rows),flush=True)
