# Ordered lifetime memo index

Source-only candidate. No compiler, runtime, or measurement has run. Root55 hold applies until explicitly released.

`LifePair` stays the append-only authoritative ledger. Each new pair has a next index; a per-`Lifetimes` bucket arena points to pair IDs. Hits compare exact ordered `(owner, pointee)` IDs and return the stored positive or negative answer. Misses run the original containment walk unchanged and append one answer in the original order before publishing its head.

The nonrecursive `check_lifetimes` owns the empty head arena. The first valid query chooses the next power of two from16 through16384 based on `p.types.len`; negative IDs return before initialization. The count remains fixed as types grow. Hashing folds the nonnegative IDs with XOR/right shifts and mixes the pointee differently. Its only left shift applies to `b &8191`, so its value cannot exceed16382; the bucket-growth shift cannot exceed16384. There is no multiplication or unchecked arithmetic overflow. Exact equality, rather than the hash, decides hits.

Audit of snapshot55 finds one pair read scan, one pair append, one local owner, and one `Lifetimes` construction. No pair mutation, truncation, clear, resize, pop, checkpoint, or restore exists. The checker constructs fresh memo state on every `check_lifetimes` call. Current private readonly restoration acts on `Program`/`Checker` before this phase; no lifetime memo participates in that state. Types/nodes can be appended by lifetime standalone setup; the fixed bucket table accepts their new IDs. Existing type identity and visited-walk semantics remain intact. A future pair truncation would require rebuilding heads; no speculative rebuild logic is added today.

Logical index cost is at most128KiB for i64 bucket entries and one additional i64 link per stored pair, plus one arena header/reference. Exact backend allocation, padding, RSS, pair count and probe counts remain unmeasured. No instrumentation is included in production candidate source.

The direct harness copies the exact `life_same`, `life_contains`, candidate hash, and `LifePair` source. It supplies actual `Type`/`Node` declarations with a minimal Program/Lifetimes owner shell. Its graph and expected ledger/output are specified independently before execution. It covers positive and negative memoization, reversed keys, same declaration versus same structural shape, a recursive array walk, a forced chain collision, new types after initialization, and2000 repeated hits. It is not a second cache implementation.

The readonly wrapper is only an iteration-cost workload. Finishing its compile does not establish that its proposed lifetime/read-only behavior is legal or admitted. Historical canonical50 timing remains a separate observation; all new comparisons must use canonical55 and candidate56 on the identical frozen input.
