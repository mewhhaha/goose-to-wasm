from pathlib import Path
import hashlib,json,os,signal,statistics,subprocess,time
root=Path('/home/jacobt/src/goose-to-wasm');w=root/'build/completion-runs/lifetime-pair-index-56';out=w/'measurement-exploratory';out.mkdir(exist_ok=True);baseline=root/'build/completion-runs/c-only-bootstrap-55/goose';candidate=w/'build/goose';library=root/'stdlib'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(value):(w/'measurement-exploratory.json').write_text(json.dumps(value,indent=2)+'\n')
assert json.loads((w/'own-fixedpoint.json').read_text())['generated_c_equal']
allowed=os.sched_getaffinity(0);cpu=7
if cpu not in allowed:cpu=min(allowed)
os.sched_setaffinity(0,{cpu})
inputs=[baseline,candidate,Path(__file__),*list((root/'build/completion-runs/snapshot-55').rglob('*')),*list((w/'inputs').rglob('*')),*list(library.glob('*.goose'))]
pins={str(p):sha(p) for p in inputs if p.is_file()}
report=dict(status='running',method='Exploratory: other owners active. Identical source/stdlib/options and CPU affinity for paired canonical55/indexed56. Two warmups plus five measured interleaved fresh-process pairs only when every pilot completes successfully with identical output/diagnostics/artifact bytes. Equal240s timeout; censored/nonzero cases retain raw observations and never get ratios. CPU is wait4 child user+system; wall is launch-to-wait4; RSS is per-child maxrss KiB.',cpu_affinity=[cpu],load_start=os.getloadavg(),input_sha256=pins,tasks=[]);save(report)
compilers=[('baseline55',baseline),('indexed56',candidate)]
workloads=[('source55',root/'build/completion-runs/snapshot-55/selfhost/main.goose'),('heavy-old-driver',w/'inputs/narrow-readonly/selfhost/probe.goose'),('heavy-new-driver',w/'inputs/narrow-readonly-new-driver/selfhost/probe.goose')]
tasks=[]
for name,source in workloads:
 for action in ('check','emit'):tasks.append((name,source,action,'native'))
for example in json.loads((w/'inputs/examples/manifest.json').read_text())['examples']:
 source=w/'inputs/examples'/example['file']
 for action,target in [('check','native'),('emit','wasm-direct')]:tasks.append(('small-'+example['name'],source,action,target))
def alarm(signum,frame):raise TimeoutError()
signal.signal(signal.SIGALRM,alarm)
def run(name,source,action,target,label,compiler,iteration):
 prefix=out/(name+'-'+action+'-'+label+'-'+str(iteration));artifact=prefix.with_suffix('.c' if target=='native' else '.wasm');command=[compiler,source,'--stdlib',library,'--target',target]
 if action=='check':command+=['--check']
 else:command+=['--standalone','-O0','-o',artifact]
 command=list(map(str,command));start=time.perf_counter_ns();timed_out=False
 with prefix.with_suffix('.stdout').open('wb') as stdout,prefix.with_suffix('.stderr').open('wb') as stderr:
  proc=subprocess.Popen(command,cwd=root,stdout=stdout,stderr=stderr,start_new_session=True);signal.setitimer(signal.ITIMER_REAL,240)
  try:pid,status,usage=os.wait4(proc.pid,0)
  except TimeoutError:
   timed_out=True;os.killpg(proc.pid,signal.SIGKILL);pid,status,usage=os.wait4(proc.pid,0)
  finally:signal.setitimer(signal.ITIMER_REAL,0)
  proc.returncode=os.waitstatus_to_exitcode(status)
 wall=time.perf_counter_ns()-start
 row=dict(compiler=label,iteration=iteration,warmup=iteration<0,command=command,exit_code=proc.returncode,timed_out=timed_out,timeout_seconds=240,wall_ns=wall,cpu_ns=int((usage.ru_utime+usage.ru_stime)*1e9),max_rss_kib=usage.ru_maxrss,stdout_sha256=sha(prefix.with_suffix('.stdout')),stderr_sha256=sha(prefix.with_suffix('.stderr')),artifact_sha256=sha(artifact) if artifact.exists() else None,stdout_file=str(prefix.with_suffix('.stdout')),stderr_file=str(prefix.with_suffix('.stderr')))
 print(name,action,label,iteration,'timeout' if timed_out else proc.returncode,round(wall/1e9,3),round(row['cpu_ns']/1e9,3),flush=True);return row
def equivalent(a,b):return not a['timed_out'] and not b['timed_out'] and a['exit_code']==b['exit_code']==0 and all(a[k]==b[k] for k in ('stdout_sha256','stderr_sha256','artifact_sha256'))
try:
 for name,source,action,target in tasks:
  task=dict(name=name,source=str(source),source_sha256=sha(source),action=action,target=target,observations=[],complete_successful_pairs=True,ratios=None);report['tasks'].append(task);save(report)
  for iteration in range(-2,5):
   order=compilers
   if iteration%2:order=list(reversed(compilers))
   pair=[]
   for label,compiler in order:
    row=run(name,source,action,target,label,compiler,iteration);task['observations'].append(row);pair.append(row);save(report)
   if not equivalent(*pair):task['complete_successful_pairs']=False;task['reason']='Incomplete, nonzero or unequal pilot/sample; no speedup ratio is valid.';save(report);break
  if task['complete_successful_pairs']:
   measured={label:[r for r in task['observations'] if r['compiler']==label and not r['warmup']] for label,_ in compilers};task['medians']={label:{key:statistics.median(r[key] for r in rows) for key in ('wall_ns','cpu_ns','max_rss_kib')} for label,rows in measured.items()};task['ratios']={key:task['medians']['indexed56'][key]/task['medians']['baseline55'][key] for key in ('wall_ns','cpu_ns','max_rss_kib')};save(report)
  if (w/'PAUSE-MEASUREMENT').exists():report['status']='paused-at-task-boundary';save(report);raise SystemExit(0)
 report.update(status='complete',load_end=os.getloadavg(),input_sha256_after={p:sha(p) for p in pins});assert report['input_sha256_after']==pins;save(report)
except BaseException as error:
 if not isinstance(error,SystemExit):report.update(status='failed',error=repr(error));save(report)
 raise
