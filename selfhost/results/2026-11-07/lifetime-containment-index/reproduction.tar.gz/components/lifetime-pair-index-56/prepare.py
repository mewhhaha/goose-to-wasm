from pathlib import Path
import difflib,hashlib,json,re,shutil
root=Path('/home/jacobt/src/goose-to-wasm');w=root/'build/completion-runs/lifetime-pair-index-56';base=root/'build/completion-runs/snapshot-55';source=w/'source'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
shutil.copytree(base,source)
(source/'source-pins.json').rename(source/'parent-55-source-pins.json');parent=json.loads((source/'parent-55-source-pins.json').read_text());assert len(parent)==58 and all(sha(source/p)==h for p,h in parent.items())
p=source/'selfhost/checker_lifetimes.goose';before=p.read_text();text=before
changes=[
 ('struct LifePair { owner: i64, pointee: i64, answer: bool }','struct LifePair { owner: i64, pointee: i64, answer: bool, next: i64 = -1 }'),
 ('    frames: LifeFrame[>..]&, items: LifeItem[>..]&, pairs: LifePair[>..]&, exits: LifeExit[>..]&,','    frames: LifeFrame[>..]&, items: LifeItem[>..]&, pairs: LifePair[>..]&, pair_heads: i64[>..]&, exits: LifeExit[>..]&,'),
 ('fn life_contains(p: Program&, l: Lifetimes&, owner: i64, pointee: i64) -> bool {','''fn life_pair_bucket(owner: i64, pointee: i64, count: i64) -> i64 {
    let a = owner ^ (owner >> 14) ^ (owner >> 28) ^ (owner >> 42) ^ (owner >> 56);
    let b = pointee ^ (pointee >> 14) ^ (pointee >> 28) ^ (pointee >> 42) ^ (pointee >> 56);
    return (a ^ b ^ ((b & 8191) << 1) ^ (b >> 13)) & (count - 1);
}
fn life_contains(p: Program&, l: Lifetimes&, owner: i64, pointee: i64) -> bool {'''),
 ('    for q in l.pairs { if q.owner == owner && q.pointee == pointee { return q.answer; } }','''    if l.pair_heads.len == 0 {
        var count: i64 = 16;
        while count < p.types.len && count < 16384 { count <<= 1; }
        for i in 0..count { l.pair_heads.push(-1); }
    }
    let bucket = life_pair_bucket(owner, pointee, l.pair_heads.len);
    var pair = l.pair_heads[bucket];
    while pair >= 0 {
        let q = l.pairs[pair];
        if q.owner == owner && q.pointee == pointee { return q.answer; }
        pair = q.next;
    }'''),
 ('    l.pairs.push(LifePair { owner: owner, pointee: pointee, answer: answer });','''    let index = l.pairs.len;
    l.pairs.push(LifePair { owner: owner, pointee: pointee, answer: answer, next: l.pair_heads[bucket] });
    l.pair_heads[bucket] = index;'''),
 ('    var items: LifeItem[>..] = []; var pairs: LifePair[>..] = []; var exits: LifeExit[>..] = [];','    var items: LifeItem[>..] = []; var pairs: LifePair[>..] = []; var pair_heads: i64[>..] = []; var exits: LifeExit[>..] = [];'),
 ('roots: roots, sets: sets, alts: alts, cells: cells, frames: frames, items: items, pairs: pairs, exits: exits,','roots: roots, sets: sets, alts: alts, cells: cells, frames: frames, items: items, pairs: pairs, pair_heads: pair_heads, exits: exits,')]
for old,new in changes:
 assert text.count(old)==1,old;text=text.replace(old,new)
p.write_text(text);(w/'candidate.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),text.splitlines(True),fromfile='a/selfhost/checker_lifetimes.goose',tofile='b/selfhost/checker_lifetimes.goose')))
pins={str(p.relative_to(source)):sha(p) for p in sorted(source.rglob('*')) if p.is_file() and p.name!='parent-55-source-pins.json'};assert len(pins)==58;(source/'source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
# Function bodies below are exact slices, not a second cache implementation.
def function(text,name):
 start=text.index('fn '+name+'(');end=text.index('\nfn ',start+1);return text[start:end]+'\n'
model=(base/'selfhost/model.goose').read_text();constants='\n'.join(line for line in model.splitlines() if re.match(r'let (TY_|TF_UNSIGNED\b)',line))+'\n'
def struct(text,name):return re.search(r'^struct '+name+r' \{.*?^\}',text,re.M|re.S).group(0)+'\n'
stub=constants+struct(model,'Node')+struct(model,'Type')+'''struct Program { types: Type[>..]&, nodes: Node[>..]& }
struct Lifetimes { pairs: LifePair[>..]&, pair_heads: i64[>..]& }
'''
main='''fn query(p: Program&, l: Lifetimes&, owner: i64, pointee: i64) { print(life_contains(p, l, owner, pointee), " ", l.pairs.len); }
fn main() {
    var types: Type[>..] = [
        Type { kind: TY_INT, count: 8 }, Type { kind: TY_INT, count: 64 },
        Type { kind: TY_ARRAY, element: 0 },
        Type { kind: TY_STRUCT, declaration: 100, first: 0 },
        Type { kind: TY_STRUCT, declaration: 101, first: 1 },
        Type { kind: TY_STRUCT, declaration: 100, first: 0 },
        Type { kind: TY_STRUCT, declaration: 102, first: 0 },
        Type { kind: TY_ARRAY, element: 3 },
        Type { kind: TY_TUPLE, first: 2 }, Type { kind: TY_REF, element: 0 },
        Type { kind: TY_ENUM, declaration: 200, first: 4 }, Type { kind: TY_ARRAY, element: 11 }
    ];
    for i in 12..16 { types.push(Type { kind: TY_INT, count: 32 }); }
    var nodes: Node[>..] = [Node { type_id: 0 }, Node { type_id: 1 }, Node { type_id: 3, next: 3 }, Node { type_id: 4 }, Node { type_id: 0 }];
    var p = Program { types: types, nodes: nodes };
    var pairs: LifePair[>..] = []; var heads: i64[>..] = [];
    var l = Lifetimes { pairs: pairs, pair_heads: heads };
    query(p, l, -1, 0); assert(heads.len == 0);
    query(p, l, 0, 0); query(p, l, 0, 0);
    query(p, l, 0, 1); query(p, l, 0, 1);
    query(p, l, 2, 0); query(p, l, 0, 2);
    query(p, l, 2, 0); query(p, l, 0, 2);
    query(p, l, 3, 5); query(p, l, 3, 6);
    query(p, l, 7, 0); query(p, l, 8, 1);
    query(p, l, 9, 0); query(p, l, 10, 0); query(p, l, 11, 0);
    p.types.push(Type { kind: TY_INT, count: 64 });
    query(p, l, 16, 0); query(p, l, 0, 0); query(p, l, 16, 0);
    query(p, l, 16, 1); query(p, l, 16, 1);
    for i in 0..1000 { assert(life_contains(p, l, 2, 0)); assert(!life_contains(p, l, 0, 2)); }
    print("repeated ", l.pairs.len);
    for q in l.pairs { print(q.owner, " ", q.pointee, " ", q.answer); }
}
'''
expected='false 0\ntrue 1\ntrue 1\nfalse 2\nfalse 2\ntrue 3\nfalse 4\ntrue 4\nfalse 4\ntrue 5\nfalse 6\ntrue 7\ntrue 8\nfalse 9\ntrue 10\nfalse 11\nfalse 12\ntrue 12\nfalse 12\ntrue 13\ntrue 13\nrepeated 13\n0 0 true\n0 1 false\n2 0 true\n0 2 false\n3 5 true\n3 6 false\n7 0 true\n8 1 true\n9 0 false\n10 0 true\n11 0 false\n16 0 false\n16 1 true\n'
controls=w/'controls';controls.mkdir();extraction={}
for name,body in [('baseline',before),('candidate',text)]:
 pair=re.search(r'^struct LifePair \{[^\n]*',body,re.M).group(0)+'\n';funcs=function(body,'life_same')
 if name=='candidate':funcs+=function(body,'life_pair_bucket')
 funcs+=function(body,'life_contains');path=controls/(name+'-direct.goose');path.write_text(stub+pair+funcs+main)
 extraction[name]={'source':str(path.relative_to(root)),'sha256':sha(path),'original_lifetime_source_sha256':hashlib.sha256(body.encode()).hexdigest(),'functions_sha256':hashlib.sha256(funcs.encode()).hexdigest()}
metadata={'status':'frozen before any compiler execution','direct_function_extraction':extraction,'direct_expected':{'stdout':expected,'exit':0,'compiler_diagnostics':''},'claims':['positive and negative answers memoized without duplicate ledger entries','ordered reversed keys remain independent','same declaration vs same shape preserve nominal identity','cyclic containment walk retains visited behavior','bucket collision (0,0) vs (16,0) at count16 preserves both answers','new type16 works after initial table16 without rehash','2000 repeated hit queries leave 13 ordered ledger entries','negative sentinel query does not initialize buckets'],'not_yet_executed':True}
(w/'expected-before-execution.json').write_text(json.dumps(metadata,indent=2)+'\n')
manifest=json.loads((root/'tests/conformance/cases.json').read_text());cases=[]
for name in ('baseline','candidate'):
 for target in ('native','wasm-direct'):
  cases.append(dict(id='lifetime-pair-direct/'+name+'/'+target,source=extraction[name]['source'],phase='run',target=target,levels=[0,2],expect=dict(stdout=expected,exit=0),provenance='exact production function extraction with independently specified graph, query order, ledger and output'))
(w/'controls-manifest.json').write_text(json.dumps(dict(schema=manifest['schema'],upstream=manifest['upstream'],cases=cases),indent=2)+'\n')
# Build helper is staged only; its execution requires the root hold release.
build=(root/'build/completion-runs/from-end-slices-55/build.py').read_text().replace('c-only-bootstrap-54-v3','c-only-bootstrap-55').replace('snapshot54-v3','snapshot55')
(w/'build.py').write_text(build)
assert all(sha(base/name)==h for name,h in parent.items())
print('prepared source only:',len(pins),'pins; one compiler source changed; direct controls frozen')
