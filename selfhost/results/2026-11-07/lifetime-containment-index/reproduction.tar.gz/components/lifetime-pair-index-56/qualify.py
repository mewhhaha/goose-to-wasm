from pathlib import Path
import concurrent.futures,hashlib,json,subprocess,time
root=Path('/home/jacobt/src/goose-to-wasm');w=root/'build/completion-runs/lifetime-pair-index-56';base=root/'build/completion-runs/c-only-bootstrap-55/goose';candidate=w/'build/goose';library=root/'stdlib'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(name,value):(w/name).write_text(json.dumps(value,indent=2)+'\n')
proof=json.loads((w/'build/report.json').read_text());assert proof['status']=='passed' and sha(candidate)==proof['executable_sha256']
commands=[]
def run(name,cmd,timeout=240):
 cmd=list(map(str,cmd));start=time.monotonic();r=subprocess.run(cmd,cwd=root,capture_output=True,timeout=timeout);(w/(name+'.stdout')).write_bytes(r.stdout);(w/(name+'.stderr')).write_bytes(r.stderr);commands.append(dict(name=name,command=cmd,exit_code=r.returncode,seconds=time.monotonic()-start));save('qualification-commands.json',commands);print(name,r.returncode,round(commands[-1]['seconds'],3),flush=True);return r
conformance=['python',root/'tests/conformance.py','--cc','clang','--compiler',candidate,'--timeout','30']
for name,manifest,extra in [('direct-v2',w/'controls-manifest.json',[]),('direct-v8-v2',w/'controls-manifest.json',['--engine','v8','--filter','/wasm-direct']),('examples',w/'examples-manifest.json',[]),('examples-v8',w/'examples-manifest.json',['--engine','v8','--filter','/wasm-direct']),('preservation',root/'build/completion-runs/temporary-retirement-54/preservation-manifest.json',[]),('preservation-v8',root/'build/completion-runs/temporary-retirement-54/preservation-all-v8-manifest.json',['--engine','v8'])]:
 r=run(name,conformance+['--manifest',manifest,'--output-dir',w/name]+extra);assert r.returncode==0,name
# Fresh paired front2800: compare complete compiler observations, not just accepted counts.
front=w/'front';front.mkdir();summary={}
for group in ('semantic-all-valid','typing','negative-type','upstream-positive'):
 rows=json.loads((root/'build/completion-runs/from-end-slices-55/front'/(group+'.json')).read_text())
 def check(row):
  result={'source':row['source'],'source_sha256':sha(row['source'])}
  for label,compiler in [('baseline',base),('candidate',candidate)]:
   try:
    r=subprocess.run([compiler,row['source'],'--stdlib',library,'--check','--target','wasm-direct'],capture_output=True,text=True,timeout=15);result[label]=dict(exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr)
   except subprocess.TimeoutExpired:result[label]=dict(exit_code=124,stdout='',stderr='TIMEOUT')
  result['equal']=result['baseline']==result['candidate'];return result
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:observations=list(pool.map(check,rows))
 (front/(group+'.json')).write_text(json.dumps(observations,indent=2)+'\n');summary[group]=dict(total=len(rows),equal=sum(x['equal'] for x in observations),baseline_accepted=sum(x['baseline']['exit_code']==0 for x in observations),candidate_accepted=sum(x['candidate']['exit_code']==0 for x in observations),mismatches=[x['source'] for x in observations if not x['equal']]);print(group,summary[group],flush=True)
 save('front/comparison.json',summary)
assert all(x['total']==x['equal'] for x in summary.values())
# Exact bytes/diagnostics on ten benchmark programs and unchanged actual source55.
artifacts=w/'emission';artifacts.mkdir();emissions=[]
examples=json.loads((w/'examples-manifest.json').read_text())['cases']
for case in examples:
 for level in (0,2):
  row=dict(case=case['id'],target=case['target'],level=level,source=case['source'],source_sha256=sha(root/case['source']),outputs={})
  for label,compiler in [('baseline',base),('candidate',candidate)]:
   dest=artifacts/(case['id'].replace('/','-')+'-'+str(level)+'-'+label+('.c' if case['target']=='native' else '.wasm'));cmd=[compiler,root/case['source'],'--stdlib',library,'--target',case['target'],'--standalone','-O'+str(level),'-o',dest];r=run('emit-'+dest.stem,cmd);row['outputs'][label]=dict(exit_code=r.returncode,stdout=r.stdout.decode(),stderr=r.stderr.decode(),sha256=sha(dest) if dest.exists() else None,bytes=dest.stat().st_size if dest.exists() else None)
  row['equal']=row['outputs']['baseline']==row['outputs']['candidate'];emissions.append(row);save('emission-equality.json',emissions);assert row['equal'] and row['outputs']['baseline']['exit_code']==0
source=root/'build/completion-runs/snapshot-55/selfhost/main.goose';source_row={'source':str(source),'outputs':{}}
for label,compiler in [('baseline',base),('candidate',candidate)]:
 dest=artifacts/('source55-'+label+'.c');r=run('unchanged-source55-'+label,[compiler,source,'--stdlib',library,'--target','native','--standalone','-O0','-o',dest]);source_row['outputs'][label]=dict(exit_code=r.returncode,stdout=r.stdout.decode(),stderr=r.stderr.decode(),sha256=sha(dest) if dest.exists() else None)
source_row['equal']=source_row['outputs']['baseline']==source_row['outputs']['candidate'];save('source55-emission-equality.json',source_row);assert source_row['equal'] and source_row['outputs']['baseline']['exit_code']==0
r=run('own-selfemit',[candidate,w/'source/selfhost/main.goose','--stdlib',library,'--target','native','--standalone','-O0','-o',w/'own-compiler.c']);assert r.returncode==0
fixed=dict(generated_c_equal=(w/'own-compiler.c').read_bytes()==(w/'build/compiler.c').read_bytes(),initial_c_sha256=sha(w/'build/compiler.c'),own_c_sha256=sha(w/'own-compiler.c'));save('own-fixedpoint.json',fixed);assert fixed['generated_c_equal']
for name in ('gate-pins-before.json','workload-pins-before-execution.json'):
 pins=json.loads((w/name).read_text());after={p:sha(root/p) if not Path(p).is_absolute() else sha(p) for p in pins};assert pins==after;save(name.replace('before','after'),after)
print('QUALIFIED',flush=True)
