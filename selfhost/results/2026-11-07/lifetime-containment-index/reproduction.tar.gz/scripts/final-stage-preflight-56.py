from pathlib import Path
import hashlib,json,tarfile,subprocess
r=Path.cwd();w=r/'build/completion-runs'
def read(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
plan=read(w/'stage-plan-56.json');assert plan['status']=='passed'
base=read(w/'delivery-56.json')['base_commit'];assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==base
planned={row['path']:row for row in plan['files']};changed=set(subprocess.check_output(['git','diff','--cached','--name-only'],text=True).splitlines());assert changed<=planned.keys()
for folder in ['bench/results/2026-11-07/lifetime-containment-index','selfhost/results/2026-11-07/lifetime-containment-index']:
 for path in (r/folder).rglob('*'):
  if path.is_file():assert path.relative_to(r).as_posix() in planned,('missing delivery',str(path))
for name,row in planned.items():
 assert sha(subprocess.check_output(['git','show',':'+name]))==row['sha256'],name
 assert sha(Path(row['source']).read_bytes())==row['sha256'],name
with tarfile.open(r/'selfhost/results/2026-11-07/lifetime-containment-index/reproduction.tar.gz') as t:
 checks={'notes/composition56-audit.json':w/'composition56-audit.json','notes/delivery-56-review-ready.json':w/'delivery-56-review-ready.json','components/astra-lifetime-pair-index-56/review.json':w/'astra-lifetime-pair-index-56/review.json','components/paired-runtime55-56/report.json':w/'paired-runtime55-56/report.json'}
 checks['components/compiler-phase-56/report.json']=w/'compiler-phase-56/report.json'
 for name,p in checks.items():assert t.extractfile(name).read()==p.read_bytes(),name
 proof=read(w/'c-only-bootstrap-56/report.json')
 for name,h in proof['source_sha256'].items():assert sha(t.extractfile('sources/selfhost/'+name).read())==h,name
 for name,h in proof['asset_sha256'].items():assert sha(t.extractfile('sources/'+name).read())==h,name
 for name,h in read(w/'new-controls-56.json')['sources'].items():assert sha(t.extractfile('qualification/'+name).read())==h,name
s=read(r/'selfhost/results/2026-11-07/lifetime-containment-index/summary.json');assert s['contracts']==dict(selected=7787,passed=7687,failed=100);assert s['existing_contract_gains']==0 and s['new_contract_rows']==8
f=read(r/'bench/results/2026-11-07/lifetime-containment-index/copy-facts.json');assert 'Wasmtime 50.0.1' in f['METHOD_AND_IDENTITIES']
pair=read(w/'paired-runtime55-56/report.json');assert pair['status']=='passed' and len(pair['commands'])==240 and sum(not x['warmup'] for x in pair['commands'])==200
for name in ['examples-latest.json','wasmtime-host-latest.json']:
 p=read(r/'bench/results'/name);assert p['sha256']==sha((r/'bench/results'/p['report']).read_bytes())
assert read(w/'compiler-phase-56/report.json')['status']=='passed'
subprocess.run(['git','diff','--cached','--check'],check=True)
assert subprocess.check_output(['git','ls-remote','origin','refs/heads/main'],text=True).split()[0]==base
(w/'final-stage-preflight-56.json').write_text(json.dumps(dict(status='passed',base_commit=base,planned_paths=len(planned),changed_paths=len(changed),capsule_and_source_controls_verified=True),indent=2)+'\n')
print('Final56 preflight passed',len(planned),'planned paths;',len(changed),'changed')
