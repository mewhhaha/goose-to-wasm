from pathlib import Path
import hashlib, json, os, shutil, subprocess, time
root=Path('/home/jacobt/src/goose-to-wasm');work=root/'build/completion-runs';public=work/'public-56'
old=json.loads((work/'public-52/build/smoke/report.json').read_text());env=dict(os.environ)
node=Path(old['node']);env['PATH']='/usr/bin:/bin:'+str(node.parent);env.pop('TMPDIR',None)
(public/'build/smoke').mkdir(exist_ok=True)
shutil.copyfile(work/'public-52/build/smoke/float.goose',public/'build/smoke/float.goose')
rows=[]
for i,row in enumerate(old['commands']):
 cmd=[v.replace('/public-52/','/public-56/') for v in row['command']];start=time.monotonic()
 result=subprocess.run(cmd,cwd=public,env=env,text=True,capture_output=True)
 rows.append(dict(command=cmd,exit_code=result.returncode,seconds=time.monotonic()-start,stdout=result.stdout,stderr=result.stderr))
 assert result.returncode==0,rows[-1]
 if i%2: assert result.stdout==row['stdout'],rows[-1]
proof=json.loads((work/'c-only-bootstrap-56/report.json').read_text())
report=dict(status='passed',environment=old['environment'],node=str(node),compiler_sha256=hashlib.sha256((public/'build/bin/goose').read_bytes()).hexdigest(),source_sha256=proof['source_sha256'],commands=rows)
(public/'build/smoke/report.json').write_text(json.dumps(report,indent=2)+'\n')
(work/'public-smoke-context-56.json').write_text(json.dumps(dict(status='passed',reference='public-52/build/smoke/report.json',expected='Independent fixed squares sum140 and float formatter 0.1/1.25 outputs; no reference compiler',source_sha256=hashlib.sha256((public/'build/smoke/float.goose').read_bytes()).hexdigest()),indent=2)+'\n')
print(report['status'],report['compiler_sha256'])
