from pathlib import Path
import datetime,hashlib,json,os,shutil,statistics,subprocess,time
root=Path('/home/jacobt/src/goose-to-wasm');w=root/'build/completion-runs';out=w/'compiler-phase-56';out.mkdir(exist_ok=False);os.sched_setaffinity(0,{7})
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=w/'snapshot-55/selfhost/main.goose';stdlib=w/'c-only-bootstrap-55/stdlib';cc=Path(shutil.which('clang-23')).resolve()
compilers={v:w/f'c-only-bootstrap-{v}/goose' for v in (55,56)}
paths=[Path(__file__),cc,*compilers.values(),*[p for p in (w/'snapshot-55').rglob('*') if p.is_file()],*[p for p in stdlib.rglob('*.goose')]]
pins={str(p):sha(p) for p in paths}
report=dict(status='running',started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),method='Same frozen snapshot55 compiler source/stdlib/options/paths. GooseO0 emits nativeC; baseline55 and indexed56 optimized host compilers alternate. One whole-source warmup then two measured processes per compiler. CPU7; coding owners explicitly quiet; OS page cache retained. wait4 captures child CPU/maxRSS. Common downstream ClangO2 C compilation is measured separately on identical emittedC.',input_sha256=pins,cpu_affinity=sorted(os.sched_getaffinity(0)),commands=[])
def save():(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
def run(cmd,label):
 started=time.monotonic()
 with (out/(label+'.stdout')).open('wb') as stdout,(out/(label+'.stderr')).open('wb') as stderr:
  proc=subprocess.Popen(list(map(str,cmd)),cwd=root,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr)
  while True:
   pid,status,usage=os.wait4(proc.pid,os.WNOHANG)
   if pid:break
   if time.monotonic()-started>600:
    proc.kill();pid,status,usage=os.wait4(proc.pid,0);break
   time.sleep(.1)
  proc.returncode=os.waitstatus_to_exitcode(status)
 row=dict(command=list(map(str,cmd)),exit_code=proc.returncode,wall_seconds=time.monotonic()-started,cpu_seconds=usage.ru_utime+usage.ru_stime,max_rss_kib=usage.ru_maxrss,stdout_sha256=sha(out/(label+'.stdout')),stderr_sha256=sha(out/(label+'.stderr')))
 assert row['exit_code']==0,(label,row)
 return row
save();common=out/'compiler.c';c_hash=None
for sample in (-1,0,1):
 versions=[55,56]
 if sample%2:versions.reverse()
 for version in versions:
  stats=out/f'{version}-{sample}-stats.json';cmd=[compilers[version],source,'--stdlib',stdlib,'--target','native','--standalone','-O0','--wasm-stats',stats,'-o',common]
  row=run(cmd,f'emit-{version}-{sample}');row.update(kind='goose-to-c',compiler=version,sample=sample,warmup=sample<0,c_sha256=sha(common),stats=json.loads(stats.read_text()))
  if c_hash is None:c_hash=row['c_sha256']
  assert row['c_sha256']==c_hash,'Compiled program bytes changed'
  report['commands'].append(row);save()
for sample in (-1,0,1):
 row=run([cc,'-std=gnu11','-O2',common,'-lm','-ldl','-pthread','-o',out/'compiler'],f'cc-{sample}')
 row.update(kind='common-c-compile',sample=sample,warmup=sample<0,c_sha256=c_hash,executable_sha256=sha(out/'compiler'));report['commands'].append(row);save()
def med(rows,key):return statistics.median(r[key] for r in rows)
summaries={}
for v in (55,56):
 rows=[r for r in report['commands'] if r.get('compiler')==v and not r['warmup']]
 summaries[str(v)]={k:med(rows,k) for k in ('wall_seconds','cpu_seconds','max_rss_kib')}
 summaries[str(v)]['phase_ns']={key:statistics.median(r['stats'][key] for r in rows) for key in ('parse_ns','typecheck_ns','optimize_ns','backend_ns')}
cc_rows=[r for r in report['commands'] if r['kind']=='common-c-compile' and not r['warmup']]
ratios={k:summaries['56'][k]/summaries['55'][k] for k in ('wall_seconds','cpu_seconds','max_rss_kib')}
after={p:sha(p) for p in pins};assert pins==after
report.update(status='passed',ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),summary=summaries,ratios=ratios,common_c_compile={k:med(cc_rows,k) for k in ('wall_seconds','cpu_seconds','max_rss_kib')},c_sha256=c_hash,input_sha256_after=after)
a=summaries['55'];b=summaries['56']
report['prose']=f"On the fixed snapshot 55 compiler workload, native C emission took {a['wall_seconds']:.2f} s with the prior compiler and {b['wall_seconds']:.2f} s with the index (CPU {a['cpu_seconds']:.2f} vs {b['cpu_seconds']:.2f} s). Peak-RSS medians were {a['max_rss_kib']/1024:.1f} and {b['max_rss_kib']/1024:.1f} MiB. Emitted C bytes match. These are two measured processes per compiler after one warmup, with alternating order on CPU 7. The common downstream C compilation took {med(cc_rows,'wall_seconds'):.2f} s and is separate."
save();print(json.dumps(dict(status=report['status'],summary=summaries,ratios=ratios,common_c_compile=report['common_c_compile']),indent=2),flush=True)
