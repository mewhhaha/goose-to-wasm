from pathlib import Path
import json
w=Path('build/completion-runs')
for name in ['qualify_55.py','public-smoke-55.py','public-cross55.py','qualification55-sequence.py','migrate_controls55.py','stage_55.py','install_55.py']:
 (w/name.replace('55','56')).write_text((w/name).read_text().replace('55','56'))
p=w/'delivery-56.json';c=json.load(open(p));c['manifest_sets']=[dict(path='astra-lifetime-pair-index-56/controls-manifest.json',prefix='lifetime-containment-review')];p.write_text(json.dumps(c,indent=2)+'\n')
