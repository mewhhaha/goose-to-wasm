from pathlib import Path
w=Path('build/completion-runs')
for name in ['publish_55.py','render_copy_55.py']:
 s=(w/name).read_text().replace('paired-runtime54-55','PAIR_RUNTIME').replace('paired-build54-55','PAIR_BUILD')
 s=s.replace('55','56').replace('PAIR_RUNTIME','paired-runtime55-56').replace('PAIR_BUILD','paired-build55-56').replace('from-end-slice-bounds','lifetime-containment-index')
 s=s.replace('c-only-bootstrap-54-v4','c-only-bootstrap-55').replace('verified-seed-54-v4','verified-seed-55').replace('parent seed is verified snapshot54','parent seed is verified snapshot55')
 s=s.replace('snapshot 54','snapshot 55').replace('qualified 54/56','qualified 55/56').replace('ratio56_to54','ratio56_to55')
 if name.startswith('publish'):
  s=s.replace("shutil.copyfile(work / 'paired-build55-56/report.json', bench / 'paired-build.json')","shutil.copyfile(work / 'paired-build55-56/report.json', bench / 'paired-build.json')\nshutil.copyfile(work / 'compiler-phase-56/report.json', bench / 'compiler-phase.json')")
  s=s.replace("('paired-build55-56','paired-build')","('paired-build55-56','paired-build'), ('compiler-phase-56','compiler-phase')")
  s=s.replace("'delivery56-helpers.py'","'delivery56-helpers.py'").replace("'paired-build55-56.py'):","'paired-build55-56.py','measure_compiler56.py'):")
 else:
  s=s.replace("rows = []","""phase = read(work / 'compiler-phase-56/report.json')
facts['COMPILER_PHASE_RESULTS'] = phase['prose']
facts['CACHE_COSTS'] = 'The index reserves 128–131,072 logical head bytes per lifetime analysis and adds eight logical bytes per memo entry. Initialization and collision-chain lookup remain costs; the measured peak RSS records the full process.'
rows = []""")
 (w/name.replace('55','56')).write_text(s)
for name in ['paired-runtime54-55.py','paired-build54-55.py']:
 s=(w/name).read_text().replace('54','PARENT').replace('55','56').replace('PARENT','55')
 s=s.replace("dirs={55:'55-v4',56:'56'}","dirs={55:'55',56:'56'}")
 (w/name.replace('54-55','55-56')).write_text(s)
s=(w/'benchmark_55.py').read_text().replace('55','56')
s=s.replace("prior=json.loads((w/'benchmark-window-54.json')","prior=json.loads((w/'benchmark-window-55.json')")
start=s.index(' cmd=[');end=s.index(';start=time.monotonic()',start)
s=s[:start]+" cmd=[v.replace('bench-snapshot-55','bench-snapshot-56').replace('install-55','install-56').replace('goose-examples-55','goose-examples-56').replace('goose-host-55','goose-host-56') for v in old['command']]"+s[end:]
(w/'benchmark_56.py').write_text(s)
