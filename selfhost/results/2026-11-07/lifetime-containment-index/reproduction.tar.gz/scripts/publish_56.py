from pathlib import Path
import collections, gzip, hashlib, io, json, tarfile, shutil, subprocess, sys

root = Path('/home/jacobt/src/goose-to-wasm')
work = root / 'build/completion-runs'
bench = root / 'bench/results/2026-11-07/lifetime-containment-index'
checks = root / 'selfhost/results/2026-11-07/lifetime-containment-index'

def read(path): return json.loads(path.read_text())
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path, value): path.write_text(json.dumps(value, indent=2) + '\n')
def gzcopy(source, target): target.write_bytes(gzip.compress(source.read_bytes(), mtime=0))

native = read(work / 'native-runtime-49-final/report.json')
assert len(native['runs']) == 45 and all(r['returncode'] == 0 for r in native['runs'])
examples = read(work / 'goose-examples-56/report.json')
host = read(work / 'goose-host-56/report.json')
full = read(work / 'c-only-conformance-56-qualified/report.json')
v8 = read(work / 'c-only-v8-56-qualified/report.json')
proof = read(work / 'c-only-bootstrap-56/report.json')
comparison = read(work / 'comparison-56.json')
for name in ('storage.h', 'pools.h', 'relative.h', 'images.h', 'runs.h'):
    assert native['inputs_sha256'][name] == proof['asset_sha256']['native/' + name]
assert native['inputs_sha256']['bounded_cells.c'] == sha(work / 'snapshot-56/native/tests/bounded_cells.c')
assert examples['status'] == host['status'] == v8['status'] == proof['status'] == 'passed'
assert full['summary']['selected'] == sum(len(r['levels']) for r in read(root / 'tests/conformance/cases.json')['cases'])
assert not comparison['shared_regressions'] and not comparison['new_failures']
assert len(examples['observations']) == 410
assert len(host['observations']) == 360 and len(host['preparation']) == 150
assert proof['fixed_point'] and proof['executable_c_sha256'] == proof.get('third_generation_c_sha256', proof['next_generation_c_sha256'])
assert examples['environment']['compiler_sha256'] == proof['executable_sha256']
for name in ('check.py','var_relative.c','bounded_cells.c','runs.c'):
    key = name if name != 'check.py' else None
    if key: assert native['inputs_sha256'][key] == sha(work / 'snapshot-56/native/tests' / name)
for report in (full, v8, proof): assert report['input_sha256'] == report['input_sha256_after']
for pins in (examples['environment']['input_sha256'], host['input_sha256']):
    for name, identity in pins.items(): assert sha(Path(name)) == identity, name
for row in host['preparation']: assert sha(Path(row['artifact'])) == row['sha256']

# Resume only an uncommitted publication preflight; delivered records are immutable.
assert not subprocess.check_output(['git', 'ls-files', '--', str(bench.relative_to(root)), str(checks.relative_to(root))], cwd=root).strip(), 'evidence paths are already tracked'
bench.mkdir(parents=True, exist_ok=True)
checks.mkdir(parents=True, exist_ok=True)
for source, target in [('goose-examples-56/report.json', 'examples.json'),
                       ('goose-host-56/report.json', 'host.json'),
                       ('benchmark-window-56.json', 'window.json')]:
    shutil.copyfile(work / source, bench / target)
shutil.copyfile(work / 'paired-runtime55-56/report.json', bench / 'paired-runtime.json')
shutil.copyfile(work / 'paired-build55-56/report.json', bench / 'paired-build.json')
shutil.copyfile(work / 'compiler-phase-56/report.json', bench / 'compiler-phase.json')
shutil.copyfile(work / 'wasm-artifact-check-56.json', bench / 'wasm-artifacts.json')
assert read(work / 'delivery-56-review-ready.json')['status'] == 'passed'
rows = []
for example in examples['examples']:
    name = example['name']
    rows.append({'name': name,
        'build_ms': {r['backend']: r['wall_seconds']['median'] * 1000
            for r in examples['compile_summary'] if r['name'] == name},
        'process_ms': {r['backend'] + '/' + r['mode']: r['wall_seconds']['median'] * 1000
            for r in host['runtime_summary'] if r['name'] == name}})
save(bench / 'summary.json', {'schema': 'goose-compiler-benchmarks-v1',
    'source_base_commit': read(work / 'delivery-56.json')['base_commit'],
    'compiler_snapshot': '56', 'source_sha256': proof['source_sha256'],
    'asset_sha256': proof['asset_sha256'], 'stdlib_sha256': proof['stdlib_sha256'],
    'bootstrap_c_sha256': proof['executable_c_sha256'], 'compiler_sha256': proof['executable_sha256'],
    'compiler_builds': 'Both measured cohorts use the exact qualified executable.',
    'examples_status': examples['status'], 'host_status': host['status'],
    'compile_samples': 5, 'runtime_samples': 5, 'preparation_samples': 5,
    'compiler_comparison': 'Both targets use the Goose-written compiler. Native uses its C backend at GCC O2. Prior snapshots are separately collected references.',
    'rows': rows})

for folder, name in [('native-runtime-49-final', 'native-runtime'), ('c-only-bootstrap-56', 'bootstrap'), ('c-only-bootstrap-55', 'parent-bootstrap'),
                     ('c-only-conformance-56-qualified', 'conformance'), ('c-only-v8-56-qualified', 'v8')]:
    gzcopy(work / folder / 'report.json', checks / (name + '.json.gz'))
gzcopy(work / 'public-56/build/bootstrap/report.json', checks / 'public-bootstrap.json.gz')
shutil.copyfile(work / 'public-56/build/smoke/report.json', checks / 'public-smoke.json')
cross = read(work / 'public-cross-56/report.json')
assert cross['status'] == 'passed' and cross['c_sha256'] == proof['executable_c_sha256']
shutil.copyfile(work / 'public-cross-56/report.json', checks / 'public-cross.json')
failures = [r for r in full['results'] if r['status'] != 'pass']
threads = [r for r in full['results'] if r['case'].startswith('upstream/threads/')]
case_targets = {r['id']: r['target'] for r in read(root / 'tests/conformance/cases.json')['cases']}
curated_wasm = [r for r in v8['results'] if case_targets[r['case']] == 'wasm-direct']
curated_native = [r for r in v8['results'] if case_targets[r['case']] == 'native']
assert len(curated_wasm) + len(curated_native) == v8['summary']['selected']
assert all(r['status'] == 'pass' for r in curated_wasm + curated_native)
expected_thread_rows = sum(len(case['levels']) for case in read(root / 'tests/conformance/cases.json')['cases'] if case['id'].startswith('upstream/threads/'))
assert len(threads) == expected_thread_rows and all(r['status'] == 'pass' for r in threads)
save(checks / 'summary.json', {'schema': 'goose-compiler-qualification-v1',
    'snapshot': '56', 'complete': not failures, 'bootstrap_status': proof['status'],
    'bootstrap_c_sha256': proof['executable_c_sha256'], 'source_sha256': proof['source_sha256'],
    'asset_sha256': proof['asset_sha256'], 'compiler_sha256': proof['executable_sha256'],
    'public_compiler_sha256': cross['compiler_sha256'], 'public_same_path_c_sha256': cross['c_sha256'],
    'fixed_point_scope': 'Consecutive C generations match; the parent seed is verified snapshot55.',
    'contracts': full['summary'], 'original_contract_rows': 5043, 'curated_v8_driver': v8['summary'], 'curated_wasm_per_engine': len(curated_wasm), 'curated_native_controls': len(curated_native), 'native_thread_checks': len(threads),
    'existing_contract_gains': len(comparison['shared_gains']), 'existing_contract_regressions': 0,
    'new_contract_rows': len(comparison['new_rows']), 'new_contract_failures': 0,
    'remaining_failure_phases': dict(collections.Counter(r['phase'] for r in failures)),
    'remaining_runtime_failure_detail': read(work / 'remaining-phases-56.json'),
    'remaining_failure_groups': dict(collections.Counter('/'.join(r['case'].split('/')[:2]) for r in failures)),
    'gains': comparison['shared_gains'],
    'permanent_controls': dict(read(work / 'new-controls-56.json'), status='all migrated controls passed in current composed qualification'),
    'scope': read(work / 'delivery-56.json')['scope'],
    'native_runtime_reference': 'Native header and permanent direct C test inputs match snapshot49 exactly; its qualified 45-command suite is reused. Checker, emission and runtime contracts are freshly qualified.'})

if '--reports-only' in sys.argv:
    print('Fresh56 reports published; capsules pending final rendered copy',flush=True)
    raise SystemExit(0)

def archive(path, files):
    missing={name:str(p) for name,p in files.items() if not p.is_file()};assert not missing,missing
    with path.open('wb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', mtime=0) as zipped, tarfile.open(fileobj=zipped, mode='w|') as bundle:
        seen = {}
        for name, source in sorted(files.items()):
            data = source.read_bytes(); identity = hashlib.sha256(data).hexdigest()
            item = tarfile.TarInfo(name); item.mode = 0o644
            if identity in seen:
                item.type = tarfile.LNKTYPE; item.linkname = seen[identity]; bundle.addfile(item)
            else:
                item.size = len(data); bundle.addfile(item, io.BytesIO(data)); seen[identity] = name

files = {}
for folder, prefix in [('goose-examples-56', 'examples'), ('goose-host-56', 'host'), ('paired-runtime55-56', 'paired-runtime'), ('paired-build55-56','paired-build'), ('compiler-phase-56','compiler-phase')]:
    for path in (work / folder).rglob('*'):
        if path.is_file(): files[prefix + '/' + path.relative_to(work / folder).as_posix()] = path
for pins in (examples['environment']['input_sha256'], host['input_sha256']):
    for name in pins:
        path = Path(name)
        if path.suffix in ('.goose', '.py', '.mjs', '.json', '.c', '.h', '.gz', '.txt') and path.stat().st_size < 20000000:
            files['inputs/' + sha(path) + '/' + path.name] = path
for name in ('LICENSE', 'NOTICE'): files['native/runtime/' + name] = work / 'snapshot-56/native/runtime' / name
archive(bench / 'measurements.tar.gz', files)

files = {}
for path in (work / 'verified-seed-55').iterdir(): files['parent-seed/' + path.name] = path
for path in (work / 'snapshot-56').rglob('*'):
    if path.is_file() and '__pycache__' not in path.parts: files['sources/' + path.relative_to(work / 'snapshot-56').as_posix()] = path
for name in ('conformance_shards.py', 'front_gate.py', 'freeze_seed.py'):
    files['scripts/' + name] = work / 'durable-tools' / name
files['scripts/publish_56.py'] = Path(__file__)
files['notes/delivery-56.json'] = work / 'delivery-56.json'
for name in ('prepare_delivery_v3.py', 'render_copy_56.py', 'compare_delivery_v2.py'): files['scripts/' + name] = work / name
for index in range(4):
    folder = work / 'c-only-conformance-56-qualified'
    gzcopy(folder / ('shard-' + str(index)) / 'report.json', checks / ('conformance-shard-' + str(index) + '.json.gz'))
    files['qualification/cases-' + str(index) + '.json'] = folder / ('cases-' + str(index) + '.json')
for name in read(work / 'delivery-56.json')['notes']:
    files['notes/' + name] = work / name
for name in ('cases.json',): files['qualification/' + name] = root / 'tests/conformance' / name
for name in read(work / 'new-controls-56.json')['sources']: files['qualification/' + name] = root / name
files['qualification/conformance.py'] = root / 'tests/conformance.py'
for path in (work / 'readme-copy-56').iterdir():
    if path.is_file(): files['copy/' + path.name] = path
# Include selected source, controls, raw targeted reports and rejected checkpoints.
for folder in read(work / 'delivery-56.json')['components']:
    for path in (work / folder).rglob('*'):
        if path.is_file() and '__pycache__' not in path.parts and path.suffix in ('.goose', '.h', '.c', '.py', '.json', '.md', '.patch', '.stdout', '.stderr', '.txt', '.log', '.gdb', '.mjs'):
            parts = path.relative_to(work / folder).parts
            if 'artifacts' in parts: continue
            if path.suffix == '.c' and path.name not in ('runs.c', 'bounded_cells.c') and not ('source' in parts and 'native' in parts and 'tests' in parts) and not ('controls' in parts): continue
            if 'upstream' in path.relative_to(work / folder).parts: continue
            files['components/' + folder + '/' + path.relative_to(work / folder).as_posix()] = path
for name in ('public-smoke-56.py', 'compare_delivery_v2.py', 'benchmark_56.py', 'stage_56.py', 'install_56.py', 'public-cross56.py', 'migrate_controls56.py', 'reproduce_delivery_v4.py', 'qualify_56.py', 'assemble_delivery_v3.py', 'qualification56-sequence.py', 'audit56.py', 'paired-runtime55-56.py'):
    files['scripts/' + name] = work / name
for name in ('helpers56.py','delivery56-helpers.py','measure56-window.py','final-stage-preflight-56.py','paired-build55-56.py','measure_compiler56.py'):
    files['scripts/' + name] = work / name
archive(checks / 'reproduction.tar.gz', files)
print('published evidence', bench, checks)
