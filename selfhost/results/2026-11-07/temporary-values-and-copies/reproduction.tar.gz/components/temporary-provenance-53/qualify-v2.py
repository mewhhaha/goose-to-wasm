from pathlib import Path
import concurrent.futures,hashlib,json,subprocess,time
root=Path('/home/jacobt/src/goose-to-wasm');w=root/'build/completion-runs/temporary-provenance-53';compiler=w/'build-v2/goose'
assert json.loads((w/'build-v2/report.json').read_text())['status']=='passed'
manifest=w/'controls-manifest-v3.json'
def run(name,cmd):
 start=time.monotonic();r=subprocess.run(list(map(str,cmd)),cwd=root,capture_output=True,timeout=240)
 (w/(name+'.stdout')).write_bytes(r.stdout);(w/(name+'.stderr')).write_bytes(r.stderr)
 return dict(name=name,command=list(map(str,cmd)),exit_code=r.returncode,seconds=time.monotonic()-start)
base=['python',root/'tests/conformance.py','--compiler',compiler,'--manifest',manifest,'--timeout','30']
checks=run('final-checks-v2',base+['--output-dir',w/'final-checks-v2','--frontend-only','--levels','0']);assert checks['exit_code']==0,checks
jobs=[('final-wasmtime-v2',base+['--output-dir',w/'final-wasmtime-v2','--engine','wasmtime']),('final-v8-v2',base+['--output-dir',w/'final-v8-v2','--filter','/wasm-direct','--engine','v8']),('final-front-v2',['python',root/'build/completion-runs/durable-tools/front_gate.py',compiler,w/'front-baseline52',w/'final-front-v2']),('final-own-source-v2',[compiler,w/'source-v2/selfhost/main.goose','--stdlib',root/'stdlib','--target','native','--check'])]
results=[checks]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 for result in pool.map(lambda row:run(*row),jobs):results.append(result);print(result['name'],result['exit_code'],round(result['seconds'],2),flush=True)
(w/'final-commands-v2.json').write_text(json.dumps(results,indent=2)+'\n');assert all(r['exit_code']==0 for r in results),results
front=json.loads((w/'final-front-v2/comparison.json').read_text());assert not any(r['regressions'] for r in front.values()),front
pins=json.loads((w/'source-v2-final-pins-before.json').read_text());after={name:hashlib.sha256(Path(name).read_bytes()).hexdigest() for name in pins};assert pins==after
(w/'source-v2-final-pins-after.json').write_text(json.dumps(after,indent=2)+'\n')
(w/'seal-v2.json').write_text(json.dumps(dict(status='passed',baseline='snapshot-52',source='source-v2',patch='candidate-v2.patch',compiler='build-v2/goose',source_pins_equal=True,frontier=front,checks=json.loads((w/'final-checks-v2/report.json').read_text())['summary'],wasmtime=json.loads((w/'final-wasmtime-v2/report.json').read_text())['summary'],v8=json.loads((w/'final-v8-v2/report.json').read_text())['summary'],own_source=next(r for r in results if r['name']=='final-own-source-v2')),indent=2)+'\n')
print('SEALED',flush=True)
