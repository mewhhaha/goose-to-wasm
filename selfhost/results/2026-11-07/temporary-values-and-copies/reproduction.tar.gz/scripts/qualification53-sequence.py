from pathlib import Path
import concurrent.futures,json,subprocess,time
root=Path('/home/jacobt/src/goose-to-wasm');w=root/'build/completion-runs'
def wait_report(p):
 for attempt in range(600):
  if p.exists():
   r=json.loads(p.read_text())
   if r['status']=='passed':return
   assert r['status']!='failed',(str(p),r.get('error'))
  time.sleep(2)
 raise RuntimeError('Report not ready: '+str(p))
def run(script):
 print('Starting',script,flush=True)
 with (w/(script+'.log')).open('w') as log:r=subprocess.run(['python',str(w/script)],cwd=root,stdout=log,stderr=subprocess.STDOUT)
 assert r.returncode==0,(script,r.returncode)
 print('Passed',script,flush=True)
def public_post():
 wait_report(w/'public-53/build/bootstrap/report.json')
 run('public-smoke-53.py');run('public-cross53.py')
wait_report(w/'c-only-bootstrap-53/report.json')
wait_report(w/'delivery-53-review-ready.json')
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 futures=[pool.submit(run,'qualify_53.py'),pool.submit(public_post)]
 for f in concurrent.futures.as_completed(futures):f.result()
print('All53 qualification stages passed',flush=True)
