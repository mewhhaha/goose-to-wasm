from pathlib import Path
import concurrent.futures,json,os,shutil,subprocess
root=Path('/home/jacobt/src/goose-to-wasm');w=root/'build/completion-runs';proof=json.loads((w/'c-only-bootstrap-53/report.json').read_text());assert proof['status']=='passed' and proof['fixed_point']
def run(label,cmd,env=None):
 with (w/(label+'.log')).open('w') as log:r=subprocess.run(list(map(str,cmd)),cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 return label,r.returncode
for label,cmd in [('freeze-53',['python',w/'durable-tools/freeze_seed.py',w/'c-only-bootstrap-53',w/'verified-seed-53']),('prepare-53',['python',w/'prepare_delivery_v2.py','53']),('reproduce-53',['python',w/'reproduce_delivery_v3.py','53'])]:
 result=run(label,cmd);assert result[1]==0,result
install=w/'install-53/bin';install.mkdir(parents=True,exist_ok=False);shutil.copyfile(w/'c-only-bootstrap-53/goose',install/'goose');(install/'goose').chmod(0o755);shutil.copytree(root/'stdlib',install/'stdlib')
env=dict(os.environ,PATH='/usr/bin:/bin');env.pop('TMPDIR',None)
jobs=[('conformance-53',['python',w/'durable-tools/conformance_shards.py','--compiler',w/'c-only-bootstrap-53/goose','--output-dir',w/'c-only-conformance-53-qualified','--jobs','4'],None),('v8-53',['python',root/'tests/conformance.py','--compiler',w/'c-only-bootstrap-53/goose','--output-dir',w/'c-only-v8-53-qualified','--filter','corpus/','--engine','v8'],None),('public-bootstrap-53',['/usr/bin/python3',w/'public-53/scripts/bootstrap.py','--verify'],env)]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 futures=[pool.submit(run,*j) for j in jobs]
 for f in concurrent.futures.as_completed(futures):print(f.result(),flush=True)
full=json.loads((w/'c-only-conformance-53-qualified/report.json').read_text());assert 'summary' in full
assert json.loads((w/'c-only-v8-53-qualified/report.json').read_text())['status']=='passed'
assert json.loads((w/'public-53/build/bootstrap/report.json').read_text())['status']=='passed'
result=run('compare-53',['python',w/'compare_batch_qualified45.py','53']);assert result[1]==0,result
comparison=json.loads((w/'comparison-53.json').read_text());assert not comparison['shared_regressions'] and not comparison['new_failures']
counts=dict(compiler_refusal=0,c_compiler_failure=0,executed_mismatch=0)
for row in full['results']:
 if row['status']=='pass' or row['phase']!='run':continue
 if full['commands'][row['compile_command']]['exit_code']!=0:counts['compiler_refusal']+=1
 elif 'run_command' not in row:counts['c_compiler_failure']+=1
 else:counts['executed_mismatch']+=1
(w/'remaining-phases-53.json').write_text(json.dumps(counts,indent=2)+'\n')
print('Qualified53',full['summary'],counts,flush=True)
