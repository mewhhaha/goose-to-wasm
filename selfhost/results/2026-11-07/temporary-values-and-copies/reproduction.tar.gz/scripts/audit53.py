from pathlib import Path
import hashlib,json,subprocess
root=Path('/home/jacobt/src/goose-to-wasm');w=root/'build/completion-runs'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
config=read(w/'delivery-53.json');parent=read(w/'c-only-bootstrap-52/report.json');proof=read(w/'c-only-bootstrap-53/report.json');assembly=read(w/'snapshot-53-assembly.json')
assert config['base_commit']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert proof['status']=='passed' and proof['fixed_point']
changed=sorted(k for k in parent['source_sha256'] if parent['source_sha256'][k]!=proof['source_sha256'][k]);assert changed==['checker_lifetimes.goose','codegen.goose'],changed
assert proof['source_sha256']['checker_lifetimes.goose']=='0a65c6d9a92c4886ca21ea6dd0ce3d69868aae722e23a694814e3c089ce62be6'
assert proof['source_sha256']['codegen.goose']=='632747b97c8c477d13adfd170e4ab09d7f902040d2199c4061e243c05314ffbe'
assert proof['asset_sha256']==parent['asset_sha256']
for name,value in assembly['sha256'].items():assert sha(w/'snapshot-53'/name)==value,name
native=read(w/'native-runtime-49-final/report.json');assert len(native['runs'])==45 and all(x['returncode']==0 for x in native['runs'])
assert native['driver_sha256']==sha(w/'snapshot-53/native/tests/check.py')
for name in ['runs.c','bounded_cells.c','var_relative.c']:assert native['inputs_sha256'][name]==sha(w/'snapshot-53/native/tests'/name)
for name,value in read(w/'new-controls-53.json')['sources'].items():assert sha(root/name)==value,name
old=json.loads(subprocess.check_output(['git','show',config['base_commit']+':tests/conformance/cases.json'],cwd=root));new=read(root/'tests/conformance/cases.json');byid={x['id']:x for x in new['cases']};assert len(byid)==len(new['cases'])
for case in old['cases']:assert byid[case['id']]==case,case['id']
assert read(w/'astra-temporary-provenance-53-native-wasmtime/report.json')['summary']==dict(selected=8,passed=8,failed=0)
assert read(w/'astra-temporary-provenance-53-v8/report.json')['summary']==dict(selected=4,passed=4,failed=0)
comparison=read(w/'comparison-53.json');assert not comparison['shared_regressions'] and not comparison['new_failures'] and len(comparison['shared_gains'])==4 and len(comparison['new_rows'])==92
limitation=read(w/'temporary-provenance-53/separate-low-memory-limitation.json');assert 'unresolved' in limitation['status']
report=dict(status='passed',parent_commit=config['base_commit'],compiler_changes=changed,source_sha256=proof['source_sha256'],unchanged_native_assets=proof['asset_sha256'],prior_manifest_rows_preserved=sum(len(x['levels']) for x in old['cases']),new_rows=92,independent_guard_rows=dict(native_and_wasmtime=8,v8_wasm=4),native_header_reference='Exact unchanged49 source/driver/tests; all45qualifiedcommands reused.',component_metadata_note='Nested source-v2/source-pins.json retains two stale baseline entries; immutable final before/after/build pins, independent review, root58file assembly and canonical proof bind actual source. No stale map used as root source authority.',separate_resource_limitation=dict(receipt_sha256=sha(w/'temporary-provenance-53/separate-low-memory-limitation.json'),status=limitation['status'],scope='Oneiteration passes2pages;10000trap. Exact by-value sibling trapsbaseline52andcandidateO0/O2. Failedstressnotcountedpassing;noequalallocationvolume/reclamationclaim.'),source_review_sha256=sha(w/'astra-temporary-provenance-53-2026-11-07/source-review.json'),no_oracle_execution=True)
(w/'composition53-audit.json').write_text(json.dumps(report,indent=2)+'\n');print('Root53 source/manifest/header/guards audit passed; low-memory limitation retained')
