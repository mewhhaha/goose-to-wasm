from pathlib import Path
import hashlib,json,resource,statistics,subprocess,time
root=Path('/home/jacobt/src/goose-to-wasm');w=root/'build/completion-runs/temporary-retirement-54';m=json.loads((w/'controls-manifest-v3.json').read_text());compilers=[('baseline',root/'build/completion-runs/c-only-bootstrap-53/goose'),('candidate',w/'build-v1/goose')];out=w/'compile-measurement';out.mkdir();rows=[]
for case in m['cases']:
 if case['target']!='wasm-direct' or case['phase']!='run':continue
 for level in case['levels']:
  observations={label:[] for label,_ in compilers};artifacts={};commands={}
  for iteration in range(-1,7):
   order=compilers
   if iteration%2:order=list(reversed(compilers))
   for label,compiler in order:
    artifact=out/(label+'.wasm');cmd=[compiler,root/case['source'],'--stdlib',root/'stdlib','--target','wasm-direct','--standalone','-O'+str(level),'-o',artifact]
    if 'maximum_pages' in case:cmd+=['--wasm-initial-pages','1','--wasm-max-pages',str(case['maximum_pages'])]
    start_cpu=resource.getrusage(resource.RUSAGE_CHILDREN);start=time.perf_counter_ns();r=subprocess.run(list(map(str,cmd)),capture_output=True);elapsed=time.perf_counter_ns()-start;end_cpu=resource.getrusage(resource.RUSAGE_CHILDREN);assert r.returncode==0,(case['id'],label,r.stderr)
    if iteration>=0:observations[label].append(dict(wall_ns=elapsed,cpu_ns=int(1e9*((end_cpu.ru_utime+end_cpu.ru_stime)-(start_cpu.ru_utime+start_cpu.ru_stime)))))
    artifacts[label]=dict(sha256=hashlib.sha256(artifact.read_bytes()).hexdigest(),bytes=artifact.stat().st_size);commands[label]=list(map(str,cmd))
  row=dict(case=case['id'],level=level,source=case['source'],source_sha256=hashlib.sha256((root/case['source']).read_bytes()).hexdigest(),maximum_pages=case.get('maximum_pages'),commands=commands,artifacts=artifacts,observations=observations,medians={label:{name:statistics.median(o[name] for o in observations[label]) for name in ('wall_ns','cpu_ns')} for label,_ in compilers})
  row['candidate_baseline_cpu_ratio']=row['medians']['candidate']['cpu_ns']/row['medians']['baseline']['cpu_ns'];row['candidate_baseline_wall_ratio']=row['medians']['candidate']['wall_ns']/row['medians']['baseline']['wall_ns'];rows.append(row)
pins={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),w/'controls-manifest-v3.json',*(p for _,p in compilers),*list((root/'stdlib').glob('*.goose'))]};(w/'compile-measurement.json').write_text(json.dumps(dict(method='One warmup then7 interleaved fresh compiler processes per source/O0/O2. Child CPU and wall nanoseconds; identical source/stdlib/options and requested memory limit. No runtime executed here.',input_sha256=pins,rows=rows),indent=2)+'\n');print('rows',len(rows),flush=True)
