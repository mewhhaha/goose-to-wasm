import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { runModule } from './run_wasm_memory.mjs';
const root = '/home/jacobt/src/goose-to-wasm/';
const work = root + 'build/completion-runs/temporary-retirement-54/';
const before = JSON.parse(readFileSync(work + 'baseline-controls/report.json'));
const after = JSON.parse(readFileSync(work + 'candidate-wasmtime/report.json'));
const manifest = JSON.parse(readFileSync(work + 'controls-manifest-v3.json'));
const contracts = new Map(manifest.cases.map(c => [c.id,c]));
const sha = data => createHash('sha256').update(data).digest('hex');
const median = values => [...values].sort((a,b) => a-b)[Math.floor(values.length/2)];
const inputPaths = [process.execPath, work+'run_wasm_memory.mjs', work+'measure_memory_runtime.mjs', root+'scripts/run_wasm.mjs', work+'controls-manifest-v3.json', root+'build/completion-runs/c-only-bootstrap-53/goose', work+'build-v1/goose'];
const inputSha256 = Object.fromEntries(inputPaths.map(path => [path,sha(readFileSync(path))]));
const result = { input_sha256: inputSha256, method: 'Same pinned source and contract; fresh module instance each run; two warmups then seven interleaved V8 runs. Wasm page counts are monotonic, so final equals peak. Timing ratios only for both-correct rows.', node: process.version, v8: process.versions.v8, rows: [] };
for (let index=0;index<after.results.length;index++) {
  const current=after.results[index];const previous=before.results[index];const contract=contracts.get(current.case);
  if (contract.target!=='wasm-direct'||current.phase!=='run') continue;
  const runs = [];
  for (const [label,report,row] of [['baseline',before,previous],['candidate',after,current]]) {
    const command=report.commands[row.compile_command].command;const at=command.indexOf('-o');
    const path=command[at+1];const bytes=readFileSync(path);
    runs.push({label,path,bytes,sha256:sha(bytes),observations:[]});
  }
  for (let round=-2;round<7;round++) {
    let order=runs;if ((round&1)!==0) order=[runs[1],runs[0]];
    for (const item of order) {
      const measured=await runModule(item.bytes,contract.stdin||'');
      if (round>=0) item.observations.push({exitCode:measured.exitCode,stdout:measured.stdout.toString(),stderr:measured.stderr,memory:measured.memory,timing:measured.timing});
    }
  }
  const row={case:current.case,level:current.level,source:contract.source,source_sha256:sha(readFileSync(root+contract.source)),expected:contract.expect,maximum_pages:contract.maximum_pages,runs:[]};
  for (const item of runs) {
    const correct=item.observations.every(o=>{
      let exit=o.exitCode===contract.expect.exit;if(contract.expect.exit==='nonzero') exit=o.exitCode!==0;
      return exit&&o.stdout===contract.expect.stdout;
    });
    row.runs.push({label:item.label,path:item.path,sha256:item.sha256,bytes:item.bytes.length,correct,median_start_function_ns:median(item.observations.map(o=>o.timing.start_function_ns)),median_compile_instantiate_ns:median(item.observations.map(o=>o.timing.compile_instantiate_ns)),observations:item.observations});
  }
  if (row.runs.every(r=>r.correct)) row.candidate_baseline_runtime_ratio=row.runs[1].median_start_function_ns/row.runs[0].median_start_function_ns;
  row.candidate_baseline_size_ratio=row.runs[1].bytes/row.runs[0].bytes;result.rows.push(row);
}
writeFileSync(work+'memory-runtime-measurement.json',JSON.stringify(result,null,2)+'\n');
process.stdout.write(JSON.stringify({rows:result.rows.length,candidate_correct:result.rows.filter(r=>r.runs[1].correct).length})+'\n');
