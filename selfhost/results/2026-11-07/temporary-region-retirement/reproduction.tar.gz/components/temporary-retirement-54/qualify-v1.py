from pathlib import Path
import concurrent.futures,hashlib,json,subprocess,time
root=Path('/home/jacobt/src/goose-to-wasm');w=root/'build/completion-runs/temporary-retirement-54';compiler=w/'build-v1/goose';baseline=root/'build/completion-runs/c-only-bootstrap-53/goose';manifest=w/'controls-manifest-v3.json'
assert json.loads((w/'build-v1/report.json').read_text())['status']=='passed'
pins={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [*w.glob('source/**/*'),manifest,*w.glob('*expected-before-execution.json')] if p.is_file()}
for case in json.loads(manifest.read_text())['cases']:
 p=root/case['source'];pins[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
(w/'qualification-pins-before.json').write_text(json.dumps(pins,indent=2)+'\n')
def run(name,cmd):
 start=time.monotonic();r=subprocess.run(list(map(str,cmd)),cwd=root,capture_output=True,timeout=240);(w/(name+'.stdout')).write_bytes(r.stdout);(w/(name+'.stderr')).write_bytes(r.stderr);return dict(name=name,command=list(map(str,cmd)),exit_code=r.returncode,seconds=time.monotonic()-start)
base=['python',root/'tests/conformance.py','--manifest',manifest,'--timeout','30']
checks=run('checks-v1',base+['--compiler',compiler,'--output-dir',w/'checks-v1','--frontend-only','--levels','0']);print('checks',checks['exit_code'],flush=True)
jobs=[('baseline-controls',base+['--compiler',baseline,'--output-dir',w/'baseline-controls','--engine','wasmtime']),('candidate-wasmtime',base+['--compiler',compiler,'--output-dir',w/'candidate-wasmtime','--engine','wasmtime']),('candidate-v8',base+['--compiler',compiler,'--output-dir',w/'candidate-v8','--filter','/wasm-direct','--engine','v8']),('front-v1',['python',root/'build/completion-runs/durable-tools/front_gate.py',compiler,root/'build/completion-runs/temporary-provenance-53/final-front-v2',w/'front-v1']),('own-selfemit-v1',[compiler,w/'source/selfhost/main.goose','--stdlib',root/'stdlib','--target','native','--standalone','-O0','-o',w/'own-compiler-v1.c'])]
results=[checks]
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
 for result in pool.map(lambda row:run(*row),jobs):results.append(result);print(result['name'],result['exit_code'],round(result['seconds'],2),flush=True)
(w/'qualification-commands-v1.json').write_text(json.dumps(results,indent=2)+'\n')
after={name:hashlib.sha256(Path(name).read_bytes()).hexdigest() for name in pins};assert pins==after;(w/'qualification-pins-after.json').write_text(json.dumps(after,indent=2)+'\n')
selfemit=next(r for r in results if r['name']=='own-selfemit-v1');same=False
if selfemit['exit_code']==0:
 same=(w/'own-compiler-v1.c').read_bytes()==(w/'build-v1/compiler.c').read_bytes()
(w/'own-fixedpoint-v1.json').write_text(json.dumps(dict(exit_code=selfemit['exit_code'],seconds=selfemit['seconds'],generated_c_equal=same,input_c_sha256=hashlib.sha256((w/'build-v1/compiler.c').read_bytes()).hexdigest(),self_c_sha256=hashlib.sha256((w/'own-compiler-v1.c').read_bytes()).hexdigest() if selfemit['exit_code']==0 else None),indent=2)+'\n')
print('FIXEDPOINT',same,flush=True)
