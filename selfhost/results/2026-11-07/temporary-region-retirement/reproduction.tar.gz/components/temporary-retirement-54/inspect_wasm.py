from pathlib import Path
import hashlib,json,sys

def unsigned(data,at):
 value=0;shift=0
 while True:
  byte=data[at];at+=1;value|=(byte&127)<<shift;shift+=7
  if byte<128:return value,at

def signed(data,at):
 value=0;shift=0
 while True:
  byte=data[at];at+=1;value|=(byte&127)<<shift;shift+=7
  if byte<128:
   if byte&64:value-=1<<shift
   return value,at

def inspect(path):
 data=path.read_bytes();assert data[:8]==b'\0asm\x01\0\0\0';at=8;out=dict(path=str(path),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),memories=[],globals=[])
 while at<len(data):
  section=data[at];size,start=unsigned(data,at+1);end=start+size
  if section==5:
   count,cursor=unsigned(data,start)
   for _ in range(count):
    flags,cursor=unsigned(data,cursor);minimum,cursor=unsigned(data,cursor);maximum=None
    if flags&1:maximum,cursor=unsigned(data,cursor)
    out['memories'].append(dict(minimum_pages=minimum,maximum_pages=maximum))
  if section==6:
   count,cursor=unsigned(data,start);out['defined_global_count']=count
   for index in range(count):
    kind,mutable=data[cursor:cursor+2];cursor+=2;op=data[cursor];cursor+=1;assert op in (0x41,0x42);value,cursor=signed(data,cursor);assert data[cursor]==0x0b;cursor+=1;out['globals'].append(dict(index=index,wasm_type=kind,mutable=mutable,initial=value))
  at=end
 count=out.get('defined_global_count');out['memory_mode']='regions' if count==12 else 'fallback' if count==5 else 'scalar' if count==1 else 'other'
 if count==12:
  values=[g['initial'] for g in out['globals']];out['region_count']=values[8];out['region_bytes']=values[7];out['stack_limit']=values[10];out['initial_live_regions']=values[3]
 return out
if __name__=='__main__':
 root=Path(sys.argv[1]);out=Path(sys.argv[2]);rows=[inspect(p) for p in sorted(root.glob('artifacts/*/program.wasm'))];out.write_text(json.dumps(rows,indent=2)+'\n');print([(r['memory_mode'],r['defined_global_count'],r['memories']) for r in rows])
