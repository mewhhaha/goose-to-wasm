from pathlib import Path
import os,signal,json
rows={}
for p in Path('/proc').iterdir():
 if not p.name.isdecimal():continue
 try:
  a=(p/'cmdline').read_bytes().split(b'\0');s=(p/'stat').read_text().rsplit(')',1)[1].split();rows[int(p.name)]=(int(s[1]),a,s[19])
 except (OSError,IndexError,ValueError):continue
roots=[pid for pid,(_,a,_) in rows.items() if len(a)>1 and a[0].endswith(b'python3') and a[1]==b'build/completion-runs/qualification54-sequence.py'];assert len(roots)==1,roots
selected=set(roots)
while True:
 n=selected|{pid for pid,(pp,_,_) in rows.items() if pp in selected}
 if n==selected:break
 selected=n
receipt=dict(status='superseded before final qualification; no pass claim',reason='Independent review confirmed missing owned builtin call demand inV2. FinalV3 reuses final guards and fully qualifies under separate immutable paths.',processes=[dict(pid=pid,command=[x.decode(errors='replace') for x in rows[pid][1] if x]) for pid in sorted(selected)])
Path('build/completion-runs/qualification54-v2-superseded.json').write_text(json.dumps(receipt,indent=2)+'\n')
for pid in sorted(selected,reverse=True):
 try:os.kill(pid,signal.SIGTERM)
 except ProcessLookupError:pass
print('Stopped',len(selected),'supersededV2 qualification processes; receipts preserved; finalV3 bootstrap untouched')
