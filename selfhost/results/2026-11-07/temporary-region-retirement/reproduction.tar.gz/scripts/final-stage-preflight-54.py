from pathlib import Path
import json,hashlib,tarfile,subprocess
r=Path.cwd();w=r/'build/completion-runs';sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda p:json.loads(p.read_text())
p=read(w/'stage-plan-54.json');assert p['status']=='passed'
base=read(w/'delivery-54.json')['base_commit'];assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==base
planned={x['path']:x for x in p['files']};changed=set(subprocess.check_output(['git','diff','--cached','--name-only'],text=True).splitlines());assert changed<=planned.keys()
for name,row in planned.items():
 assert sha(subprocess.check_output(['git','show',':'+name]))==row['sha256'],name
 assert sha(Path(row['source']).read_bytes())==row['sha256'],name
for name,value in read(w/'publication-preflight-54.json')['final_helper_sha256'].items():assert sha((w/name).read_bytes())==value,name
with tarfile.open(r/'selfhost/results/2026-11-07/temporary-region-retirement/reproduction.tar.gz') as t:
 checks={'notes/composition54-v4-audit.json':w/'composition54-v4-audit.json','notes/delivery-54-review-ready.json':w/'delivery-54-review-ready.json','components/astra-retirement-54-source-review/review-v3.json':w/'astra-retirement-54-source-review/review-v3.json','components/temporary-retirement-54-v4/qualification.json':w/'temporary-retirement-54-v4/qualification.json','components/temporary-retirement-54-v4/compile-measurement.json':w/'temporary-retirement-54-v4/compile-measurement.json','components/temporary-retirement-54-v4/memory-runtime-measurement.json':w/'temporary-retirement-54-v4/memory-runtime-measurement.json','components/paired-runtime53-54/report.json':w/'paired-runtime53-54/report.json'}
 checks['components/astra-temporary-call-order-54/plan.json']=w/'astra-temporary-call-order-54/plan.json'
 for name,path in checks.items():assert t.extractfile(name).read()==path.read_bytes(),name
 proof=read(w/'c-only-bootstrap-54-v4/report.json')
 for name,value in proof['source_sha256'].items():assert sha(t.extractfile('sources/selfhost/'+name).read())==value,name
 for name,value in proof['asset_sha256'].items():assert sha(t.extractfile('sources/'+name).read())==value,name
 for name,value in read(w/'new-controls-54.json')['sources'].items():assert sha(t.extractfile('qualification/'+name).read())==value,name
 assert t.extractfile('components/temporary-retirement-54-v4/measure_memory_runtime.mjs').read()==(w/'temporary-retirement-54-v4/measure_memory_runtime.mjs').read_bytes()
 assert t.extractfile('superseded-v2/bootstrap.json').read()==(w/'c-only-bootstrap-54/report.json').read_bytes()
summary=read(r/'selfhost/results/2026-11-07/temporary-region-retirement/summary.json');assert summary['contracts']==dict(selected=7711,passed=7609,failed=102);assert summary['existing_contract_gains']==0 and summary['new_contract_rows']==116
facts=read(r/'bench/results/2026-11-07/temporary-region-retirement/copy-facts.json');assert 'Wasmtime 50.0.1' in facts['METHOD_AND_IDENTITIES'];assert facts['RESOURCE_RESULTS'] and facts['COST_TRADEOFFS']
pair=read(w/'paired-runtime53-54/report.json');assert pair['status']=='passed' and len(pair['commands'])==240 and sum(not row['warmup'] for row in pair['commands'])==200
for name in ('examples-latest.json','wasmtime-host-latest.json'):
 d=read(r/'bench/results'/name);assert d['sha256']==sha((r/'bench/results'/d['report']).read_bytes())
subprocess.run(['git','diff','--cached','--check'],check=True)
assert subprocess.check_output(['git','ls-remote','origin','refs/heads/main'],text=True).split()[0]==base
(w/'final-stage-preflight-54.json').write_text(json.dumps(dict(status='passed',base_commit=base,planned_paths=len(planned),changed_paths=len(changed),capsule_critical_payloads_verified=True,review_and_resource_costs_final_v4=True),indent=2)+'\n')
print('Final54 staged blobs, capsule, source/controls, resource measurements and remote passed:',len(planned),'planned;',len(changed),'changed')
