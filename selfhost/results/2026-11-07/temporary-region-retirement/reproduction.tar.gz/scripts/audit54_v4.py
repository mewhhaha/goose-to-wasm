from pathlib import Path
import hashlib,json,subprocess
root=Path('/home/jacobt/src/goose-to-wasm');w=root/'build/completion-runs'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
config=read(w/'delivery-54.json');parent=read(w/'c-only-bootstrap-53/report.json');proof=read(w/'c-only-bootstrap-54-v4/report.json');assembly=read(w/'snapshot-54-v4-assembly.json')
assert config['base_commit']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert proof['status']=='passed' and proof['fixed_point']
changed=sorted(k for k in parent['source_sha256'] if parent['source_sha256'][k]!=proof['source_sha256'][k]);assert changed==['codegen.goose'],changed
assert proof['source_sha256']['codegen.goose']=='c54e866326bff07e43060b8877676958e69ac3f8c6e1edc83f7dcd8588451e1b'
assert proof['asset_sha256']==parent['asset_sha256']
for name,value in assembly['sha256'].items():assert sha(w/'snapshot-54-v4'/name)==value,name
native=read(w/'native-runtime-49-final/report.json');assert len(native['runs'])==45 and all(x['returncode']==0 for x in native['runs'])
assert native['driver_sha256']==sha(w/'snapshot-54-v4/native/tests/check.py')
for name in ['runs.c','bounded_cells.c','var_relative.c']:assert native['inputs_sha256'][name]==sha(w/'snapshot-54-v4/native/tests'/name)
for name,value in read(w/'new-controls-54.json')['sources'].items():assert sha(root/name)==value,name
old=json.loads(subprocess.check_output(['git','show',config['base_commit']+':tests/conformance/cases.json'],cwd=root));new=read(root/'tests/conformance/cases.json');byid={x['id']:x for x in new['cases']};assert len(byid)==len(new['cases'])
for case in old['cases']:assert byid[case['id']]==case,case['id']
comparison=read(w/'comparison-54-v4.json');assert not comparison['shared_regressions'] and not comparison['new_failures']
assert not comparison['shared_gains'],'Resource-limit gains are newly authored contracts, not recovered existing rows'
resource_cases=[c for c in new['cases'] if c['id'].startswith('corpus/contracts/temporary-region-retirement/') and c.get('maximum_pages') is not None];assert resource_cases and all(c['maximum_pages']==2 for c in resource_cases)
review=read(w/'delivery-54-review-ready.json');assert review['status']=='passed' and review['final_cg_sha256']==proof['source_sha256']['codegen.goose']
report=dict(status='passed',parent_commit=config['base_commit'],compiler_changes=changed,source_sha256=proof['source_sha256'],unchanged_native_assets=proof['asset_sha256'],prior_manifest_rows_preserved=sum(len(x['levels']) for x in old['cases']),new_rows=len(comparison['new_rows']),existing_gains=0,review_ready_sha256=sha(w/'delivery-54-review-ready.json'),bounded_memory_contracts=len(resource_cases),native_header_reference='Exact unchanged49 source/driver/tests; all45 qualified commands reused.',functional_scope='Previously failing two-page temporary workloads now pass. General fallback allocation retirement remains unsupported; region admission gates and live-memory limit remain in force.',final_compile_measurement_sha256=sha(w/'temporary-retirement-54-v4/compile-measurement.json'),no_oracle_execution=True)
(w/'composition54-v4-audit.json').write_text(json.dumps(report,indent=2)+'\n');print('Root54 source/manifest/header/resource audit passed')
