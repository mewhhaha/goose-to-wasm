from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
root=Path('/home/jacobt/src/goose-to-wasm');w=root/'build/completion-runs';os.sched_setaffinity(0,{7})
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
while not (w/'remaining-phases-54-v4.json').exists():time.sleep(2)
assert read(w/'comparison-54-v4.json')['candidate_summary']==dict(selected=7711,passed=7609,failed=102)
assert read(w/'public-cross-54-v4/report.json')['status']=='passed'
assert read(w/'delivery-54-review-ready.json')['status']=='passed'
r=dict(status='running',started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),cpu_affinity=sorted(os.sched_getaffinity(0)),coordination='Native owner explicitly paused; from-end owner focused gates complete/no children and explicitly idle; readonly owner yielded/no costly jobs; Astra source-only review/no execution. Full/public/focused root qualification finished before measurement.',commands=[])
for script,runner in [('benchmark_54.py','python'),('temporary-retirement-54-v4/measure_compile.py','python'),('temporary-retirement-54-v4/measure_memory_runtime.mjs','node'),('paired-runtime53-54.py','python')]:
 cmd=[runner,str(w/script)];start=time.monotonic()
 with (w/(Path(script).name+'.measurement54.log')).open('w') as log:result=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 r['commands'].append(dict(command=cmd,exit_code=result.returncode,seconds=time.monotonic()-start));(w/'measurement-window-54.json').write_text(json.dumps(r,indent=2)+'\n');assert result.returncode==0,(script,result.returncode)
rows=[]
for name in sorted(x['name'] for x in read(w/'goose-examples-54/report.json')['examples']):
 pair=[]
 for version in (53,54):
  obs=[x for x in read(w/f'goose-examples-{version}/report.json')['observations'] if x['kind']=='build' and x['backend']=='direct' and x['name']==name];assert obs and len({x['artifact_sha256'] for x in obs})==1
  for x in obs:assert sha(Path(x['artifact']))==x['artifact_sha256']
  pair.append(obs[0]['artifact_sha256'])
 rows.append(dict(name=name,previous_sha256=pair[0],current_sha256=pair[1],unchanged=pair[0]==pair[1]))
(w/'wasm-artifact-check-54.json').write_text(json.dumps(dict(status='passed',scope='Exact qualified53/final54V3 full-cohort Wasm artifacts; path identities and source/tool pins retained.',previous_report_sha256=sha(w/'goose-examples-53/report.json'),current_report_sha256=sha(w/'goose-examples-54/report.json'),rows=rows),indent=2)+'\n')
r.update(status='passed',ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());(w/'measurement-window-54.json').write_text(json.dumps(r,indent=2)+'\n');print('Final54 fresh/paired/targeted measurement window passed',flush=True)
