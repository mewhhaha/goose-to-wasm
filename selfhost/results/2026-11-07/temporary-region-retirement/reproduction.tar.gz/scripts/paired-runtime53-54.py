from pathlib import Path
import datetime,hashlib,json,os,random,statistics,subprocess,time
root=Path('/home/jacobt/src/goose-to-wasm');w=root/'build/completion-runs';out=w/'paired-runtime53-54';out.mkdir(exist_ok=False);os.sched_setaffinity(0,{7})
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
reports={v:read(w/f'goose-host-{v}/report.json') for v in [53,54]};pins={};commands={};goldens={}
for version,r in reports.items():
 assert r['status']=='passed'
 assert r['host_build']['host_sha256']==reports[53]['host_build']['host_sha256'] and r['aot_host_build']['host_sha256']==reports[53]['aot_host_build']['host_sha256']
 for name,h in r['input_sha256'].items():
  if name in pins:assert pins[name]==h,name
  pins[name]=h
 for x in r['observations']:
  if x['phase']=='measure' and x['sample']==0 and x['mode'] in ['precompiled-minimal','native-C']:
   commands[version,x['name'],x['mode']]=x['command'];goldens[x['name']]=x['stdout_sha256']
   if x['mode']=='precompiled-minimal':
    path=x['command'][2];matched=[p for p in r['preparation'] if p['artifact']==path];assert len(matched)==1,path;pins[path]=matched[0]['sha256']
for p,h in pins.items():assert sha(Path(p))==h,p
report=dict(status='running',started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Interleaved fresh-process minimal AOT and native controls for exact qualified53/54 artifacts; same host/engine bytes, CPU7, all coding owners explicitly quiet, five measured samples plus one warmup per example/version/mode. No builds inside window.',input_sha256=pins,commands=[])
rng=random.Random(5354);names=sorted(goldens)
for sample in range(-1,5):
 rng.shuffle(names)
 for name in names:
  modes=['precompiled-minimal','native-C'];rng.shuffle(modes)
  for mode in modes:
   versions=[53,54];rng.shuffle(versions)
   for version in versions:
    cmd=commands[version,name,mode];start=time.monotonic();r=subprocess.run(cmd,cwd=root,capture_output=True);elapsed=time.monotonic()-start
    assert r.returncode==0 and hashlib.sha256(r.stdout).hexdigest()==goldens[name],(cmd,r.returncode,r.stderr,r.stdout)
    stem=f'{name}-{sample}-{version}-{mode}';(out/(stem+'.stdout')).write_bytes(r.stdout);(out/(stem+'.stderr')).write_bytes(r.stderr)
    report['commands'].append(dict(name=name,version=version,mode=mode,sample=sample,warmup=sample<0,command=cmd,exit_code=r.returncode,wall_seconds=elapsed,stdout_sha256=hashlib.sha256(r.stdout).hexdigest()))
summary=[]
for name in sorted(goldens):
 row=dict(name=name)
 for mode in ['precompiled-minimal','native-C']:
  med={v:statistics.median(x['wall_seconds'] for x in report['commands'] if x['name']==name and x['version']==v and x['mode']==mode and not x['warmup']) for v in [53,54]}
  row[mode]=dict(compiler53_ms=med[53]*1000,compiler54_ms=med[54]*1000,ratio54_to53=med[54]/med[53])
 summary.append(row)
for p,h in pins.items():assert sha(Path(p))==h,p
report.update(status='passed',ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),summary=summary,input_sha256_after=pins,median_workload_ratio={mode:statistics.median(row[mode]['ratio54_to53'] for row in summary) for mode in ['precompiled-minimal','native-C']})
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(status=report['status'],median_workload_ratio=report['median_workload_ratio'],summary=summary),indent=2),flush=True)
