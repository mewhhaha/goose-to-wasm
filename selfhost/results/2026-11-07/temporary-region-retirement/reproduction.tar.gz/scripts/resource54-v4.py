from pathlib import Path
import concurrent.futures,hashlib,json,shutil,subprocess,time,importlib.util
root=Path('/home/jacobt/src/goose-to-wasm');w=root/'build/completion-runs';out=w/'temporary-retirement-54-v4'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
while read(w/'c-only-bootstrap-54-v4/report.json')['status']=='running':time.sleep(2)
proof=read(w/'c-only-bootstrap-54-v4/report.json');assert proof['status']=='passed';compiler=w/'c-only-bootstrap-54-v4/goose';assert sha(compiler)==proof['executable_sha256']
manifest=read(w/'temporary-retirement-54/controls-manifest-v5.json');manifest['cases']+=read(w/'astra-retirement-54-source-review/controls-manifest-v3.json')['cases'];manifest['cases']+=read(w/'astra-temporary-call-order-54/controls-manifest.json')['cases'];assert len({c['id'] for c in manifest['cases']})==len(manifest['cases']);(out/'controls-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
base=['python',root/'tests/conformance.py','--compiler',compiler,'--manifest',out/'controls-manifest.json','--timeout','30']
jobs=[('candidate-wasmtime',base+['--output-dir',out/'candidate-wasmtime']),('baseline-controls',['python',root/'tests/conformance.py','--compiler',w/'c-only-bootstrap-53/goose','--manifest',out/'controls-manifest.json','--timeout','30','--output-dir',out/'baseline-controls']),('candidate-v8',base+['--filter','/wasm-direct','--engine','v8','--output-dir',out/'candidate-v8']),('preservation',['python',root/'tests/conformance.py','--compiler',compiler,'--manifest',w/'temporary-retirement-54/preservation-manifest.json','--output-dir',out/'preservation']),('preservation-v8',['python',root/'tests/conformance.py','--compiler',compiler,'--manifest',w/'temporary-retirement-54/preservation-all-v8-manifest.json','--engine','v8','--output-dir',out/'preservation-v8'])]
def run(row):
 name,cmd=row;start=time.monotonic();cmd=list(map(str,cmd));existing=Path(cmd[cmd.index('--output-dir')+1])/'report.json'
 if existing.exists():
  completed=read(existing);assert 'summary' in completed and completed['input_sha256']==completed['input_sha256_after']
  for name_pin,value in completed['input_sha256'].items():assert sha(Path(name_pin))==value,name_pin
  code=int(completed['summary']['failed']>0);print(name,'retained complete report',completed['summary'],flush=True);return dict(name=name,command=cmd,exit_code=code,reused='Identical complete raw report; only inspector limit assumption corrected')
 r=subprocess.run(cmd,cwd=root,capture_output=True);(out/(name+'.stdout')).write_bytes(r.stdout);(out/(name+'.stderr')).write_bytes(r.stderr);print(name,r.returncode,round(time.monotonic()-start,2),flush=True);return dict(name=name,command=cmd,exit_code=r.returncode)
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:commands=list(pool.map(run,jobs))
assert all(r['exit_code']==0 for r in commands if r['name']!='baseline-controls')
spec=importlib.util.spec_from_file_location('inspect_wasm',w/'temporary-retirement-54/inspect_wasm.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
report=read(out/'candidate-wasmtime/report.json');bycase={c['id']:c for c in manifest['cases']};binaries=[]
for row in report['results']:
 c=bycase[row['case']]
 if c['target']!='wasm-direct' or row['phase']!='run':continue
 cmd=report['commands'][row['compile_command']]['command'];path=Path(cmd[cmd.index('-o')+1]);info=module.inspect(path);info.update(case=row['case'],level=row['level']);
 if c.get('maximum_pages') is not None:assert info['memories']==[dict(minimum_pages=1,maximum_pages=c['maximum_pages'])],info
 if any(x in row['case'] for x in ('builtin-str-demand','builtin-to-bytes-demand')):assert info['defined_global_count']==12,info
 if 'dead-statement-demand' in row['case']:assert info['defined_global_count']==5,info
 binaries.append(info)
(out/'final-binary-receipts.json').write_text(json.dumps(binaries,indent=2)+'\n');(out/'qualification.json').write_text(json.dumps(dict(status='passed',compiler_sha256=sha(compiler),commands=commands,summaries={name:read(out/name/'report.json')['summary'] for name,_ in jobs},binaries_sha256=sha(out/'final-binary-receipts.json')),indent=2)+'\n')
print('FinalV3 resource, preservation and binary limits passed',flush=True)
