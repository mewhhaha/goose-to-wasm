from pathlib import Path
w=Path('build/completion-runs');s=(w/'render_copy_53.py').read_text()
for a,b in {'goose-examples-53':'goose-examples-54','goose-host-53':'goose-host-54','c-only-bootstrap-53':'c-only-bootstrap-54-v3','comparison-53.json':'comparison-54-v3.json','c-only-conformance-53-qualified':'c-only-conformance-54-v3-qualified','c-only-v8-53-qualified':'c-only-v8-54-v3-qualified','remaining-phases-53':'remaining-phases-54-v3','readme-copy-53':'readme-copy-54','delivery-53':'delivery-54','temporary-values-and-copies':'temporary-region-retirement','Snapshot 53':'Snapshot 54','Terra53':'Terra54'}.items():s=s.replace(a,b)
s=s.replace("remaining = read(work / 'remaining-phases-54-v3.json')", """remaining = read(work / 'remaining-phases-54-v3.json')
paired = read(work / 'paired-runtime53-54/report.json')
costs = read(work / 'temporary-retirement-54-v3/compile-measurement.json')
import statistics
changed_costs = [row for row in costs['rows'] if row['artifacts']['candidate']['sha256'] != row['artifacts']['baseline']['sha256']]
same_costs = [row for row in costs['rows'] if row['artifacts']['candidate']['sha256'] == row['artifacts']['baseline']['sha256']]
cost_ratio = statistics.median(row['candidate_baseline_cpu_ratio'] for row in changed_costs)
same_ratio = statistics.median(row['candidate_baseline_cpu_ratio'] for row in same_costs)
size_ratios = [row['artifacts']['candidate']['bytes'] / row['artifacts']['baseline']['bytes'] for row in changed_costs]
aot_ratios = [row['precompiled-minimal']['ratio54_to53'] for row in paired['summary']]
assert paired['status'] == 'passed'
""")
lines=[]
for line in s.splitlines(True):
 if "'REFERENCE_CONTEXT':" in line:
  line="    'REFERENCE_CONTEXT': 'The [paired process comparison](paired-runtime.json) interleaves exact qualified 53/54 minimal AOT artifacts and native controls on the same engine/host: 200 measured processes plus 40 warmups. [Wasm identities](wasm-artifacts.json), [targeted compile costs](resource-costs.json), [memory observations](resource-memory.json) and [module limits](resource-binaries.json) are recorded separately. Prior snapshot 53 results are separately collected references.',\n"
 elif "'BENCHMARK_CONTEXT':" in line:
  line="    'BENCHMARK_CONTEXT': f\"Paired minimal AOT process ratios versus snapshot 53 ranged {min(aot_ratios):.3f}–{max(aot_ratios):.3f}, with a median workload ratio of {paired['median_workload_ratio']['precompiled-minimal']:.3f}; the native-control median was {paired['median_workload_ratio']['native-C']:.3f}. These measurements do not establish a broad runtime speedup.\",\n"
 elif "'CONFORMANCE_CONTEXT':" in line:
  line="    'CONFORMANCE_CONTEXT': f\"All {comparison['baseline_summary']['selected']:,} prior checks retained their outcomes. All {len(comparison['new_rows'])} new source-authored checks passed; these include bounded-memory contracts rather than recovered original-suite failures.\",\n"
 lines.append(line)
s=''.join(lines)
s=s.replace('rows = []', '''facts['RESOURCE_RESULTS'] = 'Repeated 10,000-iteration temporary workloads, including str and to_bytes, now fit the same two-page Wasm limit. Thirty-two scalar startup initializers reuse one region instead of 33; an 8,192-byte main temporary then fits without increasing the limit. The guards also preserve live global owners and views and still reject a live value larger than the limit.'
facts['COST_TRADEOFFS'] = f'Across {len(changed_costs)} changed small modules in the targeted cohort, emitted size was {min(size_ratios):.3f}–{max(size_ratios):.3f} times baseline and median compile CPU was {cost_ratio:.3f} times baseline. The {len(same_costs)} byte-identical controls had a median compile CPU ratio of {same_ratio:.3f}. These are targeted costs of the final candidate, separate from the ten-example process comparison.'
rows = []''')
(w/'render_copy_54.py').write_text(s)
