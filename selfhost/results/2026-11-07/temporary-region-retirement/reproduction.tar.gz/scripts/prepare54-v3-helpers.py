from pathlib import Path
import json,hashlib
w=Path('build/completion-runs')
# Keep all frozenV2 directories intact. Final variants use explicit new paths.
s=(w/'prepare_delivery_v2.py').read_text().replace('version = int(sys.argv[1])','version = int(sys.argv[1])\ntag = str(version) + "-v3"').replace('str(version)', 'tag');s=s.replace('tag = tag + "-v3"','tag = str(version) + "-v3"');(w/'prepare_delivery54_v3.py').write_text(s)
s=(w/'reproduce_delivery_v3.py').read_text().replace('{version}', '{version}-v3');(w/'reproduce_delivery54_v3.py').write_text(s)
s=(w/'compare_batch_qualified45.py').read_text().replace('conformance-{v}-qualified','conformance-{v}-v3-qualified').replace('comparison-{v}.json','comparison-{v}-v3.json');(w/'compare54_v3.py').write_text(s)
paths={'c-only-bootstrap-54':'c-only-bootstrap-54-v3','verified-seed-54':'verified-seed-54-v3','snapshot-54':'snapshot-54-v3','public-54':'public-54-v3','install-54/bin':'install-54-v3/bin','c-only-conformance-54-qualified':'c-only-conformance-54-v3-qualified','c-only-v8-54-qualified':'c-only-v8-54-v3-qualified','comparison-54.json':'comparison-54-v3.json','remaining-phases-54.json':'remaining-phases-54-v3.json','reproduction-54.json':'reproduction-54-v3.json'}
renames={'qualify_54.py':'qualify54_v3.py','public-smoke-54.py':'public-smoke54_v3.py','public-cross54.py':'public-cross54_v3.py','qualification54-sequence.py':'qualification54-v3-sequence.py','audit54.py':'audit54_v3.py'}
for name,out in renames.items():
 s=(w/name).read_text()
 for a,b in paths.items():s=s.replace(a,b)
 for a,b in renames.items():s=s.replace(a,b)
 s=s.replace('prepare_delivery_v2.py','prepare_delivery54_v3.py').replace('reproduce_delivery_v3.py','reproduce_delivery54_v3.py').replace('compare_batch_qualified45.py','compare54_v3.py')
 s=s.replace('public-cross-54','public-cross-54-v3')
 s=s.replace('delivery-54-controls-ready.json','delivery-54-v3-controls-ready.json')
 if name=='audit54.py':s=s.replace('37c91620227bcc4b32f8e4a0175dcf8c95199199089d528417cef0167da4d054','9d344a245d09cb260598b702e50fed8e2405e58256c813c134ff542b27a33058').replace("'composition54-audit.json'","'composition54-v3-audit.json'")
 (w/out).write_text(s)
for name in ['publish_54.py','stage_54.py','install_54.py','benchmark_54.py']:
 s=(w/name).read_text()
 for a,b in paths.items():s=s.replace(a,b)
 s=s.replace('public-cross-54','public-cross-54-v3')
 for a,b in renames.items():s=s.replace(a,b)
 s=s.replace('reproduce_delivery_v3.py','reproduce_delivery54_v3.py').replace('prepare_delivery_v2.py','prepare_delivery54_v3.py').replace('compare_batch_qualified45.py','compare54_v3.py')
 (w/name).write_text(s)
print('Final54V3 paths isolated; previousV2 sources, raw runs and helpers retained')
