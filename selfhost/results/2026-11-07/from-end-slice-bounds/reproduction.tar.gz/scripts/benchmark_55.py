from pathlib import Path
import datetime,json,os,subprocess,time
root=Path('/home/jacobt/src/goose-to-wasm');w=root/'build/completion-runs'
prior=json.loads((w/'benchmark-window-54.json').read_text());os.sched_setaffinity(0,{7})
r=dict(status='running',started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),cpu_affinity=sorted(os.sched_getaffinity(0)),load_start=os.getloadavg(),coordination='All active coding agents explicitly quiescent before this window. Standard disk outputs and TMPDIR retained; shared machine, CPU7 affinity.',commands=[])
for i,old in enumerate(prior['commands']):
 cmd=[v.replace('bench-snapshot-54-v4','bench-snapshot-55').replace('install-54-v4','install-55').replace('goose-examples-54','goose-examples-55').replace('goose-host-54','goose-host-55') for v in old['command']];start=time.monotonic()
 with (w/f'benchmark-55-{i}.log').open('w') as log:
  result=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 r['commands'].append(dict(command=cmd,exit_code=result.returncode,seconds=time.monotonic()-start))
 (w/'benchmark-window-55.json').write_text(json.dumps(r,indent=2)+'\n')
 assert result.returncode==0,r['commands'][-1]
r.update(status='passed',ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),load_end=os.getloadavg())
(w/'benchmark-window-55.json').write_text(json.dumps(r,indent=2)+'\n');print(r,flush=True)
