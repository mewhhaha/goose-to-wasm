from pathlib import Path
w=Path('build/completion-runs')
def current(s):
 for a,b in [('54-v4','55'),('temporary-region-retirement','from-end-slice-bounds'),('goose-examples-54','goose-examples-55'),('goose-host-54','goose-host-55'),('delivery-54','delivery-55'),('new-controls-54','new-controls-55'),('comparison-54','comparison-55'),('remaining-phases-54','remaining-phases-55'),('stage-plan-54','stage-plan-55'),('live-before-54','live-before-55'),('readme-copy-54','readme-copy-55'),('benchmark-window-54','benchmark-window-55'),('wasm-artifact-check-54','wasm-artifact-check-55'),('Snapshot 54','Snapshot 55'),("'snapshot': '54'","'snapshot': '55'"),("'compiler_snapshot': '54'","'compiler_snapshot': '55'"),('Fresh54','Fresh55'),('Terra54','Terra55')]:s=s.replace(a,b)
 return s
helpermap={'public-smoke54_v4.py':'public-smoke-55.py','compare54_v4.py':'compare_delivery_v2.py','benchmark_54.py':'benchmark_55.py','stage_54.py':'stage_55.py','install_54.py':'install_55.py','public-cross54_v4.py':'public-cross55.py','migrate_controls54.py':'migrate_controls55.py','reproduce_delivery54_v4.py':'reproduce_delivery_v4.py','qualify54_v4.py':'qualify_55.py','assemble_delivery_v2.py':'assemble_delivery_v3.py','qualification54-v4-sequence.py':'qualification55-sequence.py','audit54_v4.py':'audit55.py','paired-runtime53-54.py':'paired-runtime54-55.py','prepare_delivery54_v4.py':'prepare_delivery_v3.py'}
s=(w/'publish_54.py').read_text()
for a,b in helpermap.items():s=s.replace(a,b)
s=current(s).replace('public-cross-54','public-cross-55').replace('public-smoke-context-54','public-smoke-context-55').replace('publish_54.py','publish_55.py').replace('render_copy_54.py','render_copy_55.py').replace('paired-runtime53-54','paired-runtime54-55')
s=s.replace('c-only-bootstrap-53','c-only-bootstrap-54-v4').replace('verified-seed-53','verified-seed-54-v4').replace('parent seed is verified snapshot53','parent seed is verified snapshot54')
start=s.index("for source, name in [('compile-measurement.json'");end=s.index('rows = []',start)
s=s[:start]+"assert read(work / 'delivery-55-review-ready.json')['status'] == 'passed'\n"+s[end:]
start=s.index("for name in ('resource54-v4.py'") if "for name in ('resource54-v4.py'" in s else s.index("for name in ('resource55.py'")
s=s[:start]+"""for name in ('prepare55.py','helpers55.py','delivery55-helpers.py','measure55-window.py','final-stage-preflight-55.py'):
    files['scripts/' + name] = work / name
archive(checks / 'reproduction.tar.gz', files)
print('published evidence', bench, checks)
"""
(w/'publish_55.py').write_text(s)
for name,target in [('stage_54.py','stage_55.py'),('install_54.py','install_55.py')]:
 s=current((w/name).read_text()).replace('.goose-54.new','.goose-55.new')
 (w/target).write_text(s)
s=current((w/'render_copy_54.py').read_text()).replace('paired-runtime53-54','paired-runtime54-55').replace('ratio54_to53','ratio55_to54')
start=s.index("costs = read(");end=s.index("case_targets =",start)
s=s[:start]+"""aot_ratios = [row['precompiled-minimal']['ratio55_to54'] for row in paired['summary']]
assert paired['status'] == 'passed'
"""+s[end:]
lines=[]
for line in s.splitlines(True):
 if "'REFERENCE_CONTEXT':" in line:line="    'REFERENCE_CONTEXT': 'The [paired process comparison](paired-runtime.json) interleaves qualified 54/55 minimal AOT artifacts and native controls on the same engine/host: 200 measured processes plus 40 warmups. [Wasm identities](wasm-artifacts.json) record emitted-module equality or differences. Prior snapshot 54 timings are separately collected references.',\n"
 elif "'BENCHMARK_CONTEXT':" in line:line=line.replace('versus snapshot 53','versus snapshot 54')
 elif "'CONFORMANCE_CONTEXT':" in line:line="""    'CONFORMANCE_CONTEXT': f"Against snapshot 54, {len(comparison['shared_gains'])} of {comparison['baseline_summary']['selected']:,} prior checks improved and none regressed. All {len(comparison['new_rows'])} new source-authored checks passed.",\n"""
 elif line.startswith("facts['RESOURCE_RESULTS']") or line.startswith("facts['COST_TRADEOFFS']"):continue
 lines.append(line)
(w/'render_copy_55.py').write_text(''.join(lines))
