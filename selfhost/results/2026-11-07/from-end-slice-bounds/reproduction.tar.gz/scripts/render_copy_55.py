from pathlib import Path
import hashlib
import json

root = Path('/home/jacobt/src/goose-to-wasm')
work = root / 'build/completion-runs'

def read(path):
    return json.loads(path.read_text())

examples = read(work / 'goose-examples-55/report.json')
host = read(work / 'goose-host-55/report.json')
proof = read(work / 'c-only-bootstrap-55/report.json')
comparison = read(work / 'comparison-55.json')
full = read(work / 'c-only-conformance-55-qualified/report.json')
v8 = read(work / 'c-only-v8-55-qualified/report.json')
remaining = read(work / 'remaining-phases-55.json')
paired = read(work / 'paired-runtime54-55/report.json')
paired_build = read(work / 'paired-build54-55/report.json')
build_ratios = [row['ratio55_to54'] for row in paired_build['summary']]
aot_ratios = [row['precompiled-minimal']['ratio55_to54'] for row in paired['summary']]
assert paired['status'] == 'passed'
case_targets = {r['id']: r['target'] for r in read(root / 'tests/conformance/cases.json')['cases']}
wasm_count = sum(case_targets[r['case']] == 'wasm-direct' for r in v8['results'])
native_count = sum(case_targets[r['case']] == 'native' for r in v8['results'])
invalid_count = sum(r['status'] != 'pass' and r['phase'] == 'type-error' for r in full['results'])

assert examples['status'] == host['status'] == proof['status'] == 'passed'
assert not comparison['shared_regressions'] and not comparison['new_failures']

build = {(r['name'], r['backend']): r['wall_seconds']['median'] * 1000 for r in examples['compile_summary']}
runtime = {(r['name'], r['backend'], r['mode']): r['wall_seconds']['median'] * 1000 for r in host['runtime_summary']}
direct = [value for (name, backend), value in build.items() if backend == 'direct']
native = [value for (name, backend), value in build.items() if backend == 'native']
summary = comparison['candidate_summary']
headline = f'**Conformance is partial: {summary["failed"]} of {summary["selected"]:,} contract rows fail.**'
if summary['failed'] == 0:
    headline = f'**All {summary["selected"]:,} contract rows pass.**'
node_version = json.loads(host['environment']['node']['output'])['node']
engine_version = host['environment']['wasmtime']
assert engine_version == host['host_build']['version']
assert node_version == json.loads(examples['environment']['node']['output'])['node']
cc_first_line = examples['environment']['native_cc']['output'].splitlines()[0]
cc_version_match = __import__('re').search(r'\d+\.\d+\.\d+', cc_first_line)
assert cc_version_match
cc_identity = examples['environment']['native_cc']['command'][0] + ' ' + cc_version_match.group(0)
facts = {
    'CONFORMANCE_HEADLINE': headline,
    'UNSUPPORTED_FORMS': 'arbitrary inter-row links, copied or escaping roots, and partial or nonlocal construction exits remain refused',
    'REFERENCE_CONTEXT': 'The [paired process comparison](paired-runtime.json) interleaves qualified 54/55 minimal AOT artifacts and native controls on the same engine/host: 200 measured processes plus 40 warmups. [Wasm identities](wasm-artifacts.json) record emitted-module equality or differences. The [matched direct-build comparison](paired-build.json) records 100 measured processes plus 20 warmups using one frozen driver/source tree. Prior snapshot 54 timings are separately collected references.',
    'CAPSULE_52_CONTEXT': read(work / 'delivery-55.json')['capsule_context'],
    'ORACLE_STATUS': 'No C++ oracle was executed.',
    'CAPSULE_CONTEXT': read(work / 'delivery-55.json')['capsule_context'],
    'PASSED': f"{summary['passed']:,}",
    'TOTAL': f"{summary['selected']:,}",
    'FAILED': str(summary['failed']),
    'MACHINE': 'AMD Ryzen 7 3800X pinned to CPU 7',
    'SAMPLES': 'Five',
    'DIRECT_BUILD_RANGE': f'{min(direct):.1f}–{max(direct):.1f}',
    'NATIVE_BUILD_RANGE': f'{min(native):.1f}–{max(native):.1f}',
    'SORTING_AOT': f"{runtime['sorting', 'direct', 'precompiled-minimal']:.1f}",
    'SORTING_NATIVE': f"{runtime['sorting', 'native', 'native-C']:.1f}",
    'BENCHMARK_CONTEXT': f"Paired minimal AOT process ratios versus snapshot 54 ranged {min(aot_ratios):.3f}–{max(aot_ratios):.3f}, with a median workload ratio of {paired['median_workload_ratio']['precompiled-minimal']:.3f}; the native-control median was {paired['median_workload_ratio']['native-C']:.3f}. Matched cold direct-build ratios ranged {min(build_ratios):.3f}–{max(build_ratios):.3f}, with a median workload ratio of {paired_build['median_workload_ratio']:.3f}. All ten Wasm modules are byte-identical. No broad speedup is established.",
    'BOOTSTRAP_STATUS': 'Snapshot 55 passed C-only fixed-point verification; its final two generated C outputs match.',
    'CHANGE_SCOPE': read(work / 'delivery-55.json')['change_scope'],
    'CONFORMANCE_CONTEXT': f"Against snapshot 54, {len(comparison['shared_gains'])} of {comparison['baseline_summary']['selected']:,} prior checks improved and none regressed. All {len(comparison['new_rows'])} new source-authored checks passed.",
    'WASM_CORPUS_CONTEXT': f'The curated Wasm corpus passed {wasm_count:,}/{wasm_count:,} checks each in Wasmtime and V8; all {native_count:,} curated native controls also passed.',
    'KNOWN_GAPS': f'The remaining failures are {invalid_count} accepted invalid programs and {remaining["compiler_refusal"]} runtime contracts rejected during Goose compilation. All selected runtime checks that reached execution passed.',
    'FAILURE_PHASES': f'The {summary["failed"]} remaining failures comprise {invalid_count} invalid-program checks and {remaining["compiler_refusal"]} runtime contracts; none failed C compilation or execution.',
    'GENERATED_C_SHA256': proof['executable_c_sha256'],
    'COMPILER_SHA256': proof['executable_sha256'],
    'RUNTIME_WARMUPS': 'one',
    'METHOD_AND_IDENTITIES': f'Both targets use the exact qualified Goose compiler at Goose O2; native C uses {cc_identity} O2. Engines are Wasmtime {engine_version} and Node {node_version}. The operating-system page cache is retained.',
    'COHORT_CONTEXT': 'The compiler, source, standard library, workload and tool identities are pinned in the raw reports. Agents paused expensive work during this shared-machine measurement window.',
    'GUARD_EVIDENCE_LINK': 'The qualification capsule retains paired checker guards, exact commands and sources.',
    'REJECTED_EXPERIMENTS_AND_EVIDENCE': read(work / 'delivery-55.json')['rejected_context'],
}
rows = []
for example in examples['examples']:
    name = example['name']
    rows.append(f"| {name} | {build[name, 'direct']:.2f} | {build[name, 'native']:.2f} | {runtime[name, 'direct', 'precompiled-minimal']:.2f} | {runtime[name, 'native', 'native-C']:.2f} |")
facts['EXAMPLE_ROWS'] = '\n'.join(rows)
facts['CAPSULE_LINK'] = '../../../../selfhost/results/2026-11-07/from-end-slice-bounds/reproduction.tar.gz'
targets = {
    'README.md.in': root / 'README.md',
    'selfhost-README.md.in': root / 'selfhost/README.md',
    'bench-README.md.in': root / 'bench/README.md',
    'dated-results-README.md.in': root / 'bench/results/2026-11-07/from-end-slice-bounds/README.md',
}
for template, target in targets.items():
    text = (work / 'readme-copy-55' / template).read_text()
    for key, value in facts.items():
        text = text.replace('{{' + key + '}}', value)
    assert '{{' not in text, template
    target.write_text(text)
(root / 'bench/results/2026-11-07/from-end-slice-bounds/copy-facts.json').write_text(json.dumps(facts, indent=2) + '\n')
for name, report in [('examples-latest.json', 'examples.json'), ('wasmtime-host-latest.json', 'host.json')]:
    path = root / 'bench/results' / name
    current = read(path)
    report_path = '2026-11-07/from-end-slice-bounds/' + report
    current.update(report=report_path,
                   sha256=hashlib.sha256((root / 'bench/results' / report_path).read_bytes()).hexdigest())
    path.write_text(json.dumps(current, indent=2) + '\n')
print('Rendered Terra55 templates from qualified measurements')
