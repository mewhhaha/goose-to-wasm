from pathlib import Path
import hashlib,json,subprocess,time
w=Path('/home/jacobt/src/goose-to-wasm/build/completion-runs');out=w/'public-cross-55';out.mkdir(exist_ok=False);proof=json.loads((w/'c-only-bootstrap-55/report.json').read_text());source=w/'c-only-bootstrap-55/sources/main.goose';exe=w/'public-55/build/bin/goose';target=out/'compiler.c';cmd=[str(exe),str(source),'--stdlib',str(w/'c-only-bootstrap-55/stdlib'),'--target','native','-O0','-o',str(target)];start=time.monotonic();r=subprocess.run(cmd,text=True,capture_output=True);report=dict(command=cmd,exit_code=r.returncode,seconds=time.monotonic()-start,stdout=r.stdout,stderr=r.stderr,compiler_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),expected_c_sha256=proof['executable_c_sha256']);assert r.returncode==0,report
report['c_sha256']=hashlib.sha256(target.read_bytes()).hexdigest();report['status']='failed'
if report['c_sha256']==report['expected_c_sha256']:report['status']='passed'
report['scope']='Public installed compiler re-emits the qualified fixed-point C byte-for-byte using the same frozen workload paths. Separate bootstrap paths embed different diagnostic filenames via cc_location.'
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(report,flush=True);assert report['status']=='passed'
