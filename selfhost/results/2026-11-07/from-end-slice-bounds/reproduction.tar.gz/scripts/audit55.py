from pathlib import Path
import hashlib,json,subprocess
root=Path('/home/jacobt/src/goose-to-wasm');w=root/'build/completion-runs'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
cfg=read(w/'delivery-55.json');parent=read(w/'c-only-bootstrap-54-v4/report.json');proof=read(w/'c-only-bootstrap-55/report.json')
assert cfg['base_commit']==subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert proof['status']=='passed' and proof['fixed_point']
changed=sorted(k for k in parent['source_sha256'] if parent['source_sha256'][k]!=proof['source_sha256'][k]);assert changed==['checker.goose']
assert proof['asset_sha256']==parent['asset_sha256']
for name,value in read(w/'snapshot-55-assembly.json')['sha256'].items():assert sha(w/'snapshot-55'/name)==value,name
old=json.loads(subprocess.check_output(['git','show',cfg['base_commit']+':tests/conformance/cases.json'],cwd=root));new=read(root/'tests/conformance/cases.json');byid={c['id']:c for c in new['cases']};assert len(byid)==len(new['cases'])
for c in old['cases']:assert byid[c['id']]==c
comparison=read(w/'comparison-55.json');assert not comparison['shared_regressions'] and not comparison['new_failures'] and len(comparison['shared_gains'])==2
assert {x['case'] for x in comparison['shared_gains']}=={'upstream/syntax/parser_all'}
assert read(w/'astra-from-end-slices-55/root55-native-wasmtime/report.json')['summary']==dict(selected=8,passed=8,failed=0)
assert read(w/'astra-from-end-slices-55/root55-v8/report.json')['summary']==dict(selected=4,passed=4,failed=0)
for name,value in read(w/'new-controls-55.json')['sources'].items():assert sha(root/name)==value
assert read(w/'delivery-55-review-ready.json')['status']=='passed'
r=dict(status='passed',parent_commit=cfg['base_commit'],source_changes=changed,source_sha256=proof['source_sha256'],unchanged_native_assets=proof['asset_sha256'],existing_gains=comparison['shared_gains'],new_rows=len(comparison['new_rows']),independent_guards=dict(native_wasmtime=8,v8=4),review_sha256=sha(w/'astra-from-end-slices-55/root55-result.json'),scope='Whole original parser_all native O0/O2 recovered. Whole-program Wasm remains refused by existing thread ABI; no partial-source gain.',no_oracle_execution=True)
(w/'composition55-audit.json').write_text(json.dumps(r,indent=2)+'\n');print('Source55 audit passed')
