from pathlib import Path
w=Path('build/completion-runs')
names={'qualify54_v4.py':'qualify_55.py','public-smoke54_v4.py':'public-smoke-55.py','public-cross54_v4.py':'public-cross55.py','qualification54-v4-sequence.py':'qualification55-sequence.py'}
for name,target in names.items():
 s=(w/name).read_text().replace('-54-v4','-55').replace("'54'","'55'").replace('Qualified54','Qualified55').replace('All54','All55')
 for a,b in names.items():s=s.replace(a,b)
 s=s.replace('prepare_delivery54_v4.py','prepare_delivery_v3.py').replace('reproduce_delivery54_v4.py','reproduce_delivery_v4.py').replace('compare54_v4.py','compare_delivery_v2.py')
 for a,b in [('freeze-54','freeze-55'),('prepare-54','prepare-55'),('reproduce-54','reproduce-55'),('conformance-54','conformance-55'),('v8-54','v8-55'),('public-bootstrap-54','public-bootstrap-55'),('compare-54','compare-55'),('public-cross-54','public-cross-55'),('public-smoke-context-54','public-smoke-context-55')]:s=s.replace(a,b)
 (w/target).write_text(s)
s=(w/'migrate_controls54.py').read_text().replace('54','55');(w/'migrate_controls55.py').write_text(s)
s=(w/'paired-runtime53-54.py').read_text().replace('53','OLD').replace('54','55').replace('OLD','54');(w/'paired-runtime54-55.py').write_text(s)
# Paired previous54 benchmark uses the finalV4 source and executable paths.
s=(w/'benchmark_54.py').read_text();s=s.replace('benchmark-window-53','benchmark-window-54').replace('benchmark-54','benchmark-55').replace('benchmark-window-54.json\').write','benchmark-window-55.json\').write')
a="cmd=[v.replace('-53','-54').replace('bench-snapshot-54/', 'bench-snapshot-54-v4/').replace('install-54/bin/', 'install-54-v4/bin/') for v in old['command']]"
b="cmd=[v.replace('bench-snapshot-54-v4','bench-snapshot-55').replace('install-54-v4','install-55').replace('goose-examples-54','goose-examples-55').replace('goose-host-54','goose-host-55') for v in old['command']]"
assert a in s;s=s.replace(a,b);(w/'benchmark_55.py').write_text(s)
