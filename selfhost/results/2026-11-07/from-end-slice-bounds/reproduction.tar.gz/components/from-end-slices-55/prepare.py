from pathlib import Path
import difflib, hashlib, json, shutil
root=Path('/home/jacobt/src/goose-to-wasm'); w=root/'build/completion-runs/from-end-slices-55'; base=root/'build/completion-runs/snapshot-54-v3'; source=w/'source'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
shutil.copytree(base,source)
(source/'source-pins.json').rename(source/'parent-54-v3-source-pins.json')
(source/'parent-v2-source-pins.json').rename(source/'ancestor-54-v2-source-pins.json')
parent=json.loads((source/'parent-54-v3-source-pins.json').read_text())
assert all(sha(source/p)==h for p,h in parent.items())
p=source/'selfhost/checker.goose'; before=p.read_text(); old='if start.valid && end.valid && start.value > end.value { diagnose(p, n.token, "slice start exceeds its end"); }'; new='if (n.flags & (F_FROM_END | F_TO_END)) == 0 && start.valid && end.valid && start.value > end.value { diagnose(p, n.token, "slice start exceeds its end"); }'
assert before.count(old)==1;p.write_text(before.replace(old,new))
(w/'candidate.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),p.read_text().splitlines(True),fromfile='a/selfhost/checker.goose',tofile='b/selfhost/checker.goose')))
pins={str(p.relative_to(source)):sha(p) for p in sorted(source.rglob('*')) if p.is_file() and p.name not in ('parent-54-v3-source-pins.json','ancestor-54-v2-source-pins.json')};assert len(pins)==58;(source/'source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
build=(root/'build/completion-runs/temporary-retirement-54/build.py').read_text().replace('c-only-bootstrap-53','c-only-bootstrap-54-v3').replace('snapshot53','snapshot54-v3')
build=build.replace("proof=json.loads((work/'c-only-bootstrap-54-v3/report.json').read_text());assert sha(producer)==proof['executable_sha256']", "proof=json.loads((work/'c-only-bootstrap-54-v3/report.json').read_text());assert proof['status']=='passed';assert sha(producer)==proof['executable_sha256']")
(w/'build.py').write_text(build)
fixtures=w/'controls';fixtures.mkdir()
header='fn emit(s: i64[:]) { var value: i64 = 0; for x in s { value = value * 10 + x; } print(s.len, " ", value); }\n'
ops=['[^2..^0]','[^5..^0]','[^2..^2]','[^0..^0]','[1..^1]','[^4..4]','[..^2]','[^3..]','[..]','[2..2]','[^5..^5]','[..^0]']
expected='2 45\n5 12345\n0 0\n0 0\n3 234\n3 234\n3 123\n3 345\n5 12345\n0 0\n0 0\n5 12345\n'
positive={
 'fixed':header+'fn main() { var data = [1, 2, 3, 4, 5];\n'+''.join('emit(data'+op+');\n' for op in ops)+'}\n',
 'grow':header+'fn main() { var data: i64[>..] = [1, 2, 3, 4, 5];\n'+''.join('emit(data'+op+');\n' for op in ops)+'}\n',
 'slice-argument':header+'fn check(data: i64[:]) {\n'+''.join('emit(data'+op+');\n' for op in ops)+'}\nfn main() { var data = [1, 2, 3, 4, 5]; check(data); }\n'}
negative={
 'ordinary-inverted':('[4..2]','slice start exceeds its end'),
 'ordinary-negative':('[-1..3]','array index must be nonnegative'),
 'negative-from-end':('[^-1..^0]','array index must be nonnegative'),
 'negative-to-end':('[..^-1]','slice bound is outside the fixed array'),
 'fixed-upper-too-large':('[..6]','slice bound is outside the fixed array'),
 'fixed-from-end-upper-too-large':('[..^6]','slice bound is outside the fixed array'),
 'invalid-from-end-index':('[^1]','^ bounds are only valid in slices'),
 'fixed-index-too-large':('[5]','constant index is outside the fixed array')}
runtime={'inverted-from-end':('var data = [1, 2, 3, 4, 5];','[^1..^3]'),'from-end-low-too-large':('var data = [1, 2, 3, 4, 5];','[^6..]'),'grow-from-end-high-too-large':('var data: i64[>..] = [1, 2, 3, 4, 5];','[..^6]'),'mixed-inverted':('var data = [1, 2, 3, 4, 5];','[4..^4]')}
manifest=json.loads((root/'tests/conformance/cases.json').read_text()); cases=[]
def add(name,text,phase,expect):
 p=fixtures/(name+'.goose');p.write_text(text)
 for target in ('native','wasm-direct'):
  cases.append(dict(id=name+'/'+target,source=str(p.relative_to(root)),phase=phase,target=target,levels=[0,2],expect=expect,provenance='independently specified before execution'))
for name,text in positive.items():add(name,text,'run',dict(stdout=expected,exit=0))
for name,(op,error) in negative.items():add(name,'fn main() { var data = [1, 2, 3, 4, 5]; let s = data'+op+'; print(s); }\n','check',dict(exit=1,stderr_contains=error))
for name,(decl,op) in runtime.items():add(name,'fn main() { '+decl+' let s = data'+op+'; print(s.len); }\n','run',dict(stdout='',exit='nonzero'))
(w/'controls-manifest.json').write_text(json.dumps(dict(schema=manifest['schema'],upstream=manifest['upstream'],cases=cases),indent=2)+'\n')
row=next(c for c in manifest['cases'] if c['id']=='upstream/syntax/parser_all')
up=[row,dict(row,id=row['id']+'/wasm-direct',target='wasm-direct')]
(w/'original-parser-all-manifest.json').write_text(json.dumps(dict(schema=manifest['schema'],upstream=manifest['upstream'],cases=up),indent=2)+'\n')
(w/'expected-before-execution.json').write_text(json.dumps({'reason':'^k = len-k per upstream spec 3.10; integer value fold avoids float/u8 print semantics','positive_each':expected,'cases':cases,'upstream_original':up,'source_sha256':{str(p):sha(p) for p in fixtures.glob('*.goose')},'upstream_source_sha256':sha(root/'build/source/test/syntax/parser_all.goose')},indent=2)+'\n')
print('prepared',len(pins),'source pins,',len(cases),'controls')
