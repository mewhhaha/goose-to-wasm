from pathlib import Path
import hashlib,json
root=Path('/home/jacobt/src/goose-to-wasm');w=root/'build/completion-runs/from-end-slices-55'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads((w/p).read_text())
assert read('own-fixedpoint.json')['generated_c_equal']
pins=read('source/source-pins.json');assert len(pins)==58 and all(sha(w/'source'/p)==h for p,h in pins.items())
assert read('qualification-pins-before.json')==read('qualification-pins-after.json')
reports={n:read(n+'/report.json') for n in ('candidate-controls','candidate-controls-v8','baseline-controls','original-parser-all','original-parser-all-v8','preservation','preservation-v8')}
for n in ('candidate-controls','candidate-controls-v8','preservation','preservation-v8'):assert reports[n]['status']=='passed'
files=['candidate.patch','source/source-pins.json','source/parent-54-v3-source-pins.json','source/ancestor-54-v2-source-pins.json','source/selfhost/checker.goose','build.py','build/report.json','controls-manifest.json','original-parser-all-manifest.json','expected-before-execution.json','rejected-authoring-before-execution.json','negative-diagnostics-comparison.json','qualification-pins-before.json','qualification-pins-after.json','focused-pins-after.json','qualification-commands.json','remaining-commands.json','own-fixedpoint.json','front/comparison.json',*[n+'/report.json' for n in reports]]
producer=root/'build/completion-runs/c-only-bootstrap-54-v3/goose';proof=json.loads((producer.parent/'report.json').read_text());assert proof['status']=='passed' and sha(producer)==proof['executable_sha256']
result={
 'status':'private focused checker fix qualified on exact canonical54-v3; production admission and V4 composition pending',
 'functional_changes':['selfhost/checker.goose'],
 'patch':'candidate.patch',
 'source':'source',
 'source_count':len(pins),
 'base':{'snapshot':'build/completion-runs/snapshot-54-v3','producer':str(producer.relative_to(root)),'producer_sha256':sha(producer),'producer_proof_sha256':sha(producer.parent/'report.json'),'candidate_compiler':'build/goose','candidate_compiler_sha256':sha(w/'build/goose'),'scope_note':'Root reported two full-V3 Wasm tuple-result cleanup regressions and is preparing V4. This candidate retains V3 codegen exactly and claims no V4 or whole-corpus production qualification.'},
 'intent':'^k means len-k. Compare raw constant start/end only when neither endpoint has a from-end flag; normalized runtime checks retain responsibility otherwise.',
 'upstream':json.loads((root/'tests/conformance/cases.json').read_text())['upstream'],
 'original_upstream_source_sha256':read('expected-before-execution.json')['upstream_source_sha256'],
 'qualification':{n:r['summary'] for n,r in reports.items()},
 'negative_diagnostics':{'comparisons':len(read('negative-diagnostics-comparison.json')),'unchanged':True,'independently_expected_diagnostics_present':True},
 'frontend':{'baseline':'temporary-retirement-54/front-v2','total':sum(x['total'] for x in read('front/comparison.json').values()),'comparison':read('front/comparison.json'),'timing_note':'Gate timings under concurrent work are not performance measurements.'},
 'original_whole_parser_all':{'native':'O0/O2 both execute with exact pinned upstream output','wasm':'O0/O2 emit rejected by existing thread ABI support boundary at original line112; Wasmtime and V8 have no whole-file module to execute. No subset gain claimed.'},
 'own_c_fixedpoint':read('own-fixedpoint.json'),
 'safety':{'parser':'^ only in slices unchanged','bce':'no proof or bounds-elision changes','runtimes':'normalized slice checks unchanged; four runtime-negative sources pass native/Wasmtime/V8 nonzero contracts at O0/O2','diagnostics':'ordinary inverted, negative endpoints, fixed upper bounds, fixed index, and ^ index diagnostics match baseline exactly'},
 'rejected_or_unclaimed':[{'kind':'authoring-only correction before execution','receipt':'rejected-authoring-before-execution.json','detail':'Harness error phases require type-error/parse-error; check means success. Corrected before running compiler.'},{'kind':'considered alternative, not executed','detail':'Normalize known fixed-array lengths in checker. Rejected as unnecessary added logic: runtime already normalizes and validates all slice endpoints.'},{'kind':'unsupported original whole-file Wasm attempt','detail':'Retained failed attempts honestly; thread support is outside this checker patch.'}],
 'production_admitted':False,
 'live_files_edited':False,
 'committed_or_pushed':False,
 'cpp_oracle_executed':False,
 'files':{p:sha(w/p) for p in files}
}
(w/'handoff.json').write_text(json.dumps(result,indent=2)+'\n')
print('sealed',sha(w/'handoff.json'))
