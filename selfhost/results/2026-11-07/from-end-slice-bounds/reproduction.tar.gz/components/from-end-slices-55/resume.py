from pathlib import Path
import hashlib,json,subprocess,time
root=Path('/home/jacobt/src/goose-to-wasm');w=root/'build/completion-runs/from-end-slices-55';compiler=w/'build/goose'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert json.loads((w/'build/report.json').read_text())['status']=='passed'
assert json.loads((w/'candidate-controls/report.json').read_text())['status']=='passed'
results=[]
def run(name,cmd):
 cmd=list(map(str,cmd));start=time.monotonic();r=subprocess.run(cmd,cwd=root,capture_output=True,timeout=240);(w/(name+'.stdout')).write_bytes(r.stdout);(w/(name+'.stderr')).write_bytes(r.stderr)
 results.append(dict(name=name,command=cmd,exit_code=r.returncode,seconds=time.monotonic()-start));(w/'remaining-commands.json').write_text(json.dumps(results,indent=2)+'\n');print(name,r.returncode,round(results[-1]['seconds'],2),flush=True);return r.returncode
base=['python',root/'tests/conformance.py','--cc','clang','--timeout','30','--compiler',compiler]
assert run('preservation',base+['--manifest',root/'build/completion-runs/temporary-retirement-54/preservation-manifest.json','--output-dir',w/'preservation'])==0
assert run('preservation-v8',base+['--manifest',root/'build/completion-runs/temporary-retirement-54/preservation-all-v8-manifest.json','--output-dir',w/'preservation-v8','--engine','v8'])==0
assert run('own-selfemit',[compiler,w/'source/selfhost/main.goose','--stdlib',root/'stdlib','--target','native','--standalone','-O0','-o',w/'own-compiler.c'])==0
same=(w/'own-compiler.c').read_bytes()==(w/'build/compiler.c').read_bytes();(w/'own-fixedpoint.json').write_text(json.dumps(dict(generated_c_equal=same,input_c_sha256=sha(w/'build/compiler.c'),self_c_sha256=sha(w/'own-compiler.c')),indent=2)+'\n');assert same
pins=json.loads((w/'qualification-pins-before.json').read_text());after={p:sha(p) for p in pins};(w/'qualification-pins-after.json').write_text(json.dumps(after,indent=2)+'\n');assert pins==after
