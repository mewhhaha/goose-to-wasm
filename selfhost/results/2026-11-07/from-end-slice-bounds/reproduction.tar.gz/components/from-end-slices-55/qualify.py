from pathlib import Path
import hashlib,json,subprocess,time
root=Path('/home/jacobt/src/goose-to-wasm');w=root/'build/completion-runs/from-end-slices-55';compiler=w/'build/goose';baseline=root/'build/completion-runs/c-only-bootstrap-54-v3/goose'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert json.loads((w/'build/report.json').read_text())['status']=='passed'
inputs=[*w.glob('source/**/*'),*w.glob('controls/*.goose'),w/'controls-manifest.json',w/'original-parser-all-manifest.json',w/'expected-before-execution.json',compiler,baseline,Path(__file__)]
for name in ('semantic-all-valid','typing','negative-type','upstream-positive'):
 p=root/'build/completion-runs/temporary-retirement-54/front-v2'/(name+'.json');inputs.append(p)
 inputs.extend(Path(r['source']) for r in json.loads(p.read_text()))
for name in ('preservation-manifest.json','preservation-all-v8-manifest.json'):
 p=root/'build/completion-runs/temporary-retirement-54'/name;inputs.append(p)
 inputs.extend(root/r['source'] for r in json.loads(p.read_text())['cases'] if not r['source'].startswith('upstream:'))
pins={str(p):sha(p) for p in inputs if p.is_file()};(w/'qualification-pins-before.json').write_text(json.dumps(pins,indent=2)+'\n')
results=[]
def run(name,command,timeout=240):
 command=list(map(str,command));start=time.monotonic();r=subprocess.run(command,cwd=root,capture_output=True,timeout=timeout)
 (w/(name+'.stdout')).write_bytes(r.stdout);(w/(name+'.stderr')).write_bytes(r.stderr)
 results.append(dict(name=name,command=command,exit_code=r.returncode,seconds=time.monotonic()-start));(w/'qualification-commands.json').write_text(json.dumps(results,indent=2)+'\n');print(name,r.returncode,round(results[-1]['seconds'],2),flush=True)
 return r.returncode
base=['python',root/'tests/conformance.py','--cc','clang','--timeout','30']
run('baseline-controls',base+['--compiler',baseline,'--manifest',w/'controls-manifest.json','--output-dir',w/'baseline-controls'])
run('candidate-controls',base+['--compiler',compiler,'--manifest',w/'controls-manifest.json','--output-dir',w/'candidate-controls'])
run('candidate-controls-v8',base+['--compiler',compiler,'--manifest',w/'controls-manifest.json','--output-dir',w/'candidate-controls-v8','--engine','v8','--filter','/wasm-direct'])
run('original-parser-all',base+['--compiler',compiler,'--manifest',w/'original-parser-all-manifest.json','--output-dir',w/'original-parser-all'])
run('original-parser-all-v8',base+['--compiler',compiler,'--manifest',w/'original-parser-all-manifest.json','--output-dir',w/'original-parser-all-v8','--engine','v8','--filter','/wasm-direct'])
run('front',['python',root/'build/completion-runs/durable-tools/front_gate.py',compiler,root/'build/completion-runs/temporary-retirement-54/front-v2',w/'front'])
run('preservation',base+['--compiler',compiler,'--manifest',root/'build/completion-runs/temporary-retirement-54/preservation-manifest.json','--output-dir',w/'preservation'])
run('preservation-v8',base+['--compiler',compiler,'--manifest',root/'build/completion-runs/temporary-retirement-54/preservation-all-v8-manifest.json','--output-dir',w/'preservation-v8','--engine','v8'])
if all(r['exit_code']==0 for r in results if r['name']!='baseline-controls'):
 run('own-selfemit',[compiler,w/'source/selfhost/main.goose','--stdlib',root/'stdlib','--target','native','--standalone','-O0','-o',w/'own-compiler.c'])
 if (w/'own-compiler.c').exists():
  (w/'own-fixedpoint.json').write_text(json.dumps(dict(generated_c_equal=(w/'own-compiler.c').read_bytes()==(w/'build/compiler.c').read_bytes(),input_c_sha256=sha(w/'build/compiler.c'),self_c_sha256=sha(w/'own-compiler.c')),indent=2)+'\n')
after={p:sha(p) for p in pins};(w/'qualification-pins-after.json').write_text(json.dumps(after,indent=2)+'\n');assert after==pins
