from pathlib import Path
import hashlib,json,os,shutil,subprocess
root=Path('/home/jacobt/src/goose-to-wasm');w=root/'build/completion-runs'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
remote=subprocess.check_output(['git','ls-remote','origin','refs/heads/main'],cwd=root,text=True).split()[0]
assert head==remote
plan=json.loads((w/'stage-plan-51.json').read_text());byname={x['path']:x for x in plan['files']}
for row in plan['live_before']:
 name=row['path'];live=root/name
 if row['sha256'] is None: assert not live.exists(),('concurrent creation',name)
 else: assert sha(live)==row['sha256'],('concurrent edit',name)
 live.parent.mkdir(parents=True,exist_ok=True);source=Path(byname[name]['source']);assert sha(source)==byname[name]['sha256'];shutil.copyfile(source,live)
proof=json.loads((w/'c-only-bootstrap-51/report.json').read_text())
for name,value in proof['source_sha256'].items():assert sha(root/'selfhost'/name)==value,name
for name,value in proof['asset_sha256'].items():assert sha(root/name)==value,name
meta=json.loads((w/'public-51/build/toolchain.json').read_text());assert meta['source_sha256']==proof['source_sha256'];assert meta['asset_sha256']==proof['asset_sha256']
for name,value in meta['stdlib_sha256'].items():assert sha(root/'build/bin/stdlib'/name)==value,name
exe=root/'build/bin/goose';tmp=exe.with_name('.goose-51.new');shutil.copyfile(w/'public-51/build/bin/goose',tmp);tmp.chmod(0o755);assert sha(tmp)==meta['compiler_sha256'];os.replace(tmp,exe)
meta['compiler']=str(exe);target=root/'build/toolchain.json';temp=target.with_suffix('.json.new');temp.write_text(json.dumps(meta,indent=2)+'\n');os.replace(temp,target)
print('pushedcommit',head,'installedpubliccompiler',sha(exe),'fixedpointC',proof['executable_c_sha256'])
print(subprocess.check_output(['git','status','--short'],cwd=root,text=True))
