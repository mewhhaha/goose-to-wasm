from pathlib import Path
p=Path(__file__).resolve().parent/'source/selfhost/codegen.goose';s=p.read_text()
pos=s.index('fn cg_seed_record_image(')
s=s[:pos]+'''fn cg_enum_frame_payload(p: Program&, id: i64) -> bool {
    if !cg_enum_image(p, id) { return false; }
    var variant = p.types[id].first;
    while variant >= 0 { if cg_frame_owner(p, p.nodes[variant].type_id) { return true; } variant = p.nodes[variant].next; }
    return false;
}
fn cg_frame_array_bytes(p: Program&, m: CgModule&, f: CgBody&, id: i64, owner: i64, node: i64) -> i64 {
    let tail = cg_region_header(p, f, id, owner); let array = cg_frame_tail_type(p, id);
    cg_owner_read_base(p, m, f, tail, node); let base = cg_save(f, 0x7f);
    cg_owner_read_length(p, m, f, tail, node);
    if p.types[p.types[array].element].storage == 1 {
        wb_byte(f.code, 0xad); let count = cg_save(f, 0x7e); let end = cg_walk_elements(p, m, f, base, count, node);
        cg_get(f, end); cg_get(f, base); wb_byte(f.code, 0x6b);
    } else { wb_i32(f.code, cg_size(p, p.types[array].element)); wb_byte(f.code, 0x6c); }
    return cg_save(f, 0x7f);
}
fn cg_rebase_enum_frame(p: Program&, f: CgBody&, id: i64, owner: i64, image: i64, bytes: i64) {
    cg_get(f, image); var load = 0x2d; if p.types[id].length_storage == 2 { load = 0x2f; }
    wb_mem(f.code, load, 0, 0); let tag = cg_save(f, 0x7f); var variant = p.types[id].first;
    while variant >= 0 {
        let payload = p.nodes[variant].type_id;
        if cg_frame_owner(p, payload) {
            cg_get(f, tag); wb_i32(f.code, p.nodes[variant].integer); wb_byte(f.code, 0x46); cg_begin(f, 0x04, 0x40);
            cg_get(f, owner); wb_i32(f.code, p.nodes[variant].aux); wb_byte(f.code, 0x6a); let place = cg_save(f, 0x7f); let tail = cg_region_header(p, f, payload, place);
            for word in [0, 16] { cg_get(f, tail); cg_get(f, image); wb_i32(f.code, p.types[id].length_storage); wb_byte(f.code, 0x6a); wb_mem(f.code, 0x36, 2, word); }
            cg_get(f, tail); cg_get(f, image); cg_get(f, bytes); wb_byte(f.code, 0x6a); wb_mem(f.code, 0x36, 2, 8);
            cg_end(f);
        }
        variant = p.nodes[variant].next;
    }
}
''' +s[pos:]
needle='        cg_get(f, owner); wb_mem(f.code, 0x28, 2, 8); let limit = cg_save(f, 0x7f);\n        cg_seed_record_image'
s=s.replace(needle,'''        if cg_frame_owner(p, p.nodes[variant].type_id) { return payload; }
'''+needle)
needle='        if cg_byte_record(p, payload) {\n            let place = cg_enum_payload'
s=s.replace(needle,'''        if cg_frame_owner(p, payload) {
            let place = cg_enum_payload(p, m, f, id, owner, variant, node); let bytes = cg_frame_array_bytes(p, m, f, payload, place, node);
            cg_get(f, bytes); wb_i32(f.code, p.types[id].length_storage); wb_byte(f.code, 0x6a);
        } else if cg_byte_record(p, payload) {
            let place = cg_enum_payload''')
needle='    if cg_byte_record(p, payload) {\n        cg_get(f, source); wb_mem(f.code, 0x28, 2, 16); original ='
s=s.replace(needle,'''    if cg_frame_owner(p, payload) {
        let tail = cg_region_header(p, f, payload, source); cg_owner_read_base(p, m, f, tail, node); original = cg_save(f, 0x7f);
        payload_bytes = cg_frame_array_bytes(p, m, f, payload, source, node);
        cg_get(f, destination); wb_i32(f.code, p.nodes[variant].aux); wb_byte(f.code, 0x6a); let place = cg_save(f, 0x7f);
        cg_get(f, place); cg_get(f, source); wb_i32(f.code, cg_size(p, payload)); wb_copy(f.code);
    } else if cg_byte_record(p, payload) {
        cg_get(f, source); wb_mem(f.code, 0x28, 2, 16); original =''')
needle='    cg_byte_header(f, destination, image, bytes);\n}\nrecursive fn cg_enum_from_value'
s=s.replace(needle,'''    cg_byte_header(f, destination, image, bytes);
    if cg_frame_owner(p, payload) { cg_rebase_enum_frame(p, f, id, destination, image, bytes); }
}
recursive fn cg_enum_from_value''')
needle='    if cg_enum_image(p, from) {\n        let bytes = cg_enum_image_bytes(p, m, f, from, source, node);'
s=s.replace(needle,'''    if cg_enum_image(p, from) && !cg_enum_frame_payload(p, from) {
        let bytes = cg_enum_image_bytes(p, m, f, from, source, node);''')
needle='    cg_get(f, source); var load = 0x2d; if p.types[from].length_storage == 2 { load = 0x2f; } wb_mem(f.code, load, 0, 0); let tag = cg_save(f, 0x7f);\n    let done = cg_begin(f, 0x02, 0x40); var variant = p.types[id].first;'
s=s.replace(needle,'''    cg_get(f, source); if cg_enum_image(p, from) { wb_mem(f.code, 0x28, 2, 0); }
    var load = 0x2d; if p.types[from].length_storage == 2 { load = 0x2f; } wb_mem(f.code, load, 0, 0); let tag = cg_save(f, 0x7f);
    let done = cg_begin(f, 0x02, 0x40); var variant = p.types[id].first;''')
needle='        cg_get(f, source); wb_i32(f.code, p.types[from].length_storage); wb_byte(f.code, 0x6a); let payload = cg_save(f, 0x7f);\n        cg_enum_variant_image'
s=s.replace(needle,'''        let payload = cg_enum_payload(p, m, f, from, source, variant, node);
        cg_enum_variant_image''')
# Nested record-image relocation keeps explicit frame descriptor aligned with its copied tail bytes.
needle='    cg_get(f, header); cg_get(f, image); cg_get(f, bytes); wb_byte(f.code, 0x6a); wb_mem(f.code, 0x36, 2, 8);\n}\nfn cg_pack_record_image'
s=s.replace(needle,'''    cg_get(f, header); cg_get(f, image); cg_get(f, bytes); wb_byte(f.code, 0x6a); wb_mem(f.code, 0x36, 2, 8);
    let tail = cg_image_tail_type(p, id);
    if cg_enum_frame_payload(p, tail) {
        cg_get(f, bytes); wb_i32(f.code, cg_record_total_prefix(p, id)); wb_byte(f.code, 0x6b); let tail_bytes = cg_save(f, 0x7f);
        cg_rebase_enum_frame(p, f, tail, header, new_tail, tail_bytes);
    }
}
fn cg_pack_record_image''')
p.write_text(s)
