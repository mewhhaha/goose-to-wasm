from pathlib import Path
import os,time,hashlib,json,subprocess,shutil
b=Path(__file__).resolve().parent;r=b.parents[2];out=b/'own-abi4';out.mkdir(exist_ok=False);producer=b/'optimized4/goose';cc=Path(shutil.which('clang')).resolve();source=b/'source4/selfhost/main.goose'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
pins={str(p):sha(p) for p in [producer,cc,Path(__file__),*source.parent.glob('*.goose'),*(b/'source4/native').rglob('*.h')]};report=dict(status='running',method='Actual own compiler emitted/built using candidate native ABI; two target ownchecks and exact generated C fixedpoint.',input_sha256=pins,commands=[])
def save():(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
save()
try:
 commands=[('emit',[producer,source,'--stdlib',r/'stdlib','--target','native','--standalone','-O0','-o',out/'compiler.c']),('cc',[cc,'-std=gnu11','-O2',out/'compiler.c','-lm','-ldl','-pthread','-o',out/'goose'])]
 for target in ['native','wasm-direct']:commands.append(('check-'+target,[out/'goose',source,'--stdlib',r/'stdlib','--target',target,'--check','--library']))
 commands.append(('repeat',[out/'goose',source,'--stdlib',r/'stdlib','--target','native','--standalone','-O0','-o',out/'repeat.c']))
 for label,command in commands:
  command=list(map(str,command));start=time.monotonic()
  with (out/(label+'.stdout')).open('w') as stdout,(out/(label+'.stderr')).open('w') as stderr:
   p=subprocess.Popen(command,stdout=stdout,stderr=stderr);_,status,usage=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(status)
  report['commands'].append(dict(command=command,exit_code=p.returncode,seconds=time.monotonic()-start,max_rss_kib=usage.ru_maxrss));save();assert p.returncode==0,(out/(label+'.stderr')).read_text()[-4000:]
  print(label,'passed',flush=True)
 assert (out/'compiler.c').read_bytes()==(out/'repeat.c').read_bytes()
 assert pins=={p:sha(p) for p in pins};report.update(status='passed',generated_c_sha256=sha(out/'compiler.c'),compiler_sha256=sha(out/'goose'));save();print('Own ABI and C fixedpoint passed')
except BaseException as e:report.update(status='failed',error=repr(e));save();raise
