from pathlib import Path
import subprocess,hashlib,json,time,shutil
b=Path(__file__).resolve().parent;out=b/'optimized2';out.mkdir(exist_ok=False);c=b/'build2/compiler.c';cc=Path(shutil.which('clang')).resolve();cmd=[str(cc),'-std=gnu11','-O2',str(c),'-lm','-ldl','-pthread','-o',str(out/'goose')];start=time.monotonic();p=subprocess.run(cmd,capture_output=True,timeout=180);(out/'cc.stdout').write_bytes(p.stdout);(out/'cc.stderr').write_bytes(p.stderr)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
r=dict(status='passed' if p.returncode==0 else 'failed',input_sha256={str(x):sha(x) for x in [c,cc]},command=cmd,exit_code=p.returncode,seconds=time.monotonic()-start)
if p.returncode==0:r['compiler_sha256']=sha(out/'goose')
(out/'report.json').write_text(json.dumps(r,indent=2)+'\n');assert p.returncode==0;print(out/'goose')
