from pathlib import Path
import subprocess,time,json,hashlib,sys,shutil
b=Path(__file__).resolve().parent;r=b.parents[2];out=b/sys.argv[2];out.mkdir(exist_ok=False);compiler=Path(sys.argv[1]).resolve();expected=json.loads((b/'expected3-before-execution.json').read_text());cases=[(p,expected[p.stem]) for p in sorted((b/'controls3').glob('*.goose'))]
for path in ['storage/resizable_adt_payload_links','codegen/discarded_resizable_results']:
 p=r/'build/source/test'/str(path+'.goose');cases.append((p,(r/'build/source/test/expected'/str(p.stem+'.out')).read_text()))
results=[]
for source,want in cases:
 for level in (0,2):
  for target in ('native','wasm-direct'):
   case=source.stem+'-'+target+'-O'+str(level);artifact=out/(case+('.c' if target=='native' else '.wasm'));result=dict(case=case,source=str(source),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),expected=want,commands=[])
   commands=[('emit',[str(compiler),str(source),'--stdlib',str(r/'stdlib'),'--target',target,'--standalone','-O'+str(level),'-o',str(artifact)])]
   if target=='native':commands += [('cc',[shutil.which('clang'),'-std=gnu11','-O'+str(level),str(artifact),'-lm','-ldl','-pthread','-o',str(out/case)]),('run',[str(out/case)])]
   else:commands += [('v8',['node',str(r/'scripts/run_wasm.mjs'),str(artifact)]),('wasmtime',['python',str(r/'scripts/run_wasmtime.py'),str(artifact)])]
   for phase,cmd in commands:
    start=time.monotonic();p=subprocess.run(cmd,capture_output=True,timeout=90);(out/(case+'-'+phase+'.stdout')).write_bytes(p.stdout);(out/(case+'-'+phase+'.stderr')).write_bytes(p.stderr);ok=p.returncode==0
    if phase in ('run','v8','wasmtime'):ok=ok and p.stdout.decode()==want
    result['commands'].append(dict(phase=phase,command=cmd,seconds=time.monotonic()-start,exit_code=p.returncode,ok=ok))
    if p.returncode or phase in ('emit','cc') and not ok:break
   results.append(result);print(case,phase,ok,flush=True)
   (out/'report.json').write_text(json.dumps(dict(status='measured',compiler_sha256=hashlib.sha256(compiler.read_bytes()).hexdigest(),results=results),indent=2)+'\n')
