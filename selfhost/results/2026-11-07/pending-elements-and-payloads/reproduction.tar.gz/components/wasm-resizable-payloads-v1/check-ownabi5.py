from pathlib import Path
import subprocess,json,time,hashlib,sys
b=Path(__file__).resolve().parent;r=b.parents[2];out=b/'own-abi5';out.mkdir(exist_ok=False);compiler=b/'build5/goose';source=b/'source5/selfhost/main.goose'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
pins={str(p):sha(p) for p in [compiler,b/'build5/compiler.c',Path(__file__),*source.parent.glob('*.goose'),*(b/'source5/native').rglob('*.h')]};report=dict(status='running',method='build5 is the actual compiled full source5 compiler; its two-model ownchecks and own-generated compiler C must exactly match its clean producer C.',input_sha256=pins,commands=[])
def save():(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
save()
try:
 commands=[]
 for target in ('native','wasm-direct'):commands.append(('check-'+target,[compiler,source,'--stdlib',r/'stdlib','--target',target,'--check','--library']))
 commands.append(('repeat',[compiler,source,'--stdlib',r/'stdlib','--target','native','--standalone','-O0','-o',out/'repeat.c']))
 for label,cmd in commands:
  start=time.monotonic();p=subprocess.run(list(map(str,cmd)),capture_output=True,timeout=240);(out/(label+'.stdout')).write_bytes(p.stdout);(out/(label+'.stderr')).write_bytes(p.stderr);report['commands'].append(dict(command=list(map(str,cmd)),exit_code=p.returncode,seconds=time.monotonic()-start));save();assert p.returncode==0,p.stderr.decode()[-4000:];print(label,'passed',flush=True)
 assert (b/'build5/compiler.c').read_bytes()==(out/'repeat.c').read_bytes();assert pins=={p:sha(p) for p in pins};report.update(status='passed',generated_c_sha256=sha(out/'repeat.c'));save();print('actual compiled source5 ABI and own C fixedpoint passed')
except BaseException as e:report.update(status='failed',error=repr(e));save();raise
