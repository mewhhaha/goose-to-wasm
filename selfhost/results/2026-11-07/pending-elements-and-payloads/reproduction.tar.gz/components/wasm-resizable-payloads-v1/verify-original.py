from pathlib import Path
import tarfile,hashlib,json,subprocess
r=Path('/home/jacobt/src/goose-to-wasm');b=Path(__file__).resolve().parent
manifest_bytes=subprocess.check_output(['git','show','16a9bc16b41c0db89eb694b9522e8c5d782ce3f1:tests/conformance/cases.json'],cwd=r);manifest=json.loads(manifest_bytes);c=next(c for c in manifest['cases'] if c['id']=='upstream/storage/resizable_adt_payload_links');archive=r/manifest['upstream']['archive']
def sha(x):return hashlib.sha256(x).hexdigest()
assert sha(archive.read_bytes())==manifest['upstream']['sha256']
with tarfile.open(archive) as t:data=t.extractfile(c['source'].split(':',1)[1]).read()
source=r/'build/source/test/storage/resizable_adt_payload_links.goose';assert data==source.read_bytes()
expected=c['expect']['stdout'];assert expected==(r/'build/source/test/expected/resizable_adt_payload_links.out').read_text()
p=b/'controls8/frozen-resizable-adt-links.goose';p.write_bytes(data)
(b/'original-identity.json').write_text(json.dumps(dict(main46='16a9bc16b41c0db89eb694b9522e8c5d782ce3f1',manifest_sha256=sha(manifest_bytes),archive_sha256=sha(archive.read_bytes()),source_sha256=sha(data),expected_stdout_sha256=sha(expected.encode()),original_case=c,checked_source_equals_archive=True,checked_expected_equals_main46_manifest=True),indent=2)+'\n')
print('Main46 case, frozen archive source, checkout source, and official stdout identities match')
