from pathlib import Path
import json,hashlib,shutil
b=Path(__file__).resolve().parent;r=b.parents[2];out=b/'qualified-controls';out.mkdir(exist_ok=False);e=json.loads((b/'expected8-before-execution.json').read_text());d=json.loads((r/'tests/conformance/cases.json').read_text());cases=[]
for name in ['aliases','basic','captured','nested-enum','prefix-nested','returns','prefix-reference','pool','frozen-resizable-adt-links']:
 source=b/'controls8'/str(name+'.goose');targets=['native','wasm-direct'];provenance='independently specified before execution'
 if name=='prefix-reference':source=b/'prefix-reference-final/prefix-reference.goose';e[name]='Wrap { 12, Link { 12 } }\n'
 if name in ['pool','frozen-resizable-adt-links']:targets=['wasm-direct']
 if name=='frozen-resizable-adt-links':
  original=json.loads((b/'original-identity.json').read_text());e[name]=original['original_case']['expect']['stdout'];provenance='exact source copied from pinned main46 upstream archive; unchanged independent official stdout'
 p=out/source.name;shutil.copyfile(source,p)
 for target in targets:
  cases.append(dict(id='wasm-resizable-payloads/'+name+'/'+target,source=str(p.relative_to(r)),phase='run',target=target,levels=[0,2],expect=dict(stdout=e[name],exit=0),provenance=provenance,source_sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
manifest=dict(schema=d['schema'],upstream=d['upstream'],cases=cases);(b/'qualified-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(len(cases),'cases',sum(len(c['levels']) for c in cases),'rows')
