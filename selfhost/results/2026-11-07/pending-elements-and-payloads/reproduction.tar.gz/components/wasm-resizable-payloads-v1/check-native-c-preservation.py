from pathlib import Path
import subprocess,json,hashlib,time
b=Path(__file__).resolve().parent;r=b.parents[2];out=b/'native-c-preservation';out.mkdir(exist_ok=False);manifest=json.loads((b/'qualified-manifest.json').read_text());results=[]
for case in manifest['cases']:
 if case['target']!='native':continue
 for level in case['levels']:
  row=dict(case=case['id'],level=level,commands=[]);artifacts=[]
  for label,compiler in [('baseline46',r/'build/completion-runs/c-only-bootstrap-46/goose'),('candidate4',b/'optimized4/goose')]:
   artifact=out/(case['id'].split('/')[1]+'-O'+str(level)+'-'+label+'.c');cmd=[str(compiler),str(r/case['source']),'--stdlib',str(r/'stdlib'),'--target','native','--standalone','-O'+str(level),'-o',str(artifact)];start=time.monotonic();p=subprocess.run(cmd,capture_output=True);row['commands'].append(dict(command=cmd,exit_code=p.returncode,seconds=time.monotonic()-start));assert p.returncode==0,p.stderr;artifacts.append(artifact)
  row['equal']=artifacts[0].read_bytes()==artifacts[1].read_bytes();row['sha256']=hashlib.sha256(artifacts[1].read_bytes()).hexdigest();results.append(row)
(out/'report.json').write_text(json.dumps(dict(status='passed' if all(x['equal'] for x in results) else 'failed',results=results),indent=2)+'\n');print(sum(x['equal'] for x in results),'of',len(results),'native C exact matches')
