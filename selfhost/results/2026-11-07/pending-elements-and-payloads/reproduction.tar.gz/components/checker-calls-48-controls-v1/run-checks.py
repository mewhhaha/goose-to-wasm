from pathlib import Path
import hashlib,json,subprocess,sys,time
root=Path('/home/jacobt/src/goose-to-wasm');r=Path(__file__).resolve().parent;compiler=Path(sys.argv[1]).resolve();label=sys.argv[2];assert not (r/('verdicts-'+label+'.json')).exists()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
controls=json.loads((r/'controls.json').read_text());paths=[compiler,r/'controls.json',r/'expected-before-execution.json',Path(__file__),*(root/'stdlib').rglob('*.goose'),*[root/x['source'] for x in controls]];pins={str(p):sha(p) for p in paths};(r/('input-pins-'+label+'.json')).write_text(json.dumps(pins,indent=2)+'\n');rows=[]
for case in controls:
 assert sha(root/case['source'])==case['sha256']
 for target in ['native','wasm-direct']:
  command=list(map(str,[compiler,root/case['source'],'--stdlib',root/'stdlib','--target',target,'--check']));start=time.monotonic();p=subprocess.run(command,capture_output=True,text=True,timeout=30)
  rows.append(dict(id=case['id'],target=target,command=command,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr,seconds=time.monotonic()-start,expected_accept=case['expected_accept'],match=(p.returncode==0)==case['expected_accept']))
(r/('verdicts-'+label+'.json')).write_text(json.dumps(rows,indent=2)+'\n');assert pins=={str(p):sha(p) for p in paths}
for group in ['borrow','funval']:
 group_rows=[x for x in rows if x['id'].startswith(group)];print(group,sum(x['match'] for x in group_rows),'/',len(group_rows))
print([(x['id'],x['target'],x['exit_code'],x['stderr'][:100]) for x in rows if not x['match']])
