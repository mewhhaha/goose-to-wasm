from pathlib import Path
import hashlib,json,os,shutil,stat,time
w=Path('/home/jacobt/src/goose-to-wasm/build/completion-runs');canonical=w/'c-only-v8-39/upstream';rows=[]
def tree(p):
 result={}
 for base,dirs,files in os.walk(p):
  for name in files:
   f=Path(base)/name
   if f.is_symlink(): return None
   result[str(f.relative_to(p))]=(hashlib.sha256(f.read_bytes()).hexdigest(),stat.S_IMODE(f.stat().st_mode))
 return result
expected=tree(canonical)
for base,dirs,files in os.walk(w):
 dirs[:]=[d for d in dirs if d not in ('artifacts','.git','__pycache__')]
 if 'upstream' not in dirs:continue
 dirs.remove('upstream');p=Path(base)/'upstream'
 if p==canonical or p.is_symlink():continue
 if not any(part.startswith(('c-only-conformance-','c-only-v8-')) and any(part.startswith(prefix+str(v)) for prefix in ('c-only-conformance-','c-only-v8-') for v in range(42,47)) for part in p.parts):continue
 report=p.parent/'report.json'
 if not report.is_file():continue
 try:r=json.loads(report.read_text())
 except Exception:continue
 if 'summary' not in r or r.get('status') not in ('passed','failed'):continue
 actual=tree(p)
 if actual!=expected:continue
 before=hashlib.sha256(report.read_bytes()).hexdigest()
 shutil.rmtree(p);p.symlink_to(canonical,target_is_directory=True)
 assert hashlib.sha256(report.read_bytes()).hexdigest()==before
 rows.append(dict(path=str(p),files=len(expected),report_sha256=before));print('dedup',p,flush=True)
(w/'fixture-dedup-47.json').write_text(json.dumps(dict(status='passed',method='Byte-and-mode-identical completed copied fixture trees replaced by absolute symlink to protected immutable canonical tree; existing report bytes unchanged',canonical=str(canonical),rows=rows),indent=2)+'\n')
print('trees',len(rows),flush=True)
