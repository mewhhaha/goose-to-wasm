from pathlib import Path
import hashlib,json,subprocess
w=Path('/home/jacobt/src/goose-to-wasm/build/completion-runs');out=w/'snapshot-47-reproduced';out.mkdir(exist_ok=False);parent=json.loads((w/'c-only-bootstrap-46/report.json').read_text());names=['selfhost/'+n for n in parent['source_sha256']]+list(parent['asset_sha256'])+['native/tests/check.py','native/tests/var_relative.c','native/tests/bounded_cells.c']
for name in names:
 source=w/'snapshot-46'/name;target=out/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(source.read_bytes())
for item in json.loads((w/'delivery-47.json').read_text())['patches']:
 path=w/item['path'];assert hashlib.sha256(path.read_bytes()).hexdigest()==item['sha256'];r=subprocess.run(['patch','--fuzz=0','-p1','-i',str(path)],cwd=out,text=True,capture_output=True);assert r.returncode==0,(r.stdout,r.stderr)
for row in json.loads((w/'delivery-47.json').read_text()).get('documentation', []):
 target=out/row['path'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(subprocess.check_output(['git','show','16a9bc16b41c0db89eb694b9522e8c5d782ce3f1:'+row['path']],cwd=w.parents[1]))
 result=subprocess.run(['patch','--fuzz=0','-p1','-i',str(w/row['patch'])],cwd=out,text=True,capture_output=True);assert result.returncode==0,(result.stdout,result.stderr)
 assert hashlib.sha256(target.read_bytes()).hexdigest()==row['sha256'],row['path']
proof=json.loads((w/'c-only-bootstrap-47/report.json').read_text());pins={'selfhost/'+name:value for name,value in proof['source_sha256'].items()};pins.update(proof['asset_sha256'])
for name in ['native/tests/check.py','native/tests/var_relative.c','native/tests/bounded_cells.c']:pins[name]=hashlib.sha256((w/'snapshot-47'/name).read_bytes()).hexdigest()
for name,value in pins.items():assert hashlib.sha256((out/name).read_bytes()).hexdigest()==value,name
(w/'reproduction-47.json').write_text(json.dumps(dict(status='passed',method='Sealed patches independently reproduce all qualified compiler/runtime inputs and permanent C controls from the verified46 parent.',verified_sha256=pins),indent=2)+'\n');print('Reproduced',len(pins),'inputs')
