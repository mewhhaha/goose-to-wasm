from pathlib import Path
import copy,hashlib,json,shutil,subprocess
root=Path('/home/jacobt/src/goose-to-wasm');work=root/'build/completion-runs';path=root/'tests/conformance/cases.json';current=json.loads(path.read_text());base=json.loads(subprocess.check_output(['git','show','HEAD:tests/conformance/cases.json'],cwd=root,text=True));assert current['cases'][:len(base['cases'])]==base['cases'];manifest=copy.deepcopy(base);added=[];sources={};ids={c['id'] for c in manifest['cases']}
def retain(original,prefix):
 case=copy.deepcopy(original);source=root/case['source'];assert source.is_file(),source
 target=root/'tests/fixtures/contracts'/prefix/source.name;target.parent.mkdir(parents=True,exist_ok=True)
 if target.exists():assert target.read_bytes()==source.read_bytes(),target
 else:shutil.copyfile(source,target)
 name=target.relative_to(root).as_posix();sources[name]=hashlib.sha256(target.read_bytes()).hexdigest();case['source']=name;case['id']='corpus/contracts/'+prefix+'/'+case['id'];assert case['id'] not in ids,case['id'];ids.add(case['id']);added.append(case)
config=json.loads((work/'delivery-47.json').read_text())
for item in config['control_sets']:
 rows=json.loads((work/item['path']).read_text())
 if item['schema']=='checker':
  for row in rows:
   assert hashlib.sha256((root/row['source']).read_bytes()).hexdigest()==row['sha256']
   for target in ['native','wasm-direct']:
    phase='type-error';expect={}
    if row['expected_accept']:phase='run';expect=dict(stdout=row['stdout'],exit=0)
    retain(dict(id=row['id']+'/'+target,source=row['source'],target=target,phase=phase,levels=[0,2],expect=expect,provenance=row['contract']),item['prefix'])
 elif item['schema']=='manifest':
  for case in rows['cases']:retain(case,item['prefix'])
 else:raise RuntimeError('Unknown control schema')
manifest['cases'].extend(added);path.write_text(json.dumps(manifest,indent=2)+'\n');meta=dict(status='migrated; composed47 runtime qualification pending',cases=len(added),rows=sum(len(c['levels']) for c in added),sources=sources)
(work/'new-controls-47.json').write_text(json.dumps(meta,indent=2)+'\n');print('New47',meta['cases'],'cases',meta['rows'],'rows',len(sources),'sources; total',sum(len(c['levels']) for c in manifest['cases']))
