from pathlib import Path
import hashlib,json,subprocess
w=Path('/home/jacobt/src/goose-to-wasm/build/completion-runs');root=w.parents[1]
def read(name):return json.loads((w/name).read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
full=read('c-only-conformance-47-qualified/report.json');v8=read('c-only-v8-47-after-enospc/report.json');public=read('public-47/build/bootstrap/report.json');proof=read('c-only-bootstrap-47/report.json')
assert full['summary']['selected']==6997
assert v8['status']==public['status']==proof['status']=='passed'
for report in [full,v8,proof]:assert report['input_sha256']==report['input_sha256_after']
subprocess.run(['python',w/'compare_batch_qualified45.py','47'],cwd=root,check=True)
comparison=read('comparison-47.json');assert not comparison['shared_regressions'] and not comparison['new_failures'] and not comparison['removed_rows']
counts=dict(compiler_refusal=0,c_compiler_failure=0,executed_mismatch=0)
for row in full['results']:
 if row['status']=='pass' or row['phase']!='run':continue
 if full['commands'][row['compile_command']]['exit_code']!=0:counts['compiler_refusal']+=1
 elif 'run_command' not in row:counts['c_compiler_failure']+=1
 else:counts['executed_mismatch']+=1
(w/'remaining-phases-47.json').write_text(json.dumps(counts,indent=2)+'\n')
result=dict(status='qualified-partial-conformance',summary=full['summary'],shared_gains=len(comparison['shared_gains']),shared_regressions=0,new_rows=len(comparison['new_rows']),new_failures=0,runtime_failure_detail=counts,verified_reports={name:sha(w/name) for name in ['c-only-conformance-47-qualified/report.json','c-only-v8-47-after-enospc/report.json','c-only-bootstrap-47/report.json','public-47/build/bootstrap/report.json']},note='Initial fixture extraction and output-write ENOSPC evidence is retained separately; final full cohorts were collected after cleanup with unchanged compiler/source/expectations.')
(w/'qualification-final-47.json').write_text(json.dumps(result,indent=2)+'\n');print(result,flush=True)
