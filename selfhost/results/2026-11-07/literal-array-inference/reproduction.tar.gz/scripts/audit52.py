from pathlib import Path
import hashlib,json,subprocess
root=Path('/home/jacobt/src/goose-to-wasm');w=root/'build/completion-runs'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
config=read(w/'delivery-52.json');parent=read(w/'c-only-bootstrap-51/report.json');proof=read(w/'c-only-bootstrap-52/report.json');assembly=read(w/'snapshot-52-assembly.json')
assert config['base_commit']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert proof['status']=='passed' and proof['fixed_point']
changed=[k for k in parent['source_sha256'] if parent['source_sha256'][k]!=proof['source_sha256'][k]];assert changed==['checker.goose'],changed
assert proof['source_sha256']['checker.goose']=='4bf1b5ecbd98508cbe4ca1100c650542696fc2660578aae67d50cc9ef03175ed'
assert proof['asset_sha256']==parent['asset_sha256']
for name,value in assembly['sha256'].items():assert sha(w/'snapshot-52'/name)==value,name
native=read(w/'native-runtime-49-final/report.json');assert len(native['runs'])==45 and all(x['returncode']==0 for x in native['runs'])
assert native['driver_sha256']==sha(w/'snapshot-52/native/tests/check.py')
for name in ['runs.c','bounded_cells.c','var_relative.c']:assert native['inputs_sha256'][name]==sha(w/'snapshot-52/native/tests'/name)
for name,value in read(w/'new-controls-52.json')['sources'].items():assert sha(root/name)==value,name
old=json.loads(subprocess.check_output(['git','show',config['base_commit']+':tests/conformance/cases.json'],cwd=root));new=read(root/'tests/conformance/cases.json');byid={x['id']:x for x in new['cases']};assert len(byid)==len(new['cases'])
for case in old['cases']:assert byid[case['id']]==case,case['id']
assert read(w/'astra-literal-arguments-52-native-wasmtime/report.json')['summary']==dict(selected=8,passed=8,failed=0)
assert read(w/'astra-literal-arguments-52-v8/report.json')['summary']==dict(selected=4,passed=4,failed=0)
comparison=read(w/'comparison-52.json');assert not comparison['shared_regressions'] and not comparison['new_failures'] and len(comparison['shared_gains'])==2 and len(comparison['new_rows'])==68
report=dict(status='passed',parent_commit=config['base_commit'],only_compiler_change=changed,source_sha256=proof['source_sha256'],unchanged_native_assets=proof['asset_sha256'],prior_manifest_rows_preserved=sum(len(x['levels']) for x in old['cases']),new_rows=68,independent_guard_rows=dict(native_and_wasmtime=8,v8_wasm=4),native_header_reference='Exact unchanged49 source/driver/tests; all45qualifiedcommands reused.',component_metadata_note='Nested source-final/source-pins.json retains a stale baseline checker value; immutable final before/after/build pins, independent review, root58file assembly and canonical proof bind actual4bf1b5ec source. No stale map was used as root source authority.',source_review_sha256=sha(w/'astra-literal-arguments-52-2026-11-07/source-review.json'),no_oracle_execution=True)
(w/'composition52-audit.json').write_text(json.dumps(report,indent=2)+'\n');print('Root52 source/manifest/header/guard audit passed')
