from pathlib import Path
import concurrent.futures,hashlib,json,subprocess,time
root=Path('/home/jacobt/src/goose-to-wasm');w=root/'build/completion-runs/literal-arguments-52';compiler=w/'build-v1/goose'
assert json.loads((w/'build-v1/report.json').read_text())['status']=='passed'
manifest=w/'controls-manifest-final.json'
def run(name,cmd):
 start=time.monotonic();r=subprocess.run(list(map(str,cmd)),cwd=root,capture_output=True,timeout=240)
 (w/(name+'.stdout')).write_bytes(r.stdout);(w/(name+'.stderr')).write_bytes(r.stderr)
 return dict(name=name,command=list(map(str,cmd)),exit_code=r.returncode,seconds=time.monotonic()-start)
base=['python',root/'tests/conformance.py','--compiler',compiler,'--manifest',manifest,'--timeout','30']
checks=run('final-checks',base+['--output-dir',w/'final-checks','--frontend-only','--levels','0']);assert checks['exit_code']==0,checks
jobs=[('final-wasmtime',base+['--output-dir',w/'final-wasmtime','--engine','wasmtime']),('final-v8',base+['--output-dir',w/'final-v8','--filter','/wasm-direct','--engine','v8']),('final-front',['python',root/'build/completion-runs/durable-tools/front_gate.py',compiler,w/'front-baseline',w/'final-front']),('final-own-source',[compiler,w/'source-final/selfhost/main.goose','--stdlib',root/'stdlib','--target','native','--check'])]
results=[checks]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 for result in pool.map(lambda row:run(*row),jobs):results.append(result);print(result['name'],result['exit_code'],round(result['seconds'],2),flush=True)
(w/'final-commands.json').write_text(json.dumps(results,indent=2)+'\n');assert all(r['exit_code']==0 for r in results),results
front=json.loads((w/'final-front/comparison.json').read_text());assert not any(r['regressions'] for r in front.values()),front
pins=json.loads((w/'final-pins-before.json').read_text());after={name:hashlib.sha256(Path(name).read_bytes()).hexdigest() for name in pins};assert pins==after
(w/'final-pins-after.json').write_text(json.dumps(after,indent=2)+'\n')
(w/'final-seal.json').write_text(json.dumps(dict(status='passed',baseline='snapshot-51',source='source-final',patch='candidate-v1.patch',compiler='build-v1/goose',source_pins_equal=True,frontier=front,checks=json.loads((w/'final-checks/report.json').read_text())['summary'],wasmtime=json.loads((w/'final-wasmtime/report.json').read_text())['summary'],v8=json.loads((w/'final-v8/report.json').read_text())['summary'],own_source=next(r for r in results if r['name']=='final-own-source')),indent=2)+'\n')
print('SEALED',flush=True)
