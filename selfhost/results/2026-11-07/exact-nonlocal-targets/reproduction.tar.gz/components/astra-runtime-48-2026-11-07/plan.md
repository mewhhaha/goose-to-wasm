# Runtime refusal hills after delivered47 — 2026-11-07

Delivered baseline: main `79f92914c419c40619a0ca513c158bb5d153b990`, code `e6719a1`; 6867/6997 pass, 130 fail. Of those, 122 rows are 61 original runtime sources refused by the Goose compiler at O0/O2; none reached a failing C compiler or execution. This scout runs no compiler or oracle and changes no live or sealed source. The current nonlocal-ledger experiment is separate.

`refusal-clusters.json` pins all61 exact fixture bytes, both row diagnostics and the frozen expected manifest entries. Observed first boundaries are **46 checker/lifetime-only sources, 11 native-lowering-only, and 4 native lowering plus recursive-region validation**. The nine relative-image/cursor sources and four frontend self-relative-copy-gated sources are not cheap general admission wins: retain their owner/bounds/copy/landing requirements. Native pointee owner has that separate work.

## 1. Native result allocation for all-return constructs — already assigned

Whole-source candidates (10 original rows): `typing/diverging_values`, `codegen/recursive_loop_walk`, `codegen/self_slice_types`, `optimizer/tail_reference_params`, `stdlib/stdlib_json`. The JSON errors are in frozen-import `stdlib/json.goose:1072,1083,1091,1101`, all-return MATCH accessors; their fixture itself is otherwise admitted. Each currently has only `c: expression lacks a checked type` errors.

Canonical47 `codegen_c.goose:2468` and `:2616` allocate a result for MATCH/IF even when the checker leaves type_id=-1 for a construct that always exits. `cc_block:1248` already avoids this. Guard only these proven-diverging no-result allocations, keep emitting condition/scrutinee/arms/exits/cleanup, and retain `cc_temp:263`'s invariant for reachable untyped expressions. Preserve allocation for one-live-arm values.

Primary `codegen_nodes.h:414` IfExpr::CgAny and `:493` MatchExpr::CgAny route into an optional Dst; statement hooks `:1259–1263` pass Dst{}. `codegen_values.h:1441` CtlValX is the separate actual-value temporary path. Do not globally treat missing types as void. Independent eight pre-pinned controls: `native-divergence-controls.json` (scalar/tuple/nonfixed, RHS all-return, nonlocal condition effects, live-arm precision, false guard, invalid missing result).

`lifetimes/cycle_read_through_context` shares this allocation failure but independently rejects transient data regions; **exclude its two rows from this hill's potential gain**. Whole unchanged originals must emit native C, compile, and match original stdout at O0/O2 before any ten-row claim.

## 2. Multi-assignment writes through reference targets

Whole-source candidate: **`codegen/multi_assign` (2 rows)**. The sole recorded errors are generic `fill<T>(a:T&,b:T&,v:T)` at line19. Canonical checker `:5814–5815` compares target expression T& directly against tuple component T. Ordinary `=` already writes through references; the multi-target path omitted that target normalization.

Primary `parser.h:1931–1964` lowers multi-assignment to one hidden multi-result binding followed by ordinary assignments in target order. `typecheck_flow.h:2465–2494` handles result temporaries and dereferences a plain-reference `=` target. This is also the source authority for evaluation order: call once first, then each target expression and store in order.

Minimal coherent change: use the assigned pointee type for an ordinary plain-reference target in the existing multi-assignment check, preserving the target node's storage/reference identity and the normal readonly, optional-narrowing, assignment-state and lifetime checks. Do not broadly make tuple conversions implicit or erase reference components. Native `codegen_c.goose:1969–1989` already evaluates the call once, computes targets in order, dereferences the target, and stores the component; no backend redesign is indicated for this original. Keep `errors_tc/multi_assign_count` and `multi_assign_reference` invalid, and keep nonfixed-reference-result copies explicit (primary2469–2477).

Independent four controls: `multi-assign-controls.json`: scalar reference targets including repeated same target (last write wins), call mutating target indices (call precedes target evaluation), readonly target reject, incompatible component reject. Existing original covers resizable string/record-tail assignment, ordinary field/element destinations, slices, loop replay and generic f64 refs. Those whole-source behaviors are part of completion, not extra optional coverage.

Cheap path: checker-only probe against canonical47 on four controls plus original/error guards; then ONE private compiler build and unchanged original O0/O2 native compile/run. Run Wasm preservation too because the checker is shared. If mere acceptance exposes a later lowering issue, preserve it as unqualified; do not count those rows recovered.

## 3. Loaded owned values lose top-level const; views retain it

Whole-source candidate: **`codegen/const_global_folding` (2 rows)**. Sole recorded refusal is line48 `paint.r=0.25` after `const RED=Color{...}; var paint=RED;`. This is a new owned copy, so it may be mutated while RED remains unchanged.

Primary `typecheck_types.h:702–714` LoadType explicitly removes top const from non-reference/non-slice values; reference/slice const describes the pointee and remains. `typecheck_nodes.h:84–109` distinguishes the loaded value's type from the original storage's writability. `typecheck_flow.h:2194–2200` only reapplies const from an explicit const declaration or a readonly inferred reference/slice.

Canonical `check_loaded_type:1475–1482` decodes varint/relative reference storage but omits owned top-const removal. Also `check_read_value_type:1483–1491` invokes it only for TY_REF, while N_NAME returns the stored type at `:4788`; simply adding a flag strip inside check_loaded_type without auditing the value-read call path will miss this case. Normalize actual owned-value reads/inference, using a new/reused plain type rather than mutating shared Type records. Retain stored symbol/field type and check_readonly authority for taking addresses or writing original const storage. Preserve nested const fields, const reference and slice qualifiers, and borrowed nonfixed storage. This is not a blanket readonly relaxation.

Independent four controls: `plain-value-load-controls.json`: mutable owned struct and array copies with unchanged source, readonly reference and slice writes rejected. Add a nested const field and direct original mutation negative when implementing. The full original exercises constant initializer chains, const arrays/fills, typed scalar globals, nonliteral global init order and mutable copied aggregate; native lowering already handles those forms and currently reports no other blocker.

Cheap path: checker-only probe first, including existing readonly/constant controls; then full unchanged original O0/O2 native stdout and shared-checker Wasm preservation. This is independent of reference target normalization in hill2; keep separate patches/probe evidence even if building one combined sibling later.

## Kept separate

The 46 frontend refusals include broader call/generic-literal inference, branch slice/reference adaptation, lifetime roots/held-expression shrink precision, flow joins and self-relative copy gates. Their first diagnostic alone does not show whole-row recovery. In particular statement result-demand (`discarded_resizable_results`, `cycle_scratch_locals`) is promising but needs a dedicated CheckStmtExpr-equivalent audit (`typecheck_flow.h:2151–2170`), and scratch recursion must retain region validation. Literal parameters and typed-array inference touch specialization keys and replayed constant-use obligations; avoid folding them into top-const loads.

The eight accepted-invalid sources are a different ledger. Proposed qualified nonlocal needs v3 addresses two; the six remaining are `construct_use_param_global`, `shrink_global_unreached`, `return_const_cycle`, `cycle_read_through_target`, `checkfree_loaded_index`, `checkfree_parallel`. None is claimed fixed by these runtime hills.

All16 authored controls and expectations were pinned before any execution; source-only candidates remain hypotheses until unchanged original runtime gates pass. Keep gains, regressions, source/compiler/stdlib/engine hashes and compile/runtime costs separate. No performance improvement is claimed.
