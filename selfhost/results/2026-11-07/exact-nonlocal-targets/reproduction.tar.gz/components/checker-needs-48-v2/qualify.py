from pathlib import Path
import concurrent.futures, hashlib, json, subprocess, time
r=Path(__file__).resolve().parent;root=r.parents[2];base=root/'build/completion-runs/c-only-bootstrap-47/goose';exe=r/'build/goose';library=root/'stdlib'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(name,value):(r/name).write_text(json.dumps(value,indent=2)+'\n')
assert sha(base)==json.loads((base.parent/'report.json').read_text())['executable_sha256']
controls=json.loads((r/'controls.json').read_text())
suites=json.loads((r/'front-manifest.json').read_text());names=list(suites)
for rows in suites.values():
 for row in rows:assert sha(row['source'])==row['sha256']
paths={Path(row['source']) for rows in suites.values() for row in rows};paths.update([base,exe,Path(__file__),root/'scripts/run_wasm.mjs',root/'scripts/run_wasmtime.py',r/'controls.json',*library.rglob('*.goose'),*(r/'source/selfhost').glob('*.goose'),*[root/case['source'] for case in controls],*[root/p for case in controls for p in case.get('assets',{})]])
pins={str(p):sha(p) for p in paths};save('qualification-input-pins.json',pins)
def run(command,timeout=30):
 started=time.monotonic()
 try:
  p=subprocess.run(list(map(str,command)),cwd=root,capture_output=True,text=True,timeout=timeout)
  return dict(command=list(map(str,command)),exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr,seconds=time.monotonic()-started)
 except subprocess.TimeoutExpired:return dict(command=list(map(str,command)),exit_code=124,stdout='',stderr='TIMEOUT',seconds=time.monotonic()-started)
focus=[]
for label,compiler in [('before',base),('after',exe)]:
 for case in controls:
  assert sha(root/case['source'])==case['sha256']
  for target in ['native','wasm-direct']:
   row=run([compiler,root/case['source'],'--stdlib',library,'--target',target,'--check'])
   row.update(id=case['id'],label=label,target=target,expected_accept=case['expected_accept'],match=(row['exit_code']==0)==case['expected_accept']);focus.append(row)
 save('focus-'+label+'.json',[row for row in focus if row['label']==label]);print('focus',label,sum(x['match'] for x in focus if x['label']==label),'/',sum(x['label']==label for x in focus),flush=True)
results={}
for label,compiler in [('before',base),('after',exe)]:
 results[label]={}
 for name,rows in suites.items():
  def check(row):
   value=run([compiler,row['source'],'--stdlib',library,'--check']);value['source']=row['source'];return value
  with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:out=list(pool.map(check,rows))
  results[label][name]=out;save('front-'+label+'-'+name+'.json',out);print(label,name,sum(x['exit_code']==0 for x in out),'/',len(out),flush=True)
changes=[];losses=[];invalid=[]
for name in names:
 for before,after in zip(results['before'][name],results['after'][name]):
  if before['exit_code']!=after['exit_code']:
   row=dict(suite=name,source=after['source'],before=before['exit_code'],after=after['exit_code']);changes.append(row)
   if name=='negative-type' and before['exit_code']!=0 and after['exit_code']==0 or name!='negative-type' and before['exit_code']==0 and after['exit_code']!=0:losses.append(row)
  if after['exit_code'] not in [0,1]:invalid.append(after)
comparison=dict(changes=changes,losses=losses,compiler_failures=invalid,total=sum(map(len,suites.values())))
save('front-comparison.json',comparison);print(comparison,flush=True)
own=run([exe,r/'source/selfhost/main.goose','--stdlib',library,'--check'],180);save('own-source.json',own);print('own',own['exit_code'],own['seconds'],flush=True)
runtime=[];out=r/'runtime';out.mkdir(exist_ok=False)
for case in controls:
 if not case['expected_accept']:continue
 c=out/(case['id']+'.c');binary=out/case['id'];steps=[]
 steps.append(run([exe,root/case['source'],'--stdlib',library,'--target','native','--standalone','-O0','-o',c]))
 if steps[-1]['exit_code']==0:steps.append(run(['/usr/bin/clang-23','-std=gnu11','-O0',c,'-lm','-ldl','-pthread','-o',binary]))
 if len(steps)==2 and steps[-1]['exit_code']==0:steps.append(run([binary]))
 ok=len(steps)==3 and all(x['exit_code']==0 for x in steps) and steps[-1]['stdout']==case['stdout']
 runtime.append(dict(id=case['id'],expected_stdout=case['stdout'],steps=steps,match=ok))
 save('runtime.json',runtime)
print('runtime',sum(x['match'] for x in runtime),'/',len(runtime),flush=True)

wasm_runtime=[]
for case in controls:
 if not case['expected_accept']:continue
 module=out/(case['id']+'.wasm');emission=run([exe,root/case['source'],'--stdlib',library,'--target','wasm-direct','-O0','-o',module])
 for engine,command in [('v8',['node',root/'scripts/run_wasm.mjs',module]),('wasmtime',['python',root/'scripts/run_wasmtime.py',module])]:
  steps=[emission]
  if emission['exit_code']==0:steps.append(run(command))
  ok=len(steps)==2 and all(x['exit_code']==0 for x in steps) and steps[-1]['stdout']==case['stdout']
  wasm_runtime.append(dict(id=case['id'],engine=engine,expected_stdout=case['stdout'],steps=steps,match=ok))
 save('runtime-wasm.json',wasm_runtime)
print('runtime-wasm',sum(x['match'] for x in wasm_runtime),'/',len(wasm_runtime),flush=True)

after={name:sha(name) for name in pins};save('qualification-input-pins-after.json',after);assert after==pins
assert not losses and not invalid and own['exit_code']==0
assert all(x['match'] for x in focus if x['label']=='after')
assert all(x['match'] for x in runtime)
assert all(x['match'] for x in wasm_runtime)
