from pathlib import Path
import concurrent.futures,hashlib,json,subprocess,time
root=Path('/home/jacobt/src/goose-to-wasm');r=Path(__file__).resolve().parent;base=r.parent/'checker-needs-48-baseline-probe-v1/build/goose';candidate=r.parent/'checker-needs-48-candidate-probe-v1/build/goose'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(name,value):(r/name).write_text(json.dumps(value,indent=2)+'\n')
suites=json.loads((r/'front-manifest.json').read_text());paths={Path(row['source']) for rows in suites.values() for row in rows};paths.update([base,candidate,Path(__file__),r/'front-manifest.json',*(root/'stdlib').rglob('*.goose')]);pins={str(p):sha(p) for p in paths};save('input-pins.json',pins)
for rows in suites.values():
 for row in rows:assert sha(row['source'])==row['sha256']
results={}
for label,compiler in [('before',base),('after',candidate)]:
 results[label]={}
 for name,rows in suites.items():
  def check(row):
   command=list(map(str,[compiler,row['source'],root/'stdlib']));start=time.monotonic();p=subprocess.run(command,capture_output=True,text=True,timeout=30);return dict(command=command,source=row['source'],exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr,seconds=time.monotonic()-start)
  with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:out=list(pool.map(check,rows))
  results[label][name]=out;save('front-'+label+'-'+name+'.json',out);print(label,name,sum(x['exit_code']==0 for x in out),'/',len(out),flush=True)
changes=[];losses=[];invalid=[]
for name in suites:
 for before,after in zip(results['before'][name],results['after'][name]):
  if before['exit_code']!=after['exit_code']:
   row=dict(suite=name,source=after['source'],before=before['exit_code'],after=after['exit_code']);changes.append(row)
   if name=='negative-type' and before['exit_code']!=0 and after['exit_code']==0 or name!='negative-type' and before['exit_code']==0 and after['exit_code']!=0:losses.append(row)
  if after['exit_code'] not in [0,1]:invalid.append(after)
report=dict(changes=changes,losses=losses,compiler_failures=invalid,total=sum(map(len,suites.values())),producer='canonical46 builds private frozen47 and candidate checker probes; no canonical47 compiler timing claim')
save('comparison.json',report);save('input-pins-after.json',{str(p):sha(p) for p in paths});assert pins=={str(p):sha(p) for p in paths};print(report,flush=True);assert not losses and not invalid
