from pathlib import Path
exec((Path(__file__).resolve().parent/'run.py').read_text().split('items=plan')[0])
astra=root/'build/completion-runs/astra-runtime-48-2026-11-07'; rows=json.loads((astra/'native-divergence-controls.json').read_text()); items=[]
for row in rows:
 src=root/row['source'];assert sha(src)==row['sha256'];item={'name':'astra/'+row['id'],'source':str(src)}
 if row['expected_accept']:
  expected=r/'controls'/(row['id']+'.out');expected.write_text(row['stdout']);item.update(expected=str(expected),expected_sha256=sha(expected))
 else:item.update(negative=True,diagnostic='')
 items.append(item)
for name,expected in [('ordinary_regions','ordinary regions ok\n'),('large_values','large values ok\n'),('images','native images ok\n'),('receiving_views','receiving views ok\n'),('results','native result channels ok\n'),('relative','native fixed relatives ok\n'),('variable_images','native canonical images ok\n')]:
 out=r/'controls'/(name+'.out');out.write_text(expected);items.append({'name':'native/'+name,'source':str(r/'source/native/tests'/(name+'.goose')),'expected':str(out),'expected_sha256':sha(out)})
(r/'extra-plan.json').write_text(json.dumps(items,indent=2)+'\n')
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 futures=[pool.submit(case,item,level,version) for item in items for level in [0,2] for version in ['baseline','candidate']]
 for future in concurrent.futures.as_completed(futures):
  row=future.result();records.append(row);(r/'extra-results.json').write_text(json.dumps(records,indent=2)+'\n');print(row['version'],row['case'],row['level'],'PASS' if row['passed'] else 'FAIL',row['emit']['exit'],flush=True)
