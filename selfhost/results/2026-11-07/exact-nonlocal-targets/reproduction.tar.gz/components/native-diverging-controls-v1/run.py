from pathlib import Path
import subprocess,json,time,hashlib,concurrent.futures
r=Path(__file__).resolve().parent; root=r.parents[2]; plan=json.loads((r/'plan.json').read_text()); records=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(cmd,stem):
 t=time.monotonic(); p=subprocess.run(list(map(str,cmd)),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180); (stem.with_suffix('.stdout')).write_bytes(p.stdout);(stem.with_suffix('.stderr')).write_bytes(p.stderr)
 return {'command':list(map(str,cmd)),'exit':p.returncode,'seconds':time.monotonic()-t,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest(),'stdout':p.stdout.decode(errors='replace'),'stderr':p.stderr.decode(errors='replace')}
def case(item,level,version):
 stem=r/'runs'/version/(item['name'].replace('/','__')+f'-O{level}');stem.mkdir(parents=True,exist_ok=True)
 compiler=r/'goose'
 if version=='baseline':compiler=root/'build/completion-runs/c-only-bootstrap-47/goose'
 src=Path(item['source']); result={'case':item['name'],'level':level,'version':version,'source_sha256':sha(src),'compiler_sha256':sha(compiler),'expected_sha256':item.get('expected_sha256')}
 emit=run([compiler,src,'--stdlib',r/'stdlib','--target','native',f'-O{level}','--standalone','-o',stem/'program.c'],stem/'emit');result['emit']=emit
 if emit['exit']:
  result['passed']=item.get('negative',False) and item['diagnostic'] in emit['stderr'];return result
 if item.get('negative'):result['passed']=False;return result
 compile=run(['/usr/bin/clang-23','-std=gnu11','-O2',stem/'program.c','-lm','-ldl','-pthread','-o',stem/'program'],stem/'clang');result['clang']=compile
 if compile['exit']:result['passed']=False;return result
 execute=run([stem/'program'],stem/'execute');result['execute']=execute;result['generated_c_sha256']=sha(stem/'program.c');result['passed']=execute['exit']==0 and execute['stdout'].encode()==Path(item['expected']).read_bytes();return result
items=plan['tests']+[{'name':'control/positive','source':str(r/'controls/positive.goose'),'expected':str(r/'controls/positive.out'),'expected_sha256':sha(r/'controls/positive.out')},{'name':'control/negative','source':str(r/'controls/negative.goose'),'negative':True,'diagnostic':'value cannot implicitly convert to the required type'}]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 futures=[pool.submit(case,item,level,version) for item in items for level in [0,2] for version in ['baseline','candidate']]
 for f in concurrent.futures.as_completed(futures):
  row=f.result();records.append(row);(r/'paired-results.json').write_text(json.dumps(records,indent=2)+'\n');print(row['version'],row['case'],row['level'],'PASS' if row['passed'] else 'FAIL',row['emit']['exit'],flush=True)
