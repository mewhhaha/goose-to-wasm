from pathlib import Path
import copy,hashlib,json,shutil,subprocess
root=Path('/home/jacobt/src/goose-to-wasm');work=root/'build/completion-runs';config=json.loads((work/'delivery-48.json').read_text());base=json.loads(subprocess.check_output(['git','show','HEAD:tests/conformance/cases.json'],cwd=root,text=True));manifest=copy.deepcopy(base);ids={c['id'] for c in manifest['cases']};added=[];sources={}
def retain_file(source,prefix,expected=None):
 source=root/source;assert source.is_file(),source
 data=source.read_bytes();value=hashlib.sha256(data).hexdigest()
 if expected is not None:assert value==expected,source
 target=root/'tests/fixtures/contracts'/prefix/source.name;target.parent.mkdir(parents=True,exist_ok=True)
 if target.exists():assert target.read_bytes()==data,target
 else:target.write_bytes(data)
 name=target.relative_to(root).as_posix();sources[name]=value;return name
for item in config['control_sets']:
 rows=json.loads((work/item['path']).read_text())
 for row in rows:
  source=retain_file(row['source'],item['prefix'],row['sha256']);deps=[]
  for path,value in row.get('assets',{}).items():deps.append(retain_file(path,item['prefix'],value))
  for target in item.get('targets',['native','wasm-direct']):
   phase='type-error';expect={}
   if row['expected_accept']:phase='run';expect=dict(stdout=row['stdout'],exit=0)
   case=dict(id='corpus/contracts/'+item['prefix']+'/'+row['id']+'/'+target,source=source,target=target,phase=phase,levels=[0,2],expect=expect,provenance=row['contract']);assert case['id'] not in ids;ids.add(case['id'])
   if deps:case['dependencies']=deps
   added.append(case)
manifest['cases'].extend(added);(root/'tests/conformance/cases.json').write_text(json.dumps(manifest,indent=2)+'\n');meta=dict(status='migrated; composed48 execution pending',cases=len(added),rows=sum(len(c['levels']) for c in added),sources=sources);(work/'new-controls-48.json').write_text(json.dumps(meta,indent=2)+'\n');print('New48',meta['rows'],'rows',len(sources),'source/helper files; total',sum(len(c['levels']) for c in manifest['cases']))
