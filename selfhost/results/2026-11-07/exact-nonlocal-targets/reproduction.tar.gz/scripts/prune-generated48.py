from pathlib import Path
import hashlib,json,shutil,time
work=Path('/home/jacobt/src/goose-to-wasm/build/completion-runs');rows=[];start=time.monotonic()
for name in ['c-only-conformance-47-qualified','c-only-v8-47-qualified','c-only-v8-47-after-enospc']:
 cohort=work/name;report=cohort/'report.json';data=json.loads(report.read_text());assert 'summary' in data and data['input_sha256']==data['input_sha256_after'];identity=hashlib.sha256(report.read_bytes()).hexdigest()
 for folder in [cohort/'artifacts',*cohort.glob('shard-*/artifacts')]:
  if not folder.is_dir() or folder.is_symlink():continue
  files=[p for p in folder.rglob('*') if p.is_file()]
  for p in files:assert str(p) not in data['input_sha256'],p
  rows.append(dict(path=str(folder),files=len(files),bytes=sum(p.stat().st_size for p in files),report_sha256=identity));shutil.rmtree(folder)
 assert hashlib.sha256(report.read_bytes()).hexdigest()==identity
out=dict(status='passed',scope='Only completed47 unpinned generated program files removed; source, reports, seeds, benchmark artifacts and all active agent inputs retained.',agent_coordination='Both active coding owners confirmed no pins into these generated-artifact directories before cleanup.',seconds=time.monotonic()-start,folders=rows);(work/'artifact-pruning-48.json').write_text(json.dumps(out,indent=2)+'\n');print('Pruned',sum(x['files'] for x in rows),'generated files in',round(out['seconds'],2),'seconds',flush=True)
