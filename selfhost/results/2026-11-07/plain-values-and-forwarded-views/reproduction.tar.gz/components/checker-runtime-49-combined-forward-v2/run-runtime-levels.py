from pathlib import Path
import hashlib,json,subprocess,sys,time
root=Path('/home/jacobt/src/goose-to-wasm');r=Path(__file__).resolve().parent;compiler=Path(sys.argv[1]).resolve();label=sys.argv[2];group=''
level='-O0'
if len(sys.argv)>3:level=sys.argv[3]
out=r/('runtime-'+label);out.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
controls=json.loads((r/'controls.json').read_text());paths=[compiler,r/'controls.json',r/'expected-before-execution.json',Path(__file__),root/'scripts/run_wasm.mjs',root/'scripts/run_wasmtime.py',*(root/'stdlib').rglob('*.goose'),*[root/x['source'] for x in controls],*[root/p for case in controls for p in case.get('assets',{})]];pins={str(p):sha(p) for p in paths};(out/'input-pins.json').write_text(json.dumps(pins,indent=2)+'\n');rows=[]
def run(command):
 command=list(map(str,command));start=time.monotonic();p=subprocess.run(command,capture_output=True,text=True,timeout=30);return dict(command=command,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr,seconds=time.monotonic()-start)
for case in controls:
 if not case['expected_accept'] or group and case['group']!=group:continue
 assert sha(root/case['source'])==case['sha256'];source=root/case['source'];c=out/(case['id']+'.c');exe=out/case['id'];wasm=out/(case['id']+'.wasm')
 steps=[run([compiler,source,'--stdlib',root/'stdlib','--target','native','--standalone',level,'-o',c])]
 if steps[-1]['exit_code']==0:steps.append(run(['/usr/bin/clang-23','-std=gnu11',level,c,'-lm','-ldl','-pthread','-o',exe]))
 if len(steps)==2 and steps[-1]['exit_code']==0:steps.append(run([exe]))
 rows.append(dict(id=case['id'],engine='native',expected_stdout=case['stdout'],steps=steps,match=len(steps)==3 and all(x['exit_code']==0 for x in steps) and steps[-1]['stdout']==case['stdout']))
 emission=run([compiler,source,'--stdlib',root/'stdlib','--target','wasm-direct',level,'-o',wasm])
 for engine,command in [('v8',['node',root/'scripts/run_wasm.mjs',wasm]),('wasmtime',['python',root/'scripts/run_wasmtime.py',wasm])]:
  steps=[emission]
  if emission['exit_code']==0:steps.append(run(command))
  rows.append(dict(id=case['id'],engine=engine,expected_stdout=case['stdout'],steps=steps,match=len(steps)==2 and all(x['exit_code']==0 for x in steps) and steps[-1]['stdout']==case['stdout']))
 (out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
assert pins=={str(p):sha(p) for p in paths};print(label,sum(x['match'] for x in rows),'/',len(rows));print([(x['id'],x['engine'],x['steps'][-1]['exit_code'],x['steps'][-1]['stdout'],x['steps'][-1]['stderr'][:160]) for x in rows if not x['match']])
