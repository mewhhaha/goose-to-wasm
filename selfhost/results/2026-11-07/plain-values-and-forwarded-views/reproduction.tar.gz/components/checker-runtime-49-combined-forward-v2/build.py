from pathlib import Path
import hashlib,json,re,shutil,subprocess,sys,time
root=Path('/home/jacobt/src/goose-to-wasm');work=root/'build/completion-runs';source=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();out.mkdir(exist_ok=False)
producer=work/'c-only-bootstrap-48/goose';library=root/'stdlib';cc=Path(shutil.which('clang')).resolve();level='-O2'
if len(sys.argv)>3:level=sys.argv[3]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
proof=json.loads((work/'c-only-bootstrap-48/report.json').read_text());assert sha(producer)==proof['executable_sha256']
paths=[Path(__file__),producer,cc,*source.glob('*.goose'),*library.rglob('*.goose')]
for p in source.glob('*.goose'):
 for match in re.finditer(r'\bembed_file\(\s*"(\.\./native/[^"\n]+)"\s*\)',p.read_text()):paths.append((p.parent/match.group(1)).resolve())
report={'status':'running','producer':'verified C-only Goose snapshot48','sources':str(source),'input_sha256':{str(p):sha(p) for p in paths},'commands':[]}
def save():(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
save();c=out/'compiler.c';exe=out/'goose'
try:
 for label,command in [('emit-c',[producer,source/'main.goose','--stdlib',library,'--target','native','--standalone','-O0','-o',c]),('cc',[cc,'-std=gnu11',level,c,'-lm','-ldl','-pthread','-o',exe])]:
  command=list(map(str,command));start=time.monotonic();result=subprocess.run(command,cwd=root,capture_output=True,timeout=180)
  (out/(label+'.stdout')).write_bytes(result.stdout);(out/(label+'.stderr')).write_bytes(result.stderr)
  report['commands'].append({'command':command,'exit_code':result.returncode,'seconds':time.monotonic()-start});save()
  if result.returncode:raise RuntimeError(label+': '+result.stderr.decode(errors='replace')[-5000:])
 report['input_sha256_after']={name:sha(name) for name in report['input_sha256']};assert report['input_sha256']==report['input_sha256_after']
 report.update(status='passed',executable=str(exe),executable_sha256=sha(exe),generated_c_sha256=sha(c));print(exe)
except BaseException as error:report.update(status='failed',error=repr(error));raise
finally:save()
