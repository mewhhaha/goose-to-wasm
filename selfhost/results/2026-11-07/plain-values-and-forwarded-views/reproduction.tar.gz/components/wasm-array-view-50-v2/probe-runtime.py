from pathlib import Path
import hashlib,json,subprocess,time
r=Path(__file__).resolve().parent;root=r.parents[2];exe=r/'probe/build/goose';controls=json.loads((r/'controls.json').read_text());out=r/'probe-runtime';out.mkdir();rows=[]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
paths=[exe,r/'controls.json',r/'expected-before-execution.json',Path(__file__),*[root/c['source'] for c in controls],root/'scripts/run_wasm.mjs',root/'scripts/run_wasmtime.py',*(root/'stdlib').rglob('*.goose')];pins={str(p):sha(p) for p in paths};(out/'input-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
def run(cmd):
 cmd=list(map(str,cmd));t=time.monotonic();p=subprocess.run(cmd,capture_output=True,text=True,timeout=30);return dict(command=cmd,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr,seconds=time.monotonic()-t)
for level in ['O0','O2']:
 for c in controls:
  assert sha(root/c['source'])==c['sha256'];module=out/(c['id']+'-'+level+'.wasm');cmd=[exe,root/c['source'],root/'stdlib',module]
  if level=='O2':cmd.append('O2')
  emission=run(cmd)
  for engine,cmd in [('v8',['node',root/'scripts/run_wasm.mjs',module]),('wasmtime',['python',root/'scripts/run_wasmtime.py',module])]:
   steps=[emission]
   if emission['exit_code']==0:steps.append(run(cmd))
   rows.append(dict(id=c['id'],level=level,engine=engine,expected_stdout=c['stdout'],steps=steps,match=len(steps)==2 and all(x['exit_code']==0 for x in steps) and steps[-1]['stdout']==c['stdout']))
  (out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
assert pins=={str(p):sha(p) for p in paths};print(sum(x['match'] for x in rows),'/',len(rows));print([(x['id'],x['level'],x['engine'],x['steps'][-1]) for x in rows if not x['match']]);assert all(x['match'] for x in rows)
