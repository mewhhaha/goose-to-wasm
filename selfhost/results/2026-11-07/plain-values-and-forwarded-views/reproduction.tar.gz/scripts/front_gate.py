from pathlib import Path
import concurrent.futures, json, subprocess, sys, time

compiler = Path(sys.argv[1]).resolve()
baseline = Path(sys.argv[2]).resolve()
out = Path(sys.argv[3]).resolve()
out.mkdir(parents=True, exist_ok=True)
library = Path('/home/jacobt/src/goose-to-wasm/stdlib')

def check(row):
    try:
        result = subprocess.run([compiler, row['source'], '--stdlib', library, '--check', '--target', 'wasm-direct'],
            capture_output=True, text=True, timeout=8)
        return dict(source=row['source'], exit_code=result.returncode, stdout=result.stdout, stderr=result.stderr)
    except subprocess.TimeoutExpired:
        return dict(source=row['source'], exit_code=124, stdout='', stderr='TIMEOUT')

summary = {}
for name in ('semantic-all-valid', 'typing', 'negative-type', 'upstream-positive'):
    old = json.loads((baseline / (name + '.json')).read_text())
    started = time.monotonic()
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        new = list(pool.map(check, old))
    (out / (name + '.json')).write_text(json.dumps(new, indent=2) + '\n')
    gains, losses = [], []
    for current, previous in zip(new, old):
        before = previous['exit_code'] == 0
        after = current['exit_code'] == 0
        if name == 'negative-type':
            before = not before
            after = current['exit_code'] == 1 and ': error:' in current['stderr']
        if after and not before: gains.append(current['source'])
        if before and not after: losses.append(current['source'])
    summary[name] = dict(total=len(new), accepted=sum(r['exit_code'] == 0 for r in new),
        gains=gains, regressions=losses, seconds=time.monotonic()-started)
    print(name, summary[name], flush=True)
(out / 'comparison.json').write_text(json.dumps(summary, indent=2) + '\n')
