from pathlib import Path
import argparse, collections, hashlib, json, os, subprocess, sys, time

root = Path('/home/jacobt/src/goose-to-wasm')

def sha(path):
    with Path(path).open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()

parser = argparse.ArgumentParser()
parser.add_argument('--compiler', type=Path, required=True)
parser.add_argument('--output-dir', type=Path, required=True)
parser.add_argument('--jobs', type=int, default=4)
args = parser.parse_args()
assert 1 <= args.jobs <= 8
out = args.output_dir.resolve()
out.mkdir(parents=True, exist_ok=False)
manifest_path = root / 'tests/conformance/cases.json'
initial_pins = {str(path): sha(path) for path in (manifest_path, Path(__file__).resolve(), args.compiler.resolve())}
manifest = json.loads(manifest_path.read_text())
started = time.monotonic()
processes, shard_files = [], []
for index in range(args.jobs):
    data = dict(manifest)
    data['cases'] = manifest['cases'][index::args.jobs]
    path = out / ('cases-' + str(index) + '.json')
    path.write_text(json.dumps(data, indent=2) + '\n')
    shard_files.append(path)
    log = (out / ('shard-' + str(index) + '.log')).open('w')
    command = [sys.executable, str(root / 'tests/conformance.py'), '--compiler', str(args.compiler.resolve()),
        '--manifest', str(path), '--output-dir', str(out / ('shard-' + str(index)))]
    process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, cwd=root)
    processes.append((process, log, command))
for process, log, command in processes:
    code = process.wait()
    log.close()
    assert code in (0, 1), (code, command)

# No case, level, expectation or source is allowed to change while partitioning.
partition = [case for path in shard_files for case in json.loads(path.read_text())['cases']]
assert collections.Counter(json.dumps(case, sort_keys=True) for case in partition) == collections.Counter(
    json.dumps(case, sort_keys=True) for case in manifest['cases'])
expected = collections.Counter((case['id'], level) for case in manifest['cases'] for level in (0, 2) if level in case['levels'])
report = dict(schema='goose-conformance-v1', status='failed',
    configuration=dict(compiler=str(args.compiler.resolve()), manifest=str(manifest_path), levels=[0, 2],
        filter='', engine='wasmtime', frontend_only=False, jobs=args.jobs),
    method='Every original case and selected level executes with the unchanged conformance runner. '
        'Only case lists are partitioned; expected data is verified byte-for-byte against the full manifest. '
        'Every runtime observation is a fresh process. This is correctness qualification, not timing evidence.',
    input_sha256={}, commands=[], results=[], shards=[])
command_keys = ('compile_command', 'native_command', 'run_command', 'parse_command')
for index in range(args.jobs):
    path = out / ('shard-' + str(index)) / 'report.json'
    shard = json.loads(path.read_text())
    assert shard['status'] in ('passed', 'failed') and 'summary' in shard and 'error' not in shard
    assert shard['input_sha256'] == shard['input_sha256_after']
    offset = len(report['commands'])
    report['commands'].extend(shard['commands'])
    for row in shard['results']:
        row = dict(row)
        for key in command_keys:
            if row.get(key) is not None: row[key] += offset
        report['results'].append(row)
    for name, identity in shard['input_sha256'].items():
        assert name not in report['input_sha256'] or report['input_sha256'][name] == identity
        report['input_sha256'][name] = identity
    report['shards'].append(dict(path=str(path), sha256=sha(path), summary=shard['summary']))
    report['input_sha256'][str(path)] = sha(path)
assert collections.Counter((row['case'], row['level']) for row in report['results']) == expected
for name, identity in initial_pins.items(): assert sha(name) == identity, name
report['input_sha256'].update(initial_pins)
for path in (Path(__file__).resolve(), manifest_path): report['input_sha256'][str(path)] = sha(path)
report['input_sha256_after'] = {name: sha(name) for name in report['input_sha256']}
assert report['input_sha256'] == report['input_sha256_after']
report['summary'] = dict(selected=len(report['results']),
    passed=sum(row['status'] == 'pass' for row in report['results']),
    failed=sum(row['status'] != 'pass' for row in report['results']))
if not report['summary']['failed']: report['status'] = 'passed'
report['qualification_seconds'] = time.monotonic() - started
(out / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
print(report['summary'], 'seconds', report['qualification_seconds'], flush=True)
raise SystemExit(int(report['status'] != 'passed'))
