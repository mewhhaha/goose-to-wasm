from pathlib import Path
import hashlib, json, shutil, subprocess, sys

root = Path('/home/jacobt/src/goose-to-wasm')
work = root / 'build/completion-runs'
version = int(sys.argv[1])
source = work / ('snapshot-' + str(version))
seed = work / ('verified-seed-' + str(version))
public = work / ('public-' + str(version))
public.mkdir(exist_ok=False)
selected = []
tracked = set(subprocess.check_output(['git', 'ls-files', '-z'], cwd=root).decode().split('\0'))
proof = json.loads((work / ('c-only-bootstrap-' + str(version)) / 'report.json').read_text())
tracked.update('selfhost/' + name for name in proof['source_sha256'])
tracked.update(proof['asset_sha256'])
config=json.loads((work / ('delivery-' + str(version) + '.json')).read_text())
tracked.update(row['path'] for row in config.get('documentation', []))
tracked.update(p.relative_to(source).as_posix() for p in (source / 'native').rglob('*') if p.is_file() and '__pycache__' not in p.parts)
manifest = json.loads((root / 'tests/conformance/cases.json').read_text())
tracked.update(case['source'] for case in manifest['cases'] if not case['source'].startswith('upstream:'))
controls = work / ('new-controls-' + str(version) + '.json')
if controls.exists(): tracked.update(json.loads(controls.read_text())['sources'])
for name in sorted(tracked):
    if not name: continue
    path = Path(name)
    top = path.parts[0]
    include = name in ('README.md', 'LICENSE', 'AGENTS.md') or top in ('scripts', 'stdlib', 'examples', 'bootstrap', 'native', 'tests', 'docs') or top == 'selfhost' and len(path.parts) == 2
    if not include: continue
    original = root / path
    if top in ('selfhost', 'native') and (source / path).is_file(): original = source / path
    if top == 'bootstrap' and path.name in ('proof.json', 'seed.c.gz', 'seed.json', 'sources.tar.gz'): original = seed / path.name
    if original.is_file():
        target = public / path
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(original, target)
        selected.append(name)
(public / 'export.json').write_text(json.dumps(dict(source_only=True, files=selected,
    source_sha256={str(p.relative_to(public)): hashlib.sha256(p.read_bytes()).hexdigest() for p in public.rglob('*') if p.is_file()}), indent=2) + '\n')

bench = work / ('bench-snapshot-' + str(version))
previous = work / ('bench-snapshot-' + str(version - 1))
bench.mkdir(exist_ok=False)
for top in ('bench', 'examples', 'host', 'scripts', 'stdlib'):
    shutil.copytree(previous / top, bench / top, symlinks=True, ignore=shutil.ignore_patterns('__pycache__'))
for top in ('selfhost', 'native'):
    shutil.copytree(source / top, bench / top, symlinks=True, ignore=shutil.ignore_patterns('__pycache__'))
shutil.copyfile(root / 'selfhost/bootstrap.py', bench / 'selfhost/bootstrap.py')
(bench / 'bootstrap').mkdir()
for name in ('seed.c.gz', 'seed.json', 'sources.tar.gz'): shutil.copyfile(seed / name, bench / 'bootstrap' / name)
for name in ('requirements.txt', 'toolchain.json'): shutil.copyfile(previous / name, bench / name)
(bench / 'build').symlink_to(root / 'build', target_is_directory=True)
print('Source-only public and benchmark snapshots ready:', version)
