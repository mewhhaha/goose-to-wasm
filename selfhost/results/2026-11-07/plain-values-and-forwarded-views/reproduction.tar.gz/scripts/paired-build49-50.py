from pathlib import Path
import datetime,hashlib,json,os,random,statistics,subprocess,time
root=Path('/home/jacobt/src/goose-to-wasm');w=root/'build/completion-runs';out=w/'paired-build49-50';out.mkdir(exist_ok=False);os.sched_setaffinity(0,{7})
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
ref=read(w/'goose-examples-50/report.json');commands={}
for r in ref['observations']:
 if r['kind']=='build' and r['backend']=='direct':commands[r['name']]=r['command']
pins=dict(ref['environment']['input_sha256'])
for v in [49,50]:pins[str(w/f'install-{v}/bin/goose')]=read(w/f'c-only-bootstrap-{v}/report.json')['executable_sha256']
for p,h in pins.items():assert sha(Path(p))==h,p
report=dict(status='running',started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Paired complete uncached direct-Wasm builds using the same frozen50 driver/source paths and byte-identical stdlib, qualified49/50 compiler executables. Five samples and one warmup per workload/compiler; CPU7; all coding owners explicitly quiet. Separate from full example/runtime cohorts.',input_sha256=pins,commands=[],compiler_sha256={str(v):pins[str(w/f'install-{v}/bin/goose')] for v in [49,50]})
randomizer=random.Random(4950)
for sample in range(-1,5):
 names=list(commands);randomizer.shuffle(names)
 for name in names:
  versions=[49,50];randomizer.shuffle(versions)
  for version in versions:
   cmd=list(commands[name]);cmd[cmd.index('--goose')+1]=str(w/f'install-{version}/bin/goose');stem=f'{name}-{sample}-{version}';target=out/(stem+'.wasm');stats=out/(stem+'.json');cmd[cmd.index('-o')+1]=str(target);cmd[cmd.index('--stats')+1]=str(stats)
   start=time.monotonic();r=subprocess.run(cmd,cwd=root,capture_output=True);elapsed=time.monotonic()-start;assert r.returncode==0,(cmd,r.stderr)
   (out/(stem+'.stdout')).write_bytes(r.stdout);(out/(stem+'.stderr')).write_bytes(r.stderr)
   report['commands'].append(dict(name=name,compiler=version,sample=sample,warmup=sample<0,command=cmd,exit_code=r.returncode,wall_seconds=elapsed,artifact_sha256=sha(target),driver_stats=read(stats)))
rows=[]
for name in commands:
 med={v:statistics.median(r['wall_seconds'] for r in report['commands'] if r['name']==name and r['compiler']==v and not r['warmup']) for v in [49,50]}
 for v in [49,50]:assert len({r['artifact_sha256'] for r in report['commands'] if r['name']==name and r['compiler']==v})==1,(name,v)
 rows.append(dict(name=name,compiler49_ms=med[49]*1000,compiler50_ms=med[50]*1000,ratio50_to49=med[50]/med[49]))
for p,h in pins.items():assert sha(Path(p))==h,p
report.update(status='passed',ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),summary=rows,median_workload_ratio=statistics.median(r['ratio50_to49'] for r in rows),input_sha256_after=pins)
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(status=report['status'],median_workload_ratio=report['median_workload_ratio'],rows=rows),indent=2),flush=True)
