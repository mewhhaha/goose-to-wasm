from pathlib import Path
import hashlib,json,subprocess,sys
work=Path('/home/jacobt/src/goose-to-wasm/build/completion-runs');root=work.parents[1];version=int(sys.argv[1]);parent=version-1;config=json.loads((work/f'delivery-{version}.json').read_text());out=work/f'snapshot-{version}-reproduced';out.mkdir(exist_ok=False)
old=json.loads((work/f'c-only-bootstrap-{parent}/report.json').read_text());names=['selfhost/'+name for name in old['source_sha256']]+list(old['asset_sha256'])+['native/tests/check.py','native/tests/var_relative.c','native/tests/bounded_cells.c','native/tests/runs.c']
for name in names:
 source=work/f'snapshot-{parent}'/name;target=out/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(source.read_bytes())
for item in config['patches']:
 path=work/item['path'];assert hashlib.sha256(path.read_bytes()).hexdigest()==item['sha256'];result=subprocess.run(['patch','--fuzz=0','-p1','-i',str(path)],cwd=out,text=True,capture_output=True);assert result.returncode==0,(result.stdout,result.stderr)
for item in config.get('documentation',[]):
 target=out/item['path'];target.parent.mkdir(parents=True,exist_ok=True);base_file=subprocess.run(['git','show',config['base_commit']+':'+item['path']],cwd=root,capture_output=True);
 if base_file.returncode==0:target.write_bytes(base_file.stdout)
 result=subprocess.run(['patch','--fuzz=0','-p1','-i',str(work/item['patch'])],cwd=out,text=True,capture_output=True);assert result.returncode==0,(result.stdout,result.stderr);assert hashlib.sha256(target.read_bytes()).hexdigest()==item['sha256']
proof=json.loads((work/f'c-only-bootstrap-{version}/report.json').read_text());pins={'selfhost/'+name:value for name,value in proof['source_sha256'].items()};pins.update(proof['asset_sha256'])
for name in ['native/tests/check.py','native/tests/var_relative.c','native/tests/bounded_cells.c','native/tests/runs.c']:pins[name]=hashlib.sha256((work/f'snapshot-{version}'/name).read_bytes()).hexdigest()
for name,value in pins.items():assert hashlib.sha256((out/name).read_bytes()).hexdigest()==value,name
(work/f'reproduction-{version}.json').write_text(json.dumps(dict(status='passed',method='Sealed patches independently reproduce all qualified compiler/runtime inputs and permanent C controls from verified parent.',parent=parent,verified_sha256=pins),indent=2)+'\n');print('Reproduced',len(pins),'inputs for',version)
