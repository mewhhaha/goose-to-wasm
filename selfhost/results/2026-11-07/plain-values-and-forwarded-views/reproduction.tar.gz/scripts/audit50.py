from pathlib import Path
import hashlib,json,subprocess
root=Path('/home/jacobt/src/goose-to-wasm');w=root/'build/completion-runs'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
config=read(w/'delivery-50.json');parent=read(w/'c-only-bootstrap-49/report.json');proof=read(w/'c-only-bootstrap-50/report.json');assembly=read(w/'snapshot-50-assembly.json');binding=read(w/'source50-parent-binding.json')
assert config['base_commit']==binding['parent_delivery_commit']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert binding['immutable_prequalification_assembly_sha256']==sha(w/'snapshot-50-assembly.json')
assert proof['status']=='passed' and proof['fixed_point']
changed=[k for k in parent['source_sha256'] if parent['source_sha256'][k]!=proof['source_sha256'][k]];assert sorted(changed)==['checker.goose','codegen.goose'],changed
assert proof['asset_sha256']==parent['asset_sha256']
for name,value in assembly['sha256'].items():assert sha(w/'snapshot-50'/name)==value,name
native=read(w/'native-runtime-49-final/report.json');assert len(native['runs'])==45 and all(x['returncode']==0 for x in native['runs'])
assert native['driver_sha256']==sha(w/'snapshot-50/native/tests/check.py')
for name in ['runs.c','bounded_cells.c','var_relative.c']:assert native['inputs_sha256'][name]==sha(w/'snapshot-50/native/tests'/name)
for name,value in read(w/'new-controls-50.json')['sources'].items():assert sha(root/name)==value,name
old=json.loads(subprocess.check_output(['git','show',config['base_commit']+':tests/conformance/cases.json'],cwd=root));new=read(root/'tests/conformance/cases.json');byid={x['id']:x for x in new['cases']};assert len(byid)==len(new['cases'])
for case in old['cases']:assert byid[case['id']]==case,case['id']
report=dict(status='passed',parent_commit=config['base_commit'],source_changes=changed,unchanged_native_assets=proof['asset_sha256'],prior_manifest_rows_preserved=sum(len(x['levels']) for x in old['cases']),native_header_reference='Exact unchanged49 source/driver/tests; all45qualifiedcommands reused.',parent_binding_sha256=sha(w/'source50-parent-binding.json'),reproduction_sha256=sha(w/'reproduction-50.json'),no_oracle_execution=True)
(w/'composition50-audit.json').write_text(json.dumps(report,indent=2)+'\n');print('Root50 source/manifest/headerreuse audit passed')
