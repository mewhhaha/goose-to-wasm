from pathlib import Path
import hashlib,json,subprocess
root=Path('/home/jacobt/src/goose-to-wasm');w=root/'build/completion-runs'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
proof=read(w/'c-only-bootstrap-49/report.json');parent=read(w/'c-only-bootstrap-48/report.json');config=read(w/'delivery-49.json');assembly=read(w/'snapshot-49-assembly.json')
assert proof['status']=='passed' and proof['fixed_point']
expected=read(w/'composition49-resolved/combined-production-tests-pins.json')['source_sha256']
for name,value in expected.items():assert sha(w/'snapshot-49'/name)==value==assembly['sha256'][name],name
changed_assets={k for k in parent['asset_sha256'].keys()|proof['asset_sha256'].keys() if parent['asset_sha256'].get(k)!=proof['asset_sha256'].get(k)}
assert changed_assets=={'native/runs.h'},changed_assets
native=read(w/'native-runtime-49-final/report.json');assert len(native['runs'])==45 and all(x['returncode']==0 for x in native['runs'])
assert native['driver_sha256']==sha(w/'snapshot-49/native/tests/check.py')
for name in ['runs.c','bounded_cells.c','var_relative.c']:assert native['inputs_sha256'][name]==sha(w/'snapshot-49/native/tests'/name)
manifest=read(root/'tests/conformance/cases.json');before=json.loads(subprocess.check_output(['git','show',config['base_commit']+':tests/conformance/cases.json'],cwd=root))
byid={x['id']:x for x in manifest['cases']}
assert len(byid)==len(manifest['cases'])
for x in before['cases']:assert byid[x['id']]==x,x['id']
for name,value in read(w/'new-controls-49.json')['sources'].items():assert sha(root/name)==value
out=w/'composition49-root-interaction';out.mkdir(exist_ok=False)
cmd=['python',str(root/'tests/conformance.py'),'--compiler',str(w/'c-only-bootstrap-49/goose'),'--manifest',str(w/'composition49-resolved/interaction2-runner-manifest.json'),'--output-dir',str(out/'run')]
r=subprocess.run(cmd,cwd=root,capture_output=True,text=True);(out/'runner.stdout').write_text(r.stdout);(out/'runner.stderr').write_text(r.stderr);assert r.returncode==0,(r.stdout,r.stderr)
rows=[]
for c in read(w/'composition49-resolved/interaction2-expected-before-execution.json'):
 if c['phase']!='refusal':continue
 source=root/c['source'];assert sha(source)==c['source_sha256']
 for level in c['levels']:
  cmd=[str(w/'c-only-bootstrap-49/goose'),str(source),'--target','native','-O'+str(level),'-o',str(out/('refused'+str(level)+'.c'))]
  r=subprocess.run(cmd,cwd=root,capture_output=True,text=True);assert r.returncode==1 and 'error:' in r.stderr and 'Parse' not in r.stderr,(cmd,r.returncode,r.stderr)
  rows.append(dict(command=cmd,exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr))
report=dict(status='passed',source_base=config['base_commit'],source_sha256=expected,only_changed_native_asset=sorted(changed_assets),native_header_commands=45,prior_manifest_rows_unchanged=sum(len(c['levels']) for c in before['cases']),composed_interaction_report_sha256=sha(out/'run/report.json'),root_tuple_refusals=rows,no_oracle_execution=True)
(w/'composition49-audit.json').write_text(json.dumps(report,indent=2)+'\n');print('Root49 audit passed',flush=True)
