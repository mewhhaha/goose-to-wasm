from pathlib import Path
import json,subprocess,time
root=Path('/home/jacobt/src/goose-to-wasm');w=root/'build/completion-runs'
for attempt in range(240):
 p=w/'c-only-bootstrap-49/report.json'
 if p.exists():
  r=json.loads(p.read_text())
  if r['status']=='passed':break
  assert r['status']!='failed',r
 time.sleep(2)
else:raise RuntimeError('canonical bootstrap did not finish')
for script in ['audit49.py','qualify_49.py','public-smoke-49.py','public-cross49.py']:
 print('Starting',script,flush=True)
 r=subprocess.run(['python',str(w/script)],cwd=root);assert r.returncode==0,(script,r.returncode)
print('All49 qualification stages passed',flush=True)
