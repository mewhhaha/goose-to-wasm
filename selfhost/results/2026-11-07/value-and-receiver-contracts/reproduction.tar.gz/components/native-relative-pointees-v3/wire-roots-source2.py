from pathlib import Path
b=Path(__file__).resolve().parent/'source2/selfhost';p=b/'codegen_c_storage.goose';s=p.read_text()
s=s.replace('publication: i64 = -1, construction: i64 = -1,','publication: i64 = -1, construction: i64 = -1, run_capability: i64 = -1,')
s=s.replace('if cc_image_type(p, type_id) { return 24; }','if cc_image_type(p, type_id) { return 24; }\n    if cc_self_run(p, type_id) { return 32; }')
s=s.replace('if cc_image_type(p, type_id) { return true; }\n    let kind = cc_kind(p, type_id);','if cc_image_type(p, type_id) || cc_self_run(p, type_id) { return true; }\n    let kind = cc_kind(p, type_id);',1)
s=s.replace('if cc_image_type(p, type_id) { return false; }\n    let kind = cc_kind(p, type_id);','if cc_image_type(p, type_id) || cc_self_run(p, type_id) { return false; }\n    let kind = cc_kind(p, type_id);')
p.write_text(s)
p=b/'codegen_c.goose';s=p.read_text();start=s.index('fn cc_run_bind(');end=s.index('fn cc_channels_address(',start)
s=s[:start]+'''fn cc_run_bind(f: CcBody&, value: i64, address: i64, root: const u8[:], id: i64 = -1) -> i64 {
    let capability = f.serial; f.serial++;
    cc_id(f.out, "GRunRoot *g_run_cap", capability); cc_text(f.out, "="); cc_text(f.out, root);
    if id >= 0 { cc_number(f.out, id); } cc_text(f.out, ";\\n");
    f.channels.push(CcChannels { value: value, address: address, run_capability: capability }); return capability;
}
fn cc_run_require(p: Program&, f: CcBody&, address: i64, node: i64) -> i64 {
    let capability = cc_run_capability(f, address);
    if capability < 0 { cc_fail(p, node, "c: variable-relative run has no proved root capability"); }
    return capability;
}
fn cc_run_skip(p: Program&, f: CcBody&, array: i64) {
    cc_id(f.out, "g_self_skip_", p.types[array].element);
}
''' +s[end:]
# Associate aliases with exactly the actual root capability already proved for target.
needle='    cc_text(f.out, "*)g_address("); cc_id(f.out, "g_v", target); cc_text(f.out, "))\\n"); f.indirect.push(id); return id;'
s=s.replace(needle,'''    cc_text(f.out, "*)g_address("); cc_id(f.out, "g_v", target); cc_text(f.out, "))\\n"); f.indirect.push(id);
    if cc_self_run(p, type_id) {
        let capability = cc_run_require(p, f, target, f.function);
        f.channels.push(CcChannels { value: id, address: target, run_capability: capability });
    }
    return id;''')
# Staged construction uses a distinct temporary region, never publication to old root.
needle='    let previous = f.receiver; let active = f.active_node; let destination = f.destinations.len;\n    f.destinations.push(CcDestination { type_id: type_id, header: target, stack: -1, lifetime: 2, form: form });'
s=s.replace(needle,'''    let previous = f.receiver; let active = f.active_node; let destination = f.destinations.len;
    let keep = f.region_live; var actual = target; var actual_capability = -1;
    if cc_self_run(p, type_id) {
        actual_capability = cc_run_require(p, f, target, node); if actual_capability < 0 { return -1; }
        let staged = cc_temp(p, f, type_id); actual = cc_temporary_ref(f, staged);
    }
    f.destinations.push(CcDestination { type_id: type_id, header: actual, stack: -1, lifetime: 2, form: form, run_capability: cc_run_capability(f, actual) });''')
needle='    if value >= 0 { cc_write(p, f, CcPlace { type_id: type_id, address: target, form: form }, value, node); }'
s=s.replace(needle,'''    if value >= 0 { cc_write(p, f, CcPlace { type_id: type_id, address: target, form: form }, value, node); }
    if cc_self_run(p, type_id) { cc_restore(f, keep); f.region_live = keep; }''')
# Root temporaries bind typed actual storage after ordinary seeding.
needle='    cc_text(f.out, ";\\n"); if seed { cc_seed(p, f, type_id, "g_v", id); } return id;'
s=s.replace(needle,'''    cc_text(f.out, ";\\n"); if seed { cc_seed(p, f, type_id, "g_v", id); }
    if cc_self_run(p, type_id) {
        let address = cc_ref_temp(f); cc_set(f, address); cc_text(f.out, "g_ref(&"); cc_id(f.out, "g_v", id); cc_text(f.out, ");\\n");
        cc_run_bind(f, id, address, "&g_v", id);
    }
    return id;''')
needle='fn cc_load(p: Program&, f: CcBody&, ref: i64, type_id: i64) -> i64 {'
s=s.replace(needle,needle+'\n    if cc_self_run(p, type_id) { return cc_alias_temp(p, f, type_id, ref); }')
needle='    if cc_kind(p, type_id) == TY_TUPLE { cc_copy_tuple(p, f, ref, value, type_id); return; }'
s=s.replace(needle,'''    if cc_self_run(p, type_id) {
        let receiving = cc_run_require(p, f, ref, node); let source = cc_run_require(p, f, cc_temporary_ref(f, value), node);
        if receiving < 0 || source < 0 { return; }
        cc_text(f.out, "g_run_land("); cc_id(f.out, "g_run_cap", receiving); cc_text(f.out, ","); cc_id(f.out, "g_run_cap", source); cc_text(f.out, ","); cc_run_skip(p, f, type_id); cc_text(f.out, ");\\n"); return;
    }
'''+needle)
needle='        cc_text(f.out, "g_ref(&"); cc_id(f.out, "g_s", symbol); cc_text(f.out, ");\\n"); return ref;'
s=s.replace(needle,'''        cc_text(f.out, "g_ref(&"); cc_id(f.out, "g_s", symbol); cc_text(f.out, ");\\n");
        if cc_self_run(p, s.type_id) { cc_run_bind(f, -1, ref, "&g_s", symbol); }
        return ref;''')
needle='    var capture = p.nodes[f.function].captures; var index = 0;'
s=s.replace(needle,'''    if cc_self_run(p, s.type_id) { cc_text(f.out, "0;\\n"); cc_fail(p, node, "c: captured variable-relative run requires root capability forwarding"); return -1; }
'''+needle,1)
# New root frame is separate from ordinary GArray and packed row bytes.
s=s.replace('        if cc_image_type(p, id) { cc_text(out, "GImage"); }','        if cc_self_run(p, id) { cc_text(out, "GRunRoot"); }\n        else if cc_image_type(p, id) { cc_text(out, "GImage"); }')
needle='    if cc_image_type(p, id) { cc_text(out, "GImage value=g_image(slot);memcpy(g_address(p),&value,sizeof value);\\n"); }'
s=s.replace(needle,'''    if cc_self_run(p, id) { cc_text(out, "GRunRoot value=g_run_root(slot);memcpy(g_address(p),&value,sizeof value);\\n"); }
    else if cc_image_type(p, id) { cc_text(out, "GImage value=g_image(slot);memcpy(g_address(p),&value,sizeof value);\\n"); }''')
# No generic24byte publication is permitted for new roots.
needle='fn cc_emit_map(p: Program&, out: u8[>..]&, id: i64) {'
# actual signature includes helper? handled after inspection if absent.
if needle in s:
 s=s.replace(needle,needle+'''\n    if cc_self_run(p, id) { out.format("static void g_map_", id, "(GRef source,GRef target,GPublication *links){(void)links;if(source!=target)g_panic(\\"run publication requires typed receiving capability\\");}\\n"); return; }''')
# Existing same-object result mapping is harmless, and no newroot map publishes early.
needle='        cc_bind_named_results(p, f, function, result_type, result_ref);'
s=s.replace(needle,'''        if cc_self_run(p, result_type) { cc_run_bind(f, -1, result_ref, "g_into"); }
'''+needle)
p.write_text(s)
