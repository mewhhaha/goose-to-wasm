from pathlib import Path
b=Path(__file__).resolve().parent/'source4/selfhost';p=b/'codegen_c_storage.goose';s=p.read_text().replace('struct CcCursor { symbol: i64, index: i64, address: i64, type_id: i64 }','struct CcCursor { symbol: i64, index: i64, address: i64, type_id: i64, node: i64 = -1, owner_header: i64 = -1 }');p.write_text(s)
p=b/'codegen_c.goose';s=p.read_text()
# A self-cell read records its already-evaluated bounded owner. Owner lookup must not reevaluate its base/index.
needle='        return cc_convert(p, f, value, place.type_id, wanted, node);\n    }\n    if place.form == CC_IMAGE && place.image_end >= 0 {'
s=s.replace(needle,'''        f.cursors.push(CcCursor { symbol: -1, index: -1, address: place.image_base, type_id: p.types[place.type_id].element, node: node, owner_header: place.owner_header });
'''+needle,1)
needle='    let n = p.nodes[node];\n    if cc_bounded_relative_image(p, n.type_id) && n.kind == N_NAME {'
s=s.replace(needle,'''    let n = p.nodes[node];
    var view = f.cursors.len;
    while view > 0 {
        view--; let known = f.cursors[view];
        if known.owner_header >= 0 && (known.node == node || n.kind == N_NAME && known.symbol == n.symbol) { return known.owner_header; }
    }
    if cc_bounded_relative_image(p, n.type_id) && n.kind == N_NAME {''')
needle='        let place = cc_base_place(p, f, n.left); return place.owner_header;'
s=s.replace(needle,'        return -1;',1)
# Exact per-index view; count/end comes only from the registered root capability.
needle='        if cc_size_class(p, type_id) == 1 {\n            for cursor in f.cursors {'
s=s.replace(needle,'''        if cc_self_run(p, array) {
            let capability = cc_run_require(p, f, base, node); if capability < 0 { return CcPlace { type_id: -1, address: -1 }; }
            let image = cc_temp(p, f, type_id, true, false); cc_set(f, image); cc_text(f.out, "g_run_view("); cc_id(f.out, "g_run_cap", capability); cc_text(f.out, ","); cc_id(f.out, "g_v", index); cc_text(f.out, ","); cc_run_skip(p, f, array); cc_text(f.out, ");\\n");
            let header = cc_temporary_ref(f, image); let start = cc_ref_temp(f); let end = cc_ref_temp(f);
            cc_set(f, start); cc_text(f.out, "g_ref("); cc_id(f.out, "g_v", image); cc_text(f.out, ".base);\\n");
            cc_set(f, end); cc_text(f.out, "g_ref("); cc_id(f.out, "g_v", image); cc_text(f.out, ".end);\\n");
            f.cursors.push(CcCursor { symbol: -1, index: -1, address: start, type_id: type_id, node: node, owner_header: header });
            return CcPlace { type_id: type_id, address: start, form: CC_IMAGE, owner_header: header, image_base: start, image_end: end };
        }
        if cc_size_class(p, type_id) == 1 {
            for cursor in f.cursors {''')
# Legacy integer-loop prewalk must not create an unbounded cursor for these roots.
s=s.replace('&& cc_size_class(p, p.types[type_id].element) == 1 {\n                var exists', '&& cc_size_class(p, p.types[type_id].element) == 1 && !cc_self_run(p, type_id) {\n                var exists')
pos=s.index('recursive fn cc_loop(p:')
s=s[:pos]+'''recursive fn cc_committed_run_loop(p: Program&, f: CcBody&, node: i64, array: i64) -> i64 {
    let n = p.nodes[node];
    if n.type_id != TYPE_VOID { cc_fail(p, node, "c: run iteration result requires bounded result adaptation"); return -1; }
    let base = cc_base(p, f, n.left); let capability = cc_run_require(p, f, base, node); if capability < 0 { return -1; }
    let binding = n.first; let index_binding = p.nodes[binding].next; let element = p.types[array].element;
    let counter = cc_temp(p, f, TYPE_I64); let done = f.serial; f.serial++; let again = f.serial; f.serial++;
    let regions = f.region_live; let cursors = f.cursors.len; let publications = f.serial; f.serial++;
    cc_id(f.out, "GPublication *g_scope_publications", publications); cc_text(f.out, "=g_publication_top;\\n");
    f.exits.push(CcExit { node: node, done: done, again: again, result: -1, type_id: TYPE_VOID, regions: regions, again_regions: regions, publications: publications });
    cc_text(f.out, "for(;;){g_run_check("); cc_id(f.out, "g_run_cap", capability); cc_text(f.out, ","); cc_run_skip(p, f, array); cc_text(f.out, ");\\nif("); cc_id(f.out, "g_v", counter); cc_text(f.out, ">="); cc_id(f.out, "g_run_cap", capability); cc_text(f.out, "->header.len)break;\\n");
    let view = cc_temp(p, f, element, true, false); cc_set(f, view); cc_text(f.out, "g_run_view("); cc_id(f.out, "g_run_cap", capability); cc_text(f.out, ","); cc_id(f.out, "g_v", counter); cc_text(f.out, ","); cc_run_skip(p, f, array); cc_text(f.out, ");\\n");
    if (p.nodes[binding].flags & F_REFERENCE) != 0 {
        let header = cc_temporary_ref(f, view);
        cc_id(f.out, "g_s", p.nodes[binding].symbol); cc_text(f.out, "=g_ref("); cc_id(f.out, "g_v", view); cc_text(f.out, ".base);\\n");
        f.cursors.push(CcCursor { symbol: p.nodes[binding].symbol, index: -1, address: -1, type_id: element, owner_header: header });
    } else {
        let copied = cc_temp(p, f, element); let target = cc_temporary_ref(f, copied); cc_store(p, f, target, view, element, node);
        cc_id(f.out, "g_s", p.nodes[binding].symbol); cc_text(f.out, "="); cc_id(f.out, "g_v", copied); cc_text(f.out, ";\\n");
    }
    if index_binding >= 0 { cc_id(f.out, "g_s", p.nodes[index_binding].symbol); cc_text(f.out, "="); cc_id(f.out, "g_v", counter); cc_text(f.out, ";\\n"); }
    f.exits[f.exits.len - 1].again_regions = f.region_live;
    cc_expr(p, f, n.right); cc_id(f.out, "g_label", again); cc_text(f.out, ":;\\n");
    cc_restore(f, regions); f.region_live = regions; cc_id(f.out, "g_v", counter); cc_text(f.out, "++;}\\n");
    cc_id(f.out, "g_label", done); cc_text(f.out, ":;\\ng_publication_top="); cc_id(f.out, "g_scope_publications", publications); cc_text(f.out, ";\\n");
    f.cursors.resize(cursors); f.exits.pop(); return -1;
}
''' +s[pos:]
needle='recursive fn cc_loop(p: Program&, f: CcBody&, node: i64) -> i64 {\n    let n = p.nodes[node];'
s=s.replace(needle,'''recursive fn cc_loop(p: Program&, f: CcBody&, node: i64) -> i64 {
    let current = p.nodes[node];
    if current.kind == N_FOR {
        var array = p.nodes[current.left].type_id; while cc_kind(p, array) == TY_REF { array = p.types[array].element; }
        if cc_self_run(p, array) { return cc_committed_run_loop(p, f, node, array); }
    }
    let n = p.nodes[node];''')
# Refuse generic root operations until their typed protocol exists.
needle='    if builtin == 21 || builtin == 22 {'
s=s.replace(needle,'''    if cc_self_run(p, type_id) && builtin != 21 && builtin != 24 { cc_fail(p, node, "c: run builtin requires explicit committed-root adaptation"); return -1; }
'''+needle)
needle='    let result = cc_temp(p, f, result_type); if result < 0 { return -1; }\n    let t = p.types[operand];'
s=s.replace(needle,'''    if cc_self_run(p, operand) { cc_fail(p, node, "c: whole run comparison requires bounded adaptation"); return -1; }
'''+needle)
needle='    if cc_variable_prefix_frame(p, type_id) {'
s=s.replace(needle,'''    if cc_self_run(p, type_id) && cc_threads_used(p) { cc_fail(p, f.function, "c: variable-relative runs require explicit thread authority"); }
'''+needle,1)
p.write_text(s)
