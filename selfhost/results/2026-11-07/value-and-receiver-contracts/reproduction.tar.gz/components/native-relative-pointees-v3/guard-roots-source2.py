from pathlib import Path
b=Path(__file__).resolve().parent/'source2/selfhost';p=b/'codegen_c_storage.goose';s=p.read_text();pos=s.index('fn cc_bounded_relative_image(')
s=s[:pos]+'''fn cc_self_run_inside(p: Program&, id: i64) -> bool {
    var work: i64[>..] = [id]; var seen: bool[>..] = []; seen.resize(p.types.len, false);
    while work.len > 0 {
        let current = work.pop(); if current < 0 || seen[current] { continue; } seen[current] = true;
        if cc_self_run(p, current) { return true; } let t = p.types[current];
        if t.kind == TY_REF || t.kind == TY_ARRAY || t.kind == TY_SLICE { work.push(t.element); }
        else {
            var field = -1;
            if (t.kind == TY_STRUCT || t.kind == TY_ENUM) && t.declaration >= 0 { field = p.nodes[t.declaration].first; }
            if t.kind == TY_TUPLE { field = t.first; }
            while field >= 0 { let n = p.nodes[field]; if (n.flags & F_PAD) == 0 { work.push(n.type_id); } field = n.next; }
        }
    }
    return false;
}
''' +s[pos:];p.write_text(s)
p=b/'codegen_c.goose';s=p.read_text()
needle='    if cc_variable_prefix_frame(p, type_id) {'
s=s.replace(needle,'''    if cc_aggregate(p, type_id) && !cc_self_run(p, type_id) && cc_relative_fields(p, type_id) && cc_self_run_inside(p, type_id) { cc_fail(p, f.function, "c: nested variable-relative run roots require explicit receiving capabilities"); }
'''+needle,1)
# Keep old array guard in place until every new run operation has been qualified.
# Source2 infrastructure must not admit arrays on its own.
needle='        if cc_relative_cell(p, type_id) && cc_bounded_relative_image(p, p.types[type_id].element) {'
s=s.replace(needle,'''        if cc_self_run(p, type_id) || cc_kind(p, type_id) == TY_REF && cc_self_run(p, p.types[type_id].element) { cc_fail(p, checked, "c: variable-relative run parameters require root capability forwarding"); }
'''+needle)
needle='    cc_emit_signature(p, out, function); cc_text(out, " {\\n"); cc_parameter_aliases(p, out, function);'
s=s.replace(needle,'''    if cc_self_run(p, cc_function_result(p, function)) && (n.flags & F_NONLOCAL_TARGET) != 0 { cc_fail(p, function, "c: nonlocal run results require root capability recovery"); }
'''+needle)
s=s.replace('if cc_flat_image_abi_pending(p, p.nodes[parameter].type_id) {','if cc_flat_image_abi_pending(p, p.nodes[parameter].type_id) || cc_self_run_inside(p, p.nodes[parameter].type_id) {')
s=s.replace('if cc_flat_image_abi_pending(p, cc_function_result(p, function)) {','if cc_flat_image_abi_pending(p, cc_function_result(p, function)) || cc_self_run_inside(p, cc_function_result(p, function)) {')
# Stores and publish adapters carry completed32-byte descriptors, never24-byte maps.
needle='fn cc_emit_store(p: Program&, out: u8[>..]&, id: i64) {'
s=s.replace(needle,needle+'''
    if cc_self_run(p, id) { out.format("static void g_store_", id, "(GRef p,g_t", id, " v){g_run_land((GRunRoot*)g_address(p),&v,g_self_skip_", p.types[id].element, ");}\\n"); return; }
''')
needle='        if cc_image_type(p, id) { cc_text(out, "GImage value;memcpy(&value,source,sizeof value);g_image_copy_into(g_ref(p),value); }\\n"); }'
s=s.replace(needle,'''        if cc_self_run(p, id) { out.format("g_run_land((GRunRoot*)p,(const GRunRoot*)source,g_self_skip_", t.element, ");}\\n"); }
        else if cc_image_type(p, id) { cc_text(out, "GImage value;memcpy(&value,source,sizeof value);g_image_copy_into(g_ref(p),value); }\\n"); }''')
# Helpers reference a bounded skip declaration regardless of helper emission order.
needle='        cc_id(out, "static const uint8_t *g_image_skip_", id);'
s=s.replace(needle,'''        if cc_self_relative_image(p, id) { out.format("static const uint8_t *g_self_skip_", id, "(const uint8_t*,const uint8_t*);\\n"); }
'''+needle)
# Separate bounded next-row walking from exact local-view validation.
s=s.replace('out.format("static const uint8_t *g_self_end_", id, "(const uint8_t *start,const uint8_t *end){const uint8_t *cell=start;\\n");','out.format("static const uint8_t *g_self_skip_", id, "(const uint8_t *start,const uint8_t *end){const uint8_t *cell=start;\\n");')
s=s.replace('out.append("if(cell!=end)g_panic(\\"pure-self image trailing bytes\\");return cell;}\\n");','out.format("return cell;}\\nstatic const uint8_t *g_self_end_", id, "(const uint8_t *start,const uint8_t *end){const uint8_t *next=g_self_skip_", id, "(start,end);if(next!=end)g_panic(\\"pure-self image trailing bytes\\");return next;}\\n");')
# Local early returns reuse their registered receiving capability. Escaping recovery stays refused.
needle='    let type_id = cc_function_result(p, target); var receiver = -1;'
s=s.replace(needle,needle+'''
    if cc_self_run(p, type_id) && target != f.function { cc_fail(p, node, "c: escaping run results require root capability recovery"); return; }
''')
s=s.replace('    if cc_tuple_channels(p, type_id) && target == f.function { receiver = f.result_ref; }','    if (cc_tuple_channels(p, type_id) || cc_self_run(p, type_id)) && target == f.function { receiver = f.result_ref; }')
p.write_text(s)
