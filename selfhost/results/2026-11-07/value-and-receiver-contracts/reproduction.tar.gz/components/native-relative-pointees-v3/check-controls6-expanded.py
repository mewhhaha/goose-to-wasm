from pathlib import Path
import sys,subprocess,json,time,hashlib,shutil
b=Path(__file__).resolve().parent;r=b.parents[2];version=sys.argv[1];out=b/('controls6-build'+version);out.mkdir(exist_ok=False);compiler=b/('build'+version)/'goose';expected={'run-parameter-replace':'2 two\n','run-staged-cancel':'1 one\n4 four\n2 two\n','run-index-once':None,'run-param-alias-call':'3 x\n9 x\n','run-borrow-mutate':'11 one\n12 two\n','reject-run-format':None,'reject-run-clear':None,'reject-run-capacity':None,'reject-run-slice':None,'run-varint-padding':'1 0\n2 128\n','run-optional-null':'true\n','reject-param-rebind':None,'reject-returned-root-ref':None}
(out/'expected-before-execution.json').write_text(json.dumps(expected,indent=2)+'\n');results=[]
for source in sorted((b/'controls6').glob('*.goose')):
 for level in (0,2):
  label=source.stem+'-O'+str(level);c=out/(label+'.c');exe=out/label;row=dict(case=source.stem,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),level=level,expected=expected[source.stem],commands=[])
  for phase,cmd in [('emit',[str(compiler),str(source),'--stdlib',str(r/'build/completion-runs/c-only-bootstrap-47/stdlib'),'--target','native','--standalone','-O'+str(level),'-o',str(c)]),('cc',[shutil.which('clang'),'-std=gnu11','-O'+str(level),str(c),'-lm','-ldl','-pthread','-o',str(exe)]),('run',[str(exe)])]:
   start=time.monotonic();p=subprocess.run(cmd,capture_output=True,timeout=60);(out/(label+'-'+phase+'.stdout')).write_bytes(p.stdout);(out/(label+'-'+phase+'.stderr')).write_bytes(p.stderr);ok=p.returncode==0
   if phase=='run':ok=ok and p.stdout.decode()==expected[source.stem]
   row['commands'].append(dict(phase=phase,command=cmd,exit_code=p.returncode,seconds=time.monotonic()-start,ok=ok))
   if not ok:break
  results.append(row);print(label,phase,p.returncode,ok,flush=True);(out/'report.json').write_text(json.dumps(dict(status='measured',results=results),indent=2)+'\n')
