from pathlib import Path
p=Path(__file__).resolve().parent/'source2/selfhost/codegen_c.goose';s=p.read_text();pos=s.index('recursive fn cc_image_reference_owner(')
s=s[:pos]+'''recursive fn cc_run_reference_owner(p: Program&, f: CcBody&, node: i64, depth: i64 = 0) -> i64 {
    if node < 0 || depth > 32 { return -1; } let n = p.nodes[node];
    if n.kind == N_NAME && cc_self_run(p, cc_place_type(p, node)) { return cc_run_capability(f, cc_symbol_ref(p, f, n.symbol, node)); }
    if n.kind == N_UNARY && n.integer == T_BITAND || n.kind == N_CAST && (n.flags & F_SYNTHETIC) != 0 { return cc_run_reference_owner(p, f, n.left, depth + 1); }
    if n.kind != N_NAME || n.symbol < 0 { return -1; }
    let symbol = p.symbols[n.symbol]; if symbol.node < 0 { return -1; } let declaration = p.nodes[symbol.node];
    if declaration.kind == N_VARIABLE && (declaration.flags & F_VAR) == 0 && declaration.right >= 0 { return cc_run_reference_owner(p, f, declaration.right, depth + 1); }
    return -1;
}
''' +s[pos:]
needle='        let type_id = p.types[p.nodes[node].type_id].element; let address = cc_expr(p, f, node);'
s=s.replace(needle,needle+'''
        if cc_self_run(p, type_id) {
            let capability = cc_run_reference_owner(p, f, node);
            if capability < 0 { cc_fail(p, node, "c: run reference has no proved receiving capability"); return CcPlace { type_id: -1, address: -1 }; }
            cc_text(f.out, "if(g_ref("); cc_id(f.out, "g_run_cap", capability); cc_text(f.out, ")!="); cc_id(f.out, "g_v", address); cc_text(f.out, ")g_panic(\\"run reference owner mismatch\\");\\n");
            f.channels.push(CcChannels { value: -1, address: address, run_capability: capability });
            return CcPlace { type_id: type_id, address: address };
        }
''')
pos=s.index('recursive fn cc_image_run_array(')
s=s[:pos]+'''recursive fn cc_committed_run_array(p: Program&, f: CcBody&, node: i64) -> i64 {
    let n = p.nodes[node]; let element = p.types[n.type_id].element;
    if n.right >= 0 || n.third >= 0 { cc_fail(p, node, "c: run fill/capacity construction requires bounded receiving adaptation"); return -1; }
    let result = cc_result_temp(p, f, node, n.type_id); let address = cc_temporary_ref(f, result); let capability = cc_run_require(p, f, address, node);
    if capability < 0 { return -1; }
    cc_text(f.out, "g_run_reset("); cc_id(f.out, "g_run_cap", capability); cc_text(f.out, ");\\n");
    var child = n.first;
    while child >= 0 {
        let mark = f.region_live; let value = cc_to(p, f, child, element);
        if value >= 0 { cc_text(f.out, "(void)g_run_append("); cc_id(f.out, "g_run_cap", capability); cc_text(f.out, ","); cc_id(f.out, "g_v", value); cc_text(f.out, ","); cc_run_skip(p, f, n.type_id); cc_text(f.out, ");\\n"); }
        cc_restore(f, mark); f.region_live = mark; child = p.nodes[child].next;
    }
    return result;
}
''' +s[pos:]
s=s.replace('recursive fn cc_image_run_array(p: Program&, f: CcBody&, node: i64) -> i64 {','recursive fn cc_image_run_array(p: Program&, f: CcBody&, node: i64) -> i64 {\n    if cc_self_run(p, p.nodes[node].type_id) { return cc_committed_run_array(p, f, node); }')
needle='recursive fn cc_image_extend(p: Program&, f: CcBody&, node: i64, builtin: i64, base: i64, array: i64, argument: i64) -> i64 {'
s=s.replace(needle,needle+'''
    if cc_self_run(p, array) {
        if builtin != 24 { cc_fail(p, node, "c: variable-relative run extension requires complete bounded element adaptation"); return -1; }
        let capability = cc_run_require(p, f, base, node); if capability < 0 { return -1; }
        let mark = f.region_live; let value = cc_to(p, f, argument, p.types[array].element); if value < 0 { return -1; }
        let result = cc_ref_temp(f); cc_set(f, result); cc_text(f.out, "g_ref(g_run_append("); cc_id(f.out, "g_run_cap", capability); cc_text(f.out, ","); cc_id(f.out, "g_v", value); cc_text(f.out, ","); cc_run_skip(p, f, array); cc_text(f.out, "));\\n");
        cc_restore(f, mark); f.region_live = mark; return result;
    }
''')
# No generic run mutation may bypass paired header/end publication.
needle='    if builtin >= 26 && builtin <= 29 {'
s=s.replace(needle,'''    if cc_self_run(p, type_id) && builtin >= 26 && builtin <= 29 { cc_fail(p, node, "c: run shrink/resize/clear needs committed-root adaptation"); return -1; }
'''+needle)
p.write_text(s)
p=Path(__file__).resolve().parent/'source2/native/images.h';s=p.read_text();pos=s.index('static void g_run_check(');s=s[:pos]+'''static void g_run_reset(GRunRoot *receiving) {
    if(!receiving || !receiving->header.region)g_panic("run has no receiving region");
    receiving->header.len=0;receiving->end=receiving->header.data;
    receiving->header.region->stack.top=receiving->end;
}
''' +s[pos:];p.write_text(s)
