/* Auxiliary typed root for newly bounded variable-relative runs. GArray stays24. */
typedef struct { GArray header; uint8_t *end; } GRunRoot;
typedef const uint8_t *(*GRunSkip)(const uint8_t *,const uint8_t *);
_Static_assert(sizeof(GRunRoot)==32,"bounded run receiver frame");
static GRunRoot g_run_root(int64_t slot) {
    GArray header=g_array(slot);return (GRunRoot){header,header.data};
}
static void g_run_reset(GRunRoot *receiving) {
    if(!receiving || !receiving->header.region)g_panic("run has no receiving region");
    receiving->header.len=0;receiving->end=receiving->header.data;
    receiving->header.region->stack.top=receiving->end;
}
static void g_run_check(const GRunRoot *root,GRunSkip skip) {
    if(!root || !root->header.region || !root->header.region->base || root->header.len<0)g_panic("invalid run receiver capability");
    uintptr_t base=(uintptr_t)root->header.region->base,data=(uintptr_t)root->header.data,end=(uintptr_t)root->end;
    if(data<base || end<data || data-base>root->header.region->usable || end-base>root->header.region->usable)g_panic("run end outside receiving region");
    const uint8_t *at=root->header.data;
    for(int64_t i=0;i<root->header.len;i++)at=skip(at,root->end);
    if(at!=root->end)g_panic("run count and committed span disagree");
}
static GImage g_run_view(const GRunRoot *root,int64_t index,GRunSkip skip) {
    g_run_check(root,skip);
    if(index<0 || index>=root->header.len)g_panic("run index outside committed count");
    const uint8_t *at=root->header.data;
    for(int64_t i=0;i<index;i++)at=skip(at,root->end);
    return (GImage){(uint8_t*)at,(uint8_t*)skip(at,root->end),NULL};
}
static uint8_t *g_run_append(GRunRoot *receiving,GImage completed,GRunSkip skip) {
    g_run_check(receiving,skip);
    if(skip(completed.base,completed.end)!=completed.end)g_panic("completed run element has trailing bytes");
    if(receiving->header.len==INT64_MAX)g_panic("run length overflow");
    if(receiving->header.region->stack.top!=receiving->end)g_panic("run append has an open writer");
    int64_t bytes=g_image_span(completed);uint8_t *at=g_image_space(receiving->header.region,bytes);
    if(bytes)memmove(at,completed.base,(size_t)bytes);
    g_image_advance(receiving->header.region,at+bytes);
    receiving->header.len++;receiving->end=at+bytes;return at;
}
static void g_run_land(GRunRoot *receiving,const GRunRoot *completed,GRunSkip skip) {
    g_run_check(receiving,skip);g_run_check(completed,skip);
    if(receiving==completed)return;
    int64_t bytes=(int64_t)(completed->end-completed->header.data);GRegion *region=receiving->header.region;
    uintptr_t offset=(uintptr_t)receiving->header.data-(uintptr_t)region->base;
    if((uint64_t)bytes>region->usable-offset)g_panic("run landing exceeds receiving region");
    if(bytes)memmove(receiving->header.data,completed->header.data,(size_t)bytes);
    receiving->header.len=completed->header.len;receiving->end=receiving->header.data+bytes;
    region->stack.top=receiving->end;
    uint64_t used=(uint64_t)(receiving->end-region->base);if(used>region->high_water)region->high_water=used;
}
