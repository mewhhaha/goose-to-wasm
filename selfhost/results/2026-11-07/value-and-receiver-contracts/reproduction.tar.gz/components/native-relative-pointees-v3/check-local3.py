from pathlib import Path
import subprocess,json,hashlib,time,shutil
b=Path(__file__).resolve().parent;r=b.parents[2];out=b/'local-controls3';out.mkdir(exist_ok=False);compiler=b/'build1/goose';results=[];expected={'local-cancel':'1 one\n4 four\n','alias-evaluation':'1 one\n2 next\n','copy-alias':'1 one\n1 one\n'}
(out/'expected-before-execution.json').write_text(json.dumps(expected,indent=2)+'\n')
for source in sorted((b/'controls3').glob('*.goose')):
 for level in (0,2):
  case=source.stem+'-O'+str(level);c=out/(case+'.c');row=dict(case=case,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),commands=[]);cmd=[str(compiler),str(source),'--stdlib',str(r/'stdlib'),'--target','native','--standalone','-O'+str(level),'-o',str(c)];p=subprocess.run(cmd,capture_output=True);(out/(case+'-emit.stderr')).write_bytes(p.stderr);row['commands'].append(dict(phase='emit',command=cmd,exit_code=p.returncode));
  if p.returncode==0:
   for cc in [shutil.which('clang'),shutil.which('gcc')]:
    label=case+'-'+Path(cc).name;exe=out/label
    for phase,cmd in [('cc',[cc,'-std=gnu11','-O'+str(level),'-fsanitize=address,undefined','-fno-omit-frame-pointer',str(c),'-lm','-ldl','-pthread','-o',str(exe)]),('run',[str(exe)])]:
     start=time.monotonic();p=subprocess.run(cmd,capture_output=True,timeout=60);(out/(label+'-'+phase+'.stdout')).write_bytes(p.stdout);(out/(label+'-'+phase+'.stderr')).write_bytes(p.stderr);ok=p.returncode==0
     if phase=='run':ok=ok and p.stdout.decode()==expected[source.stem]
     row['commands'].append(dict(phase=phase,command=cmd,seconds=time.monotonic()-start,exit_code=p.returncode,ok=ok))
     if not ok:break
  results.append(row);print(case,[(x['phase'],x['exit_code'],x.get('ok')) for x in row['commands']],flush=True)
(out/'report.json').write_text(json.dumps(dict(status='measured',results=results),indent=2)+'\n')
