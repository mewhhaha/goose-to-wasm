from pathlib import Path
import subprocess,json,hashlib,time,shutil
b=Path(__file__).resolve().parent;r=b.parents[2];out=b/'admission1';out.mkdir(exist_ok=False);compiler=b/'build1/goose';cc=shutil.which('clang');results=[]
for source in sorted((b/'controls1').glob('*.goose')):
 for level in (0,2):
  case=source.stem+'-O'+str(level);c=out/(case+'.c');exe=out/case;result=dict(case=case,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),commands=[])
  for phase,cmd in [('emit',[str(compiler),str(source),'--stdlib',str(r/'stdlib'),'--target','native','--standalone','-O'+str(level),'-o',str(c)]),('cc',[cc,'-std=gnu11','-O'+str(level),str(c),'-lm','-ldl','-pthread','-o',str(exe)]),('run',[str(exe)])]:
   start=time.monotonic();p=subprocess.run(cmd,capture_output=True,timeout=90);(out/(case+'-'+phase+'.stdout')).write_bytes(p.stdout);(out/(case+'-'+phase+'.stderr')).write_bytes(p.stderr);result['commands'].append(dict(phase=phase,command=cmd,seconds=time.monotonic()-start,exit_code=p.returncode));
   if p.returncode:break
  results.append(result);print(case,result['commands'][-1]['phase'],result['commands'][-1]['exit_code'],flush=True)
(out/'report.json').write_text(json.dumps(dict(status='measured',results=results),indent=2)+'\n')
