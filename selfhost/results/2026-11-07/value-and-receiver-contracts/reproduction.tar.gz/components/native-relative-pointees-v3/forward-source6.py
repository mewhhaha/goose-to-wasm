from pathlib import Path
b=Path(__file__).resolve().parent/'source6/selfhost';p=b/'codegen_c_storage.goose';s=p.read_text();pos=s.index('fn cc_self_run_inside(');s=s[:pos]+'''fn cc_run_reference(p: Program&, id: i64) -> bool {
    return id >= 0 && p.types[id].kind == TY_REF && p.types[id].length_storage < 0 && (p.types[id].flags & TF_OPTIONAL) == 0 && cc_self_run(p, p.types[id].element);
}
''' +s[pos:];p.write_text(s)
p=b/'codegen_c.goose';s=p.read_text().replace('fn cc_run_capability(f: CcBody&, address: i64) -> i64 {','fn cc_run_capability(f: CcBody&, address: i64) -> i64 {\n    if address < 0 { return -1; }')
needle='    if declaration.kind == N_VARIABLE && (declaration.flags & F_VAR) == 0 && declaration.right >= 0 { return cc_run_reference_owner'
s=s.replace(needle,'''    if declaration.kind == N_PARAM && symbol.owner == f.function && cc_run_reference(p, symbol.type_id) { return cc_run_bind(f, -1, -1, "g_run_owner_", n.symbol); }
'''+needle)
s=s.replace('if cc_flat_image_reference(p, p.nodes[param].type_id) { cc_text(out, ",GRef"); }','if cc_flat_image_reference(p, p.nodes[param].type_id) { cc_text(out, ",GRef"); }\n        if cc_run_reference(p, p.nodes[param].type_id) { cc_text(out, ",GRunRoot*"); }')
s=s.replace('if cc_flat_image_reference(p, p.nodes[scan].type_id) { authority = true; }','if cc_flat_image_reference(p, p.nodes[scan].type_id) || cc_run_reference(p, p.nodes[scan].type_id) { authority = true; }')
needle='        if cc_flat_image_reference(p, p.nodes[param].type_id) {\n            let owner = cc_image_reference_owner(p, f, arg);'
s=s.replace(needle,'''        if cc_run_reference(p, p.nodes[param].type_id) {
            let owner = cc_run_reference_owner(p, f, arg);
            if owner < 0 { cc_fail(p, arg, "c: run argument has no proved receiving capability"); return -1; }
            f.work[args_start + args_count + ordinal] = owner;
        }
        if cc_flat_image_reference(p, p.nodes[param].type_id) {
            let owner = cc_image_reference_owner(p, f, arg);''')
needle='        if cc_flat_image_reference(p, p.nodes[param].type_id) { cc_text(f.out, ","); cc_id(f.out, "g_v", f.work[args_start + args_count + i]); }'
s=s.replace(needle,needle+'\n        if cc_run_reference(p, p.nodes[param].type_id) { cc_text(f.out, ","); cc_id(f.out, "g_run_cap", f.work[args_start + args_count + i]); }')
s=s.replace('if cc_flat_image_reference(p, p.nodes[checked].type_id) { cc_fail(p, node, "c: image-reference dispatch needs owner authority forwarding");','if cc_flat_image_reference(p, p.nodes[checked].type_id) || cc_run_reference(p, p.nodes[checked].type_id) { cc_fail(p, node, "c: image-reference dispatch needs owner authority forwarding");')
needle='        if cc_flat_image_reference(p, p.nodes[param].type_id) { cc_text(out, ",GRef "); cc_id(out, "g_image_owner_", p.nodes[param].symbol); }'
s=s.replace(needle,needle+'\n        if cc_run_reference(p, p.nodes[param].type_id) { cc_text(out, ",GRunRoot *"); cc_id(out, "g_run_owner_", p.nodes[param].symbol); }')
needle='        if cc_flat_image_reference(p, n.type_id) && !end {'
s=s.replace(needle,'''        if cc_run_reference(p, n.type_id) && !end {
            cc_text(out, "if(g_ref("); cc_id(out, "g_run_owner_", n.symbol); cc_text(out, ")!="); cc_id(out, "g_s", n.symbol); cc_text(out, ")g_panic(\\"run argument owner mismatch\\");\\ng_run_check("); cc_id(out, "g_run_owner_", n.symbol); cc_text(out, ","); cc_id(out, "g_self_skip_", p.types[p.types[n.type_id].element].element); cc_text(out, ");\\n");
        }
'''+needle)
s=s.replace('if cc_self_run(p, type_id) || cc_kind(p, type_id) == TY_REF && cc_self_run(p, p.types[type_id].element) { cc_fail(p, checked,','if cc_self_run(p, type_id) || cc_kind(p, type_id) == TY_REF && cc_self_run(p, p.types[type_id].element) && !cc_run_reference(p, type_id) { cc_fail(p, checked,')
# A returned push reference has an exact bounded view from the just-committed root.
needle='        cc_restore(f, mark); f.region_live = mark; return result;\n    }\n\n    let element = p.types[array].element;'
s=s.replace(needle,'''        let view = cc_temp(p, f, p.types[array].element, true, false); cc_set(f, view); cc_text(f.out, "(GImage){g_address("); cc_id(f.out, "g_v", result); cc_text(f.out, "),"); cc_id(f.out, "g_run_cap", capability); cc_text(f.out, "->end,NULL};\\n");
        let owner = cc_temporary_ref(f, view); f.cursors.push(CcCursor { symbol: -1, index: -1, address: result, type_id: p.types[array].element, node: node, owner_header: owner });
        cc_restore(f, mark); f.region_live = mark; return result;
    }

    let element = p.types[array].element;''')
# Pointer rebinding cannot preserve the independent incoming capability.
needle='recursive fn cc_assign(p: Program&, f: CcBody&, node: i64) -> i64 {'
if needle in s:s=s.replace(needle,needle+'\n    if p.nodes[node].integer == T_DOTASSIGN && cc_run_reference(p, cc_place_type(p, p.nodes[node].left)) { cc_fail(p, node, "c: run reference rebinding requires capability adaptation"); return -1; }')
# Preserve optional/null scalar operations that inspect no run data.
s=s.replace('if cc_self_run(p, run) && to != run && (cc_kind(p, to)', 'if from != to && cc_self_run(p, run) && !(cc_kind(p, from) == TY_REF && to == TYPE_BOOL && (p.types[from].flags & TF_OPTIONAL) != 0) && to != run && (cc_kind(p, to)')
p.write_text(s)
