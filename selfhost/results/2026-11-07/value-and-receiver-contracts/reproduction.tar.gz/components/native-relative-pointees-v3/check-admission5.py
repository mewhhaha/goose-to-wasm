from pathlib import Path
import subprocess,hashlib,json,tarfile,shutil,time
b=Path(__file__).resolve().parent;r=b.parents[2];out=b/'admission5';out.mkdir(exist_ok=False);compiler=b/'build5/goose';manifest=json.loads((r/'tests/conformance/cases.json').read_text());cases=[]
expected={'row-local':'9 alpha\n','row-forward':'12 12\n','row-map':'1 1\n2 2\n3 3\n','row-push-growth':'1 one\n','row-initializer-exit':'1 one\n3 three\n','global-bytes':'1 1\n','local-cancel':'1 one\n4 four\n','alias-evaluation':'1 one\n2 next\n','copy-alias':'1 one\n1 one\n'}
for directory in ['controls1','controls3']:
 for p in sorted((b/directory).glob('*.goose')):cases.append(dict(name=p.stem,source=p,expected=expected.get(p.stem)))
archive=r/manifest['upstream']['archive'];assert hashlib.sha256(archive.read_bytes()).hexdigest()==manifest['upstream']['sha256']
with tarfile.open(archive) as t:
 for name in ['relative_block_results','relative_destination_results']:
  c=next(x for x in manifest['cases'] if x['id']=='upstream/storage/'+name and x['target']=='native');data=t.extractfile(c['source'].split(':',1)[1]).read();p=out/(name+'.goose');p.write_bytes(data);cases.append(dict(name=name,source=p,expected=c['expect']['stdout']))
(out/'expected-before-execution.json').write_text(json.dumps({c['name']:c['expected'] for c in cases},indent=2)+'\n');results=[]
for case in cases:
 for level in (0,2):
  label=case['name']+'-O'+str(level);c=out/(label+'.c');exe=out/label;row=dict(case=case['name'],level=level,source_sha256=hashlib.sha256(case['source'].read_bytes()).hexdigest(),expected=case['expected'],commands=[])
  commands=[('emit',[str(compiler),str(case['source']),'--stdlib',str(r/'build/completion-runs/c-only-bootstrap-47/stdlib'),'--target','native','--standalone','-O'+str(level),'-o',str(c)]),('cc',[shutil.which('clang'),'-std=gnu11','-O'+str(level),str(c),'-lm','-ldl','-pthread','-o',str(exe)]),('run',[str(exe)])]
  for phase,cmd in commands:
   start=time.monotonic();p=subprocess.run(cmd,capture_output=True,timeout=90);(out/(label+'-'+phase+'.stdout')).write_bytes(p.stdout);(out/(label+'-'+phase+'.stderr')).write_bytes(p.stderr);ok=p.returncode==0
   if phase=='run':ok=ok and p.stdout.decode()==case['expected']
   row['commands'].append(dict(phase=phase,command=cmd,exit_code=p.returncode,seconds=time.monotonic()-start,ok=ok))
   if not ok:break
  results.append(row);print(label,phase,p.returncode,ok,flush=True);(out/'report.json').write_text(json.dumps(dict(status='measured',compiler_sha256=hashlib.sha256(compiler.read_bytes()).hexdigest(),results=results),indent=2)+'\n')
