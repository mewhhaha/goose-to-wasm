# Native source8 root-capability review — 2026-11-07

Disposition: **not ready for delivery**. The bounded typed-capability work is useful, but fresh-result staging violates the primary construction contract. This review is source-only. Existing source8 tests are summarized in observed-source8-evidence.json; no probe/build/runtime was launched by this reviewer, including during benchmark48 hold. Source8 and every previous source/review variant remain unchanged.

## Exact reviewed change

Compared every file in native-relative-pointees-v3/source8 with snapshot-47. Only native/runs.h, selfhost/codegen_c.goose and selfhost/codegen_c_storage.goose differ. In particular native/images.h is exact47. source8-pins.json pins those files and the baseline; adjacent patch copies preserve the reviewed delta. build8/report.json binds the same files to candidate executable 3e6dab3a8cb31ae9d49ab6e97fa2bad30c41536d518d40ecf9adedcd347f1e23.

## Blocker 1: staging fresh rows and replacing roots transactionally

Primary goose_spec.md §4.3 (1269–1293) requires fresh nonfixed results to be built directly in their receiving storage through calls and branches. Its limited-capacity exception expressly does not permit staging an ordinary fresh result for a resizable receiver. §7.3 (2517–2550) says a pushed result builds at the top of the receiving array stack, then push adjusts length; an assigned result builds in the target stack after replacing its contents. §4.4 (1309–1328) specifies clear-before-construction and disallows RHS access to the array, including through globals/captures and aliases. This is an explicit representation/construction guarantee, even when a self-contained offset would survive copying.

The primary implementation corroborates those requirements:

- codegen_builtins.h561–630: ElemValue stages fixed ordinary values only. Variable-sized values and fixed aggregates containing relative references produce no staged value: EmitPush gives GenConstruct the actual receiving stack, then increments length.
- codegen_nodes.h895–912: whole resizable assignment resets the destination stack top to its element start, then constructs the RHS there.
- codegen_construct.h1196–1251: the array count is written to its receiver before constructing the literal elements; field initialization builds in order at that same stack (1341–1378).
- codegen_stmts.h624–660: an exit value may be built behind an abandoned partial destination and moved down over it. This narrowly authorized relocation does not restore old pre-assignment contents.

Source8 does otherwise:

- cc_construct_into166–177 allocates a separate seeded run temporary and builds the whole replacement there, then g_run_land copies its byte span into the real root.
- cc_image_extend2439–2446 builds a complete fresh Row independently with cc_to, then g_run_append reserves and memmoves it into the receiving root.
- cc_committed_run_array1781–1793 repeats that staging for literal children.
- cc_flat_image_record1975–2025 stages all field values before writing the Row, including a nonfixed text result in its own image, rather than forwarding the Row's receiving byte cursor through that result.

The earlier authority-plan.md proposal of preserving old root contents through replacement was too strong and is corrected by this review. The authored controls6/run-staged-cancel.goose expectation that canceled whole assignment preserves `1 one` must remain preserved as experiment evidence, but is not primary-derived conformance evidence. Do not replace its expected output with a candidate observation. Exact observable partial-assignment behavior has not been established by this review; refuse unsupported escaping replacement forms until it is modeled from the primary rather than promising rollback. Root alias reads/writes in replacement RHS are forbidden by §4.4 and cannot justify old-root snapshot semantics.

Minimal direction: preserve GRunRoot's committed end, but use a temporary receiving **descriptor over the actual receiving region** at the committed end for a pushed Row. Forward that destination through calls/branches/field construction. Validate the completed bounded Row and publish count/end after completion. An abandoned push can discard its uncommitted suffix while leaving previous committed elements intact. A whole replacement begins by clearing the receiver; its exit handling must follow the primary partial-destination rules, not restore the old value. Keep nonlocal result or replacement routes refused where their exact destination recovery is unimplemented. Preserve arbitrary prior-row links as refused; those require more than pure-self copying.

Required proof for revised source: actual generated C receiving-descriptor instrumentation must establish that a fresh Row/callee writes in the root's region at its receiving address (not just that final bytes match). Also exercise a callback/nonlocal exit before completion and a subsequent append, and source-derived whole replacement behavior. Repeat the exact whole frozen relative_block_results original at O0/O2; its two original rows remain provisional until final-source gates finish.

## Finding 2: nested-root admission predicate is ineffective

cc_temp297 attempts to reject aggregate nested roots with `cc_relative_fields(type) && cc_self_run_inside(type)`. But cc_relative_fields in codegen_c_storage.goose338–354 stops at grow arrays and returns false. A normal holder whose field is Row[>..] therefore misses that guard. Some later operations fail for missing capabilities, but that is not a proof that defaults, copies, function results and generated helpers all refuse. The fallback g_init/g_store/g_image families do not generally forward a typed run capability.

Before admission, either demonstrate complete typed32 handling for each such route, or make the unsupported aggregate guard depend directly on cc_self_run_inside (with any supported plain-reference exceptions kept explicit). Pin an empty nested holder, populated holder, holder result, copy, field len and attempted push control. A compiler refusal is acceptable for this intentionally bounded stage; a later C compilation failure or runtime assertion is not an admission guard.

## Coherent parts retained for a revision

- GArray remains24, GRef8; the compiler's distinct GRunRoot is32 with committed end at24. No arbitrary raw GRef-to-extended-header authority is invented in caller code. cc_run_require and paired parameter checks bind the actual header address to an explicit GRunRoot pointer. Unknown returned root references, mutable alias rebinding, foreign/thread/export/dispatch and nested channels have explicit or downstream refusals; the nested guard above still needs correction.
- g_run_check checks region bounds, nonnegative count, exact count/span agreement and full Row skips; count is never inferred from capacity or working cursor. g_self_skip checks each fixed-width self link against row start and validates canonical checked-width byte-tail count. g_self_end additionally requires an exact row extent. Default count4 and varint tail forms remain distinct.
- Exact GImage element views preserve their own end, so later permitted growth cannot enlarge an old held view. Parameter owner identity is checked before use. Node/loop binding owner records avoid rerunning an initializer merely to recover its owner.
- Foreach rereads current root length, matching primary codegen_nodes.h1006–1109 and implementation.md3889 onward. Continue reaches the increment path; break restores local region state. Root-reference rebinding is refused, so an accepted mutable path cannot silently keep using an old root identity.
- The generated8-matrix report covers actual source8 C, compiler/toolchain pins, GRunRoot32/GArray24/GRef8, independent16/145-byte padded varint rows and malformed count/end/canonical-varint/self-link/owner pairing cases. Those are meaningful bounded-layout checks, not proof of fresh construction placement.
- Existing push cancellation and held-view growth controls are useful, but source8 must rerun them and complete original/own-C/native preservation gates after any implementation revision. Prior source6 whole-original results are not source8 results.

## Costs and evidence limits

Source8 performs a complete committed-run validation on every append. Each foreach iteration performs an outer full check, another full check in g_run_view, then walks from the beginning to its index. Construction and traversal therefore have quadratic row-walking cost. This is a source-derived complexity observation, not a timing measurement. No speedup claim is supported. Future optimization must retain exact logical bounds and validated capability identity.

Own-C fixed point and complete final-source preservation evidence were pending when inspected. The header/harness evidence cannot establish the compiler's own full ABI fixed point. Batch48 is unaffected and frozen separately; this candidate remains49+ work.
