from pathlib import Path
base=Path(__file__).resolve().parent/'source/selfhost'
s=base/'codegen_c_storage.goose';t=s.read_text();at=t.index('// This first physical stage')
t=t[:at]+'''// Local pure-self images carry owner bounds; arrays require separate root authority.
fn cc_self_relative_image(p: Program&, id: i64) -> bool {
    if id < 0 || p.types[id].kind != TY_STRUCT || cc_size_class(p, id) != 1 { return false; }
    var field = p.nodes[p.types[id].declaration].first; var self = false; var text = false;
    while field >= 0 {
        let n = p.nodes[field]; field = n.next;
        if (n.flags & F_PAD) != 0 { continue; } let t = p.types[n.type_id];
        if t.kind == TY_REF && t.element == id && t.length_storage > 0 && t.pool < 0 && (t.flags & TF_OPTIONAL) == 0 { self = true; }
        else if t.kind == TY_ARRAY && t.array_kind == A_VAR && t.element == TYPE_U8 && field < 0 { text = true; }
        else if t.kind != TY_INT && t.kind != TY_BOOL || t.storage != 0 { return false; }
    }
    return self && text;
}
fn cc_bounded_relative_image(p: Program&, id: i64) -> bool {
    return cc_flat_relative_image(p, id) || cc_self_relative_image(p, id);
}
''' +t[at:]
s.write_text(t)
# Bound authority routes are shared; keep old type predicate separate.
for name in ['codegen_c.goose','codegen_c_storage.goose','codegen_c_threads.goose']:
 s=base/name;t=s.read_text()
 if name=='codegen_c_storage.goose':
  before,old,after=t.partition('fn cc_flat_relative_image(')
  body,mark,after=after.partition('fn cc_flat_image_reference(')
  before=before.replace('return cc_flat_relative_image(p, id) ||','return cc_flat_relative_image(p, id) ||')
  after=after.replace('cc_flat_relative_image(', 'cc_bounded_relative_image(')
  t=before+old+body+mark+after
 else:t=t.replace('cc_flat_relative_image(', 'cc_bounded_relative_image(')
 s.write_text(t)
s=base/'codegen_c.goose';t=s.read_text()
# Explicitly preserve unsupported array guard.
t=t.replace('(!cc_image_constructible(p, p.types[type_id].element) || cc_relative_fields(p, p.types[type_id].element))','(!cc_image_constructible(p, p.types[type_id].element) || cc_relative_fields(p, p.types[type_id].element))')
# Avoid unowned standalone relative temps; only bounded read emits this.
t=t.replace('if cc_relative_cell(p, type_id) && !cc_fixed_storage(p, p.types[type_id].element)', 'if cc_relative_cell(p, type_id) && !cc_fixed_storage(p, p.types[type_id].element) && !cc_self_relative_image(p, p.types[type_id].element)')
# Owner resolution for chained self member.
needle='    if n.kind == N_UNARY && n.integer == T_BITAND { return cc_image_reference_owner(p, f, n.left, depth + 1); }'
t=t.replace(needle,'''    if n.kind == N_MEMBER && cc_relative_cell(p, n.type_id) && cc_self_relative_image(p, p.types[n.type_id].element) {
        let place = cc_base_place(p, f, n.left); return place.owner_header;
    }
'''+needle)
# Reject rebinding self anywhere (no implicit separate owner).
needle='fn cc_write(p: Program&, f: CcBody&, place: CcPlace, value: i64, node: i64) {'
t=t.replace(needle,needle+'''
    if cc_relative_cell(p, place.type_id) && cc_self_relative_image(p, p.types[place.type_id].element) { cc_fail(p, node, "c: pure-self image links cannot be rebound"); return; }
''')
# Bounded body validation before every self reference read.
needle='    if place.form == CC_IMAGE && place.image_end >= 0 {\n        let value = cc_temp'
t=t.replace(needle,'''    if place.form == CC_IMAGE && place.image_end >= 0 && cc_relative_cell(p, place.type_id) && cc_self_relative_image(p, p.types[place.type_id].element) {
        let value = cc_ref_temp(f); cc_set(f, value); cc_text(f.out, "g_relative_load("); cc_id(f.out, "g_v", place.address); cc_text(f.out, ","); cc_number(f.out, p.types[place.type_id].length_storage); cc_text(f.out, ",0,0);\\n");
        cc_text(f.out, "if("); cc_id(f.out, "g_v", value); cc_text(f.out, "!="); cc_id(f.out, "g_v", place.image_base); cc_text(f.out, ")g_panic(\\"pure-self image target mismatch\\");\\n(void)g_self_end_"); cc_number(f.out, p.types[place.type_id].element); cc_text(f.out, "(g_address("); cc_id(f.out, "g_v", place.image_base); cc_text(f.out, "),g_address("); cc_id(f.out, "g_v", place.image_end); cc_text(f.out, "));\\n");
        return cc_convert(p, f, value, place.type_id, wanted, node);
    }
    if place.form == CC_IMAGE && place.image_end >= 0 {
        let value = cc_temp''')
# Text physical load is borrowed GImage descriptor; no unbounded transfer.
needle='        out.format("static g_t", id, " g_physical_load_", id,'
pos=t.index(needle)
t=t[:pos]+'''        if t.kind == TY_ARRAY && t.array_kind == A_VAR && t.element == TYPE_U8 {
            out.format("static g_t", id, " g_physical_load_", id, "(const uint8_t *cell,const uint8_t *end){int64_t count;const uint8_t *data=g_image_count_check(cell,end,", t.length_storage, ",&count);if(!data || (uint64_t)count>(uintptr_t)end-(uintptr_t)data)g_panic(\\"invalid bounded byte image\\");return (GImage){(uint8_t*)cell,(uint8_t*)data+count,NULL};}\\n"); continue;
        }
'''+t[pos:]
# Self physical walker emitted before physical loads.
needle='    for t, id in p.types {\n        if !physical[id] { continue; }'
t=t.replace(needle,'''    for t, id in p.types {
        if !used[id] || !cc_self_relative_image(p, id) { continue; }
        out.format("static const uint8_t *g_self_end_", id, "(const uint8_t *start,const uint8_t *end){const uint8_t *cell=start;\\n");
        var field = p.nodes[t.declaration].first;
        while field >= 0 {
            let n = p.nodes[field]; field = n.next;
            if (n.flags & F_PAD) != 0 { out.format("cell=g_relative_cell_skip(cell,end,", n.aux, ");\\n"); }
            else {
                let ft = p.types[n.type_id];
                if ft.kind == TY_ARRAY { out.format("int64_t count;const uint8_t *data=g_image_count_check(cell,end,", ft.length_storage, ",&count);if(!data || (uint64_t)count>(uintptr_t)end-(uintptr_t)data)g_panic(\\"invalid bounded self image text\\");cell=data+count;\\n"); }
                else {
                    out.format("(void)g_relative_cell_skip(cell,end,", cc_physical_cell_width(p, n.type_id), ");\\n");
                    if ft.kind == TY_REF { out.format("if(g_relative_load(g_ref(cell),", ft.length_storage, ",0,0)!=g_ref(start))g_panic(\\"pure-self image target mismatch\\");\\n"); }
                    out.format("cell=g_relative_cell_skip(cell,end,", cc_physical_cell_width(p, n.type_id), ");\\n");
                }
            }
        }
        out.append("if(cell!=end)g_panic(\\"pure-self image trailing bytes\\");return cell;}\\n");
    }
'''+needle)
# Stage constructor self as a marker; all non-self leaves evaluate before writes.
needle='        var value = -1;\n        if initializer >= 0 { value = cc_to(p, f, initializer, n.type_id); } else { value = cc_default(p, f, n.type_id); }\n        if cc_relative_cell(p, n.type_id) {'
t=t.replace(needle,'''        if cc_relative_cell(p, n.type_id) && cc_self_relative_image(p, type_id) {
            if initializer < 0 || p.nodes[initializer].kind != N_SELF { cc_fail(p, node, "c: pure-self image constructor requires literal self"); return -1; }
            f.work[staged] = -1; staged++; continue;
        }
'''+needle)
# Emit receiving-relative self with final byte offset.
needle='        if cc_relative_cell(p, n.type_id) {\n            let width = p.types[n.type_id].length_storage; let cursor = cc_ref_temp(f);'
t=t.replace(needle,'''        if cc_relative_cell(p, n.type_id) && cc_self_relative_image(p, type_id) {
            let width = p.types[n.type_id].length_storage;
            cc_text(f.out, "g_relative_store(g_ref(g_image_space("); cc_id(f.out, "g_flat", raw); cc_text(f.out, "->region,"); cc_number(f.out, width); cc_text(f.out, ")),g_ref("); cc_id(f.out, "g_flat", raw); cc_text(f.out, "->base),"); cc_number(f.out, width); cc_text(f.out, ",0,0,\\"<self image>\\",0);g_image_advance("); cc_id(f.out, "g_flat", raw); cc_text(f.out, "->region,"); cc_id(f.out, "g_flat", raw); cc_text(f.out, "->region->stack.top+"); cc_number(f.out, width); cc_text(f.out, ");\\n"); continue;
        }
'''+needle)
# Do not traverse or render whole Row recursively.
needle='fn cc_render_unbounded_image(p: Program&, id: i64) -> bool {'
# This function lives storage, handled below.
s.write_text(t)
s=base/'codegen_c_storage.goose';t=s.read_text().replace('fn cc_render_unbounded_image(p: Program&, id: i64) -> bool {','fn cc_render_unbounded_image(p: Program&, id: i64) -> bool {\n    if cc_self_relative_image(p, id) { return true; }')
s.write_text(t)
