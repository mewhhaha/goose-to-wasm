# Narrow local prerequisite

Mutable experiment based on immutable snapshot46 and preserved native-relative-pointees-v1. No original frozen target gain claimed.

Admission shape is a struct with fixed scalar fields, fixed-width self-relative reference(s) to the exact struct type, and a final inline u8[] tail. Each relative constructor initializer must be literal self. Construction stages non-self leaves before resetting the receiving image cursor, then writes self against the actual image base. Rebinding pure-self cells refuses.

Owner8's explicit plain-reference owner argument is reused only for local names/immutable aliases/known parameters and exact self-member chains. Each self-link read checks the exact Row start and walks the entire bounded body (canonical count, available bytes, exact end). No variable-array element admission: existing relative-element guard stays in place. No committed-end channel implemented yet.

Pending qualification: source controls, independent bytes and malformed bounds, alias/copy/growth/nonlocal/order boundaries, whole-image copy and match restrictions, prior native preservation, full own ABI/C fixed point. This is not a deliverable patch until all admitted paths are reviewed and tested.
