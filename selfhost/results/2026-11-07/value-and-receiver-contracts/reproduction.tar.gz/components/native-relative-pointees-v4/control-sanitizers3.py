from pathlib import Path
import json,subprocess,time,hashlib,shutil
w=Path(__file__).resolve().parent;out=w/'control-sanitizers3';out.mkdir();cases=['row-push-growth','row-branch-return','foreach-append-exits','alias-evaluation','run-parameter-replace'];expected=json.loads((w/'expected1-before-execution.json').read_text());compilers=[Path(shutil.which(x)).resolve() for x in ['clang','gcc']];pins={};rows=[]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
for compiler in compilers:
 pins[str(compiler)]=sha(compiler)
 for case in cases:
  for level in (0,2):
   c=w/'controls1-build3'/(case+'-O'+str(level)+'.c');pins[str(c)]=sha(c);label=compiler.name+'-'+case+'-O'+str(level);exe=out/label;row={'case':case,'level':level,'cc':str(compiler),'commands':[]}
   for phase,cmd in [('cc',[str(compiler),'-std=gnu11','-O'+str(level),'-fsanitize=address,undefined','-fno-omit-frame-pointer',str(c),'-lm','-ldl','-pthread','-o',str(exe)]),('run',[str(exe)])]:
    start=time.monotonic();p=subprocess.run(cmd,capture_output=True,timeout=90);(out/(label+'-'+phase+'.stdout')).write_bytes(p.stdout);(out/(label+'-'+phase+'.stderr')).write_bytes(p.stderr);ok=p.returncode==0 and (phase!='run' or p.stdout.decode()==expected[case]);row['commands'].append({'phase':phase,'command':cmd,'exit_code':p.returncode,'ok':ok,'seconds':time.monotonic()-start})
    if not ok:break
   row['passed']=phase=='run' and ok;rows.append(row);(out/'report.json').write_text(json.dumps({'status':'running','input_sha256':pins,'results':rows},indent=2)+'\n');print(label,row['passed'],flush=True)
assert all(sha(p)==h for p,h in pins.items());(out/'report.json').write_text(json.dumps({'status':'passed' if all(x['passed'] for x in rows) else 'failed','input_sha256':pins,'results':rows},indent=2)+'\n')
