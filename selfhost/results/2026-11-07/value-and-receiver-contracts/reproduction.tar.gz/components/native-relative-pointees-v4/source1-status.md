Rejected at compiler typecheck: global CcBody initializer reordered has_self_runs ahead of out/exits/work. No runtime controls executed. Corrected only declaration-order initializer in source2.
