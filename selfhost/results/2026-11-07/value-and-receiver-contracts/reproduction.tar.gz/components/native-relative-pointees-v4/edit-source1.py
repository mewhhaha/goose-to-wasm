from pathlib import Path
w=Path(__file__).resolve().parent; p=w/'source1/selfhost/codegen_c.goose';s=p.read_text()
def replace(a,b):
 global s
 assert s.count(a)==1,(s.count(a),a[:100]);s=s.replace(a,b)
replace('serial: i64 = 0, result_type: i64 = TYPE_VOID,','serial: i64 = 0, result_type: i64 = TYPE_VOID, has_self_runs: bool = false, self_build_depth: i64 = 0,')
replace('let keep = f.region_live; var actual = target; var actual_capability = -1;\n    if cc_self_run(p, type_id) {\n        actual_capability = cc_run_require(p, f, target, node); if actual_capability < 0 { return -1; }\n        let staged = cc_temp(p, f, type_id); actual = cc_temporary_ref(f, staged);\n    }','let actual = target;\n    if cc_self_run(p, type_id) && cc_run_require(p, f, target, node) < 0 { return -1; }')
replace('    if cc_self_run(p, type_id) { cc_restore(f, keep); f.region_live = keep; if value >= 0 { value = cc_alias_temp(p, f, type_id, target); } }\n','')
replace('cc_aggregate(p, type_id) && !cc_self_run(p, type_id) && cc_relative_fields(p, type_id) && cc_self_run_inside(p, type_id)','f.has_self_runs && cc_aggregate(p, type_id) && !cc_self_run(p, type_id) && cc_self_run_inside(p, type_id)')
replace('if receiving < 0 || source < 0 { return; }\n        cc_text(f.out, "g_run_land(', 'if receiving < 0 || source < 0 { return; }\n        if receiving != source { cc_fail(p, node, "c: run value requires direct receiving construction"); return; }\n        cc_text(f.out, "g_run_land(')
replace('let mark = f.region_live; let value = cc_to(p, f, child, element);\n        if value >= 0 { cc_text(f.out, "(void)g_run_append("); cc_id(f.out, "g_run_cap", capability); cc_text(f.out, ","); cc_id(f.out, "g_v", value); cc_text(f.out, ","); cc_run_skip(p, f, n.type_id); cc_text(f.out, ");\\n"); }','let mark = f.region_live; cc_run_construct_element(p, f, child, n.type_id, capability);')
replace('''        let mark = f.region_live; let value = cc_to(p, f, argument, p.types[array].element); if value < 0 { return -1; }
        let result = cc_ref_temp(f); cc_set(f, result); cc_text(f.out, "g_ref(g_run_append("); cc_id(f.out, "g_run_cap", capability); cc_text(f.out, ","); cc_id(f.out, "g_v", value); cc_text(f.out, ","); cc_run_skip(p, f, array); cc_text(f.out, "));\\n");''','''        let mark = f.region_live; let result = cc_run_construct_element(p, f, argument, array, capability); if result < 0 { return -1; }''')
replace('if cc_self_run(p, target_type) { let place = cc_base_place(p, f, n.left); cc_construct_into(p, f, n.right, target_type, place.address); return; }','''if cc_self_run(p, target_type) {
            let place = cc_base_place(p, f, n.left); let capability = cc_run_require(p, f, place.address, node); if capability < 0 { return; }
            cc_text(f.out, "g_run_reset("); cc_id(f.out, "g_run_cap", capability); cc_text(f.out, ");\\n");
            cc_construct_into(p, f, n.right, target_type, place.address); return;
        }''')
replace('    if cc_bounded_relative_image(p, type_id) { return cc_flat_image_record(p, f, node, type_id); }','    if cc_self_relative_image(p, type_id) { return cc_self_image_record(p, f, node, type_id); }\n    if cc_bounded_relative_image(p, type_id) { return cc_flat_image_record(p, f, node, type_id); }')
replace('if n.kind == N_BREAK || n.kind == N_CONTINUE {\n        var index', 'if n.kind == N_BREAK || n.kind == N_CONTINUE {\n        if f.self_build_depth > 0 { cc_fail(p, node, "c: exit during self-image construction requires partial-destination handling"); return -1; }\n        var index')
# The new field is computed once for each emitted body, not per temporary/type traversal.
s=s.replace('var f = CcBody { out: body, exits: exits, work: work, function: function, result_type: result_type,','var f = CcBody { out: body, exits: exits, work: work, function: function, result_type: result_type, has_self_runs: cc_self_runs_used(p),')
# Global body similarly.
s=s.replace('var f = CcBody { out: initialization,','var f = CcBody { has_self_runs: cc_self_runs_used(p), out: initialization,')
replace('let nonlocal = (n.flags & F_NONLOCAL) != 0;','let nonlocal = (n.flags & F_NONLOCAL) != 0;\n    if f.has_self_runs && nonlocal { cc_fail(p, function, "c: run construction with nonlocal exits requires partial-destination handling"); }')
anchor='recursive fn cc_committed_run_array('
i=s.index(anchor)
s=s[:i]+'''recursive fn cc_run_construct_element(p: Program&, f: CcBody&, node: i64, array: i64, capability: i64) -> i64 {
    let element = p.types[array].element; let value = cc_temp(p, f, element, true, false);
    cc_set(f, value); cc_text(f.out, "g_run_begin("); cc_id(f.out, "g_run_cap", capability); cc_text(f.out, ","); cc_run_skip(p, f, array); cc_text(f.out, ");\\n");
    let owner = cc_temporary_ref(f, value);
    cc_construct_into(p, f, node, element, owner);
    let result = cc_ref_temp(f); cc_set(f, result); cc_text(f.out, "g_ref(g_run_finish("); cc_id(f.out, "g_run_cap", capability); cc_text(f.out, ","); cc_id(f.out, "g_v", value); cc_text(f.out, ","); cc_run_skip(p, f, array); cc_text(f.out, "));\\n");
    return result;
}
''' +s[i:]
anchor='recursive fn cc_flat_image_record('
i=s.index(anchor)
s=s[:i]+'''recursive fn cc_self_image_record(p: Program&, f: CcBody&, node: i64, type_id: i64) -> i64 {
    let result = cc_result_temp(p, f, node, type_id); let owner = cc_temporary_ref(f, result);
    let raw = f.serial; f.serial++; var binding = -1;
    if node >= 0 { binding = p.nodes[node].first; }
    cc_id(f.out, "GImage *g_self_image", raw); cc_text(f.out, "=(GImage*)g_address("); cc_id(f.out, "g_v", owner); cc_text(f.out, ");\\n");
    cc_id(f.out, "g_self_image", raw); cc_text(f.out, "->region->stack.top="); cc_id(f.out, "g_self_image", raw); cc_text(f.out, "->base;\\n");
    f.self_build_depth++;
    var field = p.nodes[p.types[type_id].declaration].first;
    while field >= 0 {
        let current = field; let n = p.nodes[field]; field = n.next;
        if (n.flags & F_PAD) != 0 { cc_image_padding(f, owner, n.aux); continue; }
        var initializer = n.right;
        if binding >= 0 {
            if p.nodes[binding].symbol != current { cc_fail(p, node, "c: image initializer is not in declaration order"); f.self_build_depth--; return -1; }
            initializer = p.nodes[binding].right; binding = p.nodes[binding].next;
        }
        if cc_relative_cell(p, n.type_id) {
            if initializer < 0 || p.nodes[initializer].kind != N_SELF { cc_fail(p, node, "c: pure-self image constructor requires literal self"); f.self_build_depth--; return -1; }
            let width = p.types[n.type_id].length_storage;
            cc_text(f.out, "g_relative_store(g_ref(g_image_space("); cc_id(f.out, "g_self_image", raw); cc_text(f.out, "->region,"); cc_number(f.out, width); cc_text(f.out, ")),g_ref("); cc_id(f.out, "g_self_image", raw); cc_text(f.out, "->base),"); cc_number(f.out, width); cc_text(f.out, ",0,0,\\"<self image>\\",0);g_image_advance("); cc_id(f.out, "g_self_image", raw); cc_text(f.out, "->region,"); cc_id(f.out, "g_self_image", raw); cc_text(f.out, "->region->stack.top+"); cc_number(f.out, width); cc_text(f.out, ");\\n");
        } else { cc_image_field_value(p, f, owner, initializer, n.type_id); }
    }
    f.self_build_depth--;
    cc_text(f.out, "g_image_finish("); cc_id(f.out, "g_v", owner); cc_text(f.out, ","); cc_id(f.out, "g_self_image", raw); cc_text(f.out, "->region->stack.top);\\n"); return result;
}
''' +s[i:]
p.write_text(s)
p=w/'source1/selfhost/codegen_c_storage.goose';s=p.read_text();anchor='fn cc_run_reference(';i=s.index(anchor);s=s[:i]+'''fn cc_self_runs_used(p: Program&) -> bool {
    for t, id in p.types { if cc_self_run(p, id) { return true; } } return false;
}
'''+s[i:];p.write_text(s)
p=w/'source1/native/runs.h';s=p.read_text();i=s.index('static uint8_t *g_run_append(');s=s[:i]+'''/* A descriptor over the actual receiving region, never a second byte owner. */
static GImage g_run_begin(GRunRoot *receiving,GRunSkip skip) {
    g_run_check(receiving,skip);
    if(receiving->header.len==INT64_MAX)g_panic("run length overflow");
    if(receiving->header.region->stack.top!=receiving->end)g_panic("run append has an open writer");
    return (GImage){receiving->end,receiving->end,receiving->header.region};
}
static uint8_t *g_run_finish(GRunRoot *receiving,GImage completed,GRunSkip skip) {
    g_run_check(receiving,skip);
    if(completed.region!=receiving->header.region || completed.base!=receiving->end || completed.end!=completed.region->stack.top)g_panic("run element has no receiving authority");
    if(skip(completed.base,completed.end)!=completed.end)g_panic("completed run element has trailing bytes");
    if(receiving->header.len==INT64_MAX)g_panic("run length overflow");
    receiving->header.len++;receiving->end=completed.end;return completed.base;
}
/* Internal result adaptation may reuse a descriptor of the same receiver only. */
static void g_run_land(GRunRoot *receiving,const GRunRoot *completed,GRunSkip skip) {
    g_run_check(receiving,skip);g_run_check(completed,skip);
    if(receiving->header.region!=completed->header.region || receiving->header.data!=completed->header.data || receiving->header.len!=completed->header.len || receiving->end!=completed->end)g_panic("run result was not constructed at its receiver");
}
''';p.write_text(s)
