from pathlib import Path
import subprocess,hashlib,json,time,shutil
w=Path(__file__).resolve().parent;r=w.parents[2];out=w/'own-c3';out.mkdir(exist_ok=False);source=w/'source3/selfhost/main.goose';producer=w/'build3/goose';cc=Path(shutil.which('clang')).resolve();library=r/'build/completion-runs/c-only-bootstrap-48/stdlib'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
paths=[Path(__file__),producer,cc,*source.parent.glob('*.goose'),*(w/'source3/native').rglob('*.h'),*library.rglob('*.goose')];report={'status':'running','method':'Actual own-compiled native C2 executable emits same exact source as C3; require C2=C3 byte equality','input_sha256':{str(p):sha(p) for p in paths},'commands':[]}
def save():(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
save()
try:
 for phase,cmd in [('C2',[producer,source,'--stdlib',library,'--target','native','--standalone','-O0','-o',out/'C2.c']),('compile-C2',[cc,'-std=gnu11','-O0',out/'C2.c','-lm','-ldl','-pthread','-o',out/'goose-C2']),('C3',[out/'goose-C2',source,'--stdlib',library,'--target','native','--standalone','-O0','-o',out/'C3.c'])]:
  start=time.monotonic();cmd=list(map(str,cmd));p=subprocess.run(cmd,capture_output=True,timeout=600);(out/(phase+'.stdout')).write_bytes(p.stdout);(out/(phase+'.stderr')).write_bytes(p.stderr);report['commands'].append({'phase':phase,'command':cmd,'exit_code':p.returncode,'seconds':time.monotonic()-start});save()
  if p.returncode:raise RuntimeError(phase+': '+p.stderr.decode(errors='replace')[-3000:])
 report['C2_sha256']=sha(out/'C2.c');report['C3_sha256']=sha(out/'C3.c');assert (out/'C2.c').read_bytes()==(out/'C3.c').read_bytes(),'C2 != C3'
 report['input_sha256_after']={p:sha(p) for p in report['input_sha256']};assert report['input_sha256']==report['input_sha256_after'];report['status']='passed'
except BaseException as e:report.update(status='failed',error=repr(e));raise
finally:save()
print(report['status'],report.get('C2_sha256'),flush=True)
