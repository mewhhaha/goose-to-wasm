from pathlib import Path
import hashlib,json,subprocess,shutil,time
b=Path(__file__).resolve().parent;out=b/'generated5-matrix';out.mkdir(exist_ok=False);source=b/'generated5/wrapper.c';compilers=[Path(shutil.which('clang')).resolve(),Path(shutil.which('gcc')).resolve()]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
pins={str(p):sha(p) for p in [source,b/'generated5/fixture.c',b/'generated5/fixture.goose',*compilers,*(b/'source5/native').rglob('*.h')]};results=[]
for cc in compilers:
 for level in (0,2):
  label=cc.name+'-O'+str(level);exe=out/label;commands=[('cc',[str(cc),'-std=gnu11','-O'+str(level),'-fsanitize=address,undefined','-fno-omit-frame-pointer',str(source),'-lm','-ldl','-pthread','-o',str(exe)]),('run',[str(exe)])]
  for phase,cmd in commands:
   start=time.monotonic();p=subprocess.run(cmd,capture_output=True,timeout=60);(out/(label+'-'+phase+'.stdout')).write_bytes(p.stdout);(out/(label+'-'+phase+'.stderr')).write_bytes(p.stderr);results.append(dict(phase=phase,command=cmd,exit_code=p.returncode,seconds=time.monotonic()-start));print(label,phase,p.returncode,flush=True)
   if p.returncode:break
status='passed'
if any(x['exit_code'] for x in results):status='failed'
assert pins=={p:sha(p) for p in pins};(out/'report.json').write_text(json.dumps(dict(status=status,method='Actual source5 generated root/reference ABI; independent mixed16/145byte row spans; nine malformed/mismatched capability/direct-receiver children',input_sha256=pins,commands=results),indent=2)+'\n')
