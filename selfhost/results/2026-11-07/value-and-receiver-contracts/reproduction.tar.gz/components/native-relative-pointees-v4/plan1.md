# Primary direct-receiver draft1

Source1 is based on snapshot48, preserving its divergent match/if fixes, with the v3/source9 native prototype rebased before correction. It is not qualified.

Fresh pure-self Row fields now stream in declaration order into the actual receiving region. Run pushes use only a temporary GImage descriptor over the committed end of that same region; no separate byte staging or fresh-result copy. Successful completion validates the complete bounded Row before publishing count/end. Whole replacement resets the receiver before RHS construction. Internal result adaptation only reuses the same root storage.

The existing auxiliary GRunRoot32 and ordinary GArray24/GRef8 layouts remain. Committed end is the sole byte bound; region capacity and working top are not read authority. Unsupported nested root carriers are explicitly refused, including defaults. Source9 optional-null parameter preservation remains.

Partial-destination exits are not admitted: programs with nonlocal return frames plus a self run refuse; direct break/continue during a pure-self Row field construction refuse. This conservative program-level nonlocal restriction may exclude unrelated nonlocal functions. Whole-literal count timing cannot escape this admitted subset. No rollback/preserve-old replacement claim remains.

Review must verify ordinary Row result calls/branches really preserve the receiving descriptor and that no hidden copying helper escapes the reuse checks. Tests will keep rejected staging assumptions separate. Original relative_block_results is a target, not a pass yet; arbitrary-row-link relative_destination_results remains outside authority.

Current checks scan all committed rows during push and repeated foreach indexing. This has quadratic costs; no runtime performance improvement is claimed.
