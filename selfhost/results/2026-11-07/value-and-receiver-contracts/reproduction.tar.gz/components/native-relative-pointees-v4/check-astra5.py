from pathlib import Path
import json,hashlib,subprocess,time,shutil
w=Path(__file__).resolve().parent;r=w.parents[2];data=r/'build/completion-runs/astra-native-direct-49-2026-11-07/expected-before-execution.json';cases=json.loads(data.read_text())['cases'];out=w/'astra-controls5';out.mkdir();rows=[]
for case in cases:
 source=r/case['source'];assert hashlib.sha256(source.read_bytes()).hexdigest()==case['sha256']
 for level in (0,2):
  label=case['id']+'-O'+str(level);c=out/(label+'.c');exe=out/label;row={'case':case['id'],'source_sha256':case['sha256'],'level':level,'expect':case['expect'],'commands':[]}
  for phase,cmd in [('emit',[str(w/'build5/goose'),str(source),'--stdlib',str(r/'stdlib'),'--target','native','--standalone','-O'+str(level),'-o',str(c)]),('cc',[shutil.which('clang'),'-std=gnu11','-O'+str(level),str(c),'-lm','-ldl','-pthread','-o',str(exe)]),('run',[str(exe)])]:
   start=time.monotonic();p=subprocess.run(cmd,capture_output=True,timeout=90);(out/(label+'-'+phase+'.stdout')).write_bytes(p.stdout);(out/(label+'-'+phase+'.stderr')).write_bytes(p.stderr);ok=p.returncode==0
   if phase=='run':ok=ok and p.stdout.decode()==case.get('stdout')
   row['commands'].append({'phase':phase,'command':cmd,'exit_code':p.returncode,'seconds':time.monotonic()-start,'ok':ok})
   if not ok:break
  row['passed']=phase=='run' and ok if case['expect']=='run' else phase=='emit' and p.returncode!=0;rows.append(row);print(label,row['passed'],flush=True)
(out/'report.json').write_text(json.dumps({'status':'passed' if all(x['passed'] for x in rows) else 'failed','expected_before_execution_sha256':hashlib.sha256(data.read_bytes()).hexdigest(),'results':rows},indent=2)+'\n')
