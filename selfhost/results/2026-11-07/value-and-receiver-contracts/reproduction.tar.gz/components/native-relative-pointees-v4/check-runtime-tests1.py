from pathlib import Path
import json,subprocess,time,hashlib,shutil
w=Path(__file__).resolve().parent;out=w/'runtime-tests1-matrix';out.mkdir();source=w/'proposed/native/tests/runs.c';compilers=[Path(shutil.which(x)).resolve() for x in ['clang','gcc']];pins={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [source,*compilers,*(w/'source5/native').rglob('*.h')]};rows=[]
for cc in compilers:
 for mode,flags in [('release',['-O2']),('sanitized',['-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer'])]:
  label=cc.name+'-'+mode;exe=out/label;row={'cc':str(cc),'mode':mode,'commands':[]}
  for phase,cmd in [('cc',[str(cc),'-std=gnu11','-pthread',*flags,str(source),'-lm','-ldl','-o',str(exe)]),('run',[str(exe)])]:
   start=time.monotonic();p=subprocess.run(cmd,capture_output=True,timeout=90);(out/(label+'-'+phase+'.stdout')).write_bytes(p.stdout);(out/(label+'-'+phase+'.stderr')).write_bytes(p.stderr);ok=p.returncode==0
   if phase=='run':
    errors=p.stderr.decode();ok=ok and p.stdout==b'native bounded run receivers ok\n' and errors.count('goose runtime error:')==10 and 'AddressSanitizer' not in errors and 'runtime error:' not in errors.replace('goose runtime error:','')
   row['commands'].append({'phase':phase,'command':cmd,'exit_code':p.returncode,'seconds':time.monotonic()-start,'ok':ok})
   if not ok:break
  row['passed']=phase=='run' and ok;rows.append(row);print(label,row['passed'],flush=True)
assert pins=={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in pins};(out/'report.json').write_text(json.dumps({'status':'passed' if all(x['passed'] for x in rows) else 'failed','method':'Permanent proposed direct-header test: independent17/18-byte golden rows, same receiving region, logical publication, held bounds, reset and ten expected runtime refusals','input_sha256':pins,'results':rows},indent=2)+'\n')
