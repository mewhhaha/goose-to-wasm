# Batch 49 source review — 2026-11-07

Status: source-only plan, not candidate approval or executable qualification. Batch 48 and all earlier evidence remain untouched. Eight supplementary controls and their expected outputs were saved before execution in controls.json / expected-before-execution.json. Prior 48 and owner 49 v1 controls remain pinned unchanged in source-pins.json.

## Multi-assignment: one ordinary-assignment contract

Primary parser.h1931–1964 lowers `a, b = f();` to a scoped hidden multi-binding followed by ordinary assignments: `{ let result#1, result#2 = f(); a = result#1; b = result#2; }`. This supplies an exact algorithm, not merely left-to-right writes:

1. Evaluate the call once, receiving every natural result into hidden storage.
2. Complete hidden binding of every result before evaluating any target. Fixed-size plain reference results decay to pointee copies (typecheck_flow.h2266–2283; codegen_calls.h75–87); preserving just their pointer is insufficient. Slices/optional references retain their view/reference meaning. Nonfixed plain references are not silently copied; CheckAssign2469–2477 rejects those hidden results. An owned nonfixed result is constructed into its eventual target by an explicit synthesized copy (2478–2483).
3. Evaluate target 1's place once, apply ordinary assignment to staged result 1, then evaluate target 2's place once and assign result 2. Do not precompute all target addresses, even after the call: the first store can change the second index.
4. Ordinary `=` writes through a plain reference, including a narrowed optional. An unnarrowed optional rejects. Rebinding/compound operators are unavailable in multi-assignment. Preserve the stored type and writable provenance: typecheck_flow.h2489–2538, PointeeWritable2649–2659 and PointeeAssign2664–2682. Apply ordinary assignment's reference layer; do not flatten nested references or remove const to make types fit.
5. Lvalue validation must allow first assignment of an uninitialized fixed local, reject repeat writes to let/const or readonly referents, retain construction-only varint/relative-width restrictions, and preserve lifetime replacement, shrink, held-destination and store effects.

Primary VarDecl::CgStmt808–830 creates all result locals, then EmitCallInto loads any decayed reference result into those locals before the later Assign statements. Assign::CgStmt832 onward evaluates/stabilizes a destination then emits its ordinary RHS/store. Thus neither C compiler argument order nor a collection of LHS addresses can substitute for the source sequence.

Recommended implementation shape: normalize multi-assignment once to the hidden multi-binding plus ordinary assignments, using existing synthetic-node/name helpers and a private result marker for nonfixed result rules. This can retire the three independent special cases. Preserve next/scope/reachability/checked state and make repeated checking of loop bodies idempotent. If retaining N_MULTI_ASSIGN, implement exactly the same staged contract and reuse ordinary qualifier/lifetime helpers; a checker-only acceptance patch is not sufficient.

Canonical47 consumer defects/pitfalls:

- checker.goose5806–5820 compares target storage type directly to component type and checks targets as reads; it misses plain-reference assignment and uninitialized-target semantics.
- checker_lifetimes.goose1864–1872 stores into `place.place` rather than following ordinary N_ASSIGN's pointee/ref destination, replacement/shrink, hold, receive/copy and through-reference store logic. Reuse the ordinary path.
- codegen.goose3618–3631 computes every target address before evaluating the RHS and allocates raw result locals from target types. Use natural call component types for capture, then convert/snapshot every hidden binding before targets.
- Shared Wasm multi-binding code at1544–1584 also lacks natural tuple component-to-binding conversion; normalization alone does not cure fixed reference results. Both region and nonregion multi-binding routes need qualification with identical controls.
- codegen_c.goose1969–1989 runs RHS first, but extracts a tuple part only after evaluating that target and does not adapt its natural type before store. It also calls cc_place and then cc_expr for a reference target. Ordinary cc_assignment has the same duplicate-evaluation pattern; repair the shared destination resolution rather than transplanting it unchanged. cc_place_location's index path executes its index, so this is observable.
- Native cc_declaration already adapts natural tuple component to binding type through cc_convert(..., clone=true), before following statements; keep that complete staging behavior.

Minimal gates: the unchanged whole original multi_assign source/output at O0/O2 on native C, V8 and Wasmtime; original invalid count/reference cases; the immutable previous controls plus new six sequencing/staging cases; single-reference indexed assignment preservation if shared target resolution changes; optional narrowed/unnarrowed and readonly controls; own-source and repeated-loop checks. Count at most two original runtime rows recovered from multi_assign, regardless of supplementary control count. Existing refusals/mismatches remain failures until their original unchanged complete program succeeds.

## Plain loaded owned types

Primary LoadType at typecheck_types.h702–714 decodes varint to i64, strips only the top const qualifier from owned values, and normalizes relative reference storage while retaining reference qualifier/optional identity. Ident::Check84–109 uses the plain loaded type while preserving the original storage's writable provenance. CheckVarDecl2194–2200 reapplies const only for explicit const bindings or readonly inferred references/slices. LoadedTypeEq718–735 uses the same conversion sequence without mutating source types.

Normalize loaded owned types at actual value-read boundaries (name, member, index, call result as appropriate), not in stored symbol/field records. The shared read helper alone is insufficient if other paths bypass it. Keep check_storage_type and readonly authority tied to original symbol/field/storage and provenance, including global names without a current local variable record. Do not erase nested qualifiers, convert a borrowed nonfixed value into an owned copy, or drop const from reference/slice views. Reference binding to encoded varint must retain storage identity until the binding decision; use the existing numeric-decay stage rather than forcing every storage read to i64 prematurely.

Owner controls already cover struct/array copies, nested/original const rejection, borrowed readonly authority, concrete/generic overload ranking, call-return copies and varint reference storage. New member/index controls verify that loaded copies are mutable while their original const storage remains unchanged. Preserve the unchanged complete const_global_folding fixture/output as the two-original-row gate. No claim that passing a narrow copy control recovers that whole original.

## Evidence discipline

No oracle or C++ execution. No production, primary or sealed source edits. No broad runs are needed for this source plan. All outputs were authored from the primary contract before candidate observation. If a control is invalidly authored, preserve it and issue a separately pinned correction with the source authority, rather than changing an expected value to match a candidate. Owner's untyped reference-array fixture must remain preserved: an unannotated array literal copies scalar referents, so the intended indexed-reference test belongs in a new version with an explicit `(i64&)[2]` annotation.
