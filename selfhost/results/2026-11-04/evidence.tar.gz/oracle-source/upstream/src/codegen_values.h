// Goose compiler — codegen's values (definitions of CodeGen members,
// codegen.h): locations (paths resolved to C lvalues or byte pointers, with
// their data stacks), loop-invariant array views, expression values, string
// literals, and the binary operators (§6.1, §4.5).
#pragma once

namespace goose {

// ------------------------------------------------------------------
// Locations: an assignable/addressable path resolved to either a typed C
// lvalue (val) or a byte pointer (bytes values, packed dynamic layouts).
// The root's data stack (and pool freelist) ride along for growth ops.

// Reference variables with reusable-pool provenance are represented as
// gs_pref so pool operations stay available through them (§5.4). This is
// a property of the VarDef (provenance), shared by caller and callee.
inline bool CodeGen::PrefVar(const VarDef *vd) {
    return vd->type && CarriesPool(vd->type) && vd->ref.reusable;
}

// Whether a value of type `have` needs a pointee load to serve as `want`:
// optimizer splices can leave a reference-typed tree in a slot whose checked
// type already decayed, and Dst::t says what the receiver wants.
inline bool CodeGen::NeedsDeref(TypeExpr *have, TypeExpr *want) {
    return have && want && IsPlainRef(have) && want->kind != TY_REF && want->kind != TY_VOID;
}

// The pointee of a fat reference `x` as a location.
inline CodeGen::Loc CodeGen::FatRefLoc(const string &x, TypeExpr *sub) {
    Loc lv;
    lv.t = sub;
    lv.stk = cat(x, ".stk");
    if (IsFrameObj(sub)) {
        lv.val = true;
        lv.s = cat("(*(", CT(sub), " *)", x, ".hdr)");
        lv.hdr = lv.s;
    } else {
        lv.s = cat(x, ".hdr->base");
        lv.lenlv = cat(x, ".hdr->len");
        lv.hdr = cat("(*", x, ".hdr)");
    }
    return lv;
}

inline CodeGen::Loc CodeGen::BytesLoc(const string &ptr, TypeExpr *t, const Loc &from) {
    Loc l;
    l.t = t;
    l.stk = from.stk;
    l.lenlv = from.lenlv;
    l.fl = from.fl;
    l.flstk = from.flstk;
    l.viaref = from.viaref || t->kind == TY_REF;
    if (IsFix(t)) {
        l.val = true;
        l.s = cat("(*(", CT(t), " *)(", ptr, "))");
    } else {
        l.val = false;
        l.s = ptr;
    }
    return l;
}

// The slot's own address and the offset it holds, for a relative
// reference loc. The stored offset is signed for the self-relative form
// and unsigned for the `in pool` one, despite both widths being spelled
// unsigned (§3.9); an int64 holds either.
inline void CodeGen::RelParts(const Loc &lv, string &faddr, string &off) {
    auto &r = *lv.t->ref;
    if (r.lenstorage == IS_VARINT) {
        assert(!lv.val);
        faddr = lv.s;
        off = cat(r.pool ? "gs_uleb_read(" : "gs_zig_read(", lv.s, ")");
    } else if (lv.val) {
        faddr = cat("((uint8_t *)&", lv.s, ")");
        off = cat("(int64_t)(", RelCT(lv.t), ")", lv.s);
    } else {
        faddr = lv.s;
        off = cat("(int64_t)*(", RelCT(lv.t), " *)(", lv.s, ")");
    }
}

// What a relative offset is measured from (§3.9): the offset field's own
// address, or, for an `in pool` reference, the pool's base biased by one
// so that a target at the base still encodes non-zero and 0 stays null.
inline string CodeGen::RelOrigin(TypeExpr *rt, const string &faddr) {
    if (!rt->ref->pool) return faddr;
    return cat("(", PoolBase(rt->ref->pool), " - 1)");
}

// The pointee of `p`, a plain pointer to a fixed-class value of type t, as a
// C lvalue. A reference's C type names a struct-like pointee by its forward
// typedef only (CT), which is all passing the pointer on needs; a member
// access, a load or a store through it needs the body, so this emits it.
inline string CodeGen::PointeeLv(const string &p, TypeExpr *t) {
    CT(t);
    return cat("(*", p, ")");
}

// Loads the value of a loc holding a (plain or relative) reference and
// steps to the pointee. Optional locs never get here (narrowing).
inline void CodeGen::DerefLoc(Loc &lv) {
    assert(lv.t->kind == TY_REF);
    if (lv.aliasof || lv.aliaspath) {
        auto nl = lv.aliaspath ? GenLoc(lv.aliaspath) : VarLoc(const_cast<VarDef *>(lv.aliasof));
        // Reads of the array come from the alias's view where it has one;
        // growth writes the header.
        if (!lv.hbase.empty() && !IsFrameObj(nl.t)) nl.s = lv.hbase;
        if (!lv.hlen.empty()) nl.hlen = lv.hlen;
        lv = nl;
        return;
    }
    auto &r = *lv.t->ref;
    if (r.lenstorage >= 0) {
        string faddr, off;
        RelParts(lv, faddr, off);
        auto p = T();
        L("uint8_t *", p, " = ", RelOrigin(lv.t, faddr), " + ", off, ";");
        auto nl = BytesLoc(p, r.sub, lv);
        lv = nl;
        return;
    }
    auto rv = lv.s;   // The lvalue text reads as the reference value.
    if (IsResz(r.sub) && IsFrameObj(r.sub)) {
        auto nl = FatRefLoc(rv, r.sub);
        nl.viaref = lv.viaref;
        lv = nl;
        return;
    }
    if (IsResz(r.sub)) {
        Loc nl;
        nl.t = r.sub;
        nl.val = false;
        nl.hdr = cat("(*", rv, ".hdr)");
        nl.s = lv.hbase.empty() ? cat(rv, ".hdr->base") : lv.hbase;
        // Growth writes the header even where the reads come from a hoist.
        nl.lenlv = cat(rv, ".hdr->len");
        nl.hlen = lv.hlen;
        nl.viaref = lv.viaref;
        nl.stk = cat(rv, ".stk");
        // A pool reference (gs_pref) has the same leading members plus the
        // freelist; keep the companions reachable for pool operations.
        nl.fl = lv.ispref ? cat("(*", rv, ".fl)") : lv.fl;
        nl.flstk = lv.ispref ? cat(rv, ".flstk") : lv.flstk;
        lv = nl;
        return;
    }
    if (IsBytesT(r.sub)) {
        Loc nl;
        nl.t = r.sub;
        nl.val = false;
        nl.s = rv;
        nl.hlen = lv.hlen;
        nl.viaref = lv.viaref;
        lv = nl;
        return;
    }
    Loc nl;
    nl.t = r.sub;
    nl.val = true;
    nl.s = PointeeLv(rv, r.sub);
    nl.hlen = lv.hlen;
    nl.viaref = lv.viaref;
    lv = nl;
}

// Resolves a location reached through a reference that can be rebound
// (Loc::viaref) to the addresses it names now, for code that runs before its
// later uses and may rebind that reference. A resizable is its header's
// address; a stack whose top this body caches keeps its name, being named by
// a binding nothing rebinds.
inline void CodeGen::PinLoc(Loc &lv) {
    if (lv.val) {
        auto p = T();
        L(CT(lv.t), " *", p, " = &(", lv.s, ");");
        lv.s = cat("(*", p, ")");
    } else if (!IsResz(lv.t)) {
        auto p = T();
        L("uint8_t *", p, " = ", lv.s, ";");
        lv.s = p;
    } else {
        assert(!lv.hdr.empty());
        auto h = T();
        L("gs_rhdr *", h, " = &(", lv.hdr, ");");
        lv.hdr = cat("(*", h, ")");
        lv.s = cat(h, "->base");
        lv.lenlv = cat(h, "->len");
    }
    if (!lv.stk.empty() && !CacheableStk(lv.stk)) {
        auto s = T();
        L("gs_stack *", s, " = ", lv.stk, ";");
        lv.stk = s;
    }
    lv.viaref = false;
}

inline CodeGen::Loc CodeGen::VarLoc(VarDef *vd) {
    Loc l;
    l.t = vd->type;
    if (auto ait = refalias.find(vd); ait != refalias.end()) {
        auto tg = const_cast<VarDef *>(ait->second);
        if (auto pit = aliaspath.find(vd); pit != aliaspath.end()) {
            auto tl = GenLoc(pit->second);
            l.val = true;
            l.s = cat("((gs_rref){ (gs_rhdr *)&", tl.hdr, ", ", tl.stk, " })");
            l.aliaspath = pit->second;
        } else if (tg->type->kind == TY_REF) {
            l = VarLoc(tg);
        } else {
            // The reference value is made where one is needed; its pointee
            // is the variable's own location (DerefLoc).
            l.val = true;
            l.s = cat("((gs_rref){ (gs_rhdr *)&", HdrLv(tg), ", ", VStkOf(tg), " })");
            l.aliasof = tg;
        }
        // A view is the alias's own, hoisted for the loops BCE judged this
        // spelling in; one of the target's is not taken over.
        l.t = vd->type;
        l.hbase.clear();
        l.hlen.clear();
        if (auto hit = views.find(vd); hit != views.end()) {
            l.hbase = hit->second.first;
            l.hlen = hit->second.second;
        }
        return l;
    }
    auto name = VName(vd);
    if (auto hit = views.find(vd); hit != views.end()) {
        l.hbase = hit->second.first;
        l.hlen = hit->second.second;
    }
    if (vd->reusable) {
        // A reusable pool: locals/globals have gs_rhdr companions; a
        // captured pool arrives as a gs_pref.
        auto pit = vpool.find(vd);
        auto git = gpools.find(vd);
        if (pit != vpool.end() || git != gpools.end()) {
            auto &p = pit != vpool.end() ? pit->second : git->second;
            auto hdr = fvptr.count(vd) ? cat("(*", name, ")") : name;
            l.val = false;
            l.hdr = hdr;
            l.s = PoolBaseOr(vd, cat(hdr, ".base"));
            l.lenlv = cat(hdr, ".len");
            l.stk = VStkOf(vd);
            l.fl = p.first;
            l.flstk = p.second;
        } else {
            l.val = false;
            l.hdr = cat("(*", name, ".hdr)");
            l.s = cat(name, ".hdr->base");
            l.lenlv = cat(name, ".hdr->len");
            l.stk = cat(name, ".stk");
            l.fl = cat("(*", name, ".fl)");
            l.flstk = cat(name, ".flstk");
        }
        return l;
    }
    if (IsResz(vd->type)) {
        // A gs_rhdr or frame object in the frame (or a pointer to one,
        // when captured).
        auto hdr = fvptr.count(vd) ? cat("(*", name, ")") : name;
        l.hdr = hdr;
        l.stk = VStkOf(vd);
        if (IsFrameObj(vd->type)) {
            l.val = true;
            l.s = hdr;
            return l;
        }
        l.val = false;
        l.s = PoolBaseOr(vd, cat(hdr, ".base"));
        l.lenlv = cat(hdr, ".len");
        return l;
    }
    if (IsBytesT(vd->type)) {
        l.val = false;
        l.s = name;
        l.stk = VStkOf(vd);
        return l;
    }
    l.val = true;
    l.s = fvptr.count(vd) ? cat("(*", name, ")") : name;
    l.viaref = vd->isvar && vd->type->kind == TY_REF;
    if (PrefVar(vd)) {
        l.ispref = true;
        l.fl = cat("(*", l.s, ".fl)");
        l.flstk = cat(l.s, ".flstk");
    }
    return l;
}

// The gs_rhdr lvalue of a resizable variable (frame header form, C.2).
inline string CodeGen::HdrLv(VarDef *vd) {
    auto name = VName(vd);
    return fvptr.count(vd) ? cat("(*", name, ")") : name;
}

// The C type a variable's storage uses (gs_pref for pool references).
inline string CodeGen::VarCT(const VarDef *vd) {
    if (PrefVar(vd)) { EmitCoreTypes(); return "gs_pref"; }
    return CT(vd->type);
}

// The data stack a nonfixed variable's value lives on, if known here.
inline string CodeGen::VStkOf(const VarDef *vd) {
    auto it = vstk.find(vd);
    if (it != vstk.end()) return it->second;
    auto git = gstks.find(vd);
    if (git != gstks.end()) return git->second;
    return "";
}

// A byte-pointer expression for field `fieldidx` within the bytes value at
// `base` (fields/ftypes from a struct instance or a variant), grouped as one
// operand for the casts and dereferences applied to it. Emits cursor
// statements when a dynamic-size field precedes the target.
inline string CodeGen::FieldPtr(const string &base, const vector<Field> &fields,
                                const vector<TypeExpr *> &ftypes, int fieldidx) {
    int64_t off = 0;
    string cur;   // Cursor variable once dynamic fields intervene.
    for (auto i = 0; i < fieldidx; i++) {
        auto &f = fields[i];
        if (f.ispad) { off += f.padsize > 0 ? f.padsize : 0; continue; }
        if (IsFix(ftypes[i])) { off += FixedSize(ftypes[i]); continue; }
        if (cur.empty()) {
            cur = T();
            L("uint8_t *", cur, " = ", base, " + ", off, ";");
        } else if (off) {
            L(cur, " += ", off, ";");
        }
        off = 0;
        L(cur, " += ", SizeX(ftypes[i], cur), ";");
    }
    if (cur.empty()) return off ? cat("(", base, " + ", off, ")") : base;
    return off ? cat("(", cur, " + ", off, ")") : cur;
}

// Reads of the length come from a loop-hoisted local where there is one;
// `lenlv`, which the operations that change the length write, does not.
inline CodeGen::ArrView CodeGen::ArrayView(const Loc &lv) {
    auto v = RawArrayView(lv);
    if (!lv.hlen.empty()) v.len = lv.hlen;
    return v;
}

inline CodeGen::ArrView CodeGen::RawArrayView(const Loc &lv) {
    auto t = lv.t;
    ArrView v;
    if (t->kind == TY_SLICE) {
        v.elem = t->sub;
        v.elems = cat(lv.s, ".data");
        v.len = cat(lv.s, ".len");
        v.typedelems = !IsBytesT(t->sub);
        return v;
    }
    assert(t->kind == TY_ARRAY);
    auto &a = *t->arr;
    v.elem = a.sub;
    switch (a.akind) {
        case A_FIXED:
            assert(lv.val);
            v.elems = cat(lv.s, ".e");
            v.len = cat(ArrSize(t->arr));
            v.typedelems = true;
            return v;
        case A_LIMITED:
            if (lv.val) {
                v.elems = cat(lv.s, ".e");
                v.len = cat("(int64_t)", lv.s, ".len");
                v.lenlv = cat(lv.s, ".len");
                v.typedelems = true;
            } else {
                v.elems = cat("((", lv.s, ") + 8)");
                v.len = cat("(int64_t)*(uint32_t *)((", lv.s, ") + 4)");
                v.lenlv = cat("(*(uint32_t *)((", lv.s, ") + 4))");
            }
            return v;
        case A_VAR: {
            assert(!lv.val);
            auto ls = LenStore(t->arr);
            if (ls == IS_VARINT) {
                // Sequential unless elements are fixed; length prefix is
                // dynamic, so materialize both once.
                auto p = T();
                L("uint8_t *", p, " = (", lv.s, ") + GS_ULEB_SIZE(", lv.s, ");");
                v.elems = p;
                v.len = cat("GS_ULEB_READ(", lv.s, ")");
            } else {
                v.elems = cat("((", lv.s, ") + ", IntSize(ls), ")");
                v.len = cat("(int64_t)*(", IntCT(ls), " *)(", lv.s, ")");
            }
            return v;
        }
        default:   // Grow / grow-shrink: elements at base, length in the header.
            assert(!lv.val && !lv.lenlv.empty());
            v.elems = cat("(", lv.s, ")");
            v.len = cat("(", lv.lenlv, ")");
            v.lenlv = lv.lenlv;
            return v;
    }
}

inline bool CodeGen::AddView(VarDef *vd) {
    auto t = vd->type;
    if (views.count(vd) || !t || t->kind != TY_REF) return false;
    if (t->ref->optional || t->ref->lenstorage >= 0) return false;
    auto s = t->ref->sub;
    if (s->kind != TY_ARRAY || s->arr->akind == A_FIXED) return false;
    // A varint length prefix is not a plain load: its view emits statements.
    if (s->arr->akind == A_VAR && LenStore(s->arr) == IS_VARINT) return false;
    // Not named yet means bound inside the loop (a for/match binder, or a
    // declaration the body repeats), which has no view to read out here. An
    // alias is never named; its binding has been passed once it is bound.
    if (!vnames.count(vd) && !gnames.count(vd) && !aliasbound.count(vd)) return false;
    auto lv = VarLoc(vd);
    DerefLoc(lv);
    auto v = ArrayView(lv);
    // Only a fat reference keeps the elements pointer in memory too; the
    // other forms reach them by offsetting the reference itself.
    string nb;
    if (IsResz(s)) {
        nb = T();
        L("uint8_t *", nb, " = ", v.elems, ";");
    }
    auto nl = T();
    L("int64_t ", nl, " = ", v.len, ";");
    views[vd] = { nb, nl };
    return true;
}

// The variable a field path's root names the storage of: an alias stands
// for its target, which every spelling of the path shares.
inline const VarDef *CodeGen::FieldRoot(const VarDef *vd) {
    for (auto guard = 0; guard < 16; guard++) {
        auto it = refalias.find(vd);
        if (it == refalias.end() || aliaspath.count(vd)) break;
        vd = it->second;
    }
    return vd;
}

// Reads the view of a grow-only or grow-shrink array held in a field into
// locals ahead of a loop (`hoistfields`), as AddView does for a reference.
inline bool CodeGen::AddFieldView(const FieldPath &fp) {
    auto vd = const_cast<VarDef *>(FieldRoot(fp.first));
    auto key = pair<const VarDef *, vector<int>>(vd, fp.second);
    auto t = vd->type;
    if (fieldviews.count(key) || !t || fp.second.empty()) return false;
    if (t->kind == TY_REF && (t->ref->optional || t->ref->lenstorage >= 0)) return false;
    // Bound inside the loop: no view to read out here (see AddView).
    if (!vnames.count(vd) && !gnames.count(vd) && !aliasbound.count(vd)) return false;
    auto lv = VarLoc(vd);
    if (lv.t->kind == TY_REF) DerefLoc(lv);
    for (auto f : fp.second) {
        if (lv.t->kind != TY_STRUCT || !lv.val) return false;
        lv = FieldLocAt(lv, f);
    }
    if (lv.t->kind != TY_ARRAY || !IsResz(lv.t) || IsFrameObj(lv.t) || lv.lenlv.empty())
        return false;
    auto v = RawArrayView(lv);
    auto nb = T(), nl = T();
    L("uint8_t *", nb, " = ", v.elems, ";");
    L("int64_t ", nl, " = ", v.len, ";");
    fieldviews[key] = { nb, nl };
    return true;
}

// A field array whose view a loop around this code read out (fieldviews)
// is read from there; growth still writes the header.
inline void CodeGen::UseFieldView(Dot *d, Loc &lv) {
    if (lv.lenlv.empty() || lv.t->kind != TY_ARRAY || !IsResz(lv.t) || IsFrameObj(lv.t)) return;
    vector<int> path;
    Node *cur = d;
    while (auto dd = Is<Dot>(cur)) {
        if (!dd->IsField()) return;
        path.push_back(dd->fieldidx);
        cur = dd->obj;
    }
    auto id = Is<Ident>(cur);
    if (!id || !id->vdef) return;
    std::reverse(path.begin(), path.end());
    auto hit = fieldviews.find({ FieldRoot(id->vdef), path });
    if (hit == fieldviews.end()) return;
    lv.s = hit->second.first;
    lv.hlen = hit->second.second;
}

// Large fixed values keep their ordinary packed C type, but their storage
// is a data-stack slot (LargeFixedOnStack). Pointer locals cannot be hoisted
// into a huge native frame by HoistAggregateDecls or by a C compiler's
// inliner. Reuse follows the existing scope watermarks, including
// break/continue/return-from.
inline void CodeGen::FixedLocal(TypeExpr *t, string &name, const string &init, bool forlocal) {
    if (!LargeFixedOnStack(t)) {
        L(CT(t), " ", name, init.empty() ? ";" : cat(" = ", init, ";"));
        return;
    }
    auto stk = AllocStk(forlocal);
    L(CT(t), " *", name, " = (", CT(t), " *)", Top(stk), ";");
    SaveBase(forlocal, stk, cat("(uint8_t *)", name));
    Bump(stk, cat("sizeof(", CT(t), ")"));
    name = cat("(*", name, ")");
    if (init == "{0}") L("GS_MEMZERO(&", name, ", sizeof(", name, "));");
    else if (!init.empty()) L(name, " = ", init, ";");
}

// Materialize a read now, before a later operand can mutate its storage.
// A bare C variable is side-effect-free but is not an evaluated value.
inline string CodeGen::Snapshot(TypeExpr *vt, const string &x) {
    auto t = T();
    FixedLocal(vt, t, x);
    return t;
}

inline string CodeGen::GenPure(Node *n) {
    if (Is<IntLit>(n) || Is<FltLit>(n) || Is<BoolLit>(n)) return GenX(n);
    return Snapshot(n->exprtype, GenX(n));
}

// An integer `/` or `%` at storage s, through runtime.h's gs_div_/gs_mod_
// macros. Those name their operands more than once, so an operand that is
// not already a C name or a number is read into a temp first; a signed `%`
// also gets the temp it keeps the remainder in.
inline string CodeGen::DivX(bool div, IntStorage s, const string &l, const string &r,
                            Line line) {
    auto pure = [&](const string &x) {
        auto core = x;
        while (core.size() > 2 && core.front() == '(' && core.back() == ')' &&
               core.find_first_of("()", 1) == core.size() - 1)
            core = core.substr(1, core.size() - 2);
        auto name = !core.empty() && !isdigit((uint8_t)core[0]);
        auto num = !core.empty() && isdigit((uint8_t)core[0]);
        for (auto ch : core) {
            if (!isalnum((uint8_t)ch) && ch != '_') name = false;
            if (!isdigit((uint8_t)ch) && !strchr("uUlL", ch)) num = false;
        }
        if (name || num) return core;
        auto t = T();
        L(IntCT(s), " ", t, " = ", x, ";");
        return t;
    };
    auto a = pure(l), b = pure(r);
    if (div) return cat("gs_div_", IntSfx(s), "(", a, ", ", b, ", ", LocArgs(line), ")");
    if (IsUnsigned(s)) return cat("gs_mod_", IntSfx(s), "(", a, ", ", b, ", ", LocArgs(line), ")");
    auto t = T();
    L("int64_t ", t, ";");
    return cat("gs_mod_", IntSfx(s), "(", t, ", ", a, ", ", b, ", ", LocArgs(line), ")");
}

// Scalar `l op r` at type t, an integer or a float type: the one table of
// arithmetic, bitwise and shift operators that binary operators, compound
// assignments (whose operator stands for its plain one), `++` and `--`, and
// the members of elementwise operations share. A call takes l and r as they
// are, converted by its parameters; an infix operator takes lx and rx, by
// default l and r cast to t, which realizes the implicit widening of
// operands the typechecker unified without converting them. `nonneg`: a
// signed `/`, `%` or `>>` computed unsigned (Binary::nonneg).
inline string CodeGen::ArithX(TType op, TypeExpr *t, const string &l, const string &r, Line line,
                              bool nonneg, string lx, string rx) {
    assert(t->kind == TY_FLT || (t->kind == TY_INT && t->intstorage != IS_VARINT));
    switch (op) {
        case T_PLUSEQ:  op = T_PLUS;   break;
        case T_MINUSEQ: op = T_MINUS;  break;
        case T_MULEQ:   op = T_MUL;    break;
        case T_DIVEQ:   op = T_DIV;    break;
        case T_MODEQ:   op = T_MOD;    break;
        case T_ANDEQ:   op = T_BITAND; break;
        case T_OREQ:    op = T_BITOR;  break;
        case T_XOREQ:   op = T_XOR;    break;
        case T_SHLEQ:   op = T_SHL;    break;
        case T_SHREQ:   op = T_SHR;    break;
        default: break;
    }
    auto ct = CT(t);
    if (lx.empty()) lx = cat("(", ct, ")(", l, ")");
    if (rx.empty()) rx = cat("(", ct, ")(", r, ")");
    if (t->kind == TY_FLT) {
        switch (op) {
            case T_PLUS:  return cat("(", lx, " + ", rx, ")");
            case T_MINUS: return cat("(", lx, " - ", rx, ")");
            case T_MUL:   return cat("(", lx, " * ", rx, ")");
            case T_DIV:   return cat("(", lx, " / ", rx, ")");
            case T_MOD:
                return cat(t->fltstorage == FS_F32 ? "fmodf(" : "fmod(", lx, ", ", rx, ")");
            default: assert(false); return l;
        }
    }
    auto s = t->intstorage;
    auto sfx = IntSfx(s);
    switch (op) {
        case T_PLUS:  return cat("gs_add_", sfx, "(", l, ", ", r, OvfLocArgs(s, line), ")");
        case T_MINUS: return cat("gs_sub_", sfx, "(", l, ", ", r, OvfLocArgs(s, line), ")");
        case T_MUL:   return cat("gs_mul_", sfx, "(", l, ", ", r, OvfLocArgs(s, line), ")");
        case T_DIV: case T_MOD:
            if (!nonneg) return DivX(op == T_DIV, s, l, r, line);
            return cat("(", ct, ")((uint64_t)(", lx, op == T_DIV ? ") / " : ") % ", "(uint64_t)(",
                       rx, "))");
        case T_BITAND: return cat("(", ct, ")(", lx, " & ", rx, ")");
        case T_BITOR:  return cat("(", ct, ")(", lx, " | ", rx, ")");
        case T_XOR:    return cat("(", ct, ")(", lx, " ^ ", rx, ")");
        case T_SHL:    return cat("gs_shl_", sfx, "(", l, ", (int64_t)(", r, "))");
        case T_SHR:
            if (!nonneg) return cat("gs_shr_", sfx, "(", l, ", (int64_t)(", r, "))");
            return cat("(", ct, ")((uint64_t)(", lx, ") >> ((int64_t)(", r, ") & ", IntBits(s) - 1,
                       "))");
        default: assert(false); return l;
    }
}

// The two minima are written as a subtraction: C has no negative decimal
// constants, and MSVC's C front end types both magnitudes as unsigned
// (C90 literal rules), which the negation would carry through.
inline string CodeGen::IntStr(int64_t v) {
    if (v == INT64_MIN) return "(-9223372036854775807LL - 1)";
    if (v == INT32_MIN) return "(-2147483647 - 1)";
    if (v > INT32_MAX || v < INT32_MIN) return cat(v, "LL");
    return cat(v);
}

inline string CodeGen::FltStr(double v, bool f32) {
    // A folded NaN or infinity has no literal spelling; math.h's macros.
    if (v != v) return "NAN";
    if (std::isinf(v)) return v > 0 ? "INFINITY" : "(-INFINITY)";
    // An f32 constant from halfway between FLT_MAX and 2^128 up rounds to an
    // infinity (§6.3), which C compilers reject as a literal or warn about.
    if (f32 && std::fabs(v) >= std::ldexp(2.0 - std::ldexp(1.0, -24), 127))
        return v > 0 ? "INFINITY" : "(-INFINITY)";
    string s;
    CatOne(s, v);
    if (f32) s += "f";
    return s;
}

// Indexed element location with bounds check (elided when the BCE pass
// proved it redundant, or for provably in-range constant indices into
// fixed arrays).
inline CodeGen::Loc CodeGen::IndexLoc(Loc lv, Node *idxnode, Line ln, bool nobc) {
    if (lv.t->kind == TY_REF) DerefLoc(lv);
    auto v = ArrayView(lv);
    if (HasStmts(idxnode)) {
        auto elems = T(), len = T();
        L(v.typedelems ? CT(v.elem) : string("uint8_t"), " *", elems, " = ", v.elems, ";");
        L("int64_t ", len, " = ", v.len, ";");
        v.elems = elems;
        v.len = len;
    }
    auto idx = GenPure(idxnode);
    if (lv.t->kind == TY_SLICE) {
        // MSVC /O2 can discard stores through a copied slice header while
        // retaining earlier values in its fixed-array owner (typecheck's
        // slices() exercises this after Goose inlining). Loading the base
        // into a scalar pointer avoids that aggregate-alias miscompilation;
        // native optimizers still hoist it when the slice is loop-invariant.
        auto p = T();
        L(IsBytesT(v.elem) ? "uint8_t" : CT(v.elem), " *", p, " = ", v.elems, ";");
        v.elems = p;
    }
    string ix;
    auto il = Is<IntLit>(idxnode);
    auto statlen = lv.t->kind == TY_ARRAY && lv.t->arr->akind == A_FIXED
                       ? ArrSize(lv.t->arr) : -1;
    if (nobc || (il && statlen >= 0 && il->val >= 0 && il->val < statlen)) ix = idx;
    else ix = cat("GS_IDX((int64_t)(", idx, "), ", v.len, ", ", LocArgs(ln), ")");
    if (v.typedelems) {
        Loc r;
        r.t = v.elem;
        r.val = true;
        r.s = cat(v.elems, "[", ix, "]");
        r.stk = lv.stk;
        r.fl = lv.fl;
        r.flstk = lv.flstk;
        r.viaref = lv.viaref || v.elem->kind == TY_REF;
        return r;
    }
    assert(IsFix(v.elem));   // Variable elements are never indexed (TC).
    // A number of 2, 4 or 8 bytes is indexed through a pointer to its type,
    // which keeps the index scaled in the address. As a byte offset the C
    // compiler folds the scale into the index's own shift (`(j >> 5) * 4`
    // becomes `(j >> 3) & -4`) and loses the scaled addressing mode.
    auto esz = FixedSize(v.elem);
    if ((v.elem->kind == TY_INT || v.elem->kind == TY_FLT) && (esz == 2 || esz == 4 || esz == 8)) {
        auto r = BytesLoc(v.elems, v.elem, lv);
        r.s = cat("(((", CT(v.elem), " *)(", v.elems, "))[", ix, "])");
        return r;
    }
    return BytesLoc(cat("(", v.elems, " + ", ix, " * ", esz, ")"), v.elem, lv);
}

// A path whose address takes no check and calls nothing: a variable, or a
// field of one, through references too.
static bool CheckFreePath(Node *n) {
    if (auto id = Is<Ident>(n)) return id->vdef != nullptr;
    if (auto d = Is<Dot>(n)) return d->IsField() && CheckFreePath(d->obj);
    return false;
}

// Two check-free paths, or integer constants, that denote the same thing.
inline bool CodeGen::SamePath(Node *a, Node *b) {
    if (auto ia = Is<Ident>(a)) {
        auto ib = Is<Ident>(b);
        return ib && ia->vdef && ia->vdef == ib->vdef;
    }
    if (auto la = Is<IntLit>(a)) {
        auto lb = Is<IntLit>(b);
        return lb && la->val == lb->val;
    }
    auto da = Is<Dot>(a), db = Is<Dot>(b);
    return da && db && da->IsField() && db->IsField() && da->fieldidx == db->fieldidx &&
           TEq(da->obj->exprtype, db->obj->exprtype) && SamePath(da->obj, db->obj);
}

// The Index whose bounds check is the first thing `arm` does: its first
// statement assigns to a path through an element of an array named by a
// check-free path, at an index held in a variable or a constant. Null
// otherwise, and where there is no check: elided already, or a constant
// within a fixed array (IndexLoc).
inline Index *CodeGen::LeadingCheck(Node *arm) {
    auto b = Is<Block>(arm);
    if (!b || b->stmts.empty()) return nullptr;
    auto a = Is<Assign>(b->stmts[0]);
    if (!a) return nullptr;
    auto p = a->lval;
    while (auto d = Is<Dot>(p)) {
        if (!d->IsField()) return nullptr;
        p = d->obj;
    }
    auto ix = Is<Index>(p);
    if (!ix || ix->nobc || fillvalues.count(ix) || !CheckFreePath(ix->obj)) return nullptr;
    if (auto iv = Is<Ident>(ix->idx)) return iv->vdef ? ix : nullptr;
    auto il = Is<IntLit>(ix->idx);
    auto at = ix->obj->exprtype;
    if (at && at->kind == TY_REF) at = at->ref->sub;
    if (!il || !at || (at->kind == TY_ARRAY && at->arr->akind == A_FIXED)) return nullptr;
    return ix;
}

// Whether two leading checks test the same index against the same array.
inline bool CodeGen::SameCheck(Index *a, Index *b) {
    return SamePath(a->obj, b->obj) && SamePath(a->idx, b->idx) &&
           TEq(a->obj->exprtype, b->obj->exprtype);
}

// The check both arms of an if start with (LeadingCheck), emitted once
// ahead of the branch on condition `c`: it fails where either arm's would,
// and reports the location of the arm `c` selects.
inline void CodeGen::EmitHoistedCheck(Index *ta, Index *ea, const string &c) {
    auto lv = GenLoc(ta->obj);
    while (lv.t->kind == TY_REF) DerefLoc(lv);
    auto v = ArrayView(lv);
    auto idx = GenPure(ta->idx);
    auto tl = ta->line, el = ea->line;
    auto file = tl.fileidx == el.fileidx
                    ? FileRef(tl) : cat("(", c, ") ? ", FileRef(tl), " : ", FileRef(el));
    auto line = tl.line == el.line ? cat(tl.line) : cat("(", c, ") ? ", tl.line, " : ", el.line);
    L("(void)GS_IDX((int64_t)(", idx, "), ", v.len, ", ", file, ", ", line, ");");
}

inline CodeGen::Loc CodeGen::GenLoc(Node *n) {
    if (auto it = fillvalues.find(n); it != fillvalues.end()) return it->second;
    if (auto id = Is<Ident>(n)) {
        assert(id->vdef);
        return VarLoc(id->vdef);
    }
    // A payload-less variant constant or a property (.len, .cap) is a value,
    // not a path: it is built on a temporary below like the other rvalues.
    if (auto d = Is<Dot>(n); d && d->IsField()) {
        auto lv = GenLoc(d->obj);
        if (lv.t->kind == TY_REF) DerefLoc(lv);
        auto ml = MemberLoc(lv, d);
        if (!fieldviews.empty()) UseFieldView(d, ml);
        return ml;
    }
    if (auto ix = Is<Index>(n)) {
        auto lv = GenLoc(ix->obj);
        if (lv.t->kind == TY_REF) DerefLoc(lv);
        return IndexLoc(lv, ix->idx, ix->line, ix->nobc);
    }
    // `&path` addressed as a location is the path itself: going through a
    // reference temporary would spell the value's stack a second way,
    // behind the top the function may be keeping in a local (see the
    // note on data-stack top caching).
    if (auto u = Is<Unary>(n); u && u->op == T_BITAND &&
        (Is<Ident>(u->child) || Is<Dot>(u->child) || Is<Index>(u->child)) &&
        u->child->exprtype && u->child->exprtype->kind != TY_REF)
        return GenLoc(u->child);
    // Any other expression: an addressed temporary (TC's LValueBase).
    Loc l;
    l.t = n->exprtype;
    if (IsResz(n->exprtype)) return GenRzTmp(n);
    if (IsBytesT(n->exprtype)) {
        string stk;
        l.s = GenPtr(n, &stk);
        l.stk = stk;
        l.val = false;
    } else {
        auto t = T();
        FixedLocal(n->exprtype, t, GenX(n));
        l.s = t;
        l.val = true;
    }
    return l;
}

// Whether a destination's C lvalue names the same storage wherever in its
// statement it is evaluated: a variable, or a field of a fixed-size value
// or an element of a fixed-size array down from one, at an index that takes
// no check, which IndexLoc holds in a temporary (and no reference that can
// be rebound, which the caller sees as Loc::viaref). An assignment stores
// to such a destination as it is spelled, a member store the C compiler's
// type-based alias analysis tells apart from other structs' fields, where
// a store through a pointer taken first is to any value of the field's type.
// Spelled like the destination's loads, it is also one location to gcc's
// loop invariant motion, which keeps an element a loop reads and writes in
// a register (and so lets the loop vectorize) only then.
inline bool CodeGen::StableDest(Node *n) {
    auto fixed = [&](TypeExpr *t) {
        if (t && t->kind == TY_REF) {
            if (t->ref->lenstorage >= 0) return (TypeExpr *)nullptr;
            t = t->ref->sub;
        }
        return t && IsFix(t) ? t : nullptr;
    };
    for (;;) {
        if (auto d = Is<Dot>(n)) {
            if (!d->IsField() || !fixed(d->obj->exprtype)) return false;
            n = d->obj;
        } else if (auto ix = Is<Index>(n)) {
            auto at = fixed(ix->obj->exprtype);
            if (!at || at->kind != TY_ARRAY || at->arr->akind != A_FIXED || fillvalues.count(ix))
                return false;
            auto il = Is<IntLit>(ix->idx);
            if (!ix->nobc && !(il && il->val >= 0 && il->val < ArrSize(at->arr))) return false;
            n = ix->obj;
        } else {
            return Is<Ident>(n) != nullptr;
        }
    }
}

// A fresh statement-scoped stack for a bytes-class temporary, returned in
// `stk`; the value's base (also the watermark to restore) is the result.
inline string CodeGen::BytesTemp(string &stk) {
    stk = AllocStk(false);
    auto base = T();
    L("uint8_t *", base, " = ", Top(stk), ";");
    SaveBase(false, stk, base);
    return base;
}

// A fresh header -- or frame object -- for a resizable value of type t,
// named by the result, on a fresh statement-scoped stack returned in
// `stk`; the elements are built there next.
inline string CodeGen::RzTemp(TypeExpr *t, string &stk) {
    EmitCoreTypes();
    stk = AllocStk(false);
    auto h = T();
    if (IsFrameObj(t)) {
        L(CT(t), " ", h, ";");
        SaveBase(false, stk, cat(FoTailHdr(t, h), ".base"));
    } else {
        L("gs_rhdr ", h, " = { ", Top(stk), ", 0 };");
        SaveBase(false, stk, cat(h, ".base"));
    }
    return h;
}

// What a construction of type t behind header h writes its count to: the
// whole frame object, or the header's count.
inline string CodeGen::RzLenLv(TypeExpr *t, const string &h) {
    return IsFrameObj(t) ? h : cat(h, ".len");
}

// The value behind such a header as a location.
inline CodeGen::Loc CodeGen::RzTempLoc(TypeExpr *t, const string &h, const string &stk) {
    Loc l;
    l.t = t;
    l.stk = stk;
    l.hdr = h;
    if (IsFrameObj(t)) {
        l.val = true;
        l.s = h;
    } else {
        l.s = cat(h, ".base");
        l.lenlv = cat(h, ".len");
    }
    return l;
}

// A resizable-valued temporary (a call or control result): elements on a
// fresh statement-scoped stack, header in a temp.
inline CodeGen::Loc CodeGen::GenRzTmp(Node *n) {
    auto t = n->exprtype;
    string stk;
    auto h = RzTemp(t, stk);
    GenAny(n, Dst { DK_STACK, stk, t, RzLenLv(t, h) });
    return RzTempLoc(t, h, stk);
}

inline CodeGen::Loc CodeGen::MemberLoc(Loc lv, Dot *d) {
    assert(d->fieldidx >= 0);
    return FieldLocAt(lv, d->fieldidx);
}

inline CodeGen::Loc CodeGen::FieldLocAt(Loc lv, int fieldidx) {
    if (lv.t->kind == TY_STRUCT) {
        auto si = SI(lv.t);
        auto ft = si->ftypes[fieldidx];
        if (lv.val) {
            Loc r = lv;
            r.t = ft;
            r.s = cat(lv.s, ".", Sanitize(si->st->fields[fieldidx].name));
            r.viaref = lv.viaref || ft->kind == TY_REF;
            r.hbase.clear();
            r.hlen.clear();
            r.lenlv.clear();
            if (IsResz(ft)) {
                // A frame object's tail: its own header (or a nested
                // frame object) is the member.
                r.hdr = r.s;
                if (!IsFrameObj(ft)) {
                    r.val = false;
                    r.lenlv = cat(r.s, ".len");
                    r.s = cat(r.s, ".base");
                }
            }
            return r;
        }
        return BytesLoc(FieldPtr(lv.s, si->st->fields, si->ftypes, fieldidx), ft, lv);
    }
    if (lv.t->kind != TY_VARIANT)
        Fail(Line {}, cat("internal: field of a non-struct location of type ", Mangle(lv.t)));
    auto ei = EIVar(lv.t);
    auto vi = ei->en->VariantIndex(lv.t->var->variant);
    auto ft = ei->vftypes[vi][fieldidx];
    if (lv.val) {
        Loc r = lv;
        r.t = ft;
        r.s = cat(lv.s, ".", Sanitize(ei->en->variants[vi].fields[fieldidx].name));
        r.viaref = lv.viaref || ft->kind == TY_REF;
        return r;
    }
    return BytesLoc(FieldPtr(lv.s, ei->en->variants[vi].fields, ei->vftypes[vi],
                             fieldidx), ft, lv);
}

// ------------------------------------------------------------------
// Expression values. GenX produces a C expression for fixed-class values
// (possibly after emitting statements); GenPtr produces a byte pointer to
// a bytes-class value. Both follow the node's checked exprtype, which
// already encodes operand unification and reference decay.

inline bool CodeGen::IsCtl(Node *n) {
    return Is<IfExpr>(n) || Is<MatchExpr>(n) || Is<Block>(n) || Is<EarlyBlock>(n) ||
           Is<LoopExpr>(n) || Is<InlineBlock>(n);
}

// The value of a location, as the given expression type expects: storage
// widening is implicit in C, varints decode, relative references load,
// and a reference loc decays to its pointee when the exprtype says so.
inline string CodeGen::LoadLoc(Loc lv, TypeExpr *et, Line ln) {
    if (lv.t->kind == TY_REF && et->kind != TY_REF) {
        DerefLoc(lv);
        return LoadLoc(lv, et, ln);
    }
    if (IsRelRef(lv.t)) {
        // Relative reference load: an ordinary (possibly fat) reference;
        // a zero offset is the null of the optional form (§3.9).
        auto &r = *lv.t->ref;
        string faddr, off;
        RelParts(lv, faddr, off);
        auto org = RelOrigin(lv.t, faddr);
        auto ov = T(), p = T();
        L("int64_t ", ov, " = ", off, ";");
        // Offset 0 is null only for the optional spelling (§3.9); a
        // non-optional slot holds a reference, so the address is the sum.
        if (r.optional) L("uint8_t *", p, " = ", ov, " ? ", org, " + ", ov, " : NULL;");
        else L("uint8_t *", p, " = ", org, " + ", ov, ";");
        // Relative references never point at resizables: pool elements
        // are at most variable-class (§3.3).
        assert(!IsResz(r.sub));
        if (IsBytesT(r.sub)) return p;
        return cat("((", CT(r.sub), " *)", p, ")");
    }
    if (et && et->kind == TY_SLICE && lv.t->kind == TY_ARRAY) {
        // A whole array at a slice destination (§3.10), any loc form
        // (fixed value or bytes/resizable pointer).
        auto v = ArrayView(lv);
        auto t = T();
        auto dp = v.typedelems && IsBytesT(et->sub)
                      ? cat("(uint8_t *)(", v.elems, ")") : string(v.elems);
        if (!v.typedelems && !IsBytesT(et->sub))
            dp = cat("(", CT(et->sub), " *)(", v.elems, ")");
        L(CT(et), " ", t, " = { ", dp, ", ", v.len, " };");
        return t;
    }
    if (!lv.val) {
        assert(IsBytesT(lv.t));
        if (lv.t->kind == TY_INT)   // varint field read: decode to i64.
            return cat("gs_zig_read(", lv.s, ")");
        if (et && IsFix(et) && !TEq(lv.t, et)) return AdaptToFixed(lv, et, ln);
        return lv.s;   // Bytes value: the pointer is the currency.
    }
    // A slice, or an array of another kind or capacity, read as a
    // static-capacity limited array (§4.2).
    if (et && lv.val && IsStaticLimited(et) &&
        (lv.t->kind == TY_SLICE || (lv.t->kind == TY_ARRAY && !TEq(lv.t, et))))
        return AdaptToFixed(lv, et, ln);
    // A variant read as its ADT (§3.5).
    if (et && et->kind == TY_ENUM && lv.t->kind == TY_VARIANT) return AdaptToFixed(lv, et, ln);
    if (lv.ispref && et && et->kind == TY_REF) {
        // A pool reference read as a plain reference drops the freelist.
        auto t = T();
        L("gs_rref ", t, " = { ", lv.s, ".hdr, ", lv.s, ".stk };");
        return t;
    }
    return lv.s;
}

// A fixed C value built from a differently-represented source: a variant
// or a variable-mode ADT read into a fixed-mode context, or an array/slice
// into a static-capacity limited array.
inline string CodeGen::AdaptToFixed(Loc lv, TypeExpr *et, Line ln) {
    if (et->kind == TY_ENUM && lv.t->kind == TY_VARIANT) {
        // The variant's own tag, its value the payload.
        assert(lv.val);
        auto ei = EIOf(et);
        auto vi = ei->en->VariantIndex(lv.t->var->variant);
        auto tv = T();
        FixedLocal(et, tv, HasUninitSlots(et) ? "{0}" : "");
        L(tv, ".tag = ", TagConst(ei, vi), ";");
        if (!EmptyLayout(ei->en->variants[vi].fields))
            L(tv, ".u.v_", Sanitize(ei->en->variants[vi].name), " = ", lv.s, ";");
        return tv;
    }
    if (et->kind == TY_ENUM) {
        auto ei = EIOf(et);
        auto ts = TagSize(ei->en);
        auto tv = T();
        FixedLocal(et, tv);
        L(tv, ".tag = *(", IntCT(TagStore(ei->en)), " *)(", lv.s, ")", ";");
        L("switch (", tv, ".tag) {");
        for (size_t vi = 0; vi < ei->en->variants.size(); vi++) {
            auto psz = VariantLayout(ei, (int)vi).size;
            L("case ", TagConst(ei, (int)vi), ":");
            ind++;
            if (psz)
                L("GS_MEMCPY(&", tv, ".u.v_", Sanitize(ei->en->variants[vi].name), ", ",
                  lv.s, " + ", ts, ", ", psz, ");");
            L("break;");
            ind--;
        }
        L("}");
        return tv;
    }
    assert(et->kind == TY_ARRAY && et->arr->akind == A_LIMITED);
    auto tv = T();
    FixedLocal(et, tv);
    CopyIntoLimited(lv, et, ln, tv, false);
    return tv;
}

// The elements of the array or slice at `lv` copied into the
// static-capacity limited array (type `et`) at the C lvalue `dst`, under
// its capacity check (§4.2). The count and the elements are read before
// anything is written, and with `overlap` they move as memmove moves them,
// so the source may lie in `dst`'s own slots.
inline void CodeGen::CopyIntoLimited(Loc lv, TypeExpr *et, Line ln, const string &dst,
                                     bool overlap) {
    auto v = ArrayView(lv);
    auto nn = T();
    L("int64_t ", nn, " = ", v.len, ";");
    L("if (", nn, " > ", ArrSize(et->arr),
      ") gs_abort(GS_E_CAPACITY, ", LocArgs(ln), ");");
    L(overlap ? "gs_memmove" : CopyFn(), "(", dst, ".e, ", v.elems, ", (size_t)(", nn, " * ",
      FixedSize(et->arr->sub), "));");
    L(dst, ".len = (", IntCT(LenStore(et->arr)), ")", nn, ";");
}

// Whether `n`, for a static-capacity limited destination `want`, is an
// array or slice of another representation that is copied in (§4.2).
inline bool CodeGen::AdaptsToLimited(Node *n, TypeExpr *want) {
    auto nt = n->exprtype;
    if (!want || !nt || !IsStaticLimited(want) || fillvalues.count(n)) return false;
    auto st = IsPlainRef(nt) ? nt->ref->sub : nt;
    return (st->kind == TY_ARRAY || st->kind == TY_SLICE) && !TEq(st, want);
}

// `n` stored into `dst`, a static-capacity limited array of type `want`,
// with an array or slice of another representation copied straight into
// its slots (CopyIntoLimited) rather than built in a temporary of `want`'s
// type first. That covers a node whose checked type differs from `want`,
// and a range or a path the checker typed as `want` whose location is such
// an array or slice. False, with nothing emitted, for anything else.
inline bool CodeGen::GenIntoLimited(Node *n, TypeExpr *want, const string &dst, bool overlap) {
    if (!want || !IsStaticLimited(want) || !n->exprtype || fillvalues.count(n)) return false;
    Loc lv;
    auto dot = Is<Dot>(n);
    if (AdaptsToLimited(n, want)) {
        lv = GenLoc(n);
    } else if (!TEq(n->exprtype, want)) {
        return false;
    } else if (auto se = Is<SliceExpr>(n)) {
        lv.val = true;
        lv.s = GenSlice(se);
        lv.t = ast.SliceOf(want->arr->sub, n->line);
    } else if (Is<Ident>(n) || Is<Index>(n) || (dot && !dot->variantconst && dot->member < 0)) {
        // What their GenX reads: the location, loaded at `want`.
        lv = GenLoc(n);
        while (lv.t->kind == TY_REF) DerefLoc(lv);
        if (lv.t->kind != TY_SLICE && (lv.t->kind != TY_ARRAY || TEq(lv.t, want))) {
            L(dst, " = ", LoadLoc(lv, want, n->line), ";");
            return true;
        }
    } else {
        return false;
    }
    while (lv.t->kind == TY_REF) DerefLoc(lv);
    CopyIntoLimited(lv, want, n->line, dst, overlap);
    return true;
}

inline string CodeGen::BytesAddrOf(const Loc &lv) {
    return lv.val ? cat("(uint8_t *)&", lv.s) : lv.s;
}

// &lvalue (§3.8): the reference value. On a location holding a reference,
// yields the stored reference.
inline string CodeGen::GenRefVal(Node *child, Line ln) {
    // A reference to a resizable value points at its frame header (C.2),
    // so it can only be taken of a whole variable.
    if (auto id = Is<Ident>(child); id && id->vdef && IsResz(id->vdef->type)) {
        auto stk = VStkOf(id->vdef);
        assert(!stk.empty());
        auto t = T();
        L("gs_rref ", t, " = { (gs_rhdr *)&", HdrLv(id->vdef), ", ", stk, " };");
        return t;
    }
    auto lv = GenLoc(child);
    if (lv.t->kind == TY_REF) {
        if (lv.t->ref->lenstorage >= 0) return LoadLoc(lv, lv.t, ln);
        return lv.s;
    }
    if (IsResz(lv.t)) {
        // A frame object's tail (or a nested frame object) has a header
        // of its own to point at.
        if (lv.hdr.empty() || lv.stk.empty())
            Fail(ln, "a reference to a resizable value nested in a variable-size "
                     "prefix or an ADT payload is unsupported; reference the owning "
                     "variable");
        auto t = T();
        L("gs_rref ", t, " = { (gs_rhdr *)&", lv.hdr, ", ", lv.stk, " };");
        return t;
    }
    if (!lv.val) return lv.s;
    return cat("&", lv.s);
}

// GenX, loading the pointee when an optimizer splice left a reference
// where the context's checked type had already decayed.
inline string CodeGen::GenXD(Node *n, TypeExpr *want) {
    if (auto it = fillvalues.find(n); it != fillvalues.end())
        return LoadLoc(it->second, want, n->line);
    if (AdaptsToLimited(n, want)) {
        // Any array or slice of the element type reaching a static-capacity
        // limited destination in a representation of its own (a copy's
        // source, a spliced callee body's result): copied into the C value
        // from wherever it lives (§4.2).
        auto lv = GenLoc(n);
        if (lv.t->kind == TY_REF) DerefLoc(lv);
        return AdaptToFixed(lv, want, n->line);
    }
    if (NeedsDeref(n->exprtype, want)) {
        auto sub = n->exprtype->ref->sub;
        if (want->kind == TY_SLICE && sub->kind == TY_ARRAY) {
            // The pointee array sliced whole (§3.10).
            auto lv = GenLoc(n);
            if (lv.t->kind == TY_REF) DerefLoc(lv);
            return LoadLoc(lv, want, n->line);
        }
        auto x = GenX(n);
        if (IsVarintT(sub)) return cat("gs_zig_read(", x, ")");
        if (IsResz(sub) || IsBytesT(sub)) return x;   // Byte-pointer currency.
        return PointeeLv(x, sub);
    }
    return GenX(n);
}

inline string CodeGen::GenTruth(Node *n) {
    auto x = GenX(n);
    auto t = n->exprtype;
    if (t->kind == TY_REF && IsResz(t->ref->sub)) return cat("(", x, ".hdr != 0)");
    return x;
}

// Whether a && or || takes the unconditional form of Binary::CgX: in a loop
// that can be straight-line code, a right operand that can neither fail nor
// have an effect, evaluated whatever the left gave (§6.11).
inline bool CodeGen::SpeculativeForm(Binary *b) {
    auto budget = 24;
    return InStraightLoop() && Speculatable(b->right, b->specidx > 0, true, budget);
}

// n where it is a && or || that GenBranch emits as branches on its operands.
inline Binary *CodeGen::ChainOp(Node *n) {
    auto b = Is<Binary>(n);
    return b && (b->op == T_ANDAND || b->op == T_OROR) && !SpeculativeForm(b) ? b : nullptr;
}

// n where it is an inlined call of a bool function that GenBranch emits as
// branches from where the callee's value is decided.
inline InlineBlock *CodeGen::BranchCall(Node *n) {
    auto ib = Is<InlineBlock>(n);
    return ib && ib->exprtype && ib->exprtype->kind == TY_BOOL && !AdtFrom(ib) ? ib : nullptr;
}

// Whether a condition, under any `!`s, is one of those.
inline bool CodeGen::BranchChain(Node *n) {
    for (auto u = Is<Unary>(n); u && u->op == T_NOT; u = Is<Unary>(n)) n = u->child;
    return ChainOp(n) || BranchCall(n);
}

// A branch to `lbl` taken where n's truth value is `when`, falling through
// where it is not. A && or || (ChainOp) is a chain of branches on its
// operands, the right one's statements running only where the left did not
// settle the value: in a loop's condition, clang ran a 0/1 flag set in an
// `if` and then tested slower than this chain, which is what C's own &&
// compiles to (§6.11). An inlined bool call (BranchCall) branches where its
// body returns or ends, on the value it returns, as the C compiler finds C
// after inlining it; a constant there is a jump or nothing. Each operand at
// a leaf is evaluated in a scope of its own, whose data-stack restores run
// once its truth value is taken, ahead of its branch, so neither path skips
// them; a branch out of the scopes down to `exitscope`, an inlined call's
// own and its arguments', restores theirs on its way.
inline void CodeGen::GenBranch(Node *n, bool when, string lbl, int exitscope) {
    if (auto u = Is<Unary>(n); u && u->op == T_NOT)
        return GenBranch(u->child, !when, lbl, exitscope);
    if (auto b = ChainOp(n)) {
        // A && is false, and a || true, as soon as one operand is.
        if ((b->op == T_ANDAND) != when) {
            GenBranch(b->left, when, lbl, exitscope);
            GenBranch(b->right, when, lbl, exitscope);
            return;
        }
        auto skip = Lbl();
        GenBranch(b->left, !when, skip);
        GenBranch(b->right, when, lbl, exitscope);
        L(skip, ":;");
        return;
    }
    if (auto ib = BranchCall(n)) {
        // The arguments bound in a scope of their own.
        PushSc(SC_PLAIN);
        Dst d;
        d.k = DK_BRANCH;
        d.s = lbl;
        d.t = ib->exprtype;
        d.when = when;
        d.exitscope = exitscope >= 0 ? exitscope : (int)cscopes.size() - 1;
        ib->EmitBody(*this, d);
        PopSc();
        return;
    }
    auto jump = [&](const string &c) {
        auto restores = false;
        if (exitscope >= 0)
            for (auto i = exitscope; i < (int)cscopes.size(); i++)
                restores = restores || !cscopes[i].saves.empty();
        if (!restores) {
            L(c.empty() ? "" : cat("if (", c, ") "), "goto ", lbl, ";");
            return;
        }
        if (!c.empty()) {
            L("if (", c, ") {");
            ind++;
        }
        EmitExitRestores(exitscope);
        L("goto ", lbl, ";");
        if (!c.empty()) {
            ind--;
            L("}");
        }
    };
    if (auto bl = Is<BoolLit>(n)) {
        if (bl->val == when) jump("");
        return;
    }
    PushSc(SC_PLAIN);
    auto x = GenTruth(n);
    if (!cscopes.back().saves.empty()) {
        auto t = T();
        L("uint8_t ", t, " = (uint8_t)(", x, " != 0);");
        x = t;
    }
    PopSc();
    jump(when ? x : cat("!(", x, ")"));
}

// Whether evaluating n, the right operand of && or || or a part of it, has
// no effect but its value and cannot fail, so that Binary::CgX may evaluate
// it whatever the left operand gave. It calls nothing and writes nothing; it
// has no check that can fail: no division, none of a debug build's overflow
// or `as` range checks (signed arithmetic, narrowing casts, float to integer),
// and no bounds check but one the types settle or BCE found to hold without
// the left operand's facts (`idxok`, Binary::specidx); and it reads only
// variables, fields of fixed structs and elements, never through an optional
// reference, which the left operand may be what narrows (§3.8). In truth
// position an optional variable stands for its null test, which reads the
// reference alone. `budget` bounds the work the operand may do for nothing.
inline bool CodeGen::Speculatable(Node *n, bool idxok, bool truth, int &budget) {
    if (--budget < 0) return false;
    auto t = n->exprtype;
    auto scalar = [](TypeExpr *x) {
        return x && (IsIntT(x) || x->kind == TY_FLT || x->kind == TY_BOOL);
    };
    auto wraps = [](TypeExpr *x) {   // unsigned arithmetic wraps in every build (§6.2)
        return x && IsIntT(x) && IntRange(x->intstorage).first == 0;
    };
    if (Is<IntLit>(n) || Is<FltLit>(n) || Is<BoolLit>(n)) return true;
    if (auto id = Is<Ident>(n)) {
        auto vt = id->vdef ? id->vdef->type : nullptr;
        if (!vt) return false;
        if (truth && IsOptional(vt) && t && IsOptional(t)) return true;
        return scalar(t ? OperandT(t) : nullptr) &&
               (scalar(vt) || (IsPlainRef(vt) && scalar(vt->ref->sub)));
    }
    if (auto u = Is<Unary>(n)) {
        switch (u->op) {
            case T_NOT: return Speculatable(u->child, idxok, true, budget);
            case T_BITNOT: return IsIntT(t) && Speculatable(u->child, idxok, false, budget);
            case T_MINUS:
                return t && t->kind == TY_FLT && Speculatable(u->child, idxok, false, budget);
            default: return false;
        }
    }
    if (auto b = Is<Binary>(n)) {
        auto both = [&](bool tr) {
            return Speculatable(b->left, idxok, tr, budget) &&
                   Speculatable(b->right, idxok, tr, budget);
        };
        auto lt = b->left->exprtype ? OperandT(b->left->exprtype) : nullptr;
        auto rt = b->right->exprtype ? OperandT(b->right->exprtype) : nullptr;
        switch (b->op) {
            case T_ANDAND: case T_OROR: return both(true);
            case T_EQ: case T_NEQ:
                if (Is<NullLit>(b->left) || Is<NullLit>(b->right)) {
                    auto other = Is<NullLit>(b->left) ? b->right : b->left;
                    if (Is<NullLit>(other)) return true;
                    auto id = Is<Ident>(other);
                    return id && id->vdef && id->vdef->type && IsOptional(id->vdef->type);
                }
                return scalar(lt) && scalar(rt) && both(false);
            case T_LT: case T_GT: case T_LTEQ: case T_GTEQ:
                return scalar(lt) && scalar(rt) && both(false);
            // At the operands' type, as Binary::CgX computes.
            case T_BITAND: case T_BITOR: case T_XOR: case T_SHL: case T_SHR:
                return lt && IsIntT(lt) && IsIntT(t) && both(false);
            case T_PLUS: case T_MINUS: case T_MUL:
                return (wraps(lt) || (lt && lt->kind == TY_FLT)) && scalar(t) && both(false);
            case T_DIV: return lt && lt->kind == TY_FLT && scalar(t) && both(false);
            default: return false;
        }
    }
    if (auto d = Is<Dot>(n)) {
        if (d->member == B_LEN || d->member == B_CAP)
            return SpeculatablePlace(d->obj, idxok, budget);
        if (!d->IsField() || !scalar(t ? OperandT(t) : nullptr)) return false;
        auto ot = d->obj->exprtype ? OperandT(d->obj->exprtype) : nullptr;
        if (!ot || ot->kind != TY_STRUCT || !IsFix(ot) || !scalar(SI(ot)->ftypes[d->fieldidx]))
            return false;
        return SpeculatablePlace(d->obj, idxok, budget);
    }
    if (auto ix = Is<Index>(n)) {
        if (!scalar(t ? OperandT(t) : nullptr) || !(IndexInRangeByType(ix) || (idxok && ix->nobc)))
            return false;
        return SpeculatablePlace(ix->obj, idxok, budget) &&
               Speculatable(ix->idx, idxok, false, budget);
    }
    if (auto c = Is<AsCast>(n)) {
        auto st = c->child->exprtype, tt = c->totype;
        if (!st || !tt || !(IsIntT(st) || st->kind == TY_FLT)) return false;
        if (tt->ix && !c->nobc) return false;   // Its bounds check may fail.
        if (tt->kind == TY_INT) {
            if (!IsIntT(st) || !IsIntT(tt)) return false;
            auto [slo, shi] = IntRange(st->intstorage);
            auto [lo, hi] = IntRange(tt->intstorage);
            auto exact = st->intstorage == IS_U64 ? tt->intstorage == IS_U64
                                                  : slo >= lo && shi <= hi;
            if (!c->unchecked && !TEq(st, tt) && !exact) return false;
        } else if (tt->kind != TY_FLT) {
            return false;
        }
        return Speculatable(c->child, idxok, false, budget);
    }
    // An inlined call or a block: scalar bindings and a value.
    Block *block = nullptr;
    if (auto ib = Is<InlineBlock>(n)) block = ib->body;
    else block = Is<Block>(n);
    if (!block || !block->tail) return false;
    for (auto st : block->stmts) {
        auto vd = Is<VarDecl>(st);
        if (!vd || vd->isglobal || vd->byref || vd->defs.size() != 1 || vd->inits.size() != 1 ||
            !vd->defs[0] || !scalar(vd->defs[0]->type) ||
            !Speculatable(vd->inits[0], idxok, false, budget))
            return false;
    }
    return Speculatable(block->tail, idxok, truth, budget);
}

// Whether the storage n names is there whatever the left operand of && or ||
// gave, for Speculatable: a variable but an optional reference, a field of
// such storage holding a fixed value, or an element of it as Speculatable
// takes one.
inline bool CodeGen::SpeculatablePlace(Node *n, bool idxok, int &budget) {
    if (--budget < 0) return false;
    if (auto id = Is<Ident>(n)) {
        auto vt = id->vdef ? id->vdef->type : nullptr;
        return vt && (vt->kind != TY_REF || IsPlainRef(vt));
    }
    if (auto d = Is<Dot>(n)) {
        if (!d->IsField()) return false;
        auto ot = d->obj->exprtype ? OperandT(d->obj->exprtype) : nullptr;
        if (!ot || ot->kind != TY_STRUCT || !IsFix(ot) ||
            SI(ot)->ftypes[d->fieldidx]->kind == TY_REF)
            return false;
        return SpeculatablePlace(d->obj, idxok, budget);
    }
    if (auto ix = Is<Index>(n)) {
        if (!(IndexInRangeByType(ix) || (idxok && ix->nobc))) return false;
        auto et = ix->exprtype;
        if (!et || et->kind == TY_REF) return false;
        return SpeculatablePlace(ix->obj, idxok, budget) &&
               Speculatable(ix->idx, idxok, false, budget);
    }
    return false;
}

// A control construct used as a fixed-class value: route it into a temp.
// A varint-typed value (an inlined call initializing a varint field or
// element) is held in its decoded i64 form, like every other varint read,
// and a relative-reference-typed one (an `if` choosing a relative field's
// target) as the plain reference every relative load gives and every
// relative store encodes (§3.9).
inline string CodeGen::CtlValX(Node *n) {
    auto t = T();
    auto vt = n->exprtype;
    if (vt->kind == TY_INT && vt->intstorage == IS_VARINT) vt = ast.inttypes[IS_I64];
    if (IsRelRef(vt))
        vt = ast.RefTo(vt->ref->sub, n->line, vt->ref->optional);
    FixedLocal(vt, t);
    // The type rides along: a spliced body may deliver a reference where
    // the checked value had already decayed (NeedsDeref).
    GenAny(n, Dst { DK_LVALUE, t, vt });
    return t;
}

// A non-control node's value routed to a destination.
inline void CodeGen::LeafAny(Node *n, const Dst &d) {
    if (d.k == DK_STACK) { GenConstruct(n, d.s, d.t, d.lenlv); return; }
    if (d.k == DK_LVALUE) {
        if (d.pool) { L(d.s, " = ", GenPrefVal(n), ";"); return; }
        if (GenIntoLimited(n, d.t, d.s, true)) return;   // The source may lie in d.s.
        // A literal holding relative references builds at the destination;
        // assigning it from a temporary would copy the temporary's offsets.
        if ((Is<StructLit>(n) || Is<ArrayLit>(n)) && HasRelRef(n->exprtype)) {
            FixedLitAt(n, d.s);
        } else {
            L(d.s, " = ", GenXD(n, d.t), ";");
        }
        return;
    }
    if (IsVoidT(n->exprtype)) { Fail(n->line, "internal: valueless leaf"); }
    // A resizable value is reached through its location: a path's is where
    // it is stored, anything else is built on a temporary stack the
    // enclosing scope releases (GenRzTmp). The location is still evaluated
    // for the index checks on its path.
    if (IsResz(n->exprtype)) {
        L("(void)(", GenLoc(n).s, ");");
        return;
    }
    L("(void)(", GenVal(n), ");");
}

inline string CodeGen::GenFixedArrayLit(ArrayLit *al) {
    auto et = al->exprtype;
    if (et->kind == TY_SLICE) {
        // A literal in slice position: a temporary fixed array, sliced
        // whole (§3.10; rooted as a temporary by the checker).
        auto count = LitCount(al);
        auto at = ast.ArrayOf(et->sub, A_FIXED, al->line, count);
        auto save = al->exprtype;
        al->exprtype = at;
        auto av = GenFixedArrayLit(al);
        al->exprtype = save;
        auto t = T();
        L(CT(et), " ", t, " = { ", av, ".e, ", count, " };");
        return t;
    }
    assert(et->kind == TY_ARRAY);
    auto tv = T();
    FixedLocal(et, tv, HasUninitSlots(et) ? "{0}" : "");
    FixedArrayLitAt(al, tv, false);
    return tv;
}

// Bytes-class value of an expression; optionally reports the data stack
// it lives on (temporaries land on a fresh statement-scoped stack).
// Resizable values carry a header and go through GenLoc/GenRzTmp instead.
inline string CodeGen::GenPtr(Node *n, string *stkout) {
    assert(!IsResz(n->exprtype));
    if (stkout) stkout->clear();
    if (auto it = fillvalues.find(n); it != fillvalues.end()) {
        if (stkout) *stkout = it->second.stk;
        return it->second.s;
    }
    // A path is the value where it is stored, and `&path` a reference
    // decayed back to its bytes pointee. A payload-less variant constant is
    // a value, not a path: it constructs below like the other rvalues.
    Node *path = nullptr;
    if (Is<Ident>(n) || Is<Index>(n)) path = n;
    else if (auto dot = Is<Dot>(n); dot && dot->IsField()) path = n;
    else if (auto u = Is<Unary>(n); u && u->op == T_BITAND) path = u->child;
    if (path) {
        auto lv = GenLoc(path);
        if (lv.t->kind == TY_REF) DerefLoc(lv);
        auto et = n->exprtype;
        if (et->kind != TY_ARRAY || TEq(lv.t, et)) {
            if (stkout) *stkout = lv.stk;
            assert(!lv.val);
            return lv.s;
        }
        // A slice or an array of another kind, which the checker let
        // construct n's array type (§4.2): built as one on a temporary.
        string stk;
        auto base = BytesTemp(stk);
        ConstructFromLoc(lv, et, stk, "", n->line);
        if (stkout) *stkout = stk;
        return base;
    }
    // A `u8[]` literal is an image in static data. A runtime-capacity limited
    // one is built below as any other value, which gives it its capacity.
    if (auto s = Is<StrLit>(n); s && n->exprtype->arr->akind == A_VAR) return GenStrBytes(s);
    // Everything else constructs on a fresh temp stack.
    string stk;
    auto base = BytesTemp(stk);
    GenAny(n, Dst { DK_STACK, stk, n->exprtype });
    if (stkout) *stkout = stk;
    return base;
}

inline string CodeGen::StrRaw(const string &v) {
    auto it = strdata.find(v);
    if (it != strdata.end()) return it->second;
    auto name = Unique(cat("gs_str", strdata.size()));
    // The checker admits no write to a literal (§9.5), so the data is C
    // const and a hole in the analysis faults rather than corrupting; the
    // cast keeps the slice and copy sites at their plain pointer type.
    Append(pdata, "static const uint8_t ", name, "[", v.size() ? v.size() : 1, "] = ", CStr(v),
           ";\n");
    auto expr = cat("((uint8_t *)", name, ")");
    strdata[v] = expr;
    return expr;
}

// Binary static data, such as an embedded shader: an initializer list, which
// MSVC takes at any size, where it takes a string literal only in pieces
// (CStr).
inline string CodeGen::BlobRaw(const string &v) {
    auto it = blobdata.find(v);
    if (it != blobdata.end()) return it->second;
    auto name = Unique(cat("gs_blob", blobdata.size()));
    Append(pdata, "static const uint8_t ", name, "[", v.size() ? v.size() : 1, "] = {");
    for (size_t i = 0; i < v.size(); i++) {
        if (i % 24 == 0) pdata += "\n   ";
        Append(pdata, " ", (int)(uint8_t)v[i], ",");
    }
    pdata += "\n};\n";
    auto expr = cat("((uint8_t *)", name, ")");
    blobdata[v] = expr;
    return expr;
}

inline string CodeGen::GenStrBytes(StrLit *s) {
    auto et = s->exprtype;
    assert(et->kind == TY_ARRAY && et->arr->akind == A_VAR);
    auto key = cat(Mangle(et), "|", s->val);
    auto it = strval.find(key);
    if (it != strval.end()) return it->second;
    auto ls = LenStore(et->arr);
    auto name = Unique(cat("gs_strv", strval.size()));
    if (ls == IS_VARINT) {
        uint8_t lenbuf[10];
        uint64_t v = s->val.size();
        string enc;
        auto nn = 0;
        do {
            lenbuf[nn] = v & 0x7f;
            v >>= 7;
            if (v) lenbuf[nn] |= 0x80;
            nn++;
        } while (v);
        enc.assign((char *)lenbuf, nn);
        enc += s->val;
        Append(pdata, "static const uint8_t ", name, "[", enc.size(), "] = ", CStr(enc),
               ";\n");
    } else {
        Append(pdata, "static const struct { ", IntCT(ls), " len; uint8_t s[",
               s->val.size() ? s->val.size() : 1, "]; } ", name, " = { ",
               s->val.size(), ", ", CStr(s->val), " };\n");
    }
    auto expr = cat("((uint8_t *)&", name, ")");
    strval[key] = expr;
    return expr;
}

// ------------------------------------------------------------------
// Binary operators. Operand exprtypes are already decayed and unified.

// Operand exprtype as an operator sees it: a spliced reference reads as
// its pointee.
inline TypeExpr *CodeGen::OperandT(TypeExpr *t) {
    return t && IsPlainRef(t) ? t->ref->sub : t;
}

// GenX or GenPtr per the operand's rep; operators see spliced references
// as their pointees.
inline string CodeGen::GenVal(Node *n) {
    auto et = OperandT(n->exprtype);
    if (et != n->exprtype) return GenXD(n, et);   // Bytes pointees share the currency.
    return IsBytesT(et) ? GenPtr(n) : GenX(n);
}

inline string CodeGen::GenPureVal(Node *n) {
    auto et = OperandT(n->exprtype);
    if (IsBytesT(et)) {
        auto p = T();
        L("uint8_t *", p, " = (uint8_t *)(", GenPtr(n), ");");
        return p;
    }
    return Snapshot(et, GenVal(n));
}

// An operand whose value must not change before it is used: when `later`,
// the code that runs between, has statements, its value lands in a temp
// (GenPureVal). Code without statements calls nothing and assigns
// nothing, so the operand's expression stands as it is -- unless its own
// statements left more than a variable's name in it, which may hold a
// call that C could order after the later operands. A number is converted
// to the operand's type as the temp would have converted it: a literal 1
// shifted at u64 must not shift as a C int.
inline string CodeGen::GenOperandVal(Node *n, bool later) {
    auto et = OperandT(n->exprtype);
    if (later || IsBytesT(et)) return GenPureVal(n);
    auto x = GenVal(n);
    if (HasStmts(n) && !IsCName(x)) return Snapshot(et, x);
    if (et->kind == TY_INT || et->kind == TY_FLT) return cat("(", CT(et), ")(", x, ")");
    return x;
}

inline bool CodeGen::IsCName(const string &x) {
    return !x.empty() && !isdigit((unsigned char)x[0]) &&
           all_of(x.begin(), x.end(), [](char c) { return isalnum((unsigned char)c) || c == '_'; });
}

inline bool CodeGen::HasStmts(Node *n) {
    if (!n) return false;
    if (Is<Call>(n) || IsCtl(n) || Is<StrLit>(n)) return true;
    auto found = false;
    n->Children([&](Node *c) { found = found || HasStmts(c); });
    return found;
}

// Equality of two direct operands (§4.5): a slice compares length then
// elements here, where as a member it compares by identity (EqX).
inline string CodeGen::GenEquality(TypeExpr *lt, const string &l, const string &r) {
    if (lt->kind == TY_SLICE) return GenSliceEq(lt, l, r);
    return EqX(lt, l, r);
}

inline string CodeGen::GenSliceEq(TypeExpr *st, const string &l, const string &r) {
    return GenRangeEq(st->sub, cat(l, ".data"), cat(l, ".len"), cat(r, ".data"),
                      cat(r, ".len"));
}

// Structural equality of two element ranges (§4.5): length then elements.
// Either range's elements may be an empty slice's null pointer, which
// gs_memeq allows.
inline string CodeGen::GenRangeEq(TypeExpr *elem, const string &ae, const string &an,
                                  const string &be, const string &bn) {
    auto t = T();
    L("uint8_t ", t, " = ", an, " == ", bn, ";");
    L("if (", t, ") {");
    ind++;
    if (ScalarEq(elem) && BitwiseEq(elem)) {
        L(t, " = gs_memeq(", ae, ", ", be, ", (size_t)((", an, ") * ", FixedSize(elem), "));");
    } else if (IsFix(elem)) {
        auto pa = T(), pb = T(), iv = T();
        L("const ", CT(elem), " *", pa, " = (const ", CT(elem), " *)(", ae, ");");
        L("const ", CT(elem), " *", pb, " = (const ", CT(elem), " *)(", be, ");");
        L("for (int64_t ", iv, " = 0; ", t, " && ", iv, " < (", an, "); ", iv, "++)");
        L("    ", t, " = ", EqX(elem, cat(pa, "[", iv, "]"), cat(pb, "[", iv, "]")),
          ";");
    } else {
        // Variable elements: parallel cursor walk.
        auto pa = T(), pb = T(), iv = T();
        L("const uint8_t *", pa, " = (const uint8_t *)(", ae, "), *", pb,
          " = (const uint8_t *)(", be, ");");
        L("for (int64_t ", iv, " = 0; ", t, " && ", iv, " < (", an, "); ", iv, "++) {");
        ind++;
        L(t, " = ", EqFn(elem), "(", pa, ", ", pb, ");");
        L(pa, " += ", SizeX(elem, pa), "; ", pb, " += ", SizeX(elem, pb), ";");
        ind--;
        L("}");
    }
    ind--;
    L("}");
    return t;
}

// Elementwise arithmetic (§6.1), expanded member by member with direct
// loads and stores — no whole-struct temporaries, which backends fail to
// scalarize. Member i of the result depends only on member i of each
// operand, so writing members straight into `dst` is exact even when it
// aliases an operand (the p.vel = p.vel + g shape). Scalar operands are
// snapshotted by the caller because they may alias any destination member.
inline void CodeGen::GenElemwiseInto(TypeExpr *t, TType op, Line line, const string &l,
                                     const string &r, const string &dst,
                                     bool lscalar, bool rscalar) {
    GenElemwiseLeaves(t, dst, [&](TypeExpr *tt, const string &path) {
        auto a = cat("(", l, ")", lscalar ? string() : path);
        auto c = cat("(", r, ")", rscalar ? string() : path);
        return ArithX(op, tt, a, c, line, false, a, c);
    });
}

// Elementwise negation (§6.1), member by member as above: member i of the
// result reads only member i of the operand.
inline void CodeGen::GenElemwiseNegInto(TypeExpr *t, Line line, const string &x,
                                        const string &dst) {
    GenElemwiseLeaves(t, dst, [&](TypeExpr *tt, const string &path) {
        auto a = cat("(", x, ")", path);
        if (tt->kind == TY_FLT) return cat("(-", a, ")");
        return cat("gs_neg_", IntSfx(tt->intstorage), "(", a,
                   OvfLocArgs(tt->intstorage, line), ")");
    });
}

// Stores leaf(type, path) into dst's member at each numeric leaf path of the
// struct or fixed array type t.
inline void CodeGen::GenElemwiseLeaves(TypeExpr *t, const string &dst,
                                       const function<string(TypeExpr *, const string &)> &leaf) {
    function<void(TypeExpr *, const string &)> rec = [&](TypeExpr *tt, const string &path) {
        switch (tt->kind) {
            case TY_INT: case TY_FLT:
                L(dst, path, " = ", leaf(tt, path), ";");
                return;
            case TY_STRUCT: {
                auto si = SI(tt);
                for (size_t i = 0; i < si->st->fields.size(); i++)
                    if (!si->st->fields[i].ispad)
                        rec(si->ftypes[i],
                            cat(path, ".", Sanitize(si->st->fields[i].name)));
                return;
            }
            case TY_ARRAY: {
                auto iv = T();
                L("for (int64_t ", iv, " = 0; ", iv, " < ", ArrSize(tt->arr), "; ", iv,
                  "++) {");
                ind++;
                rec(tt->arr->sub, cat(path, ".e[", iv, "]"));
                ind--;
                L("}");
                return;
            }
            default: assert(false); return;
        }
    };
    // Struct field paths start at the value; array paths at .e — handled
    // uniformly since the outer type is one of the two.
    rec(t, "");
}

// Left-to-right evaluation (§2): when the right operand needs statements,
// the left's value must be snapshotted before they run.
inline void CodeGen::ElemwiseOperands(Binary *b, string &l, string &r) {
    auto scalar = [&](Node *n) {
        auto t = OperandT(n->exprtype);
        return t->kind == TY_INT || t->kind == TY_FLT;
    };
    // A scalar can alias any destination member, not just the member being
    // written: v = v * v.x must use the original x for every component.
    if (scalar(b->left)) l = GenPureVal(b->left);
    else if (HasStmts(b->right)) {
        l = GenVal(b->left);
        auto lt = T();
        FixedLocal(OperandT(b->left->exprtype), lt, l);
        l = lt;
    } else l = GenVal(b->left);
    r = scalar(b->right) ? GenPureVal(b->right) : GenVal(b->right);
}

inline string CodeGen::GenElemwise(Binary *b, const string &l, const string &r) {
    auto tv = T();
    FixedLocal(b->exprtype, tv);
    GenElemwiseInto(b->exprtype, b->op, b->line, l, r, tv,
                    OperandT(b->left->exprtype)->kind != b->exprtype->kind,
                    OperandT(b->right->exprtype)->kind != b->exprtype->kind);
    return tv;
}

// A slice expression's value, in a new temp, or with `into` (a variable of
// the slice's C type) in that variable's members: the members are computed
// from temps only, so writing one cannot change the other, and TinyCC is
// spared building a temp and copying it.
inline string CodeGen::GenSlice(SliceExpr *se, const string &into) {
    auto lv = GenLoc(se->obj);
    if (lv.t->kind == TY_REF) DerefLoc(lv);
    auto v = ArrayView(lv);
    auto elems = T();
    L(v.typedelems ? CT(v.elem) : string("uint8_t"), " *", elems, " = ", v.elems, ";");
    v.elems = elems;
    auto lenv = T();
    L("int64_t ", lenv, " = ", v.len, ";");
    auto bound = [&](Node *b, bool fromend, const char *dflt) -> string {
        if (!b) return dflt;
        auto x = GenX(b);
        if (fromend) return cat("(", lenv, " - (", x, "))");
        return x;
    };
    auto lo = bound(se->lo, se->lo_from_end, "0");
    auto lov = T(), hiv = T();
    L("int64_t ", lov, " = ", lo, ";");
    auto hi = bound(se->hi, se->hi_from_end, lenv.c_str());
    L("int64_t ", hiv, " = ", hi, ";");
    if (!se->nobc)
        L("if (", lov, " < 0 || ", hiv, " < ", lov, " || ", hiv, " > ", lenv,
          ") gs_abort(GS_E_SLICE, ", LocArgs(se->line), ");");
    // Adapted contexts (slice constructing an array) leave an array
    // exprtype on the node; the slice value's own type comes from the
    // source element.
    auto et = se->exprtype->kind == TY_SLICE ? se->exprtype : ast.SliceOf(v.elem, se->line);
    string data, len;
    if (IsFix(v.elem)) {
        auto dp = v.typedelems ? v.elems
                               : cat("(", CT(v.elem), " *)(", v.elems, ")");
        data = cat(dp, " + ", lov);
        len = cat(hiv, " - ", lov);
    } else {
        // Whole-array slices only (TC): elements are sequential bytes.
        data = v.elems;
        len = lenv;
    }
    if (!into.empty()) {
        L(into, ".data = ", data, "; ", into, ".len = ", len, ";");
        return into;
    }
    auto t = T();
    L(CT(et), " ", t, " = { ", data, ", ", len, " };");
    return t;
}

}  // namespace goose
