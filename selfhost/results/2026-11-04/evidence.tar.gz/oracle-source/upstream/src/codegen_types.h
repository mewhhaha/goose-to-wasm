// Goose compiler — codegen's types (definitions of CodeGen members,
// codegen.h): type utilities and packed layouts (C.2), C naming, mangled
// type identities with on-demand typedefs, the per-type size walkers of
// bytes values, default values (§4.2) and structural equality (§4.5).
#pragma once

namespace goose {

// ------------------------------------------------------------------
// Type utilities on concrete (post-typecheck) types. Sizes of fixed and
// limited arrays were evaluated during checking; assert rather than
// re-evaluate.

inline bool CodeGen::TEq(TypeExpr *a, TypeExpr *b) {
    if (a == b) return true;
    if (a->kind != b->kind) return false;
    switch (a->kind) {
        case TY_INT:  return a->intstorage == b->intstorage;
        case TY_FLT:  return a->fltstorage == b->fltstorage;
        case TY_BOOL: case TY_VOID: case TY_FN: return true;
        case TY_STRUCT: return SI(a) == SI(b);
        case TY_ENUM:   return EIOf(a) == EIOf(b) && a->enu->varmode == b->enu->varmode;
        case TY_ARRAY: {
            auto &x = *a->arr, &y = *b->arr;
            if (x.akind != y.akind || !TEq(x.sub, y.sub)) return false;
            switch (x.akind) {
                case A_FIXED: case A_LIMITED: return ArrSize(a->arr) == ArrSize(b->arr);
                case A_VAR:     return LenStore(a->arr) == LenStore(b->arr);
                default:        return true;
            }
        }
        case TY_SLICE: return TEq(a->sub, b->sub);
        case TY_REF:
            return TEq(a->ref->sub, b->ref->sub) && a->ref->optional == b->ref->optional &&
                   a->ref->lenstorage == b->ref->lenstorage;
        case TY_VARIANT:
            return a->var->variant == b->var->variant && TEq(a->var->adt, b->var->adt);
        default: assert(false); return false;
    }
}

// Instantiations: the typechecker filled the per-TypeExpr caches for every
// type it touched; fall back to an argument-equality search for clones.
inline StructInst *CodeGen::SI(TypeExpr *t) {
    assert(t->kind == TY_STRUCT);
    if (t->struc->inst) return t->struc->inst;
    for (auto inst : t->struc->st->insts) {
        if (inst->args.size() != t->struc->args.size()) continue;
        auto ok = true;
        for (size_t i = 0; i < inst->args.size(); i++)
            ok &= TEq(inst->args[i], t->struc->args[i]);
        if (ok) return t->struc->inst = inst;
    }
    assert(false);
    return nullptr;
}

inline EnumInst *CodeGen::EIOf(TypeExpr *t) {
    assert(t->kind == TY_ENUM);
    if (t->enu->inst) return t->enu->inst;
    for (auto inst : t->enu->en->insts) {
        if (inst->args.size() != t->enu->args.size()) continue;
        auto ok = true;
        for (size_t i = 0; i < inst->args.size(); i++)
            ok &= TEq(inst->args[i], t->enu->args[i]);
        if (ok) return t->enu->inst = inst;
    }
    assert(false);
    return nullptr;
}

inline EnumInst *CodeGen::EIVar(TypeExpr *t) {   // For TY_VARIANT.
    assert(t->kind == TY_VARIANT);
    return EIOf(t->var->adt);
}

inline span<const FieldRun> CodeGen::FieldRuns(TypeExpr *t) {
    switch (t->kind) {
        case TY_STRUCT: return RunsOf(SI(t));
        case TY_ENUM: return RunsOf(EIOf(t));
        case TY_VARIANT: {
            auto ei = EIVar(t);
            return RunsOf(ei, ei->en->VariantIndex(t->var->variant));
        }
        default: return {};
    }
}

inline SizeClass CodeGen::Cls(TypeExpr *t) {
    switch (t->kind) {
        case TY_INT: return t->intstorage == IS_VARINT ? SC_VARIABLE : SC_FIXED;
        case TY_REF: return t->ref->lenstorage == IS_VARINT ? SC_VARIABLE : SC_FIXED;
        case TY_STRUCT: return SI(t)->sclass;
        case TY_ENUM: return t->enu->varmode ? EIOf(t)->varclass : SC_FIXED;
        case TY_ARRAY:
            switch (t->arr->akind) {
                case A_FIXED:   return SC_FIXED;
                case A_VAR:     return SC_VARIABLE;
                case A_LIMITED: return ArrSize(t->arr) >= 0 ? SC_FIXED : SC_VARIABLE;
                default:        return SC_RESIZABLE;
            }
        case TY_VARIANT: {
            auto c = SC_FIXED;
            EachField(t, [&](TypeExpr *ft) { c = std::max(c, Cls(ft)); });
            return c;
        }
        default: return SC_FIXED;
    }
}

// The innermost tail's gs_rhdr lvalue within frame object `obj`.
inline string CodeGen::FoTailHdr(TypeExpr *t, const string &obj) {
    auto si = SI(t);
    auto ti = LastRealField(si->st->fields);
    auto s = cat(obj, ".", Sanitize(si->st->fields[ti].name));
    auto ft = si->ftypes[ti];
    return IsFrameObj(ft) ? FoTailHdr(ft, s) : s;
}

inline TypeExpr *CodeGen::FoTailArr(TypeExpr *t) {
    auto si = SI(t);
    auto ft = si->ftypes[LastRealField(si->st->fields)];
    return IsFrameObj(ft) ? FoTailArr(ft) : ft;
}

// The bytes of a frame object before its innermost tail header, which is
// the C struct's last member: the fixed fields at every nesting level.
inline string CodeGen::FoPrefixSize(TypeExpr *t) {
    return cat("(sizeof(", CT(t), ") - sizeof(gs_rhdr))");
}

// Where the innermost tail's elements start in that bytes layout (FoBytes),
// in which a bare pad inserts nothing, as in any variable-class layout.
inline int64_t CodeGen::FoBytesPrefix(TypeExpr *t) {
    auto si = SI(t);
    int64_t n = 0;
    for (size_t i = 0; i < si->st->fields.size(); i++) {
        auto &f = si->st->fields[i];
        if (f.ispad) { n += f.padsize > 0 ? f.padsize : 0; continue; }
        auto ft = si->ftypes[i];
        if (IsResz(ft)) return n + (IsFrameObj(ft) ? FoBytesPrefix(ft) : 0);
        n += FixedSize(ft);
    }
    assert(false);   // A frame object ends in its tail.
    return n;
}

inline bool CodeGen::IsFatRef(TypeExpr *t) {
    return t->kind == TY_REF && t->ref->lenstorage < 0 && IsResz(t->ref->sub);
}

// Whether a value of type `t` carries a data stack inside it: a fat
// reference, or one reachable from the value -- in a field, a payload, an
// element, or behind a slice or a plain reference. Code handed such a value
// can grow that stack without the value's name saying which stack it is
// (SyncReach). A nominal type reached again on the way
// through itself has no further fat reference to offer, so `open` cuts the
// recursion there.
inline bool CodeGen::HoldsFatRef(TypeExpr *t) {
    set<const void *> open;
    return HoldsFatRefIn(t, open);
}

inline bool CodeGen::HoldsFatRefIn(TypeExpr *t, set<const void *> &open) {
    switch (t->kind) {
        case TY_REF: return IsFatRef(t) || HoldsFatRefIn(t->ref->sub, open);
        case TY_SLICE: return HoldsFatRefIn(t->sub, open);
        case TY_ARRAY: return HoldsFatRefIn(t->arr->sub, open);
        default:
            // A run's types vector belongs to one instantiation (or one of
            // its variants), so it identifies what was entered.
            for (auto &run : FieldRuns(t)) {
                if (!open.insert(run.ftypes).second) continue;
                for (auto ft : *run.ftypes) if (ft && HoldsFatRefIn(ft, open)) return true;
            }
            return false;
    }
}

// The stored length-field type of an array (A_VAR: declared or u32
// default; A_LIMITED with static capacity: smallest fitting type).
inline IntStorage CodeGen::LenStore(TypeArray *a) {
    switch (a->akind) {
        case A_VAR:
            return a->lenstorage < 0 ? IS_U32 : (IntStorage)a->lenstorage;
        case A_LIMITED: {
            auto k = ArrSize(a);
            assert(k >= 0);
            return k <= 255 ? IS_U8 : k <= 65535 ? IS_U16 :
                   k <= (int64_t)UINT32_MAX ? IS_U32 : IS_U64;
        }
        default: assert(false); return IS_U32;
    }
}

inline const char *CodeGen::IntCT(IntStorage s) {
    switch (s) {
        case IS_I8:  return "int8_t";
        case IS_I16: return "int16_t";
        case IS_I32: return "int32_t";
        case IS_U8:  return "uint8_t";
        case IS_U16: return "uint16_t";
        case IS_U32: return "uint32_t";
        case IS_U64: return "uint64_t";
        default:     return "int64_t";
    }
}

// The runtime arithmetic helper suffix per integer type (runtime.h).
inline const char *CodeGen::IntSfx(IntStorage s) {
    switch (s) {
        case IS_I8:  return "i8";
        case IS_I16: return "i16";
        case IS_I32: return "i32";
        case IS_U8:  return "u8";
        case IS_U16: return "u16";
        case IS_U32: return "u32";
        case IS_U64: return "u64";
        default:     return "i64";
    }
}

// The C type behind a relative reference's unsigned width spelling:
// signed for a self-relative offset, which runs both ways from its own
// field, unsigned for an `in pool` one, which is a distance from the
// pool's base (§3.9).
inline const char *CodeGen::RelCT(IntStorage s, bool uns) {
    switch (IntSize(s)) {
        case 1: return uns ? "uint8_t" : "int8_t";
        case 2: return uns ? "uint16_t" : "int16_t";
        case 4: return uns ? "uint32_t" : "int32_t";
        default: return uns ? "uint64_t" : "int64_t";
    }
}

inline const char *CodeGen::RelCT(TypeExpr *rt) {
    return RelCT((IntStorage)rt->ref->lenstorage, rt->ref->pool != nullptr);
}

// StructInst / (EnumInst, variant).

// The alignment `pad` (bare form) gives the next field: its scalar width.
inline int64_t CodeGen::PadAlign(TypeExpr *t) {
    switch (t->kind) {
        case TY_INT: return t->intstorage == IS_VARINT ? 1 : IntSize(t->intstorage);
        case TY_FLT: return t->fltstorage == FS_F32 ? 4 : 8;
        case TY_REF: return t->ref->lenstorage >= 0 ?
                            (t->ref->lenstorage == IS_VARINT ? 1
                                                             : IntSize((IntStorage)t->ref->lenstorage))
                            : 8;
        case TY_SLICE: return 8;
        default: return 1;
    }
}

inline CodeGen::Layout CodeGen::LayoutFields(const vector<Field> &fields,
                                             const vector<TypeExpr *> &ftypes) {
    Layout lo;
    int64_t off = 0;
    for (size_t i = 0; i < fields.size(); i++) {
        auto &f = fields[i];
        if (f.ispad) {
            lo.offs.push_back(off);
            if (f.padsize >= 0) {
                off += f.padsize;
            } else {
                // Bare pad: align the next real field to its own size.
                TypeExpr *nt = nullptr;
                for (auto j = i + 1; j < fields.size(); j++)
                    if (!fields[j].ispad) { nt = ftypes[j]; break; }
                auto a = nt ? PadAlign(nt) : 1;
                off = (off + a - 1) / a * a;
            }
            continue;
        }
        lo.offs.push_back(off);
        off += FixedSize(ftypes[i]);
    }
    lo.size = off;
    return lo;
}

inline const CodeGen::Layout &CodeGen::StructLayout(StructInst *si) {
    auto key = pair<const void *, int>(si, -1);
    auto it = layouts.find(key);
    if (it != layouts.end()) return it->second;
    return layouts[key] = LayoutFields(si->st->fields, si->ftypes);
}

inline const CodeGen::Layout &CodeGen::VariantLayout(EnumInst *ei, int vi) {
    auto key = pair<const void *, int>(ei, vi);
    auto it = layouts.find(key);
    if (it != layouts.end()) return it->second;
    return layouts[key] = LayoutFields(ei->en->variants[vi].fields, ei->vftypes[vi]);
}

inline int64_t CodeGen::FixedSize(TypeExpr *t) {
    switch (t->kind) {
        case TY_INT:  assert(t->intstorage != IS_VARINT); return IntSize(t->intstorage);
        case TY_FLT:  return t->fltstorage == FS_F32 ? 4 : 8;
        case TY_BOOL: return 1;
        case TY_REF:
            if (t->ref->lenstorage >= 0) {
                assert(t->ref->lenstorage != IS_VARINT);
                return IntSize((IntStorage)t->ref->lenstorage);
            }
            return IsResz(t->ref->sub) ? 16 : 8;
        case TY_SLICE: return 16;
        case TY_STRUCT: {
            // An empty struct takes the one byte C gives it.
            auto sz = StructLayout(SI(t)).size;
            return sz ? sz : 1;
        }
        case TY_ENUM: {
            assert(!t->enu->varmode);
            auto ei = EIOf(t);
            int64_t maxp = 0;
            for (size_t vi = 0; vi < ei->en->variants.size(); vi++)
                maxp = std::max(maxp, VariantLayout(ei, (int)vi).size);
            return TagSize(ei->en) + maxp;
        }
        case TY_VARIANT: {
            auto ei = EIVar(t);
            return VariantLayout(ei, ei->en->VariantIndex(t->var->variant)).size;
        }
        case TY_ARRAY: {
            auto &a = *t->arr;
            switch (a.akind) {
                case A_FIXED:   return ArrSize(t->arr) * FixedSize(a.sub);
                case A_LIMITED: return IntSize(LenStore(t->arr)) +
                                       ArrSize(t->arr) * FixedSize(a.sub);
                default: assert(false); return 0;
            }
        }
        default: assert(false); return 0;
    }
}

// ------------------------------------------------------------------
// Naming: one global identifier space for types, functions, globals, and
// static data; per-function spaces for locals seeded from it.

// A name from the program as a C identifier. Every one of them carries the
// same suffix, which is what keeps the generated file free of collisions
// without a list of names to avoid: not the C keywords, not the runtime's own
// gs_ names, not the temporaries and labels below, and -- the reason a list
// could never be right -- not whatever the platform's headers happen to
// declare or define as a macro, which is not the same set on Windows as it is
// on Linux or macOS. Struct fields and enum variants get it too: those live in
// their own C namespace, but a macro does not respect namespaces.
//
// The one name that crosses into real C untouched is an `extern fn`'s symbol,
// which is the C name the declaration gives and never comes through here.
inline string CodeGen::Sanitize(string_view name) {
    string s(name);
    if (s.empty()) s = "_";
    // `result#1`, a name the parser makes that no program can write
    // (Parser::ParseMultiAssign); a local's C name is unique either way.
    for (auto &c : s) if (c == '#') c = '_';
    return s + "_g";
}

// A namespaced declaration (docs/design/namespaces.md): the namespace, the
// leaf, the suffix above, then the namespace's length. The digits are what
// keep the mapping injective -- `a::b_c` and `a_b::c` differ in them, and no
// global name's C form ends in a digit -- without a list of characters to
// replace.
inline string CodeGen::Sanitize(string_view ns, string_view name) {
    if (ns.empty()) return Sanitize(name);
    return cat(ns, "_", name, "_g", ns.size());
}

inline string CodeGen::Unique(string base) {
    if (!used.count(base)) { used.insert(base); return base; }
    for (auto n = 2;; n++) {
        auto s = cat(base, "_", n);
        if (!used.count(s)) { used.insert(s); return s; }
    }
}

// ------------------------------------------------------------------
// Mangled type identities and on-demand C type emission. The mangle keys
// every per-type artifact (typedef, size fn, eq fn); the C name is the
// uniquified mangle.

// The raw spelling does not tell every pair of types apart: `E<F..>` and
// `E<F>..` both spell E_g_F_g_vm, `E<G.B>` and `E<G>.B` both E_g_G_g_B_p,
// and `A<B>` spells what a struct named A_g_B does. The first type to spell
// one keeps it; a type of other parts (SameMangle) spelling it later gets a
// suffix, `_m1` and up, past every mangle already handed out. Parts are
// mangled here too, so a type built of told-apart ones is told apart too.
inline string CodeGen::Mangle(TypeExpr *t) {
    auto raw = RawMangle(t);
    auto &owners = mangleowners[raw];
    for (auto &[o, m] : owners)
        if (SameMangle(o, t)) return m;
    auto m = raw;
    for (auto n = 1; mangles.count(m); n++) m = cat(raw, "_m", n);
    mangles.insert(m);
    owners.push_back({ t, m });
    return m;
}

// Whether two types are made of the parts RawMangle spells: TEq, but for
// a nominal type its declaration and arguments rather than its instance,
// so that instances whose arguments differ only in `const`, which shares a
// layout, keep sharing their C types too.
inline bool CodeGen::SameMangle(TypeExpr *a, TypeExpr *b) {
    if (a == b) return true;
    if (a->kind != b->kind) return false;
    auto sameargs = [&](const vector<TypeExpr *> &x, const vector<TypeExpr *> &y) {
        if (x.size() != y.size()) return false;
        for (size_t i = 0; i < x.size(); i++)
            if (!SameMangle(x[i], y[i])) return false;
        return true;
    };
    switch (a->kind) {
        case TY_INT:
            return a->intstorage == b->intstorage && !a->ix == !b->ix &&
                   (!a->ix || (a->ix->arr == b->ix->arr && a->ix->upto == b->ix->upto));
        case TY_STRUCT:
            return a->struc->st == b->struc->st && sameargs(a->struc->args, b->struc->args);
        case TY_ENUM:
            return a->enu->en == b->enu->en && a->enu->varmode == b->enu->varmode &&
                   sameargs(a->enu->args, b->enu->args);
        case TY_VARIANT:
            return a->var->variant == b->var->variant && SameMangle(a->var->adt, b->var->adt);
        case TY_ARRAY: {
            auto &x = *a->arr, &y = *b->arr;
            if (x.akind != y.akind || !SameMangle(x.sub, y.sub)) return false;
            switch (x.akind) {
                case A_FIXED: case A_LIMITED: return ArrSize(a->arr) == ArrSize(b->arr);
                case A_VAR:                   return LenStore(a->arr) == LenStore(b->arr);
                default:                      return true;
            }
        }
        case TY_SLICE: return SameMangle(a->sub, b->sub);
        case TY_REF:
            return a->ref->optional == b->ref->optional &&
                   a->ref->lenstorage == b->ref->lenstorage &&
                   SameMangle(a->ref->sub, b->ref->sub);
        default: return TEq(a, b);
    }
}

inline string CodeGen::RawMangle(TypeExpr *t) {
    switch (t->kind) {
        case TY_INT: {
            if (t->intstorage == IS_VARINT) return "vi";
            if (!t->ix) return IntSfx(t->intstorage);
            // An index type is a C integer, but its array is part of its
            // identity, which per-type artifacts such as a verifier depend on.
            auto [it, fresh] = ixmangles.try_emplace(t->ix->arr, (int)ixmangles.size());
            (void)fresh;
            return cat(IntSfx(t->intstorage), t->ix->upto ? "b" : "x", it->second);
        }
        case TY_FLT: return t->fltstorage == FS_F32 ? "f32" : "f64";
        case TY_BOOL: return "b";
        case TY_STRUCT: {
            auto s = Sanitize(t->struc->st->ns, t->struc->st->name);
            for (auto a : t->struc->args) Append(s, "_", Mangle(a));
            return s;
        }
        case TY_ENUM: {
            auto s = Sanitize(t->enu->en->ns, t->enu->en->name);
            for (auto a : t->enu->args) Append(s, "_", Mangle(a));
            if (t->enu->varmode) s += "_vm";
            return s;
        }
        case TY_VARIANT: {
            auto s = Mangle(t->var->adt);
            Append(s, "_", t->var->variant->name, "_p");
            return s;
        }
        case TY_ARRAY: {
            auto &a = *t->arr;
            switch (a.akind) {
                case A_FIXED:   return cat("a", ArrSize(t->arr), "_", Mangle(a.sub));
                case A_VAR:     return cat("v", IntStorageName(LenStore(t->arr)), "_",
                                           Mangle(a.sub));
                case A_LIMITED: return ArrSize(t->arr) >= 0
                                    ? cat("l", ArrSize(t->arr), "_", Mangle(a.sub))
                                    : cat("lv_", Mangle(a.sub));
                case A_GROW:    return cat("gw_", Mangle(a.sub));
                default:        return cat("gx_", Mangle(a.sub));
            }
        }
        case TY_SLICE: return cat("sl_", Mangle(t->sub));
        case TY_REF: {
            auto &r = *t->ref;
            string s = r.optional ? "o" : "r";
            if (r.lenstorage >= 0) Append(s, "l", IntStorageName(r.lenstorage));
            Append(s, "_", Mangle(r.sub));
            return s;
        }
        default: assert(false); return "void";
    }
}

inline void CodeGen::EmitCoreTypes() {
    if (corebuiltins) return;
    corebuiltins = true;
    // A resizable value is a frame header (C.2): the data pointer (element
    // region for arrays, struct start for resizable-tailed structs) plus
    // the tail element count. A reference to one points at the header.
    tdecls +=
        "typedef struct { uint8_t *base; int64_t len; } gs_rhdr;\n"
        "typedef struct { gs_rhdr *hdr; gs_stack *stk; } gs_rref;\n"
        "typedef struct { gs_rhdr *hdr; gs_stack *stk; gs_rhdr *fl; gs_stack *flstk; } "
        "gs_pref;\n\n";
    used.insert("gs_rhdr");
    used.insert("gs_rref");
    used.insert("gs_pref");
}

// The C type of a fixed-class value (also refs/slices to anything). Emits
// the typedef on first use. Never valid for bytes-class values.
inline string CodeGen::CT(TypeExpr *t) {
    switch (t->kind) {
        case TY_INT:  assert(t->intstorage != IS_VARINT); return IntCT(t->intstorage);
        case TY_FLT:  return t->fltstorage == FS_F32 ? "float" : "double";
        case TY_BOOL: return "uint8_t";
        case TY_VOID: return "void";
        case TY_REF: {
            auto &r = *t->ref;
            if (r.lenstorage >= 0) {
                assert(r.lenstorage != IS_VARINT);
                return IntCT((IntStorage)r.lenstorage);   // Stored offset form.
            }
            EmitCoreTypes();
            if (IsResz(r.sub)) return "gs_rref";
            if (IsBytesT(r.sub)) return "uint8_t *";
            // A pointer needs only the pointee's name, so a node type can
            // hold references to itself and the body can come later.
            return cat(StructLike(r.sub) ? NameCT(r.sub) : CT(r.sub), " *");
        }
        default: break;
    }
    auto name = NameCT(t);
    auto m = Mangle(t);
    if (cdefined.count(m)) return name;
    // A variant's struct is a member of its enum's union. Emitting the enum
    // emits each variant's body ahead of the enum's own, also where a payload
    // names the enum again (through a slice), so a variant starts there.
    if (t->kind == TY_VARIANT && EIVar(t)->allfixed) {
        CT(t->var->adt);
        if (cdefined.count(m)) return name;
    }
    cdefined.insert(m);   // Before the body: recursion terminates via refs.
    string d;
    switch (t->kind) {
        case TY_SLICE: {
            if (StructLike(t->sub) && !IsBytesT(t->sub)) {
                // Like a reference, a slice needs only its element's name, and
                // the element's body may hold this slice (a node type with a
                // slice of its children): the typedef goes first, the body
                // after it.
                Append(tdecls, "typedef struct { ", NameCT(t->sub), " *data; int64_t len; } ",
                       name, ";\n\n");
                slicects.insert(name);
                CT(t->sub);
                return name;
            }
            auto e = IsBytesT(t->sub) ? string("uint8_t") : CT(t->sub);
            Append(d, "typedef struct { ", e, " *data; int64_t len; } ", name, ";\n");
            slicects.insert(name);
            break;
        }
        case TY_ARRAY: {
            auto &a = *t->arr;
            auto e = CT(a.sub);
            if (a.akind == A_FIXED) {
                auto k = ArrSize(t->arr);
                Append(d, "typedef struct { ", e, " e[", k ? k : 1, "]; } ", name, ";\n");
            } else {
                assert(a.akind == A_LIMITED && ArrSize(t->arr) >= 0);
                Append(d, "typedef struct { ", IntCT(LenStore(t->arr)), " len; ", e, " e[",
                       ArrSize(t->arr) ? ArrSize(t->arr) : 1, "]; } ", name, ";\n");
            }
            break;
        }
        case TY_STRUCT: {
            auto si = SI(t);
            Append(d, "struct ", name, " {\n");
            if (EmptyLayout(si->st->fields)) Append(d, "    uint8_t gs_empty;\n");
            else EmitCFields(d, si->st->fields, si->ftypes);
            Append(d, "};\n");
            break;
        }
        case TY_VARIANT: {
            auto ei = EIVar(t);
            auto vi = ei->en->VariantIndex(t->var->variant);
            auto &v = ei->en->variants[vi];
            Append(d, "struct ", name, " {\n");
            if (EmptyLayout(v.fields)) Append(d, "    uint8_t gs_empty;\n");
            else EmitCFields(d, v.fields, ei->vftypes[vi]);
            Append(d, "};\n");
            break;
        }
        case TY_ENUM: {
            assert(!t->enu->varmode);
            auto ei = EIOf(t);
            EnsureTagEnum(ei);
            Append(d, "struct ", name, " {\n    ", IntCT(TagStore(ei->en)), " tag;\n");
            string members;
            for (size_t vi = 0; vi < ei->en->variants.size(); vi++) {
                if (EmptyLayout(ei->en->variants[vi].fields)) continue;
                auto vt = VariantType(t, (int)vi);
                Append(members, "        ", CT(vt), " v_",
                       Sanitize(ei->en->variants[vi].name), ";\n");
            }
            if (!members.empty()) Append(d, "    union {\n", members, "    } u;\n");
            Append(d, "};\n");
            break;
        }
        default: assert(false);
    }
    tdecls += d;
    tdecls += "\n";
    return name;
}

// Fixed-class kinds that C declares as a named struct: they get a
// forward typedef the moment they are named (NameCT), so a reference to
// one needs only the name and the body follows when the type is first
// needed by value or through a pointer (PointeeLv).
inline bool CodeGen::StructLike(TypeExpr *t) {
    return t->kind == TY_STRUCT || t->kind == TY_VARIANT ||
           (t->kind == TY_ENUM && !t->enu->varmode);
}

// The C name of a fixed-class type, assigned (and, for struct-like kinds,
// forward-declared) on first sight; CT emits the body.
inline string CodeGen::NameCT(TypeExpr *t) {
    auto m = Mangle(t);
    auto it = ctypes.find(m);
    if (it != ctypes.end()) return it->second;
    EmitCoreTypes();
    auto name = Unique(m);
    ctypes[m] = name;
    if (StructLike(t)) Append(tdecls, "typedef struct ", name, " ", name, ";\n");
    return name;
}

inline void CodeGen::EmitCFields(string &d, const vector<Field> &fields,
                                 const vector<TypeExpr *> &ftypes) {
    // A frame object's tail is not part of the packed layout: it is the
    // tail's own header (or nested frame object) after the fixed fields.
    auto n = fields.size();
    while (n > 0 && ftypes[n - 1] && IsResz(ftypes[n - 1])) n--;
    vector<Field> pre(fields.begin(), fields.begin() + n);
    vector<TypeExpr *> pret(ftypes.begin(), ftypes.begin() + n);
    auto lo = LayoutFields(pre, pret);
    auto npad = 0;
    for (size_t i = 0; i < n; i++) {
        auto &f = fields[i];
        if (f.ispad) {
            auto next = i + 1 < n ? lo.offs[i + 1] : lo.size;
            auto sz = next - lo.offs[i];
            if (sz > 0) Append(d, "    uint8_t gs_pad", npad++, "[", sz, "];\n");
            continue;
        }
        Append(d, "    ", CT(ftypes[i]), " ", Sanitize(f.name), ";\n");
    }
    for (auto i = n; i < fields.size(); i++) {
        EmitCoreTypes();
        Append(d, "    ", RzCT(ftypes[i]), " ", Sanitize(fields[i].name), ";\n");
    }
}

inline void CodeGen::EnsureTagEnum(EnumInst *ei) {
    if (tagenums.count(ei)) return;
    tagenums.insert(ei);
    // Use the base (mode-less) mangle as the constant prefix, told apart
    // from another instance's as a mangle is (Mangle).
    string raw = Sanitize(ei->en->ns, ei->en->name);
    for (auto a : ei->args) Append(raw, "_", Mangle(a));
    auto base = raw;
    for (auto n = 1; !tagbases.insert(base).second; n++) base = cat(raw, "_m", n);
    tagprefix[ei] = base;
    string d = "enum {\n";
    for (size_t vi = 0; vi < ei->en->variants.size(); vi++)
        Append(d, "    ", base, "_", Sanitize(ei->en->variants[vi].name), "_k = ", vi,
               ",\n");
    d += "};\n\n";
    tdecls += d;
}

inline string CodeGen::TagConst(EnumInst *ei, int vi) {
    EnsureTagEnum(ei);
    return cat(tagprefix[ei], "_", Sanitize(ei->en->variants[vi].name), "_k");
}

inline TypeExpr *CodeGen::VariantType(TypeExpr *enumtype, int vi) {
    auto ei = EIOf(enumtype);
    auto key = pair<EnumInst *, int>(ei, vi);
    auto it = varianttypes.find(key);
    if (it != varianttypes.end()) return it->second;
    auto t = ast.VariantTypeOf(enumtype, &ei->en->variants[vi], enumtype->line);
    // The fixed-mode base made for a variable-mode enum names the same
    // instantiation.
    if (t->var->adt != enumtype) t->var->adt->enu->inst = ei;
    return varianttypes[key] = t;
}

// ------------------------------------------------------------------
// Runtime size of a bytes-class value: a generated per-type walker,
// gs_size_<mangle>(p). Static-size subruns collapse into constants.

// A C expression for the size of the value of type t at ptr; emits the
// walker function on demand for dynamic types.
inline string CodeGen::SizeX(TypeExpr *t, const string &ptr) {
    if (IsFix(t)) return cat(FixedSize(t));
    return cat(SizeFn(t), "(", ptr, ")");
}

inline string CodeGen::SizeFn(TypeExpr *t) {
    auto m = Mangle(t);
    auto name = cat("gs_size_", m);
    if (sizefns.count(m)) return name;
    sizefns.insert(m);
    Append(protos, "static int64_t ", name, "(const uint8_t *p);\n");
    string b;
    Append(b, "static int64_t ", name, "(const uint8_t *p) {\n");
    Append(b, "    const uint8_t *q = p;\n");
    EmitSizeWalk(b, t, "q");
    Append(b, "    return q - p;\n}\n\n");
    code += b;
    return name;
}

// Appends statements advancing cursor `q` over one value of type t.
inline void CodeGen::EmitSizeWalk(string &b, TypeExpr *t, const string &q) {
    if (IsFix(t)) {
        Append(b, "    ", q, " += ", FixedSize(t), ";\n");
        return;
    }
    switch (t->kind) {
        case TY_INT:   // varint
            Append(b, "    ", q, " += gs_uleb_size(", q, ");\n");
            return;
        case TY_REF:   // varint-width relative reference
            Append(b, "    ", q, " += gs_uleb_size(", q, ");\n");
            return;
        case TY_ARRAY: {
            auto &a = *t->arr;
            switch (a.akind) {
                case A_VAR: {
                    auto ls = LenStore(t->arr);
                    if (ls == IS_VARINT)
                        Append(b, "    { int64_t n = GS_ULEB_READ(", q, "); ", q,
                               " += GS_ULEB_SIZE(", q, ");\n");
                    else
                        Append(b, "    { int64_t n = (int64_t)*(", IntCT(ls), " *)", q,
                               "; ", q, " += ", IntSize(ls), ";\n");
                    EmitSizeElems(b, a.sub, q);
                    Append(b, "    }\n");
                    return;
                }
                case A_LIMITED:   // Runtime capacity: [cap u32][len u32][cap slots].
                    Append(b, "    ", q, " += 8 + (int64_t)*(uint32_t *)", q, " * ",
                           FixedSize(a.sub), ";\n");
                    return;
                default:
                    // Resizable values never nest inside bytes values;
                    // their length lives in a frame header (C.2).
                    assert(false);
                    return;
            }
        }
        case TY_STRUCT: case TY_VARIANT:
            for (auto &run : FieldRuns(t)) {
                for (size_t i = 0; i < run.fields->size(); i++) {
                    auto &f = (*run.fields)[i];
                    // Bytes layouts have no bare-pad alignment; explicit pads count.
                    if (f.ispad) {
                        if (f.padsize > 0) Append(b, "    ", q, " += ", f.padsize, ";\n");
                        continue;
                    }
                    EmitSizeWalk(b, (*run.ftypes)[i], q);
                }
            }
            return;
        case TY_ENUM: {
            auto ei = EIOf(t);
            auto ts = TagSize(ei->en);
            Append(b, "    switch (*(", IntCT(TagStore(ei->en)), " *)", q, ") {\n");
            for (size_t vi = 0; vi < ei->en->variants.size(); vi++) {
                Append(b, "    case ", vi, ": { ", q, " += ", ts, ";\n");
                string inner;
                EmitSizeWalk(inner, VariantType(t, (int)vi), q);
                b += inner;
                Append(b, "    } break;\n");
            }
            Append(b, "    }\n");
            return;
        }
        default: assert(false); return;
    }
}

inline void CodeGen::EmitSizeElems(string &b, TypeExpr *elem, const string &q) {
    if (IsFix(elem)) {
        Append(b, "    ", q, " += n * ", FixedSize(elem), ";\n");
    } else {
        Append(b, "    for (int64_t i = 0; i < n; i++) ", q, " += ", SizeFn(elem), "(",
               q, ");\n");
    }
}

// The fewest bytes any value of this type can occupy: what bounds the
// element count a length field may claim, before a single element is walked.
// With `zero`, the size of the all-zeroes value instead, whose arrays are
// empty and whose ADTs are at variant 0: what a missed qpoll writes so the
// value stays valid.
inline int64_t CodeGen::MinBytes(TypeExpr *t, bool zero) {
    if (IsFix(t)) return FixedSize(t);
    switch (t->kind) {
        case TY_INT: case TY_REF: return 1;   // varint / varint-width relative ref
        case TY_ARRAY:
            switch (t->arr->akind) {
                case A_VAR:     return PrefixBytes(LenStore(t->arr));
                case A_LIMITED: return 8;     // runtime capacity: [cap][len]
                default:        return 0;
            }
        case TY_STRUCT: case TY_VARIANT: {
            int64_t n = 0;
            for (auto &run : FieldRuns(t)) {
                for (size_t i = 0; i < run.fields->size(); i++) {
                    auto &f = (*run.fields)[i];
                    if (f.ispad) { if (f.padsize > 0) n += f.padsize; continue; }
                    n += MinBytes((*run.ftypes)[i], zero);
                }
            }
            return n;
        }
        case TY_ENUM: {
            auto ei = EIOf(t);
            if (zero) return TagSize(ei->en) + MinBytes(VariantType(t, 0), true);
            int64_t m = INT64_MAX;
            for (size_t vi = 0; vi < ei->en->variants.size(); vi++)
                m = std::min(m, MinBytes(VariantType(t, (int)vi)));
            return TagSize(ei->en) + m;
        }
        default: return 0;
    }
}

// ------------------------------------------------------------------
// The verifier from_bytes runs over an untrusted image
// (docs/design/serialization.md §5).

// Does a value of this type hold a relative reference at any depth? Unlike
// HasRelRef this looks through variable-size types too, since an image's
// elements are exactly the types HasRelRef does not reach.
inline bool CodeGen::HasRelRefAny(TypeExpr *t) {
    return HasRelRefOf(t, true, [&](TypeExpr *x) { return FieldRuns(x); });
}

// Whether the verifier has anything to say about a value of this type, or
// can simply skip its bytes: a fixed value with no ADT tag to range-check,
// no boolean to validate, limited-array length to bound or relative reference to follow is
// opaque payload either way.
inline bool CodeGen::NeedsVerifyWalk(TypeExpr *t) {
    if (!IsFix(t)) return true;
    switch (t->kind) {
        case TY_BOOL: return true;
        case TY_INT:  return t->ix != nullptr;         // checked against its array
        case TY_REF:  return t->ref->lenstorage >= 0;
        case TY_ENUM: return true;                     // the tag is range-checked
        case TY_ARRAY:
            return t->arr->akind == A_LIMITED || NeedsVerifyWalk(t->arr->sub);
        case TY_STRUCT: case TY_VARIANT:
            return AnyField(t, [&](TypeExpr *ft) { return NeedsVerifyWalk(ft); });
        default: return false;
    }
}

inline void CodeGen::VNeed(string &b, const string &q, const string &bytes) {
    Append(b, "    if (n - ", q, " < ", bytes, ") return -1;\n");
}

// gs_verify_<T>(p, n, bm): the element count of the image at p, or -1 if
// those bytes are not one (serialization.md §3). Fixed elements start at
// multiples of their size, so their links are checked in the same pass that
// frames them; variable ones need the framing pass to record the starts in
// `bm` before a second pass can check a link against them.
inline string CodeGen::VerifyFn(TypeExpr *elem) {
    auto m = Mangle(elem);
    auto name = cat("gs_verify_", m);
    if (verifyfns.count(m)) return name;
    verifyfns.insert(m);
    Append(protos, "static int64_t ", name, "(const uint8_t *p, int64_t n, uint8_t *bm);\n");
    vtmpn = 0;
    string b;
    Append(b, "static int64_t ", name, "(const uint8_t *p, int64_t n, uint8_t *bm) {\n");
    // A type whose values can occupy no bytes has no recoverable element
    // count: only the empty image is one of its arrays.
    if (MinBytes(elem) <= 0) {
        Append(b, "    (void)p; (void)bm;\n    return n == 0 ? 0 : -1;\n}\n\n");
        code += b;
        return name;
    }
    auto fixed = IsFix(elem);
    auto rel = HasRelRefAny(elem);
    Append(b, "    const uint8_t *e = p + n;\n");
    Append(b, "    int64_t q = 0, cnt = 0;\n");
    Append(b, "    (void)e; (void)bm;\n");
    Append(b, "    while (q < n) {\n");
    if (!fixed && rel) Append(b, "        GS_BM_SET(bm, q);\n");
    EmitVerifyWalk(b, elem, elem, "q", fixed && rel);
    Append(b, "        cnt++;\n");
    Append(b, "    }\n");
    Append(b, "    if (q != n) return -1;\n");
    if (!fixed && rel) {
        Append(b, "    q = 0;\n");
        Append(b, "    while (q < n) {\n");
        EmitVerifyWalk(b, elem, elem, "q", true);
        Append(b, "    }\n");
    }
    Append(b, "    return cnt;\n}\n\n");
    code += b;
    return name;
}

// One self-relative reference at field offset `q` holding `off`: the target
// must be the start of an element of the image, and, where the reference is
// typed at a variant of the element ADT, an element carrying that tag (§3
// step 3). Offset 0 is null, and only an optional reference may hold it.
inline void CodeGen::EmitVerifyLink(string &b, TypeExpr *rt, TypeExpr *elem, const string &q,
                                    const string &off) {
    auto v = VTmp();
    // A reference typed at a variant addresses the *payload*, which is the
    // element start past the tag; everything else addresses the start.
    auto pt = rt->ref->sub;
    auto variant = pt->kind == TY_VARIANT && elem->kind == TY_ENUM;
    int64_t skip = 0, vi = 0;
    IntStorage ts = IS_U8;
    if (variant) {
        auto ei = EIVar(pt);
        vi = ei->en->VariantIndex(pt->var->variant);
        ts = TagStore(ei->en);
        skip = IntSize(ts);
    }
    if (rt->ref->optional) Append(b, "    if (", off, " != 0) {\n");
    else                   Append(b, "    {\n");
    // A variant reference field is already past the element tag, so removing
    // the tag size leaves a nonnegative base. Bound the untrusted offset
    // against the image before adding it, so the target cannot overflow.
    Append(b, "        int64_t ", v, " = ", q, skip ? cat(" - ", skip) : string(), ";\n");
    Append(b, "        if (", off, " < -", v, " || ", off, " >= n - ", v, ") return -1;\n");
    Append(b, "        ", v, " += ", off, ";\n");
    if (IsFix(elem))
        Append(b, "        if (", v, " % ",
               std::max<int64_t>(FixedSize(elem), 1), ") return -1;\n");
    else
        Append(b, "        if (!GS_BM_GET(bm, ", v,
               ")) return -1;\n");
    if (variant)
        Append(b, "        if (n - ", v, " < ", skip, " || *(const ", IntCT(ts), " *)(p + ",
               v, ") != ", vi, ") return -1;\n");
    Append(b, "    }\n");
}

// A run of fields. `lo` is the packed layout of a fixed struct or variant,
// whose field offsets may include alignment padding a sequential walk would
// miss; bytes layouts have none and pass null.
inline void CodeGen::EmitVerifyFields(string &b, const vector<Field> &fields,
                                      const vector<TypeExpr *> &ftypes, const Layout *lo,
                                      int64_t total, TypeExpr *elem, const string &q,
                                      bool links) {
    string start;
    if (lo) {
        start = VTmp();
        Append(b, "    int64_t ", start, " = ", q, ";\n");
        VNeed(b, q, cat(total));
    }
    for (size_t i = 0; i < fields.size(); i++) {
        auto &f = fields[i];
        if (f.ispad) {
            if (!lo && f.padsize > 0) Append(b, "    ", q, " += ", f.padsize, ";\n");
            continue;
        }
        if (lo && !NeedsVerifyWalk(ftypes[i])) continue;
        if (lo) Append(b, "    ", q, " = ", start, " + ", lo->offs[i], ";\n");
        EmitVerifyWalk(b, ftypes[i], elem, q, links);
    }
    if (lo) Append(b, "    ", q, " = ", start, " + ", total, ";\n");
}

// The checks and cursor advance for one value of type t at byte offset `q`
// of the image; any failure returns -1 from the enclosing verifier.
inline void CodeGen::EmitVerifyWalk(string &b, TypeExpr *t, TypeExpr *elem, const string &q,
                                    bool links) {
    if (!NeedsVerifyWalk(t)) {
        auto sz = FixedSize(t);
        if (sz > 0) {
            VNeed(b, q, cat(sz));
            Append(b, "    ", q, " += ", sz, ";\n");
        }
        return;
    }
    switch (t->kind) {
        case TY_BOOL:
            VNeed(b, q, "1");
            Append(b, "    if (p[", q, "] > 1) return -1;\n    ", q, "++;\n");
            return;
        case TY_INT: {
            if (t->ix) {
                // An index or bound type: an image's value must be one of the
                // array as it is now, which it stays (§3.11).
                auto sz = IntSize(t->intstorage);
                auto v = VTmp();
                VNeed(b, q, cat(sz));
                Append(b, "    { ", IntCT(t->intstorage), " ", v, "; GS_MEMCPY(&", v, ", p + ", q,
                       ", ", sz, "); if ((uint64_t)", v, t->ix->upto ? " > " : " >= ",
                       "(uint64_t)", GlobalLenLv(t->ix->arr), ") return -1; ", q, " += ", sz,
                       "; }\n");
                return;
            }
            // A varint field: only its length matters to the walk.
            auto v = VTmp();
            Append(b, "    { uint64_t ", v, "u; int64_t ", v, " = gs_uleb_check(p + ", q,
                   ", e, &", v, "u); if (!", v, ") return -1; ", q, " += ", v, "; }\n");
            return;
        }
        case TY_REF: {
            // The framing pass only has to get past the offset; the link
            // pass is the one that needs its value.
            auto w = (IntStorage)t->ref->lenstorage;
            auto v = VTmp();
            Append(b, "    {\n");
            if (w == IS_VARINT) {
                if (links) {
                    Append(b, "        int64_t ", v, "o;\n");
                    Append(b, "        int64_t ", v, "k = gs_zig_check(p + ", q, ", e, &", v,
                           "o);\n");
                } else {
                    Append(b, "        uint64_t ", v, "u;\n");
                    Append(b, "        int64_t ", v, "k = gs_uleb_check(p + ", q, ", e, &", v,
                           "u);\n");
                    Append(b, "        (void)", v, "u;\n");
                }
                Append(b, "        if (!", v, "k) return -1;\n");
            } else {
                Append(b, "        if (n - ", q, " < ", IntSize(w), ") return -1;\n");
                if (links)
                    Append(b, "        int64_t ", v, "o = (int64_t)*(const ", RelCT(t),
                           " *)(p + ", q, ");\n");
            }
            if (links) EmitVerifyLink(b, t, elem, q, cat(v, "o"));
            Append(b, "        ", q, " += ", w == IS_VARINT ? cat(v, "k") : cat(IntSize(w)),
                   ";\n");
            Append(b, "    }\n");
            return;
        }
        case TY_ARRAY: {
            auto &a = *t->arr;
            switch (a.akind) {
                case A_FIXED: {
                    auto i = VTmp();
                    Append(b, "    for (int64_t ", i, " = 0; ", i, " < ", ArrSize(t->arr),
                           "; ", i, "++) {\n");
                    EmitVerifyWalk(b, a.sub, elem, q, links);
                    Append(b, "    }\n");
                    return;
                }
                case A_VAR: {
                    auto ls = LenStore(t->arr);
                    auto v = VTmp();
                    Append(b, "    {\n");
                    Append(b, "        int64_t ", v, "n;\n");
                    if (ls == IS_VARINT) {
                        Append(b, "        uint64_t ", v, "u;\n");
                        Append(b, "        int64_t ", v, "k = gs_uleb_check(p + ", q, ", e, &",
                               v, "u);\n");
                        Append(b, "        if (!", v, "k || ", v, "u > (uint64_t)INT64_MAX) "
                               "return -1;\n");
                        Append(b, "        ", v, "n = (int64_t)", v, "u; ", q, " += ", v,
                               "k;\n");
                    } else {
                        Append(b, "        if (n - ", q, " < ", IntSize(ls), ") return -1;\n");
                        Append(b, "        ", v, "n = (int64_t)*(const ", IntCT(ls), " *)(p + ",
                               q, "); ", q, " += ", IntSize(ls), ";\n");
                    }
                    Append(b, "        if (", v, "n < 0 || ", v, "n > (n - ", q, ") / ",
                           std::max<int64_t>(MinBytes(a.sub), 1), ") return -1;\n");
                    if (!NeedsVerifyWalk(a.sub)) {
                        Append(b, "        ", q, " += ", v, "n * ", FixedSize(a.sub), ";\n");
                    } else {
                        auto i = VTmp();
                        Append(b, "        for (int64_t ", i, " = 0; ", i, " < ", v, "n; ", i,
                               "++) {\n");
                        EmitVerifyWalk(b, a.sub, elem, q, links);
                        Append(b, "        }\n");
                    }
                    Append(b, "    }\n");
                    return;
                }
                case A_LIMITED: {
                    // Slots past the length were never written (§5.3), so
                    // only the live ones are walked; the cursor still skips
                    // the whole capacity.
                    auto v = VTmp();
                    auto esz = std::max<int64_t>(FixedSize(a.sub), 1);
                    auto stat = IsFix(t);
                    Append(b, "    {\n");
                    Append(b, "        int64_t ", v, "s = ", q, ", ", v, "n;\n");
                    if (stat) {
                        auto ls = LenStore(t->arr);
                        Append(b, "        if (n - ", q, " < ", FixedSize(t), ") return -1;\n");
                        Append(b, "        ", v, "n = (int64_t)*(const ", IntCT(ls), " *)(p + ",
                               q, ");\n");
                        Append(b, "        if (", v, "n < 0 || ", v, "n > ", ArrSize(t->arr),
                               ") return -1;\n");
                        Append(b, "        ", q, " += ", IntSize(ls), ";\n");
                    } else {
                        Append(b, "        int64_t ", v, "c;\n");
                        Append(b, "        if (n - ", q, " < 8) return -1;\n");
                        Append(b, "        ", v, "c = (int64_t)*(const uint32_t *)(p + ", q,
                               ");\n");
                        Append(b, "        ", v, "n = (int64_t)*(const uint32_t *)(p + ", q,
                               " + 4);\n");
                        Append(b, "        if (", v, "n > ", v, "c || ", v, "c > (n - ", q,
                               " - 8) / ", esz, ") return -1;\n");
                        Append(b, "        ", q, " += 8;\n");
                    }
                    if (NeedsVerifyWalk(a.sub)) {
                        auto i = VTmp();
                        Append(b, "        for (int64_t ", i, " = 0; ", i, " < ", v, "n; ", i,
                               "++) {\n");
                        EmitVerifyWalk(b, a.sub, elem, q, links);
                        Append(b, "        }\n");
                    }
                    if (stat)
                        Append(b, "        ", q, " = ", v, "s + ", FixedSize(t), ";\n");
                    else
                        Append(b, "        ", q, " = ", v, "s + 8 + ", v, "c * ",
                               FixedSize(a.sub), ";\n");
                    Append(b, "    }\n");
                    return;
                }
                default: assert(false); return;
            }
        }
        case TY_STRUCT: {
            auto si = SI(t);
            auto fix = IsFix(t);
            EmitVerifyFields(b, si->st->fields, si->ftypes, fix ? &StructLayout(si) : nullptr,
                             fix ? FixedSize(t) : 0, elem, q, links);
            return;
        }
        case TY_VARIANT: {
            auto ei = EIVar(t);
            auto vi = ei->en->VariantIndex(t->var->variant);
            auto fix = IsFix(t);
            EmitVerifyFields(b, ei->en->variants[vi].fields, ei->vftypes[vi],
                             fix ? &VariantLayout(ei, vi) : nullptr, fix ? FixedSize(t) : 0,
                             elem, q, links);
            return;
        }
        case TY_ENUM: {
            // The tag is range-checked in both modes: a `match` compiles to
            // a C switch with no default, so an out-of-range one would be a
            // jump into nothing.
            auto ei = EIOf(t);
            auto ts = TagStore(ei->en);
            auto nv = (int64_t)ei->en->variants.size();
            auto fix = !t->enu->varmode;
            auto v = VTmp();
            Append(b, "    {\n");
            if (fix) Append(b, "        int64_t ", v, "s = ", q, ";\n");
            Append(b, "        int64_t ", v, "t;\n");
            Append(b, "        if (n - ", q, " < ", fix ? FixedSize(t) : IntSize(ts),
                   ") return -1;\n");
            Append(b, "        ", v, "t = (int64_t)*(const ", IntCT(ts), " *)(p + ", q, ");\n");
            Append(b, "        if ((uint64_t)", v, "t >= ", nv, "u) return -1;\n");
            Append(b, "        ", q, " += ", IntSize(ts), ";\n");
            Append(b, "        switch (", v, "t) {\n");
            for (int64_t i = 0; i < nv; i++) {
                auto vt = VariantType(t, (int)i);
                Append(b, "        case ", i, ": {\n");
                if (!fix || NeedsVerifyWalk(vt)) EmitVerifyWalk(b, vt, elem, q, links);
                Append(b, "        } break;\n");
            }
            Append(b, "        default: return -1;\n");
            Append(b, "        }\n");
            if (fix) Append(b, "        ", q, " = ", v, "s + ", FixedSize(t), ";\n");
            Append(b, "    }\n");
            return;
        }
        default: assert(false); return;
    }
}

// ------------------------------------------------------------------
// default<T>() (§4.2): all-zero bytes are the default of every fixed type
// -- numbers, false, null, empty slices and limited arrays, variant 0 --
// except where a field declares its own default, which the checker
// builds as a literal of the call's own (Call::defaultinit).

// Does any field at any depth of a fixed type declare a default value? An
// empty array has no fields.
inline bool CodeGen::HasFieldDefaults(TypeExpr *t) {
    switch (t->kind) {
        case TY_STRUCT: case TY_ENUM: case TY_VARIANT: {
            if (t->kind == TY_ENUM && t->enu->varmode) return false;
            auto runs = FieldRuns(t);
            if (t->kind == TY_ENUM) runs = runs.first(1);   // Variant 0 is the default variant.
            for (auto &run : runs)
                for (size_t i = 0; i < run.fields->size(); i++) {
                    auto &f = (*run.fields)[i];
                    if (!f.ispad && (f.defaultval || HasFieldDefaults((*run.ftypes)[i])))
                        return true;
                }
            return false;
        }
        case TY_ARRAY:
            return t->arr->akind == A_FIXED && ArrSize(t->arr) > 0 &&
                   HasFieldDefaults(t->arr->sub);
        default: return false;
    }
}

// Writes the default value of fixed type t into the C lvalue lv. A type
// with a declared field default anywhere in it never gets here: the
// checker builds its default as a literal (TypeCheck::CheckBuiltin).
inline void CodeGen::EmitDefaultInto(const string &lv, TypeExpr *t) {
    assert(!HasFieldDefaults(t));
    L("GS_MEMZERO(&", lv, ", sizeof(", lv, "));");
}

// ------------------------------------------------------------------
// Structural equality (§4.5): gs_eq_<mangle>. Fixed values pass by value,
// bytes values as pointers. Gap-free fixed types without floats of more
// than a few scalars shortcut to memcmp.

inline bool CodeGen::BitwiseEq(TypeExpr *t) {
    if (!IsFix(t)) return false;
    switch (t->kind) {
        case TY_STRUCT: case TY_VARIANT:
            for (auto &run : FieldRuns(t))
                for (size_t i = 0; i < run.fields->size(); i++)
                    if ((*run.fields)[i].ispad || !BitwiseEq((*run.ftypes)[i])) return false;
            return true;
        case TY_ENUM: return false;      // Uninitialized trailing payload area.
        case TY_ARRAY:
            if (t->arr->akind == A_LIMITED) return false;   // Uninitialized slots.
            return BitwiseEq(t->arr->sub);
        case TY_FLT: return false;       // IEEE: -0.0 == 0.0, NaN != NaN.
        default: return true;
    }
}

inline bool CodeGen::ScalarEq(TypeExpr *t) {
    return t->kind == TY_INT || t->kind == TY_FLT || t->kind == TY_BOOL ||
           (t->kind == TY_REF && t->ref->lenstorage < 0 && !IsFatRef(t));
}

// How many scalars an equality test of fixed type t compares, counting
// no further than cap. A leaf EqX has no comparison of its own for (a
// relative reference, a function) counts as cap, which keeps memcmp.
inline int64_t CodeGen::EqScalars(TypeExpr *t, int64_t cap) {
    switch (t->kind) {
        case TY_STRUCT: case TY_VARIANT: {
            int64_t n = 0;
            for (auto &run : FieldRuns(t))
                for (size_t i = 0; i < run.fields->size() && n < cap; i++)
                    if (!(*run.fields)[i].ispad) n += EqScalars((*run.ftypes)[i], cap - n);
            return min(n, cap);
        }
        case TY_ARRAY: {
            auto per = EqScalars(t->arr->sub, cap);
            auto size = ArrSize(t->arr);
            return per && size > cap / per ? cap : per * size;
        }
        default:
            return ScalarEq(t) || (t->kind == TY_REF && IsFatRef(t)) ||
                   (t->kind == TY_SLICE && !IsBytesT(t->sub)) ? 1 : cap;
    }
}

// Equality of two values as a C expression; a/b are values (fixed) or
// byte pointers (bytes-class). May emit an eq function.
inline string CodeGen::EqX(TypeExpr *t, const string &a, const string &b) {
    if (ScalarEq(t)) return cat("(", a, " == ", b, ")");
    if (t->kind == TY_REF && IsFatRef(t))
        return cat("(", a, ".hdr == ", b, ".hdr)");
    if (t->kind == TY_SLICE && !IsBytesT(t->sub))
        return cat("(", a, ".data == ", b, ".data && ", a, ".len == ", b, ".len)");
    if (IsFix(t)) {
        // A few scalars compare one by one, in an eq function the C compiler
        // inlines. Through memcmp, an operand just built in registers would
        // be stored field by field and read back in one wider load, which
        // store forwarding cannot serve.
        if (BitwiseEq(t) && EqScalars(t, 5) > 4)
            return cat("(memcmp(&", a, ", &", b, ", ", FixedSize(t), ") == 0)");
        return cat(EqFn(t), "(&", a, ", &", b, ")");
    }
    return cat(EqFn(t), "(", a, ", ", b, ")");
}

inline string CodeGen::EqFn(TypeExpr *t) {
    auto m = Mangle(t);
    auto name = cat("gs_eq_", m);
    if (eqfns.count(m)) return name;
    eqfns.insert(m);
    auto bytes = IsBytesT(t);
    auto sig = bytes ? cat("static uint8_t ", name, "(const uint8_t *a, const uint8_t *b)")
                     : cat("static uint8_t ", name, "(const ", CT(t), " *a, const ", CT(t),
                           " *b)");
    Append(protos, sig, ";\n");
    string bo;
    Append(bo, sig, " {\n");
    if (bytes) EmitEqBytes(bo, t);
    else EmitEqFixed(bo, t);
    Append(bo, "}\n\n");
    code += bo;
    return name;
}

inline void CodeGen::EmitEqFixed(string &bo, TypeExpr *t) {
    switch (t->kind) {
        case TY_STRUCT: {
            auto si = SI(t);
            for (size_t i = 0; i < si->st->fields.size(); i++) {
                auto &f = si->st->fields[i];
                if (f.ispad) continue;
                auto fn = Sanitize(f.name);
                Append(bo, "    if (!", EqX(si->ftypes[i], cat("a->", fn), cat("b->", fn)),
                       ") return 0;\n");
            }
            Append(bo, "    return 1;\n");
            return;
        }
        case TY_VARIANT: {
            auto ei = EIVar(t);
            auto vi = ei->en->VariantIndex(t->var->variant);
            auto &v = ei->en->variants[vi];
            for (size_t i = 0; i < v.fields.size(); i++) {
                if (v.fields[i].ispad) continue;
                auto fn = Sanitize(v.fields[i].name);
                Append(bo, "    if (!", EqX(ei->vftypes[vi][i], cat("a->", fn),
                                            cat("b->", fn)), ") return 0;\n");
            }
            Append(bo, "    return 1;\n");
            return;
        }
        case TY_ENUM: {
            auto ei = EIOf(t);
            Append(bo, "    if (a->tag != b->tag) return 0;\n    switch (a->tag) {\n");
            for (size_t vi = 0; vi < ei->en->variants.size(); vi++) {
                if (EmptyLayout(ei->en->variants[vi].fields)) continue;
                auto un = cat("u.v_", Sanitize(ei->en->variants[vi].name));
                Append(bo, "    case ", TagConst(ei, (int)vi), ": return ",
                       EqX(VariantType(t, (int)vi), cat("a->", un), cat("b->", un)),
                       ";\n");
            }
            Append(bo, "    default: return 1;\n    }\n");
            return;
        }
        case TY_ARRAY: {
            auto &a = *t->arr;
            if (a.akind == A_FIXED) {
                Append(bo, "    for (int64_t i = 0; i < ", ArrSize(t->arr), "; i++)\n",
                       "        if (!", EqX(a.sub, "a->e[i]", "b->e[i]"), ") return 0;\n",
                       "    return 1;\n");
            } else if (BitwiseEq(a.sub) && ArrSize(t->arr) > 0) {
                // Limited, static capacity, of elements equal exactly when
                // their bytes are: the live bytes compared as a run.
                auto esz = FixedSize(a.sub);
                auto bytes = ArrSize(t->arr) * esz;
                auto lw = IntSize(LenStore(t->arr));
                Append(bo, "    if (a->len != b->len) return 0;\n");
                if (bytes <= 64 && lw + bytes >= 8) {
                    // Whole words over the value's own storage, the bytes
                    // past the length masked off: no branch on the data.
                    // A last word that would end past the slots ends at the
                    // value's end instead, starting inside the slots or the
                    // length before them, both equal on both sides by now.
                    Append(bo, "    int64_t n = (int64_t)a->len * ", esz, ";\n",
                           "    const uint8_t *pa = (const uint8_t *)a->e, ",
                           "*pb = (const uint8_t *)b->e;\n",
                           "    uint64_t d = 0;\n");
                    auto word = [&](int64_t w) {
                        auto at = w < 0 ? cat(" - ", -w) : w ? cat(" + ", w) : string();
                        Append(bo, "    d |= (gs_ld64(pa", at, ") ^ gs_ld64(pb", at,
                               ")) & gs_bytemask(n", w < 0 ? cat(" + ", -w) : w ? cat(" - ", w)
                                                                             : string(),
                               ");\n");
                    };
                    int64_t w = 0;
                    for (; w + 8 <= bytes; w += 8) word(w);
                    if (w < bytes) word(bytes - 8);
                    Append(bo, "    return d == 0;\n");
                } else {
                    Append(bo, "    return gs_memeq(a->e, b->e, (size_t)a->len * ", esz,
                           ");\n");
                }
            } else {   // Limited, static capacity.
                Append(bo, "    if (a->len != b->len) return 0;\n",
                       "    for (int64_t i = 0; i < (int64_t)a->len; i++)\n",
                       "        if (!", EqX(a.sub, "a->e[i]", "b->e[i]"), ") return 0;\n",
                       "    return 1;\n");
            }
            return;
        }
        default: assert(false); return;
    }
}

inline void CodeGen::EmitEqBytes(string &bo, TypeExpr *t) {
    // Canonical encodings (minimal varints) make bytewise comparison exact
    // for any pad-free, float-free bytes value; walk-compare covers the rest.
    auto bitwise = [&](TypeExpr *tt) {
        // Bytes layouts have no bare-pad alignment, but explicit pads,
        // embedded fixed-mode ADTs and floats still defeat memcmp.
        function<bool(TypeExpr *)> rec = [&](TypeExpr *x) -> bool {
            if (IsFix(x)) return BitwiseEq(x);
            switch (x->kind) {
                case TY_INT: case TY_REF: return true;
                // A runtime-capacity limited array's capacity and the slots
                // past its length are no part of its value.
                case TY_ARRAY: return x->arr->akind != A_LIMITED && rec(x->arr->sub);
                case TY_STRUCT: case TY_VARIANT: case TY_ENUM:
                    for (auto &run : FieldRuns(x))
                        for (size_t i = 0; i < run.fields->size(); i++)
                            if ((*run.fields)[i].ispad || !rec((*run.ftypes)[i])) return false;
                    return true;
                default: return false;
            }
        };
        return rec(tt);
    };
    if (bitwise(t)) {
        Append(bo, "    int64_t na = ", SizeX(t, "a"), ", nb = ", SizeX(t, "b"), ";\n",
               "    return na == nb && memcmp(a, b, (size_t)na) == 0;\n");
        return;
    }
    // Structural walk with a cursor pair; limited-capacity arrays compare
    // length + live elements, everything else in field order.
    Append(bo, "    const uint8_t *pa = a, *pb = b;\n");
    EmitEqWalk(bo, t, "pa", "pb", 1);
    Append(bo, "    return 1;\n");
}

// Compares one value at *pa/*pb (advancing both); returns 0 on mismatch.
inline void CodeGen::EmitEqWalk(string &bo, TypeExpr *t, const string &pa, const string &pb,
                                int depth) {
    auto I = string("    ");
    if (IsFix(t)) {
        CT(t);   // The comparison below needs the type's C form emitted.
        if (BitwiseEq(t)) {
            Append(bo, I, "if (memcmp(", pa, ", ", pb, ", ", FixedSize(t),
                   ") != 0) return 0;\n");
        } else {
            Append(bo, I, "if (!", EqX(t, cat("(*(", CT(t), " *)", pa, ")"),
                                       cat("(*(", CT(t), " *)", pb, ")")), ") return 0;\n");
        }
        Append(bo, I, pa, " += ", FixedSize(t), "; ", pb, " += ", FixedSize(t), ";\n");
        return;
    }
    switch (t->kind) {
        case TY_INT: case TY_REF: {  // varint / varint relref: canonical bytes.
            Append(bo, I, "{ int64_t n = gs_uleb_size(", pa, ");\n",
                   I, "  if (gs_uleb_size(", pb, ") != n || memcmp(", pa, ", ", pb,
                   ", (size_t)n) != 0) return 0;\n",
                   I, "  ", pa, " += n; ", pb, " += n; }\n");
            return;
        }
        case TY_ARRAY: {
            auto &a = *t->arr;
            string lena, lenb;
            auto adv = [&](const string &p, string &out) {
                if (a.akind == A_VAR) {
                    auto ls = LenStore(t->arr);
                    if (ls == IS_VARINT) {
                        Append(bo, I, "int64_t ", out, " = GS_ULEB_READ(", p, "); ", p,
                               " += GS_ULEB_SIZE(", p, ");\n");
                    } else {
                        Append(bo, I, "int64_t ", out, " = (int64_t)*(", IntCT(ls), " *)",
                               p, "; ", p, " += ", IntSize(ls), ";\n");
                    }
                } else if (a.akind == A_LIMITED) {
                    Append(bo, I, "int64_t ", out, "cap = (int64_t)*(uint32_t *)", p,
                           "; int64_t ", out, " = (int64_t)*(uint32_t *)(", p, " + 4); ",
                           p, " += 8;\n");
                } else {
                    Append(bo, I, "int64_t ", out, " = *(int64_t *)", p, "; ", p,
                           " += 8;\n");
                }
            };
            lena = cat("na", depth);
            lenb = cat("nb", depth);
            Append(bo, I, "{\n");
            adv(pa, lena);
            adv(pb, lenb);
            Append(bo, I, "if (", lena, " != ", lenb, ") return 0;\n");
            auto iv = cat("i", depth);
            Append(bo, I, "for (int64_t ", iv, " = 0; ", iv, " < ", lena, "; ", iv,
                   "++) {\n");
            EmitEqWalk(bo, a.sub, pa, pb, depth + 1);
            Append(bo, I, "}\n");
            if (a.akind == A_LIMITED)
                Append(bo, I, pa, " += (", lena, "cap - ", lena, ") * ", FixedSize(a.sub),
                       "; ", pb, " += (", lenb, "cap - ", lenb, ") * ", FixedSize(a.sub),
                       ";\n");
            Append(bo, I, "}\n");
            return;
        }
        case TY_STRUCT: case TY_VARIANT:
            for (auto &run : FieldRuns(t)) {
                for (size_t i = 0; i < run.fields->size(); i++) {
                    auto &f = (*run.fields)[i];
                    if (!f.ispad) {
                        EmitEqWalk(bo, (*run.ftypes)[i], pa, pb, depth);
                    } else if (f.padsize > 0) {
                        // Stepped over, never compared (§4.5). A bare pad has
                        // no bytes in a bytes layout.
                        Append(bo, I, pa, " += ", f.padsize, "; ", pb, " += ", f.padsize,
                               ";\n");
                    }
                }
            }
            return;
        case TY_ENUM: {
            auto ei = EIOf(t);
            auto ts = TagSize(ei->en);
            auto tt = IntCT(TagStore(ei->en));
            Append(bo, I, "if (*(", tt, " *)", pa, " != *(", tt, " *)", pb,
                   ") return 0;\n");
            Append(bo, I, "switch (*(", tt, " *)", pa, ") {\n");
            for (size_t vi = 0; vi < ei->en->variants.size(); vi++) {
                Append(bo, I, "case ", vi, ": {\n");
                Append(bo, I, pa, " += ", ts, "; ", pb, " += ", ts, ";\n");
                EmitEqWalk(bo, VariantType(t, (int)vi), pa, pb, depth + 1);
                Append(bo, I, "} break;\n");
            }
            Append(bo, I, "}\n");
            return;
        }
        default: assert(false); return;
    }
}

}  // namespace goose
