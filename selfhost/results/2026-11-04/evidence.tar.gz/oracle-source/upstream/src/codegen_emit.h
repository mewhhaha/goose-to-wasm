// Goose compiler — codegen's function bodies (definitions of CodeGen
// members, codegen.h): named results (§7.3), the two top-caching modes,
// element-run twins (C.3), and the emission of every specialization, the
// globals (§11.1) and main.
#pragma once

namespace goose {

// ------------------------------------------------------------------
// Function bodies.

// §7.3 for a body the optimizer spliced in: an inlined call in a
// construction context still has a destination, so bind the block's named
// result to it rather than to a stack of its own -- its elements are then
// written where the value has to end up, and the `return` only completes
// the receiving metadata. Applies where the local's raw elements are
// exactly the ones the destination wants; returns the bound local, or null.
inline const VarDef *CodeGen::OpenIbNrvo(InlineBlock *ib, const Dst &d) {
    if (d.k != DK_STACK || !ib->spec || ib->spec->rets.size() != 1) return nullptr;
    auto vd = NamedResult(ib->body, ib->sf, 1, 0);
    if (!vd || !IsBytesT(vd->type) || nrvo.count(vd)) return nullptr;
    auto ct = vd->type;
    NrvoDest nd;
    nd.stk = d.s;
    nd.inlined = true;
    if (!IsResz(ct)) {
        // A packed value of the same layout needs no separate metadata:
        // its declaration and every return can share the destination.
        if (!d.lenlv.empty() || !d.t || !TEq(ct, d.t)) return nullptr;
        nrvo[vd] = nd;
        return vd;
    }
    if (!d.lenlv.empty()) {
        // An element-run or resizable receiver: raw elements plus a count.
        if (!d.t) return nullptr;
        auto elems = ct->kind == TY_ARRAY && d.t->kind == TY_ARRAY &&
                     (IsResz(d.t) || d.t->arr->akind == A_VAR) &&
                     TEq(ct->arr->sub, d.t->arr->sub);
        if (!TEq(ct, d.t) && !elems) return nullptr;
        nd.lenlv = d.lenlv;
        nd.fo = IsFrameObj(ct);
    } else {
        // A value receiver: the elements need a length prefix in front of
        // them. Its storage is the one the call itself would have written
        // -- the result type's, retargeted to the slot's when the receiver
        // names one (the retarget GenConstruct does at the leaf).
        auto at = ib->spec->rets[0];
        if (!at || at->kind != TY_ARRAY || at->arr->akind != A_VAR) return nullptr;
        if (d.t) {
            if (d.t->kind != TY_ARRAY || d.t->arr->akind != A_VAR ||
                !TEq(d.t->arr->sub, at->arr->sub)) return nullptr;
            at = d.t;
        }
        if (ct->kind != TY_ARRAY || !TEq(ct->arr->sub, at->arr->sub)) return nullptr;
        nd.prefix = true;
        nd.ls = LenStore(at->arr);
    }
    nrvo[vd] = nd;
    return vd;
}

// What `d`, bound to `init`, stands for (refalias): the resizable variable
// `&v` names, or the reference variable an identifier names, followed
// through that one's own alias. Null where d has to be a C variable: it can
// be rebound, a nested function captures it (and is handed its address),
// it is pool-shaped, or the initializer is anything but such a name. A
// parameter, an alias, and a captured reference that cannot be rebound hold
// the same value as long as d is live; a resizable variable's header and
// stack never move.
inline const VarDef *CodeGen::AliasTarget(VarDef *d, Node *init, Node *&path) {
    path = nullptr;
    if (!d || !init || !curspec || d->isvar || d->isglobal || d->reusable || !d->type ||
        !IsFatRef(d->type) || d->type->ref->optional || PrefVar(d) || d->captured ||
        capturedvars.count(d))
        return nullptr;
    // A reference variable that stands for its whole life for what it holds:
    // a parameter, an alias, a captured reference, none of them rebindable.
    auto fixedref = [&](const VarDef *t) -> const VarDef * {
        if (!t || !t->type || !IsFatRef(t->type)) return nullptr;
        if (refalias.count(t)) return t;
        if (t->isvar || t->isglobal || t->reusable || PrefVar(t)) return nullptr;
        for (auto p : curspec->params) if (p == t) return t;
        for (auto fv : curinfo->freevars) if (fv == t) return t;
        return nullptr;
    };
    if (auto u = Is<Unary>(init); u && u->op == T_BITAND) {
        if (!u->child->exprtype || !TEq(d->type->ref->sub, u->child->exprtype)) return nullptr;
        if (auto id = Is<Ident>(u->child)) {
            auto t = id->vdef;
            if (!t || !t->type || t->reusable || !IsResz(t->type)) return nullptr;
            return t;
        }
        // A frame object's tail, by fields from a variable that holds the
        // object or from a reference that stands for one: a C member of a
        // header that never moves, on the object's own stack.
        auto n = FieldChainRoot(u->child, true);
        auto id = Is<Ident>(n);
        if (n == u->child || !id || !id->vdef || !id->vdef->type) return nullptr;
        auto t = id->vdef;
        if (IsResz(t->type) ? t->reusable : !fixedref(t)) return nullptr;
        path = u->child;
        return t;
    }
    auto id = Is<Ident>(init);
    auto t = id ? id->vdef : nullptr;
    if (!t || !t->type || !init->exprtype || !TEq(init->exprtype, d->type)) return nullptr;
    // A receiver the checker takes the reference of in place.
    if (IsResz(t->type) && !t->reusable && TEq(d->type->ref->sub, t->type)) return t;
    if (!TEq(t->type, d->type)) return nullptr;
    if (auto it = refalias.find(t); it != refalias.end()) {
        if (auto pit = aliaspath.find(t); pit != aliaspath.end()) path = pit->second;
        return it->second;
    }
    return fixedref(t);
}

// `&x` or `&x.f.g` of a variable: a reference that, made here, is only
// handed on -- to a call, which syncs whatever it is handed a stack in, into
// a value, which is passed to calls the same way or read back out of a field
// (where it counts again), or to an alias, which stands for what it names.
inline bool CodeGen::HandedRef(Node *n) {
    auto un = Is<Unary>(n);
    return un && un->op == T_BITAND && Is<Ident>(FieldChainRoot(un->child, false));
}

// The node a run of field accesses `x.f.g` starts from (n itself where n is
// no field access), or null where the run takes a property or a variant
// constant, or goes through a reference not held in a variable: a reference
// field can be rebound, and leads to another stack anyway. With `typed`, an
// object without a type gives null too.
inline Node *CodeGen::FieldChainRoot(Node *n, bool typed) {
    while (auto d = Is<Dot>(n)) {
        if (!d->IsField() || (typed && !d->obj->exprtype)) return nullptr;
        n = d->obj;
        if (!Is<Ident>(n) && n->exprtype && n->exprtype->kind == TY_REF) return nullptr;
    }
    return n;
}

// Every binding of the body that AliasTarget accepts, in source order, so
// that an alias of an alias resolves to the first one's target.
inline void CodeGen::FindRefAliases(FnSpec *sp) {
    auto bind = [&](VarDef *d, Node *init) {
        Node *path = nullptr;
        auto t = AliasTarget(d, init, path);
        if (!t) return;
        refalias[d] = t;
        if (path) aliaspath[d] = path;
    };
    function<void(Node *)> walk = [&](Node *n) {
        if (!n) return;
        if (auto vd = Is<VarDecl>(n); vd && vd->defs.size() == vd->inits.size()) {
            for (size_t i = 0; i < vd->defs.size(); i++) bind(vd->defs[i], vd->inits[i]);
        }
        if (auto c = Is<Call>(n); c && c->fvbody) {
            for (size_t i = 0; i < c->fvparams.size() && i < c->args.size(); i++)
                bind(c->fvparams[i], c->args[i]);
        }
        RunChildren(n, walk);
    };
    walk(sp->body);
}

// Which classes of stacks this specialization caches the tops of (see the
// note above toporder in codegen.h). A reference to a resizable carries its
// stack inside the reference value, so it is a second spelling of a stack the
// body may also name directly; each class is cached only where nothing the
// body holds can be such a second spelling of one of its stacks:
//  * its own indexed stacks, which only a fat reference rooted at one of its
//    own locals could also name: none may be held anywhere but in a
//    parameter, a free variable or an alias. A fat reference read out of a
//    field or an element, returned by a call, or held in a variable of any
//    other kind can be dereferenced right here, and might be one. Taking one
//    of a variable does not count: that value is only handed on;
//  * the globals' dedicated stacks, which a parameter or a captured
//    reference may also be rooted at: there must be none;
//  * its captured resizables' stacks (`<fv>_stk`), likewise: a parameter or
//    a captured reference might be rooted at the same variable; and one
//    that is its function's named result lives at that function's
//    destination, where a `return ... from` to it builds its value, so
//    there must be no such return here either;
//  * its return destinations (`gs_dst<i>`), which a caller may hand over as
//    a global's stack, a parameter's, or one a captured variable is on:
//    none of those may be named, and nothing returns to a gs_fdst_ channel;
//  * its reference parameters' stacks, where RefTopsOk clears it.
// Own stacks never meet another class: a caller's expressions cannot name
// them. Of the rest, no two classes that could share a stack are cached
// together.
inline void CodeGen::PlanTopClasses(FnSpec *sp) {
    topown = topglob = topcap = topdst = reftops = false;
    auto &fvs = sinfo[sp].freevars;
    auto isparam = [&](const VarDef *v) {
        return std::find(sp->params.begin(), sp->params.end(), v) != sp->params.end();
    };
    auto isfv = [&](const VarDef *v) { return std::find(fvs.begin(), fvs.end(), v) != fvs.end(); };
    // A pool reference carries its stack (and its freelist's) as well.
    auto carries = [&](const VarDef *v) {
        return v && (PrefVar(v) || (v->type && v->type->kind == TY_REF && IsResz(v->type->ref->sub)));
    };
    auto fatparam = false, fatfv = false, capresz = false, globals = false, unknown = false;
    for (size_t i = 0; i < sp->params.size(); i++)
        if (carries(sp->params[i]) || IsPoolParam(sp, i)) fatparam = true;
    for (auto fv : fvs) {
        if (fv->reusable || carries(fv)) fatfv = true;
        else if (fv->type && IsResz(fv->type)) capresz = true;
    }
    // A return exiting this function or an inlined body stays here; any
    // other target constructs into a gs_fdst_ channel (§7.9).
    set<SFunction *> localexits { sp->sf };
    auto farreturn = false;
    function<void(Node *)> ibs = [&](Node *n) {
        if (!n) return;
        if (auto ib = Is<InlineBlock>(n)) localexits.insert(ib->sf);
        RunChildren(n, ibs);
    };
    ibs(sp->body);
    function<void(Node *)> walk = [&](Node *n) {
        if (!n) return;
        if (n->exprtype && IsFatRef(n->exprtype)) {
            if (!Is<Ident>(n) && !HandedRef(n)) unknown = true;
        }
        if (auto r = Is<Return>(n); r && !localexits.count(r->target)) farreturn = true;
        NodeVars(n, [&](const VarDef *v) {
            if (!v) return;
            if (carries(v) && !refalias.count(v) && !isparam(v) && !isfv(v)) unknown = true;
            if (v->isglobal && v->type && (IsBytesT(v->type) || HoldsFatRef(v->type)))
                globals = true;
        });
        RunChildren(n, walk);
    };
    walk(sp->body);
    auto nonfixedret = false;
    for (auto rt : sp->rets) nonfixedret |= IsBytesT(rt);
    topown = !unknown;
    topglob = topown && !fatparam && !fatfv;
    topcap = topglob && capresz && !farreturn;
    topdst = topglob && !capresz && !globals && nonfixedret && !farreturn && !fromids.count(sp);
    reftops = !topglob && RefTopsOk(sp, farreturn);
    cachetops = topown || reftops;
}

// Whether this specialization may cache the tops of the stacks it reaches
// through its reference parameters (the reftops mode; see the note above
// toporder). Every condition below rules out a second spelling of one of
// those stacks, or a way for one to move without a mark:
//  * each fat reference in the body is a parameter, named directly, so
//    `<p>.stk` is its one spelling and is in scope throughout. A reference
//    from a field, an element or an `&` here has no parameter to name;
//  * the fat parameters' root classes are distinct and every one of them
//    was rooted exactly at its call sites, which is what §10.2 proves
//    distinct: two exact roots that differ are two variables. An inexact
//    root only bounds a lifetime (§9.5), so two of them may still be one
//    stack, and two parameters in one class are not proven equal either;
//    both cases would need one cache for two stacks. With more than one fat
//    parameter every root must also be concrete (RootArg::concrete): a class
//    standing for a caller's own parameter may otherwise name a global, or a
//    variable that caller passes as another argument;
//  * nothing else the body names can be one of those stacks: no global of
//    a parameter's pointee type (a reference parameter may well be rooted
//    at one, and the specialization key does not record which), no captured
//    or by-value resizable, no return destination, and no long-distance
//    return channel: neither this function's own nor the one a return here
//    to a function further out constructs into (`farreturn`), a stack this
//    body cannot place (§7.9).
inline bool CodeGen::RefTopsOk(FnSpec *sp, bool farreturn) {
    set<const VarDef *> fatparams, classes;
    vector<TypeExpr *> pointees;
    auto concrete = true;
    for (size_t i = 0; i < sp->params.size(); i++) {
        auto vd = sp->params[i];
        if (!IsFatRef(sp->argtypes[i])) continue;
        if (!vd->refrootknown || !vd->ref.Root() || !vd->ref.Exact() ||
            !classes.insert(vd->ref.Root()).second)
            return false;
        fatparams.insert(vd);
        pointees.push_back(sp->argtypes[i]->ref->sub);
        concrete &= i < sp->roots.size() && sp->roots[i].concrete;
    }
    if (fatparams.empty() || (fatparams.size() > 1 && !concrete)) return false;
    for (auto pt : sp->argtypes) if (IsResz(pt)) return false;
    for (auto rt : sp->rets) if (IsBytesT(rt)) return false;
    if (fromids.count(sp) || farreturn) return false;
    for (auto fv : sinfo[sp].freevars)
        if (fv->reusable || (fv->type && (IsResz(fv->type) || IsFatRef(fv->type))))
            return false;
    auto ok = true;
    // A frame object's tail has its own addressable header (C.2), but
    // shares the owner's data stack. A parameter may therefore name the
    // whole global, any nested frame-object tail, or the final array.
    auto maybeparam = [&](TypeExpr *gt) {
        for (;;) {
            for (auto pt : pointees) if (TEq(pt, gt)) return true;
            if (!IsFrameObj(gt)) return false;
            auto si = SI(gt);
            gt = si->ftypes[LastRealField(si->st->fields)];
        }
    };
    // An alias stands for a parameter or for a resizable variable, whose
    // spelling it shares; the variable's own identifier is checked where its
    // binding names it.
    auto check = [&](const VarDef *v) {
        if (!v || !v->type) return;
        if (IsFatRef(v->type) && !fatparams.count(v) && !refalias.count(v)) ok = false;
        if (v->isglobal && IsBytesT(v->type) && maybeparam(v->type)) ok = false;
    };
    function<void(Node *)> walk = [&](Node *n) {
        if (!n || !ok) return;
        if (n->exprtype && IsFatRef(n->exprtype)) {
            // A reference taken of a variable is only handed on: to a call,
            // which syncs everything it is handed a stack in, or to an alias.
            auto id = Is<Ident>(n);
            if (!HandedRef(n) && (!id || !(fatparams.count(id->vdef) || refalias.count(id->vdef)))) {
                ok = false;
                return;
            }
        }
        NodeVars(n, check);
        RunChildren(n, walk);
    };
    walk(sp->body);
    return ok;
}

inline void CodeGen::ResetFnState() {
    toporder.clear();
    lenslots.clear();
    growth.clear();
    loopparent.clear();
    loopcons.clear();
    loopstack.clear();
    markers = false;
    refstkexprs.clear();
    capstkexprs.clear();
    cachetops = false;
    reftops = false;
    topown = topglob = topcap = topdst = false;
    vnames.clear();
    refalias.clear();
    aliaspath.clear();
    aliasbound.clear();
    views.clear();
    fieldviews.clear();
    vstk.clear();
    vpool.clear();
    poolbases.clear();
    fvptr.clear();
    fnused.clear();
    fnnextsuffix.clear();
    nrvo.clear();
    fdstsaves.clear();
    openat.clear();
    dsttop0.clear();
    cscopes.clear();
    body.clear();
    tmpn = 0;
    stknext = 0;
    stkmax = 0;
    ind = 1;
    termjump = false;
}

// The element-run twin of a spec (C.3): same body compiled to emit raw
// elements at the destination plus a count, instead of a [len][elems]
// value. Returns its C name, or "" when the spec cannot have one.
inline string CodeGen::EnsureEr(FnSpec *sp) {
    auto it = ernames.find(sp);
    if (it != ernames.end()) return it->second;
    auto rt = sp->rets.size() == 1 ? sp->rets[0] : nullptr;
    auto ok = rt && rt->kind == TY_ARRAY && rt->arr->akind == A_VAR && sp->body &&
              !fromids.count(sp);
    if (!ok) return ernames[sp] = "";
    auto name = Unique(cat(sinfo[sp].cname, "_er"));
    ernames[sp] = name;
    Append(protos, "static ", FnAttrs(sp), SigRet(sp), " ", name, "(",
           SigParams(sp, false, true), ");\n");
    erqueue.push_back(sp);
    return name;
}

// The members of C type ct in order, where a brace initializer of the
// generated code gives them all; none for any other type.
inline vector<string> CodeGen::BraceFields(const string &ct) {
    if (ct == "gs_rref") return { "hdr", "stk" };
    if (ct == "gs_rhdr") return { "base", "len" };
    if (slicects.count(ct)) return { "data", "len" };
    return {};
}

// The top-level elements of a brace initializer "{ a, b }", split at the
// commas outside parentheses, brackets, braces and literals.
inline vector<string> CodeGen::SplitBraceInit(const string &init) {
    vector<string> parts;
    auto trim = [](string s) {
        auto b = s.find_first_not_of(' '), e = s.find_last_not_of(' ');
        return b == string::npos ? string() : s.substr(b, e - b + 1);
    };
    if (init.size() < 2 || init.front() != '{' || init.back() != '}') return parts;
    auto body = init.substr(1, init.size() - 2);
    int depth = 0;
    size_t start = 0;
    for (size_t i = 0; i < body.size(); i++) {
        auto c = body[i];
        if (c == '"' || c == '\'') {
            for (i++; i < body.size() && body[i] != c; i++)
                if (body[i] == '\\') i++;
        } else if (c == '(' || c == '[' || c == '{') {
            depth++;
        } else if (c == ')' || c == ']' || c == '}') {
            depth--;
        } else if (c == ',' && !depth) {
            parts.push_back(trim(body.substr(start, i - start)));
            start = i + 1;
        }
    }
    parts.push_back(trim(body.substr(start)));
    for (auto &p : parts)
        if (p.empty()) return {};
    return parts;
}

// Moves every declaration of an aggregate-typed C local (a struct, array,
// slice or header typedef; never a scalar or a pointer) out of a finished
// body into a block of declarations for the function's opening brace,
// leaving an initializer behind as an assignment. MSVC 19.44 through 19.51
// at any optimization level miscompiles a read through a *copy* of a
// struct that holds the address of a block-scoped local -- the local's
// stores are treated as dead -- and a slice of a fixed array declared in
// a loop body, passed to an inlined callee, is exactly that shape. A local
// declared at function scope is handled correctly, and every name is
// unique within its function (Unique2), which is what makes the move safe.
inline string CodeGen::HoistAggregateDecls(string &b) {
    static const unordered_set<string> keep = {
        "int8_t", "int16_t", "int32_t", "int64_t", "uint8_t", "uint16_t", "uint32_t",
        "uint64_t", "float", "double", "int", "char", "size_t", "void", "return", "goto",
        "break", "continue", "else", "do", "case", "default", "static", "const", "extern",
        "volatile", "register", "unsigned", "signed", "long", "short", "struct", "union",
        "enum", "typedef", "if", "for", "while", "switch",
    };
    auto isid = [](char c) { return isalnum((unsigned char)c) || c == '_'; };
    string decls, out;
    out.reserve(b.size());
    size_t pos = 0;
    while (pos < b.size()) {
        auto nl = b.find('\n', pos);
        if (nl == string::npos) nl = b.size();
        string_view line(b.data() + pos, nl - pos);
        pos = nl + 1;
        size_t i = 0;
        while (i < line.size() && line[i] == ' ') i++;
        auto indent = i;
        auto ts = i;
        while (i < line.size() && isid(line[i])) i++;
        string type(line.substr(ts, i - ts));
        bool hoist = false;
        string name, init;
        if (!type.empty() && !isdigit((unsigned char)type[0]) && !keep.count(type) &&
            i < line.size() && line[i] == ' ') {
            i++;
            auto ns = i;
            while (i < line.size() && isid(line[i])) i++;
            name = string(line.substr(ns, i - ns));
            if (!name.empty() && !isdigit((unsigned char)name[0])) {
                auto rest = line.substr(i);
                if (rest == ";") hoist = true;
                else if (rest.size() > 4 && rest.substr(0, 3) == " = " && rest.back() == ';') {
                    init = string(rest.substr(3, rest.size() - 4));
                    hoist = true;
                }
            }
        }
        if (!hoist) {
            out.append(line);
            out += '\n';
            continue;
        }
        Append(decls, "    ", type, " ", name, ";\n");
        if (!init.empty()) {
            out.append(indent, ' ');
            if (init[0] != '{') {
                Append(out, name, " = ", init, ";\n");
                continue;
            }
            // A brace initializer of a slice or core reference type gives
            // every member, and becomes their assignments: TinyCC compiles
            // a compound literal into a memset call that zeroes it, its
            // stores, and a copy. The members' values never read the
            // variable, whose declaration they initialized. Any other one
            // becomes a compound literal (C99).
            auto fs = BraceFields(type);
            auto vals = fs.empty() ? vector<string>() : SplitBraceInit(init);
            if (fs.empty() || vals.size() != fs.size()) {
                Append(out, name, " = (", type, ")", init, ";\n");
                continue;
            }
            for (size_t k = 0; k < fs.size(); k++)
                Append(out, k ? " " : "", name, ".", fs[k], " = ", vals[k], ";");
            out += '\n';
        }
    }
    b = out;
    return decls;
}

// A simd function (§7.12): its body once per instruction-set level above
// the baseline, each under that level's target attribute and compiled where
// the C compiler supports the level (GS_SIMD, runtime.h), then the baseline
// under the function's own name, which starts by calling the highest
// version the CPU supports. Callers, prototypes and function values see one
// function. Every version computes what the baseline does: the C is the
// same text, its integer semantics are spelled out, and runtime.h keeps the
// C compiler from fusing a multiply and an add into one rounding in any of
// them, which the wider instruction sets would otherwise let it do.
inline void CodeGen::EmitSimdVersions(FnSpec *sp, const string &name, const string &params,
                                      const string &fnbody) {
    // The parameter list is `type name` declarations whose types are
    // typedef names or pointers to them; the names forward the call.
    string args;
    if (params != "void") {
        for (size_t b = 0; b <= params.size();) {
            auto e = std::min(params.find(',', b), params.size());
            auto nb = e;
            while (nb > b && (isalnum((unsigned char)params[nb - 1]) || params[nb - 1] == '_'))
                nb--;
            assert(nb < e);
            Append(args, args.empty() ? "" : ", ", string_view(params).substr(nb, e - nb));
            b = e + 1;
        }
    }
    auto ret = SigRet(sp);
    vector<string> versions(SIMD_LEVELS + 1);
    // Every version above the baseline has FMA, so math's mul_add fuses in
    // it whatever the target's mode (runtime.h).
    for (int lv = SIMD_LEVELS; lv >= 1; lv--) {
        versions[lv] = Unique(cat(name, "_simd", lv));
        Append(code, "#if GS_SIMD >= ", lv,
               "\n#undef GS_MUL_ADD_MODE\n#define GS_MUL_ADD_MODE fused\nGS_SIMD_TARGET", lv,
               " static ", ret, " ", versions[lv], "(", params, ") {\n", fnbody,
               "}\n#undef GS_MUL_ADD_MODE\n#define GS_MUL_ADD_MODE GS_MUL_ADD_BASE\n#endif\n");
    }
    Append(code, "static ", ret, " ", name, "(", params, ") {\n",
           "#if GS_SIMD >= 1\n    switch (gs_simd_level()) {\n");
    for (int lv = SIMD_LEVELS; lv >= 1; lv--) {
        if (lv > 1) Append(code, "#if GS_SIMD >= ", lv, "\n");
        auto call = cat(versions[lv], "(", args, ")");
        if (ret == "void") Append(code, "    case ", lv, ": ", call, "; return;\n");
        else Append(code, "    case ", lv, ": return ", call, ";\n");
        if (lv > 1) Append(code, "#endif\n");
    }
    Append(code, "    }\n#endif\n", fnbody, "}\n\n");
}

inline void CodeGen::EmitSpec(FnSpec *sp, bool er) {
    curspec = sp;
    curinfo = &sinfo[sp];
    emiter = er;
    ResetFnState();
    spexpr = curinfo->needssp ? "gs_sp" : "0";
    FindRefAliases(sp);
    PlanTopClasses(sp);
    markers = true;
    PushSc(SC_FN);
    auto params = SigParams(sp, true, er);
    // The spellings are only known once SigParams has named the parameters.
    if (reftops) {
        for (size_t i = 0; i < sp->params.size(); i++) {
            if (!IsFatRef(sp->argtypes[i])) continue;
            auto pn = LocalName(sp->params[i]);
            refstkexprs.insert(cat(pn, ".stk"));
            if (IsPoolParam(sp, i)) refstkexprs.insert(cat(pn, ".flstk"));
        }
    }
    if (topcap)
        for (auto fv : curinfo->freevars)
            if (fv->type && IsResz(fv->type) && !fv->reusable) capstkexprs.insert(vstk[fv]);
    // In the element-run form named results are not built at the
    // destination: the callee-side copy at return is the specified cost
    // of operating on the whole value first (§7.3).
    if (!er) DetectNrvo(sp);
    if (fromids.count(sp)) {
        // This is a long-distance return target with nonfixed returns:
        // record our destinations for in-flight values (§7.9).
        EnsureFromChannels(sp);
        auto tid = fromids[sp];
        for (size_t i = 0; i < sp->rets.size(); i++) {
            if (NeedsResultLocation(sp->rets[i])) {
                auto sav = T(), chan = cat("gs_lret_", tid, "_", i);
                L(CT(sp->rets[i]), " *", sav, " = ", chan, ";");
                L(chan, " = gs_r", i, ";");
                fdstsaves.push_back(cat(chan, " = ", sav, ";"));
                continue;
            }
            if (!IsBytesT(sp->rets[i])) continue;
            auto sav = T();
            L("gs_stack *", sav, " = gs_fdst_", tid, "_", i, ";");
            L("gs_fdst_", tid, "_", i, " = gs_dst", i, ";");
            fdstsaves.push_back(cat("gs_fdst_", tid, "_", i, " = ", sav, ";"));
        }
    }
    for (auto st : sp->body->stmts) GenStmt(st);
    if (auto tail = sp->body->tail) {
        auto asvalue = !sp->rets.empty();
        if (auto fi = Is<IfExpr>(tail); fi && !fi->elseb) asvalue = false;
        if (asvalue && !IsVoidT(tail->exprtype)) {
            vector<Node *> vals = { tail };
            GenNormalReturn(vals);
        } else {
            GenStmt(tail);
        }
    }
    if (!termjump) {
        if (curinfo->cret >= 0) {
            L("GS_UNREACHABLE(", LocArgs(sp->sf->line), ");");
            auto d = T();
            L(CT(sp->rets[curinfo->cret]), " ", d, " = {0};");
            L("return ", d, ";");
        } else {
            Epilogue("");
        }
    }
    cscopes.clear();
    // Stacks counted from 0 are the outermost callers' (CollectSpecs).
    if (stkmax > 0 && !curinfo->needssp)
        Fail(sp->sf->line, cat("internal: ", curinfo->cname, " uses data stacks without gs_sp"));
    // The element-run twin is the same body: the larger count of the two.
    stackown[sp] = std::max(stackown[sp], stkmax);
    // The regions and the markers resolve now that every stack this body
    // grows, and where it grows it, is known.
    auto plan = PlanTopCaches();
    auto bodyout = ExpandTopMarkers(body, plan);
    assert(bodyout.find("@@gs") == string::npos);
    auto decls = HoistAggregateDecls(bodyout);
    string fnbody = paramcopies + decls;
    // A whole-body cache loads at entry; a per-loop one declares and loads
    // itself at its loop's edge.
    for (size_t i = 0; i < toporder.size(); i++)
        if (!plan.fnlocals[i].empty())
            Append(fnbody, "    uint8_t *", plan.fnlocals[i], " = ", toporder[i], "->top;\n");
    fnbody += plan.fnlens;
    // Every global pool's stack is reserved by gs_init_globals, which
    // main runs before anything else, so these are final on entry.
    for (auto &p : poolbases)
        Append(fnbody, "    uint8_t *", p.second, " = ", gnames[p.first], ".base;\n");
    fnbody += bodyout;
    auto name = er ? ernames[sp] : curinfo->cname;
    if (sp->sf->issimd) EmitSimdVersions(sp, name, params, fnbody);
    else Append(code, "static ", FnAttrs(sp), SigRet(sp), " ", name, "(", params, ") {\n", fnbody,
                "}\n\n");
    curspec = nullptr;
    curinfo = nullptr;
    emiter = false;
    markers = false;
}

// ------------------------------------------------------------------
// Globals (§11.1): C globals plus dedicated data stacks for nonfixed
// ones; initializers run in declaration order before main.

// A C initializer for a compile-time constant of fixed, flat type. Fails
// for everything with a runtime component -- references, slices, ADTs,
// relative references -- leaving the value to gs_init_globals. A global
// that is static data itself stands for its initializer, spelled out
// again, since a C initializer cannot read another object.
inline bool CodeGen::StaticInitX(Node *n, TypeExpr *t, string &out) {
    if (!n || !t || !IsFix(t) || HasRelRef(t)) return false;
    if (auto id = Is<Ident>(n)) {
        auto it = id->vdef ? gstatic.find(id->vdef) : gstatic.end();
        // An integer constant may be read at a narrower type than its own,
        // which the checker found its value to fit.
        if (it == gstatic.end() ||
            !(TEq(id->vdef->type, t) || (t->kind == TY_INT && id->vdef->type->kind == TY_INT)))
            return false;
        return StaticInitX(it->second, t, out);
    }
    switch (t->kind) {
        case TY_INT: {
            auto i = Is<IntLit>(n);
            if (!i || t->intstorage == IS_VARINT) return false;
            out = i->val < 0 && t->intstorage == IS_U64 ? cat((uint64_t)i->val, "ULL")
                                                        : IntStr(i->val);
            return true;
        }
        case TY_FLT: {
            auto f = Is<FltLit>(n);
            if (!f) return false;
            out = FltStr(f->val, t->fltstorage == FS_F32);
            return true;
        }
        case TY_BOOL: {
            auto b = Is<BoolLit>(n);
            if (!b) return false;
            out = b->val ? "1" : "0";
            return true;
        }
        case TY_STRUCT: {
            auto sl = Is<StructLit>(n);
            auto si = SI(t);
            if (!sl || sl->sinst != si) return false;
            string s = "{ ";
            auto any = false;
            for (size_t fi = 0; fi < si->st->fields.size(); fi++) {
                if (si->st->fields[fi].ispad) continue;   // Pads zero-fill.
                string fx;
                if (!StaticInitX(sl->InitFor((int)fi), si->ftypes[fi], fx)) return false;
                Append(s, any ? ", " : "", ".", Sanitize(si->st->fields[fi].name),
                       " = ", fx);
                any = true;
            }
            out = any ? s + " }" : "{ 0 }";
            return true;
        }
        case TY_ARRAY: {
            auto &a = *t->arr;
            if (a.akind != A_FIXED) return false;
            auto k = ArrSize(t->arr);
            if (k < 1 || k > MAXSTATICELEMS) return false;
            string s = "{ { ";
            if (auto str = Is<StrLit>(n)) {
                if (!IsU8(a.sub) || (int64_t)str->val.size() != k) return false;
                for (int64_t e = 0; e < k; e++)
                    Append(s, e ? ", " : "", (int)(uint8_t)str->val[(size_t)e]);
            } else if (auto al = Is<ArrayLit>(n)) {
                string ex;
                if (al->fillval) {
                    if (!StaticInitX(al->fillval, a.sub, ex)) return false;
                    for (int64_t e = 0; e < k; e++) Append(s, e ? ", " : "", ex);
                } else {
                    if ((int64_t)al->elems.size() != k) return false;
                    for (int64_t e = 0; e < k; e++) {
                        if (!StaticInitX(al->elems[(size_t)e], a.sub, ex)) return false;
                        Append(s, e ? ", " : "", ex);
                    }
                }
            } else {
                return false;
            }
            out = s + " } }";
            return true;
        }
        default: return false;
    }
}

inline void CodeGen::EmitGlobalDecls() {
    for (auto g : ast.globals) {
        for (size_t di = 0; di < g->defs.size(); di++) {
            auto d = g->defs[di];
            auto name = Unique(Sanitize(g->ns, d->name));
            // Registered as they are created; see CacheableStk.
            auto reg = [&](const string &s) { gstkexprs.insert(s); };
            // A member of the instance block (gs_globals_t), and its
            // dedicated stack where it has one.
            auto member = [&](const string &decl) { Append(gblock, "    ", decl, ";\n"); };
            gnames[d] = cat("GS_GL->", name);
            if (IsResz(d->type)) {
                EmitCoreTypes();
                auto stk = Unique(cat("gs_gstk_", name));
                member(cat(RzCT(d->type), " ", name));
                member(cat("gs_stack ", stk));
                gstks[d] = cat("(&GS_GL->", stk, ")");
                reg(gstks[d]);
                if (d->reusable) {
                    auto fln = Unique(cat(name, "_fl"));
                    auto flstk = Unique(cat("gs_gstk_", fln));
                    member(cat("gs_rhdr ", fln));
                    member(cat("gs_stack ", flstk));
                    gpools[d] = { cat("GS_GL->", fln), cat("(&GS_GL->", flstk, ")") };
                    reg(gpools[d].second);
                }
            } else if (IsBytesT(d->type)) {
                auto stk = Unique(cat("gs_gstk_", name));
                member(cat("uint8_t *", name));
                member(cat("gs_stack ", stk));
                gstks[d] = cat("(&GS_GL->", stk, ")");
                reg(gstks[d]);
            } else {
                string init;
                // A `let` global of a const type with a compile-time
                // initializer is never written (§9.5): static data every
                // instance shares, const in C as well, so that the C
                // compiler folds what it reads. Its uses spell it without
                // the qualifier, as the pointers and slices into it that
                // Goose types do not mark const take it. A `var` one may
                // be assigned as a whole.
                if (!d->isvar && d->type->cq && !PrefVar(d) &&
                    StaticInitX(g->inits[di], d->type, init)) {
                    Append(data, "static const ", VarCT(d), " ", name, " = ", init, ";\n");
                    gstatic[d] = g->inits[di];
                    gnames[d] = cat("(*(", VarCT(d), " *)&", name, ")");
                } else {
                    member(cat(VarCT(d), " ", name));
                }
            }
        }
    }
}

inline void CodeGen::EmitGlobalInit() {
    curspec = nullptr;
    curinfo = nullptr;
    ResetFnState();
    spexpr = "0";
    PushSc(SC_FN);
    for (auto g : ast.globals) {
        if (g->inits.empty()) continue;
        PushSc(SC_STMT);
        for (size_t i = 0; i < g->defs.size(); i++) {
            auto d = g->defs[i];
            if (gstatic.count(d)) continue;   // Initialized at its declaration.
            if (IsResz(d->type)) {
                InitGlobalStack(d);
                GenConstruct(g->inits[i], gstks[d], d->type, GlobalLenLv(d));
            } else if (IsBytesT(d->type)) {
                InitGlobalStack(d);
                GenConstruct(g->inits[i], gstks[d], d->type);
            } else if (PrefVar(d)) {
                L(gnames[d], " = ", GenPrefVal(g->inits[i]), ";");
            } else if (IsRelRef(d->type)) {
                EmitRelStoreAt(cat("(uint8_t *)&", gnames[d]), d->type, GenX(g->inits[i]),
                               g->inits[i]->line, true, RelValue(g->inits[i]));
            } else {
                GenAny(g->inits[i], Dst { DK_LVALUE, gnames[d], d->type });
            }
        }
        if (termjump) cscopes.back().saves.clear();
        PopSc();
        termjump = false;
    }
    EmitExitRestores(0);
    cscopes.clear();
    stackown[nullptr] = std::max(stackown[nullptr], stkmax);
    auto decls = HoistAggregateDecls(body);
    Append(code, "static void gs_init_globals(void) {\n");
    code += decls;
    code += body;
    code += "}\n\n";
}

// x, a pure expression, as a value of index or bound type t: checked below
// (at most, for a bound) the length of the array t names (§3.11).
inline string CodeGen::IndexTypeCheck(const string &x, TypeExpr *t, Line ln) {
    auto n = GlobalLenLv(t->ix->arr);
    if (!t->ix->upto) return cat("GS_IDX(", x, ", ", n, ", ", LocArgs(ln), ")");
    return cat("((uint64_t)(", x, ") <= (uint64_t)(", n, ") ? (", x, ") : (gs_idxfail((int64_t)(",
               x, "), (", n, "), ", LocArgs(ln), "), (int64_t)0))");
}

// A resizable global's receiving lvalue: its header's count, or the
// whole frame object.
inline string CodeGen::GlobalLenLv(VarDef *d) { return RzLenLv(d->type, gnames[d]); }

inline void CodeGen::InitGlobalStack(VarDef *d) {
    auto stk = gstks[d];
    globalregions++;
    L("gs_stack_init(", stk, ");");
    if (IsResz(d->type) && IsFrameObj(d->type)) {
        // The tail header is set when the value is constructed.
    } else if (IsResz(d->type)) {
        L(gnames[d], ".base = ", Top(stk), ";");
        L(gnames[d], ".len = 0;");
    } else {
        L(gnames[d], " = ", Top(stk), ";");
    }
    if (d->reusable) {
        auto &p = gpools[d];
        globalregions++;
        L("gs_stack_init(", p.second, ");");
        L(p.first, ".base = ", Top(p.second), ";");
        L(p.first, ".len = 0;");
    }
}

inline void CodeGen::EmitProgramInit() {
    Append(data, "static int gs_program_initialized;\n");
    // Every function is emitted by now, so the counts are final: the main
    // program's stacks, and the most regions it and any one worker hold.
    // The worker thunks follow, each opening its program's block.
    BoundStacks();
    auto mainstacks = ProgramStacks(MainRoots());
    auto mainsf = ast.MainFunction();
    CheckStackLimit("the main program", mainstacks, mainsf ? mainsf->line : Line {});
    int64_t workerregions = 0;
    for (auto &[name, sp] : WorkerEntries()) {
        auto stacks = ProgramStacks({ sp });
        CheckStackLimit(cat("thread program ", name), stacks, sp->sf->line);
        EmitThreadThunk(sp, stacks);
        workerregions = std::max(workerregions, stacks + thunkregions[sp]);
    }
    Append(code, "static void gs_program_init(int argc, char **argv) {\n"
                 "    if (gs_program_initialized) return;\n"
                 "    gs_rt_init(argc, argv, ", mainstacks, ", ", mainstacks + globalregions,
           ", ", workerregions, ");\n");
    // The shared libraries' functions, before a global's initializer could
    // call one: on the main thread, before any worker exists, so the
    // pointers are written once here and read thereafter without
    // synchronization. A failure to open a library or find a symbol is a
    // runtime error naming it (design/dynamic_externs.md §4).
    auto dllibs = DlLibs();
    for (auto sp : usedexterns) dlbinds += !sp->sf->dylib.empty();
    if (!dllibs.empty())
        Append(code, "    gs_dl_bind(gs_dllibs, ", dllibs.size(), ", gs_dlbinds, ", dlbinds,
               ");\n");
    // The queues, before anything that could use one runs.
    vector<string> qnames;
    for (auto &[m, q] : queues) qnames.push_back(q);
    sort(qnames.begin(), qnames.end());
    for (auto &q : qnames) Append(code, "    gs_qinit(&", q, ");\n");
    Append(code, "    gs_gl = &gs_globals_main;\n    gs_init_globals();\n");
    Append(code, "    gs_program_initialized = 1;\n}\n\n");
    // A C host starts the program here: its globals, then fn main() if there
    // is one, which may call the exports and can hold the host's own setup.
    if (library)
        Append(code, "void goose_init(int argc, char **argv) {\n"
                     "    if (gs_program_initialized) return;\n"
                     "    gs_program_init(argc, argv);\n",
                     MainCall(), "}\n\n");
}

// The statement that runs fn main(), or nothing for a library without one.
inline string CodeGen::MainCall() {
    auto mainsf = ast.MainFunction();
    if (!mainsf || mainsf->specs.empty() || !sinfo.count(mainsf->specs[0])) return "";
    auto &mi = sinfo[mainsf->specs[0]];
    return cat("    ", mi.cname, "(", mi.needssp ? "0" : "", ");\n");
}

inline void CodeGen::EmitExports() {
    for (auto sf : ast.functions) {
        if (!sf->isexport) continue;
        if (sf->specs.size() != 1 || !sinfo.count(sf->specs[0]))
            Fail(sf->line, cat("export fn ", sf->name, " has no emitted specialization"));
        auto sp = sf->specs[0];
        auto &si = sinfo[sp];
        auto returnslice = !sp->rets.empty() && sp->rets[0]->kind == TY_SLICE;
        string params, args;
        vector<string> argv;
        for (size_t i = 0; i < sp->argtypes.size(); i++) {
            auto arg = Unique(cat("gs_export_arg", i));
            Append(params, params.empty() ? "" : ", ", CT(sp->argtypes[i]), " ", arg);
            PushArg(argv, sp->argtypes[i], IsPoolParam(sp, i), arg);
        }
        for (auto &a : argv) Append(args, args.empty() ? "" : ", ", a);
        auto outlen = Unique("gs_export_len");
        if (returnslice) Append(params, params.empty() ? "" : ", ", "int64_t *", outlen);
        if (params.empty()) params = "void";
        if (!args.empty() && si.needssp) args += ", ";
        if (si.needssp) args += "0";
        auto ret = sp->rets.empty() ? string("void")
                   : returnslice ? string("const uint8_t *") : CT(sp->rets[0]);
        Append(exportprotos, ret, " ", sf->cname, "(", params, ");\n");
        Append(code, ret, " ", sf->cname, "(", params, ") {\n"
                     "    if (!gs_program_initialized)\n"
                     "        gs_panic(\"goose_init must be called before exported functions\");\n");
        if (returnslice) {
            auto value = Unique("gs_export_result");
            Append(code, "    if (!", outlen,
                   ") gs_panic(\"exported slice length pointer is null\");\n");
            Append(code, "    ", CT(sp->rets[0]), " ", value, " = ", si.cname, "(", args,
                   ");\n"
                   "    *", outlen, " = ", value, ".len;\n"
                   "    return (const uint8_t *)", value, ".data;\n");
        } else if (sp->rets.empty()) {
            Append(code, "    ", si.cname, "(", args, ");\n");
        } else {
            Append(code, "    return ", si.cname, "(", args, ");\n");
        }
        Append(code, "}\n\n");
    }
}

inline string CodeGen::ExportHeader() {
    string header = "#pragma once\n#include <stdint.h>\n"
                    "typedef struct gs_stack gs_stack;\n"
                    "#pragma pack(push, 1)\n";
    header += tdecls;
    header += "#pragma pack(pop)\n\n";
    header += "#ifdef __cplusplus\nextern \"C\" {\n#endif\n"
              "void goose_init(int argc, char **argv);\n";
    header += exportprotos;
    header += "#ifdef __cplusplus\n}\n#endif\n";
    return header;
}

inline void CodeGen::EmitMain() {
    Append(code, "int main(int argc, char **argv) {\n    gs_program_init(argc, argv);\n",
           MainCall(), "    gs_rt_stats();\n    return 0;\n}\n");
}

}  // namespace goose
