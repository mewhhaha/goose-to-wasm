// Goose compiler — lexer. A hand-written scanner: one big switch over the next
// character. Input is 0-terminated, so only the 0 case checks for end of input.
#pragma once

namespace goose {

// X-macro token tables: expanded for the enum and for the display-name function.
#define TOKENS_MISC \
    F(T_EOF,      "end of file") \
    F(T_IDENT,    "identifier") \
    F(T_INTLIT,   "integer literal") \
    F(T_FLTLIT,   "float literal") \
    F(T_STRLIT,   "string literal")

#define TOKENS_PUNCT \
    F(T_LPAREN,   "(")   F(T_RPAREN,   ")") \
    F(T_LBRACKET, "[")   F(T_RBRACKET, "]") \
    F(T_LCURLY,   "{")   F(T_RCURLY,   "}") \
    F(T_COMMA,    ",")   F(T_SEMI,     ";")  F(T_COLON, ":")  F(T_QUESTION, "?") \
    F(T_COLONCOLON, "::") \
    F(T_DOT,      ".")   F(T_DOTDOT,   "..") F(T_DOTASSIGN, ".=") \
    F(T_DOTEQ,    ".==") F(T_DOTNEQ,   ".!=") \
    F(T_PLUS,     "+")   F(T_MINUS,    "-")  F(T_MUL,   "*")  F(T_DIV, "/")  F(T_MOD, "%") \
    F(T_PLUSEQ,   "+=")  F(T_MINUSEQ,  "-=") F(T_MULEQ, "*=") F(T_DIVEQ, "/=") F(T_MODEQ, "%=") \
    F(T_ANDEQ,    "&=")  F(T_OREQ,     "|=") F(T_XOREQ, "^=") \
    F(T_INC,      "++")  F(T_DEC,      "--") \
    F(T_ASSIGN,   "=")   F(T_EQ,       "==") F(T_NEQ,   "!=") \
    F(T_LT,       "<")   F(T_GT,       ">")  F(T_LTEQ,  "<=") F(T_GTEQ, ">=") \
    F(T_SHL,      "<<")  F(T_SHR,      ">>") F(T_SHLEQ, "<<=") F(T_SHREQ, ">>=") \
    F(T_NOT,      "!")   F(T_BITNOT,   "~") \
    F(T_BITAND,   "&")   F(T_BITOR,    "|")  F(T_XOR,   "^") \
    F(T_ANDAND,   "&&")  F(T_OROR,     "||") \
    F(T_ARROW,    "->")  F(T_FATARROW, "=>")

#define TOKENS_KEYWORDS \
    F(T_IMPORT,   "import")    F(T_NAMESPACE, "namespace") \
    F(T_STRUCT,   "struct")    F(T_ENUM,     "enum") \
    F(T_TYPE,     "type")      F(T_FN,       "fn")      F(T_THREADFN, "thread_fn") \
    F(T_EXPORT,   "export")    F(T_SIMD,     "simd") \
    F(T_RECURSIVE, "recursive") F(T_LET,     "let")     F(T_VAR,    "var") \
    F(T_EXTERN,   "extern")    F(T_CONST,    "const") \
    F(T_PAD,      "pad")       F(T_REUSABLE, "reusable") \
    F(T_IF,       "if")        F(T_ELSE,     "else")    F(T_WHILE,  "while") \
    F(T_FOR,      "for")       F(T_IN,       "in")      F(T_LOOP,   "loop") \
    F(T_BLOCK,    "block")     F(T_GUARD,    "guard")   F(T_MATCH,  "match") \
    F(T_RETURN,   "return")    F(T_BREAK,  "break") \
    F(T_CONTINUE, "continue")  F(T_AS,       "as") \
    F(T_TRUE,     "true")      F(T_FALSE,    "false")   F(T_NULLLIT, "null") \
    F(T_SELF,     "self") \
    F(T_TBOOL,    "bool")      F(T_TVARINT,  "varint") \
    F(T_TI8,      "i8")  F(T_TI16, "i16") F(T_TI32, "i32") F(T_TI64, "i64") \
    F(T_TU8,      "u8")  F(T_TU16, "u16") F(T_TU32, "u32") F(T_TU64, "u64") \
    F(T_TF32,     "f32") F(T_TF64, "f64")

enum TType {
    #define F(t, s) t,
    TOKENS_MISC TOKENS_PUNCT TOKENS_KEYWORDS
    #undef F
};

inline const char *TName(TType t) {
    static const char *names[] = {
        #define F(t, s) s,
        TOKENS_MISC TOKENS_PUNCT TOKENS_KEYWORDS
        #undef F
    };
    return names[t];
}

inline bool IsIdentStart(char c) { return isalpha((uint8_t)c) || c == '_'; }
inline bool IsIdentCont(char c)  { return isalnum((uint8_t)c) || c == '_'; }

// The UTF-8 sequence at p, where its bytes make one; empty for a byte that
// is no character on its own, which a message must not quote: a diagnostic
// is text, and the server sends it as JSON, which is UTF-8 throughout.
inline string_view Utf8CharAt(const char *p) {
    auto c = (uint8_t)*p;
    size_t len = c < 0x80 ? 1 : c >= 0xC2 && c < 0xE0 ? 2 : c >= 0xE0 && c < 0xF0 ? 3 : c >= 0xF0 && c < 0xF5 ? 4 : 0;
    for (size_t i = 1; i < len; i++)
        if (((uint8_t)p[i] & 0xC0) != 0x80) return {};
    return string_view(p, len);
}

// What a message calls the character at p: quoted, with its code point
// where it is not ASCII, or the byte's value where it is no character.
inline string QuotedCharAt(const char *p) {
    auto seq = Utf8CharAt(p);
    if (seq.empty()) return cat("byte ", (int)(uint8_t)*p);
    auto s = cat("'", seq, "'");
    if (seq.size() == 1) return cat(s, " (", (int)(uint8_t)*p, ")");
    uint32_t cp = (uint8_t)seq[0] & (0xFFu >> (seq.size() + 1));
    for (size_t i = 1; i < seq.size(); i++) cp = (cp << 6) | ((uint8_t)seq[i] & 0x3F);
    char buf[16];
    snprintf(buf, sizeof buf, " (U+%04X)", (unsigned)cp);
    return s + buf;
}

// The lexer holds exactly one current token. The parser copies the whole Lexer
// object where it needs to look ahead and backtrack, so it holds nothing
// that is not that token's: the file name is a view of the driver's.
struct Lexer {
    const char *p = nullptr;         // Scan position in the 0-terminated source.
    const char *linestart = nullptr;
    int line = 1;
    string_view filename;
    const char *source = nullptr;    // The whole text, for the line an error echoes.
    int fileidx = 0;                 // The file's index in Ast::sources, for diagnostics.

    // One past the previous token: where a construct that ended with it
    // ends (Parser::PrevEnd).
    const char *prevend = nullptr;
    const char *prevendlinestart = nullptr;
    int prevendline = 1;

    // Current token.
    TType tok = T_EOF;
    string_view attr;                // Source text of ident/literal tokens.
    int64_t ival = 0;                // T_INTLIT value (also char literals).
    bool iuns = false;               // T_INTLIT above i64.max: a u64 constant.
    double fval = 0;                 // T_FLTLIT value.
    string sval;                     // T_STRLIT decoded value.
    bool smultiline = false;         // T_STRLIT: a """ string spanning lines.
    int tokline = 1;
    const char *toklinestart = nullptr;
    // A token's scan is under way: an error raised now is the lexer's own,
    // with the scan position inside the token (SkipBrokenToken).
    bool scanning = false;
    // The documentation above the current token: the run of // comment
    // lines, each on a line of its own and directly below the one before,
    // that ends on the line before the token; from the first // to the end
    // of the last line. Empty for a token with none.
    string_view doc;
    // The `{` scanned so far less the `}`, the current token's included
    // (DepthBefore).
    int curlies = 0;

    shared_ptr<LexicalFile> cached_file;

    Lexer(string_view _filename, const char *_source, int _fileidx = 0,
          size_t source_size = string_view::npos)
        : p(_source), filename(_filename), source(_source), fileidx(_fileidx) {
        linestart = p;
        if (active_lexical_cache)
            cached_file = active_lexical_cache->Attach(filename,
                source_size == string_view::npos ? string_view(source) : string_view(source, source_size));
        Next();
    }

    [[noreturn]] void Error(const string &msg) { ErrorAt(msg, tokline, toklinestart); }

    // How many braces are open before the current token, which is where a
    // recovering parse is (Parser::SkipBody).
    int DepthBefore() const { return curlies - (tok == T_LCURLY) + (tok == T_RCURLY); }

    // The token after the current one, without moving. One the lexer
    // rejects reads as the end: the scan that reaches it raises the error.
    TType PeekTok() const {
        auto copy = *this;
        try {
            copy.Next();
        } catch (CompileError &) {
            return T_EOF;
        }
        return copy.tok;
    }

    // An error on a line of the source, which its text echoes, with a caret
    // under the given position, else under the token's start where the line
    // is the token's. The caret's column is the error's; it extends over the
    // token where the caret is at one that lies on one line, else one byte.
    [[noreturn]] void ErrorAt(const string &msg, int errline, const char *errlinestart,
                              const char *caret = nullptr) {
        auto d = Diagnose(msg, errline, errlinestart, caret);
        throw CompileError { d.text, { d } };
    }

    // The diagnostic ErrorAt would throw, for one the parser reports and
    // goes on past.
    Diagnostic Diagnose(const string &msg, int errline, const char *errlinestart,
                        const char *caret = nullptr) {
        Diagnostic d;
        d.where = { fileidx, errline, 0, 0, 0 };
        d.message = msg;
        if (errlinestart) {
            auto end = errlinestart;
            while (*end && *end != '\n' && *end != '\r') end++;
            auto caretpos = caret ? caret : errlinestart == toklinestart ? attr.data() : nullptr;
            if (caretpos && caretpos >= errlinestart && caretpos <= end) {
                d.where.col = (int)(caretpos - errlinestart) + 1;
                auto len = caretpos == attr.data() && attr.find('\n') == string_view::npos
                               ? attr.size() : (size_t)0;
                d.where.endline = errline;
                d.where.endcol = d.where.col + (int)max<size_t>(len, 1);
            }
        }
        d.text = RenderDiagnostic(d, filename, errlinestart ? string_view(source) : string_view(),
                                  true);
        return d;
    }

    // Where the parser recovers from an error the scan of a token raised
    // (`scanning`: an escape, a character or a string the lexer rejected),
    // the rest of that token is no token either: the scan goes on after
    // the line, or for a """ string after its closing quotes where it has
    // them.
    void SkipBrokenToken() {
        if (!scanning) return;
        auto start = attr.data();
        if (start[0] == '"' && start[1] == '"' && start[2] == '"') {
            auto close = strstr(start + 3, "\"\"\"");
            if (close) {
                // `line` counts the line breaks before linestart, which
                // LexRawString moves past p through the lines it checked
                // before the one it raised the error on.
                for (auto q = linestart; q < close; q++)
                    if (*q == '\n') { line++; linestart = q + 1; }
                p = close + 3;
                Next();
                return;
            }
        }
        while (*p && *p != '\n') p++;
        Next();
    }

    void Next() {
        auto cache = active_lexical_cache;
        if (!cache || !cached_file) {
            if (cache) cache->Scanned(nullptr);
            ScanNext(); return;
        }
        auto position = size_t(p - source), start = size_t(linestart - source);
        auto before_line = line, before_curlies = curlies;
        auto it = cached_file->transitions.find(position);
        if (it != cached_file->transitions.end()) {
            auto &t = it->second;
            if (t.before_line == line && t.before_line_start == start && t.before_curlies == curlies) {
                prevend = p; prevendline = line; prevendlinestart = linestart;
                p = source + t.after_position; linestart = source + t.after_line_start;
                line = t.after_line; curlies = t.after_curlies;
                tok = TType(t.token); tokline = t.token_line;
                toklinestart = source + t.token_line_start;
                attr = string_view(source + t.attribute, t.attribute_size);
                doc = t.has_documentation ? string_view(source + t.documentation, t.documentation_size) : string_view();
                scanning = false;
                if (tok == T_INTLIT) { ival = t.value.integer; iuns = t.unsigned_integer; }
                else if (tok == T_FLTLIT) fval = t.value.floating;
                else if (tok == T_STRLIT) { sval = *t.string_value; smultiline = t.multiline; }
                cache->Hit(*cached_file, t);
                return;
            }
        }
        cache->Scanned(cached_file.get());
        ScanNext();  // A failed scan is never stored: preserve recovery timing.
        LexicalTransition t;
        t.before_line = before_line; t.before_line_start = start; t.before_curlies = before_curlies;
        t.after_position = size_t(p - source); t.after_line_start = size_t(linestart - source);
        t.after_line = line; t.after_curlies = curlies;
        t.token = int(tok); t.token_line = tokline; t.token_line_start = size_t(toklinestart - source);
        t.attribute = size_t(attr.data() - source); t.attribute_size = attr.size();
        t.has_documentation = doc.data() != nullptr;
        if (t.has_documentation) { t.documentation = size_t(doc.data() - source); t.documentation_size = doc.size(); }
        if (tok == T_INTLIT) { t.value.integer = ival; t.unsigned_integer = iuns; }
        else if (tok == T_FLTLIT) t.value.floating = fval;
        else if (tok == T_STRLIT) { t.string_value = make_unique<string>(sval); t.multiline = smultiline; }
        cache->Store(*cached_file, position, std::move(t));
    }

    void ScanNext() {
        prevend = p;
        prevendline = line;
        prevendlinestart = linestart;
        // The run of // comment lines on lines of their own, each directly
        // below the one before, that the scan has passed: the token's
        // documentation where it ends on the line above the token.
        const char *docstart = nullptr, *docend = nullptr;
        int docline = 0;
        again:
        for (;;) {
            auto c = *p;
            if (c == ' ' || c == '\t' || c == '\r') { p++; }
            else if (c == '\n') { p++; line++; linestart = p; }
            else break;
        }
        auto start = p;
        tokline = line;
        toklinestart = linestart;
        doc = docstart && docline + 1 == line ? string_view(docstart, (size_t)(docend - docstart))
                                              : string_view();
        // An error raised while the token is still being scanned puts its
        // caret at the token's start.
        attr = string_view(start, 0);
        scanning = true;
        auto Set = [&](TType t) {
            tok = t;
            attr = string_view(start, (size_t)(p - start));
            scanning = false;
        };
        auto c = *p++;
        switch (c) {
            case 0:   p--; Set(T_EOF); return;

            case '(': Set(T_LPAREN);   return;
            case ')': Set(T_RPAREN);   return;
            case '[': Set(T_LBRACKET); return;
            case ']': Set(T_RBRACKET); return;
            case '{': curlies++; Set(T_LCURLY); return;
            case '}': curlies--; Set(T_RCURLY); return;
            case ',': Set(T_COMMA);    return;
            case ';': Set(T_SEMI);     return;
            case ':':
                if (*p == ':') { p++; Set(T_COLONCOLON); } else Set(T_COLON);
                return;
            case '?': Set(T_QUESTION); return;
            case '~': Set(T_BITNOT);   return;

            case '.':
                if (*p == '.') { p++; Set(T_DOTDOT); }
                else if (*p == '=' && p[1] == '=') { p += 2; Set(T_DOTEQ); }
                else if (*p == '!' && p[1] == '=') { p += 2; Set(T_DOTNEQ); }
                else if (*p == '=') { p++; Set(T_DOTASSIGN); }
                else Set(T_DOT);
                return;
            case '+':
                if (*p == '+') { p++; Set(T_INC); }
                else if (*p == '=') { p++; Set(T_PLUSEQ); }
                else Set(T_PLUS);
                return;
            case '-':
                if (*p == '-') { p++; Set(T_DEC); }
                else if (*p == '=') { p++; Set(T_MINUSEQ); }
                else if (*p == '>') { p++; Set(T_ARROW); }
                else Set(T_MINUS);
                return;
            case '*':
                if (*p == '=') { p++; Set(T_MULEQ); } else Set(T_MUL);
                return;
            case '%':
                if (*p == '=') { p++; Set(T_MODEQ); } else Set(T_MOD);
                return;
            case '=':
                if (*p == '=') { p++; Set(T_EQ); }
                else if (*p == '>') { p++; Set(T_FATARROW); }
                else Set(T_ASSIGN);
                return;
            case '!':
                if (*p == '=') { p++; Set(T_NEQ); } else Set(T_NOT);
                return;
            case '<':
                if (*p == '=') { p++; Set(T_LTEQ); }
                else if (*p == '<' && p[1] == '=') { p += 2; Set(T_SHLEQ); }
                else if (*p == '<') { p++; Set(T_SHL); }
                else Set(T_LT);
                return;
            case '>':
                if (*p == '=') { p++; Set(T_GTEQ); }
                else if (*p == '>' && p[1] == '=') { p += 2; Set(T_SHREQ); }
                else if (*p == '>') { p++; Set(T_SHR); }
                else Set(T_GT);
                return;
            case '&':
                if (*p == '&') { p++; Set(T_ANDAND); }
                else if (*p == '=') { p++; Set(T_ANDEQ); }
                else Set(T_BITAND);
                return;
            case '|':
                if (*p == '|') { p++; Set(T_OROR); }
                else if (*p == '=') { p++; Set(T_OREQ); }
                else Set(T_BITOR);
                return;
            case '^':
                if (*p == '=') { p++; Set(T_XOREQ); } else Set(T_XOR);
                return;

            case '/':
                if (*p == '/') {
                    // A comment with nothing but indentation before it on
                    // its line joins the run directly above it, or starts
                    // one; one after code on its line is no documentation.
                    auto own = true;
                    for (auto q = linestart; q < start; q++) own = own && (*q == ' ' || *q == '\t');
                    if (own && (!docstart || docline + 1 != line)) docstart = start;
                    while (*p && *p != '\n') p++;
                    if (own) {
                        docend = p > start && p[-1] == '\r' ? p - 1 : p;
                        docline = line;
                    }
                    goto again;
                }
                if (*p == '*') {
                    // Block comments nest, so commenting out code containing them works.
                    p++;
                    for (auto nesting = 1; nesting;) {
                        switch (*p++) {
                            case 0: p--; Error("unterminated /* comment");
                            case '\n': line++; linestart = p; break;
                            case '*': if (*p == '/') { p++; nesting--; } break;
                            case '/': if (*p == '*') { p++; nesting++; } break;
                        }
                    }
                    goto again;
                }
                if (*p == '=') { p++; Set(T_DIVEQ); } else Set(T_DIV);
                return;

            case '\'': {
                ival = LexEscapedChar('\'');
                iuns = false;
                if (*p != '\'') Error("expected closing \' of character literal");
                p++;
                Set(T_INTLIT);
                return;
            }
            case '"': {
                if (p[0] == '"' && p[1] == '"') {
                    p += 2;
                    LexRawString();
                    Set(T_STRLIT);
                    return;
                }
                sval.clear();
                smultiline = false;
                while (*p != '"') sval += (char)LexEscapedChar('"');
                p++;
                Set(T_STRLIT);
                return;
            }

            default: {
                if (isdigit((uint8_t)c)) {
                    if (c == '0' && (*p == 'x' || *p == 'X')) {
                        p++;
                        auto numstart = p;
                        while (isxdigit((uint8_t)*p)) p++;
                        if (p == numstart) Error("hex digits expected after 0x");
                        // C99-style hex floats: 0x1.8p3 (binary exponent required).
                        auto ishexfloat = false;
                        if (*p == '.' && isxdigit((uint8_t)p[1])) {
                            ishexfloat = true;
                            p++;
                            while (isxdigit((uint8_t)*p)) p++;
                        }
                        if (*p == 'p' || *p == 'P') {
                            ishexfloat = true;
                            p++;
                            if (*p == '+' || *p == '-') p++;
                            if (!isdigit((uint8_t)*p)) Error("exponent digits expected in hex float");
                            while (isdigit((uint8_t)*p)) p++;
                        } else if (ishexfloat) {
                            Error("hex float requires a p exponent");
                        }
                        if (ishexfloat) {
                            fval = strtod(string(start, p).c_str(), nullptr);
                            Set(T_FLTLIT);
                            return;
                        }
                        errno = 0;
                        ival = (int64_t)strtoull(string(numstart, p).c_str(), nullptr, 16);
                        if (errno) Error("hex literal too large for 64 bits");
                        iuns = ival < 0;
                        Set(T_INTLIT);
                        return;
                    }
                    while (isdigit((uint8_t)*p)) p++;
                    // A '.' only makes this a float if a digit follows; "1..2" must
                    // lex as int, "..", int.
                    auto isfloat = *p == '.' && isdigit((uint8_t)p[1]);
                    if (isfloat) {
                        p++;
                        while (isdigit((uint8_t)*p)) p++;
                    }
                    if ((*p == 'e' || *p == 'E') &&
                        (isdigit((uint8_t)p[1]) ||
                         ((p[1] == '+' || p[1] == '-') && isdigit((uint8_t)p[2])))) {
                        isfloat = true;
                        p += 2;
                        while (isdigit((uint8_t)*p)) p++;
                    }
                    auto text = string(start, p);
                    if (isfloat) {
                        fval = strtod(text.c_str(), nullptr);
                        Set(T_FLTLIT);
                    } else {
                        // Decimal literals cover the full u64 range; a value
                        // above i64.max is a u64 constant (§2).
                        errno = 0;
                        ival = (int64_t)strtoull(text.c_str(), nullptr, 10);
                        if (errno) Error(cat("integer literal too large for 64 bits: ", text));
                        iuns = ival < 0;
                        Set(T_INTLIT);
                    }
                    return;
                }
                if (IsIdentStart(c)) {
                    while (IsIdentCont(*p)) p++;
                    Set(T_IDENT);
                    static const unordered_map<string_view, TType> keywords = {
                        #define F(t, s) { s, t },
                        TOKENS_KEYWORDS
                        #undef F
                    };
                    auto it = keywords.find(attr);
                    if (it != keywords.end()) tok = it->second;
                    return;
                }
                Error(cat("illegal character: ", QuotedCharAt(start)));
            }
        }
    }

    // The rest of a """ string (§2), p just past the opening """. Raw: no
    // escapes, and the next """ closes it. On one line, its text is what lies
    // between. Otherwise the opening """ ends its line and the closing one
    // starts its own after nothing but indentation, the margin: the text is
    // the lines in between, joined by \n, each without the margin, which all
    // but a line of only whitespace must start with.
    void LexRawString() {
        sval.clear();
        auto q = p;
        while (*q == ' ' || *q == '\t' || *q == '\r') q++;
        smultiline = *q == '\n';
        if (!smultiline) {
            for (; !(p[0] == '"' && p[1] == '"' && p[2] == '"'); p++) {
                if (!*p) Error("unterminated \"\"\" string");
                if (*p == '\n' || (*p == '\r' && p[1] == '\n'))
                    Error("a multi-line string's text starts on the line after its opening \"\"\"");
                sval += *p;
            }
            p += 3;
            return;
        }
        auto first = q + 1;
        auto close = first;
        for (; !(close[0] == '"' && close[1] == '"' && close[2] == '"'); close++)
            if (!*close) Error("unterminated \"\"\" string");
        auto closestart = close;
        while (closestart > first && closestart[-1] != '\n') closestart--;
        auto margin = string_view(closestart, (size_t)(close - closestart));
        if (margin.find_first_not_of(" \t") != string_view::npos)
            ErrorAt("only indentation may come before the closing \"\"\" of a multi-line string",
                    line + 1 + (int)count(first, closestart, '\n'), closestart, close);
        line++;
        for (auto l = first; l < closestart; line++) {
            linestart = l;
            auto e = l;
            while (*e != '\n') e++;
            auto text = string_view(l, (size_t)(e - l));
            // Line breaks are \n whatever the file uses.
            if (!text.empty() && text.back() == '\r') text.remove_suffix(1);
            if (l != first) sval += '\n';
            if (text.substr(0, margin.size()) == margin) {
                sval += text.substr(margin.size());
            } else if (text.find_first_not_of(" \t") != string_view::npos) {
                auto bad = l;
                while ((size_t)(bad - l) < margin.size() && *bad == margin[bad - l]) bad++;
                ErrorAt("a line of a multi-line string must start with the indentation of its "
                        "closing \"\"\"", line, l, bad);
            }
            l = e + 1;
        }
        linestart = closestart;
        p = close + 3;
    }

    // Reads one (possibly escaped) character of a char/string literal body.
    int LexEscapedChar(char quote) {
        auto c = *p++;
        if (c == '\\') {
            auto e = *p++;
            switch (e) {
                case 'n':  return '\n';
                case 't':  return '\t';
                case 'r':  return '\r';
                case '0':  return 0;
                case '\\': return '\\';
                case '"':  return '"';
                case '\'': return '\'';
                case 'x': {
                    if (!isxdigit((uint8_t)p[0]) || !isxdigit((uint8_t)p[1]))
                        Error("\\x escape requires two hex digits");
                    auto hex = [](char h) { return h <= '9' ? h - '0' : (h | 0x20) - 'a' + 10; };
                    auto v = hex(*p) * 16 + hex(p[1]);
                    p += 2;
                    return v;
                }
                default: {
                    p -= 2;
                    auto seq = Utf8CharAt(p + 1);
                    Error(cat("unknown escape sequence: \\", seq.empty() ? QuotedCharAt(p + 1) : string(seq)));
                }
            }
        }
        if (!c || c == '\n') { p--; Error(cat("unterminated ", quote == '"' ? "string" : "character", " literal")); }
        return (uint8_t)c;
    }
};

}  // namespace goose
