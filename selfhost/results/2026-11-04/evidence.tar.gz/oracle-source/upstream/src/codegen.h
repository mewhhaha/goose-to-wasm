// Goose compiler — C code generation. Consumes the optimized specialization
// bodies (FnSpec::body) plus globals and emits one self-contained C file (the
// runtime files from src/runtime/ are prepended by the driver).
//
// Representation (Appendix C; §10.3's hidden-stack-argument strategy):
// * Fixed-size types become packed C types (#pragma pack(1)): scalars, packed
//   structs, fixed/limited arrays wrapped in structs, fixed-mode ADTs as
//   tag + union, references as pointers, slices as { data, len }. Large
//   fixed locals/temporaries keep that layout on scoped data stacks, and
//   internal calls pass private copies by pointer and return via out-pointers.
// * Variable values ("bytes" values) are self-describing byte images on a
//   data stack, held as a uint8_t* to the value start. A resizable value is
//   a header in the owning frame (gs_rhdr: element base + count, C.2) -- or a
//   frame object, the C struct of a resizable-tailed struct's fixed fields
//   with the tail's header last -- plus the elements on a data stack: growth
//   bumps the stack top and the header's count; the base pointer never moves.
// * References to resizable-class values are fat (gs_rref: header + stack);
//   references with reusable-pool provenance additionally carry the hidden
//   freelist (gs_pref). Which form a parameter uses comes from the
//   specialization's RootArg info, not the type.
// * Stack assignment (§10.3) is fully dynamic: every stack-using function
//   takes a hidden `int64_t gs_sp` argument, its nonfixed locals/temps use
//   gs_stks[gs_sp + k] with per-function constant k, and callees get
//   gs_sp + <locals in use>. §10.3 explicitly permits this strategy. Globals
//   own dedicated stacks outside the sp-indexed block, so thread programs
//   (which get a fresh block) share all generated functions.
// * Nonfixed return values are constructed directly at a destination stack
//   passed as a hidden gs_stack* argument (guaranteed in-place, §4.3/§7.3);
//   the C function returns nothing for them. `v.append(f())` calls f at v's
//   top and then slides the result's 8-byte length header out (see EmitCall).
// * `return ... from` (§7.9) signals through one thread-local discriminant,
//   gs_rf, plus per-target thread-local channels for the in-flight fixed
//   values (nonfixed ones are built on the target's destination stack,
//   recorded thread-locally at target entry, and moved to where that
//   destination started if the unwound calls had built there first). gs_rf
//   is zero except between a `return ... from` and the catch in its target
//   frame, so only those two points write it: every other exit of a
//   propagating function leaves it alone, and a call on a propagation path
//   costs one load and a never-taken branch.
//
// Scope exits restore data-stack watermarks: every nonfixed local's own base
// pointer doubles as the watermark to restore, so exits (fallthrough, break,
// continue, return, propagate) emit `stack->top = base;` runs in reverse
// declaration order.
//
// This file holds the CodeGen class -- its state, the small utilities, and
// the driver -- with its members declared in the order they are defined
// across codegen_types.h, codegen_frames.h, codegen_values.h,
// codegen_construct.h, codegen_stmts.h, codegen_calls.h, codegen_builtins.h,
// codegen_render.h and codegen_emit.h; the per-node CgX / CgAny / CgStmt
// overrides are codegen_nodes.h.
#pragma once

namespace goose {

// Where a value goes: nowhere (evaluated for effect), into the C lvalue `s`,
// or constructed at the top of the data stack `s`. `t` is the wanted type
// where the receiver knows it; `lenlv` is set for stack destinations of
// resizable class: elements go to the stack, and the construction assigns
// the element count (or the whole frame object) to it. A `pool` lvalue is a
// gs_pref, which a construct's value choosing among pools reaches as each
// branch's pool reference (GenPrefVal).
// DK_BRANCH is where an inlined bool call in a condition delivers its value
// (CodeGen::GenBranch): a branch to label s where the value is `when`,
// leaving the scopes down to `exitscope` on the way, and on through the
// call where it is not.
enum DstKind { DK_DISCARD, DK_LVALUE, DK_STACK, DK_BRANCH };
struct Dst {
    DstKind k = DK_DISCARD;
    string s;
    TypeExpr *t = nullptr;
    string lenlv;
    bool pool = false;
    bool when = false;
    int exitscope = -1;
};

// What a relative store knows of the reference it encodes beyond its type:
// that it is a plain `T&`, never null (CodeGen::RelValue), and that no target
// can lie at the slot's own address, where a self-relative optional slot's
// offset would read as null (CodeGen::RelSlotApart). It is declared outside
// CodeGen because CodeGen's member functions take it as a defaulted argument,
// and clang and gcc reject a default argument of a nested class with member
// initializers before the enclosing class is complete.
struct RelFacts {
    bool nonnull = false;
    bool apart = false;
};

struct CodeGen {
    Ast &ast;

    // Output sections, concatenated by Run() in this order (after the
    // driver-prepended runtime): predefs go before the runtime paste.
    string predefs;
    string tdecls;      // Packed typedefs.
    string pdata;       // Packed static data (string literals).
    string data;        // Queues, long-distance return channels, globals.
    // The members of gs_globals_t, the program instance's globals (§11.1):
    // every global that is not read-only static data, with the dedicated
    // stacks of the resizable ones. Accessed through GS_GL, main's static
    // instance directly or a worker's through the thread-local gs_gl.
    string gblock;
    // The globals a thread program uses, in declaration order: what a spawn
    // copies into the worker's instance (EmitThreadSpawn, EnsureThreadThunk).
    unordered_map<FnSpec *, vector<VarDef *>> threadglobals;
    vector<VarDef *> &ThreadGlobals(FnSpec *entry);
    string protos;
    // Extern fns called by live code, in the order their first call is
    // emitted: the prototypes follow it, and a set of pointers would put
    // them in heap-address order, which differs from run to run.
    vector<FnSpec *> usedexterns;
    // A used extern bound from a shared library (§7.10, the block form) is
    // called through a pointer the runtime fills at start: named by the
    // spec's place among the used externs and its symbol, which is stable
    // across runs and distinct per declaration.
    string DlSlot(FnSpec *sp) {
        auto it = std::find(usedexterns.begin(), usedexterns.end(), sp);
        assert(it != usedexterns.end() && !sp->sf->dylib.empty());
        return cat("gs_dl", it - usedexterns.begin(), "_", sp->sf->cname);
    }
    // The function a call goes through to reach the pointer (ExternProto).
    string DlCall(FnSpec *sp) { return cat(DlSlot(sp), "_call"); }
    // The library a dynamic extern binds from, with the spelling each
    // platform opens: the sidecars' (§7.10), the program's over the
    // package's for a platform either says anything about, and empty where
    // neither does, which leaves the runtime its derived spelling.
    DylibSpelling DlSpelling(FnSpec *sp) {
        DylibSpelling r { sp->sf->dylib };
        auto pkg = ast.filepkg[sp->sf->line.fileidx];
        for (auto p : { pkg, 0 }) {
            for (auto &d : ast.packages[p].dylibs) {
                if (d.name != r.name) continue;
                for (auto plat : { "_windows", "_macos", "_linux" }) {
                    auto &s = d.On(plat).empty() ? d.any : d.On(plat);
                    if (!s.empty()) r.On(plat) = s;
                }
            }
        }
        return r;
    }
    static bool SameDylib(const DylibSpelling &a, const DylibSpelling &b) {
        return a.name == b.name && a.onwindows == b.onwindows &&
               a.onmacos == b.onmacos && a.onlinux == b.onlinux;
    }
    // The libraries the used externs bind from, each spelling once, in the
    // order their first declaration comes in the program (file order, then
    // source order).
    vector<DylibSpelling> DlLibs() {
        vector<pair<Line, DylibSpelling>> firsts;
        for (auto sp : usedexterns) {
            if (sp->sf->dylib.empty()) continue;
            auto l = sp->sf->line;
            auto d = DlSpelling(sp);
            auto it = std::find_if(firsts.begin(), firsts.end(),
                                   [&](auto &f) { return SameDylib(f.second, d); });
            if (it == firsts.end()) firsts.emplace_back(l, d);
            else if (pair(l.fileidx, l.line) < pair(it->first.fileidx, it->first.line))
                it->first = l;
        }
        std::stable_sort(firsts.begin(), firsts.end(), [](auto &a, auto &b) {
            return pair(a.first.fileidx, a.first.line) < pair(b.first.fileidx, b.first.line);
        });
        vector<DylibSpelling> libs;
        for (auto &f : firsts) libs.push_back(f.second);
        return libs;
    }
    // What gs_program_init's bind call counted, which the tables that
    // Finish writes must agree with: every function is emitted by then.
    size_t dlbinds = 0;
    string code;        // Function bodies, size/eq helpers, thunks, main.
    string exportprotos;
    bool usesthreads = false;
    bool library = false;
    // Measurement only, and unsound: emit the whole `return ... from`
    // machinery but none of the post-call discriminant checks, so a program
    // that never takes a long-distance return still prints the right answer
    // and the checks' cost can be priced (--unsafe-no-rf-check).
    bool norfcheck = false;

    [[noreturn]] void Fail(Line l, const string &msg) {
        auto s = cat("codegen: ", msg);
        if (l.fileidx >= 0 && l.fileidx < (int)ast.sources.size())
            s = cat(ast.sources[l.fileidx].first, ":", l.line, ": ", s);
        throw CompileError { s };
    }

    // A C string literal (quotes included) for arbitrary bytes; non-printables
    // as 3-digit octal so following characters can never extend an escape.
    // MSVC takes at most 16380 bytes in one literal, so a long string becomes
    // adjacent literals, a line of its text or at most 4000 bytes each.
    static string CStr(string_view v) {
        string s = "\"";
        auto split = v.size() > 4000;
        size_t piece = 0;
        for (size_t i = 0; i < v.size(); i++) {
            auto c = v[i];
            auto u = (uint8_t)c;
            if (c == '"' || c == '\\') { s += '\\'; s += c; }
            else if (u >= 32 && u < 127) s += c;
            else {
                char buf[8];
                snprintf(buf, sizeof(buf), "\\%03o", u);
                s += buf;
            }
            if (split && (c == '\n' || ++piece == 4000) && i + 1 < v.size()) {
                s += "\"\n    \"";
                piece = 0;
            }
        }
        s += '"';
        return s;
    }

    // Abort locations: the file path becomes one static string per source
    // file in the generated code; call sites pass it plus the line number.
    map<int, string> filerefs;

    string FileRef(Line l) {
        auto it = filerefs.find(l.fileidx);
        if (it == filerefs.end()) {
            auto f = l.fileidx >= 0 && l.fileidx < (int)ast.sources.size()
                         ? ast.sources[l.fileidx].first : string("?");
            for (auto &c : f) if (c == '\\') c = '/';
            auto name = Unique(cat("gs_file", filerefs.size()));
            Append(data, "static const char ", name, "[] = ", CStr(f), ";\n");
            it = filerefs.emplace(l.fileidx, name).first;
        }
        return it->second;
    }
    string LocArgs(Line l) { return cat(FileRef(l), ", ", l.line); }

    // The trailing arguments of a gs_add/sub/mul/neg helper call: a signed
    // type's operation takes its location, for the debug build's overflow
    // message (§6.2); unsigned arithmetic wraps and takes none.
    string OvfLocArgs(IntStorage s, Line l) {
        return IsUnsigned(s) ? string() : cat(", ", LocArgs(l));
    }

    // ------------------------------------------------------------------
    // Type utilities on concrete (post-typecheck) types. Sizes of fixed and
    // limited arrays were evaluated during checking; assert rather than
    // re-evaluate.
    //
    // These read what the checker left behind and create nothing: TypeCheck's
    // ClassOf and GetStructInst instantiate a type and validate it, which is
    // the checking half of the same questions and must not happen here.
    // TEq is not TypeEq either: it is equality of C representation, so it
    // ignores `const`, which no C type carries (§9.5).

    int64_t ArrSize(TypeArray *a) {
        assert(a->size >= 0 || !a->sizeexpr);
        return a->size;
    }

    bool TEq(TypeExpr *a, TypeExpr *b);
    StructInst *SI(TypeExpr *t);
    EnumInst *EIOf(TypeExpr *t);
    EnumInst *EIVar(TypeExpr *t);
    // The field runs of a nominal type (ast.h FieldRun); empty for every
    // other kind.
    span<const FieldRun> FieldRuns(TypeExpr *t);
    // As the checker's, over the runs this pass reads rather than builds.
    template<typename F> bool AnyField(TypeExpr *t, F f) { return AnyFieldOf(FieldRuns(t), f); }
    template<typename F> void EachField(TypeExpr *t, F f) { EachFieldOf(FieldRuns(t), f); }
    SizeClass Cls(TypeExpr *t);

    bool IsFix(TypeExpr *t)  { return Cls(t) == SC_FIXED; }
    bool IsResz(TypeExpr *t) { return Cls(t) == SC_RESIZABLE; }
    bool IsBytesT(TypeExpr *t) { return Cls(t) != SC_FIXED; }
    // This is a C backend storage/ABI choice, not a language size class:
    // packed layout, copying, indexing and lifetime rules stay unchanged.
    static constexpr int64_t NATIVE_VALUE_LIMIT = 4096;
    bool IsLargeFixed(TypeExpr *t) { return IsFix(t) && FixedSize(t) > NATIVE_VALUE_LIMIT; }
    bool NeedsStack(TypeExpr *t) { return IsBytesT(t) || IsLargeFixed(t); }
    // Declare a value, replacing name with its C lvalue when stored on a
    // data stack. A binding survives its block; a temporary its statement.
    void FixedLocal(TypeExpr *t, string &name, const string &init = "", bool forlocal = false);
    // A limited array of static capacity, `T[..k]`: a C value of a length
    // and k slots, which any other array or slice of T constructs by copy
    // (§4.2, AdaptToFixed).
    bool IsStaticLimited(TypeExpr *t) {
        return t->kind == TY_ARRAY && t->arr->akind == A_LIMITED && IsFix(t);
    }
    // A resizable-tailed struct with an all-fixed prefix is a frame object
    // (C.2): a C struct of its fixed fields plus its tail's own gs_rhdr (or
    // nested frame object), held in the owning frame like a fixed value;
    // only the innermost tail's elements occupy a data stack. A gs_rref to
    // one carries the object's address in `hdr`.
    bool IsFrameObj(TypeExpr *t) { return t->kind == TY_STRUCT && SI(t)->frameobj; }
    // The C type of a resizable value's header: a frame object's own struct,
    // a gs_rhdr for anything else.
    string RzCT(TypeExpr *t) { return IsFrameObj(t) ? CT(t) : "gs_rhdr"; }
    string FoTailHdr(TypeExpr *t, const string &obj);
    TypeExpr *FoTailArr(TypeExpr *t);
    string FoPrefixSize(TypeExpr *t);
    // The same type as the tail of a value that is not a frame object keeps
    // its fixed fields as bytes in that value, like the enclosing fields.
    int64_t FoBytesPrefix(TypeExpr *t);
    bool IsFatRef(TypeExpr *t);
    bool HoldsFatRef(TypeExpr *t);
    bool HoldsFatRefIn(TypeExpr *t, set<const void *> &open);
    bool IsVoidT(TypeExpr *t) { return !t || t->kind == TY_VOID; }

    IntStorage LenStore(TypeArray *a);

    static int64_t IntSize(IntStorage s) { return IntBits(s) / 8; }

    static const char *IntCT(IntStorage s);
    static const char *IntSfx(IntStorage s);
    static const char *RelCT(IntStorage s, bool uns = false);
    static const char *RelCT(TypeExpr *rt);

    IntStorage TagStore(SEnum *en) { return en->variants.size() <= 256 ? IS_U8 : IS_U16; }
    int64_t TagSize(SEnum *en) { return IntSize(TagStore(en)); }

    // Packed layout of a run of fields: byte offsets aligned with the fields
    // vector (pads get their own offset), plus the total size. Fixed types
    // only; the same code computes the static prefix of variable structs.
    struct Layout {
        vector<int64_t> offs;
        int64_t size = 0;
    };
    map<pair<const void *, int>, Layout> layouts;   // StructInst / (EnumInst, variant).

    int64_t PadAlign(TypeExpr *t);
    Layout LayoutFields(const vector<Field> &fields, const vector<TypeExpr *> &ftypes);
    const Layout &StructLayout(StructInst *si);
    const Layout &VariantLayout(EnumInst *ei, int vi);
    int64_t FixedSize(TypeExpr *t);

    // ------------------------------------------------------------------
    // Naming: one global identifier space for types, functions, globals, and
    // static data; per-function spaces for locals seeded from it.

    set<string> used;

    string Sanitize(string_view name);
    string Sanitize(string_view ns, string_view name);
    string Unique(string base);

    // ------------------------------------------------------------------
    // Mangled type identities and on-demand C type emission. The mangle keys
    // every per-type artifact (typedef, size fn, eq fn); the C name is the
    // uniquified mangle.

    string Mangle(TypeExpr *t);
    string RawMangle(TypeExpr *t);
    bool SameMangle(TypeExpr *a, TypeExpr *b);
    map<VarDef *, int> ixmangles;   // Index types' arrays, numbered for Mangle.
    // Per raw spelling, the types it was handed out for (one of each set of
    // parts, SameMangle) with the mangle each got; and every mangle handed out.
    unordered_map<string, vector<pair<TypeExpr *, string>>> mangleowners;
    unordered_set<string> mangles;

    unordered_map<string, string> ctypes;   // mangle -> emitted C type name.
    bool corebuiltins = false;

    void EmitCoreTypes();
    string CT(TypeExpr *t);
    static bool StructLike(TypeExpr *t);
    string NameCT(TypeExpr *t);
    set<string> cdefined;    // Mangled names whose C body has been emitted.
    set<string> slicects;    // The C typedef names of slice types.

    void EmitCFields(string &d, const vector<Field> &fields, const vector<TypeExpr *> &ftypes);

    // Tag constants, one enum per EnumInst: <Mangle>_<Variant>_k.
    set<EnumInst *> tagenums;
    unordered_map<EnumInst *, string> tagprefix;
    unordered_set<string> tagbases;   // The prefixes taken.

    void EnsureTagEnum(EnumInst *ei);
    string TagConst(EnumInst *ei, int vi);

    // The TY_VARIANT type for (enum type, variant index); cached per pair.
    map<pair<EnumInst *, int>, TypeExpr *> varianttypes;

    TypeExpr *VariantType(TypeExpr *enumtype, int vi);

    // ------------------------------------------------------------------
    // Runtime size of a bytes-class value: a generated per-type walker,
    // gs_size_<mangle>(p). Static-size subruns collapse into constants.

    set<string> sizefns, eqfns;

    string SizeX(TypeExpr *t, const string &ptr);
    string SizeFn(TypeExpr *t);
    void EmitSizeWalk(string &b, TypeExpr *t, const string &q);
    void EmitSizeElems(string &b, TypeExpr *elem, const string &q);
    int64_t MinBytes(TypeExpr *t, bool zero = false);

    // ------------------------------------------------------------------
    // The verifier from_bytes runs over an untrusted image
    // (docs/design/serialization.md §5): a generated per-element-type
    // gs_verify_<mangle>(p, n, bm), the same walker shape as the size and
    // equality functions, returning the element count or -1.

    set<string> verifyfns;
    int vtmpn = 0;

    string VTmp() { return cat("v", vtmpn++); }
    bool HasRelRefAny(TypeExpr *t);
    bool NeedsVerifyWalk(TypeExpr *t);
    string VerifyFn(TypeExpr *elem);
    void VNeed(string &b, const string &q, const string &bytes);
    void EmitVerifyWalk(string &b, TypeExpr *t, TypeExpr *elem, const string &q, bool links);
    void EmitVerifyFields(string &b, const vector<Field> &fields,
                          const vector<TypeExpr *> &ftypes, const Layout *lo, int64_t total,
                          TypeExpr *elem, const string &q, bool links);
    void EmitVerifyLink(string &b, TypeExpr *rt, TypeExpr *elem, const string &q,
                        const string &off);

    // ------------------------------------------------------------------
    // default<T>() (§4.2): all-zero bytes are the default of every fixed type
    // -- numbers, false, null, empty slices and limited arrays, variant 0 --
    // except where a field declares its own default, which the checker
    // builds as a literal of the call's own (Call::defaultinit).

    bool HasFieldDefaults(TypeExpr *t);
    void EmitDefaultInto(const string &lv, TypeExpr *t);

    // ------------------------------------------------------------------
    // Structural equality (§4.5): gs_eq_<mangle>. Fixed values pass by value,
    // bytes values as pointers. Gap-free fixed types without floats of more
    // than a few scalars shortcut to memcmp.

    bool BitwiseEq(TypeExpr *t);
    bool ScalarEq(TypeExpr *t);
    int64_t EqScalars(TypeExpr *t, int64_t cap);
    string EqX(TypeExpr *t, const string &a, const string &b);
    string EqFn(TypeExpr *t);
    void EmitEqFixed(string &bo, TypeExpr *t);
    void EmitEqBytes(string &bo, TypeExpr *t);
    void EmitEqWalk(string &bo, TypeExpr *t, const string &pa, const string &pb, int depth);

    // ------------------------------------------------------------------
    // Per-specialization call interface. Signature shape (C.3 order):
    //   [declared params (resizable by-value ones add a gs_stack*)]
    //   [free-variable references, §7.5]
    //   [out-pointers for fixed returns after the first]
    //   [destination stacks for nonfixed returns]
    //   [int64_t gs_sp].
    // The C return value is the first fixed return, else void; a `return ...
    // from` discriminant travels in the thread-local gs_rf, not the signature.

    struct SpecInfo {
        string cname;
        vector<VarDef *> freevars;
        set<const VarDef *> globals; // Transitively touched stack/fat-reference globals.
        bool needssp = false;
        bool hasrf = false;
        bool readsalltops = false;   // Transitively reads every data-stack top.
        int cret = -1;               // Ret index returned as the C value.
    };
    unordered_map<FnSpec *, SpecInfo> sinfo;
    vector<FnSpec *> livespecs;

    // Data stack accounting (codegen_stacks.h). What each emitted function
    // asks for: the calls it hands a stack index, with that index relative
    // to its own (SpTop), and the most stacks its own body opens. The
    // nullptr function is what runs with gs_sp fixed at 0: gs_init_globals
    // and the render functions.
    struct StackCall {
        FnSpec *callee;
        int offset;
        Line line;
    };
    unordered_map<FnSpec *, vector<StackCall>> stackcalls;
    unordered_map<FnSpec *, int> stackown;
    // The most stacks a function can have in use at once, its callees
    // included (BoundStacks): a constant, since no call into a recursive
    // cycle is made with a stack in use (§7.8).
    unordered_map<FnSpec *, int64_t> stackneed;
    // Regions outside the indexed block: the globals' dedicated stacks
    // gs_init_globals reserves for the main program, and what each worker's
    // thunk reserves for its arguments and its copy of the globals.
    int globalregions = 0;
    unordered_map<FnSpec *, int> thunkregions;
    // GS_MAX_STACKS as the program is configured (main.cpp): the most data
    // stacks one thread program may use at once, zero for no limit.
    int64_t maxstacks = 0;
    void NoteStackCall(FnSpec *callee, Line ln) {
        stackcalls[curspec].push_back({ callee, stknext, ln });
    }
    void BoundStacks();
    int64_t ProgramStacks(const vector<FnSpec *> &roots);
    vector<FnSpec *> MainRoots();
    vector<pair<string, FnSpec *>> WorkerEntries();
    void CheckStackLimit(const string &what, int64_t stacks, Line ln);
    // The runtime configuration a report assumes (main.cpp).
    struct StackConfig {
        uint64_t reserve, gap, budget;
        int64_t maxstacks;
    };
    void StackReport(FILE *out, const StackConfig &cfg);

    // Long-distance return targets (§7.9): id, per-ret TLS channels.
    unordered_map<FnSpec *, int> fromids;
    set<FnSpec *> fromemitted;

    bool IsPoolParam(FnSpec *sp, size_t i);
    // The bytes of one unit of a pool's freelist, which its count counts: a
    // slot index, or a node of a slice pool's tree of spans (runtime.h).
    static const char *FlEntrySize(const VarDef *d) {
        return d->reusable == RU_SLICES ? "GS_SPAN_NODE" : "8";
    }

    // Which globals with dedicated data stacks a specialization may touch, its
    // callees included, plus the globals holding a fat reference, whose stack
    // is whichever one that reference is bound to. A call can only move a
    // stack it can name: one handed to it as an argument, or a global it
    // (transitively) mentions. Everything else the caller has cached stays
    // cached across the call.
    string HandedStacks(Node *n);
    string SyncReach(FnSpec *callee, const vector<string> &args, const vector<Node *> &an);
    void CollectSpecs();
    string SigParams(FnSpec *sp, bool decls, bool er = false);
    string SigRet(FnSpec *sp);
    // The members a by-value parameter of type t (a pool reference where
    // pool is set) is passed as, each a (C type, member name); none where it
    // is passed whole.
    vector<pair<string, string>> ParamFields(TypeExpr *t, bool pool);
    void PushArg(vector<string> &args, TypeExpr *t, bool pool, const string &v);
    // The entry code reassembling the parameters ParamFields passes as
    // members, which SigParams' declaring form collects for the function's
    // opening lines.
    string paramcopies;

    // ------------------------------------------------------------------
    // Per-function generation state.

    FnSpec *curspec = nullptr;
    SpecInfo *curinfo = nullptr;
    bool emiter = false;                 // Emitting a spec's element-run twin.
    unordered_map<FnSpec *, string> ernames;   // "" = ineligible.
    vector<FnSpec *> erqueue;
    string body;
    int ind = 1;
    int tmpn = 0;
    int stknext = 0, stkmax = 0;
    string spexpr;                       // "gs_sp" inside functions, "0" at global init.
    set<string> fnused;                  // Local C identifiers.
    unordered_map<string, int> fnnextsuffix;
    unordered_map<const VarDef *, string> vnames;
    unordered_map<const VarDef *, string> vstk;    // Stack expr per nonfixed local.
    unordered_map<const VarDef *, pair<string, string>> vpool;  // fl base name, fl stack expr.
    set<const VarDef *> fvptr;           // Captured fixed vars arriving as pointers.

    // A named result built at its destination (§7.3): the local's elements are
    // written where the value ends up, so only its metadata travels at the
    // return. A destination that wants a length prefix in front of the
    // elements gets those bytes reserved at the declaration and patched at the
    // return, rather than the elements moved out of the way.
    struct NrvoDest {
        string stk;               // Destination stack expression.
        string lenlv;             // Receiving count; empty for a packed value.
        IntStorage ls = IS_U32;   // The prefix's length storage.
        bool prefix = false;      // Reserve prefix bytes and patch the count.
        bool inlined = false;     // Bound by an InlineBlock, not by DetectNrvo.
        bool fo = false;          // A frame object: lenlv receives the whole object.
        string pref, hdr;         // Reserved prefix address, header name (BindLocal).
    };
    unordered_map<const VarDef *, NrvoDest> nrvo;
    vector<string> fdstsaves;            // Epilogue restores for gs_fdst_* saves.

    // Constructions under way per stack, while their parts are emitted
    // (GenConstruct, an inlined body's named result bound there): what they
    // placed sits in front of the top an exit finds on that stack.
    unordered_map<string, int> openat;
    struct OpenAt {
        CodeGen &cg;
        string stk;
        OpenAt(CodeGen &cg, const string &stk) : cg(cg), stk(stk) { cg.openat[stk]++; }
        ~OpenAt() { cg.openat[stk]--; }
    };
    vector<string> dsttop0;              // gs_dst<i>'s top on entry, once needed.

    enum { SC_PLAIN, SC_FN, SC_LOOP, SC_BLOCK, SC_IB, SC_STMT };
    struct CScope {
        int kind;
        int stkbase;
        vector<pair<string, string>> saves;   // (stack expr, base var) to restore.
        SFunction *ibsf = nullptr;            // SC_IB: which returns exit here.
        string brklbl, cntlbl;
        bool usedbrk = false, usedcnt = false;
        Dst dst;                              // Break/IB value destination.
        // A stack dst: the constructions open there on entry, and where its
        // top on entry is declared once an exit needs it (ScopeTop0).
        int open0 = 0;
        size_t topat = 0;
        int topind = 0;
        string top0;
        // SC_LOOP, once its condition is out: the loop can be straight-line
        // code (StraightCode), whose body's && and || may evaluate a right
        // operand unconditionally.
        bool straight = false;
    };
    vector<CScope> cscopes;

    template<typename... Ts> void L(const Ts &...args) {
        body.append((size_t)ind * 4, ' ');
        Append(body, args...);
        body += '\n';
    }

    string T() { return cat("t", tmpn++); }
    string Lbl() { return cat("L", tmpn++); }

    string SpIdx(int k) { return cat("GS(", spexpr, " + ", k, ")"); }
    string SpTop() { return cat(spexpr, " + ", stknext); }   // First free index.
    // A call into the recursive cycle the function being emitted is in
    // (§7.8) is made with none of its stacks in use: the checker rejects
    // every shape that would hold one across it (TypeCheck::JoinCycle), so
    // every activation of the cycle starts its stacks at the same index and
    // a program's stack count is static. One in use here is a checker gap,
    // never a program's to work around.
    void NoStackAcrossCycleCall(FnSpec *callee, Line ln) {
        if (!curspec || !curspec->incycle || !callee->incycle || !stknext) return;
        auto cycle = [](FnSpec *s) { while (s->cyclelink) s = s->cyclelink; return s; };
        if (cycle(callee) != cycle(curspec)) return;
        Fail(ln, cat("internal: ", curspec->sf->name, " holds ", stknext, " data stack(s) "
                     "across its call into the recursive cycle through ", callee->sf->name,
                     " (§7.8)"));
    }
    // Whether a fixed value above NATIVE_VALUE_LIMIT is held on a data
    // stack here (FixedLocal). Inside a function of a recursive cycle it is
    // a native local instead: the recursion's depth is bounded by the
    // native stack already, and a data stack held across a call into the
    // cycle would cost a stack per activation (NoStackAcrossCycleCall).
    bool LargeFixedOnStack(TypeExpr *t) {
        return IsLargeFixed(t) && !(curspec && curspec->incycle);
    }

    // ------------------------------------------------------------------
    // Data-stack top caching. A bump pointer read and written through
    // gs_stks[i].top is memory the C backend must reload after every byte
    // store, because a `uint8_t *` store may alias it; a run of pushes then
    // costs a load, an add and a store each instead of register arithmetic.
    // So a stack the function owns keeps its top in a local, and memory is
    // synchronized only where something else can observe it: across calls
    // (which may be handed the stack) and at every function exit.
    //
    // The local pays for itself only where the stack actually grows, and
    // elsewhere it is a live pointer holding a register for nothing, so it is
    // confined to the loops that grow the stack: a kernel loop that only reads
    // and writes elements of an array keeps the memory form for it. Growth
    // outside every loop caches the stack over the innermost block around it,
    // which is the whole body for growth at its top level: a stack grown once
    // in one branch of a long function is no local live, and synced at every
    // call, through all of it.
    //
    // Soundness rests on one spelling per cached stack. Own stacks qualify:
    // a callee's indices start above the caller's in-use watermark (§10.3), so
    // `GS(gs_sp + k)` names a stack no caller expression can also name, and
    // global stacks live outside the indexed block entirely. A reference to a
    // resizable carries its stack inside the reference value (`p.stk`), which
    // is a second spelling for a stack the body may also name directly, so
    // which stacks a function caches depends on the references it holds,
    // class by class (PlanTopClasses): its own, the globals', its captured
    // resizables', its return destinations'.
    //
    // It caches its reference parameters' stacks instead, where RefTopsOk
    // clears it: `p.stk` is then the body's only spelling of that stack, and
    // the checker's root classes say which parameters are distinct stacks
    // (§10.2). That is the form a push through a reference wants -- `*(T *)top
    // = e; top += n` with top in a register -- and the same marks carry it
    // across calls.
    vector<string> toporder;                  // Cacheable stacks, discovery order.
    // A stack and the region (loop, block or construction) it is cached over,
    // -1 meaning the whole body.
    struct TopRegion { int stk, loop; };
    vector<TopRegion> growth;                // Every growth or shrink.
    vector<int> loopparent;                   // Loop -> enclosing loop, or -1.
    vector<int> loopstack;                    // Loops open at this point of the emission.
    // Planning produces a value consumed only while finishing this body;
    // emission does not retain a second mutable set of region state.
    struct TopCachePlan {
        vector<TopRegion> regions;
        vector<string> fnlocals;             // Stack -> whole-body local, or "".
        string fnlens;                       // Whole-body length locals' declarations.
        bool IsRegion(int k, int id) const {
            for (auto r : regions) if (r.stk == k && r.loop == id) return true;
            return false;
        }
    };
    // The count of a resizable whose header is reached through memory -- a
    // reference parameter's `p.hdr->len`, a global's, a captured one's -- is
    // as much a store-to-load chain as the top when every push bumps it: a
    // byte store may alias it. Where the stack under it is cached, so is the
    // count, over the same extent and synchronized at the same points
    // (LenSlot, ExpandTopMarkers). Only a header with a single plain spelling
    // qualifies, and only where every other mention of that header in the
    // extent is one the expansion can see is harmless: its base, or one
    // between a call's flush and reload of the stack.
    struct LenSlot {
        int stk;          // The cached stack the count's array grows on.
        string lenlv;     // The count's one spelling.
        string root;      // The header's spelling, which other mentions would share.
    };
    vector<LenSlot> lenslots;
    void NoteLen(const string &stk, const string &lenlv);
    static bool LenRoot(const string &lenlv, string &root);
    bool cachetops = false;             // Any class below is cached.
    bool topown = false;                // Own indexed stacks, `GS(gs_sp + k)`.
    bool topglob = false;               // Globals' dedicated stacks.
    bool topcap = false;                // Captured resizables' stacks.
    bool topdst = false;                // Return destinations, `gs_dst<i>`.
    bool reftops = false;               // Reference parameters' stacks.
    set<string> refstkexprs;            // Their `<param>.stk` / `.flstk` spellings.
    set<string> capstkexprs;            // The captured resizables' `<fv>_stk` spellings.

    static constexpr const char *FLUSHMARK = "@@gsflush@@";
    static constexpr const char *RELOADMARK = "@@gsreload@@";
    static constexpr const char *LOOPMARK = "@@gsloop@@";
    static constexpr const char *TOPMARK = "@@gstop";

    set<string> gstkexprs;   // Every global's dedicated stack expression.

    bool CacheableStk(const string &stk);
    int TopIdx(const string &stk);
    string Top(const string &stk);
    string TopW(const string &stk);

    // Sync points are marked rather than written, because a stack first used
    // after a call still needs that call's reload: the expansion happens once
    // the whole body is emitted and every cached stack is known. The mark
    // carries what the call can reach, so expansion can sync just those --
    // "*" means everything, which is what a function exit needs.
    void MarkFlush(const string &reach = "*")  { if (markers) L(FLUSHMARK, reach); }
    void MarkReload(const string &reach = "*") { if (markers) L(RELOADMARK, reach); }

    bool markers = false;                // A specialization's body: markers are expanded.
    // Region -> "" for a loop, BLOCKREGION for a block, the stack for a
    // construction.
    vector<string> loopcons;
    static constexpr const char *BLOCKREGION = "{";
    bool InConsOf(const string &stk);
    int OpenRegion(const string &cons);
    int MarkLoopBegin();
    int MarkBlockBegin();
    void MarkLoopEnd(int id);
    int MarkConsBegin(const string &stk);
    struct ConsRegion {
        CodeGen &cg;
        int id;
        ConsRegion(CodeGen &cg, const string &stk) : cg(cg), id(cg.MarkConsBegin(stk)) {}
        ~ConsRegion() { cg.MarkLoopEnd(id); }
    };
    TopCachePlan PlanTopCaches();
    static bool LineIs(string_view s, const char *pfx);
    static string_view GotoTarget(string_view line);
    static string_view LabelHere(string_view line);
    static string_view NextLine(const string &b, size_t &i, size_t &ind0);
    string ExpandTopMarkers(const string &b, TopCachePlan &plan);
    string ExpandTopMarkers1(const string &b, TopCachePlan &plan, vector<bool> &lenok, bool &clean);
    string HoistAggregateDecls(string &b);
    vector<string> BraceFields(const string &ct);
    static vector<string> SplitBraceInit(const string &init);
    void PushSc(int kind);
    void EmitRestores(const CScope &s);
    void PopSc();
    void EmitExitRestores(int to);
    string AllocStk(bool forlocal);
    void SaveBase(bool forlocal, const string &stk, const string &basevar);

    // Globals keep their names for the whole run; locals are named per
    // function (a captured variable gets an independent name as the hidden
    // parameter of each capturer — arguments are positional).
    unordered_map<const VarDef *, string> gnames;
    unordered_map<const VarDef *, string> gstks;
    unordered_map<const VarDef *, pair<string, string>> gpools;

    // The base an `in pool` offset is measured from (§3.9), per function: the
    // pool's element region, which its stack's reservation fixes once and
    // growth never moves. A byte store through a `uint8_t *` may alias the
    // header in C, so reading `pool.base` per access would reload it after
    // every relative store; each function that needs it loads it once into a
    // local instead, emitted at entry by EmitSpec.
    vector<pair<const VarDef *, string>> poolbases;
    set<const VarDef *> poolglobals;   // Globals some `in pool` type names.

    string PoolBase(const VarDef *pool);
    string PoolBaseOr(const VarDef *vd, const string &hdrbase);
    string LocalName(VarDef *vd);
    string VName(const VarDef *vd);

    // ------------------------------------------------------------------
    // Locations: an assignable/addressable path resolved to either a typed C
    // lvalue (val) or a byte pointer (bytes values, packed dynamic layouts).
    // The root's data stack (and pool freelist) ride along for growth ops.

    // For resizable-class locations, `s` is the data pointer (elements for
    // arrays, struct start for resizable-tailed structs) and `lenlv` the
    // int64 length lvalue of the owning header; `fl` is a gs_rhdr lvalue for
    // a reusable pool's freelist.
    struct Loc {
        string s;
        TypeExpr *t = nullptr;
        bool val = false;
        bool ispref = false;   // s is a gs_pref-typed lvalue (pool reference).
        // A reference on the way here can be rebound -- one held in a `var`
        // variable, a field or an element (for a reference location, the
        // reference itself) -- so evaluating s later may reach other storage.
        bool viaref = false;
        string stk, lenlv, fl, flstk;
        string hdr;            // The resizable's own header/frame-object lvalue, when it has one.
        // A loop-hoisted view of the array behind this reference (see `views`):
        // set on the reference by VarLoc, and, for the length, carried across
        // the deref to the pointee, where ArrayView reads it instead of memory.
        string hbase, hlen;
        // A reference variable standing for a resizable variable or a frame
        // object's tail (refalias): its pointee is that location.
        const VarDef *aliasof = nullptr;
        Node *aliaspath = nullptr;
    };

    bool PrefVar(const VarDef *vd);

    // A fat reference variable that cannot be rebound, bound to a resizable
    // variable or to another such reference -- an inlined callee's `A&`
    // parameter, a base-case inlining's copy of a reference argument, a
    // function value's reference parameter -- names exactly what its
    // initializer names for its whole life. It is emitted as no C variable
    // of its own: every use reads the variable it stands for, so the stack
    // and the header keep the one spelling top caching needs (§6.10), and a
    // local's header is not made to escape by a pointer nothing needs.
    unordered_map<const VarDef *, const VarDef *> refalias;
    // An alias of a frame object's tail: the field path it was bound to,
    // from refalias's variable.
    unordered_map<const VarDef *, Node *> aliaspath;
    set<const VarDef *> aliasbound;          // The aliases whose binding has been emitted.
    set<const VarDef *> capturedvars;        // Every live specialization's free variables.
    void FindRefAliases(FnSpec *sp);
    const VarDef *AliasTarget(VarDef *d, Node *init, Node *&path);
    static bool HandedRef(Node *n);
    static Node *FieldChainRoot(Node *n, bool typed);

    // Optimizer splices can leave a reference-typed tree in a slot whose
    // checked type already decayed; Dst::t says what the receiver wants, and
    // the pointee load then happens at the leaf against it.

    bool NeedsDeref(TypeExpr *have, TypeExpr *want);
    Loc FatRefLoc(const string &x, TypeExpr *sub);
    Loc BytesLoc(const string &ptr, TypeExpr *t, const Loc &from);
    void RelParts(const Loc &lv, string &faddr, string &off);
    string RelOrigin(TypeExpr *rt, const string &faddr);
    string PointeeLv(const string &p, TypeExpr *t);
    void DerefLoc(Loc &lv);
    void PinLoc(Loc &lv);
    Loc VarLoc(VarDef *vd);
    string HdrLv(VarDef *vd);
    string VarCT(const VarDef *vd);
    string VStkOf(const VarDef *vd);
    string FieldPtr(const string &base, const vector<Field> &fields,
                    const vector<TypeExpr *> &ftypes, int fieldidx);

    // Elements pointer + length expression of an array-typed loc, all kinds.
    struct ArrView {
        string elems;      // Pointer expression (typed for val fixed/limited).
        string len;        // int64 length expression.
        string lenlv;      // Length lvalue for ops that change it (may be typed).
        TypeExpr *elem = nullptr;
        bool typedelems = false;   // elems is CT* (else uint8_t*).
    };

    // The C copy for a run of elements: gs_memcpy takes a slice's null
    // pointer for zero bytes, which memcpy may not be handed.
    static const char *CopyFn() { return "gs_memcpy"; }

    ArrView ArrayView(const Loc &lv);
    ArrView RawArrayView(const Loc &lv);
    // The address of element `i` of a view: typed pointer arithmetic where
    // the elements are typed, byte arithmetic at the element size otherwise.
    string ElemAddr(const ArrView &v, const string &i) {
        return v.typedelems ? cat(v.elems, " + ", i)
                            : cat("(", v.elems, ") + ", i, " * ", FixedSize(v.elem));
    }
    // A limited array's capacity: static for the C-typed form, read from
    // the header of the runtime-capacity byte form.
    string LimitedCap(const Loc &lv) {
        return lv.val ? cat(ArrSize(lv.t->arr)) : cat("(int64_t)*(uint32_t *)(", lv.s, ")");
    }

    // ------------------------------------------------------------------
    // Loop-invariant array views. An array reached through a reference keeps
    // both halves of its view behind that reference, and the C backend reloads
    // them at every access, since a byte store through any reference may alias
    // the header they live in. BCE marks per loop which reference variables it
    // can neither resize nor re-bind (`hoistrefs`); for those the view is read
    // into locals once before the loop and every access inside uses them.
    unordered_map<const VarDef *, pair<string, string>> views;   // base, length.
    // The same for arrays in fields (`hoistfields`), by the root variable an
    // alias stands for (FieldRoot) and the field indices.
    map<pair<const VarDef *, vector<int>>, pair<string, string>> fieldviews;

    bool AddView(VarDef *vd);
    const VarDef *FieldRoot(const VarDef *vd);
    bool AddFieldView(const FieldPath &fp);
    void UseFieldView(Dot *d, Loc &lv);

    // Installs the views a loop body may read, for the extent of that body.
    struct ViewScope {
        CodeGen &cg;
        vector<VarDef *> added;
        vector<pair<const VarDef *, vector<int>>> addedfields;
        ViewScope(CodeGen &_cg, const vector<VarDef *> &refs, const vector<FieldPath> &fields)
            : cg(_cg) {
            for (auto vd : refs) if (cg.AddView(vd)) added.push_back(vd);
            for (auto &fp : fields)
                if (cg.AddFieldView(fp)) addedfields.push_back({ cg.FieldRoot(fp.first), fp.second });
        }
        ~ViewScope() {
            for (auto vd : added) cg.views.erase(vd);
            for (auto &k : addedfields) cg.fieldviews.erase(k);
        }
    };

    string Snapshot(TypeExpr *t, const string &x);
    // Fill operands are evaluated once; literal shells containing relative
    // links are replayed at each slot using these captured leaf values.
    unordered_map<Node *, Loc> fillvalues;
    void FreezeFill(Node *n, TypeExpr *t, vector<Node *> &added);
    struct FillScope {
        CodeGen &cg;
        vector<Node *> added;
        FillScope(CodeGen &cg, Node *n, TypeExpr *t) : cg(cg) { cg.FreezeFill(n, t, added); }
        ~FillScope() { for (auto n : added) cg.fillvalues.erase(n); }
    };
    string GenPure(Node *n);
    string DivX(bool div, IntStorage s, const string &l, const string &r, Line line);
    string ArithX(TType op, TypeExpr *t, const string &l, const string &r, Line line,
                  bool nonneg = false, string lx = "", string rx = "");
    string IndexTypeCheck(const string &x, TypeExpr *t, Line ln);
    static string IntStr(int64_t v);
    static string FltStr(double v, bool f32);
    Loc IndexLoc(Loc lv, Node *idxnode, Line ln, bool nobc);
    Index *LeadingCheck(Node *arm);
    bool SamePath(Node *a, Node *b);
    bool SameCheck(Index *a, Index *b);
    void EmitHoistedCheck(Index *ta, Index *ea, const string &c);
    Loc GenLoc(Node *n);
    bool StableDest(Node *n);
    string BytesTemp(string &stk);
    string RzTemp(TypeExpr *t, string &stk);
    string RzLenLv(TypeExpr *t, const string &h);
    Loc RzTempLoc(TypeExpr *t, const string &h, const string &stk);
    Loc GenRzTmp(Node *n);
    Loc MemberLoc(Loc lv, Dot *d);
    Loc FieldLocAt(Loc lv, int fieldidx);

    // ------------------------------------------------------------------
    // Expression values. GenX produces a C expression for fixed-class values
    // (possibly after emitting statements); GenPtr produces a byte pointer to
    // a bytes-class value. Both follow the node's checked exprtype, which
    // already encodes operand unification and reference decay.

    static bool IsCtl(Node *n);
    string LoadLoc(Loc lv, TypeExpr *et, Line ln);
    string AdaptToFixed(Loc lv, TypeExpr *et, Line ln);
    void CopyIntoLimited(Loc lv, TypeExpr *et, Line ln, const string &dst, bool overlap);
    bool AdaptsToLimited(Node *n, TypeExpr *want);
    bool GenIntoLimited(Node *n, TypeExpr *want, const string &dst, bool overlap);
    string BytesAddrOf(const Loc &lv);
    string GenRefVal(Node *child, Line ln);
    string GenXD(Node *n, TypeExpr *want);
    string GenTruth(Node *n);
    bool SpeculativeForm(Binary *b);
    Binary *ChainOp(Node *n);
    InlineBlock *BranchCall(Node *n);
    bool BranchChain(Node *n);
    void GenBranch(Node *n, bool when, string lbl, int exitscope = -1);
    bool Speculatable(Node *n, bool idxok, bool truth, int &budget);
    bool SpeculatablePlace(Node *n, bool idxok, int &budget);

    // The three per-node passes dispatch virtually (ast.h); the bodies live
    // together in codegen_nodes.h, delegating into the machinery here.
    string GenX(Node *n) {
        if (!substs.empty())
            if (auto s = substs.find(n); s != substs.end()) return s->second;
        auto it = fillvalues.find(n);
        return it == fillvalues.end() ? n->CgX(*this) : LoadLoc(it->second, it->second.t, n->line);
    }
    void GenAny(Node *n, Dst d) {
        if (fillvalues.count(n)) LeafAny(n, d);
        else n->CgAny(*this, d);
    }
    void GenStmt2(Node *n) { n->CgStmt(*this); }

    string CtlValX(Node *n);
    void LeafAny(Node *n, const Dst &d);
    string GenFixedArrayLit(ArrayLit *al);
    string GenPtr(Node *n, string *stkout = nullptr);

    // ------------------------------------------------------------------
    // String literals: static byte data, C const since nothing can write it
    // (§9.5). As a slice: { data, len }. As a u8[...] value: a static
    // [lenfield][bytes] image.

    unordered_map<string, string> strdata;   // text -> raw byte array name.
    unordered_map<string, string> strval;                 // mangle+text -> value name.

    string StrRaw(const string &v);
    string GenStrBytes(StrLit *s);
    map<string, string> blobdata;
    string BlobRaw(const string &v);

    // ------------------------------------------------------------------
    // Binary operators. Operand exprtypes are already decayed and unified.

    TypeExpr *OperandT(TypeExpr *t);
    string GenVal(Node *n);
    string GenPureVal(Node *n);
    string GenOperandVal(Node *n, bool later);
    static bool IsCName(const string &x);
    bool HasStmts(Node *n);
    string GenEquality(TypeExpr *lt, const string &l, const string &r);
    string GenSliceEq(TypeExpr *st, const string &l, const string &r);
    string GenRangeEq(TypeExpr *elem, const string &ae, const string &an, const string &be,
                      const string &bn);
    void GenElemwiseInto(TypeExpr *t, TType op, Line line, const string &l,
                         const string &r, const string &dst,
                         bool lscalar = false, bool rscalar = false);
    void GenElemwiseNegInto(TypeExpr *t, Line line, const string &x, const string &dst);
    void GenElemwiseLeaves(TypeExpr *t, const string &dst,
                           const function<string(TypeExpr *, const string &)> &leaf);
    void ElemwiseOperands(Binary *b, string &l, string &r);
    string GenElemwise(Binary *b, const string &l, const string &r);
    string GenSlice(SliceExpr *se, const string &into = "");

    // ------------------------------------------------------------------
    // Construction (§4.2/§4.3): writes a value front-to-back at a stack's
    // top, bumping it. All branches of value-producing control constructs
    // construct to the same destination; calls pass the stack down.

    // A bounded target has no inaccessible guard pages. Reserve before a
    // write, and before a bump that only leaves room to be filled later.
    // The explicit top may be a cached local rather than stk->top.
    void Reserve(const string &stk, const string &n) {
        L("gs_stack_require(", stk, ", ", Top(stk), ", (uint64_t)(", n, "));");
    }
    void RequireWrite(const string &at, const string &n) {
        L("gs_write_require((const uint8_t *)(", at, "), (uint64_t)(", n, "));");
    }
    template<class Size> string StackBytes(const string &n, const Size &esz) {
        return cat("gs_stack_bytes((uint64_t)(", n, "), ", esz, ")");
    }
    void Bump(const string &stk, const string &n) {
        // n can be a write (gs_uleb_write/gs_zig_write), which checks its
        // own destination. Evaluate it once before checking the bump.
        if (n.find("gs_uleb_write(") != string::npos ||
            n.find("gs_zig_write(") != string::npos) {
            auto count = T();
            L("int64_t ", count, " = ", n, ";");
            Reserve(stk, count);
            L(TopW(stk), " += ", count, ";");
        } else {
            Reserve(stk, n);
            L(TopW(stk), " += ", n, ";");
        }
    }

    void EmitValStore(const string &stk, TypeExpr *t, const string &x);
    void StoreWhole(const string &p, TypeExpr *t, const string &x);
    void EmitLenCheck(IntStorage ls, const string &n);
    void EmitLenStore(const string &stk, IntStorage ls, const string &n);
    void EmitArrayCount(const string &stk, TypeExpr *at, const string &lenlv, const string &n,
                        bool check);
    void EmitVarintStore(const string &stk, const string &x);
    void EmitRelRangeCheck(TypeExpr *rt, const string &off, Line ln, bool inroot);
    RelFacts RelValue(Node *v);
    bool RelSlotApart(TypeExpr *rt, TypeExpr *holder, int64_t off);
    string RelOffset(TypeExpr *rt, const string &org, const string &rv, Line ln, RelFacts f);
    void EmitRelStoreAt(const string &fa, TypeExpr *rt, const string &rv, Line ln, bool inroot,
                        RelFacts f = {});
    void EmitRelStore(const string &stk, TypeExpr *rt, const string &rv, Line ln,
                      RelFacts f = {});
    void EmitRelSelfAt(const string &fa, TypeExpr *rt, int64_t fieldoff, Line ln,
                       bool inroot = true);
    void EmitRelSelfStore(const string &stk, TypeExpr *rt, int64_t fieldoff, Line ln);
    bool HasRelRef(TypeExpr *t);
    bool NeedsResultLocation(TypeExpr *t) { return IsFix(t) && t->kind != TY_REF && HasRelRef(t); }
    bool HasSelfRelRef(TypeExpr *t);
    void NoSelfRelCopy(Node *val);
    bool HasUninitSlots(TypeExpr *t);

    // Byte span of the largest fixed value that can be a relative
    // reference's root array (§3.9). Roots are variables, so this is the
    // widest offset a store into a root that is *not* on a data stack can
    // produce; stack roots are bounded by GS_STACK_RESERVE instead. Both
    // bounds decide whether EmitRelStoreAt emits its range check.
    int64_t relrootmax = 0;

    void ComputeRelRootMax();
    void EmitCopyElems(const string &stk, TypeExpr *elem, const string &src, const string &n);

    // Element count + elements pointer of an array/slice-valued source node,
    // for construction and append. Understands string literals, slices, and
    // all array kinds (through references too).
    struct SrcElems {
        string elems, n;
    };

    SrcElems GenSrcElems(Node *n);
    void GenConstruct(Node *n, const string &stk, TypeExpr *want = nullptr,
                      const string &lenlv = "");
    void ConstructFromLoc(Loc lv, TypeExpr *et, const string &stk, const string &lenlv, Line ln);
    bool CallBuildsAt(Call *c, TypeExpr *rt, TypeExpr *et, const string &lenlv);
    void ConstructCall(Call *c, TypeExpr *et, const string &stk, TypeExpr *want,
                       const string &lenlv);
    TypeExpr *AdtFrom(Node *n);
    void GenAdtAdapted(TypeExpr *from, TypeExpr *to, const Dst &d, Line ln,
                       const function<void(const Dst &)> &gen);
    Dst VariantBehindTag(TypeExpr *from, TypeExpr *to, const Dst &d);
    void GenCallAs(Call *c, TypeExpr *t, const Dst &d);
    void GenArrayFromLoc(Loc lv, TypeExpr *et, const string &stk, Line ln,
                         const string &lenlv = "");
    void EmitRzCopy(Loc lv, TypeExpr *et, const string &stk, const string &lenlv, Line ln);
    void FoBytes(TypeExpr *t, const string &obj, const string &p, bool tobytes);
    Loc FoView(const Loc &lv);
    void GenFoAsBytes(Node *n, const string &stk, TypeExpr *t, const string &lenlv);
    bool RzShape(TypeExpr *t, int64_t &prefix, TypeExpr *&elem);
    void GenVarEnumFromLoc(Loc lv, TypeExpr *et, const string &stk);
    void FixedLitAtStk(Node *n, const string &stk);
    void FixedLitAt(Node *n, const string &dst);
    void FixedLitAtLv(Node *n, const string &base, bool inroot);
    void FixedArrayLitAt(ArrayLit *al, const string &base, bool inroot);
    void StructLitAt(StructLit *sl, const string &base, bool inroot);
    void EmitValStoreTag(const string &stk, IntStorage ts, const string &x);
    // How many elements an array literal writes: its fill count, which the
    // checker evaluated into an IntLit (§4.2), or its element list's length.
    static int64_t LitCount(ArrayLit *al) {
        if (!al->fillval) return (int64_t)al->elems.size();
        assert(Is<IntLit>(al->fillcount));
        return ((IntLit *)al->fillcount)->val;
    }
    void GenArrayLit(ArrayLit *al, const string &stk, const string &lenlv = "",
                     TypeExpr *as = nullptr);
    static bool HasSelfInit(StructLit *sl);
    void GenStructLit(StructLit *sl, const string &stk, const string &lenlv = "");
    void GenFrameObjLit(StructLit *sl, StructInst *si, const string &stk, const string &obj);
    void GenFieldInits(StructLit *sl, const vector<Field> &fields, const vector<TypeExpr *> &ftypes,
                       const string &stk, const string &lenlv = "", const string &selfbase = "");

    // ------------------------------------------------------------------
    // Statements and control flow. GenAny routes a node's value to a Dst;
    // control constructs recurse so every branch reaches the same
    // destination (§4.3). Scopes mirror C braces -- all but a flat if's
    // then-block (IfExpr::flat), which shares the C block the if is in -- so
    // watermark base variables are in C scope wherever exits may restore them.

    bool termjump = false;   // The last emitted statement left via goto/return.

    void GenBlockInner(Block *b, Dst d, size_t first = 0, int exitscope = -1);
    size_t GenInlineArgs(Block *b);
    void GenStmt(Node *n);

    // ------------------------------------------------------------------
    // Loops. Shape: for (<init>; ; <incr>) { [cond exit] body restores cnt:; }
    // Goose break/continue always leave via gotos with explicit watermark
    // restores; C break/continue are never emitted for them, so nesting
    // inside generated switches stays safe. Every exit path restores only
    // the watermarks of declarations it ran past, so the continue label
    // sits after the fallthrough restores rather than sharing them.

    // A Goose loop's scope, open around the C loop or loops that run its body
    // (OpenLoop to CloseLoop): its index and top-caching region, and the
    // divisors fixed for it.
    struct OpenedLoop { int si = -1, loopid = -1; vector<string> divisors; };
    OpenedLoop OpenLoop(Block *bodyb, Node *cond, const vector<const VarDef *> &binders,
                        const Dst &d);
    void CloseLoop(const OpenedLoop &lp);
    void GenLoopBody(const function<void()> &condexit, Block *bodyb, Dst d,
                     const string &forhead = "", Node *cond = nullptr, size_t first = 0,
                     vector<const VarDef *> binders = {});
    static bool StraightCode(Node *n);
    bool InStraightLoop();
    static bool CallsRecursive(Node *n);

    // Divisors fixed for a loop being emitted, by DivisionKey: the C locals
    // holding the divisor's value as a u64, its gs_divu_gen magic and its
    // shift, or as a u32 and gs_divu32_gen's where `narrow` (HoistDivisors).
    // `zeronone`: only a zero divisor leaves it without a magic.
    struct DivMagic { string val, magic, more; bool narrow, zeronone; };
    unordered_map<string, DivMagic> divmagic;
    // The variables of the specialization being emitted that a reference is
    // made to somewhere in it (RefdLocals), for refdspec.
    set<const VarDef *> refdlocals;
    FnSpec *refdspec = nullptr;
    // A `/` or `%`, or a `/=` or `%=` dividing its target (AsDivision): the
    // plain operator, the dividend's type, the divisor, and whether BCE found
    // a signed one to be of nonnegative operands (Binary::nonneg, which BCE
    // judges for no compound assignment).
    struct Division { TType op; TypeExpr *t; Node *divisor; bool nonneg; };
    static bool AsDivision(Node *n, Division &dv);
    bool LoopDivisible(const Division &dv);
    static bool NarrowDivision(const Division &dv);
    string DivisionKey(const Division &dv, const VarDef **root = nullptr, bool *path = nullptr);
    string FixedDivX(const Division &dv, const string &l, const function<string()> &plain,
                     Line line);
    string DivisorKey(Node *n, const VarDef **root = nullptr, bool *path = nullptr);
    string DivisorValue(Node *n, string &ok);
    const set<const VarDef *> &RefdLocals();
    vector<string> HoistDivisors(Block *loopbody, Node *cond, const vector<const VarDef *> &binders);
    void GenBreakPath(Node *val);

    // Loops run in blocks of iterations (ForLoop::stripk, ForLoop::sumred):
    // a loop over whole blocks, then the rest one iteration at a time, each
    // running a copy of the body. A copy names the locals it declares afresh
    // (NameScope), so a body qualifies only where nothing is bound to its
    // locals once per function (Dupable).
    struct NameScope {
        CodeGen &cg;
        unordered_map<const VarDef *, string> vnames, vstk;
        unordered_map<const VarDef *, pair<string, string>> vpool;
        explicit NameScope(CodeGen &_cg)
            : cg(_cg), vnames(_cg.vnames), vstk(_cg.vstk), vpool(_cg.vpool) {}
        ~NameScope() {
            cg.vnames = std::move(vnames);
            cg.vstk = std::move(vstk);
            cg.vpool = std::move(vpool);
        }
    };
    // The terms of an in-order float sum computed ahead per block.
    static constexpr int SUMBLOCK = 8;
    // A loop over an array whose length BCE bounds by a constant is bounded
    // by that constant instead where the C compiler will unroll it whole
    // into few enough exits: a small bound and a small body (ForLoop::CgStmt).
    static constexpr int64_t MAXTRIPBOUND = 8;
    static constexpr int MAXTRIPBODY = 48;
    // Nodes whose value codegen spells as given text instead: a strip-mined
    // loop's `i % K`, which is its inner counter in a block.
    unordered_map<const Node *, string> substs;
    bool DupLocal(VarDef *v);
    bool Dupable(Node *n);
    int BlockSize(ForLoop *f);
    string AtLeastLeft(TypeExpr *ct, const string &hi, const string &ctr, int k, bool fromzero);
    void GenBodyCopy(Block *bodyb, int si, size_t first = 0);
    void GenBlocked(ForLoop *f, int k, const string &more, const string &step,
                    const function<void()> &bind, const string &cond);

    // ------------------------------------------------------------------
    // Exits delivering a value: where the receiver expects it (§7.3, §7.9).

    void EnterDst(int si, const Dst &d);
    void DeclareTop0(size_t at, int indent, const string &name, const string &stk);
    string ScopeTop0(int si);
    string DstTop0(size_t i);
    const NrvoDest *NrvoBoundAt(Node *val, const string &stk, const string &lenlv);
    string ExitStart(Node *val, const string &stk, const string &lenlv, int open0);
    void LandValue(const string &stk, const string &top0, const string &start, TypeExpr *t,
                   const string &lenlv);
    void GenExitValue(Node *val, int si);

    // ------------------------------------------------------------------
    // Declarations and assignment.

    void BindLocal(VarDef *d, Node *init, bool forlocal = true);
    Dst DeclStackLocal(VarDef *d, bool forlocal);
    string GenPrefVal(Node *n);
    string Unique2(const string &base);
    void GenRelAssign(Loc lv, Node *lval, Node *rhs, Line ln);
    void GenRebind(Assign *a, Loc lv);

    // ------------------------------------------------------------------
    // Returns: normal, forwarding a multi-value call, exiting an inlined
    // body, and long-distance (§7.9).

    vector<string> GenForward(Call *c, const vector<TypeExpr *> &rets, const vector<Dst> &chans);
    void GenNormalReturn(const vector<Node *> &vals);

    // The bytes a length prefix of this storage reserves ahead of the
    // elements. A varint takes the one byte that covers counts under 128.
    int64_t PrefixBytes(IntStorage ls) { return ls == IS_VARINT ? 1 : IntSize(ls); }

    void EmitPrefixPatch(const string &pref, IntStorage ls, const string &stk, const string &count,
                         const string &elems);
    void EmitNrvoFinish(const NrvoDest &nd);
    void Epilogue(const string &retv);
    void PropagateReturn(const string &rfval);
    void GenFromReturn(Return *r);

    void EnsureFromChannels(FnSpec *t);

    // ------------------------------------------------------------------
    // Calls. Returns one entry per return value: a C expression for fixed
    // values, the value's base pointer for bytes-class ones. d0 is the
    // preferred destination for the first return (in-place construction);
    // alldst supplies destinations for every return (multi-value receives).

    string CallVal0(Call *c, const string &r0, TypeExpr *want = nullptr);
    Loc CallResLoc(Call *c, const string &r0);
    string BytesResultBase(const Dst &dd, string &stk);
    void EmitSlidePrefix(const string &base, IntStorage ls, const string &stk, const string &lenlv);
    vector<string> EmitCall(Call *c, Dst d0, vector<Dst> *alldst = nullptr);
    void EmitCallInto(Call *c, vector<Dst> &dsts);
    vector<string> EmitExternCall(Call *c, FnSpec *sp);
    string ExternProto(FnSpec *sp);
    vector<Node *> CallArgNodes(Call *c, size_t nparams);
    void EmitArg(FnSpec *sp, size_t i, Node *node, vector<string> &args, bool later);
    void EmitFvArg(const VarDef *fv, vector<string> &args);
    vector<string> EmitSpecCall(Call *c, FnSpec *sp, Dst d0, vector<Dst> *alldst);
    bool NeedsReprefix(const Dst &d, TypeExpr *rt);
    void EmitReprefix(FnSpec *sp, const Dst &dd, const string &base, const string &cnt);
    void EmitRfCheck(FnSpec *callee);
    vector<string> EmitFvCall(Call *c, Dst d0);
    vector<string> EmitDispatch(Call *c, Dst d0, vector<Dst> *alldst);

    // ------------------------------------------------------------------
    // Builtins (§3.3, §3.7, §5.4, §9.3, §11.2). Emitted inline; only I/O, division,
    // varints, and thread/queue machinery call into the runtime.

    unordered_map<string, string> queues;   // Element type mangle -> queue global.

    string QueueFor(TypeExpr *t);
    Loc RecvLoc(Node *n);
    string LenCast(const Loc &lv);
    vector<string> EmitBuiltin(Call *c, Dst d0);

    // ------------------------------------------------------------------
    // Text forms (§3.7): print, str and format share them. A scalar's text
    // comes from a gs_fmt_* runtime helper writing at most GS_FMT_MAX bytes;
    // a u8 array or slice contributes its bytes as they are, and any other
    // value renders structurally into a u8[>..] builder, or through a user
    // `format` overload recorded on the call for its type.

    TypeExpr *growu8 = nullptr;
    TypeExpr *GrowU8();
    Loc TempBuilder();
    Call *FmtContext(Call *c, Node *arg);
    FnSpec *FmtSpecFor(Call *c, TypeExpr *t);
    bool SimpleText(Call *c, TypeExpr *t);
    void RenderLit(Loc &out, const string &text);
    void RenderN(Loc &out, const string &nexpr);
    void RenderLoc(Loc &out, Loc lv, TypeExpr *t, bool nested, Call *c, Line ln);
    void RenderVariant(Loc &out, Loc lv, TypeExpr *t, Call *c, Line ln);
    string RefArg(const Loc &lv, TypeExpr *sub, Line ln);
    string PrefArg(const Loc &lv, Line ln);
    void EmitUserFormat(Loc &out, Loc lv, FnSpec *sp, Line ln);

    // A type that reaches itself through references renders the levels of a
    // value below the first through a C function of its own, which calls
    // itself for the level below: the value is as deep as its references go
    // (RenderFn). No format overload renders a part of such a type (the
    // checker's CheckPrintable), so one function serves every rendering.
    struct RenderFnReq {
        TypeExpr *t = nullptr;
        Line ln;
        string sig;
    };
    unordered_map<string, string> renderfns;   // Type mangle -> function name.
    vector<RenderFnReq> renderqueue;
    vector<TypeExpr *> rendering;   // The nominal types RenderLoc is inside of here.
    string RenderFn(TypeExpr *t, Line ln);
    void EmitRenderCall(Loc &out, const Loc &lv, TypeExpr *t, Line ln);
    void EmitRenderFn(RenderFnReq r);
    Loc RenderedLoc(Node *a);
    Loc RenderToTemp(Node *a, Call *c);
    string FmtCall(Node *a, const string &dst);
    void EmitFormatInto(Loc lv, Node *a, Line ln, Call *c);
    vector<string> EmitStr(Call *c, vector<Node *> &an, Dst d0, Line ln);
    void EmitLeCheck(Line ln);
    void PayloadOf(Node *n, string &src, string &sz);
    void AppendBytes(const Loc &lv, const string &src, const string &n, Line ln);
    vector<string> EmitBytesOf(Call *c, vector<Node *> &an, Line ln);
    vector<string> EmitToBytes(vector<Node *> &an, Dst d0, Line ln);
    vector<string> EmitFromBytes(Call *c, vector<Node *> &an, Dst d0, Line ln);

    // The u8[>..] / T[>..] destination a builtin result is built at: the
    // caller's when it has one, else a fresh temporary named by `hdr`. A
    // value slot (a u8[] field or element) has no length lvalue, and takes
    // the count in a prefix reserved in front of the elements instead.
    struct RzDest {
        string stk, lenlv, hdr, pref, elems;
        IntStorage ls = IS_U32;
    };

    RzDest OpenRzDest(TypeExpr *t, Dst d0, Line ln, const char *what);
    void CloseRzDest(RzDest &rd, const string &count);
    string NewElemResult(const string &e, TypeExpr *elem, const Loc &lv, Line ln);
    vector<string> EmitPush(vector<Node *> &an, Line ln);
    string ElemValue(Node *n, TypeExpr *elem);
    void StoreElemAt(Node *n, TypeExpr *elem, const string &e, const string &ev, Line ln);
    bool LiteralBytes(Node *n, TypeExpr *t, vector<uint8_t> &out);
    bool UniformFillByte(Node *n, TypeExpr *t, int &byte);
    void EmitAppend(vector<Node *> &an, Line ln);
    vector<string> EmitAlloc(Call *c, vector<Node *> &an, Line ln);
    vector<string> EmitSlicePool(Call *c, vector<Node *> &an, Line ln);
    string SpanArgs(const Loc &lv);
    string PlaceRun(const Loc &lv, const string &n);
    string SliceLen(Node *n, TypeExpr *elem, Line ln);
    void EmitSliceExtend(const Loc &lv, const string &end, int64_t esz);
    void EmitDefaultElems(const ArrView &v, const string &first, const string &count, Node *init);

    // thread_spawn(worker, args...): pack the flat arguments contiguously on
    // a scratch stack, hand them to the runtime, unpack in a per-worker thunk.
    unordered_map<FnSpec *, string> thunks;

    vector<string> EmitThreadSpawn(Call *c, vector<Node *> &an);
    string EnsureThreadThunk(FnSpec *sp);
    void EmitThreadThunk(FnSpec *sp, int64_t stacks);
    // The image of a resizable value at a scratch stack's top: [int64 count]
    // [fixed fields][tail elements] (queue elements and copied globals).
    void EmitRzImage(Loc src, TypeExpr *t, const string &stk, Line ln);

    // ------------------------------------------------------------------
    // Function bodies.

    void DetectNrvo(FnSpec *sp);
    // What a specialization's C declaration says besides its signature.
    static const char *FnAttrs(FnSpec *sp) {
        return sp->outofline ? "GS_NOINLINE " : sp->cinline ? "GS_INLINE " : "";
    }
    const VarDef *NamedResult(Block *fnbody, SFunction *target, size_t nrets, size_t resultidx);
    const VarDef *OpenIbNrvo(InlineBlock *ib, const Dst &d);
    void PlanTopClasses(FnSpec *sp);
    bool RefTopsOk(FnSpec *sp, bool farreturn);
    void ResetFnState();
    string EnsureEr(FnSpec *sp);
    void EmitSpec(FnSpec *sp, bool er = false);
    // The instruction-set levels above the baseline a simd function has a
    // version for; runtime.h names them (GS_SIMD_TARGET1, ...).
    static constexpr int SIMD_LEVELS = 2;
    void EmitSimdVersions(FnSpec *sp, const string &name, const string &params,
                          const string &fnbody);

    // ------------------------------------------------------------------
    // Globals (§11.1): C globals plus dedicated data stacks for nonfixed
    // ones; initializers run in declaration order before main.

    // Globals whose declaration carries a C initializer, so gs_init_globals
    // has nothing left to do for them (§11.1), with the initializer, which
    // a later global's initializer naming one is spelled out from.
    map<const VarDef *, Node *> gstatic;

    // Spelling out more elements than this would trade startup work for source
    // size; such a value keeps its runtime initialization.
    static constexpr int64_t MAXSTATICELEMS = 256;

    bool StaticInitX(Node *n, TypeExpr *t, string &out);
    void EmitGlobalDecls();
    void EmitGlobalInit();
    string GlobalLenLv(VarDef *d);
    void InitGlobalStack(VarDef *d);
    void EmitProgramInit();
    void EmitExports();
    string MainCall();
    void EmitMain();

    // ------------------------------------------------------------------
    // Driver.

    // The program's C, in two parts: between them the driver splices the
    // runtime's extern support (runtime_ext.h), which is written against
    // the types in the first.
    string head;     // Types and data.
    string result;   // Includes, prototypes and code.
    string ExportHeader();

    // Extern-support C and user headers are inputs to this emission, not
    // process state that the driver must install before constructing us.
    // A function the extern support declares gets no prototype here.
    CodeGen(Ast &_ast, string_view runtime_ext_text, const vector<string> &headers,
            bool _norfcheck = false, bool _library = false, int64_t _maxstacks = 0)
        : ast(_ast), library(_library), norfcheck(_norfcheck), maxstacks(_maxstacks) {
        for (auto t : ast.alltypes)
            if (t->kind == TY_REF && t->ref->pool) poolglobals.insert(t->ref->pool);
        ComputeRelRootMax();
        CollectSpecs();
        for (auto sp : livespecs)
            for (auto fv : sinfo[sp].freevars) capturedvars.insert(fv);
        // Zero means "no long-distance return in flight", which is also the
        // state every propagating function's ordinary exit leaves behind.
        if (!fromids.empty()) data += "static GS_TLS int32_t gs_rf;\n";
        EmitGlobalDecls();
        // Prototypes for every live specialization, then their bodies.
        for (auto sp : livespecs)
            Append(protos, "static ", FnAttrs(sp), SigRet(sp), " ", sinfo[sp].cname, "(",
                   SigParams(sp, false), ");\n");
        for (auto sp : livespecs) EmitSpec(sp);
        EmitGlobalInit();
        // Element-run twins requested by call sites, the globals'
        // initializers included (may request more).
        for (size_t i = 0; i < erqueue.size(); i++) EmitSpec(erqueue[i], true);
        // The render functions any of those asked for (may ask for more).
        for (size_t i = 0; i < renderqueue.size(); i++) EmitRenderFn(renderqueue[i]);
        EmitProgramInit();
        EmitExports();
        if (!library) EmitMain();
        if (usesthreads) predefs = "#define GS_NEED_THREADS 1\n";
        // The instance block: with workers each thread reaches its own
        // through gs_gl; without them there is only main's.
        Append(data, "typedef struct {\n", gblock.empty() ? "    uint8_t gs_none;\n" : gblock,
               "} gs_globals_t;\nstatic gs_globals_t gs_globals_main;\n",
               usesthreads ? "#define GS_GL ((gs_globals_t *)gs_gl)\n"
                           : "#define GS_GL (&gs_globals_main)\n");
        // Extern fns: the runtime's own C follows the types it is written
        // against, then user headers, then prototypes for whatever neither
        // declares.
        // A header can implement any declared extern, even one no call
        // reaches. Emit their types without making the functions live.
        for (auto sp : ast.fnspecs) {
            if (!sp->sf->isextern) continue;
            for (auto t : sp->argtypes) {
                CT(t);
                // CT only forward-declares a struct behind a pointer; an
                // adapter needs its fields too. Builders use gs_rref instead.
                if (t->kind == TY_REF && !IsResz(t->ref->sub)) CT(t->ref->sub);
            }
            for (auto t : sp->rets) CT(t);
        }
        string externs;
        if (!usedexterns.empty() || !runtime_ext_text.empty()) {
            EmitCoreTypes();
            CT(ast.SliceOf(ast.inttypes[IS_U8], Line {}));
        }
        for (auto sp : usedexterns) {
            if (sp->sf->dylib.empty() &&
                runtime_ext_text.find(cat(" ", sp->sf->cname, "(")) != string_view::npos)
                continue;
            externs += ExternProto(sp);
        }
        // The shared libraries the dynamic externs bind from and the
        // pointers each symbol fills, which gs_program_init hands to
        // gs_dl_bind (design/dynamic_externs.md §5). Only a used extern is
        // bound, so a declared library no call reaches is never opened.
        auto dllibs = DlLibs();
        if (!dllibs.empty()) {
            auto spelling = [&](const string &s) { return s.empty() ? string("0") : CStr(s); };
            externs += "static const gs_dllib gs_dllibs[] = {\n";
            for (auto &lib : dllibs)
                Append(externs, "    { ", CStr(lib.name), ", ", spelling(lib.onwindows), ", ",
                       spelling(lib.onmacos), ", ", spelling(lib.onlinux), " },\n");
            externs += "};\nstatic const gs_dlbind gs_dlbinds[] = {\n";
            size_t n = 0;
            for (auto sp : usedexterns) {
                if (sp->sf->dylib.empty()) continue;
                assert(++n <= dlbinds && "an extern bound after gs_program_init was emitted");
                auto d = DlSpelling(sp);
                auto lib = std::find_if(dllibs.begin(), dllibs.end(),
                                        [&](auto &l) { return SameDylib(l, d); }) - dllibs.begin();
                Append(externs, "    { ", lib, ", ", CStr(sp->sf->cname), ", (void **)&",
                       DlSlot(sp), " },\n");
            }
            externs += "};\n";
        }
        string includes;
        for (auto inc : headers) {
            // Forward slashes even for a Windows path: a backslash inside a
            // header name is undefined, and every C compiler on Windows takes
            // the slash form.
            for (auto &c : inc) if (c == '\\') c = '/';
            Append(includes, "#include \"", inc, "\"\n");
        }
        Append(head, "\n/* ---- types ---- */\n#pragma pack(push, 1)\n", tdecls, pdata,
               "#pragma pack(pop)\n\n/* ---- data ---- */\n", data);
        Append(result, "\n/* ---- includes ---- */\n", includes,
               "\n/* ---- extern prototypes ---- */\n", externs,
               "\n/* ---- prototypes ---- */\n", protos, "\n/* ---- code ---- */\n", code);
    }
};

}  // namespace goose
