from pathlib import Path
import subprocess,json,hashlib,time,sys
root=Path('/home/jacobt/src/goose-to-wasm');base=Path('/dev/shm/goose-selfhost-work/wasm-float-probes');candidate=Path(sys.argv[1]);assert candidate.is_file()
commands={'oracle':root/'build/next-runtime-hills/final/bin/goose','candidate':candidate};host=root/'build/bin/goose-wasmtime';rows=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for source in sorted(base.glob('*.goose')):
 for level in [0,2]:
  row={'case':source.name,'optimization':level,'source_sha256':sha(source),'compilation':{},'execution':{}};d=base/(source.stem+f'-O{level}');d.mkdir(exist_ok=True)
  for side,cc in commands.items():
   artifact=d/(side+'.wasm');cmd=[str(cc),str(source),'--target','wasm-direct',f'-O{level}','-o',str(artifact)];started=time.monotonic();r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30)
   (d/(side+'-compile.stdout')).write_bytes(r.stdout);(d/(side+'-compile.stderr')).write_bytes(r.stderr);row['compilation'][side]={'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-started,'stderr':r.stderr.decode()}
   if not r.returncode:
    cmd=[str(host),'--no-cache',str(artifact)];r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30);(d/(side+'-run.stdout')).write_bytes(r.stdout);(d/(side+'-run.stderr')).write_bytes(r.stderr);row['execution'][side]={'command':cmd,'exit_code':r.returncode,'stdout':r.stdout.decode(),'stderr':r.stderr.decode(),'artifact_sha256':sha(artifact)}
  o=row['execution'].get('oracle');c=row['execution'].get('candidate');row['runtime_equal']=bool(o and c and o['exit_code']==c['exit_code'] and o['stdout']==c['stdout'])
  rows.append(row);print(source.name,level,row['runtime_equal'],{side:x['exit_code'] for side,x in row['compilation'].items()})
report={'scope':'Focused f32/f64 Wasm runtime qualification against independent pinned C++ compilation. Covers arithmetic, IEEE division by zero/nonfinite values, signed zero and compound arithmetic. Does not establish full language or byte parity.','binary_sha256':{str(p):sha(p) for p in [*commands.values(),host]},'results':rows}
(base/'report.json').write_text(json.dumps(report,indent=2)+'\n');sys.exit(0 if all(x['runtime_equal'] for x in rows) else 1)
