from pathlib import Path
import subprocess,json,hashlib,random,time
root=Path('/home/jacobt/src/goose-to-wasm'); out=Path('/dev/shm/goose-selfhost-work/frontend-parse-tests'); oracle=root/'build/next-runtime-hills/final/bin/goose'; candidate=Path('/dev/shm/goose-selfhost-work/build-2/goose-selfhost')
valid={
'declarations':'''namespace Front;
struct Box<T: i64> { pad 4, const value: T = 1, let extra: const u8[:] = "ok", }
enum Result<T> { None, Some { value: T }, }
type Alias = const(Box<i64>)&?;
extern "libc.so.6" { fn system(command: const u8&) -> i32 = "system"; }
export "front_api" fn api(x: i64) -> i64 { x }
checkfree inline fn plus(x: i64 = 1) -> i64 { x + 1 }
simd fn lanes(x: i64) -> i64 { x }
thread_fn work(x: i64) -> i64 { x }
recursive fn Front::pair(a: i64, b: i64) -> i64, i64 { return a, b; }
''',
'controls':'''fn main() {
    reusable var pool: i64[>..] = [];
    reusable[] var pieces: u8[:][>..] = [];
    var a, b = 1, 2;
    a, b = pair(); a++; b <<= 1;
    guard a > 0 else { return 0; }
    for &v, i: i64 in pool { v += i; }
    for i: (u32 in pool) in 0..10 { if i == 3 { continue; } }
    let early = block { loop { break 3; } };
    let y = match a { -3..0 => 1, 1, 2 => 3, _ => { 4 } };
    call(a) { var x: i64, y => if x > y { return x from main; } else { y } };
    return a, b from pair;
}
''',
'construction':'''struct X<T> { value: T }
enum E<T> { None, Some { x: T } }
fn main() {
    let x = X<i64> { value: 1, .. };
    let e = E<i64>.Some { x: 4 };
    let a = [1; 20]; let b = [..100];
    let r: E<i64>..&<u32 in pool> = value;
    let s: u8[>..<] = [];
    let bounds: (u32 upto pool)[3] = [1, 2, 3];
    let signature: fn(i64, u8[:]) -> (i64, u8[:]) = f;
    let cut = a[^3..^1];
    const for <F, A> in fields<X<i64>> { print(F, A); }
    let c = X<i64> { const for <F, A> in fields<X<i64>> { A: 1, } };
    let d = match e { const for <N, V> in variants<E<i64>> { V v => 1, }, _ => 2 };
}
''',
'raw_string':'''fn main() {
 let a = """inline \\ raw""";
 let b = """
     first
       second

     last
     """;
 let c = '\\xFF'; let d = "\\n\\t\\r\\0\\\\\\\"\\'";
}
''',
}
invalid={
'comment':'fn main() { /* nope',
'string':'fn main() { let s = "nope; }',
'character':"fn main() { let c = 'ab'; }",
'escape':'fn main() { let s = "\\xg0"; }',
'missing_param':'fn main(x: i64 { print(x); }',
'unclosed_type':'struct X<T { x: i64 }',
'bad_expression':'fn main() { let x = 1 + ; }',
'missing_body':'fn main() { while true }',
'raw_margin':'fn main() { let s = """\n  bad\n    """; }',
'inline_multiline':'fn main() { let s = """text\ntext"""; }',
'illegal_utf8':'fn main() { 😀; }',
'partial_field':'struct A { x: }',
'bad_pattern':'fn main() { match x { _ , 1 => 3 } }',
'double_namespace':'namespace A; namespace B; fn main() {}',
'late_namespace':'fn main() {} namespace A;',
}
rows=[]
def check(name,text,expect):
    d=out/name;d.mkdir(exist_ok=True); src=d/'input.goose';src.write_text(text)
    row={'case':name,'expected':expect,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'compilers':{}}
    for label,binary in [('oracle',oracle),('candidate',candidate)]:
        command=[str(binary),str(src),'--parse'];began=time.monotonic()
        try:
            val=subprocess.run(command,capture_output=True,timeout=3,cwd=root)
            (d/(label+'.stdout')).write_bytes(val.stdout);(d/(label+'.stderr')).write_bytes(val.stderr)
            result={'command':command,'exit_code':val.returncode,'elapsed_s':time.monotonic()-began,'stderr_bytes':len(val.stderr)}
        except subprocess.TimeoutExpired:
            result={'command':command,'exit_code':None,'error':'timeout','elapsed_s':time.monotonic()-began}
        row['compilers'][label]=result
    row['acceptance_equal']=(row['compilers']['oracle']['exit_code']==0)==(row['compilers']['candidate']['exit_code']==0)
    row['terminated']=all(x['exit_code'] is not None for x in row['compilers'].values());rows.append(row)
for name,source in valid.items():check('valid-'+name,source,'accept')
for name,source in invalid.items():check('invalid-'+name,source,'reject')
rng=random.Random(29171);tokens=['if','while','fn','let','const','for','<','>',':','(',')','{','}','[',']',',',';','=>','=','1','x','"hi"','..','return','&']
for i in range(100):
    source='fn main() { '+' '.join(rng.choice(tokens) for _ in range(rng.randrange(1,45)))+' }'
    check('fuzz-'+str(i),source,'termination')
report={'oracle_sha256':hashlib.sha256(oracle.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(candidate.read_bytes()).hexdigest(),'source_pin':json.loads((candidate.parent/'report.json').read_text())['input_sha256'],'rows':rows}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'valid':[(x['case'], {k:v['exit_code'] for k,v in x['compilers'].items()}) for x in rows if x['expected']=='accept'],'invalid_refused':sum(x['compilers']['candidate']['exit_code'] not in (0,None) for x in rows if x['expected']=='reject'),'invalid_total':len(invalid),'timeouts':sum(not x['terminated'] for x in rows),'acceptance_disagreements':[x['case'] for x in rows if not x['acceptance_equal']]}))
