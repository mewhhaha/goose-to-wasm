from pathlib import Path
import subprocess,json,hashlib,time,random
root=Path('/home/jacobt/src/goose-to-wasm'); out=Path('/dev/shm/goose-selfhost-work/frontend-native-tests-4')
oracle=root/'build/next-runtime-hills/final/bin/goose'; candidate=Path('/dev/shm/goose-selfhost-work/build-4/goose-selfhost'); clang=Path('/usr/bin/clang')
fixtures={
'scalar':'fn main() { print(42, " ", 1.25); }\n',
'fixed':'fn main() { let xs: i64[4] = [2, 3, 5, 7]; var n: i64 = 0; for x in xs { n += x; } print(n); }\n',
'grow':'fn main() { var xs: i64[>..] = []; xs.push(4); xs.push(9); xs.append([16, 25]); print(xs, " ", xs.len); }\n',
'record':'struct Point { x: i64, y: i64 }\nfn main() { var p = Point { x: 4, y: 7 }; p.x += 3; print(p.x, " ", p.y); }\n',
'record_ref':'struct Point { x: i64, y: i64 }\nfn main() { var p = Point { x: 4, y: 7 }; let r = &p.x; p.x = 19; print(r); }\n',
'grow_ref':'fn main() { var xs: i64[>..] = [4]; let r = &xs[0]; for i in 0..100 { xs.push(i); } print(r, " ", xs.len); }\n',
'multi':'fn pair() -> i64, i64 { return 4, 9; }\nfn main() { let a, b = pair(); print(a, " ", b); }\n',
'match':'fn main() { let x = 7; let y = match x { 0..3 => 10, 4, 7 => 20, _ => 30 }; print(y); }\n',
'equality':'struct Pair { a: i64, b: i64 }\nfn main() { var x: i64[>..] = [1,2,3]; var y: i64[>..] = [1,2,3]; print(x == y, " ", Pair { a:1,b:2 } == Pair { a:1,b:2 }); }\n',
}
rng=random.Random(42017)
literals=['0.0','0.1','1.00000000000000011102230246251565404236316680908203125','1.0000000000000001110223024625156540423631668090820312500000000001','9007199254740993.0','2.2250738585072014e-308','4.9406564584124654e-324','2.4703282292062327e-324','1.7976931348623157e308','1.7976931348623159e308','0x0.0000000000001p-1022','0x1.fffffffffffffp1023','0x1.fffffffffffff8p1023']
for i in range(160):
    digits=''.join(str(rng.randrange(10)) for _ in range(rng.randrange(1,75)))
    point=rng.randrange(len(digits)+1)
    if point==0: text='0.'+digits
    elif point==len(digits): text=digits+'.0'
    else: text=digits[:point]+'.'+digits[point:]
    literals.append(text+'e'+str(rng.randrange(-350,351)))
for i in range(80):
    whole=''.join(rng.choice('0123456789abcdef') for _ in range(rng.randrange(1,20)))
    frac=''.join(rng.choice('0123456789abcdef') for _ in range(rng.randrange(1,30)))
    literals.append('0x'+whole+'.'+frac+'p'+str(rng.randrange(-1150,1100)))
fixtures.update({
'grow_ref_mutate': 'fn main() { var xs: i64[>..] = [4]; let r = &xs[0]; for i in 0..100 { xs.push(i); } xs[0] = 31; print(r, " ", xs.len); }\n',
'string_owner': 'fn main() { var s: u8[>..] = "hello"; s.push(33); print(s); }\n',
'slice_mutate': 'fn main() { var xs: i64[>..] = [1,2,3]; let s = xs[1..]; for i in 0..100 { xs.push(i); } xs[1]=19; print(s); }\n',
'deep_copy': 'fn main() { var a: i64[>..] = [1,2]; var b=a; b[0]=9; print(a, " ", b); }\n',
'limited': 'fn main() { var xs: i64[..4] = [1,2]; xs.push(3); let last=xs.pop(); print(xs, " ", last, " ", xs.cap); }\n',
'enum': 'enum E { A, B { x:i64 } }\nfn main() { let v:E=E.B { x:7 }; let y=match v { A=>0, B b=>b.x }; print(y); }\n',
'record_print': 'struct Pair { a:i64,b:i64 }\nfn main() { print(Pair { a:4,b:7 }); }\n',
})
fixtures.update({
'enum_print': 'enum E { A, B { x:i64 } }\nfn main() { let a:E=E.A; let b:E=E.B { x:7 }; print(a," ",b); }\n',
'nested_string': 'struct Text { a:u8[:],b:u8[:] }\nfn main() { print(Text { a:"hello",b:"a\\n\\\\b" }); let words:u8[:][2]=["one","two"]; print(words); }\n',
})
fixtures['float_bits']='fn main() { let xs: f64['+str(len(literals))+'] = ['+',\n'.join(literals)+']; print(bytes_of(xs)); }\n'

def run(cmd,prefix,timeout=30):
    began=time.monotonic(); item={'command':[str(x) for x in cmd]}
    try:
        v=subprocess.run(cmd,capture_output=True,timeout=timeout,cwd=root)
        item.update(exit_code=v.returncode,elapsed_s=time.monotonic()-began)
        prefix.with_suffix('.stdout').write_bytes(v.stdout);prefix.with_suffix('.stderr').write_bytes(v.stderr)
        item.update(stdout_sha256=hashlib.sha256(v.stdout).hexdigest(),stdout_bytes=len(v.stdout),stderr_bytes=len(v.stderr))
    except subprocess.TimeoutExpired as ex:
        item.update(exit_code=None,error='timeout',elapsed_s=time.monotonic()-began)
        prefix.with_suffix('.stdout').write_bytes(ex.stdout or b'');prefix.with_suffix('.stderr').write_bytes(ex.stderr or b'')
    return item
rows=[]
for name,source in fixtures.items():
    d=out/name;d.mkdir(exist_ok=True);path=d/'input.goose';path.write_text(source)
    row={'case':name,'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'implementations':{}}
    for label,compiler in [('oracle',oracle),('candidate',candidate)]:
        cfile=d/(label+'.c'); binary=d/(label+'.bin')
        compiled=run([compiler,path,'--target','native','--standalone','-O0','-o',cfile],d/(label+'-goose'))
        val={'compile':compiled}
        if compiled.get('exit_code')==0:
            val['c_sha256']=hashlib.sha256(cfile.read_bytes()).hexdigest()
            built=run([clang,'-std=gnu11','-O0',cfile,'-lm','-ldl','-pthread','-o',binary],d/(label+'-clang'))
            val['c_compile']=built
            if built.get('exit_code')==0:val['runtime']=run([binary],d/(label+'-runtime'))
        row['implementations'][label]=val
    a=row['implementations']['oracle'].get('runtime'); b=row['implementations']['candidate'].get('runtime')
    row['runtime_equal']=bool(a and b and (a['exit_code'],a['stdout_sha256'])==(b['exit_code'],b['stdout_sha256']))
    rows.append(row)
    print(name,row['runtime_equal'],{key:{phase:item.get('exit_code') for phase,item in value.items() if isinstance(item,dict)} for key,value in row['implementations'].items()},flush=True)
report={'oracle_sha256':hashlib.sha256(oracle.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(candidate.read_bytes()).hexdigest(),'candidate_build_report':str(candidate.parent/'report.json'),'clang_sha256':hashlib.sha256(clang.read_bytes()).hexdigest(),'source_pin':json.loads((candidate.parent/'report.json').read_text())['input_sha256'],'float_literals':len(literals),'rows':rows}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
