from pathlib import Path
import hashlib,json,subprocess,time,shutil,sys
root=Path('/home/jacobt/src/goose-to-wasm')
private=Path('/dev/shm/goose-selfhost-work/wasm-probe')
ordinal=int(sys.argv[1]); dest=private/f'attempt-{ordinal}';dest.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
inputs={}
for name in ('model.goose','codegen.goose','wasm.goose'):
    src=root/'selfhost'/name;target=private/name;shutil.copyfile(src,target);inputs[str(src)]=sha(target)
inputs[str(private/'probe.goose')]=sha(private/'probe.goose')
oracle=root/'build/next-runtime-hills/final/bin/goose';pin=json.loads((root/'selfhost/oracle.json').read_text())
assert sha(oracle)==pin['binary_sha256']
command=[str(oracle),str(private/'probe.goose'),'--check','--target','native','-O0']
started=time.monotonic();r=subprocess.run(command,cwd=root,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(dest/'oracle.stdout').write_bytes(r.stdout);(dest/'oracle.stderr').write_bytes(r.stderr)
report={'scope':'Isolated pinned-oracle typecheck of Wasm emitter with private source snapshots. No Goose compiler execution or full bootstrap qualification.','command':command,'exit_code':r.returncode,'seconds':time.monotonic()-started,'oracle_sha256':sha(oracle),'input_sha256':inputs,'stdout_sha256':sha(dest/'oracle.stdout'),'stderr_sha256':sha(dest/'oracle.stderr')}
(dest/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2));print(r.stderr.decode())
sys.exit(r.returncode)
