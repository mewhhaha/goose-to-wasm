from pathlib import Path
from fractions import Fraction
from decimal import Decimal,localcontext
import struct,math,random,subprocess,json,hashlib,time
root=Path('/home/jacobt/src/goose-to-wasm');out=Path('/dev/shm/goose-selfhost-work/frontend-float-fuzz');oracle=root/'build/next-runtime-hills/final/bin/goose';candidate=Path('/dev/shm/goose-selfhost-work/build-2/goose-selfhost')
rng=random.Random(781923)
literals=['-0.0','-0x0.0p0']
for i in range(500):
    count=rng.randrange(1,401);digits=str(rng.randrange(1,10))+''.join(str(rng.randrange(10)) for _ in range(count-1)); point=rng.randrange(count+1)
    if point==0:s='0.'+digits
    elif point==count:s=digits+'.0'
    else:s=digits[:point]+'.'+digits[point:]
    literals.append(s+'e'+str(rng.randrange(-350,351)-point))
for i in range(100):
    bits=rng.randrange(1,0x7fefffffffffffff);a=struct.unpack('<d',bits.to_bytes(8,'little'))[0];b=math.nextafter(a,math.inf)
    mid=(Fraction.from_float(a)+Fraction.from_float(b))/2
    with localcontext() as ctx:
        ctx.prec=1300
        exact=Decimal(mid.numerator)/Decimal(mid.denominator)
        exact_text=format(exact,'f');fractional=len(exact_text.split('.')[1]) if '.' in exact_text else 0
        epsilon=Decimal(1).scaleb(-fractional-30)
        for v in [exact-epsilon,exact,exact+epsilon]:
            text=format(v,'f')
            if '.' not in text:text+='.0'
            literals.append(text)
source='fn main() { let xs: f64['+str(len(literals))+'] = ['+',\n'.join(literals)+']; print(bytes_of(xs)); }\n';src=out/'input.goose';src.write_text(source)
expected=b''.join(struct.pack('<d',float.fromhex(s) if 'x' in s else float(s)) for s in literals)+b'\n';(out/'python-reference.bin').write_bytes(expected)
rows={}
for label,compiler in [('oracle',oracle),('candidate',candidate)]:
    stages=[]
    for phase,cmd in [('compile',[compiler,src,'--target','native','--standalone','-O0','-o',out/(label+'.c')]),('c_compile',['/usr/bin/clang','-std=gnu11','-O0',out/(label+'.c'),'-lm','-ldl','-pthread','-o',out/(label+'.bin')]),('runtime',[out/(label+'.bin')])]:
        began=time.monotonic();p=subprocess.run(cmd,capture_output=True,cwd=root,timeout=60)
        (out/(label+'-'+phase+'.stdout')).write_bytes(p.stdout);(out/(label+'-'+phase+'.stderr')).write_bytes(p.stderr)
        stages.append({'phase':phase,'command':[str(x) for x in cmd],'exit_code':p.returncode,'elapsed_s':time.monotonic()-began,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stdout_bytes':len(p.stdout)})
        if p.returncode:break
    actual=(out/(label+'-runtime.stdout')).read_bytes() if (out/(label+'-runtime.stdout')).exists() else b''
    mismatches=[]
    for i in range(len(literals)):
        if actual[i*8:(i+1)*8]!=expected[i*8:(i+1)*8]:mismatches.append({'index':i,'literal':literals[i],'expected_hex':expected[i*8:(i+1)*8].hex(),'actual_hex':actual[i*8:(i+1)*8].hex()})
    rows[label]={'stages':stages,'reference_equal':actual==expected,'mismatch_count':len(mismatches),'first_mismatches':mismatches[:4]}
report={'seed':781923,'literals':len(literals),'exact_midpoint_triplets':100,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'python_reference_sha256':hashlib.sha256(expected).hexdigest(),'oracle_sha256':hashlib.sha256(oracle.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(candidate.read_bytes()).hexdigest(),'candidate_source_pins':json.loads((candidate.parent/'report.json').read_text())['input_sha256'],'rows':rows}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({key:{'reference_equal':val['reference_equal'],'mismatch_count':val['mismatch_count'],'first_mismatches':val['first_mismatches']} for key,val in rows.items()}))
