from pathlib import Path
import subprocess,json,hashlib,time
root=Path('/home/jacobt/src/goose-to-wasm');base=Path('/dev/shm/goose-selfhost-work/wasm-runtime-probes')
commands={'oracle':root/'build/next-runtime-hills/final/bin/goose','candidate':Path('/dev/shm/goose-selfhost-work/build-3/goose-selfhost')};host=root/'build/bin/goose-wasmtime';rows=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for source in sorted(base.glob('*.goose')):
 for level in [0,2]:
  row={'case':source.name,'optimization':level,'source_sha256':sha(source),'compilation':{},'execution':{}}
  d=base/(source.stem+f'-O{level}');d.mkdir(exist_ok=True)
  for side,cc in commands.items():
   artifact=d/(side+'.wasm');cmd=[str(cc),str(source),'--target','wasm-direct',f'-O{level}','-o',str(artifact)];started=time.monotonic();cmd += ['--stdlib',str(root/'build/bin/stdlib')] if side=='candidate' else [];r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=20)
   (d/(side+'-compile.stdout')).write_bytes(r.stdout);(d/(side+'-compile.stderr')).write_bytes(r.stderr);row['compilation'][side]={'exit_code':r.returncode,'seconds':time.monotonic()-started,'binary_sha256':sha(cc),'stderr':r.stderr.decode()}
   if not r.returncode:
    r=subprocess.run([str(host),'--no-cache',str(artifact)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=20);(d/(side+'-run.stdout')).write_bytes(r.stdout);(d/(side+'-run.stderr')).write_bytes(r.stderr);row['execution'][side]={'exit_code':r.returncode,'stdout':r.stdout.decode(),'stderr':r.stderr.decode(),'artifact_sha256':sha(artifact)}
  o=row['execution'].get('oracle');c=row['execution'].get('candidate');row['runtime_equal']=bool(o and c and o['exit_code']==c['exit_code'] and o['stdout']==c['stdout'])
  if o and c and o['stdout']!=c['stdout']:
   for i,(a,b) in enumerate(zip(o['stdout'].splitlines(),c['stdout'].splitlines())):
    if a!=b:row['first_diff']={'line':i+1,'oracle':a,'candidate':b};break
  rows.append(row);print(source.name,level,row['runtime_equal'],row.get('first_diff'),{s:x['exit_code'] for s,x in row['compilation'].items()})
(base/'report.json').write_text(json.dumps({'stage0_scope':'build-3 unchanged binary, diagnostic fixtures only','results':rows},indent=2)+'\n')
