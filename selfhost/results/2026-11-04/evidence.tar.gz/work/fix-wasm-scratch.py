import re
p='selfhost/codegen.goose'
s=open(p).read()
s=s.replace('fn cg_pack_view(', 'recursive fn cg_pack_view(')
s=s.replace('CgImport { host: host, signature: cg_host_signature(m, host) }','CgImport { signature: cg_host_signature(m, host), host: host }')
s=s.replace('results: i64[>..]&, destinations: i64[>..]&,','results: i64[>..]&, destinations: i64[>..]&, work: i64[>..]&,')
s=s.replace('var results: i64[>..] = []; var destinations: i64[>..] = [];','var results: i64[>..] = []; var destinations: i64[>..] = []; var work: i64[>..] = [];')
s=s.replace('results: results, destinations: destinations, function: function','results: results, destinations: destinations, work: work, function: function')
s=s.replace('n.integer as f64', 'n.integer')
def replace_fn(name, new):
    global s
    start=re.search(r'(?m)^(?:recursive )?fn '+name+r'\(',s).start()
    nxt=re.search(r'(?m)^(?:recursive )?fn |^struct ',s[start+1:])
    end=start+1+nxt.start()
    s=s[:start]+new.rstrip()+'\n'+s[end:]
replace_fn('cg_set_values','''recursive fn cg_set_values(p: Program&, m: CgModule&, f: CgBody&, first: i64, type_id: i64, first_slot: i64, node: i64) {
    let count = cg_result_count(p, type_id);
    if count == 0 { if first >= 0 { cg_discard(p, m, f, first); } return; }
    if first < 0 { cg_fail(p, node, "wasm: missing control result"); return; }
    if p.nodes[first].next < 0 && cg_type_kind(p, p.nodes[first].type_id) == TY_TUPLE {
        cg_expr(p, m, f, first); var at = count;
        while at > 0 { at--; cg_set(f, first_slot + at); } return;
    }
    var item = first; var ordinal = 0;
    while item >= 0 && ordinal < count {
        cg_to(p, m, f, item, cg_result_at(p, type_id, ordinal)); cg_set(f, first_slot + ordinal);
        item = p.nodes[item].next; ordinal++;
    }
    if item >= 0 || ordinal != count { cg_fail(p, node, "wasm: control result arity mismatch"); }
}''')
old='''    let target_type = cg_result_type(p, target); var types: i64[>..] = []; cg_result_types(p, target_type, types);
    var values: i64[>..] = [];
    for id in types { values.push(cg_local(f, cg_wasm_type(p, id))); }
    var first_slot = -1; if values.len > 0 { first_slot = values[0]; }'''
s=s.replace(old,'''    let target_type = cg_result_type(p, target); let count = cg_result_count(p, target_type);
    let first_slot = cg_control_slots(p, f, target_type);''')
s=s.replace('''    for id, i in types {
        offset = cg_align(offset, 8); cg_get(f, frame);''','''    for i in 0..count {
        let id = cg_result_at(p, target_type, i);
        offset = cg_align(offset, 8); cg_get(f, frame);''',1)
s=s.replace('''        cg_get(f, values[i]); cg_write_value(p, m, f, id, destination, node);''','''        cg_get(f, first_slot + i); cg_write_value(p, m, f, id, destination, node);''',1)
start=s.index('    if n.first >= 0 {', s.index('recursive fn cg_declaration'))
end=s.index('    let symbol = n.symbol;',start)
s=s[:start]+'''    if n.first >= 0 {
        var binding = n.first; var first_slot = -1; var count = 0;
        while binding >= 0 {
            let slot = cg_local(f, cg_wasm_type(p, p.nodes[binding].type_id));
            if first_slot < 0 { first_slot = slot; } count++; binding = p.nodes[binding].next;
        }
        if n.right >= 0 && cg_type_kind(p, p.nodes[n.right].type_id) == TY_TUPLE {
            cg_expr(p, m, f, n.right); var at = count; while at > 0 { at--; cg_set(f, first_slot + at); }
        } else {
            var initializer = n.right; binding = n.first; var ordinal = 0;
            while binding >= 0 {
                if initializer >= 0 { cg_to(p, m, f, initializer, p.nodes[binding].type_id); initializer = p.nodes[initializer].next; }
                else { cg_zero(f.code, cg_wasm_type(p, p.nodes[binding].type_id)); }
                cg_set(f, first_slot + ordinal); ordinal++; binding = p.nodes[binding].next;
            }
        }
        binding = n.first; var ordinal = 0;
        while binding >= 0 {
            cg_symbol_address(p, m, f, p.nodes[binding].symbol, binding); let address = cg_save(f, 0x7f);
            if n.right < 0 { cg_get(f, address); wb_i32(f.code, 0); wb_i32(f.code, cg_size(p, p.nodes[binding].type_id)); wb_fill(f.code); }
            else { cg_get(f, first_slot + ordinal); cg_write_value(p, m, f, p.nodes[binding].type_id, address, binding); }
            binding = p.nodes[binding].next; ordinal++;
        }
        return;
    }
'''+s[end:]
s=s.replace('''        var values: i64[>..] = []; var types: i64[>..] = []; var child = arg;''','''        let mark = f.work.len; var child = arg;''')
s=s.replace('''            values.push(value); types.push(id); child = p.nodes[child].next;''','''            f.work.push(id); f.work.push(value); child = p.nodes[child].next;''')
s=s.replace('''        for id, i in types { cg_print(p, m, f, id, values[i], node, false); }
        wb_op(f.code, 0x10, CG_NEWLINE); return;''','''        let end = f.work.len; var at = mark;
        while at < end { let id = f.work[at]; let value = f.work[at + 1]; cg_print(p, m, f, id, value, node, false); at += 2; }
        f.work.resize(mark); wb_op(f.code, 0x10, CG_NEWLINE); return;''')
replace_fn('cg_multi_assignment','''recursive fn cg_multi_assignment(p: Program&, m: CgModule&, f: CgBody&, node: i64) {
    let n = p.nodes[node]; let mark = f.work.len; var target = n.first;
    while target >= 0 {
        cg_address(p, m, f, target); let address = cg_save(f, 0x7f); let id = p.nodes[target].type_id; let value = cg_local(f, cg_wasm_type(p, id));
        f.work.push(address); f.work.push(id); f.work.push(value); target = p.nodes[target].next;
    }
    let end = f.work.len; cg_expr(p, m, f, n.right); var at = end;
    while at > mark { at -= 3; cg_set(f, f.work[at + 2]); }
    at = mark;
    while at < end { let id = f.work[at + 1]; let address = f.work[at]; let value = f.work[at + 2]; cg_get(f, value); cg_write_value(p, m, f, id, address, node); at += 3; }
    f.work.resize(mark);
}''')
s+='''
fn cg_result_count(p: Program&, id: i64) -> i64 {
    if cg_type_kind(p, id) == TY_VOID { return 0; }
    if cg_type_kind(p, id) != TY_TUPLE { return 1; }
    var count = 0; var part = p.types[id].first;
    while part >= 0 { count++; part = p.nodes[part].next; } return count;
}
fn cg_result_at(p: Program&, id: i64, index: i64) -> i64 {
    if cg_type_kind(p, id) != TY_TUPLE { return id; }
    var part = p.types[id].first; var ordinal = 0;
    while part >= 0 { if ordinal == index { return p.nodes[part].type_id; } part = p.nodes[part].next; ordinal++; }
    return TYPE_UNKNOWN;
}
'''
open(p,'w').write(s)
