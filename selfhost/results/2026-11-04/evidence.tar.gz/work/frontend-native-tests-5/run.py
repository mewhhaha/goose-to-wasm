from pathlib import Path
import subprocess,json,hashlib,time
root=Path('/home/jacobt/src/goose-to-wasm');out=Path('/dev/shm/goose-selfhost-work/frontend-native-tests-5');oracle=root/'build/next-runtime-hills/final/bin/goose';candidate=Path('/dev/shm/goose-selfhost-work/build-5/goose-selfhost');clang=Path('/usr/bin/clang')
old=(Path('/dev/shm/goose-selfhost-work/frontend-native-tests-4/run.py')).read_text().split('\ndef run(')[0]
ns={};exec(old,ns);fixtures=ns['fixtures'];fixtures.pop('nested_string');fixtures['nested_string_const']=Path('/dev/shm/goose-selfhost-work/frontend-native-tests-4/nested_string_const/input.goose').read_text()
root=Path('/home/jacobt/src/goose-to-wasm');out=Path('/dev/shm/goose-selfhost-work/frontend-native-tests-5');oracle=root/'build/next-runtime-hills/final/bin/goose';candidate=Path('/dev/shm/goose-selfhost-work/build-5/goose-selfhost');clang=Path('/usr/bin/clang')
cases=[(name,text,'baseline',[]) for name,text in fixtures.items()]
for variant,body in [('expression','a%b'),('return','return a%b;')]:
    text='recursive fn remainder(a:i64,b:i64)->i64 { '+body+' }\nfn main(){'
    for a,b in [(-8,3),(8,3),(-8,-3),(8,-3),(-9223372036854775808,-9223372036854775808),(-1,-9223372036854775808),(1,-9223372036854775808),(-9223372036854775808,-3),(-9223372036854775808,-1)]:text+=f'print(remainder({a},{b}));'
    text+='}\n';cases.append(('mod-'+variant,text,'regression',[]))
for bits in [8,16,32,64]:
    for signed in [False,True]:
        typ=('i' if signed else 'u')+str(bits)
        for op,word in [('<<','left'),('>>','right')]:
            # Counts are function arguments, so negative/oversize values reach runtime masking.
            value='1' if op=='<<' or not signed else '-2'
            text=f'recursive fn shift(a:{typ},b:{typ})->{typ} {{ return a{op}b; }}\nfn count(n:i64)->{typ} {{ n as! {typ} }}\nfn main(){{'
            for count in [0,bits-1,bits,bits+1,-1,-bits-1]:text+=f'print(shift({value},count({count})));'
            text+='}\n';cases.append((f'shift-{typ}-{word}',text,'regression',[]))
cases.append(('division-overflow','recursive fn divide(a:i64,b:i64)->i64 { return a/b; }\nfn main(){print(divide(-9223372036854775808,-1));}\n','runtime-error',[]))
for name in ['debug_overflow','debug_overflow_explicit']:
    cases.append((name,Path('/dev/shm/goose-selfhost-work/review-probes/'+name+'.goose').read_text(),'unsupported',['--debug']))
# Keep captured review cases, not just regenerated equivalents.
for name in ['intmod','intmod_explicit','shift_u8','shift_u8_explicit']:
    cases.append(('captured-'+name,Path('/dev/shm/goose-selfhost-work/review-probes/'+name+'.goose').read_text(),'regression',[]))

def execute(cmd,prefix,timeout=30):
    began=time.monotonic()
    try:
        p=subprocess.run(cmd,capture_output=True,cwd=root,timeout=timeout)
        prefix.with_suffix('.stdout').write_bytes(p.stdout);prefix.with_suffix('.stderr').write_bytes(p.stderr)
        return {'command':[str(x) for x in cmd],'exit_code':p.returncode,'elapsed_s':time.monotonic()-began,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest(),'stdout_bytes':len(p.stdout)}
    except subprocess.TimeoutExpired as p:
        prefix.with_suffix('.stdout').write_bytes(p.stdout or b'');prefix.with_suffix('.stderr').write_bytes(p.stderr or b'')
        return {'command':[str(x) for x in cmd],'exit_code':None,'error':'timeout','elapsed_s':time.monotonic()-began}
rows=[]
for name,text,kind,extra in cases:
  for level in [0,2]:
    d=out/(name+'-O'+str(level));d.mkdir(exist_ok=True);src=d/'input.goose';src.write_text(text)
    row={'case':name,'kind':kind,'optimization':level,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'implementations':{}}
    for label,compiler in [('oracle',oracle),('candidate',candidate)]:
      cfile=d/(label+'.c');binary=d/(label+'.bin');steps={}
      steps['compile']=execute([compiler,src,'--target','native','--standalone',f'-O{level}',*extra,'-o',cfile],d/(label+'-goose'))
      if steps['compile']['exit_code']==0:
        steps['c_sha256']=hashlib.sha256(cfile.read_bytes()).hexdigest()
        steps['c_compile']=execute([clang,'-std=gnu11',f'-O{level}',cfile,'-lm','-ldl','-pthread','-o',binary],d/(label+'-clang'))
        if steps['c_compile']['exit_code']==0:steps['runtime']=execute([binary],d/(label+'-runtime'))
      row['implementations'][label]=steps
    a=row['implementations']['oracle'].get('runtime');b=row['implementations']['candidate'].get('runtime')
    row['runtime_equal']=bool(kind!='unsupported' and a and b and (a['exit_code'],a['stdout_sha256'])==(b['exit_code'],b['stdout_sha256']))
    row['explicit_unsupported_refusal']=bool(kind=='unsupported' and row['implementations']['candidate']['compile']['exit_code'] not in (0,None) and not (d/'candidate.c').exists())
    rows.append(row)
    print(name,level,'equal='+str(row['runtime_equal']),'unsupported='+str(row['explicit_unsupported_refusal']),{k:{p:v.get('exit_code') for p,v in s.items() if isinstance(v,dict)} for k,s in row['implementations'].items()},flush=True)
report={'schema':'native-targeted-regressions-v1','oracle_sha256':hashlib.sha256(oracle.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(candidate.read_bytes()).hexdigest(),'candidate_build_report':str(candidate.parent/'report.json'),'candidate_source_pins':json.loads((candidate.parent/'report.json').read_text())['input_sha256'],'clang_sha256':hashlib.sha256(clang.read_bytes()).hexdigest(),'rows':rows,'summary':{'cases':len(cases),'runs':len(rows),'runtime_equal':sum(r['runtime_equal'] for r in rows),'unsupported_refusal':sum(r['explicit_unsupported_refusal'] for r in rows),'failures':[r['case']+'-O'+str(r['optimization']) for r in rows if not r['runtime_equal'] and not r['explicit_unsupported_refusal']]}}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report['summary']))
