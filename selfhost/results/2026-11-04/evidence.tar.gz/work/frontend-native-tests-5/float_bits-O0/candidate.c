#define _GNU_SOURCE 1
#include <stdint.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <limits.h>
#include <setjmp.h>
#include <time.h>
#include <unistd.h>
#include <sys/stat.h>
#include <dirent.h>
#include <dlfcn.h>
#include <errno.h>
typedef struct GRefCell *GRef;
struct GRefCell { GRef parent; unsigned char *root; unsigned char *direct; int64_t offset; };
typedef struct { GRef base; int64_t len; } GSlice;
typedef struct { unsigned char *data; int64_t len, cap; } GArray;
typedef struct GClosure { void *function; int64_t count; GRef captures[]; } GClosure;
typedef struct GAllocation { struct GAllocation *next; void *data; } GAllocation;
static GAllocation *g_allocations;
static int g_argc; static char **g_argv;
static void g_panic(const char *s) { fprintf(stderr,"goose runtime error: %s\n",s); exit(1); }
static void *g_alloc(size_t n) {
    void *p=calloc(1,n+!n); if(!p) g_panic("out of memory");
    GAllocation *a=malloc(sizeof *a); if(!a) g_panic("out of memory");
    a->data=p; a->next=g_allocations; g_allocations=a; return p;
}
static void g_cleanup(void) { while(g_allocations) { GAllocation *a=g_allocations; g_allocations=a->next; free(a->data); free(a); } }
static GRef g_ref(void *p) { GRef r=g_alloc(sizeof *r); r->direct=p; return r; }
static unsigned char *g_address(GRef r) {
    if(!r) g_panic("null reference");
    unsigned char *base=r->direct;
    if(r->parent) base=g_address(r->parent);
    else if(r->root) memcpy(&base,r->root,sizeof base);
    if(!r->offset) return base;
    if(!base) g_panic("null reference");
    return base+r->offset;
}
static GRef g_offset(GRef p,int64_t n) { GRef r=g_alloc(sizeof *r); r->parent=p; r->offset=n; return r; }
static GRef g_moving(void *root,int64_t n) { GRef r=g_alloc(sizeof *r); r->root=root; r->offset=n; return r; }
static uint64_t g_read_length(const void *p,int n) { uint64_t v=0; memcpy(&v,p,n); return v; }
static void g_write_length(void *p,int n,uint64_t v) { memcpy(p,&v,n); }
static int64_t g_len(GRef r,int kind,int64_t fixed,int prefix) {
    if(kind==5) { GSlice s; memcpy(&s,g_address(r),sizeof s); return s.len; }
    if(kind==0) return fixed;
    if(kind==2 && fixed>=0) return (int64_t)g_read_length(g_address(r),prefix);
    GArray a; memcpy(&a,g_address(r),sizeof a); return a.len;
}
static int64_t g_cap(GRef r,int kind,int64_t fixed) {
    if(kind==2 && fixed>=0) return fixed;
    GArray a; memcpy(&a,g_address(r),sizeof a); return a.cap;
}
static GRef g_element(GRef r,int kind,int64_t fixed,int prefix,int64_t width,int64_t index,int allow_end) {
    int64_t len=g_len(r,kind,fixed,prefix);
    if(index<0 || index>len || (!allow_end && index==len)) g_panic("index out of bounds");
    if(width && index>INT64_MAX/width) g_panic("array offset overflow");
    if(kind==5) { GSlice s; memcpy(&s,g_address(r),sizeof s); return g_offset(s.base,index*width); }
    if(kind==0) return g_offset(r,index*width);
    if(kind==2 && fixed>=0) return g_offset(r,prefix+index*width);
    return g_moving(g_address(r),index*width);
}
static GSlice g_view(GRef r,int kind,int64_t fixed,int prefix,int64_t width) {
    GSlice s={g_element(r,kind,fixed,prefix,width,0,1),g_len(r,kind,fixed,prefix)}; return s;
}
static void g_reserve(GRef r,int kind,int64_t fixed,int prefix,int64_t width,int64_t count) {
    if(count<0 || (width && count>INT64_MAX/width)) g_panic("invalid capacity");
    if(kind==2 && fixed>=0) { if(count>fixed) g_panic("limited array capacity exceeded"); return; }
    if(kind!=3 && kind!=4 && kind!=2) g_panic("array cannot grow");
    GArray a; memcpy(&a,g_address(r),sizeof a);
    if(count>a.cap) {
        int64_t cap=a.cap*2+8; if(cap<count) cap=count;
        if(width && cap>INT64_MAX/width) g_panic("array capacity overflow");
        unsigned char *data=g_alloc((size_t)(cap*width));
        if(a.len) memcpy(data,a.data,(size_t)(a.len*width)); a.data=data; a.cap=cap;
        memcpy(g_address(r),&a,sizeof a);
    }
}
static void g_set_len(GRef r,int kind,int64_t fixed,int prefix,int64_t count) {
    if(kind==2 && fixed>=0) g_write_length(g_address(r),prefix,(uint64_t)count);
    else { GArray a; memcpy(&a,g_address(r),sizeof a); a.len=count; memcpy(g_address(r),&a,sizeof a); }
}
static GRef g_push(GRef r,int kind,int64_t fixed,int prefix,int64_t width,const void *v) {
    int64_t n=g_len(r,kind,fixed,prefix); g_reserve(r,kind,fixed,prefix,width,n+1);
    g_set_len(r,kind,fixed,prefix,n+1); GRef dst=g_element(r,kind,fixed,prefix,width,n,0);
    memcpy(g_address(dst),v,(size_t)width); return dst;
}
static void g_bytes(GArray *out,const void *p,int64_t n) {
    if(n<=0) return; GRef r=g_ref(out); g_reserve(r,3,-1,0,1,out->len+n);
    memmove(out->data+out->len,p,(size_t)n); out->len+=n;
}
static GClosure *g_closure(void *function,int64_t n) { GClosure *c=g_alloc(sizeof *c+(size_t)n*sizeof(GRef)); c->function=function; c->count=n; return c; }
typedef struct GReturnFrame { struct GReturnFrame *parent; int64_t function; jmp_buf jump; void *result; size_t size; } GReturnFrame;
static _Thread_local GReturnFrame *g_return_top;
static void g_throw(int64_t function,const void *value,size_t size) {
    GReturnFrame *f=g_return_top;
    while(f && f->function!=function) f=f->parent;
    if(!f || f->size!=size) g_panic("nonlocal return target is not active");
    if(size) memcpy(f->result,value,size); g_return_top=f; longjmp(f->jump,1);
}
static int64_t g_div(int64_t a,int64_t b) { if(!b) g_panic("division by zero"); if(a==INT64_MIN && b==-1) g_panic("signed integer overflow"); return a/b; }
static int64_t g_mod(int64_t a,int64_t b) { if(!b) g_panic("division by zero"); if(a==INT64_MIN && b==-1) return 0; int64_t r=a%b; if(r<0) { uint64_t magnitude=(uint64_t)b; if(b<0) magnitude=0-magnitude; return (int64_t)((uint64_t)r+magnitude); } return r; }
static uint64_t g_udiv(uint64_t a,uint64_t b) { if(!b) g_panic("division by zero"); return a/b; }
static uint64_t g_umod(uint64_t a,uint64_t b) { if(!b) g_panic("division by zero"); return a%b; }
static uint64_t g_float_wrap(double a) { if(!isfinite(a)) g_panic("float conversion is not finite"); a=fmod(trunc(a),18446744073709551616.0); if(a<0) a+=18446744073709551616.0; if(a>=9223372036854775808.0) return ((uint64_t)(a-9223372036854775808.0))+(UINT64_C(1)<<63); return (uint64_t)a; }
static void g_print_bytes(GArray *out,const void *p,int64_t n) { if(out) g_bytes(out,p,n); else if(n) fwrite(p,1,(size_t)n,stdout); }
static void g_print_text(GArray *out,const char *s) { g_print_bytes(out,s,(int64_t)strlen(s)); }
static char *g_path(GSlice p) { if(p.len<0 || p.len>=4096) return NULL; char *s=g_alloc((size_t)p.len+1); if(p.len) memcpy(s,g_address(p.base),(size_t)p.len); if(memchr(s,0,(size_t)p.len)) return NULL; return s; }
static int g_os_read_file(GSlice path,GRef out) { char *s=g_path(path); if(!s) return 0; FILE *f=fopen(s,"rb"); if(!f) return 0; GArray a; memcpy(&a,g_address(out),sizeof a); unsigned char b[16384]; size_t n; while((n=fread(b,1,sizeof b,f))) g_bytes(&a,b,(int64_t)n); int ok=!ferror(f); fclose(f); memcpy(g_address(out),&a,sizeof a); return ok; }
static int g_os_write_file(GSlice path,GSlice data,const char *mode) { char *s=g_path(path); if(!s) return 0; FILE *f=fopen(s,mode); if(!f) return 0; int ok=fwrite(g_address(data.base),1,(size_t)data.len,f)==(size_t)data.len; return fclose(f)==0 && ok; }
static int g_os_write_atomic(GSlice path,GSlice data) { char *s=g_path(path); if(!s) return 0; size_t n=strlen(s); char *tmp=g_alloc(n+16); memcpy(tmp,s,n); memcpy(tmp+n,".tmp-XXXXXX",12); int fd=mkstemp(tmp); if(fd<0) return 0; FILE *f=fdopen(fd,"wb"); if(!f) { close(fd); unlink(tmp); return 0; } int ok=fwrite(g_address(data.base),1,(size_t)data.len,f)==(size_t)data.len; if(fflush(f)||fsync(fd)) ok=0; if(fclose(f)) ok=0; if(ok && rename(tmp,s)) ok=0; if(!ok) unlink(tmp); return ok; }
static int g_os_kind(GSlice path) { char *s=g_path(path); struct stat st; if(!s || stat(s,&st)) return 0; if(S_ISDIR(st.st_mode)) return 2; return 1; }
static int g_os_line(GRef out) { GArray a; memcpy(&a,g_address(out),sizeof a); int c; int any=0; while((c=fgetc(stdin))!=EOF) { any=1; if(c==10) break; unsigned char b=(unsigned char)c; g_bytes(&a,&b,1); } if(a.len && a.data[a.len-1]==13) a.len--; memcpy(g_address(out),&a,sizeof a); return any; }
static void g_os_stdin(GRef out) { GArray a; memcpy(&a,g_address(out),sizeof a); unsigned char b[16384]; size_t n; while((n=fread(b,1,sizeof b,stdin))) g_bytes(&a,b,(int64_t)n); memcpy(g_address(out),&a,sizeof a); }
static void g_os_arg(int64_t i,GRef out) { if(i<0 || i>=g_argc) return; GArray a; memcpy(&a,g_address(out),sizeof a); g_bytes(&a,g_argv[i],(int64_t)strlen(g_argv[i])); memcpy(g_address(out),&a,sizeof a); }
static int g_os_env(GSlice name,GRef out) { char *n=g_path(name); const char *v=NULL; if(n) v=getenv(n); if(!v) return 0; GArray a; memcpy(&a,g_address(out),sizeof a); g_bytes(&a,v,(int64_t)strlen(v)); memcpy(g_address(out),&a,sizeof a); return 1; }
static int64_t g_os_time(int monotonic) { struct timespec t; clockid_t c=CLOCK_REALTIME; if(monotonic) c=CLOCK_MONOTONIC; if(clock_gettime(c,&t)) return 0; return (int64_t)t.tv_sec*1000000000+t.tv_nsec; }
static void g_os_sleep(int64_t ms) { if(ms<0) return; struct timespec t={ms/1000,(ms%1000)*1000000}; while(nanosleep(&t,&t) && errno==EINTR) {} }
static uint64_t g_os_random(void) { uint64_t n=0; FILE *f=fopen("/dev/urandom","rb"); if(f) { if(fread(&n,1,sizeof n,f)!=sizeof n) n=0; fclose(f); } if(!n) n=(uint64_t)g_os_time(0)^(uint64_t)(uintptr_t)&n; n^=n>>30; n*=UINT64_C(0xbf58476d1ce4e5b9); n^=n>>27; n*=UINT64_C(0x94d049bb133111eb); return n^(n>>31); }
static int g_sort_names(const void *a,const void *b) { return strcmp(*(const char *const *)a,*(const char *const *)b); }
static int g_os_list(GSlice path,GRef out) { char *s=g_path(path); if(!s) return 0; DIR *d=opendir(s); if(!d) return 0; char **names=NULL; size_t n=0,cap=0; struct dirent *e; while((e=readdir(d))) { if(!strcmp(e->d_name,".") || !strcmp(e->d_name,"..")) continue; if(n==cap) { cap=cap*2+16; names=realloc(names,cap*sizeof *names); if(!names) g_panic("out of memory"); } names[n]=strdup(e->d_name); n++; } closedir(d); qsort(names,n,sizeof *names,g_sort_names); GArray a; memcpy(&a,g_address(out),sizeof a); for(size_t i=0;i<n;i++) { g_bytes(&a,names[i],(int64_t)strlen(names[i])); g_bytes(&a,"\n",1); free(names[i]); } free(names); memcpy(g_address(out),&a,sizeof a); return 1; }

#define GS_CHECKED_STACKS 0
static void g_format_bounds(void *p,uint64_t n) { (void)p; (void)n; }
static const char gs_digit_pairs[201] =
    "00010203040506070809101112131415161718192021222324252627282930313233343536373839"
    "40414243444546474849505152535455565758596061626364656667686970717273747576777879"
    "8081828384858687888990919293949596979899";

static int gs_fmt_digits(uint64_t v) {
    int n = 1;
    for (;;) {
        if (v < 10) return n;
        if (v < 100) return n + 1;
        if (v < 1000) return n + 2;
        if (v < 10000) return n + 3;
        v /= 10000;
        n += 4;
    }
}

static int64_t gs_fmt_u64(uint8_t *dst, uint64_t v) {
    int n = gs_fmt_digits(v);

    uint8_t *p = dst + n;
    while (v >= 100) {
        unsigned r = (unsigned)(v % 100);
        v /= 100;
        p -= 2;
        p[0] = (uint8_t)gs_digit_pairs[2 * r];
        p[1] = (uint8_t)gs_digit_pairs[2 * r + 1];
    }
    if (v >= 10) {
        p[-2] = (uint8_t)gs_digit_pairs[2 * v];
        p[-1] = (uint8_t)gs_digit_pairs[2 * v + 1];
    } else {
        p[-1] = (uint8_t)('0' + v);
    }
    return n;
}

static int64_t gs_fmt_i64(uint8_t *dst, int64_t v) {
    if (v >= 0) return gs_fmt_u64(dst, (uint64_t)v);
    /* The magnitude in unsigned arithmetic, so i64.min needs no case. */

    dst[0] = '-';
    return 1 + gs_fmt_u64(dst + 1, 0 - (uint64_t)v);
}

/* A float's text is the fewest significant digits that read back as the
   same value of its own type and, of those, the ones nearest it, a tie going
   to the even digit (as Python's repr and Ryu choose). They are found in
   integers, by Burger and Dybvig's free-format algorithm, not through the C
   library: msvcrt, which tcc uses on Windows, rounds a printf tie away from
   zero, and below a power of two the gap to the next float is half the gap
   above, so the shortest text can lie above the value while the correctly
   rounded spelling of that length, below it, does not read back.

   The numbers are naturals in 32-bit limbs, least significant first. The
   denominator s stays below 2^1079 (ten times 2^1075, for the smallest
   doubles), and the others below eleven times s. */
typedef struct { int n; uint32_t d[36]; } gs_big;

/* a = v << sh, for v > 0. */
static void gs_big_set(gs_big *a, uint64_t v, int sh) {
    int w = sh >> 5, b = sh & 31, i;
    uint64_t lo = v << b, hi = b ? v >> (64 - b) : 0;
    for (i = 0; i < w; i++) a->d[i] = 0;
    a->d[w] = (uint32_t)lo;
    a->d[w + 1] = (uint32_t)(lo >> 32);
    a->d[w + 2] = (uint32_t)hi;
    a->n = w + 3;
    while (!a->d[a->n - 1]) a->n--;
}

static void gs_big_mul(gs_big *a, uint32_t m) {
    uint64_t c = 0;
    for (int i = 0; i < a->n; i++) {
        c += (uint64_t)a->d[i] * m;
        a->d[i] = (uint32_t)c;
        c >>= 32;
    }
    if (c) a->d[a->n++] = (uint32_t)c;
}

static void gs_big_mul_pow10(gs_big *a, int k) {
    for (; k >= 9; k -= 9) gs_big_mul(a, 1000000000u);
    for (; k > 0; k--) gs_big_mul(a, 10);
}

static int gs_big_cmp(const gs_big *a, const gs_big *b) {
    if (a->n != b->n) return a->n < b->n ? -1 : 1;
    for (int i = a->n - 1; i >= 0; i--)
        if (a->d[i] != b->d[i]) return a->d[i] < b->d[i] ? -1 : 1;
    return 0;
}

/* t = a + b */
static void gs_big_add(gs_big *t, const gs_big *a, const gs_big *b) {
    int n = a->n > b->n ? a->n : b->n;
    uint64_t c = 0;
    for (int i = 0; i < n; i++) {
        c += (uint64_t)(i < a->n ? a->d[i] : 0) + (i < b->n ? b->d[i] : 0);
        t->d[i] = (uint32_t)c;
        c >>= 32;
    }
    t->n = n;
    if (c) t->d[t->n++] = (uint32_t)c;
}

/* a -= b, for a >= b. */
static void gs_big_sub(gs_big *a, const gs_big *b) {
    uint64_t borrow = 0;
    for (int i = 0; i < a->n; i++) {
        uint64_t x = (uint64_t)a->d[i] - (i < b->n ? b->d[i] : 0) - borrow;
        a->d[i] = (uint32_t)x;
        borrow = x >> 63;
    }
    while (a->n && !a->d[a->n - 1]) a->n--;
}

/* The shortest digits of f * 2^e (f > 0) as a float of `bits` significant
   bits and least exponent emin, into dig; returns their count and sets *k
   so that the value they spell is 0.d1d2... * 10^*k. */
static int gs_float_digits(uint64_t f, int e, int bits, int emin, char *dig, int *k) {
    gs_big r, s, mp, mlo, t;
    /* Reading rounds a tie to the even significand, so the interval that
       reads back as f * 2^e includes its ends when f is even. */
    int even = !(f & 1);
    /* Below a power of two, the gap to the next float down is half the gap up. */
    int asym = f == (uint64_t)1 << (bits - 1) && e > emin;
    int up = e > 0 ? e : 0, lg = e - 1, n = 0, c;
    /* The value is r / s, and what reads back as it reaches from (r - *mm) / s
       to (r + mp) / s: half the gap to each neighbour. */
    gs_big *mm = asym ? &mlo : &mp;
    gs_big_set(&r, f, up + 1 + asym);
    gs_big_set(&s, 1, up - e + 1 + asym);
    gs_big_set(&mp, 1, up + asym);
    gs_big_set(&mlo, 1, up);
    /* Scale to 10^*k, the least power of ten above the interval: with
       lg = floor(log2 value), ceil(lg log10 2) is it or one short, and
       78913 / 2^18 is log10 2 closely enough to compute that for |lg| < 1650. */
    for (uint64_t g = f; g; g >>= 1) lg++;
    *k = lg > 0 ? ((lg * 78913) >> 18) + 1 : -((-lg * 78913) >> 18);
    if (*k >= 0) gs_big_mul_pow10(&s, *k);
    else {
        gs_big_mul_pow10(&r, -*k);
        gs_big_mul_pow10(&mp, -*k);
        if (asym) gs_big_mul_pow10(&mlo, -*k);
    }
    gs_big_add(&t, &r, &mp);
    c = gs_big_cmp(&t, &s);
    if (even ? c >= 0 : c > 0) {
        gs_big_mul(&s, 10);
        ++*k;
    }
    /* Each digit d leaves the remainder r: stop where the digits so far
       followed by d (r within *mm) or by d + 1 (r + mp past s) read back. */
    for (;;) {
        int d = 0, low, high;
        gs_big_mul(&r, 10);
        gs_big_mul(&mp, 10);
        if (asym) gs_big_mul(&mlo, 10);
        while (gs_big_cmp(&r, &s) >= 0) {
            gs_big_sub(&r, &s);
            d++;
        }
        c = gs_big_cmp(&r, mm);
        low = even ? c <= 0 : c < 0;
        gs_big_add(&t, &r, &mp);
        c = gs_big_cmp(&t, &s);
        high = even ? c >= 0 : c > 0;
        if (!low && !high) {
            dig[n++] = (char)('0' + d);
            continue;
        }
        if (low && high) {
            /* Both read back: the nearer, d + 1 when r is past half of s,
               and of two as near, the even one. */
            gs_big_add(&t, &r, &r);
            c = gs_big_cmp(&t, &s);
            high = c > 0 || (c == 0 && (d & 1));
        }
        dig[n++] = (char)('0' + d + high);
        return n;
    }
}

/* The text of a finite float from its fields: the sign, the significand
   without its implicit bit and the biased exponent, for a type of `bits`
   significant bits and least exponent emin. The digits are laid out as C's
   %g lays them out at a precision of max(15, digits): in exponent form, with
   at least two exponent digits, below 1e-4 or from that power of ten up. */
static int64_t gs_fmt_float_unchecked(uint8_t *dst, int neg, uint64_t frac, int bexp, int bits,
                            int emin) {
    char dig[20], *p = (char *)dst;
    int k, n, x, i;
    if (neg) *p++ = '-';
    if (!frac && !bexp) {
        memcpy(p, "0.0", 3);
        return p + 3 - (char *)dst;
    }
    n = gs_float_digits(bexp ? frac | (uint64_t)1 << (bits - 1) : frac,
                        (bexp ? bexp - 1 : 0) + emin, bits, emin, dig, &k);
    x = k - 1;
    if (x < -4 || x >= (n > 15 ? n : 15)) {
        *p++ = dig[0];
        if (n > 1) *p++ = '.';
        for (i = 1; i < n; i++) *p++ = dig[i];
        *p++ = 'e';
        *p++ = x < 0 ? '-' : '+';
        if (x < 0) x = -x;
        if (x >= 100) *p++ = (char)('0' + x / 100);
        *p++ = (char)('0' + x / 10 % 10);
        *p++ = (char)('0' + x % 10);
    } else if (x < 0) {
        *p++ = '0';
        *p++ = '.';
        for (i = -1; i > x; i--) *p++ = '0';
        for (i = 0; i < n; i++) *p++ = dig[i];
    } else {
        for (i = 0; i < n || i <= x; i++) {
            if (i == x + 1) *p++ = '.';
            *p++ = i < n ? dig[i] : '0';
        }
        /* A whole number still reads as a float: 1.0, not 1. */
        if (n <= x + 1) {
            *p++ = '.';
            *p++ = '0';
        }
    }
    return p - (char *)dst;
}

static int64_t gs_fmt_float(uint8_t *dst, int neg, uint64_t frac, int bexp, int bits,
                            int emin) {
#if GS_CHECKED_STACKS
    /* Determine the exact length before touching a data stack. The longest
       f64 spelling fits in 32 bytes, including sign and three exponent digits. */
    uint8_t text[32];
    int64_t n = gs_fmt_float_unchecked(text, neg, frac, bexp, bits, emin);

    memcpy(dst, text, (size_t)n);
    return n;
#else
    return gs_fmt_float_unchecked(dst, neg, frac, bexp, bits, emin);
#endif
}

static int64_t gs_fmt_f64(uint8_t *dst, double v) {
    uint64_t b;
    /* C libraries disagree here (msvcrt, which tcc uses on Windows, writes
       1.#INF and -1.#IND; others give a NaN's sign bit, which depends on
       the CPU that made it), so these are spelled by the runtime. */
    if (v != v) { g_format_bounds(dst, 3); memcpy(dst, "nan", 3); return 3; }
    if (isinf(v)) {
        if (v > 0) { g_format_bounds(dst, 3); memcpy(dst, "inf", 3); return 3; }
        g_format_bounds(dst, 4);
        memcpy(dst, "-inf", 4);
        return 4;
    }
    memcpy(&b, &v, sizeof b);
    return gs_fmt_float(dst, (int)(b >> 63), b & (((uint64_t)1 << 52) - 1),
                        (int)(b >> 52) & 0x7FF, 53, -1074);
}

/* The digits are the f32's own, laid out as an f64's are, so 0.1 as an f32
   prints as 0.1, not as the digits of the f64 it widens to. */
static int64_t gs_fmt_f32(uint8_t *dst, float v) {
    double d = v;
    uint32_t b;
    if (d != d || isinf(d)) return gs_fmt_f64(dst, d);
    memcpy(&b, &v, sizeof b);
    return gs_fmt_float(dst, (int)(b >> 31), b & 0x7FFFFF, (int)(b >> 23) & 0xFF, 24, -149);
}

static int64_t gs_fmt_bool(uint8_t *dst, int64_t v) {

    memcpy(dst, v ? "true" : "false", v ? 4 : 5);
    return v ? 4 : 5;
}

static int64_t gs_fmt_quoted(uint8_t *dst, const uint8_t *s, int64_t n) {
#if GS_CHECKED_STACKS
    uint64_t size = 2;
    for (int64_t i = 0; i < n; i++) {
        uint8_t c = s[i];
        uint64_t part = 1;
        if (c == '"' || c == '\\' || c == '\n' || c == '\r' || c == '\t') part++;
        if (size > UINT64_MAX - part) gs_panic("data stack overflow: quoted text size");
        size += part;
    }
    g_format_bounds(dst, size);
#endif
    uint8_t *d = dst;
    *d++ = '"';
    for (int64_t i = 0; i < n; i++) {
        uint8_t c = s[i];
        switch (c) {
            case '"': *d++ = '\\'; *d++ = '"'; break;
            case '\\': *d++ = '\\'; *d++ = '\\'; break;
            case '\n': *d++ = '\\'; *d++ = 'n'; break;
            case '\r': *d++ = '\\'; *d++ = 'r'; break;
            case '\t': *d++ = '\\'; *d++ = 't'; break;
            default: *d++ = c; break;
        }
    }
    *d++ = '"';
    return (int64_t)(d - dst);
}
static unsigned char *g_nullable_address(GRef r) { if(!r)return NULL;return g_address(r); }
static double g_float_literal(uint64_t bits) { double v; memcpy(&v,&bits,sizeof v); return v; }
static int64_t g_clz(uint64_t x) { if(!x) return 64; return __builtin_clzll(x); }
static int64_t g_ctz(uint64_t x) { if(!x) return 64; return __builtin_ctzll(x); }
static int g_os_path_op(GSlice path,int op) { char *s=g_path(path); if(!s) return 0; if(op==0) return unlink(s)==0; if(op==1) return rmdir(s)==0; if(mkdir(s,0777)==0) return 1; return errno==EEXIST && g_os_kind(path)==2; }
static int g_os_rename(GSlice from,GSlice to) { char *a=g_path(from),*b=g_path(to); if(!a || !b) return 0; return rename(a,b)==0; }
static int g_os_resource(GRef out) { char path[4096]; ssize_t n=readlink("/proc/self/exe",path,sizeof path); if(n<=0 || n==(ssize_t)sizeof path) return 0; while(n>0 && path[n-1]!='/') n--; if(!n) return 0; GArray a; memcpy(&a,g_address(out),sizeof a); g_bytes(&a,path,n); memcpy(g_address(out),&a,sizeof a); return 1; }
static int g_trim_memory(void) { void *p=dlsym(RTLD_DEFAULT,"malloc_trim"); if(!p) return 0; return ((int (*)(size_t))p)(0); }
typedef struct { void *data; int64_t len; } GForeignSlice;
static GForeignSlice g_foreign_slice(GSlice s) { GForeignSlice r={g_address(s.base),s.len}; return r; }
static void *g_external(const char *library,const char *name) { void *handle=RTLD_DEFAULT; if(library) { handle=dlopen(library,RTLD_NOW|RTLD_LOCAL); if(!handle) g_panic(dlerror()); } void *p=dlsym(handle,name); if(!p) g_panic(dlerror()); return p; }static void g_initialize(void); static int g_initialized;
typedef void g_t0;
typedef uint8_t g_t1;
typedef int8_t g_t2;
typedef int16_t g_t3;
typedef int32_t g_t4;
typedef int64_t g_t5;
typedef uint8_t g_t6;
typedef uint16_t g_t7;
typedef uint32_t g_t8;
typedef uint64_t g_t9;
typedef float g_t10;
typedef double g_t11;
typedef GSlice g_t12;
typedef GClosure* g_t13;
typedef struct { unsigned char data[2024]; } g_t14;
typedef GClosure* g_t15;
typedef GClosure* g_t16;
static g_t1 g_clone_1(g_t1 v);
static int g_equal_1(g_t1 a,g_t1 b);
static void g_print_1(GArray *out,g_t1 v);
static void g_nested_1(GArray *out,g_t1 v);
static g_t1 g_load_1(GRef p) {g_t1 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_1(GRef p,g_t1 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t2 g_clone_2(g_t2 v);
static int g_equal_2(g_t2 a,g_t2 b);
static void g_print_2(GArray *out,g_t2 v);
static void g_nested_2(GArray *out,g_t2 v);
static g_t2 g_load_2(GRef p) {g_t2 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_2(GRef p,g_t2 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t3 g_clone_3(g_t3 v);
static int g_equal_3(g_t3 a,g_t3 b);
static void g_print_3(GArray *out,g_t3 v);
static void g_nested_3(GArray *out,g_t3 v);
static g_t3 g_load_3(GRef p) {g_t3 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_3(GRef p,g_t3 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t4 g_clone_4(g_t4 v);
static int g_equal_4(g_t4 a,g_t4 b);
static void g_print_4(GArray *out,g_t4 v);
static void g_nested_4(GArray *out,g_t4 v);
static g_t4 g_load_4(GRef p) {g_t4 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_4(GRef p,g_t4 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t5 g_clone_5(g_t5 v);
static int g_equal_5(g_t5 a,g_t5 b);
static void g_print_5(GArray *out,g_t5 v);
static void g_nested_5(GArray *out,g_t5 v);
static g_t5 g_load_5(GRef p) {g_t5 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_5(GRef p,g_t5 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t6 g_clone_6(g_t6 v);
static int g_equal_6(g_t6 a,g_t6 b);
static void g_print_6(GArray *out,g_t6 v);
static void g_nested_6(GArray *out,g_t6 v);
static g_t6 g_load_6(GRef p) {g_t6 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_6(GRef p,g_t6 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t7 g_clone_7(g_t7 v);
static int g_equal_7(g_t7 a,g_t7 b);
static void g_print_7(GArray *out,g_t7 v);
static void g_nested_7(GArray *out,g_t7 v);
static g_t7 g_load_7(GRef p) {g_t7 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_7(GRef p,g_t7 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t8 g_clone_8(g_t8 v);
static int g_equal_8(g_t8 a,g_t8 b);
static void g_print_8(GArray *out,g_t8 v);
static void g_nested_8(GArray *out,g_t8 v);
static g_t8 g_load_8(GRef p) {g_t8 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_8(GRef p,g_t8 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t9 g_clone_9(g_t9 v);
static int g_equal_9(g_t9 a,g_t9 b);
static void g_print_9(GArray *out,g_t9 v);
static void g_nested_9(GArray *out,g_t9 v);
static g_t9 g_load_9(GRef p) {g_t9 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_9(GRef p,g_t9 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t10 g_clone_10(g_t10 v);
static int g_equal_10(g_t10 a,g_t10 b);
static void g_print_10(GArray *out,g_t10 v);
static void g_nested_10(GArray *out,g_t10 v);
static g_t10 g_load_10(GRef p) {g_t10 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_10(GRef p,g_t10 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t11 g_clone_11(g_t11 v);
static int g_equal_11(g_t11 a,g_t11 b);
static void g_print_11(GArray *out,g_t11 v);
static void g_nested_11(GArray *out,g_t11 v);
static g_t11 g_load_11(GRef p) {g_t11 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_11(GRef p,g_t11 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t12 g_clone_12(g_t12 v);
static int g_equal_12(g_t12 a,g_t12 b);
static void g_print_12(GArray *out,g_t12 v);
static void g_nested_12(GArray *out,g_t12 v);
static g_t12 g_load_12(GRef p) {g_t12 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_12(GRef p,g_t12 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t13 g_clone_13(g_t13 v);
static int g_equal_13(g_t13 a,g_t13 b);
static void g_print_13(GArray *out,g_t13 v);
static void g_nested_13(GArray *out,g_t13 v);
static g_t13 g_load_13(GRef p) {g_t13 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_13(GRef p,g_t13 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t14 g_clone_14(g_t14 v);
static int g_equal_14(g_t14 a,g_t14 b);
static void g_print_14(GArray *out,g_t14 v);
static void g_nested_14(GArray *out,g_t14 v);
static g_t14 g_load_14(GRef p) {g_t14 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_14(GRef p,g_t14 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t15 g_clone_15(g_t15 v);
static int g_equal_15(g_t15 a,g_t15 b);
static void g_print_15(GArray *out,g_t15 v);
static void g_nested_15(GArray *out,g_t15 v);
static g_t15 g_load_15(GRef p) {g_t15 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_15(GRef p,g_t15 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t16 g_clone_16(g_t16 v);
static int g_equal_16(g_t16 a,g_t16 b);
static void g_print_16(GArray *out,g_t16 v);
static void g_nested_16(GArray *out,g_t16 v);
static g_t16 g_load_16(GRef p) {g_t16 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_16(GRef p,g_t16 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t1 g_clone_1(g_t1 v) {
return v;}
static int g_equal_1(g_t1 a,g_t1 b){
return a==b;
}
static void g_print_1(GArray *out,g_t1 v) {
unsigned char b[128]; int64_t n=gs_fmt_bool(b,v);g_print_bytes(out,b,n);
}
static void g_nested_1(GArray *out,g_t1 v){
g_print_1(out,v);
}
static g_t2 g_clone_2(g_t2 v) {
return v;}
static int g_equal_2(g_t2 a,g_t2 b){
return a==b;
}
static void g_print_2(GArray *out,g_t2 v) {
unsigned char b[128]; int64_t n=gs_fmt_i64(b,v);g_print_bytes(out,b,n);
}
static void g_nested_2(GArray *out,g_t2 v){
g_print_2(out,v);
}
static g_t3 g_clone_3(g_t3 v) {
return v;}
static int g_equal_3(g_t3 a,g_t3 b){
return a==b;
}
static void g_print_3(GArray *out,g_t3 v) {
unsigned char b[128]; int64_t n=gs_fmt_i64(b,v);g_print_bytes(out,b,n);
}
static void g_nested_3(GArray *out,g_t3 v){
g_print_3(out,v);
}
static g_t4 g_clone_4(g_t4 v) {
return v;}
static int g_equal_4(g_t4 a,g_t4 b){
return a==b;
}
static void g_print_4(GArray *out,g_t4 v) {
unsigned char b[128]; int64_t n=gs_fmt_i64(b,v);g_print_bytes(out,b,n);
}
static void g_nested_4(GArray *out,g_t4 v){
g_print_4(out,v);
}
static g_t5 g_clone_5(g_t5 v) {
return v;}
static int g_equal_5(g_t5 a,g_t5 b){
return a==b;
}
static void g_print_5(GArray *out,g_t5 v) {
unsigned char b[128]; int64_t n=gs_fmt_i64(b,v);g_print_bytes(out,b,n);
}
static void g_nested_5(GArray *out,g_t5 v){
g_print_5(out,v);
}
static g_t6 g_clone_6(g_t6 v) {
return v;}
static int g_equal_6(g_t6 a,g_t6 b){
return a==b;
}
static void g_print_6(GArray *out,g_t6 v) {
unsigned char b[128]; int64_t n=gs_fmt_u64(b,v);g_print_bytes(out,b,n);
}
static void g_nested_6(GArray *out,g_t6 v){
g_print_6(out,v);
}
static g_t7 g_clone_7(g_t7 v) {
return v;}
static int g_equal_7(g_t7 a,g_t7 b){
return a==b;
}
static void g_print_7(GArray *out,g_t7 v) {
unsigned char b[128]; int64_t n=gs_fmt_u64(b,v);g_print_bytes(out,b,n);
}
static void g_nested_7(GArray *out,g_t7 v){
g_print_7(out,v);
}
static g_t8 g_clone_8(g_t8 v) {
return v;}
static int g_equal_8(g_t8 a,g_t8 b){
return a==b;
}
static void g_print_8(GArray *out,g_t8 v) {
unsigned char b[128]; int64_t n=gs_fmt_u64(b,v);g_print_bytes(out,b,n);
}
static void g_nested_8(GArray *out,g_t8 v){
g_print_8(out,v);
}
static g_t9 g_clone_9(g_t9 v) {
return v;}
static int g_equal_9(g_t9 a,g_t9 b){
return a==b;
}
static void g_print_9(GArray *out,g_t9 v) {
unsigned char b[128]; int64_t n=gs_fmt_u64(b,v);g_print_bytes(out,b,n);
}
static void g_nested_9(GArray *out,g_t9 v){
g_print_9(out,v);
}
static g_t10 g_clone_10(g_t10 v) {
return v;}
static int g_equal_10(g_t10 a,g_t10 b){
return a==b;
}
static void g_print_10(GArray *out,g_t10 v) {
unsigned char b[128]; int64_t n=gs_fmt_f32(b,v);g_print_bytes(out,b,n);
}
static void g_nested_10(GArray *out,g_t10 v){
g_print_10(out,v);
}
static g_t11 g_clone_11(g_t11 v) {
return v;}
static int g_equal_11(g_t11 a,g_t11 b){
return a==b;
}
static void g_print_11(GArray *out,g_t11 v) {
unsigned char b[128]; int64_t n=gs_fmt_f64(b,v);g_print_bytes(out,b,n);
}
static void g_nested_11(GArray *out,g_t11 v){
g_print_11(out,v);
}
static g_t12 g_clone_12(g_t12 v) {
return v;}
static int g_equal_12(g_t12 a,g_t12 b){
GRef ar=g_ref(&a),br=g_ref(&b);int64_t n=g_len(ar,5,-1,0);if(n!=g_len(br,5,-1,0))return 0;
for(int64_t i=0;i<n;i++){if(!g_equal_6(g_load_6(g_element(ar,5,-1,0,1,i,0)),g_load_6(g_element(br,5,-1,0,1,i,0))))return 0;}return 1;
}
static void g_print_12(GArray *out,g_t12 v) {
GRef r=g_ref(&v); int64_t n=g_len(r,5,-1,0);
for(int64_t i=0;i<n;i++) {
g_print_bytes(out,g_address(g_element(r,5,-1,0,1,i,0)),1);
}
}
static void g_nested_12(GArray *out,g_t12 v){
GRef r=g_ref(&v);int64_t n=g_len(r,5,-1,0);if(n<0 || (uint64_t)n>(SIZE_MAX-2)/2)g_panic("text size overflow");unsigned char *b=g_alloc((size_t)n*2+2);int64_t written=gs_fmt_quoted(b,g_address(g_element(r,5,-1,0,1,0,1)),n);g_print_bytes(out,b,written);
}
static g_t13 g_clone_13(g_t13 v) {
return v;}
static int g_equal_13(g_t13 a,g_t13 b){
return a==b;
}
static void g_print_13(GArray *out,g_t13 v) {
g_print_text(out,"fn");
}
static void g_nested_13(GArray *out,g_t13 v){
g_print_13(out,v);
}
static g_t14 g_clone_14(g_t14 v) {
GRef src=g_ref(&v); int64_t n=g_len(src,0,253,0);
GRef dst=g_ref(&v); for(int64_t i=0;i<n;i++) {
g_store_11(g_element(dst,0,253,0,8,i,0),g_clone_11(g_load_11(g_element(src,0,253,0,8,i,0)))); }
return v;}
static int g_equal_14(g_t14 a,g_t14 b){
GRef ar=g_ref(&a),br=g_ref(&b);int64_t n=g_len(ar,0,253,0);if(n!=g_len(br,0,253,0))return 0;
for(int64_t i=0;i<n;i++){if(!g_equal_11(g_load_11(g_element(ar,0,253,0,8,i,0)),g_load_11(g_element(br,0,253,0,8,i,0))))return 0;}return 1;
}
static void g_print_14(GArray *out,g_t14 v) {
GRef r=g_ref(&v); int64_t n=g_len(r,0,253,0);
g_print_text(out,"[");
for(int64_t i=0;i<n;i++) {
if(i)g_print_text(out,", ");
g_nested_11(out,g_load_11(g_element(r,0,253,0,8,i,0)));
}
g_print_text(out,"]");
}
static void g_nested_14(GArray *out,g_t14 v){
g_print_14(out,v);
}
static g_t15 g_clone_15(g_t15 v) {
return v;}
static int g_equal_15(g_t15 a,g_t15 b){
return a==b;
}
static void g_print_15(GArray *out,g_t15 v) {
g_print_text(out,"fn");
}
static void g_nested_15(GArray *out,g_t15 v){
g_print_15(out,v);
}
static g_t16 g_clone_16(g_t16 v) {
return v;}
static int g_equal_16(g_t16 a,g_t16 b){
return a==b;
}
static void g_print_16(GArray *out,g_t16 v) {
g_print_text(out,"fn");
}
static void g_nested_16(GArray *out,g_t16 v){
g_print_16(out,v);
}
static g_t0 g_fn2(GClosure *g_env);
static g_t0 g_fn2(GClosure *g_env) {
GReturnFrame g_frame={0};g_frame.parent=g_return_top;g_frame.function=2;
g_return_top=&g_frame;if(setjmp(g_frame.jump))goto g_return;
g_t14 g_s1={0};
{
GRef g_v0=0;
g_v0=g_ref(&g_s1);
g_t14 g_v1={0};
GRef g_v2=0;
g_v2=g_ref(&g_v1);
g_t5 g_v3={0};
g_v3=253;
g_t11 g_v4={0};
g_v4=g_float_literal(UINT64_C(0));
g_store_11(g_element(g_v2,0,253,0,8,0,0),g_v4);
g_t11 g_v5={0};
g_v5=g_float_literal(UINT64_C(4591870180066957722));
g_store_11(g_element(g_v2,0,253,0,8,1,0),g_v5);
g_t11 g_v6={0};
g_v6=g_float_literal(UINT64_C(4607182418800017408));
g_store_11(g_element(g_v2,0,253,0,8,2,0),g_v6);
g_t11 g_v7={0};
g_v7=g_float_literal(UINT64_C(4607182418800017409));
g_store_11(g_element(g_v2,0,253,0,8,3,0),g_v7);
g_t11 g_v8={0};
g_v8=g_float_literal(UINT64_C(4845873199050653696));
g_store_11(g_element(g_v2,0,253,0,8,4,0),g_v8);
g_t11 g_v9={0};
g_v9=g_float_literal(UINT64_C(4503599627370496));
g_store_11(g_element(g_v2,0,253,0,8,5,0),g_v9);
g_t11 g_v10={0};
g_v10=g_float_literal(UINT64_C(1));
g_store_11(g_element(g_v2,0,253,0,8,6,0),g_v10);
g_t11 g_v11={0};
g_v11=g_float_literal(UINT64_C(0));
g_store_11(g_element(g_v2,0,253,0,8,7,0),g_v11);
g_t11 g_v12={0};
g_v12=g_float_literal(UINT64_C(9218868437227405311));
g_store_11(g_element(g_v2,0,253,0,8,8,0),g_v12);
g_t11 g_v13={0};
g_v13=INFINITY;
g_store_11(g_element(g_v2,0,253,0,8,9,0),g_v13);
g_t11 g_v14={0};
g_v14=g_float_literal(UINT64_C(1));
g_store_11(g_element(g_v2,0,253,0,8,10,0),g_v14);
g_t11 g_v15={0};
g_v15=g_float_literal(UINT64_C(9218868437227405311));
g_store_11(g_element(g_v2,0,253,0,8,11,0),g_v15);
g_t11 g_v16={0};
g_v16=INFINITY;
g_store_11(g_element(g_v2,0,253,0,8,12,0),g_v16);
g_t11 g_v17={0};
g_v17=g_float_literal(UINT64_C(4005167699530140215));
g_store_11(g_element(g_v2,0,253,0,8,13,0),g_v17);
g_t11 g_v18={0};
g_v18=g_float_literal(UINT64_C(5892713935095098913));
g_store_11(g_element(g_v2,0,253,0,8,14,0),g_v18);
g_t11 g_v19={0};
g_v19=g_float_literal(UINT64_C(5769556440825123613));
g_store_11(g_element(g_v2,0,253,0,8,15,0),g_v19);
g_t11 g_v20={0};
g_v20=g_float_literal(UINT64_C(3181938859592490285));
g_store_11(g_element(g_v2,0,253,0,8,16,0),g_v20);
g_t11 g_v21={0};
g_v21=g_float_literal(UINT64_C(4109002015699619416));
g_store_11(g_element(g_v2,0,253,0,8,17,0),g_v21);
g_t11 g_v22={0};
g_v22=g_float_literal(UINT64_C(2645287746577988848));
g_store_11(g_element(g_v2,0,253,0,8,18,0),g_v22);
g_t11 g_v23={0};
g_v23=g_float_literal(UINT64_C(8030972759258023644));
g_store_11(g_element(g_v2,0,253,0,8,19,0),g_v23);
g_t11 g_v24={0};
g_v24=INFINITY;
g_store_11(g_element(g_v2,0,253,0,8,20,0),g_v24);
g_t11 g_v25={0};
g_v25=g_float_literal(UINT64_C(4704458884332664019));
g_store_11(g_element(g_v2,0,253,0,8,21,0),g_v25);
g_t11 g_v26={0};
g_v26=INFINITY;
g_store_11(g_element(g_v2,0,253,0,8,22,0),g_v26);
g_t11 g_v27={0};
g_v27=g_float_literal(UINT64_C(8859389055658808634));
g_store_11(g_element(g_v2,0,253,0,8,23,0),g_v27);
g_t11 g_v28={0};
g_v28=g_float_literal(UINT64_C(447563653440538154));
g_store_11(g_element(g_v2,0,253,0,8,24,0),g_v28);
g_t11 g_v29={0};
g_v29=g_float_literal(UINT64_C(6993155102912199704));
g_store_11(g_element(g_v2,0,253,0,8,25,0),g_v29);
g_t11 g_v30={0};
g_v30=g_float_literal(UINT64_C(3628010359834251721));
g_store_11(g_element(g_v2,0,253,0,8,26,0),g_v30);
g_t11 g_v31={0};
g_v31=g_float_literal(UINT64_C(1222711228653463081));
g_store_11(g_element(g_v2,0,253,0,8,27,0),g_v31);
g_t11 g_v32={0};
g_v32=INFINITY;
g_store_11(g_element(g_v2,0,253,0,8,28,0),g_v32);
g_t11 g_v33={0};
g_v33=g_float_literal(UINT64_C(6228251650382225984));
g_store_11(g_element(g_v2,0,253,0,8,29,0),g_v33);
g_t11 g_v34={0};
g_v34=g_float_literal(UINT64_C(2388312706442789330));
g_store_11(g_element(g_v2,0,253,0,8,30,0),g_v34);
g_t11 g_v35={0};
g_v35=g_float_literal(UINT64_C(4806266458643649661));
g_store_11(g_element(g_v2,0,253,0,8,31,0),g_v35);
g_t11 g_v36={0};
g_v36=g_float_literal(UINT64_C(8301026198874887296));
g_store_11(g_element(g_v2,0,253,0,8,32,0),g_v36);
g_t11 g_v37={0};
g_v37=g_float_literal(UINT64_C(5766226098060346528));
g_store_11(g_element(g_v2,0,253,0,8,33,0),g_v37);
g_t11 g_v38={0};
g_v38=g_float_literal(UINT64_C(983821293431280567));
g_store_11(g_element(g_v2,0,253,0,8,34,0),g_v38);
g_t11 g_v39={0};
g_v39=g_float_literal(UINT64_C(640277745441478880));
g_store_11(g_element(g_v2,0,253,0,8,35,0),g_v39);
g_t11 g_v40={0};
g_v40=g_float_literal(UINT64_C(671422064614577873));
g_store_11(g_element(g_v2,0,253,0,8,36,0),g_v40);
g_t11 g_v41={0};
g_v41=g_float_literal(UINT64_C(9195108723397657489));
g_store_11(g_element(g_v2,0,253,0,8,37,0),g_v41);
g_t11 g_v42={0};
g_v42=g_float_literal(UINT64_C(1689065239016698482));
g_store_11(g_element(g_v2,0,253,0,8,38,0),g_v42);
g_t11 g_v43={0};
g_v43=g_float_literal(UINT64_C(5032909334995508786));
g_store_11(g_element(g_v2,0,253,0,8,39,0),g_v43);
g_t11 g_v44={0};
g_v44=g_float_literal(UINT64_C(5872237531039225157));
g_store_11(g_element(g_v2,0,253,0,8,40,0),g_v44);
g_t11 g_v45={0};
g_v45=g_float_literal(UINT64_C(1629022070888638568));
g_store_11(g_element(g_v2,0,253,0,8,41,0),g_v45);
g_t11 g_v46={0};
g_v46=g_float_literal(UINT64_C(7897419137470212216));
g_store_11(g_element(g_v2,0,253,0,8,42,0),g_v46);
g_t11 g_v47={0};
g_v47=g_float_literal(UINT64_C(8720884166595033884));
g_store_11(g_element(g_v2,0,253,0,8,43,0),g_v47);
g_t11 g_v48={0};
g_v48=g_float_literal(UINT64_C(2182123789000046806));
g_store_11(g_element(g_v2,0,253,0,8,44,0),g_v48);
g_t11 g_v49={0};
g_v49=g_float_literal(UINT64_C(8460954063561400474));
g_store_11(g_element(g_v2,0,253,0,8,45,0),g_v49);
g_t11 g_v50={0};
g_v50=g_float_literal(UINT64_C(8063845559738977826));
g_store_11(g_element(g_v2,0,253,0,8,46,0),g_v50);
g_t11 g_v51={0};
g_v51=g_float_literal(UINT64_C(8814899069267005718));
g_store_11(g_element(g_v2,0,253,0,8,47,0),g_v51);
g_t11 g_v52={0};
g_v52=g_float_literal(UINT64_C(1422871158159568568));
g_store_11(g_element(g_v2,0,253,0,8,48,0),g_v52);
g_t11 g_v53={0};
g_v53=g_float_literal(UINT64_C(6816768765091229310));
g_store_11(g_element(g_v2,0,253,0,8,49,0),g_v53);
g_t11 g_v54={0};
g_v54=g_float_literal(UINT64_C(3824835572315228713));
g_store_11(g_element(g_v2,0,253,0,8,50,0),g_v54);
g_t11 g_v55={0};
g_v55=g_float_literal(UINT64_C(3113036482823491053));
g_store_11(g_element(g_v2,0,253,0,8,51,0),g_v55);
g_t11 g_v56={0};
g_v56=g_float_literal(UINT64_C(3802597394409172490));
g_store_11(g_element(g_v2,0,253,0,8,52,0),g_v56);
g_t11 g_v57={0};
g_v57=g_float_literal(UINT64_C(2378906630013209327));
g_store_11(g_element(g_v2,0,253,0,8,53,0),g_v57);
g_t11 g_v58={0};
g_v58=INFINITY;
g_store_11(g_element(g_v2,0,253,0,8,54,0),g_v58);
g_t11 g_v59={0};
g_v59=g_float_literal(UINT64_C(6496006018289659185));
g_store_11(g_element(g_v2,0,253,0,8,55,0),g_v59);
g_t11 g_v60={0};
g_v60=g_float_literal(UINT64_C(0));
g_store_11(g_element(g_v2,0,253,0,8,56,0),g_v60);
g_t11 g_v61={0};
g_v61=g_float_literal(UINT64_C(3648106949820815832));
g_store_11(g_element(g_v2,0,253,0,8,57,0),g_v61);
g_t11 g_v62={0};
g_v62=g_float_literal(UINT64_C(6368151124216342288));
g_store_11(g_element(g_v2,0,253,0,8,58,0),g_v62);
g_t11 g_v63={0};
g_v63=g_float_literal(UINT64_C(1790195389874879066));
g_store_11(g_element(g_v2,0,253,0,8,59,0),g_v63);
g_t11 g_v64={0};
g_v64=g_float_literal(UINT64_C(3752081986132186250));
g_store_11(g_element(g_v2,0,253,0,8,60,0),g_v64);
g_t11 g_v65={0};
g_v65=g_float_literal(UINT64_C(0));
g_store_11(g_element(g_v2,0,253,0,8,61,0),g_v65);
g_t11 g_v66={0};
g_v66=g_float_literal(UINT64_C(2244354743578365543));
g_store_11(g_element(g_v2,0,253,0,8,62,0),g_v66);
g_t11 g_v67={0};
g_v67=g_float_literal(UINT64_C(1667885392533376690));
g_store_11(g_element(g_v2,0,253,0,8,63,0),g_v67);
g_t11 g_v68={0};
g_v68=INFINITY;
g_store_11(g_element(g_v2,0,253,0,8,64,0),g_v68);
g_t11 g_v69={0};
g_v69=g_float_literal(UINT64_C(5994600393520210540));
g_store_11(g_element(g_v2,0,253,0,8,65,0),g_v69);
g_t11 g_v70={0};
g_v70=g_float_literal(UINT64_C(3304208451613649993));
g_store_11(g_element(g_v2,0,253,0,8,66,0),g_v70);
g_t11 g_v71={0};
g_v71=g_float_literal(UINT64_C(8579924855804457733));
g_store_11(g_element(g_v2,0,253,0,8,67,0),g_v71);
g_t11 g_v72={0};
g_v72=g_float_literal(UINT64_C(5190052588119063643));
g_store_11(g_element(g_v2,0,253,0,8,68,0),g_v72);
g_t11 g_v73={0};
g_v73=g_float_literal(UINT64_C(5055186697757859387));
g_store_11(g_element(g_v2,0,253,0,8,69,0),g_v73);
g_t11 g_v74={0};
g_v74=g_float_literal(UINT64_C(7462770869358707572));
g_store_11(g_element(g_v2,0,253,0,8,70,0),g_v74);
g_t11 g_v75={0};
g_v75=g_float_literal(UINT64_C(743870241223618655));
g_store_11(g_element(g_v2,0,253,0,8,71,0),g_v75);
g_t11 g_v76={0};
g_v76=g_float_literal(UINT64_C(8014656277571747088));
g_store_11(g_element(g_v2,0,253,0,8,72,0),g_v76);
g_t11 g_v77={0};
g_v77=g_float_literal(UINT64_C(8428575629880434462));
g_store_11(g_element(g_v2,0,253,0,8,73,0),g_v77);
g_t11 g_v78={0};
g_v78=g_float_literal(UINT64_C(8007474494933317031));
g_store_11(g_element(g_v2,0,253,0,8,74,0),g_v78);
g_t11 g_v79={0};
g_v79=g_float_literal(UINT64_C(4945424723314012025));
g_store_11(g_element(g_v2,0,253,0,8,75,0),g_v79);
g_t11 g_v80={0};
g_v80=g_float_literal(UINT64_C(1776714748289151547));
g_store_11(g_element(g_v2,0,253,0,8,76,0),g_v80);
g_t11 g_v81={0};
g_v81=g_float_literal(UINT64_C(350081766734535176));
g_store_11(g_element(g_v2,0,253,0,8,77,0),g_v81);
g_t11 g_v82={0};
g_v82=g_float_literal(UINT64_C(3912848399716826062));
g_store_11(g_element(g_v2,0,253,0,8,78,0),g_v82);
g_t11 g_v83={0};
g_v83=g_float_literal(UINT64_C(6335922501865298516));
g_store_11(g_element(g_v2,0,253,0,8,79,0),g_v83);
g_t11 g_v84={0};
g_v84=g_float_literal(UINT64_C(3328386423976112932));
g_store_11(g_element(g_v2,0,253,0,8,80,0),g_v84);
g_t11 g_v85={0};
g_v85=g_float_literal(UINT64_C(1733148242577623348));
g_store_11(g_element(g_v2,0,253,0,8,81,0),g_v85);
g_t11 g_v86={0};
g_v86=g_float_literal(UINT64_C(4156584266632212234));
g_store_11(g_element(g_v2,0,253,0,8,82,0),g_v86);
g_t11 g_v87={0};
g_v87=g_float_literal(UINT64_C(3303656317231126777));
g_store_11(g_element(g_v2,0,253,0,8,83,0),g_v87);
g_t11 g_v88={0};
g_v88=INFINITY;
g_store_11(g_element(g_v2,0,253,0,8,84,0),g_v88);
g_t11 g_v89={0};
g_v89=g_float_literal(UINT64_C(4076108549889347786));
g_store_11(g_element(g_v2,0,253,0,8,85,0),g_v89);
g_t11 g_v90={0};
g_v90=INFINITY;
g_store_11(g_element(g_v2,0,253,0,8,86,0),g_v90);
g_t11 g_v91={0};
g_v91=g_float_literal(UINT64_C(8494773382364512930));
g_store_11(g_element(g_v2,0,253,0,8,87,0),g_v91);
g_t11 g_v92={0};
g_v92=g_float_literal(UINT64_C(4980949228569965298));
g_store_11(g_element(g_v2,0,253,0,8,88,0),g_v92);
g_t11 g_v93={0};
g_v93=g_float_literal(UINT64_C(1878423667955815480));
g_store_11(g_element(g_v2,0,253,0,8,89,0),g_v93);
g_t11 g_v94={0};
g_v94=g_float_literal(UINT64_C(199835759260786970));
g_store_11(g_element(g_v2,0,253,0,8,90,0),g_v94);
g_t11 g_v95={0};
g_v95=g_float_literal(UINT64_C(3346979000480718215));
g_store_11(g_element(g_v2,0,253,0,8,91,0),g_v95);
g_t11 g_v96={0};
g_v96=g_float_literal(UINT64_C(4467632678085255127));
g_store_11(g_element(g_v2,0,253,0,8,92,0),g_v96);
g_t11 g_v97={0};
g_v97=g_float_literal(UINT64_C(3283374273921982718));
g_store_11(g_element(g_v2,0,253,0,8,93,0),g_v97);
g_t11 g_v98={0};
g_v98=INFINITY;
g_store_11(g_element(g_v2,0,253,0,8,94,0),g_v98);
g_t11 g_v99={0};
g_v99=INFINITY;
g_store_11(g_element(g_v2,0,253,0,8,95,0),g_v99);
g_t11 g_v100={0};
g_v100=g_float_literal(UINT64_C(6648724050736940226));
g_store_11(g_element(g_v2,0,253,0,8,96,0),g_v100);
g_t11 g_v101={0};
g_v101=g_float_literal(UINT64_C(8989451096935104677));
g_store_11(g_element(g_v2,0,253,0,8,97,0),g_v101);
g_t11 g_v102={0};
g_v102=g_float_literal(UINT64_C(1130186057340922418));
g_store_11(g_element(g_v2,0,253,0,8,98,0),g_v102);
g_t11 g_v103={0};
g_v103=INFINITY;
g_store_11(g_element(g_v2,0,253,0,8,99,0),g_v103);
g_t11 g_v104={0};
g_v104=g_float_literal(UINT64_C(1658250507547163710));
g_store_11(g_element(g_v2,0,253,0,8,100,0),g_v104);
g_t11 g_v105={0};
g_v105=g_float_literal(UINT64_C(3464240066524928027));
g_store_11(g_element(g_v2,0,253,0,8,101,0),g_v105);
g_t11 g_v106={0};
g_v106=g_float_literal(UINT64_C(7948307639801569007));
g_store_11(g_element(g_v2,0,253,0,8,102,0),g_v106);
g_t11 g_v107={0};
g_v107=g_float_literal(UINT64_C(1449357576686593860));
g_store_11(g_element(g_v2,0,253,0,8,103,0),g_v107);
g_t11 g_v108={0};
g_v108=g_float_literal(UINT64_C(1561845769080002743));
g_store_11(g_element(g_v2,0,253,0,8,104,0),g_v108);
g_t11 g_v109={0};
g_v109=g_float_literal(UINT64_C(3389747053336783239));
g_store_11(g_element(g_v2,0,253,0,8,105,0),g_v109);
g_t11 g_v110={0};
g_v110=g_float_literal(UINT64_C(771976051991131990));
g_store_11(g_element(g_v2,0,253,0,8,106,0),g_v110);
g_t11 g_v111={0};
g_v111=g_float_literal(UINT64_C(4777304015600763026));
g_store_11(g_element(g_v2,0,253,0,8,107,0),g_v111);
g_t11 g_v112={0};
g_v112=g_float_literal(UINT64_C(1442802340948349566));
g_store_11(g_element(g_v2,0,253,0,8,108,0),g_v112);
g_t11 g_v113={0};
g_v113=g_float_literal(UINT64_C(8914906975533035643));
g_store_11(g_element(g_v2,0,253,0,8,109,0),g_v113);
g_t11 g_v114={0};
g_v114=g_float_literal(UINT64_C(975961617117352653));
g_store_11(g_element(g_v2,0,253,0,8,110,0),g_v114);
g_t11 g_v115={0};
g_v115=g_float_literal(UINT64_C(5443561120196127071));
g_store_11(g_element(g_v2,0,253,0,8,111,0),g_v115);
g_t11 g_v116={0};
g_v116=g_float_literal(UINT64_C(4364829712392495659));
g_store_11(g_element(g_v2,0,253,0,8,112,0),g_v116);
g_t11 g_v117={0};
g_v117=g_float_literal(UINT64_C(3435452607891134805));
g_store_11(g_element(g_v2,0,253,0,8,113,0),g_v117);
g_t11 g_v118={0};
g_v118=g_float_literal(UINT64_C(8121501791027687217));
g_store_11(g_element(g_v2,0,253,0,8,114,0),g_v118);
g_t11 g_v119={0};
g_v119=g_float_literal(UINT64_C(8073721655841670329));
g_store_11(g_element(g_v2,0,253,0,8,115,0),g_v119);
g_t11 g_v120={0};
g_v120=g_float_literal(UINT64_C(2078300232886609781));
g_store_11(g_element(g_v2,0,253,0,8,116,0),g_v120);
g_t11 g_v121={0};
g_v121=g_float_literal(UINT64_C(267313595402018462));
g_store_11(g_element(g_v2,0,253,0,8,117,0),g_v121);
g_t11 g_v122={0};
g_v122=g_float_literal(UINT64_C(2958037114941988060));
g_store_11(g_element(g_v2,0,253,0,8,118,0),g_v122);
g_t11 g_v123={0};
g_v123=INFINITY;
g_store_11(g_element(g_v2,0,253,0,8,119,0),g_v123);
g_t11 g_v124={0};
g_v124=g_float_literal(UINT64_C(0));
g_store_11(g_element(g_v2,0,253,0,8,120,0),g_v124);
g_t11 g_v125={0};
g_v125=g_float_literal(UINT64_C(8101599615987144427));
g_store_11(g_element(g_v2,0,253,0,8,121,0),g_v125);
g_t11 g_v126={0};
g_v126=g_float_literal(UINT64_C(5635175954939594973));
g_store_11(g_element(g_v2,0,253,0,8,122,0),g_v126);
g_t11 g_v127={0};
g_v127=g_float_literal(UINT64_C(4351641955852899738));
g_store_11(g_element(g_v2,0,253,0,8,123,0),g_v127);
g_t11 g_v128={0};
g_v128=g_float_literal(UINT64_C(1161507582246467887));
g_store_11(g_element(g_v2,0,253,0,8,124,0),g_v128);
g_t11 g_v129={0};
g_v129=g_float_literal(UINT64_C(6805955804891491762));
g_store_11(g_element(g_v2,0,253,0,8,125,0),g_v129);
g_t11 g_v130={0};
g_v130=g_float_literal(UINT64_C(5564810267605949286));
g_store_11(g_element(g_v2,0,253,0,8,126,0),g_v130);
g_t11 g_v131={0};
g_v131=g_float_literal(UINT64_C(3986333060279576774));
g_store_11(g_element(g_v2,0,253,0,8,127,0),g_v131);
g_t11 g_v132={0};
g_v132=g_float_literal(UINT64_C(5817122810634462525));
g_store_11(g_element(g_v2,0,253,0,8,128,0),g_v132);
g_t11 g_v133={0};
g_v133=g_float_literal(UINT64_C(1450214935376233509));
g_store_11(g_element(g_v2,0,253,0,8,129,0),g_v133);
g_t11 g_v134={0};
g_v134=g_float_literal(UINT64_C(1357597606390754952));
g_store_11(g_element(g_v2,0,253,0,8,130,0),g_v134);
g_t11 g_v135={0};
g_v135=INFINITY;
g_store_11(g_element(g_v2,0,253,0,8,131,0),g_v135);
g_t11 g_v136={0};
g_v136=g_float_literal(UINT64_C(1658889310140803714));
g_store_11(g_element(g_v2,0,253,0,8,132,0),g_v136);
g_t11 g_v137={0};
g_v137=g_float_literal(UINT64_C(8525506417214170780));
g_store_11(g_element(g_v2,0,253,0,8,133,0),g_v137);
g_t11 g_v138={0};
g_v138=g_float_literal(UINT64_C(8403013428326846728));
g_store_11(g_element(g_v2,0,253,0,8,134,0),g_v138);
g_t11 g_v139={0};
g_v139=g_float_literal(UINT64_C(1528861457442000007));
g_store_11(g_element(g_v2,0,253,0,8,135,0),g_v139);
g_t11 g_v140={0};
g_v140=g_float_literal(UINT64_C(7386354945794214367));
g_store_11(g_element(g_v2,0,253,0,8,136,0),g_v140);
g_t11 g_v141={0};
g_v141=g_float_literal(UINT64_C(6572945838833173773));
g_store_11(g_element(g_v2,0,253,0,8,137,0),g_v141);
g_t11 g_v142={0};
g_v142=g_float_literal(UINT64_C(7690529906508920230));
g_store_11(g_element(g_v2,0,253,0,8,138,0),g_v142);
g_t11 g_v143={0};
g_v143=g_float_literal(UINT64_C(4136126338616924679));
g_store_11(g_element(g_v2,0,253,0,8,139,0),g_v143);
g_t11 g_v144={0};
g_v144=g_float_literal(UINT64_C(9049254093775290510));
g_store_11(g_element(g_v2,0,253,0,8,140,0),g_v144);
g_t11 g_v145={0};
g_v145=g_float_literal(UINT64_C(86348474367875409));
g_store_11(g_element(g_v2,0,253,0,8,141,0),g_v145);
g_t11 g_v146={0};
g_v146=g_float_literal(UINT64_C(189192839116787303));
g_store_11(g_element(g_v2,0,253,0,8,142,0),g_v146);
g_t11 g_v147={0};
g_v147=g_float_literal(UINT64_C(2166370610369969801));
g_store_11(g_element(g_v2,0,253,0,8,143,0),g_v147);
g_t11 g_v148={0};
g_v148=g_float_literal(UINT64_C(380759057574562406));
g_store_11(g_element(g_v2,0,253,0,8,144,0),g_v148);
g_t11 g_v149={0};
g_v149=g_float_literal(UINT64_C(6994627935825020104));
g_store_11(g_element(g_v2,0,253,0,8,145,0),g_v149);
g_t11 g_v150={0};
g_v150=g_float_literal(UINT64_C(4094062030571013688));
g_store_11(g_element(g_v2,0,253,0,8,146,0),g_v150);
g_t11 g_v151={0};
g_v151=g_float_literal(UINT64_C(7866351395861616901));
g_store_11(g_element(g_v2,0,253,0,8,147,0),g_v151);
g_t11 g_v152={0};
g_v152=g_float_literal(UINT64_C(3048372481821419420));
g_store_11(g_element(g_v2,0,253,0,8,148,0),g_v152);
g_t11 g_v153={0};
g_v153=g_float_literal(UINT64_C(11011));
g_store_11(g_element(g_v2,0,253,0,8,149,0),g_v153);
g_t11 g_v154={0};
g_v154=g_float_literal(UINT64_C(3318557881388119007));
g_store_11(g_element(g_v2,0,253,0,8,150,0),g_v154);
g_t11 g_v155={0};
g_v155=g_float_literal(UINT64_C(8007315873423602926));
g_store_11(g_element(g_v2,0,253,0,8,151,0),g_v155);
g_t11 g_v156={0};
g_v156=g_float_literal(UINT64_C(2346910648940279069));
g_store_11(g_element(g_v2,0,253,0,8,152,0),g_v156);
g_t11 g_v157={0};
g_v157=INFINITY;
g_store_11(g_element(g_v2,0,253,0,8,153,0),g_v157);
g_t11 g_v158={0};
g_v158=g_float_literal(UINT64_C(4411422418202952447));
g_store_11(g_element(g_v2,0,253,0,8,154,0),g_v158);
g_t11 g_v159={0};
g_v159=g_float_literal(UINT64_C(4662970539281743872));
g_store_11(g_element(g_v2,0,253,0,8,155,0),g_v159);
g_t11 g_v160={0};
g_v160=g_float_literal(UINT64_C(4705605263446980980));
g_store_11(g_element(g_v2,0,253,0,8,156,0),g_v160);
g_t11 g_v161={0};
g_v161=g_float_literal(UINT64_C(7913225693655601122));
g_store_11(g_element(g_v2,0,253,0,8,157,0),g_v161);
g_t11 g_v162={0};
g_v162=g_float_literal(UINT64_C(3305498356104572280));
g_store_11(g_element(g_v2,0,253,0,8,158,0),g_v162);
g_t11 g_v163={0};
g_v163=g_float_literal(UINT64_C(768362503579167860));
g_store_11(g_element(g_v2,0,253,0,8,159,0),g_v163);
g_t11 g_v164={0};
g_v164=g_float_literal(UINT64_C(2735913399189683252));
g_store_11(g_element(g_v2,0,253,0,8,160,0),g_v164);
g_t11 g_v165={0};
g_v165=g_float_literal(UINT64_C(4898712057688252158));
g_store_11(g_element(g_v2,0,253,0,8,161,0),g_v165);
g_t11 g_v166={0};
g_v166=g_float_literal(UINT64_C(7590144066126395440));
g_store_11(g_element(g_v2,0,253,0,8,162,0),g_v166);
g_t11 g_v167={0};
g_v167=INFINITY;
g_store_11(g_element(g_v2,0,253,0,8,163,0),g_v167);
g_t11 g_v168={0};
g_v168=g_float_literal(UINT64_C(0));
g_store_11(g_element(g_v2,0,253,0,8,164,0),g_v168);
g_t11 g_v169={0};
g_v169=g_float_literal(UINT64_C(7760025229350305328));
g_store_11(g_element(g_v2,0,253,0,8,165,0),g_v169);
g_t11 g_v170={0};
g_v170=g_float_literal(UINT64_C(1340971458314030516));
g_store_11(g_element(g_v2,0,253,0,8,166,0),g_v170);
g_t11 g_v171={0};
g_v171=g_float_literal(UINT64_C(8003073000444108503));
g_store_11(g_element(g_v2,0,253,0,8,167,0),g_v171);
g_t11 g_v172={0};
g_v172=g_float_literal(UINT64_C(2465916312409311497));
g_store_11(g_element(g_v2,0,253,0,8,168,0),g_v172);
g_t11 g_v173={0};
g_v173=g_float_literal(UINT64_C(5098163337150112384));
g_store_11(g_element(g_v2,0,253,0,8,169,0),g_v173);
g_t11 g_v174={0};
g_v174=g_float_literal(UINT64_C(8702382227463086390));
g_store_11(g_element(g_v2,0,253,0,8,170,0),g_v174);
g_t11 g_v175={0};
g_v175=INFINITY;
g_store_11(g_element(g_v2,0,253,0,8,171,0),g_v175);
g_t11 g_v176={0};
g_v176=g_float_literal(UINT64_C(8305465940934365515));
g_store_11(g_element(g_v2,0,253,0,8,172,0),g_v176);
g_t11 g_v177={0};
g_v177=g_float_literal(UINT64_C(408512076688698090));
g_store_11(g_element(g_v2,0,253,0,8,173,0),g_v177);
g_t11 g_v178={0};
g_v178=g_float_literal(UINT64_C(3395377767575321658));
g_store_11(g_element(g_v2,0,253,0,8,174,0),g_v178);
g_t11 g_v179={0};
g_v179=g_float_literal(UINT64_C(6919473901575602176));
g_store_11(g_element(g_v2,0,253,0,8,175,0),g_v179);
g_t11 g_v180={0};
g_v180=g_float_literal(UINT64_C(2744914910704754278));
g_store_11(g_element(g_v2,0,253,0,8,176,0),g_v180);
g_t11 g_v181={0};
g_v181=g_float_literal(UINT64_C(1918957891365772673));
g_store_11(g_element(g_v2,0,253,0,8,177,0),g_v181);
g_t11 g_v182={0};
g_v182=g_float_literal(UINT64_C(4505394615764585105));
g_store_11(g_element(g_v2,0,253,0,8,178,0),g_v182);
g_t11 g_v183={0};
g_v183=INFINITY;
g_store_11(g_element(g_v2,0,253,0,8,179,0),g_v183);
g_t11 g_v184={0};
g_v184=g_float_literal(UINT64_C(3693071026391777846));
g_store_11(g_element(g_v2,0,253,0,8,180,0),g_v184);
g_t11 g_v185={0};
g_v185=g_float_literal(UINT64_C(2382288625526904302));
g_store_11(g_element(g_v2,0,253,0,8,181,0),g_v185);
g_t11 g_v186={0};
g_v186=INFINITY;
g_store_11(g_element(g_v2,0,253,0,8,182,0),g_v186);
g_t11 g_v187={0};
g_v187=g_float_literal(UINT64_C(2684353549086096032));
g_store_11(g_element(g_v2,0,253,0,8,183,0),g_v187);
g_t11 g_v188={0};
g_v188=g_float_literal(UINT64_C(4611002988287980272));
g_store_11(g_element(g_v2,0,253,0,8,184,0),g_v188);
g_t11 g_v189={0};
g_v189=g_float_literal(UINT64_C(9132328476024237544));
g_store_11(g_element(g_v2,0,253,0,8,185,0),g_v189);
g_t11 g_v190={0};
g_v190=g_float_literal(UINT64_C(4458673740631428986));
g_store_11(g_element(g_v2,0,253,0,8,186,0),g_v190);
g_t11 g_v191={0};
g_v191=g_float_literal(UINT64_C(9143406073232779941));
g_store_11(g_element(g_v2,0,253,0,8,187,0),g_v191);
g_t11 g_v192={0};
g_v192=g_float_literal(UINT64_C(242273594724319232));
g_store_11(g_element(g_v2,0,253,0,8,188,0),g_v192);
g_t11 g_v193={0};
g_v193=g_float_literal(UINT64_C(6420978857411692396));
g_store_11(g_element(g_v2,0,253,0,8,189,0),g_v193);
g_t11 g_v194={0};
g_v194=g_float_literal(UINT64_C(703154383489857638));
g_store_11(g_element(g_v2,0,253,0,8,190,0),g_v194);
g_t11 g_v195={0};
g_v195=g_float_literal(UINT64_C(248461188631740927));
g_store_11(g_element(g_v2,0,253,0,8,191,0),g_v195);
g_t11 g_v196={0};
g_v196=g_float_literal(UINT64_C(5653369180614445872));
g_store_11(g_element(g_v2,0,253,0,8,192,0),g_v196);
g_t11 g_v197={0};
g_v197=g_float_literal(UINT64_C(600634314272269532));
g_store_11(g_element(g_v2,0,253,0,8,193,0),g_v197);
g_t11 g_v198={0};
g_v198=g_float_literal(UINT64_C(7575661555180946175));
g_store_11(g_element(g_v2,0,253,0,8,194,0),g_v198);
g_t11 g_v199={0};
g_v199=g_float_literal(UINT64_C(8321994342363857116));
g_store_11(g_element(g_v2,0,253,0,8,195,0),g_v199);
g_t11 g_v200={0};
g_v200=g_float_literal(UINT64_C(7766131363224223744));
g_store_11(g_element(g_v2,0,253,0,8,196,0),g_v200);
g_t11 g_v201={0};
g_v201=INFINITY;
g_store_11(g_element(g_v2,0,253,0,8,197,0),g_v201);
g_t11 g_v202={0};
g_v202=g_float_literal(UINT64_C(4103390514035082624));
g_store_11(g_element(g_v2,0,253,0,8,198,0),g_v202);
g_t11 g_v203={0};
g_v203=INFINITY;
g_store_11(g_element(g_v2,0,253,0,8,199,0),g_v203);
g_t11 g_v204={0};
g_v204=g_float_literal(UINT64_C(3860202478430309903));
g_store_11(g_element(g_v2,0,253,0,8,200,0),g_v204);
g_t11 g_v205={0};
g_v205=g_float_literal(UINT64_C(2889538548027883520));
g_store_11(g_element(g_v2,0,253,0,8,201,0),g_v205);
g_t11 g_v206={0};
g_v206=g_float_literal(UINT64_C(9151303587084196859));
g_store_11(g_element(g_v2,0,253,0,8,202,0),g_v206);
g_t11 g_v207={0};
g_v207=g_float_literal(UINT64_C(8534863030365062573));
g_store_11(g_element(g_v2,0,253,0,8,203,0),g_v207);
g_t11 g_v208={0};
g_v208=g_float_literal(UINT64_C(5242700680347785902));
g_store_11(g_element(g_v2,0,253,0,8,204,0),g_v208);
g_t11 g_v209={0};
g_v209=g_float_literal(UINT64_C(576011018748085536));
g_store_11(g_element(g_v2,0,253,0,8,205,0),g_v209);
g_t11 g_v210={0};
g_v210=g_float_literal(UINT64_C(6177538776861001667));
g_store_11(g_element(g_v2,0,253,0,8,206,0),g_v210);
g_t11 g_v211={0};
g_v211=INFINITY;
g_store_11(g_element(g_v2,0,253,0,8,207,0),g_v211);
g_t11 g_v212={0};
g_v212=g_float_literal(UINT64_C(7033303249377823107));
g_store_11(g_element(g_v2,0,253,0,8,208,0),g_v212);
g_t11 g_v213={0};
g_v213=g_float_literal(UINT64_C(6809257711551471705));
g_store_11(g_element(g_v2,0,253,0,8,209,0),g_v213);
g_t11 g_v214={0};
g_v214=g_float_literal(UINT64_C(4163150896272445869));
g_store_11(g_element(g_v2,0,253,0,8,210,0),g_v214);
g_t11 g_v215={0};
g_v215=INFINITY;
g_store_11(g_element(g_v2,0,253,0,8,211,0),g_v215);
g_t11 g_v216={0};
g_v216=g_float_literal(UINT64_C(7962417407919589320));
g_store_11(g_element(g_v2,0,253,0,8,212,0),g_v216);
g_t11 g_v217={0};
g_v217=g_float_literal(UINT64_C(6923752416645656652));
g_store_11(g_element(g_v2,0,253,0,8,213,0),g_v217);
g_t11 g_v218={0};
g_v218=g_float_literal(UINT64_C(1869161274987213279));
g_store_11(g_element(g_v2,0,253,0,8,214,0),g_v218);
g_t11 g_v219={0};
g_v219=g_float_literal(UINT64_C(3893834669943357968));
g_store_11(g_element(g_v2,0,253,0,8,215,0),g_v219);
g_t11 g_v220={0};
g_v220=g_float_literal(UINT64_C(4421536623427791872));
g_store_11(g_element(g_v2,0,253,0,8,216,0),g_v220);
g_t11 g_v221={0};
g_v221=g_float_literal(UINT64_C(7272514540767620528));
g_store_11(g_element(g_v2,0,253,0,8,217,0),g_v221);
g_t11 g_v222={0};
g_v222=g_float_literal(UINT64_C(8387489868499786904));
g_store_11(g_element(g_v2,0,253,0,8,218,0),g_v222);
g_t11 g_v223={0};
g_v223=g_float_literal(UINT64_C(1425534601765756456));
g_store_11(g_element(g_v2,0,253,0,8,219,0),g_v223);
g_t11 g_v224={0};
g_v224=g_float_literal(UINT64_C(2620793004680653972));
g_store_11(g_element(g_v2,0,253,0,8,220,0),g_v224);
g_t11 g_v225={0};
g_v225=g_float_literal(UINT64_C(815555350900972800));
g_store_11(g_element(g_v2,0,253,0,8,221,0),g_v225);
g_t11 g_v226={0};
g_v226=g_float_literal(UINT64_C(565092666208109673));
g_store_11(g_element(g_v2,0,253,0,8,222,0),g_v226);
g_t11 g_v227={0};
g_v227=g_float_literal(UINT64_C(3934236314184464224));
g_store_11(g_element(g_v2,0,253,0,8,223,0),g_v227);
g_t11 g_v228={0};
g_v228=g_float_literal(UINT64_C(8236994398228840448));
g_store_11(g_element(g_v2,0,253,0,8,224,0),g_v228);
g_t11 g_v229={0};
g_v229=g_float_literal(UINT64_C(8285862896168524839));
g_store_11(g_element(g_v2,0,253,0,8,225,0),g_v229);
g_t11 g_v230={0};
g_v230=g_float_literal(UINT64_C(9098739186167145111));
g_store_11(g_element(g_v2,0,253,0,8,226,0),g_v230);
g_t11 g_v231={0};
g_v231=g_float_literal(UINT64_C(7068471196822713993));
g_store_11(g_element(g_v2,0,253,0,8,227,0),g_v231);
g_t11 g_v232={0};
g_v232=g_float_literal(UINT64_C(724308073281316631));
g_store_11(g_element(g_v2,0,253,0,8,228,0),g_v232);
g_t11 g_v233={0};
g_v233=g_float_literal(UINT64_C(7074960524134115504));
g_store_11(g_element(g_v2,0,253,0,8,229,0),g_v233);
g_t11 g_v234={0};
g_v234=g_float_literal(UINT64_C(8054362843218982748));
g_store_11(g_element(g_v2,0,253,0,8,230,0),g_v234);
g_t11 g_v235={0};
g_v235=g_float_literal(UINT64_C(2312623990125265146));
g_store_11(g_element(g_v2,0,253,0,8,231,0),g_v235);
g_t11 g_v236={0};
g_v236=g_float_literal(UINT64_C(6854505704394418093));
g_store_11(g_element(g_v2,0,253,0,8,232,0),g_v236);
g_t11 g_v237={0};
g_v237=g_float_literal(UINT64_C(5491682423128527479));
g_store_11(g_element(g_v2,0,253,0,8,233,0),g_v237);
g_t11 g_v238={0};
g_v238=g_float_literal(UINT64_C(9178451039066339920));
g_store_11(g_element(g_v2,0,253,0,8,234,0),g_v238);
g_t11 g_v239={0};
g_v239=g_float_literal(UINT64_C(8861152770797799072));
g_store_11(g_element(g_v2,0,253,0,8,235,0),g_v239);
g_t11 g_v240={0};
g_v240=g_float_literal(UINT64_C(4741308429329250780));
g_store_11(g_element(g_v2,0,253,0,8,236,0),g_v240);
g_t11 g_v241={0};
g_v241=g_float_literal(UINT64_C(3518576737094075538));
g_store_11(g_element(g_v2,0,253,0,8,237,0),g_v241);
g_t11 g_v242={0};
g_v242=g_float_literal(UINT64_C(4642560769718816256));
g_store_11(g_element(g_v2,0,253,0,8,238,0),g_v242);
g_t11 g_v243={0};
g_v243=g_float_literal(UINT64_C(8485657036201191164));
g_store_11(g_element(g_v2,0,253,0,8,239,0),g_v243);
g_t11 g_v244={0};
g_v244=g_float_literal(UINT64_C(7636651169242342538));
g_store_11(g_element(g_v2,0,253,0,8,240,0),g_v244);
g_t11 g_v245={0};
g_v245=g_float_literal(UINT64_C(490767937656584704));
g_store_11(g_element(g_v2,0,253,0,8,241,0),g_v245);
g_t11 g_v246={0};
g_v246=g_float_literal(UINT64_C(6435002848833248805));
g_store_11(g_element(g_v2,0,253,0,8,242,0),g_v246);
g_t11 g_v247={0};
g_v247=g_float_literal(UINT64_C(25168));
g_store_11(g_element(g_v2,0,253,0,8,243,0),g_v247);
g_t11 g_v248={0};
g_v248=g_float_literal(UINT64_C(5104332835968895915));
g_store_11(g_element(g_v2,0,253,0,8,244,0),g_v248);
g_t11 g_v249={0};
g_v249=g_float_literal(UINT64_C(1692590218657789531));
g_store_11(g_element(g_v2,0,253,0,8,245,0),g_v249);
g_t11 g_v250={0};
g_v250=g_float_literal(UINT64_C(555924117315381194));
g_store_11(g_element(g_v2,0,253,0,8,246,0),g_v250);
g_t11 g_v251={0};
g_v251=g_float_literal(UINT64_C(5184915663550732301));
g_store_11(g_element(g_v2,0,253,0,8,247,0),g_v251);
g_t11 g_v252={0};
g_v252=g_float_literal(UINT64_C(3907597070992231014));
g_store_11(g_element(g_v2,0,253,0,8,248,0),g_v252);
g_t11 g_v253={0};
g_v253=g_float_literal(UINT64_C(8578916203101017336));
g_store_11(g_element(g_v2,0,253,0,8,249,0),g_v253);
g_t11 g_v254={0};
g_v254=g_float_literal(UINT64_C(899982739033699021));
g_store_11(g_element(g_v2,0,253,0,8,250,0),g_v254);
g_t11 g_v255={0};
g_v255=g_float_literal(UINT64_C(1118324065305351282));
g_store_11(g_element(g_v2,0,253,0,8,251,0),g_v255);
g_t11 g_v256={0};
g_v256=g_float_literal(UINT64_C(5997225863878947499));
g_store_11(g_element(g_v2,0,253,0,8,252,0),g_v256);
g_t14 g_v257={0};
g_v257=g_clone_14(g_v1);
g_store_14(g_v0,g_v257);
GRef g_v259=0;
g_v259=g_ref(&g_s1);
g_t12 g_v260={0};
g_v260=g_view(g_v259,0,253,0,8);
g_v260.len*=8;
g_print_12(NULL,g_v260);
g_print_text(NULL,"\n");
}
g_return:g_return_top=g_frame.parent;
return;
}
static void g_initialize(void){if(g_initialized)return;g_initialized=1;
}
int main(int argc,char **argv){g_argc=argc;g_argv=argv;atexit(g_cleanup);g_initialize();g_fn2(NULL);return 0;}
