#define _GNU_SOURCE 1
#include <stdint.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <limits.h>
#include <setjmp.h>
#include <time.h>
#include <unistd.h>
#include <sys/stat.h>
#include <dirent.h>
#include <dlfcn.h>
#include <errno.h>
typedef struct GRefCell *GRef;
struct GRefCell { GRef parent; unsigned char *root; unsigned char *direct; int64_t offset; };
typedef struct { GRef base; int64_t len; } GSlice;
typedef struct { unsigned char *data; int64_t len, cap; } GArray;
typedef struct GClosure { void *function; int64_t count; GRef captures[]; } GClosure;
typedef struct GAllocation { struct GAllocation *next; void *data; } GAllocation;
static GAllocation *g_allocations;
static int g_argc; static char **g_argv;
static void g_panic(const char *s) { fprintf(stderr,"goose runtime error: %s\n",s); exit(1); }
static void *g_alloc(size_t n) {
    void *p=calloc(1,n+!n); if(!p) g_panic("out of memory");
    GAllocation *a=malloc(sizeof *a); if(!a) g_panic("out of memory");
    a->data=p; a->next=g_allocations; g_allocations=a; return p;
}
static void g_cleanup(void) { while(g_allocations) { GAllocation *a=g_allocations; g_allocations=a->next; free(a->data); free(a); } }
static GRef g_ref(void *p) { GRef r=g_alloc(sizeof *r); r->direct=p; return r; }
static unsigned char *g_address(GRef r) {
    if(!r) g_panic("null reference");
    unsigned char *base=r->direct;
    if(r->parent) base=g_address(r->parent);
    else if(r->root) memcpy(&base,r->root,sizeof base);
    if(!r->offset) return base;
    if(!base) g_panic("null reference");
    return base+r->offset;
}
static GRef g_offset(GRef p,int64_t n) { GRef r=g_alloc(sizeof *r); r->parent=p; r->offset=n; return r; }
static GRef g_moving(void *root,int64_t n) { GRef r=g_alloc(sizeof *r); r->root=root; r->offset=n; return r; }
static uint64_t g_read_length(const void *p,int n) { uint64_t v=0; memcpy(&v,p,n); return v; }
static void g_write_length(void *p,int n,uint64_t v) { memcpy(p,&v,n); }
static int64_t g_len(GRef r,int kind,int64_t fixed,int prefix) {
    if(kind==5) { GSlice s; memcpy(&s,g_address(r),sizeof s); return s.len; }
    if(kind==0) return fixed;
    if(kind==2 && fixed>=0) return (int64_t)g_read_length(g_address(r),prefix);
    GArray a; memcpy(&a,g_address(r),sizeof a); return a.len;
}
static int64_t g_cap(GRef r,int kind,int64_t fixed) {
    if(kind==2 && fixed>=0) return fixed;
    GArray a; memcpy(&a,g_address(r),sizeof a); return a.cap;
}
static GRef g_element(GRef r,int kind,int64_t fixed,int prefix,int64_t width,int64_t index,int allow_end) {
    int64_t len=g_len(r,kind,fixed,prefix);
    if(index<0 || index>len || (!allow_end && index==len)) g_panic("index out of bounds");
    if(width && index>INT64_MAX/width) g_panic("array offset overflow");
    if(kind==5) { GSlice s; memcpy(&s,g_address(r),sizeof s); return g_offset(s.base,index*width); }
    if(kind==0) return g_offset(r,index*width);
    if(kind==2 && fixed>=0) return g_offset(r,prefix+index*width);
    return g_moving(g_address(r),index*width);
}
static GSlice g_view(GRef r,int kind,int64_t fixed,int prefix,int64_t width) {
    GSlice s={g_element(r,kind,fixed,prefix,width,0,1),g_len(r,kind,fixed,prefix)}; return s;
}
static void g_reserve(GRef r,int kind,int64_t fixed,int prefix,int64_t width,int64_t count) {
    if(count<0 || (width && count>INT64_MAX/width)) g_panic("invalid capacity");
    if(kind==2 && fixed>=0) { if(count>fixed) g_panic("limited array capacity exceeded"); return; }
    if(kind!=3 && kind!=4 && kind!=2) g_panic("array cannot grow");
    GArray a; memcpy(&a,g_address(r),sizeof a);
    if(count>a.cap) {
        int64_t cap=a.cap*2+8; if(cap<count) cap=count;
        if(width && cap>INT64_MAX/width) g_panic("array capacity overflow");
        unsigned char *data=g_alloc((size_t)(cap*width));
        if(a.len) memcpy(data,a.data,(size_t)(a.len*width)); a.data=data; a.cap=cap;
        memcpy(g_address(r),&a,sizeof a);
    }
}
static void g_set_len(GRef r,int kind,int64_t fixed,int prefix,int64_t count) {
    if(kind==2 && fixed>=0) g_write_length(g_address(r),prefix,(uint64_t)count);
    else { GArray a; memcpy(&a,g_address(r),sizeof a); a.len=count; memcpy(g_address(r),&a,sizeof a); }
}
static GRef g_push(GRef r,int kind,int64_t fixed,int prefix,int64_t width,const void *v) {
    int64_t n=g_len(r,kind,fixed,prefix); g_reserve(r,kind,fixed,prefix,width,n+1);
    g_set_len(r,kind,fixed,prefix,n+1); GRef dst=g_element(r,kind,fixed,prefix,width,n,0);
    memcpy(g_address(dst),v,(size_t)width); return dst;
}
static void g_bytes(GArray *out,const void *p,int64_t n) {
    if(n<=0) return; GRef r=g_ref(out); g_reserve(r,3,-1,0,1,out->len+n);
    memmove(out->data+out->len,p,(size_t)n); out->len+=n;
}
static GClosure *g_closure(void *function,int64_t n) { GClosure *c=g_alloc(sizeof *c+(size_t)n*sizeof(GRef)); c->function=function; c->count=n; return c; }
typedef struct GReturnFrame { struct GReturnFrame *parent; int64_t function; jmp_buf jump; void *result; size_t size; } GReturnFrame;
static _Thread_local GReturnFrame *g_return_top;
static void g_throw(int64_t function,const void *value,size_t size) {
    GReturnFrame *f=g_return_top;
    while(f && f->function!=function) f=f->parent;
    if(!f || f->size!=size) g_panic("nonlocal return target is not active");
    if(size) memcpy(f->result,value,size); g_return_top=f; longjmp(f->jump,1);
}
static int64_t g_div(int64_t a,int64_t b) { if(!b) g_panic("division by zero"); if(a==INT64_MIN && b==-1) g_panic("signed integer overflow"); return a/b; }
static int64_t g_mod(int64_t a,int64_t b) { if(!b) g_panic("division by zero"); if(a==INT64_MIN && b==-1) return 0; int64_t r=a%b; if(r<0) { uint64_t magnitude=(uint64_t)b; if(b<0) magnitude=0-magnitude; return (int64_t)((uint64_t)r+magnitude); } return r; }
static uint64_t g_udiv(uint64_t a,uint64_t b) { if(!b) g_panic("division by zero"); return a/b; }
static uint64_t g_umod(uint64_t a,uint64_t b) { if(!b) g_panic("division by zero"); return a%b; }
static uint64_t g_float_wrap(double a) { if(!isfinite(a)) g_panic("float conversion is not finite"); a=fmod(trunc(a),18446744073709551616.0); if(a<0) a+=18446744073709551616.0; if(a>=9223372036854775808.0) return ((uint64_t)(a-9223372036854775808.0))+(UINT64_C(1)<<63); return (uint64_t)a; }
static void g_print_bytes(GArray *out,const void *p,int64_t n) { if(out) g_bytes(out,p,n); else if(n) fwrite(p,1,(size_t)n,stdout); }
static void g_print_text(GArray *out,const char *s) { g_print_bytes(out,s,(int64_t)strlen(s)); }
static char *g_path(GSlice p) { if(p.len<0 || p.len>=4096) return NULL; char *s=g_alloc((size_t)p.len+1); if(p.len) memcpy(s,g_address(p.base),(size_t)p.len); if(memchr(s,0,(size_t)p.len)) return NULL; return s; }
static int g_os_read_file(GSlice path,GRef out) { char *s=g_path(path); if(!s) return 0; FILE *f=fopen(s,"rb"); if(!f) return 0; GArray a; memcpy(&a,g_address(out),sizeof a); unsigned char b[16384]; size_t n; while((n=fread(b,1,sizeof b,f))) g_bytes(&a,b,(int64_t)n); int ok=!ferror(f); fclose(f); memcpy(g_address(out),&a,sizeof a); return ok; }
static int g_os_write_file(GSlice path,GSlice data,const char *mode) { char *s=g_path(path); if(!s) return 0; FILE *f=fopen(s,mode); if(!f) return 0; int ok=fwrite(g_address(data.base),1,(size_t)data.len,f)==(size_t)data.len; return fclose(f)==0 && ok; }
static int g_os_write_atomic(GSlice path,GSlice data) { char *s=g_path(path); if(!s) return 0; size_t n=strlen(s); char *tmp=g_alloc(n+16); memcpy(tmp,s,n); memcpy(tmp+n,".tmp-XXXXXX",12); int fd=mkstemp(tmp); if(fd<0) return 0; FILE *f=fdopen(fd,"wb"); if(!f) { close(fd); unlink(tmp); return 0; } int ok=fwrite(g_address(data.base),1,(size_t)data.len,f)==(size_t)data.len; if(fflush(f)||fsync(fd)) ok=0; if(fclose(f)) ok=0; if(ok && rename(tmp,s)) ok=0; if(!ok) unlink(tmp); return ok; }
static int g_os_kind(GSlice path) { char *s=g_path(path); struct stat st; if(!s || stat(s,&st)) return 0; if(S_ISDIR(st.st_mode)) return 2; return 1; }
static int g_os_line(GRef out) { GArray a; memcpy(&a,g_address(out),sizeof a); int c; int any=0; while((c=fgetc(stdin))!=EOF) { any=1; if(c==10) break; unsigned char b=(unsigned char)c; g_bytes(&a,&b,1); } if(a.len && a.data[a.len-1]==13) a.len--; memcpy(g_address(out),&a,sizeof a); return any; }
static void g_os_stdin(GRef out) { GArray a; memcpy(&a,g_address(out),sizeof a); unsigned char b[16384]; size_t n; while((n=fread(b,1,sizeof b,stdin))) g_bytes(&a,b,(int64_t)n); memcpy(g_address(out),&a,sizeof a); }
static void g_os_arg(int64_t i,GRef out) { if(i<0 || i>=g_argc) return; GArray a; memcpy(&a,g_address(out),sizeof a); g_bytes(&a,g_argv[i],(int64_t)strlen(g_argv[i])); memcpy(g_address(out),&a,sizeof a); }
static int g_os_env(GSlice name,GRef out) { char *n=g_path(name); const char *v=NULL; if(n) v=getenv(n); if(!v) return 0; GArray a; memcpy(&a,g_address(out),sizeof a); g_bytes(&a,v,(int64_t)strlen(v)); memcpy(g_address(out),&a,sizeof a); return 1; }
static int64_t g_os_time(int monotonic) { struct timespec t; clockid_t c=CLOCK_REALTIME; if(monotonic) c=CLOCK_MONOTONIC; if(clock_gettime(c,&t)) return 0; return (int64_t)t.tv_sec*1000000000+t.tv_nsec; }
static void g_os_sleep(int64_t ms) { if(ms<0) return; struct timespec t={ms/1000,(ms%1000)*1000000}; while(nanosleep(&t,&t) && errno==EINTR) {} }
static uint64_t g_os_random(void) { uint64_t n=0; FILE *f=fopen("/dev/urandom","rb"); if(f) { if(fread(&n,1,sizeof n,f)!=sizeof n) n=0; fclose(f); } if(!n) n=(uint64_t)g_os_time(0)^(uint64_t)(uintptr_t)&n; n^=n>>30; n*=UINT64_C(0xbf58476d1ce4e5b9); n^=n>>27; n*=UINT64_C(0x94d049bb133111eb); return n^(n>>31); }
static int g_sort_names(const void *a,const void *b) { return strcmp(*(const char *const *)a,*(const char *const *)b); }
static int g_os_list(GSlice path,GRef out) { char *s=g_path(path); if(!s) return 0; DIR *d=opendir(s); if(!d) return 0; char **names=NULL; size_t n=0,cap=0; struct dirent *e; while((e=readdir(d))) { if(!strcmp(e->d_name,".") || !strcmp(e->d_name,"..")) continue; if(n==cap) { cap=cap*2+16; names=realloc(names,cap*sizeof *names); if(!names) g_panic("out of memory"); } names[n]=strdup(e->d_name); n++; } closedir(d); qsort(names,n,sizeof *names,g_sort_names); GArray a; memcpy(&a,g_address(out),sizeof a); for(size_t i=0;i<n;i++) { g_bytes(&a,names[i],(int64_t)strlen(names[i])); g_bytes(&a,"\n",1); free(names[i]); } free(names); memcpy(g_address(out),&a,sizeof a); return 1; }

#define GS_CHECKED_STACKS 0
static void g_format_bounds(void *p,uint64_t n) { (void)p; (void)n; }
static const char gs_digit_pairs[201] =
    "00010203040506070809101112131415161718192021222324252627282930313233343536373839"
    "40414243444546474849505152535455565758596061626364656667686970717273747576777879"
    "8081828384858687888990919293949596979899";

static int gs_fmt_digits(uint64_t v) {
    int n = 1;
    for (;;) {
        if (v < 10) return n;
        if (v < 100) return n + 1;
        if (v < 1000) return n + 2;
        if (v < 10000) return n + 3;
        v /= 10000;
        n += 4;
    }
}

static int64_t gs_fmt_u64(uint8_t *dst, uint64_t v) {
    int n = gs_fmt_digits(v);

    uint8_t *p = dst + n;
    while (v >= 100) {
        unsigned r = (unsigned)(v % 100);
        v /= 100;
        p -= 2;
        p[0] = (uint8_t)gs_digit_pairs[2 * r];
        p[1] = (uint8_t)gs_digit_pairs[2 * r + 1];
    }
    if (v >= 10) {
        p[-2] = (uint8_t)gs_digit_pairs[2 * v];
        p[-1] = (uint8_t)gs_digit_pairs[2 * v + 1];
    } else {
        p[-1] = (uint8_t)('0' + v);
    }
    return n;
}

static int64_t gs_fmt_i64(uint8_t *dst, int64_t v) {
    if (v >= 0) return gs_fmt_u64(dst, (uint64_t)v);
    /* The magnitude in unsigned arithmetic, so i64.min needs no case. */

    dst[0] = '-';
    return 1 + gs_fmt_u64(dst + 1, 0 - (uint64_t)v);
}

/* A float's text is the fewest significant digits that read back as the
   same value of its own type and, of those, the ones nearest it, a tie going
   to the even digit (as Python's repr and Ryu choose). They are found in
   integers, by Burger and Dybvig's free-format algorithm, not through the C
   library: msvcrt, which tcc uses on Windows, rounds a printf tie away from
   zero, and below a power of two the gap to the next float is half the gap
   above, so the shortest text can lie above the value while the correctly
   rounded spelling of that length, below it, does not read back.

   The numbers are naturals in 32-bit limbs, least significant first. The
   denominator s stays below 2^1079 (ten times 2^1075, for the smallest
   doubles), and the others below eleven times s. */
typedef struct { int n; uint32_t d[36]; } gs_big;

/* a = v << sh, for v > 0. */
static void gs_big_set(gs_big *a, uint64_t v, int sh) {
    int w = sh >> 5, b = sh & 31, i;
    uint64_t lo = v << b, hi = b ? v >> (64 - b) : 0;
    for (i = 0; i < w; i++) a->d[i] = 0;
    a->d[w] = (uint32_t)lo;
    a->d[w + 1] = (uint32_t)(lo >> 32);
    a->d[w + 2] = (uint32_t)hi;
    a->n = w + 3;
    while (!a->d[a->n - 1]) a->n--;
}

static void gs_big_mul(gs_big *a, uint32_t m) {
    uint64_t c = 0;
    for (int i = 0; i < a->n; i++) {
        c += (uint64_t)a->d[i] * m;
        a->d[i] = (uint32_t)c;
        c >>= 32;
    }
    if (c) a->d[a->n++] = (uint32_t)c;
}

static void gs_big_mul_pow10(gs_big *a, int k) {
    for (; k >= 9; k -= 9) gs_big_mul(a, 1000000000u);
    for (; k > 0; k--) gs_big_mul(a, 10);
}

static int gs_big_cmp(const gs_big *a, const gs_big *b) {
    if (a->n != b->n) return a->n < b->n ? -1 : 1;
    for (int i = a->n - 1; i >= 0; i--)
        if (a->d[i] != b->d[i]) return a->d[i] < b->d[i] ? -1 : 1;
    return 0;
}

/* t = a + b */
static void gs_big_add(gs_big *t, const gs_big *a, const gs_big *b) {
    int n = a->n > b->n ? a->n : b->n;
    uint64_t c = 0;
    for (int i = 0; i < n; i++) {
        c += (uint64_t)(i < a->n ? a->d[i] : 0) + (i < b->n ? b->d[i] : 0);
        t->d[i] = (uint32_t)c;
        c >>= 32;
    }
    t->n = n;
    if (c) t->d[t->n++] = (uint32_t)c;
}

/* a -= b, for a >= b. */
static void gs_big_sub(gs_big *a, const gs_big *b) {
    uint64_t borrow = 0;
    for (int i = 0; i < a->n; i++) {
        uint64_t x = (uint64_t)a->d[i] - (i < b->n ? b->d[i] : 0) - borrow;
        a->d[i] = (uint32_t)x;
        borrow = x >> 63;
    }
    while (a->n && !a->d[a->n - 1]) a->n--;
}

/* The shortest digits of f * 2^e (f > 0) as a float of `bits` significant
   bits and least exponent emin, into dig; returns their count and sets *k
   so that the value they spell is 0.d1d2... * 10^*k. */
static int gs_float_digits(uint64_t f, int e, int bits, int emin, char *dig, int *k) {
    gs_big r, s, mp, mlo, t;
    /* Reading rounds a tie to the even significand, so the interval that
       reads back as f * 2^e includes its ends when f is even. */
    int even = !(f & 1);
    /* Below a power of two, the gap to the next float down is half the gap up. */
    int asym = f == (uint64_t)1 << (bits - 1) && e > emin;
    int up = e > 0 ? e : 0, lg = e - 1, n = 0, c;
    /* The value is r / s, and what reads back as it reaches from (r - *mm) / s
       to (r + mp) / s: half the gap to each neighbour. */
    gs_big *mm = asym ? &mlo : &mp;
    gs_big_set(&r, f, up + 1 + asym);
    gs_big_set(&s, 1, up - e + 1 + asym);
    gs_big_set(&mp, 1, up + asym);
    gs_big_set(&mlo, 1, up);
    /* Scale to 10^*k, the least power of ten above the interval: with
       lg = floor(log2 value), ceil(lg log10 2) is it or one short, and
       78913 / 2^18 is log10 2 closely enough to compute that for |lg| < 1650. */
    for (uint64_t g = f; g; g >>= 1) lg++;
    *k = lg > 0 ? ((lg * 78913) >> 18) + 1 : -((-lg * 78913) >> 18);
    if (*k >= 0) gs_big_mul_pow10(&s, *k);
    else {
        gs_big_mul_pow10(&r, -*k);
        gs_big_mul_pow10(&mp, -*k);
        if (asym) gs_big_mul_pow10(&mlo, -*k);
    }
    gs_big_add(&t, &r, &mp);
    c = gs_big_cmp(&t, &s);
    if (even ? c >= 0 : c > 0) {
        gs_big_mul(&s, 10);
        ++*k;
    }
    /* Each digit d leaves the remainder r: stop where the digits so far
       followed by d (r within *mm) or by d + 1 (r + mp past s) read back. */
    for (;;) {
        int d = 0, low, high;
        gs_big_mul(&r, 10);
        gs_big_mul(&mp, 10);
        if (asym) gs_big_mul(&mlo, 10);
        while (gs_big_cmp(&r, &s) >= 0) {
            gs_big_sub(&r, &s);
            d++;
        }
        c = gs_big_cmp(&r, mm);
        low = even ? c <= 0 : c < 0;
        gs_big_add(&t, &r, &mp);
        c = gs_big_cmp(&t, &s);
        high = even ? c >= 0 : c > 0;
        if (!low && !high) {
            dig[n++] = (char)('0' + d);
            continue;
        }
        if (low && high) {
            /* Both read back: the nearer, d + 1 when r is past half of s,
               and of two as near, the even one. */
            gs_big_add(&t, &r, &r);
            c = gs_big_cmp(&t, &s);
            high = c > 0 || (c == 0 && (d & 1));
        }
        dig[n++] = (char)('0' + d + high);
        return n;
    }
}

/* The text of a finite float from its fields: the sign, the significand
   without its implicit bit and the biased exponent, for a type of `bits`
   significant bits and least exponent emin. The digits are laid out as C's
   %g lays them out at a precision of max(15, digits): in exponent form, with
   at least two exponent digits, below 1e-4 or from that power of ten up. */
static int64_t gs_fmt_float_unchecked(uint8_t *dst, int neg, uint64_t frac, int bexp, int bits,
                            int emin) {
    char dig[20], *p = (char *)dst;
    int k, n, x, i;
    if (neg) *p++ = '-';
    if (!frac && !bexp) {
        memcpy(p, "0.0", 3);
        return p + 3 - (char *)dst;
    }
    n = gs_float_digits(bexp ? frac | (uint64_t)1 << (bits - 1) : frac,
                        (bexp ? bexp - 1 : 0) + emin, bits, emin, dig, &k);
    x = k - 1;
    if (x < -4 || x >= (n > 15 ? n : 15)) {
        *p++ = dig[0];
        if (n > 1) *p++ = '.';
        for (i = 1; i < n; i++) *p++ = dig[i];
        *p++ = 'e';
        *p++ = x < 0 ? '-' : '+';
        if (x < 0) x = -x;
        if (x >= 100) *p++ = (char)('0' + x / 100);
        *p++ = (char)('0' + x / 10 % 10);
        *p++ = (char)('0' + x % 10);
    } else if (x < 0) {
        *p++ = '0';
        *p++ = '.';
        for (i = -1; i > x; i--) *p++ = '0';
        for (i = 0; i < n; i++) *p++ = dig[i];
    } else {
        for (i = 0; i < n || i <= x; i++) {
            if (i == x + 1) *p++ = '.';
            *p++ = i < n ? dig[i] : '0';
        }
        /* A whole number still reads as a float: 1.0, not 1. */
        if (n <= x + 1) {
            *p++ = '.';
            *p++ = '0';
        }
    }
    return p - (char *)dst;
}

static int64_t gs_fmt_float(uint8_t *dst, int neg, uint64_t frac, int bexp, int bits,
                            int emin) {
#if GS_CHECKED_STACKS
    /* Determine the exact length before touching a data stack. The longest
       f64 spelling fits in 32 bytes, including sign and three exponent digits. */
    uint8_t text[32];
    int64_t n = gs_fmt_float_unchecked(text, neg, frac, bexp, bits, emin);

    memcpy(dst, text, (size_t)n);
    return n;
#else
    return gs_fmt_float_unchecked(dst, neg, frac, bexp, bits, emin);
#endif
}

static int64_t gs_fmt_f64(uint8_t *dst, double v) {
    uint64_t b;
    /* C libraries disagree here (msvcrt, which tcc uses on Windows, writes
       1.#INF and -1.#IND; others give a NaN's sign bit, which depends on
       the CPU that made it), so these are spelled by the runtime. */
    if (v != v) { g_format_bounds(dst, 3); memcpy(dst, "nan", 3); return 3; }
    if (isinf(v)) {
        if (v > 0) { g_format_bounds(dst, 3); memcpy(dst, "inf", 3); return 3; }
        g_format_bounds(dst, 4);
        memcpy(dst, "-inf", 4);
        return 4;
    }
    memcpy(&b, &v, sizeof b);
    return gs_fmt_float(dst, (int)(b >> 63), b & (((uint64_t)1 << 52) - 1),
                        (int)(b >> 52) & 0x7FF, 53, -1074);
}

/* The digits are the f32's own, laid out as an f64's are, so 0.1 as an f32
   prints as 0.1, not as the digits of the f64 it widens to. */
static int64_t gs_fmt_f32(uint8_t *dst, float v) {
    double d = v;
    uint32_t b;
    if (d != d || isinf(d)) return gs_fmt_f64(dst, d);
    memcpy(&b, &v, sizeof b);
    return gs_fmt_float(dst, (int)(b >> 31), b & 0x7FFFFF, (int)(b >> 23) & 0xFF, 24, -149);
}

static int64_t gs_fmt_bool(uint8_t *dst, int64_t v) {

    memcpy(dst, v ? "true" : "false", v ? 4 : 5);
    return v ? 4 : 5;
}

static int64_t gs_fmt_quoted(uint8_t *dst, const uint8_t *s, int64_t n) {
#if GS_CHECKED_STACKS
    uint64_t size = 2;
    for (int64_t i = 0; i < n; i++) {
        uint8_t c = s[i];
        uint64_t part = 1;
        if (c == '"' || c == '\\' || c == '\n' || c == '\r' || c == '\t') part++;
        if (size > UINT64_MAX - part) gs_panic("data stack overflow: quoted text size");
        size += part;
    }
    g_format_bounds(dst, size);
#endif
    uint8_t *d = dst;
    *d++ = '"';
    for (int64_t i = 0; i < n; i++) {
        uint8_t c = s[i];
        switch (c) {
            case '"': *d++ = '\\'; *d++ = '"'; break;
            case '\\': *d++ = '\\'; *d++ = '\\'; break;
            case '\n': *d++ = '\\'; *d++ = 'n'; break;
            case '\r': *d++ = '\\'; *d++ = 'r'; break;
            case '\t': *d++ = '\\'; *d++ = 't'; break;
            default: *d++ = c; break;
        }
    }
    *d++ = '"';
    return (int64_t)(d - dst);
}
static unsigned char *g_nullable_address(GRef r) { if(!r)return NULL;return g_address(r); }
static double g_float_literal(uint64_t bits) { double v; memcpy(&v,&bits,sizeof v); return v; }
static int64_t g_clz(uint64_t x) { if(!x) return 64; return __builtin_clzll(x); }
static int64_t g_ctz(uint64_t x) { if(!x) return 64; return __builtin_ctzll(x); }
static int g_os_path_op(GSlice path,int op) { char *s=g_path(path); if(!s) return 0; if(op==0) return unlink(s)==0; if(op==1) return rmdir(s)==0; if(mkdir(s,0777)==0) return 1; return errno==EEXIST && g_os_kind(path)==2; }
static int g_os_rename(GSlice from,GSlice to) { char *a=g_path(from),*b=g_path(to); if(!a || !b) return 0; return rename(a,b)==0; }
static int g_os_resource(GRef out) { char path[4096]; ssize_t n=readlink("/proc/self/exe",path,sizeof path); if(n<=0 || n==(ssize_t)sizeof path) return 0; while(n>0 && path[n-1]!='/') n--; if(!n) return 0; GArray a; memcpy(&a,g_address(out),sizeof a); g_bytes(&a,path,n); memcpy(g_address(out),&a,sizeof a); return 1; }
static int g_trim_memory(void) { void *p=dlsym(RTLD_DEFAULT,"malloc_trim"); if(!p) return 0; return ((int (*)(size_t))p)(0); }
typedef struct { void *data; int64_t len; } GForeignSlice;
static GForeignSlice g_foreign_slice(GSlice s) { GForeignSlice r={g_address(s.base),s.len}; return r; }
static void *g_external(const char *library,const char *name) { void *handle=RTLD_DEFAULT; if(library) { handle=dlopen(library,RTLD_NOW|RTLD_LOCAL); if(!handle) g_panic(dlerror()); } void *p=dlsym(handle,name); if(!p) g_panic(dlerror()); return p; }static void g_initialize(void); static int g_initialized;
typedef void g_t0;
typedef uint8_t g_t1;
typedef int8_t g_t2;
typedef int16_t g_t3;
typedef int32_t g_t4;
typedef int64_t g_t5;
typedef uint8_t g_t6;
typedef uint16_t g_t7;
typedef uint32_t g_t8;
typedef uint64_t g_t9;
typedef float g_t10;
typedef double g_t11;
typedef GSlice g_t12;
typedef GClosure* g_t13;
typedef GClosure* g_t14;
typedef GClosure* g_t15;
typedef GClosure* g_t16;
static g_t1 g_clone_1(g_t1 v);
static int g_equal_1(g_t1 a,g_t1 b);
static void g_print_1(GArray *out,g_t1 v);
static void g_nested_1(GArray *out,g_t1 v);
static g_t1 g_load_1(GRef p) {g_t1 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_1(GRef p,g_t1 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t2 g_clone_2(g_t2 v);
static int g_equal_2(g_t2 a,g_t2 b);
static void g_print_2(GArray *out,g_t2 v);
static void g_nested_2(GArray *out,g_t2 v);
static g_t2 g_load_2(GRef p) {g_t2 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_2(GRef p,g_t2 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t3 g_clone_3(g_t3 v);
static int g_equal_3(g_t3 a,g_t3 b);
static void g_print_3(GArray *out,g_t3 v);
static void g_nested_3(GArray *out,g_t3 v);
static g_t3 g_load_3(GRef p) {g_t3 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_3(GRef p,g_t3 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t4 g_clone_4(g_t4 v);
static int g_equal_4(g_t4 a,g_t4 b);
static void g_print_4(GArray *out,g_t4 v);
static void g_nested_4(GArray *out,g_t4 v);
static g_t4 g_load_4(GRef p) {g_t4 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_4(GRef p,g_t4 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t5 g_clone_5(g_t5 v);
static int g_equal_5(g_t5 a,g_t5 b);
static void g_print_5(GArray *out,g_t5 v);
static void g_nested_5(GArray *out,g_t5 v);
static g_t5 g_load_5(GRef p) {g_t5 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_5(GRef p,g_t5 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t6 g_clone_6(g_t6 v);
static int g_equal_6(g_t6 a,g_t6 b);
static void g_print_6(GArray *out,g_t6 v);
static void g_nested_6(GArray *out,g_t6 v);
static g_t6 g_load_6(GRef p) {g_t6 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_6(GRef p,g_t6 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t7 g_clone_7(g_t7 v);
static int g_equal_7(g_t7 a,g_t7 b);
static void g_print_7(GArray *out,g_t7 v);
static void g_nested_7(GArray *out,g_t7 v);
static g_t7 g_load_7(GRef p) {g_t7 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_7(GRef p,g_t7 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t8 g_clone_8(g_t8 v);
static int g_equal_8(g_t8 a,g_t8 b);
static void g_print_8(GArray *out,g_t8 v);
static void g_nested_8(GArray *out,g_t8 v);
static g_t8 g_load_8(GRef p) {g_t8 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_8(GRef p,g_t8 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t9 g_clone_9(g_t9 v);
static int g_equal_9(g_t9 a,g_t9 b);
static void g_print_9(GArray *out,g_t9 v);
static void g_nested_9(GArray *out,g_t9 v);
static g_t9 g_load_9(GRef p) {g_t9 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_9(GRef p,g_t9 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t10 g_clone_10(g_t10 v);
static int g_equal_10(g_t10 a,g_t10 b);
static void g_print_10(GArray *out,g_t10 v);
static void g_nested_10(GArray *out,g_t10 v);
static g_t10 g_load_10(GRef p) {g_t10 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_10(GRef p,g_t10 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t11 g_clone_11(g_t11 v);
static int g_equal_11(g_t11 a,g_t11 b);
static void g_print_11(GArray *out,g_t11 v);
static void g_nested_11(GArray *out,g_t11 v);
static g_t11 g_load_11(GRef p) {g_t11 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_11(GRef p,g_t11 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t12 g_clone_12(g_t12 v);
static int g_equal_12(g_t12 a,g_t12 b);
static void g_print_12(GArray *out,g_t12 v);
static void g_nested_12(GArray *out,g_t12 v);
static g_t12 g_load_12(GRef p) {g_t12 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_12(GRef p,g_t12 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t13 g_clone_13(g_t13 v);
static int g_equal_13(g_t13 a,g_t13 b);
static void g_print_13(GArray *out,g_t13 v);
static void g_nested_13(GArray *out,g_t13 v);
static g_t13 g_load_13(GRef p) {g_t13 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_13(GRef p,g_t13 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t14 g_clone_14(g_t14 v);
static int g_equal_14(g_t14 a,g_t14 b);
static void g_print_14(GArray *out,g_t14 v);
static void g_nested_14(GArray *out,g_t14 v);
static g_t14 g_load_14(GRef p) {g_t14 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_14(GRef p,g_t14 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t15 g_clone_15(g_t15 v);
static int g_equal_15(g_t15 a,g_t15 b);
static void g_print_15(GArray *out,g_t15 v);
static void g_nested_15(GArray *out,g_t15 v);
static g_t15 g_load_15(GRef p) {g_t15 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_15(GRef p,g_t15 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t16 g_clone_16(g_t16 v);
static int g_equal_16(g_t16 a,g_t16 b);
static void g_print_16(GArray *out,g_t16 v);
static void g_nested_16(GArray *out,g_t16 v);
static g_t16 g_load_16(GRef p) {g_t16 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_16(GRef p,g_t16 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t1 g_clone_1(g_t1 v) {
return v;}
static int g_equal_1(g_t1 a,g_t1 b){
return a==b;
}
static void g_print_1(GArray *out,g_t1 v) {
unsigned char b[128]; int64_t n=gs_fmt_bool(b,v);g_print_bytes(out,b,n);
}
static void g_nested_1(GArray *out,g_t1 v){
g_print_1(out,v);
}
static g_t2 g_clone_2(g_t2 v) {
return v;}
static int g_equal_2(g_t2 a,g_t2 b){
return a==b;
}
static void g_print_2(GArray *out,g_t2 v) {
unsigned char b[128]; int64_t n=gs_fmt_i64(b,v);g_print_bytes(out,b,n);
}
static void g_nested_2(GArray *out,g_t2 v){
g_print_2(out,v);
}
static g_t3 g_clone_3(g_t3 v) {
return v;}
static int g_equal_3(g_t3 a,g_t3 b){
return a==b;
}
static void g_print_3(GArray *out,g_t3 v) {
unsigned char b[128]; int64_t n=gs_fmt_i64(b,v);g_print_bytes(out,b,n);
}
static void g_nested_3(GArray *out,g_t3 v){
g_print_3(out,v);
}
static g_t4 g_clone_4(g_t4 v) {
return v;}
static int g_equal_4(g_t4 a,g_t4 b){
return a==b;
}
static void g_print_4(GArray *out,g_t4 v) {
unsigned char b[128]; int64_t n=gs_fmt_i64(b,v);g_print_bytes(out,b,n);
}
static void g_nested_4(GArray *out,g_t4 v){
g_print_4(out,v);
}
static g_t5 g_clone_5(g_t5 v) {
return v;}
static int g_equal_5(g_t5 a,g_t5 b){
return a==b;
}
static void g_print_5(GArray *out,g_t5 v) {
unsigned char b[128]; int64_t n=gs_fmt_i64(b,v);g_print_bytes(out,b,n);
}
static void g_nested_5(GArray *out,g_t5 v){
g_print_5(out,v);
}
static g_t6 g_clone_6(g_t6 v) {
return v;}
static int g_equal_6(g_t6 a,g_t6 b){
return a==b;
}
static void g_print_6(GArray *out,g_t6 v) {
unsigned char b[128]; int64_t n=gs_fmt_u64(b,v);g_print_bytes(out,b,n);
}
static void g_nested_6(GArray *out,g_t6 v){
g_print_6(out,v);
}
static g_t7 g_clone_7(g_t7 v) {
return v;}
static int g_equal_7(g_t7 a,g_t7 b){
return a==b;
}
static void g_print_7(GArray *out,g_t7 v) {
unsigned char b[128]; int64_t n=gs_fmt_u64(b,v);g_print_bytes(out,b,n);
}
static void g_nested_7(GArray *out,g_t7 v){
g_print_7(out,v);
}
static g_t8 g_clone_8(g_t8 v) {
return v;}
static int g_equal_8(g_t8 a,g_t8 b){
return a==b;
}
static void g_print_8(GArray *out,g_t8 v) {
unsigned char b[128]; int64_t n=gs_fmt_u64(b,v);g_print_bytes(out,b,n);
}
static void g_nested_8(GArray *out,g_t8 v){
g_print_8(out,v);
}
static g_t9 g_clone_9(g_t9 v) {
return v;}
static int g_equal_9(g_t9 a,g_t9 b){
return a==b;
}
static void g_print_9(GArray *out,g_t9 v) {
unsigned char b[128]; int64_t n=gs_fmt_u64(b,v);g_print_bytes(out,b,n);
}
static void g_nested_9(GArray *out,g_t9 v){
g_print_9(out,v);
}
static g_t10 g_clone_10(g_t10 v) {
return v;}
static int g_equal_10(g_t10 a,g_t10 b){
return a==b;
}
static void g_print_10(GArray *out,g_t10 v) {
unsigned char b[128]; int64_t n=gs_fmt_f32(b,v);g_print_bytes(out,b,n);
}
static void g_nested_10(GArray *out,g_t10 v){
g_print_10(out,v);
}
static g_t11 g_clone_11(g_t11 v) {
return v;}
static int g_equal_11(g_t11 a,g_t11 b){
return a==b;
}
static void g_print_11(GArray *out,g_t11 v) {
unsigned char b[128]; int64_t n=gs_fmt_f64(b,v);g_print_bytes(out,b,n);
}
static void g_nested_11(GArray *out,g_t11 v){
g_print_11(out,v);
}
static g_t12 g_clone_12(g_t12 v) {
return v;}
static int g_equal_12(g_t12 a,g_t12 b){
GRef ar=g_ref(&a),br=g_ref(&b);int64_t n=g_len(ar,5,-1,0);if(n!=g_len(br,5,-1,0))return 0;
for(int64_t i=0;i<n;i++){if(!g_equal_6(g_load_6(g_element(ar,5,-1,0,1,i,0)),g_load_6(g_element(br,5,-1,0,1,i,0))))return 0;}return 1;
}
static void g_print_12(GArray *out,g_t12 v) {
GRef r=g_ref(&v); int64_t n=g_len(r,5,-1,0);
for(int64_t i=0;i<n;i++) {
g_print_bytes(out,g_address(g_element(r,5,-1,0,1,i,0)),1);
}
}
static void g_nested_12(GArray *out,g_t12 v){
GRef r=g_ref(&v);int64_t n=g_len(r,5,-1,0);if(n<0 || (uint64_t)n>(SIZE_MAX-2)/2)g_panic("text size overflow");unsigned char *b=g_alloc((size_t)n*2+2);int64_t written=gs_fmt_quoted(b,g_address(g_element(r,5,-1,0,1,0,1)),n);g_print_bytes(out,b,written);
}
static g_t13 g_clone_13(g_t13 v) {
return v;}
static int g_equal_13(g_t13 a,g_t13 b){
return a==b;
}
static void g_print_13(GArray *out,g_t13 v) {
g_print_text(out,"fn");
}
static void g_nested_13(GArray *out,g_t13 v){
g_print_13(out,v);
}
static g_t14 g_clone_14(g_t14 v) {
return v;}
static int g_equal_14(g_t14 a,g_t14 b){
return a==b;
}
static void g_print_14(GArray *out,g_t14 v) {
g_print_text(out,"fn");
}
static void g_nested_14(GArray *out,g_t14 v){
g_print_14(out,v);
}
static g_t15 g_clone_15(g_t15 v) {
return v;}
static int g_equal_15(g_t15 a,g_t15 b){
return a==b;
}
static void g_print_15(GArray *out,g_t15 v) {
g_print_text(out,"fn");
}
static void g_nested_15(GArray *out,g_t15 v){
g_print_15(out,v);
}
static g_t16 g_clone_16(g_t16 v) {
return v;}
static int g_equal_16(g_t16 a,g_t16 b){
return a==b;
}
static void g_print_16(GArray *out,g_t16 v) {
g_print_text(out,"fn");
}
static void g_nested_16(GArray *out,g_t16 v){
g_print_16(out,v);
}
static g_t4 g_fn2(GClosure *g_env,g_t4 g_s3,g_t4 g_s4);
static g_t4 g_fn14(GClosure *g_env,g_t5 g_s5);
static g_t0 g_fn23(GClosure *g_env);
static g_t4 g_fn2(GClosure *g_env,g_t4 g_s3,g_t4 g_s4) {
volatile g_t4 g_result={0};
GReturnFrame g_frame={0};g_frame.parent=g_return_top;g_frame.function=2;
g_frame.result=(void*)&g_result;g_frame.size=sizeof g_result;
g_return_top=&g_frame;if(setjmp(g_frame.jump))goto g_return;
{
GRef g_v0=0;
g_v0=g_ref(&g_s3);
g_t4 g_v1={0};
g_v1=g_load_4(g_v0);
GRef g_v2=0;
g_v2=g_ref(&g_s4);
g_t4 g_v3={0};
g_v3=g_load_4(g_v2);
g_t4 g_v4={0};
g_v4=(g_t4)((uint64_t)g_v1<<(uint64_t)(g_v3&31));
g_result=g_v4;
goto g_return;
}
g_return:g_return_top=g_frame.parent;
return g_result;
}
static g_t4 g_fn14(GClosure *g_env,g_t5 g_s5) {
volatile g_t4 g_result={0};
GReturnFrame g_frame={0};g_frame.parent=g_return_top;g_frame.function=14;
g_frame.result=(void*)&g_result;g_frame.size=sizeof g_result;
g_return_top=&g_frame;if(setjmp(g_frame.jump))goto g_return;
g_t4 g_v0={0};
{
GRef g_v1=0;
g_v1=g_ref(&g_s5);
g_t5 g_v2={0};
g_v2=g_load_5(g_v1);
g_t4 g_v3={0};
g_v3=(g_t4)g_v2;
g_result=g_v3;
goto g_return;
}
g_result=g_v0;
g_return:g_return_top=g_frame.parent;
return g_result;
}
static g_t0 g_fn23(GClosure *g_env) {
GReturnFrame g_frame={0};g_frame.parent=g_return_top;g_frame.function=23;
g_return_top=&g_frame;if(setjmp(g_frame.jump))goto g_return;
g_t5 g_s7={0};
g_t5 g_s8={0};
g_t5 g_s9={0};
g_t5 g_s10={0};
g_t5 g_s11={0};
g_t5 g_s12={0};
{
g_t13 g_v1={0};
g_v1=g_closure((void*)g_fn2,0);
g_t4 g_v2={0};
g_v2=(g_t4)UINT64_C(1);
g_t4 g_v3={0};
{
GRef g_v4=0;
g_v4=g_ref(&g_s7);
g_t5 g_v5={0};
g_v5=(g_t5)UINT64_C(0);
g_store_5(g_v4,g_v5);
GRef g_v6=0;
g_v6=g_ref(&g_s7);
g_t5 g_v7={0};
g_v7=g_load_5(g_v6);
g_t4 g_v8={0};
g_v8=(g_t4)g_v7;
g_v3=g_v8;
}
g_t4 g_v9={0};
g_v9=g_fn2(g_v1,g_v2,g_v3);
g_print_4(NULL,g_v9);
g_print_text(NULL,"\n");
g_t13 g_v11={0};
g_v11=g_closure((void*)g_fn2,0);
g_t4 g_v12={0};
g_v12=(g_t4)UINT64_C(1);
g_t4 g_v13={0};
{
GRef g_v14=0;
g_v14=g_ref(&g_s8);
g_t5 g_v15={0};
g_v15=(g_t5)UINT64_C(31);
g_store_5(g_v14,g_v15);
GRef g_v16=0;
g_v16=g_ref(&g_s8);
g_t5 g_v17={0};
g_v17=g_load_5(g_v16);
g_t4 g_v18={0};
g_v18=(g_t4)g_v17;
g_v13=g_v18;
}
g_t4 g_v19={0};
g_v19=g_fn2(g_v11,g_v12,g_v13);
g_print_4(NULL,g_v19);
g_print_text(NULL,"\n");
g_t13 g_v21={0};
g_v21=g_closure((void*)g_fn2,0);
g_t4 g_v22={0};
g_v22=(g_t4)UINT64_C(1);
g_t4 g_v23={0};
{
GRef g_v24=0;
g_v24=g_ref(&g_s9);
g_t5 g_v25={0};
g_v25=(g_t5)UINT64_C(32);
g_store_5(g_v24,g_v25);
GRef g_v26=0;
g_v26=g_ref(&g_s9);
g_t5 g_v27={0};
g_v27=g_load_5(g_v26);
g_t4 g_v28={0};
g_v28=(g_t4)g_v27;
g_v23=g_v28;
}
g_t4 g_v29={0};
g_v29=g_fn2(g_v21,g_v22,g_v23);
g_print_4(NULL,g_v29);
g_print_text(NULL,"\n");
g_t13 g_v31={0};
g_v31=g_closure((void*)g_fn2,0);
g_t4 g_v32={0};
g_v32=(g_t4)UINT64_C(1);
g_t4 g_v33={0};
{
GRef g_v34=0;
g_v34=g_ref(&g_s10);
g_t5 g_v35={0};
g_v35=(g_t5)UINT64_C(33);
g_store_5(g_v34,g_v35);
GRef g_v36=0;
g_v36=g_ref(&g_s10);
g_t5 g_v37={0};
g_v37=g_load_5(g_v36);
g_t4 g_v38={0};
g_v38=(g_t4)g_v37;
g_v33=g_v38;
}
g_t4 g_v39={0};
g_v39=g_fn2(g_v31,g_v32,g_v33);
g_print_4(NULL,g_v39);
g_print_text(NULL,"\n");
g_t13 g_v41={0};
g_v41=g_closure((void*)g_fn2,0);
g_t4 g_v42={0};
g_v42=(g_t4)UINT64_C(1);
g_t4 g_v43={0};
{
GRef g_v44=0;
g_v44=g_ref(&g_s11);
g_t5 g_v45={0};
g_v45=(g_t5)UINT64_C(18446744073709551615);
g_store_5(g_v44,g_v45);
GRef g_v46=0;
g_v46=g_ref(&g_s11);
g_t5 g_v47={0};
g_v47=g_load_5(g_v46);
g_t4 g_v48={0};
g_v48=(g_t4)g_v47;
g_v43=g_v48;
}
g_t4 g_v49={0};
g_v49=g_fn2(g_v41,g_v42,g_v43);
g_print_4(NULL,g_v49);
g_print_text(NULL,"\n");
g_t13 g_v51={0};
g_v51=g_closure((void*)g_fn2,0);
g_t4 g_v52={0};
g_v52=(g_t4)UINT64_C(1);
g_t4 g_v53={0};
{
GRef g_v54=0;
g_v54=g_ref(&g_s12);
g_t5 g_v55={0};
g_v55=(g_t5)UINT64_C(18446744073709551583);
g_store_5(g_v54,g_v55);
GRef g_v56=0;
g_v56=g_ref(&g_s12);
g_t5 g_v57={0};
g_v57=g_load_5(g_v56);
g_t4 g_v58={0};
g_v58=(g_t4)g_v57;
g_v53=g_v58;
}
g_t4 g_v59={0};
g_v59=g_fn2(g_v51,g_v52,g_v53);
g_print_4(NULL,g_v59);
g_print_text(NULL,"\n");
}
g_return:g_return_top=g_frame.parent;
return;
}
static void g_initialize(void){if(g_initialized)return;g_initialized=1;
}
int main(int argc,char **argv){g_argc=argc;g_argv=argv;atexit(g_cleanup);g_initialize();g_fn23(NULL);return 0;}
