from pathlib import Path
import hashlib,json,subprocess,struct
ROOT=Path('/home/jacobt/src/goose-to-wasm');BASE=Path('/dev/shm/goose-selfhost-work');OUT=BASE/'wasm-byte-audit'
class Reader:
 def __init__(self,data,base=0):self.data=data;self.at=0;self.base=base
 def byte(self):v=self.data[self.at];self.at+=1;return v
 def raw(self,n):v=self.data[self.at:self.at+n];self.at+=n;return v
 def u(self):
  n=0;shift=0
  while True:
   b=self.byte();n|=(b&127)<<shift
   if not b&128:return n
   shift+=7
 def s(self):
  n=0;shift=0
  while True:
   b=self.byte();n|=(b&127)<<shift;shift+=7
   if not b&128:return n-(1<<shift) if b&64 else n
 def name(self):return self.raw(self.u()).decode(errors='replace')
def sha(b):return hashlib.sha256(b).hexdigest()
def diff(a,b):
 for i,(x,y) in enumerate(zip(a,b)):
  if x!=y:return i
 if len(a)!=len(b):return min(len(a),len(b))
 return None
WT={0x7f:'i32',0x7e:'i64',0x7d:'f32',0x7c:'f64',0x70:'funcref'}
SN={0:'custom',1:'type',2:'import',3:'function',4:'table',5:'memory',6:'global',7:'export',8:'start',9:'element',10:'code',11:'data',12:'data_count'}
def limits(r):
 f=r.u();lo=r.u();return {'flags':f,'minimum':lo,'maximum':r.u() if f&1 else None}
def expr(r):
 op=r.byte()
 if op in (0x41,0x42):v=r.s()
 elif op==0x43:v=struct.unpack('<f',r.raw(4))[0]
 elif op==0x44:v=struct.unpack('<d',r.raw(8))[0]
 else:raise ValueError(hex(op))
 assert r.byte()==0x0b
 return {'opcode':hex(op),'value':v}
def parse(path):
 b=path.read_bytes();r=Reader(b);assert r.raw(8)==b'\0asm\1\0\0\0';result={'path':str(path),'sha256':sha(b),'bytes':len(b),'header':b[:8].hex(),'sections':[]};types=[];funcs=[];names={};imports=[];bodies=[]
 while r.at<len(b):
  off=r.at;sid=r.byte();length=r.u();poff=r.at;payload=r.raw(length);s={'id':sid,'kind':SN[sid],'offset':off,'payload_offset':poff,'payload_bytes':length,'total_bytes':r.at-off,'sha256':sha(payload),'payload':payload};q=Reader(payload,poff)
  if sid==0:
   s['name']=q.name();s['custom_payload_bytes']=len(payload)-q.at
   if s['name']=='goose.direct':s['producer_abi']=q.name()
   elif s['name']=='name':
    while q.at<len(payload):
     k=q.byte();sub=q.raw(q.u());v=Reader(sub)
     if k==1:
      for _ in range(v.u()):index=v.u();names[index]=v.name()
   elif s['name']=='goose.regions':s['regions']=payload[q.at:].decode(errors='replace')
  elif sid==1:
   for _ in range(q.u()):
    assert q.byte()==0x60;a=[WT[q.byte()] for _ in range(q.u())];ret=[WT[q.byte()] for _ in range(q.u())];types.append({'args':a,'results':ret})
   s['types']=types
  elif sid==2:
   for i in range(q.u()):
    item={'index':i,'module':q.name(),'name':q.name(),'kind':q.byte()};assert item['kind']==0;item['type_index']=q.u();item['signature']=types[item['type_index']];imports.append(item)
   s['imports']=imports
  elif sid==3:funcs=[q.u() for _ in range(q.u())];s['type_indices']=funcs
  elif sid==4:s['tables']=[{'element_type':WT[q.byte()],'limits':limits(q)} for _ in range(q.u())]
  elif sid==5:s['memories']=[limits(q) for _ in range(q.u())]
  elif sid==6:
   gs=[]
   for i in range(q.u()):gs.append({'index':i,'type':WT[q.byte()],'mutable':q.byte(),'initializer':expr(q)})
   s['globals']=gs
  elif sid==7:
   exports=[]
   for _ in range(q.u()):exports.append({'name':q.name(),'kind':q.byte(),'index':q.u()})
   s['exports']=exports
  elif sid==9:s['element_hex']=payload.hex()
  elif sid==10:
   for j in range(q.u()):
    index=len(imports)+j;size_offset=q.at;size=q.u();body_offset=q.at;body=q.raw(size);v=Reader(body);groups=[]
    for _ in range(v.u()):count=v.u();t=WT[v.byte()];groups.append({'count':count,'type':t})
    bodies.append({'index':index,'type_index':funcs[j],'signature':types[funcs[j]],'offset':poff+body_offset,'size_offset':poff+size_offset,'bytes':size,'sha256':sha(body),'local_groups':groups,'instruction_offset':poff+body_offset+v.at,'instruction_bytes':size-v.at,'hex':body.hex(),'raw':body})
   s['function_bodies']=bodies
  elif sid==11:
   seg=[]
   for _ in range(q.u()):
    mode=q.u();assert mode==0;offset=expr(q);data=q.raw(q.u());seg.append({'address':offset['value'],'bytes':len(data),'sha256':sha(data),'hex':data.hex(),'text':data.decode(errors='replace')})
   s['segments']=seg
  result['sections'].append(s)
 for body in bodies:body['name']=names.get(body['index'])
 result['function_names']=names
 return result
report=json.loads((BASE/'parity-1/report.json').read_text());audits=[]
for row in report['results']:
 if 'artifacts' not in row:continue
 o=parse(Path(row['artifacts']['oracle']['path']));c=parse(Path(row['artifacts']['candidate']['path']));ab=Path(o['path']).read_bytes();bb=Path(c['path']).read_bytes()
 audit={'case':row['case'],'optimization':row['optimization'],'first_module_diff':diff(ab,bb),'runtime_equal':row['runtime_equal'],'golden_equal':row['golden_equal'],'oracle':o,'candidate':c,'section_comparison':[]}
 def key(s):return (s['id'],s.get('name',''))
 os={key(s):s for s in o['sections']};cs={key(s):s for s in c['sections']}
 for k in dict.fromkeys([*os,*cs]):
  x=os.get(k);y=cs.get(k);pair={'id':k[0],'kind':SN[k[0]],'name':k[1],'oracle_offset':x['offset'] if x else None,'candidate_offset':y['offset'] if y else None,'oracle_payload_bytes':x['payload_bytes'] if x else None,'candidate_payload_bytes':y['payload_bytes'] if y else None,'equal':bool(x and y and x['payload']==y['payload'])}
  if x and y:
   n=diff(x['payload'],y['payload']);pair.update(first_payload_diff=n,first_oracle_offset=x['payload_offset']+n if n is not None else None,first_candidate_offset=y['payload_offset']+n if n is not None else None)
  audit['section_comparison'].append(pair)
 ob=next(s['function_bodies'] for s in o['sections'] if s['id']==10);cb=next(s['function_bodies'] for s in c['sections'] if s['id']==10);audit['body_comparison']=[]
 for x,y in zip(ob,cb):audit['body_comparison'].append({'index':x['index'],'oracle_name':x['name'],'oracle_bytes':x['bytes'],'candidate_bytes':y['bytes'],'equal':x['raw']==y['raw'],'first_body_diff':diff(x['raw'],y['raw'])})
 for side in ('oracle','candidate'):
  path=Path(audit[side]['path']);d=subprocess.run(['llvm-objdump','-d',str(path)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True);(OUT/f'{row["case"]}-O{row["optimization"]}-{side}.disasm').write_bytes(d.stdout)
 audits.append(audit)
# Pin the actual source snapshots behind the binaries and the oracle sources used
# for interpreting the output. No candidate outputs are changed by this audit.
input_paths=[BASE/'parity-1/report.json',BASE/'build-2/report.json',ROOT/'selfhost/oracle.json',ROOT/'compiler/direct_wasm.h',ROOT/'compiler/direct_wasm_emit.h',ROOT/'compiler/wasm_binary.h',ROOT/'compiler/direct_wasm_expr.h',ROOT/'compiler/direct_wasm_leaf.h']
for n in ('codegen.goose','wasm.goose','model.goose','optimizer.goose'):input_paths.append(BASE/'build-2/sources'/n)
out={'schema':'goose-wasm-byte-audit-v1','scope':'Read-only audit of parity-1 artifacts from pinned oracle and stage0 build-2. Does not establish language parity or change compiler behavior.','input_sha256':{str(p):sha(p.read_bytes()) for p in input_paths},'artifacts':audits}
def clean(x):
 if isinstance(x,dict):return {k:clean(v) for k,v in x.items() if k not in ('payload','raw')}
 if isinstance(x,list):return [clean(v) for v in x]
 return x
(OUT/'report.json').write_text(json.dumps(clean(out),indent=2)+'\n')
for a in audits:
 o=a['oracle'];c=a['candidate'];ob=next(s['function_bodies'] for s in o['sections'] if s['id']==10);cb=next(s['function_bodies'] for s in c['sections'] if s['id']==10)
 print(a['case'],a['optimization'],'first',a['first_module_diff'],'sizes',o['bytes'],c['bytes'],'functions',len(ob),len(cb),'bodies',[(x['bytes'],y['bytes']) for x,y in zip(ob,cb)],'equal sections',[x['kind'] for x in a['section_comparison'] if x['equal']])
