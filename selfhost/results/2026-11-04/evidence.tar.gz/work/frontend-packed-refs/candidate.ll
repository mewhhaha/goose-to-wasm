; ModuleID = '/dev/shm/goose-selfhost-work/frontend-packed-refs/candidate-fixed-runtime.c'
source_filename = "/dev/shm/goose-selfhost-work/frontend-packed-refs/candidate-fixed-runtime.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct.GAllocation = type { ptr, ptr }
%struct.GReturnFrame = type { ptr, i64, [1 x %struct.__jmp_buf_tag], ptr, i64 }
%struct.__jmp_buf_tag = type { [8 x i64], i32, %struct.__sigset_t }
%struct.__sigset_t = type { [16 x i64] }
%struct.g_t16 = type { [50 x i8] }
%struct.g_t13 = type { [25 x i8] }
%struct.g_t14 = type { [24 x i8] }
%struct.GSlice = type { ptr, i64 }
%struct.GRefCell = type { ptr, ptr, ptr, i64 }
%struct.GArray = type { ptr, i64, i64 }

@g_argc = internal global i32 0, align 4
@g_argv = internal global ptr null, align 8
@.src = private unnamed_addr constant [76 x i8] c"/dev/shm/goose-selfhost-work/frontend-packed-refs/candidate-fixed-runtime.c\00", align 1
@.src.1 = private unnamed_addr constant [22 x i8] c"/usr/include/stdlib.h\00", align 1
@0 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 877, i32 63 }, { ptr, i32, i32 } { ptr @.src.1, i32 756, i32 51 }, i32 1 }
@g_allocations = internal global ptr null, align 8
@1 = private unnamed_addr constant { i16, i16, [41 x i8] } { i16 -1, i16 0, [41 x i8] c"'GAllocation' (aka 'struct GAllocation')\00" }
@2 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 30, i32 101 }, ptr @1, i8 3, i8 3 }
@3 = private unnamed_addr constant { i16, i16, [23 x i8] } { i16 -1, i16 0, [23 x i8] c"'struct GAllocation *'\00" }
@4 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 30, i32 101 }, ptr @3, i8 3, i8 0 }
@5 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 30, i32 115 }, ptr @1, i8 3, i8 3 }
@6 = private unnamed_addr constant { i16, i16, [9 x i8] } { i16 -1, i16 0, [9 x i8] c"'void *'\00" }
@7 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 30, i32 115 }, ptr @6, i8 3, i8 0 }
@g_initialized = internal global i32 0, align 4
@g_return_top = internal thread_local global ptr null, align 8
@8 = private unnamed_addr constant { i16, i16, [23 x i8] } { i16 0, i16 13, [23 x i8] c"'int64_t' (aka 'long')\00" }
@9 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 747, i32 62 }, ptr @8, i8 3, i8 1 }
@.str = private unnamed_addr constant [2 x i8] c" \00", align 1
@.str.2 = private unnamed_addr constant [2 x i8] c"\0A\00", align 1
@10 = private unnamed_addr constant { i16, i16, [18 x i8] } { i16 -1, i16 0, [18 x i8] c"'struct GRefCell'\00" }
@11 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 31, i32 60 }, ptr @10, i8 3, i8 3 }
@12 = private unnamed_addr constant { i16, i16, [18 x i8] } { i16 -1, i16 0, [18 x i8] c"'unsigned char *'\00" }
@13 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 31, i32 60 }, ptr @12, i8 3, i8 1 }
@.str.3 = private unnamed_addr constant [14 x i8] c"out of memory\00", align 1
@14 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 28, i32 8 }, ptr @1, i8 3, i8 3 }
@15 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 28, i32 8 }, ptr @6, i8 3, i8 1 }
@16 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 28, i32 19 }, ptr @1, i8 3, i8 3 }
@17 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 28, i32 19 }, ptr @3, i8 3, i8 1 }
@stderr = external global ptr, align 8
@.src.4 = private unnamed_addr constant [21 x i8] c"/usr/include/stdio.h\00", align 1
@18 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 24, i32 46 }, { ptr, i32, i32 } { ptr @.src.4, i32 365, i32 45 }, i32 1 }
@.str.5 = private unnamed_addr constant [25 x i8] c"goose runtime error: %s\0A\00", align 1
@19 = private unnamed_addr global { { ptr, i32, i32 } } { { ptr, i32, i32 } { ptr @.src, i32 24, i32 85 } }
@20 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 41, i32 72 }, ptr @10, i8 3, i8 3 }
@21 = private unnamed_addr constant { i16, i16, [33 x i8] } { i16 -1, i16 0, [33 x i8] c"'GRef' (aka 'struct GRefCell *')\00" }
@22 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 41, i32 72 }, ptr @21, i8 3, i8 1 }
@23 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 41, i32 85 }, ptr @10, i8 3, i8 3 }
@24 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 41, i32 85 }, ptr @8, i8 3, i8 1 }
@.src.6 = private unnamed_addr constant [22 x i8] c"/usr/include/string.h\00", align 1
@25 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 492, i32 47 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 1 }
@26 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 492, i32 60 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 2 }
@.str.7 = private unnamed_addr constant [15 x i8] c"null reference\00", align 1
@27 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 34, i32 28 }, ptr @10, i8 3, i8 3 }
@28 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 34, i32 28 }, ptr @12, i8 3, i8 0 }
@29 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 35, i32 11 }, ptr @10, i8 3, i8 3 }
@30 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 35, i32 11 }, ptr @21, i8 3, i8 0 }
@31 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 35, i32 37 }, ptr @10, i8 3, i8 3 }
@32 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 35, i32 37 }, ptr @21, i8 3, i8 0 }
@33 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 36, i32 16 }, ptr @10, i8 3, i8 3 }
@34 = private unnamed_addr constant { i16, i16, [10 x i8] } { i16 -1, i16 0, [10 x i8] c"'void **'\00" }
@35 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 36, i32 16 }, ptr @34, i8 3, i8 0 }
@36 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 36, i32 38 }, ptr @10, i8 3, i8 3 }
@37 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 36, i32 38 }, ptr @34, i8 3, i8 0 }
@38 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 36, i32 29 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 1 }
@39 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 36, i32 35 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 2 }
@40 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 36, i32 35 }, ptr @34, i8 3, i8 0 }
@41 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 37, i32 12 }, ptr @10, i8 3, i8 3 }
@42 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 37, i32 12 }, ptr @8, i8 3, i8 0 }
@43 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 39, i32 20 }, ptr @10, i8 3, i8 3 }
@44 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 39, i32 20 }, ptr @8, i8 3, i8 0 }
@45 = private unnamed_addr global { { ptr, i32, i32 } } { { ptr, i32, i32 } { ptr @.src, i32 39, i32 16 } }
@46 = private unnamed_addr constant { i16, i16, [7 x i8] } { i16 0, i16 13, [7 x i8] c"'long'\00" }
@47 = private unnamed_addr global { { ptr, i32, i32 }, ptr } { { ptr, i32, i32 } { ptr @.src, i32 68, i32 44 }, ptr @46 }
@.str.8 = private unnamed_addr constant [17 x i8] c"invalid capacity\00", align 1
@.str.9 = private unnamed_addr constant [32 x i8] c"limited array capacity exceeded\00", align 1
@.str.10 = private unnamed_addr constant [18 x i8] c"array cannot grow\00", align 1
@48 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 71, i32 22 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 1 }
@49 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 71, i32 25 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 2 }
@50 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 72, i32 16 }, ptr @8, i8 3, i8 0 }
@51 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 73, i32 23 }, ptr @8, i8 3, i8 0 }
@52 = private unnamed_addr global { { ptr, i32, i32 }, ptr } { { ptr, i32, i32 } { ptr @.src, i32 73, i32 26 }, ptr @8 }
@53 = private unnamed_addr global { { ptr, i32, i32 }, ptr } { { ptr, i32, i32 } { ptr @.src, i32 73, i32 28 }, ptr @8 }
@54 = private unnamed_addr global { { ptr, i32, i32 }, ptr } { { ptr, i32, i32 } { ptr @.src, i32 74, i32 34 }, ptr @46 }
@.str.11 = private unnamed_addr constant [24 x i8] c"array capacity overflow\00", align 1
@55 = private unnamed_addr global { { ptr, i32, i32 }, ptr } { { ptr, i32, i32 } { ptr @.src, i32 75, i32 49 }, ptr @8 }
@56 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 76, i32 14 }, ptr @8, i8 3, i8 0 }
@57 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 76, i32 49 }, ptr @8, i8 3, i8 0 }
@58 = private unnamed_addr global { { ptr, i32, i32 }, ptr } { { ptr, i32, i32 } { ptr @.src, i32 76, i32 52 }, ptr @8 }
@59 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 76, i32 26 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 1 }
@60 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 76, i32 31 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 2 }
@61 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 76, i32 77 }, ptr @8, i8 3, i8 1 }
@62 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 77, i32 16 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 1 }
@63 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 77, i32 29 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 2 }
@64 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 82, i32 29 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 1 }
@65 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 82, i32 32 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 2 }
@66 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 82, i32 58 }, ptr @8, i8 3, i8 1 }
@67 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 82, i32 76 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 1 }
@68 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 82, i32 89 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 2 }
@69 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 44, i32 63 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 1 }
@70 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 44, i32 65 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 2 }
@71 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 487, i32 47 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 1 }
@72 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 487, i32 60 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 2 }
@.str.12 = private unnamed_addr constant [20 x i8] c"index out of bounds\00", align 1
@73 = private unnamed_addr global { { ptr, i32, i32 }, ptr } { { ptr, i32, i32 } { ptr @.src, i32 58, i32 32 }, ptr @46 }
@.str.13 = private unnamed_addr constant [22 x i8] c"array offset overflow\00", align 1
@74 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 59, i32 36 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 1 }
@75 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 59, i32 39 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 2 }
@76 = private unnamed_addr global { { ptr, i32, i32 }, ptr } { { ptr, i32, i32 } { ptr @.src, i32 59, i32 91 }, ptr @8 }
@77 = private unnamed_addr global { { ptr, i32, i32 }, ptr } { { ptr, i32, i32 } { ptr @.src, i32 60, i32 40 }, ptr @8 }
@78 = private unnamed_addr global { { ptr, i32, i32 }, ptr } { { ptr, i32, i32 } { ptr @.src, i32 61, i32 59 }, ptr @8 }
@79 = private unnamed_addr global { { ptr, i32, i32 }, ptr } { { ptr, i32, i32 } { ptr @.src, i32 61, i32 53 }, ptr @8 }
@80 = private unnamed_addr global { { ptr, i32, i32 }, ptr } { { ptr, i32, i32 } { ptr @.src, i32 62, i32 48 }, ptr @8 }
@81 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 46, i32 36 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 1 }
@82 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 46, i32 39 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 2 }
@83 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 46, i32 72 }, ptr @8, i8 3, i8 0 }
@84 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 49, i32 22 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 1 }
@85 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 49, i32 25 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 2 }
@86 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 49, i32 58 }, ptr @8, i8 3, i8 0 }
@87 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 43, i32 75 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 1 }
@88 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 43, i32 78 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 2 }
@89 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 42, i32 77 }, ptr @10, i8 3, i8 3 }
@90 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 42, i32 77 }, ptr @34, i8 3, i8 1 }
@91 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 42, i32 91 }, ptr @10, i8 3, i8 3 }
@92 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 42, i32 91 }, ptr @8, i8 3, i8 1 }
@93 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 677, i32 20 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 1 }
@94 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 677, i32 25 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 2 }
@95 = private unnamed_addr constant { i16, i16, [10 x i8] } { i16 -1, i16 0, [10 x i8] c"'g_t14 *'\00" }
@96 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 677, i32 25 }, ptr @95, i8 3, i8 0 }
@97 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 677, i32 73 }, ptr @8, i8 3, i8 0 }
@98 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 677, i32 65 }, ptr @8, i8 3, i8 1 }
@99 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 677, i32 92 }, ptr @8, i8 3, i8 0 }
@100 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 677, i32 84 }, ptr @8, i8 3, i8 1 }
@101 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 677, i32 130 }, ptr @8, i8 3, i8 0 }
@102 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 677, i32 145 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 1 }
@103 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 677, i32 145 }, ptr @95, i8 3, i8 1 }
@104 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 677, i32 148 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 2 }
@105 = private unnamed_addr global { { ptr, i32, i32 }, ptr } { { ptr, i32, i32 } { ptr @.src, i32 679, i32 42 }, ptr @8 }
@106 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 532, i32 49 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 1 }
@107 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 532, i32 62 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 2 }
@108 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 532, i32 62 }, ptr @95, i8 3, i8 0 }
@109 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 531, i32 49 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 1 }
@110 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 531, i32 52 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 2 }
@111 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 527, i32 49 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 1 }
@112 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 527, i32 62 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 2 }
@113 = private unnamed_addr constant { i16, i16, [10 x i8] } { i16 -1, i16 0, [10 x i8] c"'g_t13 *'\00" }
@114 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 527, i32 62 }, ptr @113, i8 3, i8 0 }
@115 = private unnamed_addr global { { ptr, i32, i32 }, ptr } { { ptr, i32, i32 } { ptr @.src, i32 705, i32 42 }, ptr @8 }
@116 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 526, i32 49 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 1 }
@117 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 526, i32 52 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 2 }
@118 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 542, i32 49 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 1 }
@119 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 542, i32 62 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 2 }
@120 = private unnamed_addr constant { i16, i16, [10 x i8] } { i16 -1, i16 0, [10 x i8] c"'g_t16 *'\00" }
@121 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 542, i32 62 }, ptr @120, i8 3, i8 0 }
@122 = private unnamed_addr global { { ptr, i32, i32 }, ptr } { { ptr, i32, i32 } { ptr @.src, i32 85, i32 80 }, ptr @8 }
@123 = private unnamed_addr global { { ptr, i32, i32 }, ptr } { { ptr, i32, i32 } { ptr @.src, i32 86, i32 36 }, ptr @8 }
@124 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 87, i32 12 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 1 }
@125 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 87, i32 27 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 2 }
@126 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 486, i32 46 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 1 }
@127 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 486, i32 49 }, { ptr, i32, i32 } { ptr @.src.6, i32 48, i32 28 }, i32 2 }
@128 = private unnamed_addr constant { i16, i16, [32 x i8] } { i16 0, i16 6, [32 x i8] c"'uint8_t' (aka 'unsigned char')\00" }
@129 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 167, i32 5 }, ptr @128, i8 0, i8 1 }
@130 = private unnamed_addr global { { ptr, i32, i32 } } { { ptr, i32, i32 } { ptr @.src, i32 168, i32 31 } }
@131 = private unnamed_addr global { { ptr, i32, i32 }, ptr } { { ptr, i32, i32 } { ptr @.src, i32 168, i32 14 }, ptr @8 }
@132 = private unnamed_addr global { { ptr, i32, i32 } } { { ptr, i32, i32 } { ptr @.src, i32 146, i32 22 } }
@133 = private unnamed_addr constant { i16, i16, [33 x i8] } { i16 0, i16 12, [33 x i8] c"'uint64_t' (aka 'unsigned long')\00" }
@134 = private unnamed_addr global { { ptr, i32, i32 }, ptr } { { ptr, i32, i32 } { ptr @.src, i32 148, i32 35 }, ptr @133 }
@135 = private unnamed_addr global { { ptr, i32, i32 }, ptr } { { ptr, i32, i32 } { ptr @.src, i32 149, i32 11 }, ptr @133 }
@136 = private unnamed_addr global { { ptr, i32, i32 } } { { ptr, i32, i32 } { ptr @.src, i32 150, i32 11 } }
@gs_digit_pairs = internal constant [201 x i8] c"00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899\00", align 16
@137 = private unnamed_addr constant { i16, i16, [18 x i8] } { i16 -1, i16 0, [18 x i8] c"'const char[201]'\00" }
@138 = private unnamed_addr constant { i16, i16, [15 x i8] } { i16 0, i16 10, [15 x i8] c"'unsigned int'\00" }
@139 = private unnamed_addr global { { ptr, i32, i32 }, ptr, ptr } { { ptr, i32, i32 } { ptr @.src, i32 151, i32 25 }, ptr @137, ptr @138 }
@140 = private unnamed_addr global { { ptr, i32, i32 } } { { ptr, i32, i32 } { ptr @.src, i32 151, i32 25 } }
@141 = private unnamed_addr constant { i16, i16, [13 x i8] } { i16 0, i16 7, [13 x i8] c"'const char'\00" }
@142 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 151, i32 25 }, ptr @141, i8 0, i8 0 }
@143 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 151, i32 9 }, ptr @128, i8 0, i8 1 }
@144 = private unnamed_addr global { { ptr, i32, i32 }, ptr, ptr } { { ptr, i32, i32 } { ptr @.src, i32 152, i32 25 }, ptr @137, ptr @138 }
@145 = private unnamed_addr global { { ptr, i32, i32 } } { { ptr, i32, i32 } { ptr @.src, i32 152, i32 25 } }
@146 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 152, i32 25 }, ptr @141, i8 0, i8 0 }
@147 = private unnamed_addr global { { ptr, i32, i32 } } { { ptr, i32, i32 } { ptr @.src, i32 152, i32 9 } }
@148 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 152, i32 9 }, ptr @128, i8 0, i8 1 }
@149 = private unnamed_addr global { { ptr, i32, i32 }, ptr, ptr } { { ptr, i32, i32 } { ptr @.src, i32 155, i32 26 }, ptr @137, ptr @133 }
@150 = private unnamed_addr global { { ptr, i32, i32 } } { { ptr, i32, i32 } { ptr @.src, i32 155, i32 26 } }
@151 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 155, i32 26 }, ptr @141, i8 0, i8 0 }
@152 = private unnamed_addr global { { ptr, i32, i32 } } { { ptr, i32, i32 } { ptr @.src, i32 155, i32 9 } }
@153 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 155, i32 9 }, ptr @128, i8 0, i8 1 }
@154 = private unnamed_addr global { { ptr, i32, i32 }, ptr, ptr } { { ptr, i32, i32 } { ptr @.src, i32 156, i32 26 }, ptr @137, ptr @133 }
@155 = private unnamed_addr global { { ptr, i32, i32 } } { { ptr, i32, i32 } { ptr @.src, i32 156, i32 26 } }
@156 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 156, i32 26 }, ptr @141, i8 0, i8 0 }
@157 = private unnamed_addr global { { ptr, i32, i32 } } { { ptr, i32, i32 } { ptr @.src, i32 156, i32 9 } }
@158 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 156, i32 9 }, ptr @128, i8 0, i8 1 }
@159 = private unnamed_addr global { { ptr, i32, i32 } } { { ptr, i32, i32 } { ptr @.src, i32 158, i32 9 } }
@160 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 158, i32 9 }, ptr @128, i8 0, i8 1 }
@161 = private unnamed_addr constant { i16, i16, [6 x i8] } { i16 0, i16 11, [6 x i8] c"'int'\00" }
@162 = private unnamed_addr global { { ptr, i32, i32 }, ptr } { { ptr, i32, i32 } { ptr @.src, i32 135, i32 31 }, ptr @161 }
@163 = private unnamed_addr global { { ptr, i32, i32 }, ptr } { { ptr, i32, i32 } { ptr @.src, i32 136, i32 32 }, ptr @161 }
@164 = private unnamed_addr global { { ptr, i32, i32 }, ptr } { { ptr, i32, i32 } { ptr @.src, i32 137, i32 33 }, ptr @161 }
@165 = private unnamed_addr global { { ptr, i32, i32 }, ptr } { { ptr, i32, i32 } { ptr @.src, i32 138, i32 11 }, ptr @133 }
@166 = private unnamed_addr global { { ptr, i32, i32 }, ptr } { { ptr, i32, i32 } { ptr @.src, i32 139, i32 11 }, ptr @161 }
@stdout = external global ptr, align 8
@167 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 107, i32 124 }, { ptr, i32, i32 } { ptr @.src.4, i32 740, i32 43 }, i32 4 }
@168 = private unnamed_addr constant { i16, i16, [9 x i8] } { i16 -1, i16 0, [9 x i8] c"'GArray'\00" }
@169 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 90, i32 67 }, ptr @168, i8 3, i8 3 }
@170 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 90, i32 67 }, ptr @8, i8 3, i8 0 }
@171 = private unnamed_addr global { { ptr, i32, i32 }, ptr } { { ptr, i32, i32 } { ptr @.src, i32 90, i32 70 }, ptr @8 }
@172 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 91, i32 18 }, ptr @168, i8 3, i8 3 }
@173 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 91, i32 18 }, ptr @12, i8 3, i8 0 }
@174 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 91, i32 28 }, ptr @168, i8 3, i8 3 }
@175 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 91, i32 28 }, ptr @8, i8 3, i8 0 }
@176 = private unnamed_addr global { { ptr, i32, i32 } } { { ptr, i32, i32 } { ptr @.src, i32 91, i32 22 } }
@177 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 91, i32 13 }, { ptr, i32, i32 } { ptr @.src.6, i32 52, i32 14 }, i32 1 }
@178 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 91, i32 32 }, { ptr, i32, i32 } { ptr @.src.6, i32 52, i32 14 }, i32 2 }
@179 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 91, i32 51 }, ptr @168, i8 3, i8 3 }
@180 = private unnamed_addr global { { ptr, i32, i32 }, ptr, i8, i8 } { { ptr, i32, i32 } { ptr @.src, i32 91, i32 51 }, ptr @8, i8 3, i8 1 }
@181 = private unnamed_addr global { { ptr, i32, i32 }, ptr } { { ptr, i32, i32 } { ptr @.src, i32 91, i32 54 }, ptr @8 }
@182 = private unnamed_addr global { { ptr, i32, i32 }, ptr } { { ptr, i32, i32 } { ptr @.src, i32 654, i32 22 }, ptr @8 }
@183 = private unnamed_addr global { { ptr, i32, i32 }, { ptr, i32, i32 }, i32 } { { ptr, i32, i32 } { ptr @.src, i32 108, i32 91 }, { ptr, i32, i32 } { ptr @.src.6, i32 440, i32 33 }, i32 1 }

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define dso_local i32 @main(i32 noundef %0, ptr noundef %1) #0 !func_sanitize !5 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca ptr, align 8
  store i32 0, ptr %3, align 4
  store i32 %0, ptr %4, align 4
  store ptr %1, ptr %5, align 8
  %6 = load i32, ptr %4, align 4
  store i32 %6, ptr @g_argc, align 4
  %7 = load ptr, ptr %5, align 8
  store ptr %7, ptr @g_argv, align 8
  br i1 true, label %9, label %8, !prof !6, !nosanitize !7

8:                                                ; preds = %2
  call void @__ubsan_handle_nonnull_arg(ptr @0) #13, !nosanitize !7
  br label %9, !nosanitize !7

9:                                                ; preds = %8, %2
  %10 = call i32 @atexit(ptr noundef @g_cleanup) #14
  call void @g_initialize()
  call void @g_fn9(ptr noundef null)
  ret i32 0
}

; Function Attrs: nounwind
declare i32 @atexit(ptr noundef) #1

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @g_cleanup() #0 !func_sanitize !8 {
  %1 = alloca ptr, align 8
  br label %2

2:                                                ; preds = %39, %0
  %3 = load ptr, ptr @g_allocations, align 8
  %4 = icmp ne ptr %3, null
  br i1 %4, label %5, label %42

5:                                                ; preds = %2
  %6 = load ptr, ptr @g_allocations, align 8
  store ptr %6, ptr %1, align 8
  %7 = load ptr, ptr %1, align 8
  %8 = icmp ne ptr %7, null, !nosanitize !7
  %9 = ptrtoint ptr %7 to i64, !nosanitize !7
  %10 = and i64 %9, 7, !nosanitize !7
  %11 = icmp eq i64 %10, 0, !nosanitize !7
  %12 = and i1 %8, %11, !nosanitize !7
  br i1 %12, label %14, label %13, !prof !6, !nosanitize !7

13:                                               ; preds = %5
  call void @__ubsan_handle_type_mismatch_v1(ptr @2, i64 %9) #13, !nosanitize !7
  br label %14, !nosanitize !7

14:                                               ; preds = %13, %5
  %15 = getelementptr inbounds nuw %struct.GAllocation, ptr %7, i32 0, i32 0
  %16 = icmp ne ptr %15, null, !nosanitize !7
  %17 = ptrtoint ptr %15 to i64, !nosanitize !7
  %18 = and i64 %17, 7, !nosanitize !7
  %19 = icmp eq i64 %18, 0, !nosanitize !7
  %20 = and i1 %16, %19, !nosanitize !7
  br i1 %20, label %22, label %21, !prof !6, !nosanitize !7

21:                                               ; preds = %14
  call void @__ubsan_handle_type_mismatch_v1(ptr @4, i64 %17) #13, !nosanitize !7
  br label %22, !nosanitize !7

22:                                               ; preds = %21, %14
  %23 = load ptr, ptr %15, align 8
  store ptr %23, ptr @g_allocations, align 8
  %24 = load ptr, ptr %1, align 8
  %25 = icmp ne ptr %24, null, !nosanitize !7
  %26 = ptrtoint ptr %24 to i64, !nosanitize !7
  %27 = and i64 %26, 7, !nosanitize !7
  %28 = icmp eq i64 %27, 0, !nosanitize !7
  %29 = and i1 %25, %28, !nosanitize !7
  br i1 %29, label %31, label %30, !prof !6, !nosanitize !7

30:                                               ; preds = %22
  call void @__ubsan_handle_type_mismatch_v1(ptr @5, i64 %26) #13, !nosanitize !7
  br label %31, !nosanitize !7

31:                                               ; preds = %30, %22
  %32 = getelementptr inbounds nuw %struct.GAllocation, ptr %24, i32 0, i32 1
  %33 = icmp ne ptr %32, null, !nosanitize !7
  %34 = ptrtoint ptr %32 to i64, !nosanitize !7
  %35 = and i64 %34, 7, !nosanitize !7
  %36 = icmp eq i64 %35, 0, !nosanitize !7
  %37 = and i1 %33, %36, !nosanitize !7
  br i1 %37, label %39, label %38, !prof !6, !nosanitize !7

38:                                               ; preds = %31
  call void @__ubsan_handle_type_mismatch_v1(ptr @7, i64 %34) #13, !nosanitize !7
  br label %39, !nosanitize !7

39:                                               ; preds = %38, %31
  %40 = load ptr, ptr %32, align 8
  call void @free(ptr noundef %40) #14
  %41 = load ptr, ptr %1, align 8
  call void @free(ptr noundef %41) #14
  br label %2, !llvm.loop !9

42:                                               ; preds = %2
  ret void
}

; Function Attrs: uwtable
declare void @__ubsan_handle_nonnull_arg(ptr) #2

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @g_initialize() #0 !func_sanitize !8 {
  %1 = load i32, ptr @g_initialized, align 4
  %2 = icmp ne i32 %1, 0
  br i1 %2, label %3, label %4

3:                                                ; preds = %0
  br label %5

4:                                                ; preds = %0
  store i32 1, ptr @g_initialized, align 4
  br label %5

5:                                                ; preds = %4, %3
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @g_fn9(ptr noundef %0) #0 !func_sanitize !11 {
  %2 = alloca ptr, align 8
  %3 = alloca %struct.GReturnFrame, align 8
  %4 = alloca %struct.g_t16, align 1
  %5 = alloca ptr, align 8
  %6 = alloca %struct.g_t16, align 8
  %7 = alloca ptr, align 8
  %8 = alloca i64, align 8
  %9 = alloca %struct.g_t13, align 8
  %10 = alloca ptr, align 8
  %11 = alloca i8, align 1
  %12 = alloca ptr, align 8
  %13 = alloca %struct.g_t14, align 8
  %14 = alloca ptr, align 8
  %15 = alloca i64, align 8
  %16 = alloca i64, align 8
  %17 = alloca %struct.g_t14, align 8
  %18 = alloca %struct.g_t14, align 1
  %19 = alloca ptr, align 8
  %20 = alloca %struct.g_t13, align 8
  %21 = alloca %struct.g_t13, align 1
  %22 = alloca %struct.g_t13, align 8
  %23 = alloca ptr, align 8
  %24 = alloca i8, align 1
  %25 = alloca ptr, align 8
  %26 = alloca %struct.g_t14, align 8
  %27 = alloca ptr, align 8
  %28 = alloca i64, align 8
  %29 = alloca i64, align 8
  %30 = alloca %struct.g_t14, align 8
  %31 = alloca %struct.g_t14, align 1
  %32 = alloca ptr, align 8
  %33 = alloca %struct.g_t13, align 8
  %34 = alloca %struct.g_t13, align 1
  %35 = alloca %struct.g_t16, align 8
  %36 = alloca %struct.g_t16, align 1
  %37 = alloca ptr, align 8
  %38 = alloca i64, align 8
  %39 = alloca ptr, align 8
  %40 = alloca ptr, align 8
  %41 = alloca i64, align 8
  %42 = alloca ptr, align 8
  %43 = alloca ptr, align 8
  %44 = alloca i64, align 8
  %45 = alloca ptr, align 8
  %46 = alloca ptr, align 8
  %47 = alloca i64, align 8
  %48 = alloca ptr, align 8
  %49 = alloca ptr, align 8
  %50 = alloca i64, align 8
  %51 = alloca ptr, align 8
  %52 = alloca ptr, align 8
  %53 = alloca i64, align 8
  %54 = alloca ptr, align 8
  %55 = alloca i64, align 8
  %56 = alloca %struct.GSlice, align 8
  %57 = alloca %struct.GSlice, align 8
  %58 = alloca ptr, align 8
  %59 = alloca i64, align 8
  %60 = alloca ptr, align 8
  %61 = alloca ptr, align 8
  %62 = alloca i64, align 8
  %63 = alloca ptr, align 8
  %64 = alloca i64, align 8
  store ptr %0, ptr %2, align 8
  call void @llvm.memset.p0.i64(ptr align 8 %3, i8 0, i64 232, i1 false)
  %65 = call align 8 ptr @llvm.threadlocal.address.p0(ptr align 8 @g_return_top)
  %66 = load ptr, ptr %65, align 8
  %67 = getelementptr inbounds nuw %struct.GReturnFrame, ptr %3, i32 0, i32 0
  store ptr %66, ptr %67, align 8
  %68 = getelementptr inbounds nuw %struct.GReturnFrame, ptr %3, i32 0, i32 1
  %69 = ptrtoint ptr %68 to i64, !nosanitize !7
  %70 = and i64 %69, 7, !nosanitize !7
  %71 = icmp eq i64 %70, 0, !nosanitize !7
  br i1 %71, label %73, label %72, !prof !6, !nosanitize !7

72:                                               ; preds = %1
  call void @__ubsan_handle_type_mismatch_v1(ptr @9, i64 %69) #13, !nosanitize !7
  br label %73, !nosanitize !7

73:                                               ; preds = %72, %1
  store i64 9, ptr %68, align 8
  %74 = call align 8 ptr @llvm.threadlocal.address.p0(ptr align 8 @g_return_top)
  store ptr %3, ptr %74, align 8
  %75 = getelementptr inbounds nuw %struct.GReturnFrame, ptr %3, i32 0, i32 2
  %76 = getelementptr inbounds [1 x %struct.__jmp_buf_tag], ptr %75, i64 0, i64 0
  %77 = call i32 @_setjmp(ptr noundef %76) #15
  %78 = icmp ne i32 %77, 0
  br i1 %78, label %79, label %80

79:                                               ; preds = %73
  br label %167

80:                                               ; preds = %73
  call void @llvm.memset.p0.i64(ptr align 1 %4, i8 0, i64 50, i1 false)
  store ptr null, ptr %5, align 8
  %81 = call ptr @g_ref(ptr noundef %4)
  store ptr %81, ptr %5, align 8
  call void @llvm.memset.p0.i64(ptr align 1 %6, i8 0, i64 50, i1 false)
  store ptr null, ptr %7, align 8
  %82 = call ptr @g_ref(ptr noundef %6)
  store ptr %82, ptr %7, align 8
  store i64 0, ptr %8, align 8
  store i64 2, ptr %8, align 8
  call void @llvm.memset.p0.i64(ptr align 1 %9, i8 0, i64 25, i1 false)
  store ptr null, ptr %10, align 8
  %83 = call ptr @g_ref(ptr noundef %9)
  store ptr %83, ptr %10, align 8
  store i8 0, ptr %11, align 1
  store i8 3, ptr %11, align 1
  store ptr null, ptr %12, align 8
  %84 = load ptr, ptr %10, align 8
  %85 = call ptr @g_offset(ptr noundef %84, i64 noundef 0)
  store ptr %85, ptr %12, align 8
  %86 = load ptr, ptr %12, align 8
  %87 = load i8, ptr %11, align 1
  call void @g_store_6(ptr noundef %86, i8 noundef zeroext %87)
  call void @llvm.memset.p0.i64(ptr align 1 %13, i8 0, i64 24, i1 false)
  store ptr null, ptr %14, align 8
  %88 = call ptr @g_ref(ptr noundef %13)
  store ptr %88, ptr %14, align 8
  store i64 0, ptr %15, align 8
  store i64 1, ptr %15, align 8
  %89 = load ptr, ptr %14, align 8
  %90 = load i64, ptr %15, align 8
  call void @g_reserve(ptr noundef %89, i32 noundef 3, i64 noundef -1, i32 noundef 0, i64 noundef 8, i64 noundef %90)
  %91 = load ptr, ptr %14, align 8
  %92 = load i64, ptr %15, align 8
  call void @g_set_len(ptr noundef %91, i32 noundef 3, i64 noundef -1, i32 noundef 0, i64 noundef %92)
  store i64 0, ptr %16, align 8
  store i64 1, ptr %16, align 8
  %93 = load ptr, ptr %14, align 8
  %94 = call ptr @g_element(ptr noundef %93, i32 noundef 3, i64 noundef -1, i32 noundef 0, i64 noundef 8, i64 noundef 0, i32 noundef 0)
  %95 = load i64, ptr %16, align 8
  call void @g_store_5(ptr noundef %94, i64 noundef %95)
  call void @llvm.memset.p0.i64(ptr align 1 %17, i8 0, i64 24, i1 false)
  call void @g_clone_14(ptr dead_on_unwind writable sret(%struct.g_t14) align 1 %18, ptr noundef byval(%struct.g_t14) align 8 %13)
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %17, ptr align 1 %18, i64 24, i1 false)
  store ptr null, ptr %19, align 8
  %96 = load ptr, ptr %10, align 8
  %97 = call ptr @g_offset(ptr noundef %96, i64 noundef 1)
  store ptr %97, ptr %19, align 8
  %98 = load ptr, ptr %19, align 8
  call void @g_store_14(ptr noundef %98, ptr noundef byval(%struct.g_t14) align 8 %17)
  call void @llvm.memset.p0.i64(ptr align 1 %20, i8 0, i64 25, i1 false)
  call void @g_clone_13(ptr dead_on_unwind writable sret(%struct.g_t13) align 1 %21, ptr noundef byval(%struct.g_t13) align 8 %9)
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %20, ptr align 1 %21, i64 25, i1 false)
  %99 = load ptr, ptr %7, align 8
  %100 = call ptr @g_element(ptr noundef %99, i32 noundef 0, i64 noundef 2, i32 noundef 0, i64 noundef 25, i64 noundef 0, i32 noundef 0)
  call void @g_store_13(ptr noundef %100, ptr noundef byval(%struct.g_t13) align 8 %20)
  call void @llvm.memset.p0.i64(ptr align 1 %22, i8 0, i64 25, i1 false)
  store ptr null, ptr %23, align 8
  %101 = call ptr @g_ref(ptr noundef %22)
  store ptr %101, ptr %23, align 8
  store i8 0, ptr %24, align 1
  store i8 4, ptr %24, align 1
  store ptr null, ptr %25, align 8
  %102 = load ptr, ptr %23, align 8
  %103 = call ptr @g_offset(ptr noundef %102, i64 noundef 0)
  store ptr %103, ptr %25, align 8
  %104 = load ptr, ptr %25, align 8
  %105 = load i8, ptr %24, align 1
  call void @g_store_6(ptr noundef %104, i8 noundef zeroext %105)
  call void @llvm.memset.p0.i64(ptr align 1 %26, i8 0, i64 24, i1 false)
  store ptr null, ptr %27, align 8
  %106 = call ptr @g_ref(ptr noundef %26)
  store ptr %106, ptr %27, align 8
  store i64 0, ptr %28, align 8
  store i64 1, ptr %28, align 8
  %107 = load ptr, ptr %27, align 8
  %108 = load i64, ptr %28, align 8
  call void @g_reserve(ptr noundef %107, i32 noundef 3, i64 noundef -1, i32 noundef 0, i64 noundef 8, i64 noundef %108)
  %109 = load ptr, ptr %27, align 8
  %110 = load i64, ptr %28, align 8
  call void @g_set_len(ptr noundef %109, i32 noundef 3, i64 noundef -1, i32 noundef 0, i64 noundef %110)
  store i64 0, ptr %29, align 8
  store i64 2, ptr %29, align 8
  %111 = load ptr, ptr %27, align 8
  %112 = call ptr @g_element(ptr noundef %111, i32 noundef 3, i64 noundef -1, i32 noundef 0, i64 noundef 8, i64 noundef 0, i32 noundef 0)
  %113 = load i64, ptr %29, align 8
  call void @g_store_5(ptr noundef %112, i64 noundef %113)
  call void @llvm.memset.p0.i64(ptr align 1 %30, i8 0, i64 24, i1 false)
  call void @g_clone_14(ptr dead_on_unwind writable sret(%struct.g_t14) align 1 %31, ptr noundef byval(%struct.g_t14) align 8 %26)
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %30, ptr align 1 %31, i64 24, i1 false)
  store ptr null, ptr %32, align 8
  %114 = load ptr, ptr %23, align 8
  %115 = call ptr @g_offset(ptr noundef %114, i64 noundef 1)
  store ptr %115, ptr %32, align 8
  %116 = load ptr, ptr %32, align 8
  call void @g_store_14(ptr noundef %116, ptr noundef byval(%struct.g_t14) align 8 %30)
  call void @llvm.memset.p0.i64(ptr align 1 %33, i8 0, i64 25, i1 false)
  call void @g_clone_13(ptr dead_on_unwind writable sret(%struct.g_t13) align 1 %34, ptr noundef byval(%struct.g_t13) align 8 %22)
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %33, ptr align 1 %34, i64 25, i1 false)
  %117 = load ptr, ptr %7, align 8
  %118 = call ptr @g_element(ptr noundef %117, i32 noundef 0, i64 noundef 2, i32 noundef 0, i64 noundef 25, i64 noundef 1, i32 noundef 0)
  call void @g_store_13(ptr noundef %118, ptr noundef byval(%struct.g_t13) align 8 %33)
  call void @llvm.memset.p0.i64(ptr align 1 %35, i8 0, i64 50, i1 false)
  call void @g_clone_16(ptr dead_on_unwind writable sret(%struct.g_t16) align 1 %36, ptr noundef byval(%struct.g_t16) align 8 %6)
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %35, ptr align 1 %36, i64 50, i1 false)
  %119 = load ptr, ptr %5, align 8
  call void @g_store_16(ptr noundef %119, ptr noundef byval(%struct.g_t16) align 8 %35)
  store ptr null, ptr %37, align 8
  %120 = call ptr @g_ref(ptr noundef %4)
  store ptr %120, ptr %37, align 8
  store i64 0, ptr %38, align 8
  store i64 0, ptr %38, align 8
  store ptr null, ptr %39, align 8
  %121 = load ptr, ptr %37, align 8
  %122 = load i64, ptr %38, align 8
  %123 = call ptr @g_element(ptr noundef %121, i32 noundef 0, i64 noundef 2, i32 noundef 0, i64 noundef 25, i64 noundef %122, i32 noundef 0)
  store ptr %123, ptr %39, align 8
  store ptr null, ptr %40, align 8
  %124 = load ptr, ptr %39, align 8
  %125 = call ptr @g_offset(ptr noundef %124, i64 noundef 1)
  store ptr %125, ptr %40, align 8
  store i64 0, ptr %41, align 8
  store i64 4, ptr %41, align 8
  store ptr null, ptr %42, align 8
  %126 = load ptr, ptr %40, align 8
  %127 = call ptr @g_push(ptr noundef %126, i32 noundef 3, i64 noundef -1, i32 noundef 0, i64 noundef 8, ptr noundef %41)
  store ptr %127, ptr %42, align 8
  store ptr null, ptr %43, align 8
  %128 = call ptr @g_ref(ptr noundef %4)
  store ptr %128, ptr %43, align 8
  store i64 0, ptr %44, align 8
  store i64 1, ptr %44, align 8
  store ptr null, ptr %45, align 8
  %129 = load ptr, ptr %43, align 8
  %130 = load i64, ptr %44, align 8
  %131 = call ptr @g_element(ptr noundef %129, i32 noundef 0, i64 noundef 2, i32 noundef 0, i64 noundef 25, i64 noundef %130, i32 noundef 0)
  store ptr %131, ptr %45, align 8
  store ptr null, ptr %46, align 8
  %132 = load ptr, ptr %45, align 8
  %133 = call ptr @g_offset(ptr noundef %132, i64 noundef 1)
  store ptr %133, ptr %46, align 8
  store i64 0, ptr %47, align 8
  store i64 5, ptr %47, align 8
  store ptr null, ptr %48, align 8
  %134 = load ptr, ptr %46, align 8
  %135 = call ptr @g_push(ptr noundef %134, i32 noundef 3, i64 noundef -1, i32 noundef 0, i64 noundef 8, ptr noundef %47)
  store ptr %135, ptr %48, align 8
  store ptr null, ptr %49, align 8
  %136 = call ptr @g_ref(ptr noundef %4)
  store ptr %136, ptr %49, align 8
  store i64 0, ptr %50, align 8
  store i64 0, ptr %50, align 8
  store ptr null, ptr %51, align 8
  %137 = load ptr, ptr %49, align 8
  %138 = load i64, ptr %50, align 8
  %139 = call ptr @g_element(ptr noundef %137, i32 noundef 0, i64 noundef 2, i32 noundef 0, i64 noundef 25, i64 noundef %138, i32 noundef 0)
  store ptr %139, ptr %51, align 8
  store ptr null, ptr %52, align 8
  %140 = load ptr, ptr %51, align 8
  %141 = call ptr @g_offset(ptr noundef %140, i64 noundef 1)
  store ptr %141, ptr %52, align 8
  store i64 0, ptr %53, align 8
  store i64 1, ptr %53, align 8
  store ptr null, ptr %54, align 8
  %142 = load ptr, ptr %52, align 8
  %143 = load i64, ptr %53, align 8
  %144 = call ptr @g_element(ptr noundef %142, i32 noundef 3, i64 noundef -1, i32 noundef 0, i64 noundef 8, i64 noundef %143, i32 noundef 0)
  store ptr %144, ptr %54, align 8
  store i64 0, ptr %55, align 8
  %145 = load ptr, ptr %54, align 8
  %146 = call i64 @g_load_5(ptr noundef %145)
  store i64 %146, ptr %55, align 8
  %147 = load i64, ptr %55, align 8
  call void @g_print_5(ptr noundef null, i64 noundef %147)
  call void @llvm.memset.p0.i64(ptr align 8 %56, i8 0, i64 16, i1 false)
  %148 = getelementptr inbounds nuw %struct.GSlice, ptr %57, i32 0, i32 0
  %149 = call ptr @g_ref(ptr noundef @.str)
  store ptr %149, ptr %148, align 8
  %150 = getelementptr inbounds nuw %struct.GSlice, ptr %57, i32 0, i32 1
  store i64 1, ptr %150, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %56, ptr align 8 %57, i64 16, i1 false)
  %151 = getelementptr inbounds nuw { ptr, i64 }, ptr %56, i32 0, i32 0
  %152 = load ptr, ptr %151, align 8
  %153 = getelementptr inbounds nuw { ptr, i64 }, ptr %56, i32 0, i32 1
  %154 = load i64, ptr %153, align 8
  call void @g_print_12(ptr noundef null, ptr %152, i64 %154)
  store ptr null, ptr %58, align 8
  %155 = call ptr @g_ref(ptr noundef %4)
  store ptr %155, ptr %58, align 8
  store i64 0, ptr %59, align 8
  store i64 1, ptr %59, align 8
  store ptr null, ptr %60, align 8
  %156 = load ptr, ptr %58, align 8
  %157 = load i64, ptr %59, align 8
  %158 = call ptr @g_element(ptr noundef %156, i32 noundef 0, i64 noundef 2, i32 noundef 0, i64 noundef 25, i64 noundef %157, i32 noundef 0)
  store ptr %158, ptr %60, align 8
  store ptr null, ptr %61, align 8
  %159 = load ptr, ptr %60, align 8
  %160 = call ptr @g_offset(ptr noundef %159, i64 noundef 1)
  store ptr %160, ptr %61, align 8
  store i64 0, ptr %62, align 8
  store i64 1, ptr %62, align 8
  store ptr null, ptr %63, align 8
  %161 = load ptr, ptr %61, align 8
  %162 = load i64, ptr %62, align 8
  %163 = call ptr @g_element(ptr noundef %161, i32 noundef 3, i64 noundef -1, i32 noundef 0, i64 noundef 8, i64 noundef %162, i32 noundef 0)
  store ptr %163, ptr %63, align 8
  store i64 0, ptr %64, align 8
  %164 = load ptr, ptr %63, align 8
  %165 = call i64 @g_load_5(ptr noundef %164)
  store i64 %165, ptr %64, align 8
  %166 = load i64, ptr %64, align 8
  call void @g_print_5(ptr noundef null, i64 noundef %166)
  call void @g_print_text(ptr noundef null, ptr noundef @.str.2)
  br label %167

167:                                              ; preds = %80, %79
  %168 = getelementptr inbounds nuw %struct.GReturnFrame, ptr %3, i32 0, i32 0
  %169 = load ptr, ptr %168, align 8
  %170 = call align 8 ptr @llvm.threadlocal.address.p0(ptr align 8 @g_return_top)
  store ptr %169, ptr %170, align 8
  ret void
}

; Function Attrs: uwtable
declare void @__ubsan_handle_type_mismatch_v1(ptr, i64) #2

; Function Attrs: nounwind
declare void @free(ptr noundef) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #3

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare nonnull ptr @llvm.threadlocal.address.p0(ptr nonnull) #4

; Function Attrs: nounwind returns_twice
declare i32 @_setjmp(ptr noundef) #5

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal ptr @g_ref(ptr noundef %0) #0 !func_sanitize !12 {
  %2 = alloca ptr, align 8
  %3 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %4 = call ptr @g_alloc(i64 noundef 32)
  store ptr %4, ptr %3, align 8
  %5 = load ptr, ptr %2, align 8
  %6 = load ptr, ptr %3, align 8
  %7 = icmp ne ptr %6, null, !nosanitize !7
  %8 = ptrtoint ptr %6 to i64, !nosanitize !7
  %9 = and i64 %8, 7, !nosanitize !7
  %10 = icmp eq i64 %9, 0, !nosanitize !7
  %11 = and i1 %7, %10, !nosanitize !7
  br i1 %11, label %13, label %12, !prof !6, !nosanitize !7

12:                                               ; preds = %1
  call void @__ubsan_handle_type_mismatch_v1(ptr @11, i64 %8) #13, !nosanitize !7
  br label %13, !nosanitize !7

13:                                               ; preds = %12, %1
  %14 = getelementptr inbounds nuw %struct.GRefCell, ptr %6, i32 0, i32 2
  %15 = icmp ne ptr %14, null, !nosanitize !7
  %16 = ptrtoint ptr %14 to i64, !nosanitize !7
  %17 = and i64 %16, 7, !nosanitize !7
  %18 = icmp eq i64 %17, 0, !nosanitize !7
  %19 = and i1 %15, %18, !nosanitize !7
  br i1 %19, label %21, label %20, !prof !6, !nosanitize !7

20:                                               ; preds = %13
  call void @__ubsan_handle_type_mismatch_v1(ptr @13, i64 %16) #13, !nosanitize !7
  br label %21, !nosanitize !7

21:                                               ; preds = %20, %13
  store ptr %5, ptr %14, align 8
  %22 = load ptr, ptr %3, align 8
  ret ptr %22
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal ptr @g_offset(ptr noundef %0, i64 noundef %1) #0 !func_sanitize !13 {
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  %5 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store i64 %1, ptr %4, align 8
  %6 = call ptr @g_alloc(i64 noundef 32)
  store ptr %6, ptr %5, align 8
  %7 = load ptr, ptr %3, align 8
  %8 = load ptr, ptr %5, align 8
  %9 = icmp ne ptr %8, null, !nosanitize !7
  %10 = ptrtoint ptr %8 to i64, !nosanitize !7
  %11 = and i64 %10, 7, !nosanitize !7
  %12 = icmp eq i64 %11, 0, !nosanitize !7
  %13 = and i1 %9, %12, !nosanitize !7
  br i1 %13, label %15, label %14, !prof !6, !nosanitize !7

14:                                               ; preds = %2
  call void @__ubsan_handle_type_mismatch_v1(ptr @20, i64 %10) #13, !nosanitize !7
  br label %15, !nosanitize !7

15:                                               ; preds = %14, %2
  %16 = getelementptr inbounds nuw %struct.GRefCell, ptr %8, i32 0, i32 0
  %17 = icmp ne ptr %16, null, !nosanitize !7
  %18 = ptrtoint ptr %16 to i64, !nosanitize !7
  %19 = and i64 %18, 7, !nosanitize !7
  %20 = icmp eq i64 %19, 0, !nosanitize !7
  %21 = and i1 %17, %20, !nosanitize !7
  br i1 %21, label %23, label %22, !prof !6, !nosanitize !7

22:                                               ; preds = %15
  call void @__ubsan_handle_type_mismatch_v1(ptr @22, i64 %18) #13, !nosanitize !7
  br label %23, !nosanitize !7

23:                                               ; preds = %22, %15
  store ptr %7, ptr %16, align 8
  %24 = load i64, ptr %4, align 8
  %25 = load ptr, ptr %5, align 8
  %26 = icmp ne ptr %25, null, !nosanitize !7
  %27 = ptrtoint ptr %25 to i64, !nosanitize !7
  %28 = and i64 %27, 7, !nosanitize !7
  %29 = icmp eq i64 %28, 0, !nosanitize !7
  %30 = and i1 %26, %29, !nosanitize !7
  br i1 %30, label %32, label %31, !prof !6, !nosanitize !7

31:                                               ; preds = %23
  call void @__ubsan_handle_type_mismatch_v1(ptr @23, i64 %27) #13, !nosanitize !7
  br label %32, !nosanitize !7

32:                                               ; preds = %31, %23
  %33 = getelementptr inbounds nuw %struct.GRefCell, ptr %25, i32 0, i32 3
  %34 = icmp ne ptr %33, null, !nosanitize !7
  %35 = ptrtoint ptr %33 to i64, !nosanitize !7
  %36 = and i64 %35, 7, !nosanitize !7
  %37 = icmp eq i64 %36, 0, !nosanitize !7
  %38 = and i1 %34, %37, !nosanitize !7
  br i1 %38, label %40, label %39, !prof !6, !nosanitize !7

39:                                               ; preds = %32
  call void @__ubsan_handle_type_mismatch_v1(ptr @24, i64 %35) #13, !nosanitize !7
  br label %40, !nosanitize !7

40:                                               ; preds = %39, %32
  store i64 %24, ptr %33, align 8
  %41 = load ptr, ptr %5, align 8
  ret ptr %41
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @g_store_6(ptr noundef %0, i8 noundef zeroext %1) #0 !func_sanitize !14 {
  %3 = alloca ptr, align 8
  %4 = alloca i8, align 1
  store ptr %0, ptr %3, align 8
  store i8 %1, ptr %4, align 1
  %5 = load ptr, ptr %3, align 8
  %6 = call ptr @g_address(ptr noundef %5)
  %7 = icmp ne ptr %6, null, !nosanitize !7
  br i1 %7, label %9, label %8, !prof !6, !nosanitize !7

8:                                                ; preds = %2
  call void @__ubsan_handle_nonnull_arg(ptr @25) #13, !nosanitize !7
  br label %9, !nosanitize !7

9:                                                ; preds = %8, %2
  %10 = icmp ne ptr %4, null, !nosanitize !7
  br i1 %10, label %12, label %11, !prof !6, !nosanitize !7

11:                                               ; preds = %9
  call void @__ubsan_handle_nonnull_arg(ptr @26) #13, !nosanitize !7
  br label %12, !nosanitize !7

12:                                               ; preds = %11, %9
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %6, ptr align 1 %4, i64 1, i1 false)
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @g_reserve(ptr noundef %0, i32 noundef %1, i64 noundef %2, i32 noundef %3, i64 noundef %4, i64 noundef %5) #0 !func_sanitize !15 {
  %7 = alloca ptr, align 8
  %8 = alloca i32, align 4
  %9 = alloca i64, align 8
  %10 = alloca i32, align 4
  %11 = alloca i64, align 8
  %12 = alloca i64, align 8
  %13 = alloca %struct.GArray, align 8
  %14 = alloca i64, align 8
  %15 = alloca ptr, align 8
  store ptr %0, ptr %7, align 8
  store i32 %1, ptr %8, align 4
  store i64 %2, ptr %9, align 8
  store i32 %3, ptr %10, align 4
  store i64 %4, ptr %11, align 8
  store i64 %5, ptr %12, align 8
  %16 = load i64, ptr %12, align 8
  %17 = icmp slt i64 %16, 0
  br i1 %17, label %32, label %18

18:                                               ; preds = %6
  %19 = load i64, ptr %11, align 8
  %20 = icmp ne i64 %19, 0
  br i1 %20, label %21, label %33

21:                                               ; preds = %18
  %22 = load i64, ptr %12, align 8
  %23 = load i64, ptr %11, align 8
  %24 = icmp ne i64 %23, 0, !nosanitize !7
  %25 = icmp ne i64 %23, -1, !nosanitize !7
  %26 = or i1 true, %25, !nosanitize !7
  %27 = and i1 %24, %26, !nosanitize !7
  br i1 %27, label %29, label %28, !prof !6, !nosanitize !7

28:                                               ; preds = %21
  call void @__ubsan_handle_divrem_overflow(ptr @47, i64 9223372036854775807, i64 %23) #13, !nosanitize !7
  br label %29, !nosanitize !7

29:                                               ; preds = %28, %21
  %30 = sdiv i64 9223372036854775807, %23
  %31 = icmp sgt i64 %22, %30
  br i1 %31, label %32, label %33

32:                                               ; preds = %29, %6
  call void @g_panic(ptr noundef @.str.8)
  br label %33

33:                                               ; preds = %32, %29, %18
  %34 = load i32, ptr %8, align 4
  %35 = icmp eq i32 %34, 2
  br i1 %35, label %36, label %45

36:                                               ; preds = %33
  %37 = load i64, ptr %9, align 8
  %38 = icmp sge i64 %37, 0
  br i1 %38, label %39, label %45

39:                                               ; preds = %36
  %40 = load i64, ptr %12, align 8
  %41 = load i64, ptr %9, align 8
  %42 = icmp sgt i64 %40, %41
  br i1 %42, label %43, label %44

43:                                               ; preds = %39
  call void @g_panic(ptr noundef @.str.9)
  br label %44

44:                                               ; preds = %43, %39
  br label %173

45:                                               ; preds = %36, %33
  %46 = load i32, ptr %8, align 4
  %47 = icmp ne i32 %46, 3
  br i1 %47, label %48, label %55

48:                                               ; preds = %45
  %49 = load i32, ptr %8, align 4
  %50 = icmp ne i32 %49, 4
  br i1 %50, label %51, label %55

51:                                               ; preds = %48
  %52 = load i32, ptr %8, align 4
  %53 = icmp ne i32 %52, 2
  br i1 %53, label %54, label %55

54:                                               ; preds = %51
  call void @g_panic(ptr noundef @.str.10)
  br label %55

55:                                               ; preds = %54, %51, %48, %45
  %56 = load ptr, ptr %7, align 8
  %57 = call ptr @g_address(ptr noundef %56)
  %58 = icmp ne ptr %13, null, !nosanitize !7
  br i1 %58, label %60, label %59, !prof !6, !nosanitize !7

59:                                               ; preds = %55
  call void @__ubsan_handle_nonnull_arg(ptr @48) #13, !nosanitize !7
  br label %60, !nosanitize !7

60:                                               ; preds = %59, %55
  %61 = icmp ne ptr %57, null, !nosanitize !7
  br i1 %61, label %63, label %62, !prof !6, !nosanitize !7

62:                                               ; preds = %60
  call void @__ubsan_handle_nonnull_arg(ptr @49) #13, !nosanitize !7
  br label %63, !nosanitize !7

63:                                               ; preds = %62, %60
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %13, ptr align 1 %57, i64 24, i1 false)
  %64 = load i64, ptr %12, align 8
  %65 = getelementptr inbounds nuw %struct.GArray, ptr %13, i32 0, i32 2
  %66 = ptrtoint ptr %65 to i64, !nosanitize !7
  %67 = and i64 %66, 7, !nosanitize !7
  %68 = icmp eq i64 %67, 0, !nosanitize !7
  br i1 %68, label %70, label %69, !prof !6, !nosanitize !7

69:                                               ; preds = %63
  call void @__ubsan_handle_type_mismatch_v1(ptr @50, i64 %66) #13, !nosanitize !7
  br label %70, !nosanitize !7

70:                                               ; preds = %69, %63
  %71 = load i64, ptr %65, align 8
  %72 = icmp sgt i64 %64, %71
  br i1 %72, label %73, label %173

73:                                               ; preds = %70
  %74 = getelementptr inbounds nuw %struct.GArray, ptr %13, i32 0, i32 2
  %75 = ptrtoint ptr %74 to i64, !nosanitize !7
  %76 = and i64 %75, 7, !nosanitize !7
  %77 = icmp eq i64 %76, 0, !nosanitize !7
  br i1 %77, label %79, label %78, !prof !6, !nosanitize !7

78:                                               ; preds = %73
  call void @__ubsan_handle_type_mismatch_v1(ptr @51, i64 %75) #13, !nosanitize !7
  br label %79, !nosanitize !7

79:                                               ; preds = %78, %73
  %80 = load i64, ptr %74, align 8
  %81 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %80, i64 2), !nosanitize !7
  %82 = extractvalue { i64, i1 } %81, 0, !nosanitize !7
  %83 = extractvalue { i64, i1 } %81, 1, !nosanitize !7
  %84 = xor i1 %83, true, !nosanitize !7
  br i1 %84, label %86, label %85, !prof !6, !nosanitize !7

85:                                               ; preds = %79
  call void @__ubsan_handle_mul_overflow(ptr @52, i64 %80, i64 2) #13, !nosanitize !7
  br label %86, !nosanitize !7

86:                                               ; preds = %85, %79
  %87 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %82, i64 8), !nosanitize !7
  %88 = extractvalue { i64, i1 } %87, 0, !nosanitize !7
  %89 = extractvalue { i64, i1 } %87, 1, !nosanitize !7
  %90 = xor i1 %89, true, !nosanitize !7
  br i1 %90, label %92, label %91, !prof !6, !nosanitize !7

91:                                               ; preds = %86
  call void @__ubsan_handle_add_overflow(ptr @53, i64 %82, i64 8) #13, !nosanitize !7
  br label %92, !nosanitize !7

92:                                               ; preds = %91, %86
  store i64 %88, ptr %14, align 8
  %93 = load i64, ptr %14, align 8
  %94 = load i64, ptr %12, align 8
  %95 = icmp slt i64 %93, %94
  br i1 %95, label %96, label %98

96:                                               ; preds = %92
  %97 = load i64, ptr %12, align 8
  store i64 %97, ptr %14, align 8
  br label %98

98:                                               ; preds = %96, %92
  %99 = load i64, ptr %11, align 8
  %100 = icmp ne i64 %99, 0
  br i1 %100, label %101, label %113

101:                                              ; preds = %98
  %102 = load i64, ptr %14, align 8
  %103 = load i64, ptr %11, align 8
  %104 = icmp ne i64 %103, 0, !nosanitize !7
  %105 = icmp ne i64 %103, -1, !nosanitize !7
  %106 = or i1 true, %105, !nosanitize !7
  %107 = and i1 %104, %106, !nosanitize !7
  br i1 %107, label %109, label %108, !prof !6, !nosanitize !7

108:                                              ; preds = %101
  call void @__ubsan_handle_divrem_overflow(ptr @54, i64 9223372036854775807, i64 %103) #13, !nosanitize !7
  br label %109, !nosanitize !7

109:                                              ; preds = %108, %101
  %110 = sdiv i64 9223372036854775807, %103
  %111 = icmp sgt i64 %102, %110
  br i1 %111, label %112, label %113

112:                                              ; preds = %109
  call void @g_panic(ptr noundef @.str.11)
  br label %113

113:                                              ; preds = %112, %109, %98
  %114 = load i64, ptr %14, align 8
  %115 = load i64, ptr %11, align 8
  %116 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %114, i64 %115), !nosanitize !7
  %117 = extractvalue { i64, i1 } %116, 0, !nosanitize !7
  %118 = extractvalue { i64, i1 } %116, 1, !nosanitize !7
  %119 = xor i1 %118, true, !nosanitize !7
  br i1 %119, label %121, label %120, !prof !6, !nosanitize !7

120:                                              ; preds = %113
  call void @__ubsan_handle_mul_overflow(ptr @55, i64 %114, i64 %115) #13, !nosanitize !7
  br label %121, !nosanitize !7

121:                                              ; preds = %120, %113
  %122 = call ptr @g_alloc(i64 noundef %117)
  store ptr %122, ptr %15, align 8
  %123 = getelementptr inbounds nuw %struct.GArray, ptr %13, i32 0, i32 1
  %124 = ptrtoint ptr %123 to i64, !nosanitize !7
  %125 = and i64 %124, 7, !nosanitize !7
  %126 = icmp eq i64 %125, 0, !nosanitize !7
  br i1 %126, label %128, label %127, !prof !6, !nosanitize !7

127:                                              ; preds = %121
  call void @__ubsan_handle_type_mismatch_v1(ptr @56, i64 %124) #13, !nosanitize !7
  br label %128, !nosanitize !7

128:                                              ; preds = %127, %121
  %129 = load i64, ptr %123, align 8
  %130 = icmp ne i64 %129, 0
  br i1 %130, label %131, label %155

131:                                              ; preds = %128
  %132 = load ptr, ptr %15, align 8
  %133 = getelementptr inbounds nuw %struct.GArray, ptr %13, i32 0, i32 0
  %134 = load ptr, ptr %133, align 8
  %135 = getelementptr inbounds nuw %struct.GArray, ptr %13, i32 0, i32 1
  %136 = ptrtoint ptr %135 to i64, !nosanitize !7
  %137 = and i64 %136, 7, !nosanitize !7
  %138 = icmp eq i64 %137, 0, !nosanitize !7
  br i1 %138, label %140, label %139, !prof !6, !nosanitize !7

139:                                              ; preds = %131
  call void @__ubsan_handle_type_mismatch_v1(ptr @57, i64 %136) #13, !nosanitize !7
  br label %140, !nosanitize !7

140:                                              ; preds = %139, %131
  %141 = load i64, ptr %135, align 8
  %142 = load i64, ptr %11, align 8
  %143 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %141, i64 %142), !nosanitize !7
  %144 = extractvalue { i64, i1 } %143, 0, !nosanitize !7
  %145 = extractvalue { i64, i1 } %143, 1, !nosanitize !7
  %146 = xor i1 %145, true, !nosanitize !7
  br i1 %146, label %148, label %147, !prof !6, !nosanitize !7

147:                                              ; preds = %140
  call void @__ubsan_handle_mul_overflow(ptr @58, i64 %141, i64 %142) #13, !nosanitize !7
  br label %148, !nosanitize !7

148:                                              ; preds = %147, %140
  %149 = icmp ne ptr %132, null, !nosanitize !7
  br i1 %149, label %151, label %150, !prof !6, !nosanitize !7

150:                                              ; preds = %148
  call void @__ubsan_handle_nonnull_arg(ptr @59) #13, !nosanitize !7
  br label %151, !nosanitize !7

151:                                              ; preds = %150, %148
  %152 = icmp ne ptr %134, null, !nosanitize !7
  br i1 %152, label %154, label %153, !prof !6, !nosanitize !7

153:                                              ; preds = %151
  call void @__ubsan_handle_nonnull_arg(ptr @60) #13, !nosanitize !7
  br label %154, !nosanitize !7

154:                                              ; preds = %153, %151
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %132, ptr align 1 %134, i64 %144, i1 false)
  br label %155

155:                                              ; preds = %154, %128
  %156 = load ptr, ptr %15, align 8
  %157 = getelementptr inbounds nuw %struct.GArray, ptr %13, i32 0, i32 0
  store ptr %156, ptr %157, align 8
  %158 = load i64, ptr %14, align 8
  %159 = getelementptr inbounds nuw %struct.GArray, ptr %13, i32 0, i32 2
  %160 = ptrtoint ptr %159 to i64, !nosanitize !7
  %161 = and i64 %160, 7, !nosanitize !7
  %162 = icmp eq i64 %161, 0, !nosanitize !7
  br i1 %162, label %164, label %163, !prof !6, !nosanitize !7

163:                                              ; preds = %155
  call void @__ubsan_handle_type_mismatch_v1(ptr @61, i64 %160) #13, !nosanitize !7
  br label %164, !nosanitize !7

164:                                              ; preds = %163, %155
  store i64 %158, ptr %159, align 8
  %165 = load ptr, ptr %7, align 8
  %166 = call ptr @g_address(ptr noundef %165)
  %167 = icmp ne ptr %166, null, !nosanitize !7
  br i1 %167, label %169, label %168, !prof !6, !nosanitize !7

168:                                              ; preds = %164
  call void @__ubsan_handle_nonnull_arg(ptr @62) #13, !nosanitize !7
  br label %169, !nosanitize !7

169:                                              ; preds = %168, %164
  %170 = icmp ne ptr %13, null, !nosanitize !7
  br i1 %170, label %172, label %171, !prof !6, !nosanitize !7

171:                                              ; preds = %169
  call void @__ubsan_handle_nonnull_arg(ptr @63) #13, !nosanitize !7
  br label %172, !nosanitize !7

172:                                              ; preds = %171, %169
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %166, ptr align 8 %13, i64 24, i1 false)
  br label %173

173:                                              ; preds = %44, %172, %70
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @g_set_len(ptr noundef %0, i32 noundef %1, i64 noundef %2, i32 noundef %3, i64 noundef %4) #0 !func_sanitize !16 {
  %6 = alloca ptr, align 8
  %7 = alloca i32, align 4
  %8 = alloca i64, align 8
  %9 = alloca i32, align 4
  %10 = alloca i64, align 8
  %11 = alloca %struct.GArray, align 8
  store ptr %0, ptr %6, align 8
  store i32 %1, ptr %7, align 4
  store i64 %2, ptr %8, align 8
  store i32 %3, ptr %9, align 4
  store i64 %4, ptr %10, align 8
  %12 = load i32, ptr %7, align 4
  %13 = icmp eq i32 %12, 2
  br i1 %13, label %14, label %22

14:                                               ; preds = %5
  %15 = load i64, ptr %8, align 8
  %16 = icmp sge i64 %15, 0
  br i1 %16, label %17, label %22

17:                                               ; preds = %14
  %18 = load ptr, ptr %6, align 8
  %19 = call ptr @g_address(ptr noundef %18)
  %20 = load i32, ptr %9, align 4
  %21 = load i64, ptr %10, align 8
  call void @g_write_length(ptr noundef %19, i32 noundef %20, i64 noundef %21)
  br label %46

22:                                               ; preds = %14, %5
  %23 = load ptr, ptr %6, align 8
  %24 = call ptr @g_address(ptr noundef %23)
  %25 = icmp ne ptr %11, null, !nosanitize !7
  br i1 %25, label %27, label %26, !prof !6, !nosanitize !7

26:                                               ; preds = %22
  call void @__ubsan_handle_nonnull_arg(ptr @64) #13, !nosanitize !7
  br label %27, !nosanitize !7

27:                                               ; preds = %26, %22
  %28 = icmp ne ptr %24, null, !nosanitize !7
  br i1 %28, label %30, label %29, !prof !6, !nosanitize !7

29:                                               ; preds = %27
  call void @__ubsan_handle_nonnull_arg(ptr @65) #13, !nosanitize !7
  br label %30, !nosanitize !7

30:                                               ; preds = %29, %27
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %11, ptr align 1 %24, i64 24, i1 false)
  %31 = load i64, ptr %10, align 8
  %32 = getelementptr inbounds nuw %struct.GArray, ptr %11, i32 0, i32 1
  %33 = ptrtoint ptr %32 to i64, !nosanitize !7
  %34 = and i64 %33, 7, !nosanitize !7
  %35 = icmp eq i64 %34, 0, !nosanitize !7
  br i1 %35, label %37, label %36, !prof !6, !nosanitize !7

36:                                               ; preds = %30
  call void @__ubsan_handle_type_mismatch_v1(ptr @66, i64 %33) #13, !nosanitize !7
  br label %37, !nosanitize !7

37:                                               ; preds = %36, %30
  store i64 %31, ptr %32, align 8
  %38 = load ptr, ptr %6, align 8
  %39 = call ptr @g_address(ptr noundef %38)
  %40 = icmp ne ptr %39, null, !nosanitize !7
  br i1 %40, label %42, label %41, !prof !6, !nosanitize !7

41:                                               ; preds = %37
  call void @__ubsan_handle_nonnull_arg(ptr @67) #13, !nosanitize !7
  br label %42, !nosanitize !7

42:                                               ; preds = %41, %37
  %43 = icmp ne ptr %11, null, !nosanitize !7
  br i1 %43, label %45, label %44, !prof !6, !nosanitize !7

44:                                               ; preds = %42
  call void @__ubsan_handle_nonnull_arg(ptr @68) #13, !nosanitize !7
  br label %45, !nosanitize !7

45:                                               ; preds = %44, %42
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %39, ptr align 8 %11, i64 24, i1 false)
  br label %46

46:                                               ; preds = %45, %17
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @g_store_5(ptr noundef %0, i64 noundef %1) #0 !func_sanitize !17 {
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  store ptr %0, ptr %3, align 8
  store i64 %1, ptr %4, align 8
  %5 = load ptr, ptr %3, align 8
  %6 = call ptr @g_address(ptr noundef %5)
  %7 = icmp ne ptr %6, null, !nosanitize !7
  br i1 %7, label %9, label %8, !prof !6, !nosanitize !7

8:                                                ; preds = %2
  call void @__ubsan_handle_nonnull_arg(ptr @71) #13, !nosanitize !7
  br label %9, !nosanitize !7

9:                                                ; preds = %8, %2
  %10 = icmp ne ptr %4, null, !nosanitize !7
  br i1 %10, label %12, label %11, !prof !6, !nosanitize !7

11:                                               ; preds = %9
  call void @__ubsan_handle_nonnull_arg(ptr @72) #13, !nosanitize !7
  br label %12, !nosanitize !7

12:                                               ; preds = %11, %9
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %6, ptr align 8 %4, i64 8, i1 false)
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal ptr @g_element(ptr noundef %0, i32 noundef %1, i64 noundef %2, i32 noundef %3, i64 noundef %4, i64 noundef %5, i32 noundef %6) #0 !func_sanitize !18 {
  %8 = alloca ptr, align 8
  %9 = alloca ptr, align 8
  %10 = alloca i32, align 4
  %11 = alloca i64, align 8
  %12 = alloca i32, align 4
  %13 = alloca i64, align 8
  %14 = alloca i64, align 8
  %15 = alloca i32, align 4
  %16 = alloca i64, align 8
  %17 = alloca %struct.GSlice, align 8
  store ptr %0, ptr %9, align 8
  store i32 %1, ptr %10, align 4
  store i64 %2, ptr %11, align 8
  store i32 %3, ptr %12, align 4
  store i64 %4, ptr %13, align 8
  store i64 %5, ptr %14, align 8
  store i32 %6, ptr %15, align 4
  %18 = load ptr, ptr %9, align 8
  %19 = load i32, ptr %10, align 4
  %20 = load i64, ptr %11, align 8
  %21 = load i32, ptr %12, align 4
  %22 = call i64 @g_len(ptr noundef %18, i32 noundef %19, i64 noundef %20, i32 noundef %21)
  store i64 %22, ptr %16, align 8
  %23 = load i64, ptr %14, align 8
  %24 = icmp slt i64 %23, 0
  br i1 %24, label %36, label %25

25:                                               ; preds = %7
  %26 = load i64, ptr %14, align 8
  %27 = load i64, ptr %16, align 8
  %28 = icmp sgt i64 %26, %27
  br i1 %28, label %36, label %29

29:                                               ; preds = %25
  %30 = load i32, ptr %15, align 4
  %31 = icmp ne i32 %30, 0
  br i1 %31, label %37, label %32

32:                                               ; preds = %29
  %33 = load i64, ptr %14, align 8
  %34 = load i64, ptr %16, align 8
  %35 = icmp eq i64 %33, %34
  br i1 %35, label %36, label %37

36:                                               ; preds = %32, %25, %7
  call void @g_panic(ptr noundef @.str.12)
  br label %37

37:                                               ; preds = %36, %32, %29
  %38 = load i64, ptr %13, align 8
  %39 = icmp ne i64 %38, 0
  br i1 %39, label %40, label %52

40:                                               ; preds = %37
  %41 = load i64, ptr %14, align 8
  %42 = load i64, ptr %13, align 8
  %43 = icmp ne i64 %42, 0, !nosanitize !7
  %44 = icmp ne i64 %42, -1, !nosanitize !7
  %45 = or i1 true, %44, !nosanitize !7
  %46 = and i1 %43, %45, !nosanitize !7
  br i1 %46, label %48, label %47, !prof !6, !nosanitize !7

47:                                               ; preds = %40
  call void @__ubsan_handle_divrem_overflow(ptr @73, i64 9223372036854775807, i64 %42) #13, !nosanitize !7
  br label %48, !nosanitize !7

48:                                               ; preds = %47, %40
  %49 = sdiv i64 9223372036854775807, %42
  %50 = icmp sgt i64 %41, %49
  br i1 %50, label %51, label %52

51:                                               ; preds = %48
  call void @g_panic(ptr noundef @.str.13)
  br label %52

52:                                               ; preds = %51, %48, %37
  %53 = load i32, ptr %10, align 4
  %54 = icmp eq i32 %53, 5
  br i1 %54, label %55, label %75

55:                                               ; preds = %52
  %56 = load ptr, ptr %9, align 8
  %57 = call ptr @g_address(ptr noundef %56)
  %58 = icmp ne ptr %17, null, !nosanitize !7
  br i1 %58, label %60, label %59, !prof !6, !nosanitize !7

59:                                               ; preds = %55
  call void @__ubsan_handle_nonnull_arg(ptr @74) #13, !nosanitize !7
  br label %60, !nosanitize !7

60:                                               ; preds = %59, %55
  %61 = icmp ne ptr %57, null, !nosanitize !7
  br i1 %61, label %63, label %62, !prof !6, !nosanitize !7

62:                                               ; preds = %60
  call void @__ubsan_handle_nonnull_arg(ptr @75) #13, !nosanitize !7
  br label %63, !nosanitize !7

63:                                               ; preds = %62, %60
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %17, ptr align 1 %57, i64 16, i1 false)
  %64 = getelementptr inbounds nuw %struct.GSlice, ptr %17, i32 0, i32 0
  %65 = load ptr, ptr %64, align 8
  %66 = load i64, ptr %14, align 8
  %67 = load i64, ptr %13, align 8
  %68 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %66, i64 %67), !nosanitize !7
  %69 = extractvalue { i64, i1 } %68, 0, !nosanitize !7
  %70 = extractvalue { i64, i1 } %68, 1, !nosanitize !7
  %71 = xor i1 %70, true, !nosanitize !7
  br i1 %71, label %73, label %72, !prof !6, !nosanitize !7

72:                                               ; preds = %63
  call void @__ubsan_handle_mul_overflow(ptr @76, i64 %66, i64 %67) #13, !nosanitize !7
  br label %73, !nosanitize !7

73:                                               ; preds = %72, %63
  %74 = call ptr @g_offset(ptr noundef %65, i64 noundef %69)
  store ptr %74, ptr %8, align 8
  br label %126

75:                                               ; preds = %52
  %76 = load i32, ptr %10, align 4
  %77 = icmp eq i32 %76, 0
  br i1 %77, label %78, label %89

78:                                               ; preds = %75
  %79 = load ptr, ptr %9, align 8
  %80 = load i64, ptr %14, align 8
  %81 = load i64, ptr %13, align 8
  %82 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %80, i64 %81), !nosanitize !7
  %83 = extractvalue { i64, i1 } %82, 0, !nosanitize !7
  %84 = extractvalue { i64, i1 } %82, 1, !nosanitize !7
  %85 = xor i1 %84, true, !nosanitize !7
  br i1 %85, label %87, label %86, !prof !6, !nosanitize !7

86:                                               ; preds = %78
  call void @__ubsan_handle_mul_overflow(ptr @77, i64 %80, i64 %81) #13, !nosanitize !7
  br label %87, !nosanitize !7

87:                                               ; preds = %86, %78
  %88 = call ptr @g_offset(ptr noundef %79, i64 noundef %83)
  store ptr %88, ptr %8, align 8
  br label %126

89:                                               ; preds = %75
  %90 = load i32, ptr %10, align 4
  %91 = icmp eq i32 %90, 2
  br i1 %91, label %92, label %114

92:                                               ; preds = %89
  %93 = load i64, ptr %11, align 8
  %94 = icmp sge i64 %93, 0
  br i1 %94, label %95, label %114

95:                                               ; preds = %92
  %96 = load ptr, ptr %9, align 8
  %97 = load i32, ptr %12, align 4
  %98 = sext i32 %97 to i64
  %99 = load i64, ptr %14, align 8
  %100 = load i64, ptr %13, align 8
  %101 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %99, i64 %100), !nosanitize !7
  %102 = extractvalue { i64, i1 } %101, 0, !nosanitize !7
  %103 = extractvalue { i64, i1 } %101, 1, !nosanitize !7
  %104 = xor i1 %103, true, !nosanitize !7
  br i1 %104, label %106, label %105, !prof !6, !nosanitize !7

105:                                              ; preds = %95
  call void @__ubsan_handle_mul_overflow(ptr @78, i64 %99, i64 %100) #13, !nosanitize !7
  br label %106, !nosanitize !7

106:                                              ; preds = %105, %95
  %107 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %98, i64 %102), !nosanitize !7
  %108 = extractvalue { i64, i1 } %107, 0, !nosanitize !7
  %109 = extractvalue { i64, i1 } %107, 1, !nosanitize !7
  %110 = xor i1 %109, true, !nosanitize !7
  br i1 %110, label %112, label %111, !prof !6, !nosanitize !7

111:                                              ; preds = %106
  call void @__ubsan_handle_add_overflow(ptr @79, i64 %98, i64 %102) #13, !nosanitize !7
  br label %112, !nosanitize !7

112:                                              ; preds = %111, %106
  %113 = call ptr @g_offset(ptr noundef %96, i64 noundef %108)
  store ptr %113, ptr %8, align 8
  br label %126

114:                                              ; preds = %92, %89
  %115 = load ptr, ptr %9, align 8
  %116 = call ptr @g_address(ptr noundef %115)
  %117 = load i64, ptr %14, align 8
  %118 = load i64, ptr %13, align 8
  %119 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %117, i64 %118), !nosanitize !7
  %120 = extractvalue { i64, i1 } %119, 0, !nosanitize !7
  %121 = extractvalue { i64, i1 } %119, 1, !nosanitize !7
  %122 = xor i1 %121, true, !nosanitize !7
  br i1 %122, label %124, label %123, !prof !6, !nosanitize !7

123:                                              ; preds = %114
  call void @__ubsan_handle_mul_overflow(ptr @80, i64 %117, i64 %118) #13, !nosanitize !7
  br label %124, !nosanitize !7

124:                                              ; preds = %123, %114
  %125 = call ptr @g_moving(ptr noundef %116, i64 noundef %120)
  store ptr %125, ptr %8, align 8
  br label %126

126:                                              ; preds = %124, %112, %87, %73
  %127 = load ptr, ptr %8, align 8
  ret ptr %127
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @g_clone_14(ptr dead_on_unwind noalias writable sret(%struct.g_t14) align 1 %0, ptr noundef byval(%struct.g_t14) align 8 %1) #0 !func_sanitize !19 {
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  %5 = alloca %struct.GArray, align 8
  %6 = alloca %struct.GArray, align 8
  %7 = alloca ptr, align 8
  %8 = alloca i64, align 8
  %9 = call ptr @g_ref(ptr noundef %1)
  store ptr %9, ptr %3, align 8
  %10 = load ptr, ptr %3, align 8
  %11 = call i64 @g_len(ptr noundef %10, i32 noundef 3, i64 noundef -1, i32 noundef 0)
  store i64 %11, ptr %4, align 8
  %12 = icmp ne ptr %5, null, !nosanitize !7
  br i1 %12, label %14, label %13, !prof !6, !nosanitize !7

13:                                               ; preds = %2
  call void @__ubsan_handle_nonnull_arg(ptr @93) #13, !nosanitize !7
  br label %14, !nosanitize !7

14:                                               ; preds = %13, %2
  %15 = icmp ne ptr %1, null, !nosanitize !7
  br i1 %15, label %17, label %16, !prof !6, !nosanitize !7

16:                                               ; preds = %14
  call void @__ubsan_handle_nonnull_arg(ptr @94) #13, !nosanitize !7
  br label %17, !nosanitize !7

17:                                               ; preds = %16, %14
  %18 = ptrtoint ptr %1 to i64, !nosanitize !7
  %19 = and i64 %18, 7, !nosanitize !7
  %20 = icmp eq i64 %19, 0, !nosanitize !7
  br i1 %20, label %22, label %21, !prof !6, !nosanitize !7

21:                                               ; preds = %17
  call void @__ubsan_handle_type_mismatch_v1(ptr @96, i64 %18) #13, !nosanitize !7
  br label %22, !nosanitize !7

22:                                               ; preds = %21, %17
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %5, ptr align 8 %1, i64 24, i1 false)
  call void @llvm.memset.p0.i64(ptr align 8 %6, i8 0, i64 24, i1 false)
  %23 = getelementptr inbounds nuw %struct.GArray, ptr %5, i32 0, i32 1
  %24 = ptrtoint ptr %23 to i64, !nosanitize !7
  %25 = and i64 %24, 7, !nosanitize !7
  %26 = icmp eq i64 %25, 0, !nosanitize !7
  br i1 %26, label %28, label %27, !prof !6, !nosanitize !7

27:                                               ; preds = %22
  call void @__ubsan_handle_type_mismatch_v1(ptr @97, i64 %24) #13, !nosanitize !7
  br label %28, !nosanitize !7

28:                                               ; preds = %27, %22
  %29 = load i64, ptr %23, align 8
  %30 = getelementptr inbounds nuw %struct.GArray, ptr %6, i32 0, i32 1
  %31 = ptrtoint ptr %30 to i64, !nosanitize !7
  %32 = and i64 %31, 7, !nosanitize !7
  %33 = icmp eq i64 %32, 0, !nosanitize !7
  br i1 %33, label %35, label %34, !prof !6, !nosanitize !7

34:                                               ; preds = %28
  call void @__ubsan_handle_type_mismatch_v1(ptr @98, i64 %31) #13, !nosanitize !7
  br label %35, !nosanitize !7

35:                                               ; preds = %34, %28
  store i64 %29, ptr %30, align 8
  %36 = getelementptr inbounds nuw %struct.GArray, ptr %5, i32 0, i32 2
  %37 = ptrtoint ptr %36 to i64, !nosanitize !7
  %38 = and i64 %37, 7, !nosanitize !7
  %39 = icmp eq i64 %38, 0, !nosanitize !7
  br i1 %39, label %41, label %40, !prof !6, !nosanitize !7

40:                                               ; preds = %35
  call void @__ubsan_handle_type_mismatch_v1(ptr @99, i64 %37) #13, !nosanitize !7
  br label %41, !nosanitize !7

41:                                               ; preds = %40, %35
  %42 = load i64, ptr %36, align 8
  %43 = getelementptr inbounds nuw %struct.GArray, ptr %6, i32 0, i32 2
  %44 = ptrtoint ptr %43 to i64, !nosanitize !7
  %45 = and i64 %44, 7, !nosanitize !7
  %46 = icmp eq i64 %45, 0, !nosanitize !7
  br i1 %46, label %48, label %47, !prof !6, !nosanitize !7

47:                                               ; preds = %41
  call void @__ubsan_handle_type_mismatch_v1(ptr @100, i64 %44) #13, !nosanitize !7
  br label %48, !nosanitize !7

48:                                               ; preds = %47, %41
  store i64 %42, ptr %43, align 8
  %49 = getelementptr inbounds nuw %struct.GArray, ptr %6, i32 0, i32 2
  %50 = ptrtoint ptr %49 to i64, !nosanitize !7
  %51 = and i64 %50, 7, !nosanitize !7
  %52 = icmp eq i64 %51, 0, !nosanitize !7
  br i1 %52, label %54, label %53, !prof !6, !nosanitize !7

53:                                               ; preds = %48
  call void @__ubsan_handle_type_mismatch_v1(ptr @101, i64 %50) #13, !nosanitize !7
  br label %54, !nosanitize !7

54:                                               ; preds = %53, %48
  %55 = load i64, ptr %49, align 8
  %56 = mul i64 %55, 8
  %57 = call ptr @g_alloc(i64 noundef %56)
  %58 = getelementptr inbounds nuw %struct.GArray, ptr %6, i32 0, i32 0
  store ptr %57, ptr %58, align 8
  %59 = icmp ne ptr %1, null, !nosanitize !7
  br i1 %59, label %61, label %60, !prof !6, !nosanitize !7

60:                                               ; preds = %54
  call void @__ubsan_handle_nonnull_arg(ptr @102) #13, !nosanitize !7
  br label %61, !nosanitize !7

61:                                               ; preds = %60, %54
  %62 = ptrtoint ptr %1 to i64, !nosanitize !7
  %63 = and i64 %62, 7, !nosanitize !7
  %64 = icmp eq i64 %63, 0, !nosanitize !7
  br i1 %64, label %66, label %65, !prof !6, !nosanitize !7

65:                                               ; preds = %61
  call void @__ubsan_handle_type_mismatch_v1(ptr @103, i64 %62) #13, !nosanitize !7
  br label %66, !nosanitize !7

66:                                               ; preds = %65, %61
  %67 = icmp ne ptr %6, null, !nosanitize !7
  br i1 %67, label %69, label %68, !prof !6, !nosanitize !7

68:                                               ; preds = %66
  call void @__ubsan_handle_nonnull_arg(ptr @104) #13, !nosanitize !7
  br label %69, !nosanitize !7

69:                                               ; preds = %68, %66
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %6, i64 24, i1 false)
  %70 = call ptr @g_ref(ptr noundef %5)
  store ptr %70, ptr %3, align 8
  %71 = call ptr @g_ref(ptr noundef %1)
  store ptr %71, ptr %7, align 8
  store i64 0, ptr %8, align 8
  br label %72

72:                                               ; preds = %92, %69
  %73 = load i64, ptr %8, align 8
  %74 = load i64, ptr %4, align 8
  %75 = icmp slt i64 %73, %74
  br i1 %75, label %76, label %93

76:                                               ; preds = %72
  %77 = load ptr, ptr %7, align 8
  %78 = load i64, ptr %8, align 8
  %79 = call ptr @g_element(ptr noundef %77, i32 noundef 3, i64 noundef -1, i32 noundef 0, i64 noundef 8, i64 noundef %78, i32 noundef 0)
  %80 = load ptr, ptr %3, align 8
  %81 = load i64, ptr %8, align 8
  %82 = call ptr @g_element(ptr noundef %80, i32 noundef 3, i64 noundef -1, i32 noundef 0, i64 noundef 8, i64 noundef %81, i32 noundef 0)
  %83 = call i64 @g_load_5(ptr noundef %82)
  %84 = call i64 @g_clone_5(i64 noundef %83)
  call void @g_store_5(ptr noundef %79, i64 noundef %84)
  br label %85

85:                                               ; preds = %76
  %86 = load i64, ptr %8, align 8
  %87 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %86, i64 1), !nosanitize !7
  %88 = extractvalue { i64, i1 } %87, 0, !nosanitize !7
  %89 = extractvalue { i64, i1 } %87, 1, !nosanitize !7
  %90 = xor i1 %89, true, !nosanitize !7
  br i1 %90, label %92, label %91, !prof !6, !nosanitize !7

91:                                               ; preds = %85
  call void @__ubsan_handle_add_overflow(ptr @105, i64 %86, i64 1) #13, !nosanitize !7
  br label %92, !nosanitize !7

92:                                               ; preds = %91, %85
  store i64 %88, ptr %8, align 8
  br label %72, !llvm.loop !20

93:                                               ; preds = %72
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %0, ptr align 8 %1, i64 24, i1 false)
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #6

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @g_store_14(ptr noundef %0, ptr noundef byval(%struct.g_t14) align 8 %1) #0 !func_sanitize !21 {
  %3 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = call ptr @g_address(ptr noundef %4)
  %6 = icmp ne ptr %5, null, !nosanitize !7
  br i1 %6, label %8, label %7, !prof !6, !nosanitize !7

7:                                                ; preds = %2
  call void @__ubsan_handle_nonnull_arg(ptr @106) #13, !nosanitize !7
  br label %8, !nosanitize !7

8:                                                ; preds = %7, %2
  %9 = icmp ne ptr %1, null, !nosanitize !7
  br i1 %9, label %11, label %10, !prof !6, !nosanitize !7

10:                                               ; preds = %8
  call void @__ubsan_handle_nonnull_arg(ptr @107) #13, !nosanitize !7
  br label %11, !nosanitize !7

11:                                               ; preds = %10, %8
  %12 = ptrtoint ptr %1 to i64, !nosanitize !7
  %13 = and i64 %12, 7, !nosanitize !7
  %14 = icmp eq i64 %13, 0, !nosanitize !7
  br i1 %14, label %16, label %15, !prof !6, !nosanitize !7

15:                                               ; preds = %11
  call void @__ubsan_handle_type_mismatch_v1(ptr @108, i64 %12) #13, !nosanitize !7
  br label %16, !nosanitize !7

16:                                               ; preds = %15, %11
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %5, ptr align 8 %1, i64 24, i1 false)
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @g_clone_13(ptr dead_on_unwind noalias writable sret(%struct.g_t13) align 1 %0, ptr noundef byval(%struct.g_t13) align 8 %1) #0 !func_sanitize !22 {
  %3 = alloca %struct.g_t14, align 8
  %4 = alloca %struct.g_t14, align 8
  %5 = call ptr @g_ref(ptr noundef %1)
  %6 = call ptr @g_offset(ptr noundef %5, i64 noundef 1)
  %7 = call ptr @g_ref(ptr noundef %1)
  %8 = call ptr @g_offset(ptr noundef %7, i64 noundef 1)
  call void @g_load_14(ptr dead_on_unwind writable sret(%struct.g_t14) align 1 %4, ptr noundef %8)
  call void @g_clone_14(ptr dead_on_unwind writable sret(%struct.g_t14) align 1 %3, ptr noundef byval(%struct.g_t14) align 8 %4)
  call void @g_store_14(ptr noundef %6, ptr noundef byval(%struct.g_t14) align 8 %3)
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %0, ptr align 8 %1, i64 25, i1 false)
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @g_store_13(ptr noundef %0, ptr noundef byval(%struct.g_t13) align 8 %1) #0 !func_sanitize !23 {
  %3 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = call ptr @g_address(ptr noundef %4)
  %6 = icmp ne ptr %5, null, !nosanitize !7
  br i1 %6, label %8, label %7, !prof !6, !nosanitize !7

7:                                                ; preds = %2
  call void @__ubsan_handle_nonnull_arg(ptr @111) #13, !nosanitize !7
  br label %8, !nosanitize !7

8:                                                ; preds = %7, %2
  %9 = icmp ne ptr %1, null, !nosanitize !7
  br i1 %9, label %11, label %10, !prof !6, !nosanitize !7

10:                                               ; preds = %8
  call void @__ubsan_handle_nonnull_arg(ptr @112) #13, !nosanitize !7
  br label %11, !nosanitize !7

11:                                               ; preds = %10, %8
  %12 = ptrtoint ptr %1 to i64, !nosanitize !7
  %13 = and i64 %12, 7, !nosanitize !7
  %14 = icmp eq i64 %13, 0, !nosanitize !7
  br i1 %14, label %16, label %15, !prof !6, !nosanitize !7

15:                                               ; preds = %11
  call void @__ubsan_handle_type_mismatch_v1(ptr @114, i64 %12) #13, !nosanitize !7
  br label %16, !nosanitize !7

16:                                               ; preds = %15, %11
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %5, ptr align 8 %1, i64 25, i1 false)
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @g_clone_16(ptr dead_on_unwind noalias writable sret(%struct.g_t16) align 1 %0, ptr noundef byval(%struct.g_t16) align 8 %1) #0 !func_sanitize !24 {
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  %5 = alloca ptr, align 8
  %6 = alloca i64, align 8
  %7 = alloca %struct.g_t13, align 8
  %8 = alloca %struct.g_t13, align 8
  %9 = call ptr @g_ref(ptr noundef %1)
  store ptr %9, ptr %3, align 8
  %10 = load ptr, ptr %3, align 8
  %11 = call i64 @g_len(ptr noundef %10, i32 noundef 0, i64 noundef 2, i32 noundef 0)
  store i64 %11, ptr %4, align 8
  %12 = call ptr @g_ref(ptr noundef %1)
  store ptr %12, ptr %5, align 8
  store i64 0, ptr %6, align 8
  br label %13

13:                                               ; preds = %31, %2
  %14 = load i64, ptr %6, align 8
  %15 = load i64, ptr %4, align 8
  %16 = icmp slt i64 %14, %15
  br i1 %16, label %17, label %32

17:                                               ; preds = %13
  %18 = load ptr, ptr %5, align 8
  %19 = load i64, ptr %6, align 8
  %20 = call ptr @g_element(ptr noundef %18, i32 noundef 0, i64 noundef 2, i32 noundef 0, i64 noundef 25, i64 noundef %19, i32 noundef 0)
  %21 = load ptr, ptr %3, align 8
  %22 = load i64, ptr %6, align 8
  %23 = call ptr @g_element(ptr noundef %21, i32 noundef 0, i64 noundef 2, i32 noundef 0, i64 noundef 25, i64 noundef %22, i32 noundef 0)
  call void @g_load_13(ptr dead_on_unwind writable sret(%struct.g_t13) align 1 %8, ptr noundef %23)
  call void @g_clone_13(ptr dead_on_unwind writable sret(%struct.g_t13) align 1 %7, ptr noundef byval(%struct.g_t13) align 8 %8)
  call void @g_store_13(ptr noundef %20, ptr noundef byval(%struct.g_t13) align 8 %7)
  br label %24

24:                                               ; preds = %17
  %25 = load i64, ptr %6, align 8
  %26 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %25, i64 1), !nosanitize !7
  %27 = extractvalue { i64, i1 } %26, 0, !nosanitize !7
  %28 = extractvalue { i64, i1 } %26, 1, !nosanitize !7
  %29 = xor i1 %28, true, !nosanitize !7
  br i1 %29, label %31, label %30, !prof !6, !nosanitize !7

30:                                               ; preds = %24
  call void @__ubsan_handle_add_overflow(ptr @115, i64 %25, i64 1) #13, !nosanitize !7
  br label %31, !nosanitize !7

31:                                               ; preds = %30, %24
  store i64 %27, ptr %6, align 8
  br label %13, !llvm.loop !25

32:                                               ; preds = %13
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %0, ptr align 8 %1, i64 50, i1 false)
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @g_store_16(ptr noundef %0, ptr noundef byval(%struct.g_t16) align 8 %1) #0 !func_sanitize !26 {
  %3 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = call ptr @g_address(ptr noundef %4)
  %6 = icmp ne ptr %5, null, !nosanitize !7
  br i1 %6, label %8, label %7, !prof !6, !nosanitize !7

7:                                                ; preds = %2
  call void @__ubsan_handle_nonnull_arg(ptr @118) #13, !nosanitize !7
  br label %8, !nosanitize !7

8:                                                ; preds = %7, %2
  %9 = icmp ne ptr %1, null, !nosanitize !7
  br i1 %9, label %11, label %10, !prof !6, !nosanitize !7

10:                                               ; preds = %8
  call void @__ubsan_handle_nonnull_arg(ptr @119) #13, !nosanitize !7
  br label %11, !nosanitize !7

11:                                               ; preds = %10, %8
  %12 = ptrtoint ptr %1 to i64, !nosanitize !7
  %13 = and i64 %12, 7, !nosanitize !7
  %14 = icmp eq i64 %13, 0, !nosanitize !7
  br i1 %14, label %16, label %15, !prof !6, !nosanitize !7

15:                                               ; preds = %11
  call void @__ubsan_handle_type_mismatch_v1(ptr @121, i64 %12) #13, !nosanitize !7
  br label %16, !nosanitize !7

16:                                               ; preds = %15, %11
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %5, ptr align 8 %1, i64 50, i1 false)
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal ptr @g_push(ptr noundef %0, i32 noundef %1, i64 noundef %2, i32 noundef %3, i64 noundef %4, ptr noundef %5) #0 !func_sanitize !27 {
  %7 = alloca ptr, align 8
  %8 = alloca i32, align 4
  %9 = alloca i64, align 8
  %10 = alloca i32, align 4
  %11 = alloca i64, align 8
  %12 = alloca ptr, align 8
  %13 = alloca i64, align 8
  %14 = alloca ptr, align 8
  store ptr %0, ptr %7, align 8
  store i32 %1, ptr %8, align 4
  store i64 %2, ptr %9, align 8
  store i32 %3, ptr %10, align 4
  store i64 %4, ptr %11, align 8
  store ptr %5, ptr %12, align 8
  %15 = load ptr, ptr %7, align 8
  %16 = load i32, ptr %8, align 4
  %17 = load i64, ptr %9, align 8
  %18 = load i32, ptr %10, align 4
  %19 = call i64 @g_len(ptr noundef %15, i32 noundef %16, i64 noundef %17, i32 noundef %18)
  store i64 %19, ptr %13, align 8
  %20 = load ptr, ptr %7, align 8
  %21 = load i32, ptr %8, align 4
  %22 = load i64, ptr %9, align 8
  %23 = load i32, ptr %10, align 4
  %24 = load i64, ptr %11, align 8
  %25 = load i64, ptr %13, align 8
  %26 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %25, i64 1), !nosanitize !7
  %27 = extractvalue { i64, i1 } %26, 0, !nosanitize !7
  %28 = extractvalue { i64, i1 } %26, 1, !nosanitize !7
  %29 = xor i1 %28, true, !nosanitize !7
  br i1 %29, label %31, label %30, !prof !6, !nosanitize !7

30:                                               ; preds = %6
  call void @__ubsan_handle_add_overflow(ptr @122, i64 %25, i64 1) #13, !nosanitize !7
  br label %31, !nosanitize !7

31:                                               ; preds = %30, %6
  call void @g_reserve(ptr noundef %20, i32 noundef %21, i64 noundef %22, i32 noundef %23, i64 noundef %24, i64 noundef %27)
  %32 = load ptr, ptr %7, align 8
  %33 = load i32, ptr %8, align 4
  %34 = load i64, ptr %9, align 8
  %35 = load i32, ptr %10, align 4
  %36 = load i64, ptr %13, align 8
  %37 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %36, i64 1), !nosanitize !7
  %38 = extractvalue { i64, i1 } %37, 0, !nosanitize !7
  %39 = extractvalue { i64, i1 } %37, 1, !nosanitize !7
  %40 = xor i1 %39, true, !nosanitize !7
  br i1 %40, label %42, label %41, !prof !6, !nosanitize !7

41:                                               ; preds = %31
  call void @__ubsan_handle_add_overflow(ptr @123, i64 %36, i64 1) #13, !nosanitize !7
  br label %42, !nosanitize !7

42:                                               ; preds = %41, %31
  call void @g_set_len(ptr noundef %32, i32 noundef %33, i64 noundef %34, i32 noundef %35, i64 noundef %38)
  %43 = load ptr, ptr %7, align 8
  %44 = load i32, ptr %8, align 4
  %45 = load i64, ptr %9, align 8
  %46 = load i32, ptr %10, align 4
  %47 = load i64, ptr %11, align 8
  %48 = load i64, ptr %13, align 8
  %49 = call ptr @g_element(ptr noundef %43, i32 noundef %44, i64 noundef %45, i32 noundef %46, i64 noundef %47, i64 noundef %48, i32 noundef 0)
  store ptr %49, ptr %14, align 8
  %50 = load ptr, ptr %14, align 8
  %51 = call ptr @g_address(ptr noundef %50)
  %52 = load ptr, ptr %12, align 8
  %53 = load i64, ptr %11, align 8
  %54 = icmp ne ptr %51, null, !nosanitize !7
  br i1 %54, label %56, label %55, !prof !6, !nosanitize !7

55:                                               ; preds = %42
  call void @__ubsan_handle_nonnull_arg(ptr @124) #13, !nosanitize !7
  br label %56, !nosanitize !7

56:                                               ; preds = %55, %42
  %57 = icmp ne ptr %52, null, !nosanitize !7
  br i1 %57, label %59, label %58, !prof !6, !nosanitize !7

58:                                               ; preds = %56
  call void @__ubsan_handle_nonnull_arg(ptr @125) #13, !nosanitize !7
  br label %59, !nosanitize !7

59:                                               ; preds = %58, %56
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %51, ptr align 1 %52, i64 %53, i1 false)
  %60 = load ptr, ptr %14, align 8
  ret ptr %60
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i64 @g_load_5(ptr noundef %0) #0 !func_sanitize !28 {
  %2 = alloca ptr, align 8
  %3 = alloca i64, align 8
  store ptr %0, ptr %2, align 8
  %4 = load ptr, ptr %2, align 8
  %5 = call ptr @g_address(ptr noundef %4)
  %6 = icmp ne ptr %3, null, !nosanitize !7
  br i1 %6, label %8, label %7, !prof !6, !nosanitize !7

7:                                                ; preds = %1
  call void @__ubsan_handle_nonnull_arg(ptr @126) #13, !nosanitize !7
  br label %8, !nosanitize !7

8:                                                ; preds = %7, %1
  %9 = icmp ne ptr %5, null, !nosanitize !7
  br i1 %9, label %11, label %10, !prof !6, !nosanitize !7

10:                                               ; preds = %8
  call void @__ubsan_handle_nonnull_arg(ptr @127) #13, !nosanitize !7
  br label %11, !nosanitize !7

11:                                               ; preds = %10, %8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 1 %5, i64 8, i1 false)
  %12 = load i64, ptr %3, align 8
  ret i64 %12
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @g_print_5(ptr noundef %0, i64 noundef %1) #0 !func_sanitize !29 {
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  %5 = alloca [128 x i8], align 16
  %6 = alloca i64, align 8
  store ptr %0, ptr %3, align 8
  store i64 %1, ptr %4, align 8
  %7 = getelementptr inbounds [128 x i8], ptr %5, i64 0, i64 0
  %8 = load i64, ptr %4, align 8
  %9 = call i64 @gs_fmt_i64(ptr noundef %7, i64 noundef %8)
  store i64 %9, ptr %6, align 8
  %10 = load ptr, ptr %3, align 8
  %11 = getelementptr inbounds [128 x i8], ptr %5, i64 0, i64 0
  %12 = load i64, ptr %6, align 8
  call void @g_print_bytes(ptr noundef %10, ptr noundef %11, i64 noundef %12)
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @g_print_12(ptr noundef %0, ptr %1, i64 %2) #0 !func_sanitize !30 {
  %4 = alloca %struct.GSlice, align 8
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca i64, align 8
  %8 = alloca i64, align 8
  %9 = getelementptr inbounds nuw { ptr, i64 }, ptr %4, i32 0, i32 0
  store ptr %1, ptr %9, align 8
  %10 = getelementptr inbounds nuw { ptr, i64 }, ptr %4, i32 0, i32 1
  store i64 %2, ptr %10, align 8
  store ptr %0, ptr %5, align 8
  %11 = call ptr @g_ref(ptr noundef %4)
  store ptr %11, ptr %6, align 8
  %12 = load ptr, ptr %6, align 8
  %13 = call i64 @g_len(ptr noundef %12, i32 noundef 5, i64 noundef -1, i32 noundef 0)
  store i64 %13, ptr %7, align 8
  store i64 0, ptr %8, align 8
  br label %14

14:                                               ; preds = %31, %3
  %15 = load i64, ptr %8, align 8
  %16 = load i64, ptr %7, align 8
  %17 = icmp slt i64 %15, %16
  br i1 %17, label %18, label %32

18:                                               ; preds = %14
  %19 = load ptr, ptr %5, align 8
  %20 = load ptr, ptr %6, align 8
  %21 = load i64, ptr %8, align 8
  %22 = call ptr @g_element(ptr noundef %20, i32 noundef 5, i64 noundef -1, i32 noundef 0, i64 noundef 1, i64 noundef %21, i32 noundef 0)
  %23 = call ptr @g_address(ptr noundef %22)
  call void @g_print_bytes(ptr noundef %19, ptr noundef %23, i64 noundef 1)
  br label %24

24:                                               ; preds = %18
  %25 = load i64, ptr %8, align 8
  %26 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %25, i64 1), !nosanitize !7
  %27 = extractvalue { i64, i1 } %26, 0, !nosanitize !7
  %28 = extractvalue { i64, i1 } %26, 1, !nosanitize !7
  %29 = xor i1 %28, true, !nosanitize !7
  br i1 %29, label %31, label %30, !prof !6, !nosanitize !7

30:                                               ; preds = %24
  call void @__ubsan_handle_add_overflow(ptr @182, i64 %25, i64 1) #13, !nosanitize !7
  br label %31, !nosanitize !7

31:                                               ; preds = %30, %24
  store i64 %27, ptr %8, align 8
  br label %14, !llvm.loop !31

32:                                               ; preds = %14
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @g_print_text(ptr noundef %0, ptr noundef %1) #0 !func_sanitize !32 {
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store ptr %1, ptr %4, align 8
  %5 = load ptr, ptr %3, align 8
  %6 = load ptr, ptr %4, align 8
  %7 = load ptr, ptr %4, align 8
  %8 = icmp ne ptr %7, null, !nosanitize !7
  br i1 %8, label %10, label %9, !prof !6, !nosanitize !7

9:                                                ; preds = %2
  call void @__ubsan_handle_nonnull_arg(ptr @183) #13, !nosanitize !7
  br label %10, !nosanitize !7

10:                                               ; preds = %9, %2
  %11 = call i64 @strlen(ptr noundef %7) #16
  call void @g_print_bytes(ptr noundef %5, ptr noundef %6, i64 noundef %11)
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal ptr @g_alloc(i64 noundef %0) #0 !func_sanitize !33 {
  %2 = alloca i64, align 8
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  store i64 %0, ptr %2, align 8
  %5 = load i64, ptr %2, align 8
  %6 = load i64, ptr %2, align 8
  %7 = icmp ne i64 %6, 0
  %8 = xor i1 %7, true
  %9 = zext i1 %8 to i32
  %10 = sext i32 %9 to i64
  %11 = add i64 %5, %10
  %12 = call noalias ptr @calloc(i64 noundef 1, i64 noundef %11) #17
  store ptr %12, ptr %3, align 8
  %13 = load ptr, ptr %3, align 8
  %14 = icmp ne ptr %13, null
  br i1 %14, label %16, label %15

15:                                               ; preds = %1
  call void @g_panic(ptr noundef @.str.3)
  br label %16

16:                                               ; preds = %15, %1
  %17 = call noalias ptr @malloc(i64 noundef 16) #18
  store ptr %17, ptr %4, align 8
  %18 = load ptr, ptr %4, align 8
  %19 = icmp ne ptr %18, null
  br i1 %19, label %21, label %20

20:                                               ; preds = %16
  call void @g_panic(ptr noundef @.str.3)
  br label %21

21:                                               ; preds = %20, %16
  %22 = load ptr, ptr %3, align 8
  %23 = load ptr, ptr %4, align 8
  %24 = icmp ne ptr %23, null, !nosanitize !7
  %25 = ptrtoint ptr %23 to i64, !nosanitize !7
  %26 = and i64 %25, 7, !nosanitize !7
  %27 = icmp eq i64 %26, 0, !nosanitize !7
  %28 = and i1 %24, %27, !nosanitize !7
  br i1 %28, label %30, label %29, !prof !6, !nosanitize !7

29:                                               ; preds = %21
  call void @__ubsan_handle_type_mismatch_v1(ptr @14, i64 %25) #13, !nosanitize !7
  br label %30, !nosanitize !7

30:                                               ; preds = %29, %21
  %31 = getelementptr inbounds nuw %struct.GAllocation, ptr %23, i32 0, i32 1
  %32 = icmp ne ptr %31, null, !nosanitize !7
  %33 = ptrtoint ptr %31 to i64, !nosanitize !7
  %34 = and i64 %33, 7, !nosanitize !7
  %35 = icmp eq i64 %34, 0, !nosanitize !7
  %36 = and i1 %32, %35, !nosanitize !7
  br i1 %36, label %38, label %37, !prof !6, !nosanitize !7

37:                                               ; preds = %30
  call void @__ubsan_handle_type_mismatch_v1(ptr @15, i64 %33) #13, !nosanitize !7
  br label %38, !nosanitize !7

38:                                               ; preds = %37, %30
  store ptr %22, ptr %31, align 8
  %39 = load ptr, ptr @g_allocations, align 8
  %40 = load ptr, ptr %4, align 8
  %41 = icmp ne ptr %40, null, !nosanitize !7
  %42 = ptrtoint ptr %40 to i64, !nosanitize !7
  %43 = and i64 %42, 7, !nosanitize !7
  %44 = icmp eq i64 %43, 0, !nosanitize !7
  %45 = and i1 %41, %44, !nosanitize !7
  br i1 %45, label %47, label %46, !prof !6, !nosanitize !7

46:                                               ; preds = %38
  call void @__ubsan_handle_type_mismatch_v1(ptr @16, i64 %42) #13, !nosanitize !7
  br label %47, !nosanitize !7

47:                                               ; preds = %46, %38
  %48 = getelementptr inbounds nuw %struct.GAllocation, ptr %40, i32 0, i32 0
  %49 = icmp ne ptr %48, null, !nosanitize !7
  %50 = ptrtoint ptr %48 to i64, !nosanitize !7
  %51 = and i64 %50, 7, !nosanitize !7
  %52 = icmp eq i64 %51, 0, !nosanitize !7
  %53 = and i1 %49, %52, !nosanitize !7
  br i1 %53, label %55, label %54, !prof !6, !nosanitize !7

54:                                               ; preds = %47
  call void @__ubsan_handle_type_mismatch_v1(ptr @17, i64 %50) #13, !nosanitize !7
  br label %55, !nosanitize !7

55:                                               ; preds = %54, %47
  store ptr %39, ptr %48, align 8
  %56 = load ptr, ptr %4, align 8
  store ptr %56, ptr @g_allocations, align 8
  %57 = load ptr, ptr %3, align 8
  ret ptr %57
}

; Function Attrs: nounwind allocsize(0,1)
declare noalias ptr @calloc(i64 noundef, i64 noundef) #7

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @g_panic(ptr noundef %0) #0 !func_sanitize !34 {
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = load ptr, ptr @stderr, align 8
  %4 = icmp ne ptr %3, null, !nosanitize !7
  br i1 %4, label %6, label %5, !prof !6, !nosanitize !7

5:                                                ; preds = %1
  call void @__ubsan_handle_nonnull_arg(ptr @18) #13, !nosanitize !7
  br label %6, !nosanitize !7

6:                                                ; preds = %5, %1
  %7 = load ptr, ptr %2, align 8
  %8 = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %3, ptr noundef @.str.5, ptr noundef %7) #14
  call void @exit(i32 noundef 1) #14
  br i1 false, label %10, label %9, !prof !6, !nosanitize !7

9:                                                ; preds = %6
  call void @__ubsan_handle_builtin_unreachable(ptr @19) #19, !nosanitize !7
  unreachable, !nosanitize !7

10:                                               ; preds = %6
  unreachable
}

; Function Attrs: nounwind allocsize(0)
declare noalias ptr @malloc(i64 noundef) #8

; Function Attrs: nounwind
declare i32 @fprintf(ptr noundef, ptr noundef, ...) #1

; Function Attrs: nounwind
declare void @exit(i32 noundef) #1

; Function Attrs: noreturn nounwind uwtable
declare void @__ubsan_handle_builtin_unreachable(ptr) #9

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal ptr @g_address(ptr noundef %0) #0 !func_sanitize !35 {
  %2 = alloca ptr, align 8
  %3 = alloca ptr, align 8
  %4 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  %5 = load ptr, ptr %3, align 8
  %6 = icmp ne ptr %5, null
  br i1 %6, label %8, label %7

7:                                                ; preds = %1
  call void @g_panic(ptr noundef @.str.7)
  br label %8

8:                                                ; preds = %7, %1
  %9 = load ptr, ptr %3, align 8
  %10 = icmp ne ptr %9, null, !nosanitize !7
  %11 = ptrtoint ptr %9 to i64, !nosanitize !7
  %12 = and i64 %11, 7, !nosanitize !7
  %13 = icmp eq i64 %12, 0, !nosanitize !7
  %14 = and i1 %10, %13, !nosanitize !7
  br i1 %14, label %16, label %15, !prof !6, !nosanitize !7

15:                                               ; preds = %8
  call void @__ubsan_handle_type_mismatch_v1(ptr @27, i64 %11) #13, !nosanitize !7
  br label %16, !nosanitize !7

16:                                               ; preds = %15, %8
  %17 = getelementptr inbounds nuw %struct.GRefCell, ptr %9, i32 0, i32 2
  %18 = icmp ne ptr %17, null, !nosanitize !7
  %19 = ptrtoint ptr %17 to i64, !nosanitize !7
  %20 = and i64 %19, 7, !nosanitize !7
  %21 = icmp eq i64 %20, 0, !nosanitize !7
  %22 = and i1 %18, %21, !nosanitize !7
  br i1 %22, label %24, label %23, !prof !6, !nosanitize !7

23:                                               ; preds = %16
  call void @__ubsan_handle_type_mismatch_v1(ptr @28, i64 %19) #13, !nosanitize !7
  br label %24, !nosanitize !7

24:                                               ; preds = %23, %16
  %25 = load ptr, ptr %17, align 8
  store ptr %25, ptr %4, align 8
  %26 = load ptr, ptr %3, align 8
  %27 = icmp ne ptr %26, null, !nosanitize !7
  %28 = ptrtoint ptr %26 to i64, !nosanitize !7
  %29 = and i64 %28, 7, !nosanitize !7
  %30 = icmp eq i64 %29, 0, !nosanitize !7
  %31 = and i1 %27, %30, !nosanitize !7
  br i1 %31, label %33, label %32, !prof !6, !nosanitize !7

32:                                               ; preds = %24
  call void @__ubsan_handle_type_mismatch_v1(ptr @29, i64 %28) #13, !nosanitize !7
  br label %33, !nosanitize !7

33:                                               ; preds = %32, %24
  %34 = getelementptr inbounds nuw %struct.GRefCell, ptr %26, i32 0, i32 0
  %35 = icmp ne ptr %34, null, !nosanitize !7
  %36 = ptrtoint ptr %34 to i64, !nosanitize !7
  %37 = and i64 %36, 7, !nosanitize !7
  %38 = icmp eq i64 %37, 0, !nosanitize !7
  %39 = and i1 %35, %38, !nosanitize !7
  br i1 %39, label %41, label %40, !prof !6, !nosanitize !7

40:                                               ; preds = %33
  call void @__ubsan_handle_type_mismatch_v1(ptr @30, i64 %36) #13, !nosanitize !7
  br label %41, !nosanitize !7

41:                                               ; preds = %40, %33
  %42 = load ptr, ptr %34, align 8
  %43 = icmp ne ptr %42, null
  br i1 %43, label %44, label %63

44:                                               ; preds = %41
  %45 = load ptr, ptr %3, align 8
  %46 = icmp ne ptr %45, null, !nosanitize !7
  %47 = ptrtoint ptr %45 to i64, !nosanitize !7
  %48 = and i64 %47, 7, !nosanitize !7
  %49 = icmp eq i64 %48, 0, !nosanitize !7
  %50 = and i1 %46, %49, !nosanitize !7
  br i1 %50, label %52, label %51, !prof !6, !nosanitize !7

51:                                               ; preds = %44
  call void @__ubsan_handle_type_mismatch_v1(ptr @31, i64 %47) #13, !nosanitize !7
  br label %52, !nosanitize !7

52:                                               ; preds = %51, %44
  %53 = getelementptr inbounds nuw %struct.GRefCell, ptr %45, i32 0, i32 0
  %54 = icmp ne ptr %53, null, !nosanitize !7
  %55 = ptrtoint ptr %53 to i64, !nosanitize !7
  %56 = and i64 %55, 7, !nosanitize !7
  %57 = icmp eq i64 %56, 0, !nosanitize !7
  %58 = and i1 %54, %57, !nosanitize !7
  br i1 %58, label %60, label %59, !prof !6, !nosanitize !7

59:                                               ; preds = %52
  call void @__ubsan_handle_type_mismatch_v1(ptr @32, i64 %55) #13, !nosanitize !7
  br label %60, !nosanitize !7

60:                                               ; preds = %59, %52
  %61 = load ptr, ptr %53, align 8
  %62 = call ptr @g_address(ptr noundef %61)
  store ptr %62, ptr %4, align 8
  br label %112

63:                                               ; preds = %41
  %64 = load ptr, ptr %3, align 8
  %65 = icmp ne ptr %64, null, !nosanitize !7
  %66 = ptrtoint ptr %64 to i64, !nosanitize !7
  %67 = and i64 %66, 7, !nosanitize !7
  %68 = icmp eq i64 %67, 0, !nosanitize !7
  %69 = and i1 %65, %68, !nosanitize !7
  br i1 %69, label %71, label %70, !prof !6, !nosanitize !7

70:                                               ; preds = %63
  call void @__ubsan_handle_type_mismatch_v1(ptr @33, i64 %66) #13, !nosanitize !7
  br label %71, !nosanitize !7

71:                                               ; preds = %70, %63
  %72 = getelementptr inbounds nuw %struct.GRefCell, ptr %64, i32 0, i32 1
  %73 = icmp ne ptr %72, null, !nosanitize !7
  %74 = ptrtoint ptr %72 to i64, !nosanitize !7
  %75 = and i64 %74, 7, !nosanitize !7
  %76 = icmp eq i64 %75, 0, !nosanitize !7
  %77 = and i1 %73, %76, !nosanitize !7
  br i1 %77, label %79, label %78, !prof !6, !nosanitize !7

78:                                               ; preds = %71
  call void @__ubsan_handle_type_mismatch_v1(ptr @35, i64 %74) #13, !nosanitize !7
  br label %79, !nosanitize !7

79:                                               ; preds = %78, %71
  %80 = load ptr, ptr %72, align 8
  %81 = icmp ne ptr %80, null
  br i1 %81, label %82, label %111

82:                                               ; preds = %79
  %83 = load ptr, ptr %3, align 8
  %84 = icmp ne ptr %83, null, !nosanitize !7
  %85 = ptrtoint ptr %83 to i64, !nosanitize !7
  %86 = and i64 %85, 7, !nosanitize !7
  %87 = icmp eq i64 %86, 0, !nosanitize !7
  %88 = and i1 %84, %87, !nosanitize !7
  br i1 %88, label %90, label %89, !prof !6, !nosanitize !7

89:                                               ; preds = %82
  call void @__ubsan_handle_type_mismatch_v1(ptr @36, i64 %85) #13, !nosanitize !7
  br label %90, !nosanitize !7

90:                                               ; preds = %89, %82
  %91 = getelementptr inbounds nuw %struct.GRefCell, ptr %83, i32 0, i32 1
  %92 = icmp ne ptr %91, null, !nosanitize !7
  %93 = ptrtoint ptr %91 to i64, !nosanitize !7
  %94 = and i64 %93, 7, !nosanitize !7
  %95 = icmp eq i64 %94, 0, !nosanitize !7
  %96 = and i1 %92, %95, !nosanitize !7
  br i1 %96, label %98, label %97, !prof !6, !nosanitize !7

97:                                               ; preds = %90
  call void @__ubsan_handle_type_mismatch_v1(ptr @37, i64 %93) #13, !nosanitize !7
  br label %98, !nosanitize !7

98:                                               ; preds = %97, %90
  %99 = load ptr, ptr %91, align 8
  %100 = icmp ne ptr %4, null, !nosanitize !7
  br i1 %100, label %102, label %101, !prof !6, !nosanitize !7

101:                                              ; preds = %98
  call void @__ubsan_handle_nonnull_arg(ptr @38) #13, !nosanitize !7
  br label %102, !nosanitize !7

102:                                              ; preds = %101, %98
  %103 = icmp ne ptr %99, null, !nosanitize !7
  br i1 %103, label %105, label %104, !prof !6, !nosanitize !7

104:                                              ; preds = %102
  call void @__ubsan_handle_nonnull_arg(ptr @39) #13, !nosanitize !7
  br label %105, !nosanitize !7

105:                                              ; preds = %104, %102
  %106 = ptrtoint ptr %99 to i64, !nosanitize !7
  %107 = and i64 %106, 7, !nosanitize !7
  %108 = icmp eq i64 %107, 0, !nosanitize !7
  br i1 %108, label %110, label %109, !prof !6, !nosanitize !7

109:                                              ; preds = %105
  call void @__ubsan_handle_type_mismatch_v1(ptr @40, i64 %106) #13, !nosanitize !7
  br label %110, !nosanitize !7

110:                                              ; preds = %109, %105
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %4, ptr align 8 %99, i64 8, i1 false)
  br label %111

111:                                              ; preds = %110, %79
  br label %112

112:                                              ; preds = %111, %60
  %113 = load ptr, ptr %3, align 8
  %114 = icmp ne ptr %113, null, !nosanitize !7
  %115 = ptrtoint ptr %113 to i64, !nosanitize !7
  %116 = and i64 %115, 7, !nosanitize !7
  %117 = icmp eq i64 %116, 0, !nosanitize !7
  %118 = and i1 %114, %117, !nosanitize !7
  br i1 %118, label %120, label %119, !prof !6, !nosanitize !7

119:                                              ; preds = %112
  call void @__ubsan_handle_type_mismatch_v1(ptr @41, i64 %115) #13, !nosanitize !7
  br label %120, !nosanitize !7

120:                                              ; preds = %119, %112
  %121 = getelementptr inbounds nuw %struct.GRefCell, ptr %113, i32 0, i32 3
  %122 = icmp ne ptr %121, null, !nosanitize !7
  %123 = ptrtoint ptr %121 to i64, !nosanitize !7
  %124 = and i64 %123, 7, !nosanitize !7
  %125 = icmp eq i64 %124, 0, !nosanitize !7
  %126 = and i1 %122, %125, !nosanitize !7
  br i1 %126, label %128, label %127, !prof !6, !nosanitize !7

127:                                              ; preds = %120
  call void @__ubsan_handle_type_mismatch_v1(ptr @42, i64 %123) #13, !nosanitize !7
  br label %128, !nosanitize !7

128:                                              ; preds = %127, %120
  %129 = load i64, ptr %121, align 8
  %130 = icmp ne i64 %129, 0
  br i1 %130, label %133, label %131

131:                                              ; preds = %128
  %132 = load ptr, ptr %4, align 8
  store ptr %132, ptr %2, align 8
  br label %175

133:                                              ; preds = %128
  %134 = load ptr, ptr %4, align 8
  %135 = icmp ne ptr %134, null
  br i1 %135, label %137, label %136

136:                                              ; preds = %133
  call void @g_panic(ptr noundef @.str.7)
  br label %137

137:                                              ; preds = %136, %133
  %138 = load ptr, ptr %4, align 8
  %139 = load ptr, ptr %3, align 8
  %140 = icmp ne ptr %139, null, !nosanitize !7
  %141 = ptrtoint ptr %139 to i64, !nosanitize !7
  %142 = and i64 %141, 7, !nosanitize !7
  %143 = icmp eq i64 %142, 0, !nosanitize !7
  %144 = and i1 %140, %143, !nosanitize !7
  br i1 %144, label %146, label %145, !prof !6, !nosanitize !7

145:                                              ; preds = %137
  call void @__ubsan_handle_type_mismatch_v1(ptr @43, i64 %141) #13, !nosanitize !7
  br label %146, !nosanitize !7

146:                                              ; preds = %145, %137
  %147 = getelementptr inbounds nuw %struct.GRefCell, ptr %139, i32 0, i32 3
  %148 = icmp ne ptr %147, null, !nosanitize !7
  %149 = ptrtoint ptr %147 to i64, !nosanitize !7
  %150 = and i64 %149, 7, !nosanitize !7
  %151 = icmp eq i64 %150, 0, !nosanitize !7
  %152 = and i1 %148, %151, !nosanitize !7
  br i1 %152, label %154, label %153, !prof !6, !nosanitize !7

153:                                              ; preds = %146
  call void @__ubsan_handle_type_mismatch_v1(ptr @44, i64 %149) #13, !nosanitize !7
  br label %154, !nosanitize !7

154:                                              ; preds = %153, %146
  %155 = load i64, ptr %147, align 8
  %156 = getelementptr inbounds i8, ptr %138, i64 %155
  %157 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 1, i64 %155), !nosanitize !7
  %158 = extractvalue { i64, i1 } %157, 1, !nosanitize !7
  %159 = or i1 %158, false, !nosanitize !7
  %160 = extractvalue { i64, i1 } %157, 0, !nosanitize !7
  %161 = ptrtoint ptr %138 to i64, !nosanitize !7
  %162 = add i64 %161, %160, !nosanitize !7
  %163 = icmp ne ptr %138, null, !nosanitize !7
  %164 = icmp ne i64 %162, 0, !nosanitize !7
  %165 = icmp eq i1 %163, %164, !nosanitize !7
  %166 = xor i1 %159, true, !nosanitize !7
  %167 = icmp uge i64 %162, %161, !nosanitize !7
  %168 = icmp sge i64 %160, 0, !nosanitize !7
  %169 = icmp ult i64 %162, %161, !nosanitize !7
  %170 = select i1 %168, i1 %167, i1 %169, !nosanitize !7
  %171 = and i1 %170, %166, !nosanitize !7
  %172 = and i1 %165, %171, !nosanitize !7
  br i1 %172, label %174, label %173, !prof !6, !nosanitize !7

173:                                              ; preds = %154
  call void @__ubsan_handle_pointer_overflow(ptr @45, i64 %161, i64 %162) #13, !nosanitize !7
  br label %174, !nosanitize !7

174:                                              ; preds = %173, %154
  store ptr %156, ptr %2, align 8
  br label %175

175:                                              ; preds = %174, %131
  %176 = load ptr, ptr %2, align 8
  ret ptr %176
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64) #10

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64) #10

; Function Attrs: uwtable
declare void @__ubsan_handle_pointer_overflow(ptr, i64, i64) #2

; Function Attrs: uwtable
declare void @__ubsan_handle_divrem_overflow(ptr, i64, i64) #2

; Function Attrs: uwtable
declare void @__ubsan_handle_mul_overflow(ptr, i64, i64) #2

; Function Attrs: uwtable
declare void @__ubsan_handle_add_overflow(ptr, i64, i64) #2

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @g_write_length(ptr noundef %0, i32 noundef %1, i64 noundef %2) #0 !func_sanitize !36 {
  %4 = alloca ptr, align 8
  %5 = alloca i32, align 4
  %6 = alloca i64, align 8
  store ptr %0, ptr %4, align 8
  store i32 %1, ptr %5, align 4
  store i64 %2, ptr %6, align 8
  %7 = load ptr, ptr %4, align 8
  %8 = load i32, ptr %5, align 4
  %9 = sext i32 %8 to i64
  %10 = icmp ne ptr %7, null, !nosanitize !7
  br i1 %10, label %12, label %11, !prof !6, !nosanitize !7

11:                                               ; preds = %3
  call void @__ubsan_handle_nonnull_arg(ptr @69) #13, !nosanitize !7
  br label %12, !nosanitize !7

12:                                               ; preds = %11, %3
  %13 = icmp ne ptr %6, null, !nosanitize !7
  br i1 %13, label %15, label %14, !prof !6, !nosanitize !7

14:                                               ; preds = %12
  call void @__ubsan_handle_nonnull_arg(ptr @70) #13, !nosanitize !7
  br label %15, !nosanitize !7

15:                                               ; preds = %14, %12
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %7, ptr align 8 %6, i64 %9, i1 false)
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i64 @g_len(ptr noundef %0, i32 noundef %1, i64 noundef %2, i32 noundef %3) #0 !func_sanitize !37 {
  %5 = alloca i64, align 8
  %6 = alloca ptr, align 8
  %7 = alloca i32, align 4
  %8 = alloca i64, align 8
  %9 = alloca i32, align 4
  %10 = alloca %struct.GSlice, align 8
  %11 = alloca %struct.GArray, align 8
  store ptr %0, ptr %6, align 8
  store i32 %1, ptr %7, align 4
  store i64 %2, ptr %8, align 8
  store i32 %3, ptr %9, align 4
  %12 = load i32, ptr %7, align 4
  %13 = icmp eq i32 %12, 5
  br i1 %13, label %14, label %30

14:                                               ; preds = %4
  %15 = load ptr, ptr %6, align 8
  %16 = call ptr @g_address(ptr noundef %15)
  %17 = icmp ne ptr %10, null, !nosanitize !7
  br i1 %17, label %19, label %18, !prof !6, !nosanitize !7

18:                                               ; preds = %14
  call void @__ubsan_handle_nonnull_arg(ptr @81) #13, !nosanitize !7
  br label %19, !nosanitize !7

19:                                               ; preds = %18, %14
  %20 = icmp ne ptr %16, null, !nosanitize !7
  br i1 %20, label %22, label %21, !prof !6, !nosanitize !7

21:                                               ; preds = %19
  call void @__ubsan_handle_nonnull_arg(ptr @82) #13, !nosanitize !7
  br label %22, !nosanitize !7

22:                                               ; preds = %21, %19
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %10, ptr align 1 %16, i64 16, i1 false)
  %23 = getelementptr inbounds nuw %struct.GSlice, ptr %10, i32 0, i32 1
  %24 = ptrtoint ptr %23 to i64, !nosanitize !7
  %25 = and i64 %24, 7, !nosanitize !7
  %26 = icmp eq i64 %25, 0, !nosanitize !7
  br i1 %26, label %28, label %27, !prof !6, !nosanitize !7

27:                                               ; preds = %22
  call void @__ubsan_handle_type_mismatch_v1(ptr @83, i64 %24) #13, !nosanitize !7
  br label %28, !nosanitize !7

28:                                               ; preds = %27, %22
  %29 = load i64, ptr %23, align 8
  store i64 %29, ptr %5, align 8
  br label %62

30:                                               ; preds = %4
  %31 = load i32, ptr %7, align 4
  %32 = icmp eq i32 %31, 0
  br i1 %32, label %33, label %35

33:                                               ; preds = %30
  %34 = load i64, ptr %8, align 8
  store i64 %34, ptr %5, align 8
  br label %62

35:                                               ; preds = %30
  %36 = load i32, ptr %7, align 4
  %37 = icmp eq i32 %36, 2
  br i1 %37, label %38, label %46

38:                                               ; preds = %35
  %39 = load i64, ptr %8, align 8
  %40 = icmp sge i64 %39, 0
  br i1 %40, label %41, label %46

41:                                               ; preds = %38
  %42 = load ptr, ptr %6, align 8
  %43 = call ptr @g_address(ptr noundef %42)
  %44 = load i32, ptr %9, align 4
  %45 = call i64 @g_read_length(ptr noundef %43, i32 noundef %44)
  store i64 %45, ptr %5, align 8
  br label %62

46:                                               ; preds = %38, %35
  %47 = load ptr, ptr %6, align 8
  %48 = call ptr @g_address(ptr noundef %47)
  %49 = icmp ne ptr %11, null, !nosanitize !7
  br i1 %49, label %51, label %50, !prof !6, !nosanitize !7

50:                                               ; preds = %46
  call void @__ubsan_handle_nonnull_arg(ptr @84) #13, !nosanitize !7
  br label %51, !nosanitize !7

51:                                               ; preds = %50, %46
  %52 = icmp ne ptr %48, null, !nosanitize !7
  br i1 %52, label %54, label %53, !prof !6, !nosanitize !7

53:                                               ; preds = %51
  call void @__ubsan_handle_nonnull_arg(ptr @85) #13, !nosanitize !7
  br label %54, !nosanitize !7

54:                                               ; preds = %53, %51
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %11, ptr align 1 %48, i64 24, i1 false)
  %55 = getelementptr inbounds nuw %struct.GArray, ptr %11, i32 0, i32 1
  %56 = ptrtoint ptr %55 to i64, !nosanitize !7
  %57 = and i64 %56, 7, !nosanitize !7
  %58 = icmp eq i64 %57, 0, !nosanitize !7
  br i1 %58, label %60, label %59, !prof !6, !nosanitize !7

59:                                               ; preds = %54
  call void @__ubsan_handle_type_mismatch_v1(ptr @86, i64 %56) #13, !nosanitize !7
  br label %60, !nosanitize !7

60:                                               ; preds = %59, %54
  %61 = load i64, ptr %55, align 8
  store i64 %61, ptr %5, align 8
  br label %62

62:                                               ; preds = %60, %41, %33, %28
  %63 = load i64, ptr %5, align 8
  ret i64 %63
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal ptr @g_moving(ptr noundef %0, i64 noundef %1) #0 !func_sanitize !38 {
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  %5 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  store i64 %1, ptr %4, align 8
  %6 = call ptr @g_alloc(i64 noundef 32)
  store ptr %6, ptr %5, align 8
  %7 = load ptr, ptr %3, align 8
  %8 = load ptr, ptr %5, align 8
  %9 = icmp ne ptr %8, null, !nosanitize !7
  %10 = ptrtoint ptr %8 to i64, !nosanitize !7
  %11 = and i64 %10, 7, !nosanitize !7
  %12 = icmp eq i64 %11, 0, !nosanitize !7
  %13 = and i1 %9, %12, !nosanitize !7
  br i1 %13, label %15, label %14, !prof !6, !nosanitize !7

14:                                               ; preds = %2
  call void @__ubsan_handle_type_mismatch_v1(ptr @89, i64 %10) #13, !nosanitize !7
  br label %15, !nosanitize !7

15:                                               ; preds = %14, %2
  %16 = getelementptr inbounds nuw %struct.GRefCell, ptr %8, i32 0, i32 1
  %17 = icmp ne ptr %16, null, !nosanitize !7
  %18 = ptrtoint ptr %16 to i64, !nosanitize !7
  %19 = and i64 %18, 7, !nosanitize !7
  %20 = icmp eq i64 %19, 0, !nosanitize !7
  %21 = and i1 %17, %20, !nosanitize !7
  br i1 %21, label %23, label %22, !prof !6, !nosanitize !7

22:                                               ; preds = %15
  call void @__ubsan_handle_type_mismatch_v1(ptr @90, i64 %18) #13, !nosanitize !7
  br label %23, !nosanitize !7

23:                                               ; preds = %22, %15
  store ptr %7, ptr %16, align 8
  %24 = load i64, ptr %4, align 8
  %25 = load ptr, ptr %5, align 8
  %26 = icmp ne ptr %25, null, !nosanitize !7
  %27 = ptrtoint ptr %25 to i64, !nosanitize !7
  %28 = and i64 %27, 7, !nosanitize !7
  %29 = icmp eq i64 %28, 0, !nosanitize !7
  %30 = and i1 %26, %29, !nosanitize !7
  br i1 %30, label %32, label %31, !prof !6, !nosanitize !7

31:                                               ; preds = %23
  call void @__ubsan_handle_type_mismatch_v1(ptr @91, i64 %27) #13, !nosanitize !7
  br label %32, !nosanitize !7

32:                                               ; preds = %31, %23
  %33 = getelementptr inbounds nuw %struct.GRefCell, ptr %25, i32 0, i32 3
  %34 = icmp ne ptr %33, null, !nosanitize !7
  %35 = ptrtoint ptr %33 to i64, !nosanitize !7
  %36 = and i64 %35, 7, !nosanitize !7
  %37 = icmp eq i64 %36, 0, !nosanitize !7
  %38 = and i1 %34, %37, !nosanitize !7
  br i1 %38, label %40, label %39, !prof !6, !nosanitize !7

39:                                               ; preds = %32
  call void @__ubsan_handle_type_mismatch_v1(ptr @92, i64 %35) #13, !nosanitize !7
  br label %40, !nosanitize !7

40:                                               ; preds = %39, %32
  store i64 %24, ptr %33, align 8
  %41 = load ptr, ptr %5, align 8
  ret ptr %41
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i64 @g_read_length(ptr noundef %0, i32 noundef %1) #0 !func_sanitize !39 {
  %3 = alloca ptr, align 8
  %4 = alloca i32, align 4
  %5 = alloca i64, align 8
  store ptr %0, ptr %3, align 8
  store i32 %1, ptr %4, align 4
  store i64 0, ptr %5, align 8
  %6 = load ptr, ptr %3, align 8
  %7 = load i32, ptr %4, align 4
  %8 = sext i32 %7 to i64
  %9 = icmp ne ptr %5, null, !nosanitize !7
  br i1 %9, label %11, label %10, !prof !6, !nosanitize !7

10:                                               ; preds = %2
  call void @__ubsan_handle_nonnull_arg(ptr @87) #13, !nosanitize !7
  br label %11, !nosanitize !7

11:                                               ; preds = %10, %2
  %12 = icmp ne ptr %6, null, !nosanitize !7
  br i1 %12, label %14, label %13, !prof !6, !nosanitize !7

13:                                               ; preds = %11
  call void @__ubsan_handle_nonnull_arg(ptr @88) #13, !nosanitize !7
  br label %14, !nosanitize !7

14:                                               ; preds = %13, %11
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %5, ptr align 1 %6, i64 %8, i1 false)
  %15 = load i64, ptr %5, align 8
  ret i64 %15
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i64 @g_clone_5(i64 noundef %0) #0 !func_sanitize !40 {
  %2 = alloca i64, align 8
  store i64 %0, ptr %2, align 8
  %3 = load i64, ptr %2, align 8
  ret i64 %3
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @g_load_14(ptr dead_on_unwind noalias writable sret(%struct.g_t14) align 1 %0, ptr noundef %1) #0 !func_sanitize !41 {
  %3 = alloca ptr, align 8
  store ptr %1, ptr %3, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = call ptr @g_address(ptr noundef %4)
  %6 = icmp ne ptr %0, null, !nosanitize !7
  br i1 %6, label %8, label %7, !prof !6, !nosanitize !7

7:                                                ; preds = %2
  call void @__ubsan_handle_nonnull_arg(ptr @109) #13, !nosanitize !7
  br label %8, !nosanitize !7

8:                                                ; preds = %7, %2
  %9 = icmp ne ptr %5, null, !nosanitize !7
  br i1 %9, label %11, label %10, !prof !6, !nosanitize !7

10:                                               ; preds = %8
  call void @__ubsan_handle_nonnull_arg(ptr @110) #13, !nosanitize !7
  br label %11, !nosanitize !7

11:                                               ; preds = %10, %8
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %0, ptr align 1 %5, i64 24, i1 false)
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @g_load_13(ptr dead_on_unwind noalias writable sret(%struct.g_t13) align 1 %0, ptr noundef %1) #0 !func_sanitize !42 {
  %3 = alloca ptr, align 8
  store ptr %1, ptr %3, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = call ptr @g_address(ptr noundef %4)
  %6 = icmp ne ptr %0, null, !nosanitize !7
  br i1 %6, label %8, label %7, !prof !6, !nosanitize !7

7:                                                ; preds = %2
  call void @__ubsan_handle_nonnull_arg(ptr @116) #13, !nosanitize !7
  br label %8, !nosanitize !7

8:                                                ; preds = %7, %2
  %9 = icmp ne ptr %5, null, !nosanitize !7
  br i1 %9, label %11, label %10, !prof !6, !nosanitize !7

10:                                               ; preds = %8
  call void @__ubsan_handle_nonnull_arg(ptr @117) #13, !nosanitize !7
  br label %11, !nosanitize !7

11:                                               ; preds = %10, %8
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %0, ptr align 1 %5, i64 25, i1 false)
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i64 @gs_fmt_i64(ptr noundef %0, i64 noundef %1) #0 !func_sanitize !43 {
  %3 = alloca i64, align 8
  %4 = alloca ptr, align 8
  %5 = alloca i64, align 8
  store ptr %0, ptr %4, align 8
  store i64 %1, ptr %5, align 8
  %6 = load i64, ptr %5, align 8
  %7 = icmp sge i64 %6, 0
  br i1 %7, label %8, label %12

8:                                                ; preds = %2
  %9 = load ptr, ptr %4, align 8
  %10 = load i64, ptr %5, align 8
  %11 = call i64 @gs_fmt_u64(ptr noundef %9, i64 noundef %10)
  store i64 %11, ptr %3, align 8
  br label %42

12:                                               ; preds = %2
  %13 = load ptr, ptr %4, align 8
  %14 = getelementptr inbounds i8, ptr %13, i64 0
  %15 = icmp ne ptr %14, null, !nosanitize !7
  br i1 %15, label %18, label %16, !prof !6, !nosanitize !7

16:                                               ; preds = %12
  %17 = ptrtoint ptr %14 to i64, !nosanitize !7
  call void @__ubsan_handle_type_mismatch_v1(ptr @129, i64 %17) #13, !nosanitize !7
  br label %18, !nosanitize !7

18:                                               ; preds = %16, %12
  store i8 45, ptr %14, align 1
  %19 = load ptr, ptr %4, align 8
  %20 = getelementptr inbounds i8, ptr %19, i64 1
  %21 = ptrtoint ptr %19 to i64, !nosanitize !7
  %22 = add i64 %21, 1, !nosanitize !7
  %23 = icmp ne ptr %19, null, !nosanitize !7
  %24 = icmp ne i64 %22, 0, !nosanitize !7
  %25 = icmp eq i1 %23, %24, !nosanitize !7
  %26 = icmp uge i64 %22, %21, !nosanitize !7
  %27 = icmp ult i64 %22, %21, !nosanitize !7
  %28 = select i1 true, i1 %26, i1 %27, !nosanitize !7
  %29 = and i1 %28, true, !nosanitize !7
  %30 = and i1 %25, %29, !nosanitize !7
  br i1 %30, label %32, label %31, !prof !6, !nosanitize !7

31:                                               ; preds = %18
  call void @__ubsan_handle_pointer_overflow(ptr @130, i64 %21, i64 %22) #13, !nosanitize !7
  br label %32, !nosanitize !7

32:                                               ; preds = %31, %18
  %33 = load i64, ptr %5, align 8
  %34 = sub i64 0, %33
  %35 = call i64 @gs_fmt_u64(ptr noundef %20, i64 noundef %34)
  %36 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 1, i64 %35), !nosanitize !7
  %37 = extractvalue { i64, i1 } %36, 0, !nosanitize !7
  %38 = extractvalue { i64, i1 } %36, 1, !nosanitize !7
  %39 = xor i1 %38, true, !nosanitize !7
  br i1 %39, label %41, label %40, !prof !6, !nosanitize !7

40:                                               ; preds = %32
  call void @__ubsan_handle_add_overflow(ptr @131, i64 1, i64 %35) #13, !nosanitize !7
  br label %41, !nosanitize !7

41:                                               ; preds = %40, %32
  store i64 %37, ptr %3, align 8
  br label %42

42:                                               ; preds = %41, %8
  %43 = load i64, ptr %3, align 8
  ret i64 %43
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @g_print_bytes(ptr noundef %0, ptr noundef %1, i64 noundef %2) #0 !func_sanitize !44 {
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca i64, align 8
  store ptr %0, ptr %4, align 8
  store ptr %1, ptr %5, align 8
  store i64 %2, ptr %6, align 8
  %7 = load ptr, ptr %4, align 8
  %8 = icmp ne ptr %7, null
  br i1 %8, label %9, label %13

9:                                                ; preds = %3
  %10 = load ptr, ptr %4, align 8
  %11 = load ptr, ptr %5, align 8
  %12 = load i64, ptr %6, align 8
  call void @g_bytes(ptr noundef %10, ptr noundef %11, i64 noundef %12)
  br label %25

13:                                               ; preds = %3
  %14 = load i64, ptr %6, align 8
  %15 = icmp ne i64 %14, 0
  br i1 %15, label %16, label %24

16:                                               ; preds = %13
  %17 = load ptr, ptr %5, align 8
  %18 = load i64, ptr %6, align 8
  %19 = load ptr, ptr @stdout, align 8
  %20 = icmp ne ptr %19, null, !nosanitize !7
  br i1 %20, label %22, label %21, !prof !6, !nosanitize !7

21:                                               ; preds = %16
  call void @__ubsan_handle_nonnull_arg(ptr @167) #13, !nosanitize !7
  br label %22, !nosanitize !7

22:                                               ; preds = %21, %16
  %23 = call i64 @fwrite(ptr noundef %17, i64 noundef 1, i64 noundef %18, ptr noundef %19)
  br label %24

24:                                               ; preds = %22, %13
  br label %25

25:                                               ; preds = %24, %9
  ret void
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i64 @gs_fmt_u64(ptr noundef %0, i64 noundef %1) #0 !func_sanitize !45 {
  %3 = alloca ptr, align 8
  %4 = alloca i64, align 8
  %5 = alloca i32, align 4
  %6 = alloca ptr, align 8
  %7 = alloca i32, align 4
  store ptr %0, ptr %3, align 8
  store i64 %1, ptr %4, align 8
  %8 = load i64, ptr %4, align 8
  %9 = call i32 @gs_fmt_digits(i64 noundef %8)
  store i32 %9, ptr %5, align 4
  %10 = load ptr, ptr %3, align 8
  %11 = load i32, ptr %5, align 4
  %12 = sext i32 %11 to i64
  %13 = getelementptr inbounds i8, ptr %10, i64 %12
  %14 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 1, i64 %12), !nosanitize !7
  %15 = extractvalue { i64, i1 } %14, 1, !nosanitize !7
  %16 = or i1 %15, false, !nosanitize !7
  %17 = extractvalue { i64, i1 } %14, 0, !nosanitize !7
  %18 = ptrtoint ptr %10 to i64, !nosanitize !7
  %19 = add i64 %18, %17, !nosanitize !7
  %20 = icmp ne ptr %10, null, !nosanitize !7
  %21 = icmp ne i64 %19, 0, !nosanitize !7
  %22 = icmp eq i1 %20, %21, !nosanitize !7
  %23 = xor i1 %16, true, !nosanitize !7
  %24 = icmp uge i64 %19, %18, !nosanitize !7
  %25 = icmp sge i64 %17, 0, !nosanitize !7
  %26 = icmp ult i64 %19, %18, !nosanitize !7
  %27 = select i1 %25, i1 %24, i1 %26, !nosanitize !7
  %28 = and i1 %27, %23, !nosanitize !7
  %29 = and i1 %22, %28, !nosanitize !7
  br i1 %29, label %31, label %30, !prof !6, !nosanitize !7

30:                                               ; preds = %2
  call void @__ubsan_handle_pointer_overflow(ptr @132, i64 %18, i64 %19) #13, !nosanitize !7
  br label %31, !nosanitize !7

31:                                               ; preds = %30, %2
  store ptr %13, ptr %6, align 8
  br label %32

32:                                               ; preds = %135, %31
  %33 = load i64, ptr %4, align 8
  %34 = icmp uge i64 %33, 100
  br i1 %34, label %35, label %136

35:                                               ; preds = %32
  %36 = load i64, ptr %4, align 8
  br i1 true, label %38, label %37, !prof !6, !nosanitize !7

37:                                               ; preds = %35
  call void @__ubsan_handle_divrem_overflow(ptr @134, i64 %36, i64 100) #13, !nosanitize !7
  br label %38, !nosanitize !7

38:                                               ; preds = %37, %35
  %39 = urem i64 %36, 100
  %40 = trunc i64 %39 to i32
  store i32 %40, ptr %7, align 4
  %41 = load i64, ptr %4, align 8
  br i1 true, label %43, label %42, !prof !6, !nosanitize !7

42:                                               ; preds = %38
  call void @__ubsan_handle_divrem_overflow(ptr @135, i64 %41, i64 100) #13, !nosanitize !7
  br label %43, !nosanitize !7

43:                                               ; preds = %42, %38
  %44 = udiv i64 %41, 100
  store i64 %44, ptr %4, align 8
  %45 = load ptr, ptr %6, align 8
  %46 = getelementptr inbounds i8, ptr %45, i64 -2
  %47 = ptrtoint ptr %45 to i64, !nosanitize !7
  %48 = add i64 %47, -2, !nosanitize !7
  %49 = icmp ne ptr %45, null, !nosanitize !7
  %50 = icmp ne i64 %48, 0, !nosanitize !7
  %51 = icmp eq i1 %49, %50, !nosanitize !7
  %52 = icmp uge i64 %48, %47, !nosanitize !7
  %53 = icmp ult i64 %48, %47, !nosanitize !7
  %54 = select i1 false, i1 %52, i1 %53, !nosanitize !7
  %55 = and i1 %54, true, !nosanitize !7
  %56 = and i1 %51, %55, !nosanitize !7
  br i1 %56, label %58, label %57, !prof !6, !nosanitize !7

57:                                               ; preds = %43
  call void @__ubsan_handle_pointer_overflow(ptr @136, i64 %47, i64 %48) #13, !nosanitize !7
  br label %58, !nosanitize !7

58:                                               ; preds = %57, %43
  store ptr %46, ptr %6, align 8
  %59 = load i32, ptr %7, align 4
  %60 = mul i32 2, %59
  %61 = zext i32 %60 to i64, !nosanitize !7
  %62 = icmp ult i64 %61, 201, !nosanitize !7
  br i1 %62, label %64, label %63, !prof !6, !nosanitize !7

63:                                               ; preds = %58
  call void @__ubsan_handle_out_of_bounds(ptr @139, i64 %61) #13, !nosanitize !7
  br label %64, !nosanitize !7

64:                                               ; preds = %63, %58
  %65 = zext i32 %60 to i64
  %66 = getelementptr inbounds nuw [201 x i8], ptr @gs_digit_pairs, i64 0, i64 %65
  %67 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 1, i64 %65), !nosanitize !7
  %68 = extractvalue { i64, i1 } %67, 1, !nosanitize !7
  %69 = or i1 %68, false, !nosanitize !7
  %70 = extractvalue { i64, i1 } %67, 0, !nosanitize !7
  %71 = add i64 ptrtoint (ptr @gs_digit_pairs to i64), %70, !nosanitize !7
  %72 = icmp ne i64 %71, 0, !nosanitize !7
  %73 = icmp eq i1 true, %72, !nosanitize !7
  %74 = xor i1 %69, true, !nosanitize !7
  %75 = icmp uge i64 %71, ptrtoint (ptr @gs_digit_pairs to i64), !nosanitize !7
  %76 = and i1 %75, %74, !nosanitize !7
  %77 = and i1 %73, %76, !nosanitize !7
  br i1 %77, label %79, label %78, !prof !6, !nosanitize !7

78:                                               ; preds = %64
  call void @__ubsan_handle_pointer_overflow(ptr @140, i64 ptrtoint (ptr @gs_digit_pairs to i64), i64 %71) #13, !nosanitize !7
  br label %79, !nosanitize !7

79:                                               ; preds = %78, %64
  %80 = icmp ne ptr %66, null, !nosanitize !7
  br i1 %80, label %83, label %81, !prof !6, !nosanitize !7

81:                                               ; preds = %79
  %82 = ptrtoint ptr %66 to i64, !nosanitize !7
  call void @__ubsan_handle_type_mismatch_v1(ptr @142, i64 %82) #13, !nosanitize !7
  br label %83, !nosanitize !7

83:                                               ; preds = %81, %79
  %84 = load i8, ptr %66, align 1
  %85 = load ptr, ptr %6, align 8
  %86 = getelementptr inbounds i8, ptr %85, i64 0
  %87 = icmp ne ptr %86, null, !nosanitize !7
  br i1 %87, label %90, label %88, !prof !6, !nosanitize !7

88:                                               ; preds = %83
  %89 = ptrtoint ptr %86 to i64, !nosanitize !7
  call void @__ubsan_handle_type_mismatch_v1(ptr @143, i64 %89) #13, !nosanitize !7
  br label %90, !nosanitize !7

90:                                               ; preds = %88, %83
  store i8 %84, ptr %86, align 1
  %91 = load i32, ptr %7, align 4
  %92 = mul i32 2, %91
  %93 = add i32 %92, 1
  %94 = zext i32 %93 to i64, !nosanitize !7
  %95 = icmp ult i64 %94, 201, !nosanitize !7
  br i1 %95, label %97, label %96, !prof !6, !nosanitize !7

96:                                               ; preds = %90
  call void @__ubsan_handle_out_of_bounds(ptr @144, i64 %94) #13, !nosanitize !7
  br label %97, !nosanitize !7

97:                                               ; preds = %96, %90
  %98 = zext i32 %93 to i64
  %99 = getelementptr inbounds nuw [201 x i8], ptr @gs_digit_pairs, i64 0, i64 %98
  %100 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 1, i64 %98), !nosanitize !7
  %101 = extractvalue { i64, i1 } %100, 1, !nosanitize !7
  %102 = or i1 %101, false, !nosanitize !7
  %103 = extractvalue { i64, i1 } %100, 0, !nosanitize !7
  %104 = add i64 ptrtoint (ptr @gs_digit_pairs to i64), %103, !nosanitize !7
  %105 = icmp ne i64 %104, 0, !nosanitize !7
  %106 = icmp eq i1 true, %105, !nosanitize !7
  %107 = xor i1 %102, true, !nosanitize !7
  %108 = icmp uge i64 %104, ptrtoint (ptr @gs_digit_pairs to i64), !nosanitize !7
  %109 = and i1 %108, %107, !nosanitize !7
  %110 = and i1 %106, %109, !nosanitize !7
  br i1 %110, label %112, label %111, !prof !6, !nosanitize !7

111:                                              ; preds = %97
  call void @__ubsan_handle_pointer_overflow(ptr @145, i64 ptrtoint (ptr @gs_digit_pairs to i64), i64 %104) #13, !nosanitize !7
  br label %112, !nosanitize !7

112:                                              ; preds = %111, %97
  %113 = icmp ne ptr %99, null, !nosanitize !7
  br i1 %113, label %116, label %114, !prof !6, !nosanitize !7

114:                                              ; preds = %112
  %115 = ptrtoint ptr %99 to i64, !nosanitize !7
  call void @__ubsan_handle_type_mismatch_v1(ptr @146, i64 %115) #13, !nosanitize !7
  br label %116, !nosanitize !7

116:                                              ; preds = %114, %112
  %117 = load i8, ptr %99, align 1
  %118 = load ptr, ptr %6, align 8
  %119 = getelementptr inbounds i8, ptr %118, i64 1
  %120 = ptrtoint ptr %118 to i64, !nosanitize !7
  %121 = add i64 %120, 1, !nosanitize !7
  %122 = icmp ne ptr %118, null, !nosanitize !7
  %123 = icmp ne i64 %121, 0, !nosanitize !7
  %124 = icmp eq i1 %122, %123, !nosanitize !7
  %125 = icmp uge i64 %121, %120, !nosanitize !7
  %126 = icmp ult i64 %121, %120, !nosanitize !7
  %127 = select i1 true, i1 %125, i1 %126, !nosanitize !7
  %128 = and i1 %127, true, !nosanitize !7
  %129 = and i1 %124, %128, !nosanitize !7
  br i1 %129, label %131, label %130, !prof !6, !nosanitize !7

130:                                              ; preds = %116
  call void @__ubsan_handle_pointer_overflow(ptr @147, i64 %120, i64 %121) #13, !nosanitize !7
  br label %131, !nosanitize !7

131:                                              ; preds = %130, %116
  %132 = icmp ne ptr %119, null, !nosanitize !7
  br i1 %132, label %135, label %133, !prof !6, !nosanitize !7

133:                                              ; preds = %131
  %134 = ptrtoint ptr %119 to i64, !nosanitize !7
  call void @__ubsan_handle_type_mismatch_v1(ptr @148, i64 %134) #13, !nosanitize !7
  br label %135, !nosanitize !7

135:                                              ; preds = %133, %131
  store i8 %117, ptr %119, align 1
  br label %32, !llvm.loop !46

136:                                              ; preds = %32
  %137 = load i64, ptr %4, align 8
  %138 = icmp uge i64 %137, 10
  br i1 %138, label %139, label %225

139:                                              ; preds = %136
  %140 = load i64, ptr %4, align 8
  %141 = mul i64 2, %140
  %142 = icmp ult i64 %141, 201, !nosanitize !7
  br i1 %142, label %144, label %143, !prof !6, !nosanitize !7

143:                                              ; preds = %139
  call void @__ubsan_handle_out_of_bounds(ptr @149, i64 %141) #13, !nosanitize !7
  br label %144, !nosanitize !7

144:                                              ; preds = %143, %139
  %145 = getelementptr inbounds nuw [201 x i8], ptr @gs_digit_pairs, i64 0, i64 %141
  %146 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 1, i64 %141), !nosanitize !7
  %147 = extractvalue { i64, i1 } %146, 1, !nosanitize !7
  %148 = or i1 %147, false, !nosanitize !7
  %149 = extractvalue { i64, i1 } %146, 0, !nosanitize !7
  %150 = add i64 ptrtoint (ptr @gs_digit_pairs to i64), %149, !nosanitize !7
  %151 = icmp ne i64 %150, 0, !nosanitize !7
  %152 = icmp eq i1 true, %151, !nosanitize !7
  %153 = xor i1 %148, true, !nosanitize !7
  %154 = icmp uge i64 %150, ptrtoint (ptr @gs_digit_pairs to i64), !nosanitize !7
  %155 = and i1 %154, %153, !nosanitize !7
  %156 = and i1 %152, %155, !nosanitize !7
  br i1 %156, label %158, label %157, !prof !6, !nosanitize !7

157:                                              ; preds = %144
  call void @__ubsan_handle_pointer_overflow(ptr @150, i64 ptrtoint (ptr @gs_digit_pairs to i64), i64 %150) #13, !nosanitize !7
  br label %158, !nosanitize !7

158:                                              ; preds = %157, %144
  %159 = icmp ne ptr %145, null, !nosanitize !7
  br i1 %159, label %162, label %160, !prof !6, !nosanitize !7

160:                                              ; preds = %158
  %161 = ptrtoint ptr %145 to i64, !nosanitize !7
  call void @__ubsan_handle_type_mismatch_v1(ptr @151, i64 %161) #13, !nosanitize !7
  br label %162, !nosanitize !7

162:                                              ; preds = %160, %158
  %163 = load i8, ptr %145, align 1
  %164 = load ptr, ptr %6, align 8
  %165 = getelementptr inbounds i8, ptr %164, i64 -2
  %166 = ptrtoint ptr %164 to i64, !nosanitize !7
  %167 = add i64 %166, -2, !nosanitize !7
  %168 = icmp ne ptr %164, null, !nosanitize !7
  %169 = icmp ne i64 %167, 0, !nosanitize !7
  %170 = icmp eq i1 %168, %169, !nosanitize !7
  %171 = icmp uge i64 %167, %166, !nosanitize !7
  %172 = icmp ult i64 %167, %166, !nosanitize !7
  %173 = select i1 false, i1 %171, i1 %172, !nosanitize !7
  %174 = and i1 %173, true, !nosanitize !7
  %175 = and i1 %170, %174, !nosanitize !7
  br i1 %175, label %177, label %176, !prof !6, !nosanitize !7

176:                                              ; preds = %162
  call void @__ubsan_handle_pointer_overflow(ptr @152, i64 %166, i64 %167) #13, !nosanitize !7
  br label %177, !nosanitize !7

177:                                              ; preds = %176, %162
  %178 = icmp ne ptr %165, null, !nosanitize !7
  br i1 %178, label %181, label %179, !prof !6, !nosanitize !7

179:                                              ; preds = %177
  %180 = ptrtoint ptr %165 to i64, !nosanitize !7
  call void @__ubsan_handle_type_mismatch_v1(ptr @153, i64 %180) #13, !nosanitize !7
  br label %181, !nosanitize !7

181:                                              ; preds = %179, %177
  store i8 %163, ptr %165, align 1
  %182 = load i64, ptr %4, align 8
  %183 = mul i64 2, %182
  %184 = add i64 %183, 1
  %185 = icmp ult i64 %184, 201, !nosanitize !7
  br i1 %185, label %187, label %186, !prof !6, !nosanitize !7

186:                                              ; preds = %181
  call void @__ubsan_handle_out_of_bounds(ptr @154, i64 %184) #13, !nosanitize !7
  br label %187, !nosanitize !7

187:                                              ; preds = %186, %181
  %188 = getelementptr inbounds nuw [201 x i8], ptr @gs_digit_pairs, i64 0, i64 %184
  %189 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 1, i64 %184), !nosanitize !7
  %190 = extractvalue { i64, i1 } %189, 1, !nosanitize !7
  %191 = or i1 %190, false, !nosanitize !7
  %192 = extractvalue { i64, i1 } %189, 0, !nosanitize !7
  %193 = add i64 ptrtoint (ptr @gs_digit_pairs to i64), %192, !nosanitize !7
  %194 = icmp ne i64 %193, 0, !nosanitize !7
  %195 = icmp eq i1 true, %194, !nosanitize !7
  %196 = xor i1 %191, true, !nosanitize !7
  %197 = icmp uge i64 %193, ptrtoint (ptr @gs_digit_pairs to i64), !nosanitize !7
  %198 = and i1 %197, %196, !nosanitize !7
  %199 = and i1 %195, %198, !nosanitize !7
  br i1 %199, label %201, label %200, !prof !6, !nosanitize !7

200:                                              ; preds = %187
  call void @__ubsan_handle_pointer_overflow(ptr @155, i64 ptrtoint (ptr @gs_digit_pairs to i64), i64 %193) #13, !nosanitize !7
  br label %201, !nosanitize !7

201:                                              ; preds = %200, %187
  %202 = icmp ne ptr %188, null, !nosanitize !7
  br i1 %202, label %205, label %203, !prof !6, !nosanitize !7

203:                                              ; preds = %201
  %204 = ptrtoint ptr %188 to i64, !nosanitize !7
  call void @__ubsan_handle_type_mismatch_v1(ptr @156, i64 %204) #13, !nosanitize !7
  br label %205, !nosanitize !7

205:                                              ; preds = %203, %201
  %206 = load i8, ptr %188, align 1
  %207 = load ptr, ptr %6, align 8
  %208 = getelementptr inbounds i8, ptr %207, i64 -1
  %209 = ptrtoint ptr %207 to i64, !nosanitize !7
  %210 = add i64 %209, -1, !nosanitize !7
  %211 = icmp ne ptr %207, null, !nosanitize !7
  %212 = icmp ne i64 %210, 0, !nosanitize !7
  %213 = icmp eq i1 %211, %212, !nosanitize !7
  %214 = icmp uge i64 %210, %209, !nosanitize !7
  %215 = icmp ult i64 %210, %209, !nosanitize !7
  %216 = select i1 false, i1 %214, i1 %215, !nosanitize !7
  %217 = and i1 %216, true, !nosanitize !7
  %218 = and i1 %213, %217, !nosanitize !7
  br i1 %218, label %220, label %219, !prof !6, !nosanitize !7

219:                                              ; preds = %205
  call void @__ubsan_handle_pointer_overflow(ptr @157, i64 %209, i64 %210) #13, !nosanitize !7
  br label %220, !nosanitize !7

220:                                              ; preds = %219, %205
  %221 = icmp ne ptr %208, null, !nosanitize !7
  br i1 %221, label %224, label %222, !prof !6, !nosanitize !7

222:                                              ; preds = %220
  %223 = ptrtoint ptr %208 to i64, !nosanitize !7
  call void @__ubsan_handle_type_mismatch_v1(ptr @158, i64 %223) #13, !nosanitize !7
  br label %224, !nosanitize !7

224:                                              ; preds = %222, %220
  store i8 %206, ptr %208, align 1
  br label %247

225:                                              ; preds = %136
  %226 = load i64, ptr %4, align 8
  %227 = add i64 48, %226
  %228 = trunc i64 %227 to i8
  %229 = load ptr, ptr %6, align 8
  %230 = getelementptr inbounds i8, ptr %229, i64 -1
  %231 = ptrtoint ptr %229 to i64, !nosanitize !7
  %232 = add i64 %231, -1, !nosanitize !7
  %233 = icmp ne ptr %229, null, !nosanitize !7
  %234 = icmp ne i64 %232, 0, !nosanitize !7
  %235 = icmp eq i1 %233, %234, !nosanitize !7
  %236 = icmp uge i64 %232, %231, !nosanitize !7
  %237 = icmp ult i64 %232, %231, !nosanitize !7
  %238 = select i1 false, i1 %236, i1 %237, !nosanitize !7
  %239 = and i1 %238, true, !nosanitize !7
  %240 = and i1 %235, %239, !nosanitize !7
  br i1 %240, label %242, label %241, !prof !6, !nosanitize !7

241:                                              ; preds = %225
  call void @__ubsan_handle_pointer_overflow(ptr @159, i64 %231, i64 %232) #13, !nosanitize !7
  br label %242, !nosanitize !7

242:                                              ; preds = %241, %225
  %243 = icmp ne ptr %230, null, !nosanitize !7
  br i1 %243, label %246, label %244, !prof !6, !nosanitize !7

244:                                              ; preds = %242
  %245 = ptrtoint ptr %230 to i64, !nosanitize !7
  call void @__ubsan_handle_type_mismatch_v1(ptr @160, i64 %245) #13, !nosanitize !7
  br label %246, !nosanitize !7

246:                                              ; preds = %244, %242
  store i8 %228, ptr %230, align 1
  br label %247

247:                                              ; preds = %246, %224
  %248 = load i32, ptr %5, align 4
  %249 = sext i32 %248 to i64
  ret i64 %249
}

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal i32 @gs_fmt_digits(i64 noundef %0) #0 !func_sanitize !47 {
  %2 = alloca i32, align 4
  %3 = alloca i64, align 8
  %4 = alloca i32, align 4
  store i64 %0, ptr %3, align 8
  store i32 1, ptr %4, align 4
  br label %5

5:                                                ; preds = %58, %1
  %6 = load i64, ptr %3, align 8
  %7 = icmp ult i64 %6, 10
  br i1 %7, label %8, label %10

8:                                                ; preds = %5
  %9 = load i32, ptr %4, align 4
  store i32 %9, ptr %2, align 4
  br label %59

10:                                               ; preds = %5
  %11 = load i64, ptr %3, align 8
  %12 = icmp ult i64 %11, 100
  br i1 %12, label %13, label %22

13:                                               ; preds = %10
  %14 = load i32, ptr %4, align 4
  %15 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %14, i32 1), !nosanitize !7
  %16 = extractvalue { i32, i1 } %15, 0, !nosanitize !7
  %17 = extractvalue { i32, i1 } %15, 1, !nosanitize !7
  %18 = xor i1 %17, true, !nosanitize !7
  br i1 %18, label %21, label %19, !prof !6, !nosanitize !7

19:                                               ; preds = %13
  %20 = zext i32 %14 to i64, !nosanitize !7
  call void @__ubsan_handle_add_overflow(ptr @162, i64 %20, i64 1) #13, !nosanitize !7
  br label %21, !nosanitize !7

21:                                               ; preds = %19, %13
  store i32 %16, ptr %2, align 4
  br label %59

22:                                               ; preds = %10
  %23 = load i64, ptr %3, align 8
  %24 = icmp ult i64 %23, 1000
  br i1 %24, label %25, label %34

25:                                               ; preds = %22
  %26 = load i32, ptr %4, align 4
  %27 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %26, i32 2), !nosanitize !7
  %28 = extractvalue { i32, i1 } %27, 0, !nosanitize !7
  %29 = extractvalue { i32, i1 } %27, 1, !nosanitize !7
  %30 = xor i1 %29, true, !nosanitize !7
  br i1 %30, label %33, label %31, !prof !6, !nosanitize !7

31:                                               ; preds = %25
  %32 = zext i32 %26 to i64, !nosanitize !7
  call void @__ubsan_handle_add_overflow(ptr @163, i64 %32, i64 2) #13, !nosanitize !7
  br label %33, !nosanitize !7

33:                                               ; preds = %31, %25
  store i32 %28, ptr %2, align 4
  br label %59

34:                                               ; preds = %22
  %35 = load i64, ptr %3, align 8
  %36 = icmp ult i64 %35, 10000
  br i1 %36, label %37, label %46

37:                                               ; preds = %34
  %38 = load i32, ptr %4, align 4
  %39 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %38, i32 3), !nosanitize !7
  %40 = extractvalue { i32, i1 } %39, 0, !nosanitize !7
  %41 = extractvalue { i32, i1 } %39, 1, !nosanitize !7
  %42 = xor i1 %41, true, !nosanitize !7
  br i1 %42, label %45, label %43, !prof !6, !nosanitize !7

43:                                               ; preds = %37
  %44 = zext i32 %38 to i64, !nosanitize !7
  call void @__ubsan_handle_add_overflow(ptr @164, i64 %44, i64 3) #13, !nosanitize !7
  br label %45, !nosanitize !7

45:                                               ; preds = %43, %37
  store i32 %40, ptr %2, align 4
  br label %59

46:                                               ; preds = %34
  %47 = load i64, ptr %3, align 8
  br i1 true, label %49, label %48, !prof !6, !nosanitize !7

48:                                               ; preds = %46
  call void @__ubsan_handle_divrem_overflow(ptr @165, i64 %47, i64 10000) #13, !nosanitize !7
  br label %49, !nosanitize !7

49:                                               ; preds = %48, %46
  %50 = udiv i64 %47, 10000
  store i64 %50, ptr %3, align 8
  %51 = load i32, ptr %4, align 4
  %52 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %51, i32 4), !nosanitize !7
  %53 = extractvalue { i32, i1 } %52, 0, !nosanitize !7
  %54 = extractvalue { i32, i1 } %52, 1, !nosanitize !7
  %55 = xor i1 %54, true, !nosanitize !7
  br i1 %55, label %58, label %56, !prof !6, !nosanitize !7

56:                                               ; preds = %49
  %57 = zext i32 %51 to i64, !nosanitize !7
  call void @__ubsan_handle_add_overflow(ptr @166, i64 %57, i64 4) #13, !nosanitize !7
  br label %58, !nosanitize !7

58:                                               ; preds = %56, %49
  store i32 %53, ptr %4, align 4
  br label %5

59:                                               ; preds = %45, %33, %21, %8
  %60 = load i32, ptr %2, align 4
  ret i32 %60
}

; Function Attrs: uwtable
declare void @__ubsan_handle_out_of_bounds(ptr, i64) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32) #10

; Function Attrs: noinline nounwind optnone sspstrong uwtable
define internal void @g_bytes(ptr noundef %0, ptr noundef %1, i64 noundef %2) #0 !func_sanitize !44 {
  %4 = alloca ptr, align 8
  %5 = alloca ptr, align 8
  %6 = alloca i64, align 8
  %7 = alloca ptr, align 8
  store ptr %0, ptr %4, align 8
  store ptr %1, ptr %5, align 8
  store i64 %2, ptr %6, align 8
  %8 = load i64, ptr %6, align 8
  %9 = icmp sle i64 %8, 0
  br i1 %9, label %10, label %11

10:                                               ; preds = %3
  br label %124

11:                                               ; preds = %3
  %12 = load ptr, ptr %4, align 8
  %13 = call ptr @g_ref(ptr noundef %12)
  store ptr %13, ptr %7, align 8
  %14 = load ptr, ptr %7, align 8
  %15 = load ptr, ptr %4, align 8
  %16 = icmp ne ptr %15, null, !nosanitize !7
  %17 = ptrtoint ptr %15 to i64, !nosanitize !7
  %18 = and i64 %17, 7, !nosanitize !7
  %19 = icmp eq i64 %18, 0, !nosanitize !7
  %20 = and i1 %16, %19, !nosanitize !7
  br i1 %20, label %22, label %21, !prof !6, !nosanitize !7

21:                                               ; preds = %11
  call void @__ubsan_handle_type_mismatch_v1(ptr @169, i64 %17) #13, !nosanitize !7
  br label %22, !nosanitize !7

22:                                               ; preds = %21, %11
  %23 = getelementptr inbounds nuw %struct.GArray, ptr %15, i32 0, i32 1
  %24 = icmp ne ptr %23, null, !nosanitize !7
  %25 = ptrtoint ptr %23 to i64, !nosanitize !7
  %26 = and i64 %25, 7, !nosanitize !7
  %27 = icmp eq i64 %26, 0, !nosanitize !7
  %28 = and i1 %24, %27, !nosanitize !7
  br i1 %28, label %30, label %29, !prof !6, !nosanitize !7

29:                                               ; preds = %22
  call void @__ubsan_handle_type_mismatch_v1(ptr @170, i64 %25) #13, !nosanitize !7
  br label %30, !nosanitize !7

30:                                               ; preds = %29, %22
  %31 = load i64, ptr %23, align 8
  %32 = load i64, ptr %6, align 8
  %33 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %31, i64 %32), !nosanitize !7
  %34 = extractvalue { i64, i1 } %33, 0, !nosanitize !7
  %35 = extractvalue { i64, i1 } %33, 1, !nosanitize !7
  %36 = xor i1 %35, true, !nosanitize !7
  br i1 %36, label %38, label %37, !prof !6, !nosanitize !7

37:                                               ; preds = %30
  call void @__ubsan_handle_add_overflow(ptr @171, i64 %31, i64 %32) #13, !nosanitize !7
  br label %38, !nosanitize !7

38:                                               ; preds = %37, %30
  call void @g_reserve(ptr noundef %14, i32 noundef 3, i64 noundef -1, i32 noundef 0, i64 noundef 1, i64 noundef %34)
  %39 = load ptr, ptr %4, align 8
  %40 = icmp ne ptr %39, null, !nosanitize !7
  %41 = ptrtoint ptr %39 to i64, !nosanitize !7
  %42 = and i64 %41, 7, !nosanitize !7
  %43 = icmp eq i64 %42, 0, !nosanitize !7
  %44 = and i1 %40, %43, !nosanitize !7
  br i1 %44, label %46, label %45, !prof !6, !nosanitize !7

45:                                               ; preds = %38
  call void @__ubsan_handle_type_mismatch_v1(ptr @172, i64 %41) #13, !nosanitize !7
  br label %46, !nosanitize !7

46:                                               ; preds = %45, %38
  %47 = getelementptr inbounds nuw %struct.GArray, ptr %39, i32 0, i32 0
  %48 = icmp ne ptr %47, null, !nosanitize !7
  %49 = ptrtoint ptr %47 to i64, !nosanitize !7
  %50 = and i64 %49, 7, !nosanitize !7
  %51 = icmp eq i64 %50, 0, !nosanitize !7
  %52 = and i1 %48, %51, !nosanitize !7
  br i1 %52, label %54, label %53, !prof !6, !nosanitize !7

53:                                               ; preds = %46
  call void @__ubsan_handle_type_mismatch_v1(ptr @173, i64 %49) #13, !nosanitize !7
  br label %54, !nosanitize !7

54:                                               ; preds = %53, %46
  %55 = load ptr, ptr %47, align 8
  %56 = load ptr, ptr %4, align 8
  %57 = icmp ne ptr %56, null, !nosanitize !7
  %58 = ptrtoint ptr %56 to i64, !nosanitize !7
  %59 = and i64 %58, 7, !nosanitize !7
  %60 = icmp eq i64 %59, 0, !nosanitize !7
  %61 = and i1 %57, %60, !nosanitize !7
  br i1 %61, label %63, label %62, !prof !6, !nosanitize !7

62:                                               ; preds = %54
  call void @__ubsan_handle_type_mismatch_v1(ptr @174, i64 %58) #13, !nosanitize !7
  br label %63, !nosanitize !7

63:                                               ; preds = %62, %54
  %64 = getelementptr inbounds nuw %struct.GArray, ptr %56, i32 0, i32 1
  %65 = icmp ne ptr %64, null, !nosanitize !7
  %66 = ptrtoint ptr %64 to i64, !nosanitize !7
  %67 = and i64 %66, 7, !nosanitize !7
  %68 = icmp eq i64 %67, 0, !nosanitize !7
  %69 = and i1 %65, %68, !nosanitize !7
  br i1 %69, label %71, label %70, !prof !6, !nosanitize !7

70:                                               ; preds = %63
  call void @__ubsan_handle_type_mismatch_v1(ptr @175, i64 %66) #13, !nosanitize !7
  br label %71, !nosanitize !7

71:                                               ; preds = %70, %63
  %72 = load i64, ptr %64, align 8
  %73 = getelementptr inbounds i8, ptr %55, i64 %72
  %74 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 1, i64 %72), !nosanitize !7
  %75 = extractvalue { i64, i1 } %74, 1, !nosanitize !7
  %76 = or i1 %75, false, !nosanitize !7
  %77 = extractvalue { i64, i1 } %74, 0, !nosanitize !7
  %78 = ptrtoint ptr %55 to i64, !nosanitize !7
  %79 = add i64 %78, %77, !nosanitize !7
  %80 = icmp ne ptr %55, null, !nosanitize !7
  %81 = icmp ne i64 %79, 0, !nosanitize !7
  %82 = icmp eq i1 %80, %81, !nosanitize !7
  %83 = xor i1 %76, true, !nosanitize !7
  %84 = icmp uge i64 %79, %78, !nosanitize !7
  %85 = icmp sge i64 %77, 0, !nosanitize !7
  %86 = icmp ult i64 %79, %78, !nosanitize !7
  %87 = select i1 %85, i1 %84, i1 %86, !nosanitize !7
  %88 = and i1 %87, %83, !nosanitize !7
  %89 = and i1 %82, %88, !nosanitize !7
  br i1 %89, label %91, label %90, !prof !6, !nosanitize !7

90:                                               ; preds = %71
  call void @__ubsan_handle_pointer_overflow(ptr @176, i64 %78, i64 %79) #13, !nosanitize !7
  br label %91, !nosanitize !7

91:                                               ; preds = %90, %71
  %92 = load ptr, ptr %5, align 8
  %93 = load i64, ptr %6, align 8
  %94 = icmp ne ptr %73, null, !nosanitize !7
  br i1 %94, label %96, label %95, !prof !6, !nosanitize !7

95:                                               ; preds = %91
  call void @__ubsan_handle_nonnull_arg(ptr @177) #13, !nosanitize !7
  br label %96, !nosanitize !7

96:                                               ; preds = %95, %91
  %97 = icmp ne ptr %92, null, !nosanitize !7
  br i1 %97, label %99, label %98, !prof !6, !nosanitize !7

98:                                               ; preds = %96
  call void @__ubsan_handle_nonnull_arg(ptr @178) #13, !nosanitize !7
  br label %99, !nosanitize !7

99:                                               ; preds = %98, %96
  call void @llvm.memmove.p0.p0.i64(ptr align 1 %73, ptr align 1 %92, i64 %93, i1 false)
  %100 = load i64, ptr %6, align 8
  %101 = load ptr, ptr %4, align 8
  %102 = icmp ne ptr %101, null, !nosanitize !7
  %103 = ptrtoint ptr %101 to i64, !nosanitize !7
  %104 = and i64 %103, 7, !nosanitize !7
  %105 = icmp eq i64 %104, 0, !nosanitize !7
  %106 = and i1 %102, %105, !nosanitize !7
  br i1 %106, label %108, label %107, !prof !6, !nosanitize !7

107:                                              ; preds = %99
  call void @__ubsan_handle_type_mismatch_v1(ptr @179, i64 %103) #13, !nosanitize !7
  br label %108, !nosanitize !7

108:                                              ; preds = %107, %99
  %109 = getelementptr inbounds nuw %struct.GArray, ptr %101, i32 0, i32 1
  %110 = icmp ne ptr %109, null, !nosanitize !7
  %111 = ptrtoint ptr %109 to i64, !nosanitize !7
  %112 = and i64 %111, 7, !nosanitize !7
  %113 = icmp eq i64 %112, 0, !nosanitize !7
  %114 = and i1 %110, %113, !nosanitize !7
  br i1 %114, label %116, label %115, !prof !6, !nosanitize !7

115:                                              ; preds = %108
  call void @__ubsan_handle_type_mismatch_v1(ptr @180, i64 %111) #13, !nosanitize !7
  br label %116, !nosanitize !7

116:                                              ; preds = %115, %108
  %117 = load i64, ptr %109, align 8
  %118 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %117, i64 %100), !nosanitize !7
  %119 = extractvalue { i64, i1 } %118, 0, !nosanitize !7
  %120 = extractvalue { i64, i1 } %118, 1, !nosanitize !7
  %121 = xor i1 %120, true, !nosanitize !7
  br i1 %121, label %123, label %122, !prof !6, !nosanitize !7

122:                                              ; preds = %116
  call void @__ubsan_handle_add_overflow(ptr @181, i64 %117, i64 %100) #13, !nosanitize !7
  br label %123, !nosanitize !7

123:                                              ; preds = %122, %116
  store i64 %119, ptr %109, align 8
  br label %124

124:                                              ; preds = %123, %10
  ret void
}

declare i64 @fwrite(ptr noundef, i64 noundef, i64 noundef, ptr noundef) #11

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memmove.p0.p0.i64(ptr writeonly captures(none), ptr readonly captures(none), i64, i1 immarg) #6

; Function Attrs: nounwind willreturn memory(read)
declare i64 @strlen(ptr noundef) #12

attributes #0 = { noinline nounwind optnone sspstrong uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { uwtable }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #4 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #5 = { nounwind returns_twice "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #7 = { nounwind allocsize(0,1) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { nounwind allocsize(0) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #9 = { noreturn nounwind uwtable }
attributes #10 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #11 = { "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #12 = { nounwind willreturn memory(read) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #13 = { nomerge nounwind }
attributes #14 = { nounwind }
attributes #15 = { nounwind returns_twice }
attributes #16 = { nounwind willreturn memory(read) }
attributes #17 = { nounwind allocsize(0,1) }
attributes #18 = { nounwind allocsize(0) }
attributes #19 = { nomerge noreturn nounwind }

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}

!0 = !{i32 8, !"PIC Level", i32 2}
!1 = !{i32 7, !"PIE Level", i32 2}
!2 = !{i32 7, !"uwtable", i32 2}
!3 = !{i32 7, !"frame-pointer", i32 2}
!4 = !{!"clang version 23.1.4"}
!5 = !{i32 -1056584962, i32 -1359287618}
!6 = !{!"branch_weights", i32 1048575, i32 1}
!7 = !{}
!8 = !{i32 -1056584962, i32 905068220}
!9 = distinct !{!9, !10}
!10 = !{!"llvm.loop.mustprogress"}
!11 = !{i32 -1056584962, i32 678431871}
!12 = !{i32 -1056584962, i32 301567483}
!13 = !{i32 -1056584962, i32 -2078042771}
!14 = !{i32 -1056584962, i32 -1330558852}
!15 = !{i32 -1056584962, i32 -898975478}
!16 = !{i32 -1056584962, i32 1022264975}
!17 = !{i32 -1056584962, i32 -2026065387}
!18 = !{i32 -1056584962, i32 -1459969037}
!19 = !{i32 -1056584962, i32 -1422700610}
!20 = distinct !{!20, !10}
!21 = !{i32 -1056584962, i32 62662881}
!22 = !{i32 -1056584962, i32 -739585828}
!23 = !{i32 -1056584962, i32 264116041}
!24 = !{i32 -1056584962, i32 -1430252629}
!25 = distinct !{!25, !10}
!26 = !{i32 -1056584962, i32 1935577798}
!27 = !{i32 -1056584962, i32 -521812245}
!28 = !{i32 -1056584962, i32 -1652325427}
!29 = !{i32 -1056584962, i32 -1008557448}
!30 = !{i32 -1056584962, i32 1506541315}
!31 = distinct !{!31, !10}
!32 = !{i32 -1056584962, i32 1362895967}
!33 = !{i32 -1056584962, i32 1945911726}
!34 = !{i32 -1056584962, i32 -1840228982}
!35 = !{i32 -1056584962, i32 1621769557}
!36 = !{i32 -1056584962, i32 1614614061}
!37 = !{i32 -1056584962, i32 -529346796}
!38 = !{i32 -1056584962, i32 508789304}
!39 = !{i32 -1056584962, i32 -1052961672}
!40 = !{i32 -1056584962, i32 1414169877}
!41 = !{i32 -1056584962, i32 -338927675}
!42 = !{i32 -1056584962, i32 1923751461}
!43 = !{i32 -1056584962, i32 724052357}
!44 = !{i32 -1056584962, i32 900826269}
!45 = !{i32 -1056584962, i32 -157865977}
!46 = distinct !{!46, !10}
!47 = !{i32 -1056584962, i32 -1765455387}
