from pathlib import Path
import subprocess,time,os,random,json,hashlib,statistics,copy
root=Path('/home/jacobt/src/goose-to-wasm');old=Path('/dev/shm/goose-compile-times-2');out=Path('/dev/shm/goose-compile-times-3')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
original=json.loads((old/'report.json').read_text());assert original['status']=='passed'
for name,expected in original['input_sha256'].items():
 if name!=str(root/'selfhost/benchmark.py'):assert sha(name)==expected,name
for e in original['executables'].values():assert sha(e['path'])==e['sha256']
inputs={name:sha(name) for name in original['input_sha256']};inputs[str(out/'run.py')]=sha(out/'run.py')
r=copy.deepcopy(original);r.update(status='running',commands=[],qualification=[],observations=[],program_summary=[],input_sha256=inputs)
r.pop('input_sha256_after',None);r['build_cohort']={'report':str(old/'report.json'),'sha256':sha(old/'report.json'),'script_sha256':sha(old/'benchmark.py'),'note':'Clean build observations reused. Prior program timings rejected due~1ms timeout-wait bias; this cohort has blocking wait.'};r['configuration']['output_dir']=str(out)
r['method']+=' Final program cohort uses blocking subprocess.run with no timeout, avoiding timeout-wait polling. Build cohort is separately pinned.'
original_affinity=sorted(os.sched_getaffinity(0));r['environment'].update(program_load_start=os.getloadavg());os.sched_setaffinity(0,[2]);counter=0
examples=json.loads((root/'examples/manifest.json').read_text())['examples'];profiles=['cpp-release','goose-gcc-O0','goose-gcc-O2'];cells=[(name,e,level) for e in examples for level in [0,2] for name in profiles]
(out/'wasm').mkdir();(out/'logs').mkdir();rng=random.Random(67104)
def save():(out/'report.json').write_text(json.dumps(r,indent=2)+'\n')
def run(cmd,label):
 global counter
 d=out/'logs'/f'{counter:05d}-{label}';counter+=1;d.mkdir();start=time.perf_counter_ns();p=subprocess.run(list(map(str,cmd)),cwd=root,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE);seconds=(time.perf_counter_ns()-start)/1e9
 (d/'stdout').write_bytes(p.stdout);(d/'stderr').write_bytes(p.stderr);row={'command':list(map(str,cmd)),'seconds':seconds,'exit_code':p.returncode,'log':str(d.relative_to(out))};r['commands'].append(row);assert p.returncode==0,(label,p.stderr.decode());return row
def compile_cell(name,e,level):
 artifact=out/'wasm'/f'{name}-{e["name"]}-O{level}.wasm';cmd=[r['executables'][name]['path'],root/'examples'/e['file'],'--target','wasm-direct','--stdlib',old/'stdlib',f'-O{level}','-o',artifact];return run(cmd,'program'),artifact
save()
try:
 for name,e,level in cells:
  _,artifact=compile_cell(name,e,level);row=run([root/'build/bin/goose-wasmtime','--no-cache',artifact],'qualify');stdout=out/row['log']/'stdout';golden=root/'examples'/e['expected'];assert stdout.read_bytes()==golden.read_bytes()
  r['qualification'].append({'profile':name,'example':e['name'],'level':level,'artifact_sha256':sha(artifact),'module_bytes':artifact.stat().st_size,'stdout_sha256':sha(stdout),'golden_sha256':sha(golden)})
 for phase,count in [('warmup',2),('measure',21)]:
  for sample in range(count):
   order=list(cells);rng.shuffle(order)
   for name,e,level in order:
    row,_=compile_cell(name,e,level);r['observations'].append({'profile':name,'example':e['name'],'level':level,'phase':phase,'sample':sample,'seconds':row['seconds']})
   save()
  print(phase,count,flush=True)
 for name,e,level in cells:
  values=[x['seconds']*1000 for x in r['observations'] if x['phase']=='measure' and (x['profile'],x['example'],x['level'])==(name,e['name'],level)]
  r['program_summary'].append({'profile':name,'example':e['name'],'level':level,'median_ms':statistics.median(values),'min_ms':min(values),'max_ms':max(values),'samples':len(values)})
 r['input_sha256_after']={name:sha(name) for name in inputs};assert r['input_sha256_after']==inputs;r['environment']['program_load_end']=os.getloadavg();r['status']='passed'
except BaseException as error:r.update(status='failed',error=repr(error));raise
finally:os.sched_setaffinity(0,original_affinity);save()
print(out/'report.json')
