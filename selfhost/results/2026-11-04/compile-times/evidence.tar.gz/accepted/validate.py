from pathlib import Path
import json,subprocess,hashlib
root=Path('/home/jacobt/src/goose-to-wasm');out=Path('/dev/shm/goose-compile-times-3');old=Path('/dev/shm/goose-compile-times-2');r=json.loads((out/'report.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();checks=[]
for q in r['qualification']:
 p=out/'wasm'/f'{q["profile"]}-{q["example"]}-O{q["level"]}.wasm';assert sha(p)==q['artifact_sha256'];checks.append({'kind':'qualified-artifact-unchanged','profile':q['profile'],'example':q['example'],'level':q['level'],'sha256':sha(p)})
for e in json.loads((root/'examples/manifest.json').read_text())['examples']:
 for level in [0,2]:
  a=out/'wasm'/f'goose-gcc-O0-{e["name"]}-O{level}.wasm';b=out/'wasm'/f'goose-gcc-O2-{e["name"]}-O{level}.wasm';assert a.read_bytes()==b.read_bytes();checks.append({'kind':'goose-build-profiles-byte-identical','example':e['name'],'level':level,'sha256':sha(a)})
 d=out/'rebuilt-cpp-validation';d.mkdir(exist_ok=True)
 for sample in range(3):
  binary=old/'builds'/f'{sample}-cpp-release'/'goose';artifact=d/f'{sample}-{e["name"]}.wasm';cmd=[binary,root/'examples'/e['file'],'--target','wasm-direct','--stdlib',old/'stdlib','-O2','-o',artifact];p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE);(d/f'{sample}-{e["name"]}.stdout').write_bytes(p.stdout);(d/f'{sample}-{e["name"]}.stderr').write_bytes(p.stderr);assert p.returncode==0,p.stderr
  reference=out/'wasm'/f'cpp-release-{e["name"]}-O2.wasm';assert artifact.read_bytes()==reference.read_bytes();checks.append({'kind':'rebuilt-cpp-byte-identical-to-frozen-oracle','sample':sample,'example':e['name'],'binary_sha256':sha(binary),'artifact_sha256':sha(artifact),'command':list(map(str,cmd))})
summary={'status':'passed','checks':checks,'counts':{'qualified_artifacts_unchanged':60,'goose_build_profiles_byte_identical':20,'rebuilt_cpp_matches':30}}
(out/'validation.json').write_text(json.dumps(summary,indent=2)+'\n');print(summary['counts'])
