# Print factory performance review

Read-only review, 2026-11-05. No compiler/oracle or benchmark was run, and no compiler source was edited. Inspected frozen snapshots 34/37, their existing five-sample example/host reports, and Wasm section/body lengths with a small binary reader. New output is this ignored disk file only.

## Conclusion

Plain scalar/byte-only print already bypasses the factory in snapshot37. The useful minimal repair is to create the output builder type lazily, after deciding that lowering is required. The larger aggregate growth comes from newly reachable render helpers containing repeated raw builder-append machinery. Address that in Wasm code generation while preserving the semantic rendering graph.

## Exact minimal frontend patch

In `selfhost/checker.goose:check_lower_rendering` (snapshot37 lines 2502-2586), move:

```goose
let output_type = render_output_type(p); let array_type = p.types[output_type].element;
```

from before the `c.render_hooks` population loop to immediately after:

```goose
if !needed { return -2; }
```

No new leaf predicate, hook resolver, cache, or flag is required. Keep layout validation, the existing hook scan/resolution, recursive-type validation, and the `needed` decision in their current order. The builder types are used only after that decision. Generated output/parameter types are not themselves rendered as values, so creating the builder after the original value types' hook table is populated does not omit a value hook.

Why this matters even when no builder is emitted: `render_output_type` eagerly inserts `u8[>..]` plus its reference. `cg_collect` (3287-3289) scans every type for a growable array and enables the resolver when region mode is absent. The plain `squares` workload gains exactly two types, zero checked nodes, zero semantic functions, one emitted Wasm body, and 193 module bytes between 34 and 37. That is a concrete demand leak, separate from rendering correctness.

Do not promise an exact 193-byte recovery before building: 34 and 37 differ elsewhere. The unchanged node/function counts and the all-types resolver path strongly identify the mechanism; qualify the patched 37 artifact against unmodified 37 to establish the exact improvement.

An additional early return for globally hook-free leaf calls could avoid scanning layouts/types, but it duplicates the existing classification and is not needed for this first patch. In particular, do not add a type-only return ahead of overload selection or `check_value`.

## What actually grew

These are existing pinned `compile/*/direct/0/program.wasm` artifacts, not timing estimates. All ten example source hashes match across snapshots; the three reviewed compiler source files match their corresponding benchmark snapshots byte-for-byte. “Functions” means checked backend functions; emitted body counts also include closure wrappers/runtime support.

| Workload | Module bytes 34 -> 37 | Code-section bytes 34 -> 37 | Data-section bytes 34 -> 37 | Functions 34 -> 37 | Emitted bodies 34 -> 37 |
|---|---:|---:|---:|---:|---:|
| squares | 1,659 -> 1,852 | 1,242 -> 1,419 | 112 -> 112 | 2 -> 2 | 7 -> 8 |
| tour | 54,095 -> 119,134 | 52,592 -> 117,484 | 1,068 -> 1,127 | 7 -> 24 | 18 -> 52 |
| sieve | 19,111 -> 36,525 | 18,112 -> 35,426 | 660 -> 734 | 1 -> 6 | 6 -> 16 |
| functions | 205,148 -> 227,174 | 203,413 -> 225,334 | 880 -> 939 | 95 -> 103 | 192 -> 208 |
| sorting | 199,792 -> 211,314 | 198,175 -> 209,612 | 777 -> 836 | 90 -> 94 | 182 -> 190 |

`errors` (45,357), `sudoku` (20,637), `maze` (102,459), `vm` (81,822), and `life` (37,570) are byte-for-byte identical Wasm modules across these snapshots, verified by SHA-256, not merely equal size. Their differing timing observations cannot be attributed to changed Wasm code.

CX changes `wasm_default` from builtins 1/2 to 0/1/2. The existing `needed` loop still returns raw for hook-free primitive/bool/byte-sequence calls. It lowers optional and aggregate print. Once one argument needs lowering, every sibling uses the shared builder too. In `sieve`, only the integer-slice and fixed integer-array print calls introduce the default graph; its ordinary count/checksum prints stay raw. Five new helpers produce ten additional bodies. `tour` adds seventeen helpers/thirty-four bodies. The increases are code-heavy, not static labels: `tour` adds 64,892 code bytes but only 59 data bytes. DI's enum-label hoisting remains useful and should stay.

Existing independently collected parallel preparation medians: tour 49.384 -> 107.003 ms; sieve 17.038 -> 32.672 ms; functions 175.878 -> 202.103 ms. Engine: Wasmtime 50.0.1; CPU Ryzen 7 3800X, affinity [7], five samples. These observations align with larger modules but are not a paired causal measurement. Native/warm AOT numbers from these separate sessions do not establish a regression caused by this change.

## Why retain the semantic factory

`check_render_hook` selects non-generic two-argument format overloads from the nominal namespace and then global scope. `check_render_has_hook` traverses parts. `check_render_parameter` preserves the argument's actual storage/reference/read-only behavior. `render_function` checks the resolved hook before structural rendering and handles optional values, aggregate recursion, quoted bytes, and variant copying. Reimplementing these decisions in a backend fast path would create two semantic rules.

The same `format` hook provides print, str, and format spelling. A user overload named `str` is resolved through ordinary `check_call` before the builtin path; do not intercept names earlier. Directly loaded varint values may select the i64 hook while a varint field rendered as part of an aggregate remains varint. Encoded-reference storage identity matters too. Classification after eagerly erasing those distinctions would skip hooks or pass the wrong storage.

Argument order also blocks a superficial rewrite: primary §3.7 and `CheckPrintable` say evaluate and render each argument in order, with hooks in between, and print the completed line. The factory's sequential calls implement that. A hook may clear/rebind the shared builder or mutate a later argument. Do not print raw siblings directly to stdout, allocate one builder per argument, or hoist all argument evaluation before helper calls. The current raw builtin snapshots leaf values/bytes; that does not justify routing arbitrary reference-bearing aggregates through it.

For `str`, retain its natural fresh owning `u8[>..]` result. Receiving a slice is a view of the completed result, as the current synthetic-block conversion in `check_expect` specifies. The lazy-type patch changes neither AST replacement nor result/provenance. Do not restore the old function-value wrapper or clone already-checked arguments to optimize this path.

## Next measured hill: share raw byte append code in the Wasm backend

Best first larger target: `cg_format_bytes` (2279), called by every `cg_format_text`, numeric formatter, byte-sequence render, and generated punctuation append. Each call emits length overflow checks, reserve/capacity logic, pointer resolution, copy, region publication, and new length. The source emitters are shared; the generated Wasm instructions are duplicated. `render_function` also marks helpers recursive, preventing normal inlining; this already avoids one class of expansion and should not be removed globally.

A bounded experiment:

1. Keep semantic render helpers and their existing call/evaluation order unchanged. Demand-plan one private Wasm raw append helper for the common `u8[>..]` builder representation and the module's selected region/non-region ABI. Invoke it with the current output header, data pointer, and byte count. This is below hook resolution and receives already evaluated bytes.
2. Reuse the existing `cg_format_bytes` emission to define that helper once. Preserve pointer forwarding after reserve, overlap-safe `memory.copy`, overflow/region bounds, and output length/publication. Passing bytes by address must not change source lifetime across a possible growth operation.
3. Start only with canonical A_GROW output, the format-hook destination shape. Leave A_LIMITED and A_GROWSHRINK fallback emission unchanged. Limited formatting currently builds an argument separately before checked append; do not change its capacity/partial-write behavior. A later extension can share more shapes after explicit layout/effect gates.
4. Preserve diagnostic source information. Existing traps embed the call's source/token. Either pass diagnostic pointer/length or retain callsite failure branches; a common helper must not silently attribute all failures to its synthetic definition. Do not remove bounds checks to make the helper small.
5. Register the helper with the same deterministic function-index/signature discipline as the existing header/prefix runtime helpers. Avoid affecting native C output or the no-format module. Measure code bytes and actual cold preparation under matched conditions before accepting the extra call overhead.

Once append sharing is measured, consider common signed/unsigned integer-to-text helpers. `cg_integer_text` currently emits a decimal loop, sign handling, and a 32-byte local buffer at each use. Preserve signed-minimum magnitude handling, u64 maximum, zero, and width-correct loading; f32/f64 must retain their separate host formatting contracts. A shared helper should receive caller-owned scratch output or return an unambiguous slice with a valid lifetime. It should not share static mutable scratch across recursive calls/hooks. Do not combine this second experiment with the first when measuring attribution.

A smaller secondary factory optimization is normalizing `quoted` for proven hook-free non-byte scalar helpers (quoting affects bytes, not integers), but keep hookful storage/provenance keys unchanged. It will not explain or remove all observed growth. A broader backend demand scan restricted to reachable typed uses could eliminate other unused grow-type resolver leaks; that is a separate hill from moving the premature builder creation.

## Finish gates

For the lazy frontend patch:

- Self-bootstrap stage/source equality and the project's ordinary qualification checks.
- Compare unmodified 37 and patched 37 on the exact `squares` source. Record compiler hashes, module hashes, nodes/types/functions, Wasm sections/bodies. Expected direction: two accidental builder types and the extra resolver support disappear; output remains `sum=140` plus newline.
- Exact output for all ten current examples in both engines/backends; retain aggregate factory behavior and existing passing render corpus.
- Leaf controls: no arguments; signed/unsigned widths; i64 minimum/u64 maximum; bool; f32/f64 including -0.0/NaN/infinities; byte literals, fixed/variable/encoded/grow/slice byte storage; ordinary/narrowed references; unrelated format overload present; matching scalar/byte/reference hook present.
- Focused semantic corpus: `rendered_varint_storage`, `rendered_varint_results`, `rendered_reference_results`, `rendered_properties_by_ref`, `rendered_temporaries`, `render_self_relative_hooks`, `render_repointed_parts`, `render_fixed_payload_copies`, `format_hook_provenance`, `format_later_args`, and recursive format-part rejection cases. Preserve their existing statuses; do not count known failures as passes.
- For shared append additionally gate empty/self append and aliased builder views, exact limited-capacity boundaries/overflow, GrowShrink fallback, hooked builders that clear themselves, side effects/nonlocal exits in later arguments, optional/recursive aggregates, and integer boundaries. Compare exact stdout/error phases at O0/O2, Wasmtime/V8, and native controls.
- Only after bytes qualify, collect matched interleaved cold-prepare samples and warm runtime controls. Keep snapshot34 numbers labeled separately collected references.

## Reproduction identities

Reports: `build/completion-runs/goose-examples-37/report.json`, `build/completion-runs/goose-host-37/report.json`; reference reports `/dev/shm/goose-completion-work/goose-examples-34/report.json` and `.../goose-host-34/report.json`. Examples were compiled direct at O2 with cache disabled; each report records one unique module per example across five samples.

Installed compiler SHA-256: 34 `33eeddafe7523bfe2b4093debd84b34da3395a1efe83b25a94fbf490bb1c75f1`; 37 `a89f4c447a7eea5950f510301cac6be0b7c35d37690da9182952cac42d2b0391`.

Snapshot37 source SHA-256 (each matches bench-snapshot37): checker `2c01520fd0ea4cf3d07981648bda0a2e038f4a9e68b17aaab3d68e0df7855245`; checker_rendering `a389a9416ae458c44a275d47dcb4d8a5debdb493a68cdccb896e17e5ce321ac2`; codegen `e4b838b3eb7f30d2d924e2a646e06e1d3da9baa9a2ad1ba61ba859f984f6846e`.

Snapshot34 source SHA-256: checker `25615f790592752cba0c459b15ee3219221482b3dc3b1da98ecd060f1950f8df`; checker_rendering `eb34ce6c2a888635029fd78fc2e975d63187e688b61dfc6173b387d9c1c2a4d2`; codegen `1b7b467b4226e9aeafd4f14854d6184e96bfc09646481692029ba7916936547d`.

Example module hashes (34 -> 37): squares `6d7abf8390d59e60543f3af9cff3283c26b5ae31578f6c3a5910893db59a2ca3` -> `0e52326fee0b40ce8ddeb5af5876b7d363be90c4dd24c4cabc12b2af2062f922`; tour `4875cc6c4b1893a08b77bd34161ca4e41e4990d4b660faaf4e9f66ab829f8e96` -> `525f9e7508e425dcb7a24654d7febc3f37cf8970dc8a89b4b2ead12683192ce4`; sieve `54dbc1c390c59cf17ba29135525e78a5081eaa4f4f8e080df6e6c4632efa4a3b` -> `ab2ddd35aeeaa9c63adb26af92ad93177797c045b1fed74792b3046380094daa`. Full remaining source/module hashes are in the pinned reports and driver-stats files.
