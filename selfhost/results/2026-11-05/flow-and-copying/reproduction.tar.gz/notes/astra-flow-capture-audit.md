# Extra caller flow capture audit

Read-only audit of `build/completion-runs/loop-assignment-v2/source/selfhost/checker.goose`, 2026-11-05. Source SHA-256: `4e441381b1b0908f061741dd842e0ba2fba22a9a8af9cfd1fe75ac91f7a06327`. No compiler, oracle, suite, or benchmark was run; no compiler source was edited.

## Decision

Do not promote the proposed current-state predicate. Its premise is valid only after an initialized binding has reached a stable state; its snapshot membership is not stable. The current span consumers need a symbol present on both sides of a transition.

A minimal safe alternative needs no new field: omit only extra-frame immutable value symbols known to be initialized at their declaration, specifically ordinary `N_VARIABLE` declarations with `right >= 0`, or parameter symbols. Retain every delayed-initialization binding in every snapshot, including after it becomes assigned. Preserve complete lexical-frame snapshots as v2 does.

## Concrete counterexample to dynamic omission

The existing negative is already a discriminator:

```goose
fn each<F>(k: i64) { for i in k { F(i); } }
fn main() {
    let x: i64;
    each(2) { x = 5; };
}
```

Inside `each`, main is an extra suspended frame. The loop entry includes x because `assigned=false`. The F call assigns x through kind 6/4 effects. A snapshot filtered on current `assigned=true` now omits x. `check_loop_backedge` (4190) intersects entry and edge symbol IDs, so it never sees x's false-to-true transition and misses the repeated assignment.

The same mismatch affects ordinary branch joins (`check_flow_join`, 3576): only matching IDs are merged, so a then-branch that assigned x may contribute no state while the else branch still includes x. `check_function` (4910-4917) treats a missing exit-flow entry as not definitely assigned, so a one-shot HOF can also lose the definite-assignment guarantee needed by `block_once` in `let_assigned_once.goose`.

The checker legitimately changes an initialized-on-this-path x back to unassigned when `check_flow_restore` explores another branch or returns from checking a callee. Thus “no further legal source assignment” does not imply “the checker will never change these bits again.” Pending earlier snapshots matter.

## Smallest stable predicate

Apply only to cursors marked `active=true`; never suppress any ordinary lexical-frame entry.

Conceptually, omission requires all of:

- immutable symbol (`S_MUTABLE` clear);
- concrete non-reference/non-slice value type;
- a declaration class whose variable starts initialized and is never a delayed-assignment target: `S_PARAMETER` set, or `symbol.node >= 0 && nodes[symbol.node].kind == N_VARIABLE && nodes[symbol.node].right >= 0`;
- its normal invariant is `(assigned, maybeassigned, narrowed) == (true, true, -1)`.

For concrete type classification, an explicit allowed set is simplest: TY_BOOL, TY_INT, TY_FLOAT, TY_ARRAY, TY_STRUCT, TY_ENUM, TY_TUPLE. Keeping other kinds is conservative. In particular `type_id >= 0` alone does not exclude TY_UNKNOWN or TY_NAME. TY_GENERIC, TY_REF, and TY_SLICE stay tracked. A concrete aggregate containing references can still be omitted: these CheckFlow bits describe the outer binding, not its fields' provenance or contents.

The declaration-class requirement is the essential difference. Do not promote a delayed-init `let` into the omitted class after an assignment. Do not infer omission from only current `assigned`/`maybeassigned`, even if no direct mutation of those true bits is expected during execution.

For the initial patch, retain all N_BINDING nodes. That node kind includes multi-bindings and other contexts, and its own `right` is not a reliable initializer marker. Loop/match binders and initialized tuple-result binders could be classified later, but this conservative first predicate needs no parent search or new state. Checking the current true/true/-1 bits as a defensive guard is fine in addition to the stable declaration class; it must not replace that class.

## Why this class is stable in the actual checker

- `check_variable` (4650-4755) checks a local initializer before `check_declare`; immediately after declaration it sets both assignment bits from `init >= 0`. Local variables are not predeclared by `check_predeclare`. Thus no flow snapshot can observe a successfully initialized local symbol in a pre-initialized state. Global predeclarations are outside this optimization because globals are on the lexical chain, never an extra caller frame.
- `check_prepare_function` (2850-2867) declares each parameter and immediately sets both assignment bits true. Ordinary concrete value parameters never undergo optional narrowing.
- `check_assign_narrowing` (1804) can create narrowing only for a TY_REF optional. `check_narrow_condition` (1813-1833) also requires a TY_REF declared type. Both are excluded.
- `check_apply_call_effects` (3273-3306): kind 4 only sets both bits true; kind 5 only clears narrowing; kind 6 diagnoses a repeated immutable assignment and sets maybeassigned true. None changes this stable tuple for an initialized concrete value.
- `check_assignment_target` (4821-4837): a whole immutable rebinding diagnoses immediately using live `CheckVariable`; field/pointee writes leave the outer flow tuple unchanged. Effects/provenance are separate tables and are not removed by omitting a CheckFlow entry.
- Declaration/parameter/loop/match initialization writes belong to their own symbols. Cloning produces fresh declaration symbols; a fresh recursive activation does not reset an existing initialized caller symbol. Flow restores/joins can only restore prior true/true/-1 snapshots for this class.
- Function exit summarization skips entry symbols already assigned (4908-4909), so an omitted already-initialized value cannot lose a needed definite-assignment effect. This is precisely why retaining all delayed-init bindings matters.
- `check_bind_effect_context` keys nonlocal targets and does not change assignment/narrowing state. Literal-dependency and writable-use markers are CheckVariable fields not stored in CheckFlow; this optimization changes neither their tracking nor restore behavior.

I found no valid-state counterexample for this restricted declaration-initialized class in the audited implementation. This is a source audit, not a measured qualification result.

## Larger alternatives and tradeoffs

A stable per-symbol `assigned_at_declaration` bit, set only during declaration/parameter initialization, would let the same rule cover N_BINDING without AST-shape checks. It is more explicit but adds state and touches additional initialization sites. It is not required for the first experiment.

Freezing an omission set “at suspension” is harder than it sounds: nested suspensions can occur while older branch/loop snapshots still require a delayed-init symbol. Any such design must preserve membership across every outstanding snapshot that will be joined, not merely a single callee call. Avoid it for this patch.

A baseline-plus-delta flow representation can omit current true facts if every consumer reconstructs them against a stable baseline, but current restore, join, loop-backedge, and function-exit consumers do not have that representation. Retrofitting those consumers would be a larger performance hill.

## Qualification gates

Keep all three loop negatives rejecting, and all focused 310/84/515 controls at their existing statuses. In particular retain `let_assigned_once.goose` exact output, including block_once, nested_init, per_activation, and far_exit.

Add or retain HOF flow controls: delayed-init x assigned on one branch only (later read rejects); assigned on both exclusive branches (later read succeeds); assignment before continue (repeated let rejects); assignment only on a break/return branch (surviving backedge stays unassigned); one-shot F assignment gives definite assignment; conditional/reused F assignment still diagnoses a later write. Run variants with nested forwarding HOFs and a nonlocal return.

Keep initialized immutable scalar/struct/array parameters and locals as omission controls, with writable references passed to scalar storage/fields. Their values may change, but omitted flow bits must remain irrelevant. Optional/reference/slice and unresolved/generic symbols remain retained controls.

Compare private v2 and the stable-predicate v3 using identical pinned source/workload/compiler settings, stage equality, exact outputs/statuses, peak RSS, and multiple paired/interleaved user-time samples. The supplied one-pair v2 observations (+16% RSS, 41.79 -> 46.48 seconds user time) are preliminary, not a benchmark conclusion. Do not accept the dynamic predicate just because it lowers RSS: it can do so by dropping the required transition records.
