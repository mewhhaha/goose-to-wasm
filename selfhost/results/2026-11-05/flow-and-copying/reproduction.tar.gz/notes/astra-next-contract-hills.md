# Next contract hills — source audit, 2026-11-05

Baseline: frozen `snapshot-37`, published main `c067dcc9`; exact report `build/completion-runs/c-only-conformance-37/report.json`, compiler SHA-256 `a89f4c447a7eea5950f510301cac6be0b7c35d37690da9182952cac42d2b0391`. It records **4,717/5,028 passing rows, 311 failing rows = 187 distinct cases**. The failures contain **126 runtime-contract cases / 250 rows** and **61 error-contract cases / 61 rows**. Two runtime cases fail only at O2; all other runtime cases fail at both O0 and O2. Counts below are observed baseline failures, not promised recoveries or current integrated results.

This was a read-only source/report audit. No compiler, original C++ oracle, build, or test was run. The only written artifact is this ignored report. `S/` below means `build/completion-runs/snapshot-37/selfhost/`; `P/` means frozen primary source `build/source/src/`. Test names omit `upstream/`; sources are under the report's `shard-*/upstream/test/` trees. No memory facts were used.

## Ranked implementation queue

### 1. Let concrete nonfixed array parameters reach conversion checking — 3 cases / 6 rows

Exact cases: `codegen/call_array_adaptation`, `codegen/limited_array_adaptation`, `codegen/funval_array_adaptation`.

The first fails at `tv(sli())` (line 164), the second specifically at `take(g[..])` and `take(g[..2])` (line 30), and the third at `limarg(F())` / `varg(F())` (lines 86/101). `S/checker.goose:449` (`check_unify`) rejects formal ARRAY versus actual SLICE before `check_conversion` can approve construction. `check_choose_call:3060` invokes this unconditionally in both inference passes. `check_conversion:1624` already supports array construction from same-element slices.

**Bounded patch reviewed with root:** only when formal is ARRAY with non-FIXED kind and actual is SLICE, substitute existing bindings and permit the shape mismatch if the substituted formal has no generics. Keep conversion, readonly instantiation, phase-two checking and storage-copy validation. This covers concrete, explicit-T and already-anchored-T calls without inventing reverse generic inference. Root has started this experiment.

Do not generally teach structural unification ARRAY <- SLICE: `P/typecheck_calls.h:940` permits generic inference through ARRAY -> SLICE only; `BindTypes:1034` requires the same array kind. An unbound `f<T>(x: T[])` must not infer T solely from a slice. The bounded change intentionally leaves the pre-existing later-anchor/source-order issue untouched: the first pass can mark a candidate failed before a later argument binds T.

Do not bypass all concrete structural checks until fixing the latent fixed-destination hole: `S/checker.goose:1625` lets unknown-count slice -> fixed array pass because its count test only runs for `s.count >= 0`. `P/typecheck_exprs.h:1265-1278` rejects cross-type fixed-array construction after exact-type/literal cases.

Discriminators: concrete slice -> variable/grow/static-limited/runtime-limited value; explicit T and earlier typed anchor; literal/string/call result and readonly slice copied to fresh mutable array. Reject unbound reverse inference, dynamic slice -> `u8[3]`, `u16[:]` -> `u8[]`, and slice -> `u8[]&`. Retain limited-capacity overflow at runtime and mismatched known fixed lengths. The three original large cases may expose later backend failures; count only full original-row passes.

### 2. Preserve return-construction context through nested aggregate slots — 3 cases / 6 rows

Exact cases: `codegen/named_result_destinations`, `stdlib/stdlib_regex`, `stdlib/stdlib_exception`.

`S/checker.goose:1217-1232` (`check_slot_value`) rejects nonfixed named storage unconditionally in fields/elements. This blocks `return Result { out: out }`, `return Regex { fwd: dead, rev: dead, before: dead, ... }` (`stdlib/regex.goose:193`), and `[value] from handler` (`stdlib/exception.goose:25`). `P/typecheck_exprs.h:832-841` exempts `inreturn && v.lvalue && IsOwnLocal(n)`; `IsOwnLocal:878` uses the current specialization's ownership, not merely lexical containment in the nearest block. Root assigned this follow-up to the semantic agent.

Keep a scoped return-construction context while checking the expression, including fields and array elements; reset it when checking call arguments/callee bodies where their own construction context applies. Preserve nonlocal destination and lifetime validation. Test bare/aggregate/array/multiple returns, one local appearing twice, branch tails and early returns. Negative controls must retain copying requirements for another function's captured nonfixed storage and ordinary value argument/field construction outside return context. These are observed frontend blockers, not a guarantee that all three complete immediately.

### 3. Separate lookup roles for globally coexisting values, types and functions — 5 cases / 10 rows

Exact baseline cases: `syntax/global_function_names`, `codegen/local_name_suffixes`, `stdlib/parse_flt_reference`, `storage/serialize`, `stdlib/stdlib_dictionary_model`.

`S/checker.goose:282-299` (`check_declare`) permits only function/function duplicates. `check_lookup_scope:210` returns the newest symbol without a role filter; `check_lookup_name:254` propagates this through namespaces. `check_call:3437-3450` sets `first=-1` when lookup finds a global value, losing functions sharing that name instead of looking them up separately.

The first two cases collide global variables and functions (`print_count`, `count`, `last`, `value`). `parse_flt_reference` and `serialize` have global `rng: u64` beside imported `struct rng`. `stdlib_dictionary_model` has `struct last` beside imported `fn last`. This is three lookup domains, not just suppressing a duplicate diagnostic. `P/typecheck_calls.h:52-73` explicitly ignores a *global* variable when resolving functions, while retaining local-variable shadowing; `P/typecheck_exprs.h:27` independently resolves runtime variable identifiers; `P/ast.h:2788` owns function-set lookup.

Use context-specific filtered lookup and collision validation, preserving local shadowing and same-domain duplicate errors. Test each declaration order; imported/namespace-qualified/unqualified calls; overload sets with a global variable; type construction and a value of that name; local variable hides functions; duplicate variables/types still fail. The dictionary/serialization cases have additional diagnostics, so 10 is the exact affected baseline-row count, not a recovery forecast.

### 4. Lower compound aggregate arithmetic through the existing elementwise machinery — 3 cases / 6 rows

Exact cases: `codegen/elementwise_compound`, `codegen/elementwise_scalar`, `runtime/elementwise_scalar_overflow`.

`S/checker.goose:4760-4804` checks the RHS against the entire LHS type, then accepts only scalar numeric storage. Ordinary aggregate binary operations already use `check_aggregate_operation:4027` and `S/checker_operations.goose:170`. `S/codegen_c.goose:1473-1503` currently lowers compound updates as scalar `cc_binary_values`, so removing the frontend error alone is insufficient.

`P/typecheck_flow.h:2839-2884` gives the exact rule: same-type elementwise aggregates; scalar scaling only for *= and /=, with a compatible uniform scalar leaf type; no slice/array adaptation merely because ordinary assignment allows copying. Reuse checked elementwise computation while evaluating the destination once and snapshotting old LHS before RHS side effects. The original `elementwise_compound` already discriminates index evaluation once, RHS mutating/rebinding the destination, nested shapes, >4 KiB temporaries, and leaf-width behavior. Retain `errors_tc/elementwise_compound_shape` and width/overflow controls. Numeric-literal flexibility is owned elsewhere; this aggregate update support remains independently missing.

### 5. Propagate completion across tag dispatch — 1 case / 2 rows

Exact case: `typing/never_returns`. Its reported errors are only `dispatched(c)` at line 25, where both case functions call `stop()`; the checker incorrectly believes execution can reach the end of the i64 function.

`S/checker.goose:3312-3398` (`check_try_dispatch`) checks every case and applies effects, but never computes whether all cases fail to return normally and never marks the dispatch call divergent. Compare ordinary call completion handling in `check_call:3513-3516`; primary `P/typecheck_calls.h:516-529` ORs each case record's `mayreturn` and combines that with argument reachability. Aggregate case noncompletion conservatively, and retain normal continuation if any case can return. Existing test also covers mixed returning/diverging cases, callbacks, recursion, and nonlocal returns to the owner. A return *to* the owner resumes that owner's caller and must not be confused with a permanently unreachable outer continuation.

Do not roll the other completion-looking failures into this two-row estimate. `typing/never_returns_arguments` and `typing/unreachable_statements` both compile but trap with `nonlocal return target is not active` (4 distinct level rows); they require a runtime target/activation trace, not an error relaxation.

### 6. Track the value demand of control expressions — 1 case / 2 rows, plus related blockers

Exact narrow case: `codegen/discarded_resizable_results`. `S/checker_validation.goose:72-76` diagnoses nonfixed control-flow branch values even when the enclosing expression is a statement evaluated solely for effects. A statement-demand/void context should not demand a copy. Preserve effects and statement-region release; the original test's 4 MiB reservation and repeated large discarded results already discriminate leaked temporary storage. A stored nonfixed branch value must still require explicit copying unless it is a valid own-local return or reference/slice binding.

Related `typing/branch_reference_arguments` and `typing/branch_slice_joins` (4 baseline rows) should be split before assigning work: the former has both enum dispatch on a control expression (line 74; native/enum owner overlap) and own-local return branches (lines 35/40/49/54; rank 2). The latter includes a qualified const-slice call at line 104 and loss of slice join context on a break at line 141. `S/checker.goose:3605` joins types, `check_expect:1671` marks reference context, and `P/typecheck_exprs.h:859-875` defers branch-copy rejection until reference binding / slice join is settled. They are not both explained by rank 1.

## Larger reserve: lifetime precision, not diagnostic exemptions

Four exact cases / 8 rows fail with committed-root-depth errors: `lifetimes/class_read_views`, `growshrink_unrelated_refs`, `holder_contents_views`, `param_contents_views`. The relevant chain is `S/checker_lifetimes.goose:970` (`life_load`), `1044-1090` (`life_store`), `1297-1418` (frame/input reuse and discovery), and `1900-1925` (for binder initialization). Compare primary `P/typecheck_flow.h:423` (`SlotView`) and `2730-2803` (`CheckRefRebindRoot`). In particular, separate a holder/slot's storage root from the referents loaded through it, and distinguish an enlarged discovery summary from an actual source rebinding. This audit did not prove a single common defect for all four; do not change depth equality just to recover them.

Additional exact lifetime groups: stored-reference outlives errors in `lifetimes/read_back_typed`, `lifetimes/temporary_bindings`, `optimizer/viewed_copies` (6 rows); pending-expression shrink errors in `lifetimes/copied_temporaries`, `lifetimes/for_sequence_shrinks`, `codegen/shrink_frame_prefix`, `codegen/variable_prefix_frame_tail` (8 rows); live-holder shrink errors in `lifetimes/held_refs_tail_shrinks`, `lifetimes/shrink_before_exit`, `lifetimes/shrink_global_exact_stores`, `lifetimes/slice_ref_views` (8 rows). These larger groups need provenance-focused traces and their existing matching rejection controls before a patch plan can claim recoveries.

## Ownership and qualification boundaries

This queue excludes existing owners' flexible integer widths, parameter-default lexical context, nested reached validation, logical RHS kills, loop flow capture, central global flow visibility, lazy rendering output typing, and all physical variable-record/VAR-array/enum representation work. I6's four qualified rows and I7's pending work are not subtracted from the frozen report. Already-qualified wasm d52 is outside this baseline queue.

`c: expression lacks a checked type` is emitted at the containing function by `S/codegen_c.goose:270`; identical wording across tests is not evidence of one root cause. Several such cases include render hooks owned by root. Likewise two O2-only failures (`lifetimes/shrink_rules`, `stdlib/stdlib_dictionary`) report `c: block result has no value`; retain them as separate optimizer/codegen work, not extra rows credited to a frontend fix.

For every experiment: measure focused original rows at both listed levels, add discriminating positive/negative probes, and rerun the frozen unchanged full manifest before claiming a batch gain. Keep cases and optimization-level rows separate, and record any newly exposed blocker rather than counting frontend acceptance as delivery.
