from pathlib import Path
import collections, gzip, hashlib, io, json, shutil, tarfile

root = Path('/home/jacobt/src/goose-to-wasm')
work = Path('/dev/shm/goose-completion-work')
bench = root / 'bench/results/2026-11-05/fixed-relative-and-bindings'
checks = root / 'selfhost/results/2026-11-05/fixed-relative-and-contracts'

def read(path): return json.loads(path.read_text())
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path, value): path.write_text(json.dumps(value, indent=2) + '\n')
def gzcopy(source, target): target.write_bytes(gzip.compress(source.read_bytes(), mtime=0))

examples = read(work / 'goose-examples-34/report.json')
host = read(work / 'goose-host-34/report.json')
full = read(work / 'c-only-conformance-34/report.json')
v8 = read(work / 'c-only-v8-34/report.json')
proof = read(work / 'c-only-bootstrap-34/report.json')
comparison = read(work / 'comparison-34.json')
assert examples['status'] == host['status'] == v8['status'] == proof['status'] == 'passed'
assert full['summary'] == {'selected': 5021, 'passed': 4681, 'failed': 340}
assert not comparison['regressions'] and len(comparison['gains']) == 123
assert len(examples['observations']) == 410
assert len(host['observations']) == 360 and len(host['preparation']) == 150
assert proof['generated_c_sha256'] == proof['next_generation_c_sha256']
assert examples['environment']['compiler_sha256'] == proof['executable_sha256']
for report in (full, v8, proof): assert report['input_sha256'] == report['input_sha256_after']
for pins in (examples['environment']['input_sha256'], host['input_sha256']):
    for name, identity in pins.items(): assert sha(Path(name)) == identity, name
for row in host['preparation']: assert sha(Path(row['artifact'])) == row['sha256']

bench.mkdir(parents=True, exist_ok=True)
checks.mkdir(parents=True, exist_ok=True)
shutil.copyfile(work / 'goose-examples-34/report.json', bench / 'examples.json')
shutil.copyfile(work / 'goose-host-34/report.json', bench / 'host.json')
shutil.copyfile(work / 'benchmark-window-34.json', bench / 'window.json')
rows = []
for example in examples['examples']:
    name = example['name']
    rows.append({'name': name,
        'build_ms': {r['backend']: r['wall_seconds']['median'] * 1000
            for r in examples['compile_summary'] if r['name'] == name},
        'process_ms': {r['backend'] + '/' + r['mode']: r['wall_seconds']['median'] * 1000
            for r in host['runtime_summary'] if r['name'] == name}})
save(bench / 'summary.json', {'schema': 'goose-compiler-benchmarks-v1',
    'source_base_commit': 'a12a37d85b3c61c9258314250cea591a303eec7f',
    'compiler_snapshot': '34', 'source_sha256': proof['source_sha256'],
    'asset_sha256': proof['asset_sha256'], 'bootstrap_c_sha256': proof['executable_c_sha256'],
    'compiler_sha256': proof['executable_sha256'],
    'compiler_builds': 'The exact qualified executable was copied to the benchmark installation; both cohorts use this binary.',
    'examples_status': examples['status'], 'host_status': host['status'],
    'compile_samples': 5, 'runtime_samples': 5, 'preparation_samples': 5,
    'compiler_comparison': 'Both targets use the Goose-written compiler. Native uses its C backend at GCC O2. Snapshot32 and earlier C++ runs were collected separately.',
    'rows': rows})

for folder, name in [('c-only-bootstrap-34', 'bootstrap'), ('c-only-bootstrap-33', 'parent-bootstrap'),
                     ('c-only-conformance-34', 'conformance'), ('c-only-v8-34', 'v8')]:
    gzcopy(work / folder / 'report.json', checks / (name + '.json.gz'))
gzcopy(work / 'public-34/build/bootstrap/report.json', checks / 'public-bootstrap.json.gz')
shutil.copyfile(work / 'public-34/build/smoke/report.json', checks / 'public-smoke.json')
failures = [r for r in full['results'] if r['status'] != 'pass']
threads = [r for r in full['results'] if r['case'].startswith('upstream/threads/')]
assert len(threads) == 52 and all(r['status'] == 'pass' for r in threads)
save(checks / 'summary.json', {'schema': 'goose-compiler-qualification-v1',
    'snapshot': '34', 'complete': False, 'bootstrap_status': proof['status'],
    'bootstrap_c_sha256': proof['executable_c_sha256'], 'source_sha256': proof['source_sha256'],
    'asset_sha256': proof['asset_sha256'], 'compiler_sha256': proof['executable_sha256'],
    'fixed_point_scope': 'Two consecutive C outputs match. Parent snapshot33 separately passed three generations.',
    'contracts': full['summary'], 'curated_v8': v8['summary'], 'native_thread_checks': len(threads),
    'existing_contract_gains': 123, 'existing_contract_regressions': 0,
    'remaining_failure_phases': dict(collections.Counter(r['phase'] for r in failures)),
    'remaining_failure_groups': dict(collections.Counter('/'.join(r['case'].split('/')[:2]) for r in failures)),
    'known_gaps': ['80 invalid typing contracts still accepted', '260 runtime contracts still fail during compilation or execution',
        'Variable images, varint storage, result-channel adaptation and frontend lifetime/type gaps remain'],
    'gains': comparison['gains']})

def archive(path, files):
    with path.open('wb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', mtime=0) as zipped, tarfile.open(fileobj=zipped, mode='w|') as bundle:
        seen = {}
        for name, source in sorted(files.items()):
            data = source.read_bytes(); identity = hashlib.sha256(data).hexdigest()
            item = tarfile.TarInfo(name); item.mode = 0o644
            if identity in seen:
                item.type = tarfile.LNKTYPE; item.linkname = seen[identity]; bundle.addfile(item)
            else:
                item.size = len(data); bundle.addfile(item, io.BytesIO(data)); seen[identity] = name

files = {}
for folder, prefix in [('goose-examples-34', 'examples'), ('goose-host-34', 'host')]:
    for path in (work / folder).rglob('*'):
        if path.is_file(): files[prefix + '/' + path.relative_to(work / folder).as_posix()] = path
for pins in (examples['environment']['input_sha256'], host['input_sha256']):
    for name, identity in pins.items():
        path = Path(name)
        if path.suffix in ('.goose', '.py', '.mjs', '.json', '.c', '.h', '.gz', '.txt') and path.stat().st_size < 20000000:
            files['inputs/' + identity + '/' + path.name] = path
for name in ('LICENSE', 'NOTICE'): files['native/runtime/' + name] = work / 'snapshot-34/native/runtime' / name
archive(bench / 'measurements.tar.gz', files)

files = {}
for path in (work / 'verified-seed-33').iterdir(): files['parent-seed/' + path.name] = path
for top in ('selfhost', 'native'):
    for path in (work / 'snapshot-34' / top).rglob('*'):
        if path.is_file() and '__pycache__' not in path.parts:
            files['sources/' + path.relative_to(work / 'snapshot-34').as_posix()] = path
for name in ('conformance_shards.py', 'front_gate.py', 'freeze_seed.py', 'publish_34.py'):
    files['scripts/' + name] = work / name
for index in range(4):
    folder = work / 'c-only-conformance-34'
    path = folder / ('shard-' + str(index)) / 'report.json'
    gzcopy(path, checks / ('conformance-shard-' + str(index) + '.json.gz'))
    files['qualification/cases-' + str(index) + '.json'] = folder / ('cases-' + str(index) + '.json')
files['qualification/conformance_shards.py'] = work / 'conformance_shards.py'
files['notes/native-variable-review.md'] = work / 'native-variable-review.md'
files['qualification/H8.json'] = work / 'native-lowering-H8/qualification.json'
archive(checks / 'reproduction.tar.gz', files)
print(bench, sha(bench / 'measurements.tar.gz'))
print(checks, sha(checks / 'reproduction.tar.gz'))
