from pathlib import Path
import subprocess,os,threading,hashlib,json,time,sys
root=Path('/home/jacobt/src/goose-to-wasm');out=root/'build/completion-runs/member-calls-v1';label=sys.argv[1];compiler=Path(sys.argv[2]).resolve();work=Path(sys.argv[3]).resolve();name=sys.argv[4]
paths=[compiler,*work.parent.glob('*.goose'),*(root/'stdlib').glob('*.goose'),Path(__file__)];sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();before={str(f):sha(f) for f in paths};cmd=[str(compiler),str(work),'--target','native','--stdlib',str(root/'stdlib'),'--check'];started=time.monotonic()
with (out/(name+'.stdout')).open('w') as so,(out/(name+'.stderr')).open('w') as se:
 child=subprocess.Popen(cmd,cwd=root,stdout=so,stderr=se);timer=threading.Timer(180,child.kill);timer.start();_,status,usage=os.wait4(child.pid,0);timer.cancel();child.returncode=os.waitstatus_to_exitcode(status)
report=dict(label=label,command=cmd,exit_code=child.returncode,user_seconds=usage.ru_utime,system_seconds=usage.ru_stime,maxrss_kib=usage.ru_maxrss,wall_seconds=time.monotonic()-started,stdout=(out/(name+'.stdout')).read_text(),stderr=(out/(name+'.stderr')).read_text(),before=before,after={str(f):sha(f) for f in paths},concurrent_load='Root42 canonical builds and related qualification active; CPU/RSS observations only; no runtime-performance win claim')
report['pins_unchanged']=report['before']==report['after'];(out/(name+'.json')).write_text(json.dumps(report,indent=2)+'\n');print({k:v for k,v in report.items() if k not in ('before','after')},flush=True)
