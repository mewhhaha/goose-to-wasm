from pathlib import Path
import subprocess,hashlib,json,sys,time,os,threading
root=Path('/home/jacobt/src/goose-to-wasm');out=root/'build/completion-runs/lifetime-views-v1/cost8';out.mkdir(exist_ok=True)
base=root/'build/completion-runs/c-only-bootstrap-40/goose';candidate=root/'build/completion-runs/lifetime-views-v1/build8/goose';work=root/'build/completion-runs/snapshot-40/selfhost/main.goose'
paths=[base,candidate,*work.parent.glob('*.goose'),* (root/'stdlib').glob('*.goose')]
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
report={'before':{str(f):sha(f) for f in paths},'runs':[]}
for i,(label,compiler) in enumerate([('baseline',base),('candidate',candidate),('candidate',candidate),('baseline',base)]):
 command=[str(compiler),str(work),'--target','native','--stdlib',str(root/'stdlib'),'--check'];started=time.monotonic()
 with (out/f'{i}-{label}.stdout').open('w') as so,(out/f'{i}-{label}.stderr').open('w') as se:
  child=subprocess.Popen(command,cwd=root,stdout=so,stderr=se);timer=threading.Timer(180,child.kill);timer.start()
  _,status,usage=os.wait4(child.pid,0);timer.cancel();child.returncode=os.waitstatus_to_exitcode(status)
 entry={'label':label,'command':command,'exit_code':child.returncode,'stderr':(out/f'{i}-{label}.stderr').read_text(),'stdout':(out/f'{i}-{label}.stdout').read_text(),'user_seconds':usage.ru_utime,'system_seconds':usage.ru_stime,'maxrss_kib':usage.ru_maxrss,'wall_seconds':time.monotonic()-started};report['runs'].append(entry);print(entry,flush=True)
 (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
 if child.returncode:break
report['after']={str(f):sha(f) for f in paths};report['pins_unchanged']=report['before']==report['after'];(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
