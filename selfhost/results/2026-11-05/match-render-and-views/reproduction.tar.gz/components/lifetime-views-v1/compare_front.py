import json,sys
from pathlib import Path
base=Path(sys.argv[1]); current=Path(sys.argv[2]); summary={}
for name in ('semantic-all-valid','typing','negative-type','upstream-positive'):
 b=json.loads((base/f'{name}.json').read_text()); a=json.loads((current/f'{name}.json').read_text()); gained=[]; lost=[]
 for x,y in zip(b,a):
  xp=x['exit_code']==0; yp=y['exit_code']==0
  if name=='negative-type': xp=x['exit_code']==1 and ': error:' in x['stderr']; yp=y['exit_code']==1 and ': error:' in y['stderr']
  if xp and not yp:lost.append(dict(source=y['source'],stderr=y['stderr']))
  if yp and not xp:gained.append(y['source'])
 summary[name]=dict(total=len(a),gains=gained,regressions=lost,crashes=[r['source'] for r in a if r['exit_code'] not in (0,1)])
 print(name,'gains',len(gained),'losses',len(lost),flush=True)
 for r in lost:print(r)
(current/'matched-comparison.json').write_text(json.dumps(summary,indent=2)+'\n')
