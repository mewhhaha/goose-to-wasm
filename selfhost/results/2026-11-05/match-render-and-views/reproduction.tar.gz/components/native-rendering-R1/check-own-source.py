from pathlib import Path
import hashlib,json,subprocess,time,os
base=Path(__file__).resolve().parent;root=Path('/home/jacobt/src/goose-to-wasm');out=base/'own-source-run';out.mkdir(exist_ok=False)
def sha(path):
 with Path(path).open('rb') as source:return hashlib.file_digest(source,'sha256').hexdigest()
paths=[base/'build/goose',Path(__file__).resolve(),*base.joinpath('source/selfhost').glob('*.goose'),*root.joinpath('stdlib').rglob('*.goose')]
pins={str(path):sha(path) for path in paths};command=list(map(str,[base/'build/goose',base/'source/selfhost/main.goose','--stdlib',root/'stdlib','--check','--library']));started=time.monotonic()
with (out/'stdout').open('w') as stdout,(out/'stderr').open('w') as stderr:
 child=subprocess.Popen(command,cwd=root,stdout=stdout,stderr=stderr);_,status,usage=os.wait4(child.pid,0);child.returncode=os.waitstatus_to_exitcode(status)
after={path:sha(path) for path in pins}
r=dict(status='failed',command=command,exit_code=child.returncode,seconds=time.monotonic()-started,max_rss_kib=usage.ru_maxrss,input_sha256=pins,input_sha256_after=after)
if child.returncode==0 and pins==after:r['status']='passed'
(out/'report.json').write_text(json.dumps(r,indent=2)+'\n');assert r['status']=='passed',(out/'stderr').read_text()[-4000:]
