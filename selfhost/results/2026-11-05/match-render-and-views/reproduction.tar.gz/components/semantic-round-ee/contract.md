Normal and nonlocal assignment exits

A function's ordinary continuation exports definite assignment where all of its normal exits assign the binding, and possible assignment where any do. A write followed only by a nonlocal return contributes to the target function's exits, not to the callee's ordinary continuation. Existing raw may-write effects are removed only when the joined normal exits rule them out; joined possible assignments are exported even when they arrived through a nested nonlocal exit.

Each private function scope can retain a linked list of nonlocal target summaries. A summary intersects definite assignments and unions new possible assignments across exits to that exact active target. It records changes relative to callee entry. Reusing a checked callee creates a fresh target exit from the current caller flow, then adds the callee's recorded assignment changes. Unrelated caller assignments made since the original check are preserved. These summaries use stable IDs in the existing flow arena; no checked Program/model metadata or backend ABI changes are required.

The new scope field defaults to no summaries. Most functions have no nonlocal exits and use the empty fast path. Function signature specialization and captured input-flow checks are unchanged. Root and lifetime validation are unchanged.

Rejected ED v1 filtered raw effects without exporting the target's joined possible assignment and lost errors_tc/let_assign_nested_fn_return_from. ED v2 reinserted effects in the wrong order and falsely refused the first valid initializer call; a third cached nonlocal call also demonstrated why current caller flow must be replayed. Both rejected patches, their sources and reports remain in semantic-round-ed.
