from pathlib import Path
import json,subprocess
r=Path(__file__).parent.resolve();d=r/'focus';d.mkdir(exist_ok=True)
cases={
'normal_nonlocal_join':(True,'fn run(c:bool)->i64{let x:i64;fn setx(d:bool){fn bail(e:bool){if e{x=1;return from setx;}}bail(d);x=2;}setx(c);return x;}fn main(){print(run(true)," ",run(false));}'),
'normal_assign_then_second_write':(False,'fn main(){let x:i64;fn init(){x=1;}init();x=2;print(x);}'),
'normal_assign_cached_second_call':(False,'fn main(){let x:i64;fn init(){x=1;}init();init();print(x);}'),
'normal_maybe_assign_then_write':(False,'fn run(c:bool){let x:i64;fn maybe(d:bool){if d{x=1;}}maybe(c);x=2;print(x);}fn main(){run(false);}'),
'normal_read_not_assigned':(False,'fn run(c:bool){let x:i64;fn target(d:bool){fn bail(e:bool){if e{x=1;return from target;}}bail(d);print(x);}target(c);}fn main(){run(false);}'),
'nonlocal_returned_initialization':(True,'fn run(c:bool)->i64{let x:i64;fn target(d:bool){fn step(e:bool){if e{x=1;return from target;}x=2;}step(d);}target(c);return x;}fn main(){print(run(true)," ",run(false));}'),
'normal_assign_while_nonlocal_elsewhere':(False,'fn run(c:bool){let x:i64;fn target(d:bool){fn step(e:bool){if e{return from target;}x=1;}step(d);x=2;}target(c);}fn main(){run(false);}'),
}
rows=[]
for name,(accept,text) in cases.items():
 p=d/(name+'.goose');p.write_text(text+'\n');x=subprocess.run([str(r/'probe'),str(p),str(Path('stdlib').resolve())],capture_output=True,text=True,timeout=6);rows.append(dict(id=name,expected_accept=accept,exit_code=x.returncode,stdout=x.stdout,stderr=x.stderr,match=(accept and x.returncode==0)or(not accept and x.returncode!=0 and ': error:' in x.stdout+x.stderr)))
(r/'focus.json').write_text(json.dumps(rows,indent=2)+'\n');print('focus',sum(x['match'] for x in rows),'/',len(rows))
for x in rows:
 if not x['match']:print(json.dumps(x,indent=2))
