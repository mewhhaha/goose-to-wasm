from pathlib import Path
import concurrent.futures,hashlib,json,subprocess,sys,time
w=Path(__file__).parent.resolve();root=w.parents[2];library=root/'stdlib'
compiler=Path(sys.argv[1]).resolve();label=sys.argv[2];probe='--probe' in sys.argv

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(name,value):(w/name).write_text(json.dumps(value,indent=2)+'\n')
def command(source,layout='wasm'):
 if probe:
  out=[str(compiler),str(source),str(library)]
  if layout=='native':out.append('native')
  return out
 target=layout
 if layout=='wasm':target='wasm-direct'
 return [str(compiler),str(source),'--stdlib',str(library),'--target',target,'--check']
def run(source,layout='wasm'):
 cmd=command(source,layout);start=time.monotonic()
 try:
  p=subprocess.run(cmd,capture_output=True,text=True,timeout=25)
  return dict(command=cmd,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr,seconds=time.monotonic()-start)
 except subprocess.TimeoutExpired:return dict(command=cmd,exit_code=124,stdout='',stderr='TIMEOUT',seconds=time.monotonic()-start)
paths=[Path(__file__),compiler,w/'contracts.json',*library.rglob('*.goose'),*(w/'source/selfhost').glob('*.goose'),*(w/'focus').glob('*.goose')]
for name in ['readonly-wrapper-closure-cases.json','reference-wrapper-closure-cases-v2.json','conversion-cases.json']:paths.append(w/name)
suites={}
if '--front' in sys.argv:
 for name in ['semantic-all-valid','typing','negative-type','upstream-positive']:
  rows=json.loads((w.parent/'semantic-round-em'/('front43-before-'+name+'.json')).read_text());suites[name]=rows;paths.extend(Path(x['source']) for x in rows)
pins={str(p):sha(p) for p in paths};save(label+'-pins-start.json',pins)
focus=[]
for case in json.loads((w/'contracts.json').read_text()):
 for layout in ['native','wasm']:
  result=run(case['source'],layout);focus.append(dict(case,layout=layout,**result,match=(result['exit_code']==0)==case['expected_accept']))
save(label+'-focus.json',focus);print('focus',sum(x['match'] for x in focus),'/',len(focus),flush=True)
for x in focus:
 if not x['match']:print('focus disagreement',x['case'],x['layout'],x['stdout'][:300],x['stderr'][:300],flush=True)
if '--groups' in sys.argv:
 scratch=w/('closure-scratch-'+label+'.goose')
 for name in ['readonly-wrapper-closure-cases','reference-wrapper-closure-cases-v2','conversion-cases']:
  data=json.loads((w/(name+'.json')).read_text());out=[]
  for case in data['cases']:
   assert hashlib.sha256(case['source'].encode()).hexdigest()==case.get('source_sha256',case.get('sha256'))
   scratch.write_text(case['source'])
   for layout in ['native','wasm']:
    result=run(scratch,layout);out.append(dict(case=case['case'],layout=layout,source_sha256=case.get('source_sha256',case.get('sha256')),expected_accept=case['expected_accept'],**result,match=(result['exit_code']==0)==case['expected_accept']))
  save(label+'-'+name+'.json',out);print(name,sum(x['match'] for x in out),'/',len(out),flush=True)
  for x in out:
   if not x['match']:print('group disagreement',name,x['case'],x['layout'],x['stdout'][:200],x['stderr'][:200],flush=True)
if '--front' in sys.argv:
 results={}
 for name,rows in suites.items():
  def one(row):return dict(source=row['source'],**run(row['source']))
  with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:out=list(pool.map(one,rows))
  results[name]=out;print('front',name,sum(x['exit_code']==0 for x in out),'/',len(out),flush=True)
 save(label+'-front.json',results)
assert pins=={name:sha(name) for name in pins};save(label+'-pins-final.json',pins)
