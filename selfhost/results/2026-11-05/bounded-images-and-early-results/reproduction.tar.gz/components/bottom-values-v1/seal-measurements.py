from pathlib import Path
import hashlib,json
w=Path(__file__).parent.resolve();root=w.parents[2]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(name):return json.loads((w/name).read_text())
def save(name,value):(w/name).write_text(json.dumps(value,indent=2)+'\n')
proof=json.loads((w.parent/'c-only-bootstrap-45/report.json').read_text());assert proof['status']=='passed';assert sha(w.parent/'c-only-bootstrap-45/goose')==proof['executable_sha256']
base={};candidate={}
for name,h in proof['source_sha256'].items():
 assert sha(w.parent/'snapshot-45/selfhost'/name)==h;base[name]=h;candidate[name]=sha(w/'source/selfhost'/name)
assert [name for name in base if base[name]!=candidate[name]]==['checker.goose']
for name,h in proof['asset_sha256'].items():assert sha(w.parent/'snapshot-45'/name)==h and sha(w/'source'/name)==h
build=read('compiler/report.json');assert build['status']=='passed';assert build['input_sha256'][str(w/'source/selfhost/checker.goose')]==candidate['checker.goose'];assert build['input_sha256']==build['input_sha256_after'];assert sha(w/'compiler/goose')==build['executable_sha256']
front_base=read('baseline45-front.json');front=read('full-front.json');changes=[];losses=[];compiler_failures=[];sources={}
for name,rows in front.items():
 for b,a in zip(front_base[name],rows):
  assert b['source']==a['source'];sources[a['source']]=sha(a['source'])
  if b['exit_code']!=a['exit_code']:
   item=dict(suite=name,source=a['source'],before=b['exit_code'],after=a['exit_code']);changes.append(item)
   if name=='negative-type' and a['exit_code']==0 or name!='negative-type' and b['exit_code']==0:losses.append(item)
  if a['exit_code'] not in (0,1):compiler_failures.append(a)
assert not losses and not compiler_failures
prior=json.loads((w.parent/'semantic-round-em/qualification-input-pins43-final.json').read_text());assert all(prior.get(name)==h for name,h in sources.items())
save('frontend-source-pins.json',dict(source_sha256=sources,prior_authority='semantic-round-em/qualification-input-pins43-final.json',all_match_prior_qualified_fixtures=True))
save('front-comparison.json',dict(rows=sum(map(len,front.values())),unique_sources=len(sources),changes=changes,losses=losses,compiler_failures=compiler_failures))
focus=read('full-focus.json');assert len(focus)==40 and all(x['match'] for x in focus)
closures={}
for group in ['readonly-wrapper-closure-cases','reference-wrapper-closure-cases-v2','conversion-cases']:
 before=read('baseline45-corrected-'+group+'.json');after=read('full-'+group+'.json');assert len(before)==len(after) and all(x['match'] for x in after)
 changed=[];bad=[]
 for b,a in zip(before,after):
  assert b['case']==a['case'] and b['layout']==a['layout']
  if b['match']!=a['match']:
   changed.append(dict(case=a['case'],layout=a['layout'],before=b['exit_code'],after=a['exit_code'],expected_accept=a['expected_accept']))
   if b['match']:bad.append(changed[-1])
 assert not bad;closures[group]=dict(total=len(after),before_matched=sum(x['match'] for x in before),after_matched=sum(x['match'] for x in after),changes=changed,losses=bad)
save('closure-comparison.json',closures)
runtime=read('runtime/report.json');baseline=read('runtime-baseline45/report.json');v8=read('runtime-v8/report.json');assert runtime['summary']==dict(selected=36,passed=36,failed=0);assert v8['summary']==dict(selected=18,passed=18,failed=0)
index={(x['case'],x['level']):x for x in baseline['results']};gains=[];runtime_losses=[]
for a in runtime['results']:
 b=index[(a['case'],a['level'])]
 if a['status']!=b['status']:
  item=dict(case=a['case'],level=a['level'],before=b['status'],after=a['status'],baseline_failure_phase='compiler refusal')
  if 'run_command' in b:item['baseline_failure_phase']='execution output';item['baseline_stdout']=baseline['commands'][b['run_command']]['stdout']
  gains.append(item)
  if b['status']=='pass':runtime_losses.append(item)
assert not runtime_losses;save('runtime-comparison.json',dict(baseline45=baseline['summary'],native_wasmtime=runtime['summary'],v8_engine=v8['summary'],gains=gains,compiler_refusal_fixes=sum(x['baseline_failure_phase']=='compiler refusal' for x in gains),execution_output_fixes=sum(x['baseline_failure_phase']=='execution output' for x in gains),losses=runtime_losses))
frozen=read('frozen-failures45/report.json');old=read('frozen-failures45-baseline.json');old_index={(x['case'],x['level']):x for x in old['results']};frozen_changes=[]
for a in frozen['results']:
 b=old_index[(a['case'],a['level'])];assert 'run_command' not in a
 if a['status']!=b['status']:frozen_changes.append(dict(case=a['case'],level=a['level'],before=b['status'],after=a['status']))
assert len(frozen['results'])==138 and not frozen_changes
save('frozen-comparison.json',dict(rows=138,before_failed=138,after_failed=138,changes=frozen_changes,existing_frozen_contract_gains=0,execution_mismatches=0,baseline_report_sha256=old['report_sha256'],expectations='unchanged frozen45 contracts; all prior failures were probed, not only selected likely wins'))
own=read('own-source.json');assert own['exit_code']==0
for name,h in own['source_sha256'].items():assert sha(name)==h
pins=dict(base='snapshot-45',authority='c-only-bootstrap-45/report.json',producer_sha256=proof['executable_sha256'],base_source_sha256=base,candidate_source_sha256=candidate,candidate_executable_sha256=build['executable_sha256'],asset_sha256=proof['asset_sha256'],focus_sha256={p.name:sha(p) for p in sorted((w/'focus').glob('*.goose'))},group_sha256={name:sha(w/name) for name in ['readonly-wrapper-closure-cases.json','reference-wrapper-closure-cases-v2.json','conversion-cases.json']},patch_sha256=sha(w/'bottom-conversion-snapshot45.patch'),primary_sha256={str(p):sha(p) for p in [root/'build/source/src/typecheck_flow.h',root/'build/source/src/typecheck_exprs.h',root/'build/source/test/typing/named_constant_literals.goose',root/'build/source/test/typing/branch_reference_parameters.goose',root/'build/source/test/errors_tc/varint_field_ref_identity.goose']})
save('source-pins.json',pins);save('source-pins-final.json',pins)
print('checker',candidate['checker.goose'],'compiler',build['executable_sha256']);print({name:(x['before_matched'],x['after_matched'],x['total']) for name,x in closures.items()});print('runtime gains',len(gains))
