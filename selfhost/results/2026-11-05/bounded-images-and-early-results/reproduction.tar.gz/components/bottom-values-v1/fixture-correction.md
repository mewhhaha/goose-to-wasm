Two private audit inputs were corrected from independent frozen contracts. No committed expectation changed.

The audit's local `let n=1` is an I64 value, not an adaptable named constant. Frozen `typing/named_constant_literals.goose:3–10` states that only untyped integer globals adapt this way. The local-let case remains a narrowing rejection; a new global `let K=1` supplies the valid positive.

Reference identity uses `.==`. The old `.=` copied input was a parser rejection and is retained in `rejected-identity-assignment-input.goose`. The corrected `.==` case and the grouped explicit-reference-copy case now exercise semantic identity rejection. Exact identities and authorities are in `fixture-correction.json`; old raw results remain retained.
