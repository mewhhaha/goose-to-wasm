from pathlib import Path
base=Path(__file__).resolve().parent
p=base/'source/selfhost/codegen_c_storage.goose';s=p.read_text();anchor='fn cc_physical_cell_width(p: Program&, id: i64) -> i64 {\n';new='''fn cc_flat_image_reference(p: Program&, id: i64) -> bool {
    return id >= 0 && p.types[id].kind == TY_REF && (p.types[id].flags & TF_OPTIONAL) == 0 && cc_flat_relative_image(p, p.types[id].element);
}
'''+anchor;assert anchor in s;s=s.replace(anchor,new,1);p.write_text(s)
p=base/'source/selfhost/codegen_c.goose';s=p.read_text()
# Bounded canonical equality skips padding instead of relying on its zero fill.
needle='    if cc_flat_relative_image(p, type_id) { out.append("int64_t n=g_image_span(a);if(n!=g_image_span(b) || (n && memcmp(a.base,b.base,(size_t)n)))return 0;\\n"); return; }'
repl='''    if cc_flat_relative_image(p, type_id) {
        out.append("const uint8_t *ac=a.base,*bc=b.base;\\n"); var field = first;
        while field >= 0 {
            let n = p.nodes[field]; var width = n.aux;
            if (n.flags & F_PAD) == 0 {
                out.format("if(!g_equal_", n.type_id, "(g_physical_load_", n.type_id, "(ac,a.end),g_physical_load_", n.type_id, "(bc,b.end)))return 0;\\n");
                width = cc_physical_cell_width(p, n.type_id);
            }
            out.format("ac=g_relative_cell_skip(ac,a.end,", width, ");bc=g_relative_cell_skip(bc,b.end,", width, ");\\n"); field = n.next;
        }
        return;
    }''';assert needle in s;s=s.replace(needle,repl,1)
# A borrow's separate authority can come only from a stable owned header or an
# immutable internal parameter/alias. It never changes the natural Ref value.
anchor='recursive fn cc_base_place(p: Program&, f: CcBody&, node: i64) -> CcPlace {\n'
helper='''recursive fn cc_image_reference_owner(p: Program&, f: CcBody&, node: i64, depth: i64 = 0) -> i64 {
    if node < 0 || depth > 32 { return -1; }
    let n = p.nodes[node];
    if cc_flat_relative_image(p, n.type_id) && n.kind == N_NAME { return cc_symbol_ref(p, f, n.symbol, node); }
    if n.kind == N_UNARY && n.integer == T_BITAND { return cc_image_reference_owner(p, f, n.left, depth + 1); }
    if n.kind == N_CAST && (n.flags & F_SYNTHETIC) != 0 { return cc_image_reference_owner(p, f, n.left, depth + 1); }
    if n.kind != N_NAME || n.symbol < 0 { return -1; }
    let symbol = p.symbols[n.symbol]; if !cc_flat_image_reference(p, symbol.type_id) || symbol.node < 0 { return -1; }
    let declaration = p.nodes[symbol.node];
    if (declaration.flags & F_VAR) != 0 { return -1; }
    if declaration.kind == N_PARAM && symbol.owner == f.function {
        let owner = cc_ref_temp(f); cc_set(f, owner); cc_id(f.out, "g_image_owner_", n.symbol); cc_text(f.out, ";\\n"); return owner;
    }
    if declaration.kind == N_VARIABLE && declaration.right >= 0 { return cc_image_reference_owner(p, f, declaration.right, depth + 1); }
    return -1;
}
'''+anchor
assert anchor in s;s=s.replace(anchor,helper,1)
needle='''        if cc_image_type(p, type_id) { return CcPlace { type_id: type_id, address: address, form: CC_IMAGE, image_base: address }; }'''
repl='''        if cc_flat_relative_image(p, type_id) {
            let owner = cc_image_reference_owner(p, f, node);
            if owner < 0 { cc_fail(p, node, "c: relative image reference has no proved owner authority"); return CcPlace { type_id: -1, address: -1 }; }
            let end = cc_ref_temp(f); cc_set(f, end); cc_text(f.out, "g_ref(((GImage*)g_address("); cc_id(f.out, "g_v", owner); cc_text(f.out, "))->end);\\n");
            return CcPlace { type_id: type_id, address: address, form: CC_IMAGE, image_base: address, owner_header: owner, image_end: end };
        }
'''+needle
assert needle in s;s=s.replace(needle,repl,1)
# Extend only the affected internal C signatures; GRef remains eight bytes.
needle='''    while param >= 0 { cc_text(out, ","); cc_type(out, p.nodes[param].type_id); if cc_indirect(p, p.nodes[param].type_id) { cc_text(out, "*"); } param = p.nodes[param].next; }'''
repl='''    while param >= 0 {
        cc_text(out, ","); cc_type(out, p.nodes[param].type_id); if cc_indirect(p, p.nodes[param].type_id) { cc_text(out, "*"); }
        if cc_flat_image_reference(p, p.nodes[param].type_id) { cc_text(out, ",GRef"); }
        param = p.nodes[param].next;
    }'''
assert needle in s;s=s.replace(needle,repl,1)
needle='''        else { cc_text(out, " "); cc_id(out, "g_s", p.nodes[param].symbol); } param = p.nodes[param].next;'''
repl='''        else { cc_text(out, " "); cc_id(out, "g_s", p.nodes[param].symbol); }
        if cc_flat_image_reference(p, p.nodes[param].type_id) { cc_text(out, ",GRef "); cc_id(out, "g_image_owner_", p.nodes[param].symbol); }
        param = p.nodes[param].next;''';assert needle in s;s=s.replace(needle,repl,1)
needle='''        if cc_indirect(p, n.type_id) {
            if end { cc_undef(out, "g_s", n.symbol); }'''
repl='''        if cc_flat_image_reference(p, n.type_id) && !end {
            cc_text(out, "if(((GImage*)g_address("); cc_id(out, "g_image_owner_", n.symbol); cc_text(out, "))->base!=g_address("); cc_id(out, "g_s", n.symbol); cc_text(out, "))g_panic(\\\"image reference owner mismatch\\\");\\n");
            cc_text(out, "(void)g_image_span(*(GImage*)g_address("); cc_id(out, "g_image_owner_", n.symbol); cc_text(out, "));\\n");
        }
        if cc_indirect(p, n.type_id) {
            if end { cc_undef(out, "g_s", n.symbol); }''';assert needle in s;s=s.replace(needle,repl,1)
# Reserve owner slots before evaluating any argument, just like value slots.
needle='''    while arg >= 0 { f.work.push(-1); args_count++; arg = p.nodes[arg].next; }
    arg = n.first; var ordinal = 0;
    while param >= 0 && arg >= 0 {'''
repl='''    while arg >= 0 { f.work.push(-1); args_count++; arg = p.nodes[arg].next; }
    var authority = false; var scan = param;
    while scan >= 0 { if cc_flat_image_reference(p, p.nodes[scan].type_id) { authority = true; } scan = p.nodes[scan].next; }
    if authority { for i in args_count { f.work.push(-1); } }
    arg = n.first; var ordinal = 0;
    while param >= 0 && arg >= 0 {''';assert needle in s;s=s.replace(needle,repl,1)
needle='''        f.work[args_start + ordinal] = value;
        ordinal++; param = p.nodes[param].next; arg = p.nodes[arg].next;'''
repl='''        f.work[args_start + ordinal] = value;
        if cc_flat_image_reference(p, p.nodes[param].type_id) {
            let owner = cc_image_reference_owner(p, f, arg);
            if owner < 0 { cc_fail(p, arg, "c: relative image argument has no proved owner authority"); return -1; }
            f.work[args_start + args_count + ordinal] = owner;
        }
        ordinal++; param = p.nodes[param].next; arg = p.nodes[arg].next;''';assert needle in s;s=s.replace(needle,repl,1)
needle='''    for i in 0..args_count { cc_text(f.out, ","); if cc_indirect(p, p.nodes[param].type_id) { cc_text(f.out, "&"); } cc_id(f.out, "g_v", f.work[args_start + i]); param = p.nodes[param].next; } cc_text(f.out, ");\\n");'''
repl='''    for i in 0..args_count {
        cc_text(f.out, ","); if cc_indirect(p, p.nodes[param].type_id) { cc_text(f.out, "&"); } cc_id(f.out, "g_v", f.work[args_start + i]);
        if cc_flat_image_reference(p, p.nodes[param].type_id) { cc_text(f.out, ","); cc_id(f.out, "g_v", f.work[args_start + args_count + i]); }
        param = p.nodes[param].next;
    } cc_text(f.out, ");\\n");''';assert needle in s;s=s.replace(needle,repl,1)
# Unsupported ABI paths remain explicit admissions, not malformed C calls.
needle='''    let signature = p.symbols[n.symbol].type_id;
    let args_start = f.work.len;'''
repl='''    let signature = p.symbols[n.symbol].type_id;
    var checked = p.types[signature].first;
    while checked >= 0 {
        if cc_flat_image_reference(p, p.nodes[checked].type_id) { cc_fail(p, node, "c: image-reference dispatch needs owner authority forwarding"); return -1; }
        checked = p.nodes[checked].next;
    }
    let args_start = f.work.len;''';assert needle in s;s=s.replace(needle,repl,1)
needle='''    let n = p.nodes[function]; cc_emit_signature(p, out, function); cc_text(out, " {\\n"); cc_parameter_aliases(p, out, function);
'''
repl=needle+'''    if (n.flags & (F_EXTERN | F_EXPORT | F_THREAD)) != 0 {
        var parameter = n.first;
        while parameter >= 0 {
            if cc_flat_image_reference(p, p.nodes[parameter].type_id) { cc_fail(p, function, "c: image-reference foreign/export/thread ABI needs owner authority forwarding"); }
            parameter = p.nodes[parameter].next;
        }
    }
''';assert needle in s;s=s.replace(needle,repl,1)
p.write_text(s);print('private owner authority stage written; encoded pool leaf staging retained')
