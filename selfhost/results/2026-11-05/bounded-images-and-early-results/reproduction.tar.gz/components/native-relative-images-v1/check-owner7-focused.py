from pathlib import Path
import os,json,hashlib,subprocess,shutil,time
base=Path(__file__).resolve().parent;out=base/'owner7-focused';out.mkdir(exist_ok=False);cc=Path(shutil.which('clang')).resolve();gdb=Path(shutil.which('gdb')).resolve()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
contracts=json.loads((base/'qualified-contracts44-v4.json').read_text());run=json.loads((base/'qualified7-contracts-v4/report.json').read_text());assert run['status']=='passed'
pins={str(p):sha(p) for p in [Path(__file__).resolve(),cc,gdb,base/'build-owner7/goose',base/'qualified-contracts44-v4.json',base/'qualified7-contracts-v4/report.json']}
r=dict(status='running',method='Actual unmodified generated C recompiled with Clang ASan+UBSan O0/O2; separate read-only GDB observations at image commit and shutdown against independently specified bytes. Correctness/layout only, no debugger timing comparison.',input_sha256=pins,commands=[],bytes={})
def save():(out/'report.json').write_text(json.dumps(r,indent=2)+'\n')
def execute(label,command,expected=None,code=0):
 command=list(map(str,command));t=time.monotonic();p=subprocess.run(command,capture_output=True,timeout=60,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1'))
 (out/(label+'.stdout')).write_bytes(p.stdout);(out/(label+'.stderr')).write_bytes(p.stderr);r['commands'].append(dict(command=command,exit_code=p.returncode,seconds=time.monotonic()-t));save();assert p.returncode==code,(label,p.stderr[-3000:])
 if expected is not None:assert p.stdout==expected,(label,p.stdout)
 assert b'ERROR: AddressSanitizer' not in p.stderr and b'runtime error:' not in p.stderr.replace(b'goose runtime error:',b''),(label,p.stderr)
 return p
for row in run['results']:
 case=next(c for c in contracts['cases'] if c['id']==row['case']);source=Path(run['commands'][row['compile_command']]['command'][-1]);pins[str(source)]=sha(source);label=row['case'].split('/')[-1]+'-O'+str(row['level']);binary=out/label
 execute(label+'-cc',[cc,'-std=gnu11','-O'+str(row['level']),'-g','-fsanitize=address,undefined','-fno-omit-frame-pointer',source,'-lm','-ldl','-pthread','-o',binary]);code=case['expect']['exit'];failures=0
 if code=='nonzero':code=1;failures=1
 observed=execute(label+'-run',[binary],case['expect']['stdout'].encode(),code);assert observed.stderr.count(b'goose runtime error:')==failures,(label,observed.stderr)
r['input_sha256_after']={p:sha(p) for p in pins};assert pins==r['input_sha256_after'];r['status']='passed';save();print('final32 generated programs passed Clang O0/O2 ASan+UBSan')
