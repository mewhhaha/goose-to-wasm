from pathlib import Path
import re,json,subprocess,hashlib,shutil,time
base=Path(__file__).resolve().parent;old=base/'owner5-focused';out=base/'owner5-bytes';out.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
previous=json.loads((old/'report.json').read_text());assert previous['status']=='passed' and len(previous['commands'])==52
contracts=json.loads((base/'qualified-contracts44-v2.json').read_text());run=json.loads((base/'qualified5-contracts-v2/report.json').read_text());cc=Path(shutil.which('clang')).resolve();gdb=Path(shutil.which('gdb')).resolve()
for row in run['results']:
 name=row['case'].split('/')[-1]+'-O'+str(row['level']);case=next(c for c in contracts['cases'] if c['id']==row['case']);assert (old/(name+'-run.stdout')).read_text()==case['expect']['stdout'];err=(old/(name+'-run.stderr')).read_text();assert 'AddressSanitizer' not in err and 'runtime error:' not in err.replace('goose runtime error:','');assert err.count('goose runtime error:')==int(case['expect']['exit']=='nonzero')
pins={str(p):sha(p) for p in [Path(__file__).resolve(),cc,gdb,old/'report.json',base/'qualified5-contracts-v2/report.json',base/'qualified-contracts44-v2.json']}
r=dict(status='running',method='Read-only GDB byte probe of final owner5 generated C. Stop at the actual user-main g_activation_leave before restoring its regions. Existing52 sanitizer child outcomes and output/diagnostics revalidated without rerunning unchanged binaries.',input_sha256=pins,commands=[],bytes={})
def save():(out/'report.json').write_text(json.dumps(r,indent=2)+'\n')
expectations={'direct-fixed':dict(initial=['81018900000078563412'],final=['81011100000078563412']),'direct-varint':dict(initial=['810189015b','80010048'],final=['810189015b','80010048']),'initializer-pool-growth':dict(initial=['81010105'],final=['81010105'])}
for name,expected in expectations.items():
 row=next(x for x in run['results'] if x['case'].endswith('/'+name) and x['level']==0);source=Path(run['commands'][row['compile_command']]['command'][-1]);pins[str(source)]=sha(source);entry=re.search(r'int main\(.*?;(g_fn\d+)\(NULL,g_global_regions\)',source.read_text()).group(1)
 script=(base/'flat2-focused/direct-fixed.gdb').read_text().replace(' def stop(self):\n  print("LAYOUT', ' def stop(self):\n  if gdb.newest_frame().older().name()!="'+entry+'":return False\n  print("LAYOUT').replace('Finish("g_runtime_finish")','Finish("g_activation_leave")');path=out/(name+'.gdb');path.write_text(script);pins[str(path)]=sha(path);binary=out/name
 for label,command in [('cc',[cc,'-std=gnu11','-O0','-g',source,'-lm','-ldl','-pthread','-o',binary]),('gdb',[gdb,'-q','--batch','-x',path,'--args',binary])]:
  command=list(map(str,command));start=time.monotonic();p=subprocess.run(command,capture_output=True,timeout=30);(out/(name+'-'+label+'.stdout')).write_bytes(p.stdout);(out/(name+'-'+label+'.stderr')).write_bytes(p.stderr);r['commands'].append(dict(command=command,exit_code=p.returncode,seconds=time.monotonic()-start));save();assert p.returncode==0,p.stderr
 text=p.stdout.decode();actual=dict(initial=[x[6:] for x in text.splitlines() if x.startswith('IMAGE ')],final=[x[6:] for x in text.splitlines() if x.startswith('FINAL ')]);r['bytes'][name]=dict(expected=expected,actual=actual);save();assert actual==expected,(name,text);assert 'LAYOUT 8 16 24' in text,text
r['input_sha256_after']={p:sha(p) for p in pins};assert pins==r['input_sha256_after'];r['status']='passed';save();print('exact committed/final bytes and8/16/24 layouts passed;52 sanitizer commands preserved')
