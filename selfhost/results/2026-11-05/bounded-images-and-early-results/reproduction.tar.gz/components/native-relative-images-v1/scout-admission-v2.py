from pathlib import Path
import json,hashlib,subprocess,time
base=Path(__file__).resolve().parent;root=base.parents[2];producer=root/'build/completion-runs/c-only-bootstrap-44/goose';proof=root/'build/completion-runs/c-only-bootstrap-44/report.json'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
r=json.loads(proof.read_text());assert r['status']=='passed' and sha(producer)==r['executable_sha256']
out=base/'admission44-v2';out.mkdir(exist_ok=False);rows=[];pins={str(p):sha(p) for p in [producer,proof,Path(__file__).resolve(),base/'controls-v2.json',*sorted((base/'controls').glob('*.goose')),*sorted((root/'stdlib').glob('*.goose'))]}
for case in json.loads((base/'controls-v2.json').read_text()):
 row=dict(case,observations=[])
 for action in ['check','emit']:
  command=list(map(str,[producer,case['source'],'--stdlib',root/'stdlib','--target','native','-O0']))
  if action=='check':command+=['--check']
  else:command+=['--standalone','-o',str(out/(case['name']+'.c'))]
  t=time.monotonic();p=subprocess.run(command,capture_output=True,text=True,timeout=20);row['observations'].append(dict(action=action,command=command,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr,seconds=time.monotonic()-t))
 row['frontend_expectation_match']=(row['observations'][0]['exit_code']==0)==case['expect_frontend_accept'];rows.append(row);print(case['name'],[(x['action'],x['exit_code']) for x in row['observations']],row['observations'][-1]['stderr'].splitlines()[:2],flush=True)
report=dict(status='scouted',method='Verified C-only44 producer only. Baseline check and emit classify staged valid programs versus preserved frontend refusals; no candidate implementation or expected-output capture.',input_sha256=pins,results=rows,input_sha256_after={p:sha(p) for p in pins});assert pins==report['input_sha256_after'];(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
