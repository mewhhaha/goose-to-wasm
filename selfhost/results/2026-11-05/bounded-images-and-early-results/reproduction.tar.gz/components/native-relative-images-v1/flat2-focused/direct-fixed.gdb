set pagination off
set confirm off
python
import gdb
images=[]
class Commit(gdb.Breakpoint):
 def stop(self):
  frame=gdb.newest_frame();header=frame.read_var("destination").cast(gdb.lookup_type("GImage").pointer()).dereference();base=int(header["base"]);end=int(frame.read_var("end"));images.append((base,end-base));data=gdb.selected_inferior().read_memory(base,end-base).tobytes();print("IMAGE "+data.hex());return False
class Finish(gdb.Breakpoint):
 def stop(self):
  print("LAYOUT "+str(int(gdb.parse_and_eval("sizeof(GRef)")))+" "+str(int(gdb.parse_and_eval("2*sizeof(const uint8_t*)")))+" "+str(int(gdb.parse_and_eval("sizeof(GImage)"))))
  for base,size in images:print("FINAL "+gdb.selected_inferior().read_memory(base,size).tobytes().hex())
  return False
Commit("g_image_finish")
Finish("g_runtime_finish")
end
run
