from pathlib import Path
import os,json,hashlib,subprocess,shutil,time
base=Path(__file__).resolve().parent;out=base/'flat2-focused';out.mkdir(exist_ok=False);cc=Path(shutil.which('clang')).resolve();gdb=Path(shutil.which('gdb')).resolve()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
contracts=json.loads((base/'flat-contracts44.json').read_text());run=json.loads((base/'flat2-contracts/report.json').read_text());assert run['status']=='passed'
pins={str(p):sha(p) for p in [Path(__file__).resolve(),cc,gdb,base/'build-flat2/goose',base/'flat-contracts44.json',base/'flat2-contracts/report.json']}
r=dict(status='running',method='Actual unmodified generated C recompiled with Clang ASan+UBSan O0/O2; separate read-only GDB observations at image commit and shutdown against independently specified bytes. Correctness/layout only, no debugger timing comparison.',input_sha256=pins,commands=[],bytes={})
def save():(out/'report.json').write_text(json.dumps(r,indent=2)+'\n')
def execute(label,command,expected=None,code=0):
 command=list(map(str,command));t=time.monotonic();p=subprocess.run(command,capture_output=True,timeout=60,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1'))
 (out/(label+'.stdout')).write_bytes(p.stdout);(out/(label+'.stderr')).write_bytes(p.stderr);r['commands'].append(dict(command=command,exit_code=p.returncode,seconds=time.monotonic()-t));save();assert p.returncode==code,(label,p.stderr[-3000:])
 if expected is not None:assert p.stdout==expected,(label,p.stdout)
 assert b'ERROR: AddressSanitizer' not in p.stderr and b'runtime error:' not in p.stderr.replace(b'goose runtime error:',b''),(label,p.stderr)
 return p
for row in run['results']:
 case=next(c for c in contracts['cases'] if c['id']==row['case']);source=Path(run['commands'][row['compile_command']]['command'][-1]);pins[str(source)]=sha(source);label=row['case'].split('/')[-1]+'-O'+str(row['level']);binary=out/label
 execute(label+'-cc',[cc,'-std=gnu11','-O'+str(row['level']),'-g','-fsanitize=address,undefined','-fno-omit-frame-pointer',source,'-lm','-ldl','-pthread','-o',binary]);code=case['expect']['exit'];failures=0
 if code=='nonzero':code=1;failures=1
 observed=execute(label+'-run',[binary],case['expect']['stdout'].encode(),code);assert observed.stderr.count(b'goose runtime error:')==failures,(label,observed.stderr)
expectations={
'direct-fixed':dict(initial=['81018900000078563412'],final=['81011100000078563412']),
'direct-varint':dict(initial=['810189015b','80010048'],final=['810189015b','80010048']),
'initializer-pool-growth':dict(initial=['81010105'],final=['81010105'])}
script='''set pagination off
set confirm off
python
import gdb
images=[]
class Commit(gdb.Breakpoint):
 def stop(self):
  frame=gdb.newest_frame();header=frame.read_var("destination").cast(gdb.lookup_type("GImage").pointer()).dereference();base=int(header["base"]);end=int(frame.read_var("end"));images.append((base,end-base));data=gdb.selected_inferior().read_memory(base,end-base).tobytes();print("IMAGE "+data.hex());return False
class Finish(gdb.Breakpoint):
 def stop(self):
  print("LAYOUT "+str(int(gdb.parse_and_eval("sizeof(GRef)")))+" "+str(int(gdb.parse_and_eval("2*sizeof(const uint8_t*)")))+" "+str(int(gdb.parse_and_eval("sizeof(GImage)"))))
  for base,size in images:print("FINAL "+gdb.selected_inferior().read_memory(base,size).tobytes().hex())
  return False
Commit("g_image_finish")
Finish("g_runtime_finish")
end
run
'''
for name,expect in expectations.items():
 row=next(x for x in run['results'] if x['case'].endswith('/'+name) and x['level']==0);source=Path(run['commands'][row['compile_command']]['command'][-1]);binary=out/(name+'-gdb');execute(name+'-gdb-cc',[cc,'-std=gnu11','-O0','-g',source,'-lm','-ldl','-pthread','-o',binary]);path=out/(name+'.gdb');path.write_text(script);pins[str(path)]=sha(path);p=execute(name+'-gdb',[gdb,'-q','--batch','-x',path,'--args',binary]);text=p.stdout.decode();actual=dict(initial=[x[6:] for x in text.splitlines() if x.startswith('IMAGE ')],final=[x[6:] for x in text.splitlines() if x.startswith('FINAL ')]);r['bytes'][name]=dict(expected=expect,actual=actual);save();assert actual==expect,(name,text);assert 'LAYOUT 8 16 24' in text,text
r['input_sha256_after']={p:sha(p) for p in pins};assert pins==r['input_sha256_after'];r['status']='passed';save();print('14 sanitized programs plus exact GDB bytes/layout passed')
