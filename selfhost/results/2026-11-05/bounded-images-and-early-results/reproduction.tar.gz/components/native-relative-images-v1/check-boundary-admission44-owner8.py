from pathlib import Path
import json,hashlib,subprocess
base=Path(__file__).resolve().parent;root=base.parents[2];out=base/'boundary-admission44-owner8';out.mkdir(exist_ok=False);compiler=base.parent/'c-only-bootstrap-44/goose';manifest=base/'boundary-controls44-v7.json';cases=json.loads(manifest.read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
pins={str(p):sha(p) for p in [compiler,manifest,Path(__file__).resolve(),*[Path(c['source']) for c in cases]]};rows=[]
for case in cases:
 for level in [0,2]:
  cmd=list(map(str,[compiler,case['source'],'--stdlib',root/'stdlib','--target','native','-O'+str(level),'--check']));a=subprocess.run(cmd,capture_output=True,text=True,timeout=10);row=dict(case=case['name'],level=level,command=cmd,exit_code=a.returncode,stdout=a.stdout,stderr=a.stderr,expected_exit=case['frontend_exit']);rows.append(row);assert a.returncode==case['frontend_exit'],row
r=dict(status='passed',method='Canonical44 admission of every unsupported boundary matches final owner8 frontend classification. Candidate emission refusal qualified separately.',input_sha256=pins,results=rows,input_sha256_after={p:sha(p) for p in pins});assert r['input_sha256']==r['input_sha256_after'];(out/'report.json').write_text(json.dumps(r,indent=2)+'\n');print(len(rows),'baseline admissions match')
