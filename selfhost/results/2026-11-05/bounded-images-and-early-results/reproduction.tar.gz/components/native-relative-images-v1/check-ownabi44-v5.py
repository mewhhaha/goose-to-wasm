from pathlib import Path
import os,time,hashlib,json,subprocess,shutil
base=Path(__file__).resolve().parent;root=base.parents[2];out=base/'own-abi44-v5';out.mkdir(exist_ok=False);producer=base/'build-owner5/goose';cc=Path(shutil.which('clang')).resolve()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
pins=dict(json.loads((base/'build-owner5/report.json').read_text())['input_sha256']);pins.update({str(p):sha(p) for p in [producer,cc,Path(__file__).resolve()]});r=dict(status='running',method='Actual full candidate emits its compiler using the extended CcPlace/owner-channel ABI; Clang-O2 builds it; that actual new compiler checks both target models and emits byte-identical compiler C. Correctness only.',input_sha256=pins,commands=[])
def save():(out/'report.json').write_text(json.dumps(r,indent=2)+'\n')
save()
try:
 commands=[('emit',[producer,base/'source/selfhost/main.goose','--stdlib',root/'stdlib','--target','native','--standalone','-O0','-o',out/'compiler.c']),('cc',[cc,'-std=gnu11','-O2',out/'compiler.c','-lm','-ldl','-pthread','-o',out/'goose'])]
 for target in ['native','wasm-direct']:commands.append(('check-'+target,[out/'goose',base/'source/selfhost/main.goose','--stdlib',root/'stdlib','--target',target,'--check','--library']))
 commands.append(('repeat',[out/'goose',base/'source/selfhost/main.goose','--stdlib',root/'stdlib','--target','native','--standalone','-O0','-o',out/'repeat.c']))
 for label,command in commands:
  command=list(map(str,command));start=time.monotonic()
  with (out/(label+'.stdout')).open('w') as stdout,(out/(label+'.stderr')).open('w') as stderr:
   child=subprocess.Popen(command,stdout=stdout,stderr=stderr);_,status,usage=os.wait4(child.pid,0);child.returncode=os.waitstatus_to_exitcode(status)
  r['commands'].append(dict(command=command,exit_code=child.returncode,seconds=time.monotonic()-start,max_rss_kib=usage.ru_maxrss));save();assert child.returncode==0,(out/(label+'.stderr')).read_text()[-5000:]
 assert (out/'compiler.c').read_bytes()==(out/'repeat.c').read_bytes(),'new ABI emission changed'
 r['input_sha256_after']={p:sha(p) for p in pins};assert pins==r['input_sha256_after'];r.update(status='passed',generated_c_sha256=sha(out/'compiler.c'),compiler_sha256=sha(out/'goose'));save();print('actual compiled ABI, two model ownchecks, and fixedpoint C passed')
except BaseException as e:r.update(status='failed',error=repr(e));save();raise
