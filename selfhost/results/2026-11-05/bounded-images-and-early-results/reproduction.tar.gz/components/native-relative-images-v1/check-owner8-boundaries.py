from pathlib import Path
import json,hashlib,subprocess,time
base=Path(__file__).resolve().parent;root=base.parents[2];out=base/'owner8-boundaries';out.mkdir(exist_ok=False);compiler=base/'build-owner8/goose';cases=json.loads((base/'boundary-controls44-v7.json').read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
pins={str(p):sha(p) for p in [compiler,Path(__file__).resolve(),base/'boundary-controls44-v7.json',*[Path(x['source']) for x in cases]]};r=dict(status='running',method='Preserved unsupported owner/provenance/ABI paths checked at both optimization levels, independently of valid path gains. Frontend admission stays equal to verified44 scout.',input_sha256=pins,results=[])
def save():(out/'report.json').write_text(json.dumps(r,indent=2)+'\n')
try:
 for case in cases:
  for level in [0,2]:
   row=dict(case=case['name'],level=level,commands=[])
   for phase in ['check','emit']:
    command=[str(compiler),case['source'],'--stdlib',str(root/'stdlib'),'--target','native','-O'+str(level)]
    if phase=='check':command+=['--check']
    else:command+=['--standalone','-o',str(out/(case['name']+'-O'+str(level)+'.c'))]
    p=subprocess.run(command,capture_output=True,text=True,timeout=20);row['commands'].append(dict(phase=phase,command=command,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr))
   row['match']=row['commands'][0]['exit_code']==case['frontend_exit'] and row['commands'][1]['exit_code']==1;r['results'].append(row);save();assert row['match'],row
 r['input_sha256_after']={p:sha(p) for p in pins};assert pins==r['input_sha256_after'];r['status']='passed';save();print(len(r['results']),'unsupported path refusals preserved')
except BaseException as e:r.update(status='failed',error=repr(e));save();raise
