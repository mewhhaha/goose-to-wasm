from pathlib import Path
import json,hashlib,shutil,subprocess,os,time
base=Path(__file__).resolve().parent;out=base/'bounded-cells-final';out.mkdir(exist_ok=False);source=base/'controls/bounded_cells.c'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
compilers=[Path(shutil.which(n)).resolve() for n in ['clang','gcc']]
pins={str(p):sha(p) for p in [Path(__file__).resolve(),source,*compilers,*sorted((base/'source/native').glob('*.h')),*sorted((base/'source/native/runtime').glob('*.h'))]}
r=dict(status='running',method='Final bounded physical cell APIs: independent canonical bytes, sentinel preservation, receiving-cell origin, valid fixed/var skips, and six bounded refusal cases. GRef8 and auxiliary cursor16 assertions. No timing claim.',input_sha256=pins,commands=[])
def save():(out/'report.json').write_text(json.dumps(r,indent=2)+'\n')
try:
 for cc in compilers:
  for level in [0,2]:
   name=cc.name+'-O'+str(level);exe=out/name
   commands=[('cc',[cc,'-std=gnu11','-O'+str(level),'-g','-fsanitize=address,undefined','-fno-omit-frame-pointer',source,'-lm','-ldl','-pthread','-o',exe]),('run',[exe])]
   for action,command in commands:
    command=list(map(str,command));start=time.monotonic();p=subprocess.run(command,capture_output=True,timeout=30,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1'))
    (out/(name+'-'+action+'.stdout')).write_bytes(p.stdout);(out/(name+'-'+action+'.stderr')).write_bytes(p.stderr);r['commands'].append(dict(command=command,exit_code=p.returncode,seconds=time.monotonic()-start));save();assert p.returncode==0,p.stderr.decode()[-3000:]
    if action=='run':
     assert p.stdout==b'bounded physical relative cursor bytes ok\n',p.stdout
     assert p.stderr.count(b'goose runtime error:')==6,p.stderr
     assert b'ERROR: AddressSanitizer' not in p.stderr and b'runtime error:' not in p.stderr.replace(b'goose runtime error:',b''),p.stderr
 r['input_sha256_after']={p:sha(p) for p in pins};assert pins==r['input_sha256_after'];r['status']='passed';save();print('Clang/GCC O0/O2 bounded byte controls passed')
except BaseException as e:r.update(status='failed',error=repr(e));save();raise
