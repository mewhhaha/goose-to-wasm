from pathlib import Path
import hashlib,json,subprocess
base=Path(__file__).resolve().parent;root=base.parents[2];out=base/'preservation44-owner7';out.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
programs=[root/'native/tests/relative.goose',root/'native/tests/variable_images.goose',root/'tests/fixtures/contracts/static-globals/owning_snapshots.goose']
compilers=[root/'build/completion-runs/c-only-bootstrap-44/goose',base/'build-owner7/goose'];pins={str(p):sha(p) for p in [Path(__file__).resolve(),*programs,*compilers]};rows=[]
for source in programs:
 paths=[]
 for index,compiler in enumerate(compilers):
  target=out/(source.stem+'-'+str(index)+'.c');cmd=list(map(str,[compiler,source,'--stdlib',root/'stdlib','--target','native','--standalone','-O0','-o',target]));r=subprocess.run(cmd,capture_output=True,text=True,timeout=20);assert r.returncode==0,(source,r.stderr);paths.append(target)
 baseline=paths[0].read_text();candidate=paths[1].read_text();start=candidate.index('/* Physical cell walking has a logical end;');end=candidate.index('static GRef g_relative_var_load(',start);helper=candidate[start:end];normalized=candidate[:start]+candidate[end:]
 row=dict(source=str(source),source_sha256=sha(source),baseline_c_sha256=sha(paths[0]),candidate_c_sha256=sha(paths[1]),baseline_bytes=paths[0].stat().st_size,candidate_bytes=paths[1].stat().st_size,new_runtime_helper_bytes=len(helper.encode()),all_other_c_bytes_identical=baseline==normalized);rows.append(row);assert row['all_other_c_bytes_identical'],source
for name in ['selfhost/codegen_c_images.goose','native/images.h','selfhost/checker.goose','selfhost/model.goose']:
 assert (base/'source'/name).read_bytes()==(root/'build/completion-runs/snapshot-44'/name).read_bytes(),name
report=dict(status='passed',method='Same unchanged source/stdlib/flags with frozen44 and actual candidate. The one added unused bounded-cell runtime helper is removed for comparison; every remaining generated C byte must be identical. Includes fixed relative values, ordinary variable images, and worker owning snapshot policy. Codec, verification, checker/model source files remain byte-identical.',input_sha256=pins,results=rows,input_sha256_after={p:sha(p) for p in pins});assert pins==report['input_sha256_after'];(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print('three unaffected generated programs identical except unused bounded-cell helper')
