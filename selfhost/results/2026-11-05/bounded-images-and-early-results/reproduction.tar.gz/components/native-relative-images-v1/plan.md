Private scout against immutable snapshot44. No compiler/runtime source changes or guard relaxation.

The first implementation should construct and access relative cells only while the exact receiving image header and its logical extent are available. Natural references remain `GRef` (8 bytes); `{at,end}` is an auxiliary physical cursor (16 bytes), never aggregate image bytes or a replacement natural reference value.

Current evidence:

- Verified canonical44 checks five valid staged controls and rejects the two invalid ones. Every staged valid program still stops at an explicit native lowering guard.
- Clang/GCC O0/O2 ASan+UBSan pass the independent prefix/reference/sentinel byte fixture and three bounded failure cases. This proves existing bounded raw offset operations, not compiler lowering or a cross-call provenance protocol.
- `nonfixed-pointee.goose` initially indexed a variable element and failed before the intended boundary. Its source/report remain; `nonfixed-pointee-push.goose` constructs through `push` and reaches the intended physical-view refusal.

The source contracts to preserve:

| Contract | Existing source |
| --- | --- |
| Relative offsets are computed from the final slot, or the named pool base biased by one | primary `codegen_construct.h:166-216`, `codegen_values.h:85-119` |
| Construction passes the receiving stack through calls and every value-producing branch | primary `codegen_construct.h:8-16`, `codegen.h:1288-1300` |
| A loaded relative pointer to a bytes-class pointee remains a byte location | primary `codegen_values.h:99-120`, `codegen_values.h:960-983` |
| Varint relative cells are construction-only; fixed-width rebinding remains distinct | primary `typecheck_flow.h:2603-2606` |
| Existing receiver identity and publication chains are explicit | `codegen_c.goose:136-150`, `native/storage.h:155-168` |
| Canonical verification is a separate root-aware walk, not permission to admit ordinary transfer bytes | primary `codegen_types.h:888-1183`; selfhost `ci_verifiable` remains unchanged |

Concrete missing pieces:

1. `CcPlace` has `image_base` and `owner_header`, but no end. Member traversal propagates only those two. `cc_base_place` recreates `CC_IMAGE` from a raw reference and loses even the header. `CcCursor` also carries only an address. A known region capacity or current stack top is not an exact logical image extent.
2. `g_physical_skip_*` currently aliases single-pointer transfer/image helpers. A varint relative cell has source size zero; `ci_direct` would make its transfer skip advance zero bytes. That helper must never become its physical cursor implementation.
3. `cc_image_put_value` currently routes relative cells through `g_relative_store`. Width zero means the native `GVarRelative` control, not canonical packed bytes. Simply enabling `cc_image_constructible` would reserve zero bytes and write the wrong representation.
4. A `CC_IMAGE` fixed relative read can fall through to a natural `g_load` selected by the wanted type. Physical reads must use the declared cell width and then return a natural `GRef`; requested result type cannot select the stored width.
5. Receiver construction saves publication links, but a relative-image implementation must also prove rollback of the borrowed receiver's cursor/header on abandoned construction. Existing `CcDestination.publication/construction` fields are placeholders, not that proof.

Staged implementation:

1. Add an explicit logical-end ID to physical places/cursors and propagate it from an actual `GImage` receiver/view. Reject a relative image access when that authority is missing. Keep fixed-pointee admission narrow: the pointee has fixed native physical layout, matching frame/source size, and no owned region/header that would be interpreted as packed bytes. Do not change variable-pointee refusal.
2. Generate a separate bounded physical skip family for the newly admitted relative-containing images. Fixed fields check remaining bytes; varint integer/reference cells use bounded canonical checks; records and arrays pass the same end. This family must not reuse or alter `g_image_{size,write,unpack}` ordinary transfer behavior or `ci_verifiable`.
3. Construction reserves the maximum ten-byte varint cell capacity, calls raw `g_relative_var_store(cell,capacity_end,...)`, and advances by its returned end. Only actual encoded bytes enter the image. Reads call bounded raw load with declared cell semantics. Fixed-width stores check cell capacity and use the fixed offset API. Varint field rebinding stays rejected by the frontend.
4. Construct into the actual receiving root. Relative targets remain natural addresses until that slot exists; preserve fill-leaf freezing and `self` receiver binding. Admit tuple image result channels only where each child has a real image receiver. For fresh append/declaration receivers, test a construction transaction that snapshots header/cursor/publication state and restores it on ordinary exit and nonlocal unwind before committing. Do not advertise rollback based only on resetting publication links.
5. Prove a separate physical-authority channel before admitting borrowed image references through parameters, returns, captures or dispatch. Existing `CcChannels` transports receiving result locations, not image-reference bounds. The small ABI experiment must forward `{logical root,end,owner}` alongside the existing natural reference without enlarging `GRef`. Until it succeeds, keep those unknown-bound paths refused explicitly.
6. Only then widen the relative-image constructor predicate for the exact types/paths covered. Run both levels, meaningful sanitizer byte/provenance tests, prior native passes, original frontend refusals, actual own-compiled ABI/fixedpoint checks, and paired fixed-image bytes. Keep transfer codecs and verification byte-identical. Measure generated C size, compile wall/RSS and any cursor metadata cost; claim gains only for original case/level pairs actually recovered.

Controls waiting at each stage:

- Direct fixed/varint cells, optional null, following padding/sentinel, and actual fixed-width rebinding: `direct-fixed`, `direct-varint`.
- Calls, branches and tuple result receivers: `receiver-result`.
- Mandatory unknown-bound refusal until the authority channel exists: `borrowed-view`.
- Variable-pointee physical/native confusion remains refused: `nonfixed-pointee-push`.
- Existing exact-root and construction-only frontend refusals: `wrong-pool`, `varint-rebind`.
- Before qualification add independent abandoned append/nonlocal-return controls asserting old length, old elements, next append cursor, and no escaped view to partial bytes; add growth relocation and fixed-image byte controls.

The named upstream programs contain mixed requirements: `relative_reference_of` needs a holder-reference authority channel; `relative_destination_results` and `relative_block_results` include variable pointees/embedded variable fields beyond the direct fixed-pointee cells. `self_relative_adt_payloads` may fail at transient-region lifetime rules first. Do not promise any of those complete programs from stage1 or waive their earlier lifetime guard.

Rejected shortcuts: natural pointer bytes or `GVarRelative` controls in aggregate bytes; raw-region-capacity as logical end; unbounded skip to discover a trusted end; changing image references to header addresses (breaks natural byte identity); guard removal without an access-specific authority check; varint in-place overwrite; verifier/ordinary codec relaxation; claiming publication-link restoration proves receiver rollback.
