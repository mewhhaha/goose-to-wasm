from pathlib import Path
base=Path(__file__).resolve().parent
storage=base/'source/selfhost/codegen_c_storage.goose'
s=storage.read_text();s=s.replace('image_base: i64 = -1 }','image_base: i64 = -1, image_end: i64 = -1 }',1)
anchor='fn cc_image_constructible(p: Program&, id: i64) -> bool {\n'
new='''// This first physical stage has no nested owner or self-relative field.
fn cc_flat_relative_image(p: Program&, id: i64) -> bool {
    if id < 0 || p.types[id].kind != TY_STRUCT || cc_size_class(p, id) != 1 { return false; }
    var field = p.nodes[p.types[id].declaration].first; var relative = false;
    while field >= 0 {
        let n = p.nodes[field]; field = n.next;
        if (n.flags & F_PAD) != 0 { continue; }
        let t = p.types[n.type_id];
        if t.kind == TY_REF && t.length_storage >= 0 && t.pool >= 0 {
            if !cc_fixed_storage(p, t.element) || cc_region_width(p, t.element) != 0 || cc_frame_size(p, t.element) != p.types[t.element].size { return false; }
            relative = true;
        } else if t.kind != TY_INT && t.kind != TY_BOOL { return false; }
    }
    return relative;
}
fn cc_physical_cell_width(p: Program&, id: i64) -> i64 {
    let t = p.types[id];
    if t.kind == TY_REF { return t.length_storage; }
    if t.kind == TY_INT && t.storage != 0 { return 0; }
    return t.size;
}
fn cc_image_constructible(p: Program&, id: i64) -> bool {
    if cc_flat_relative_image(p, id) { return true; }
'''
assert anchor in s;s=s.replace(anchor,new);storage.write_text(s)
p=base/'source/native/relative.h';s=p.read_text();needle='static GRef g_relative_var_load('
idx=s.index(needle);s=s[:idx]+'''/* Physical cell walking has a logical end; it never reads a scalar control. */
static const uint8_t *g_relative_cell_skip(const uint8_t *cell,const uint8_t *end,int width) {
    if(!width)return g_relative_var_skip(cell,end);
    uintptr_t at=(uintptr_t)cell,limit=(uintptr_t)end;
    if(width<0 || limit<at || (uint64_t)width>limit-at)g_panic("physical cell exceeds image extent");
    return cell+width;
}
'''+s[idx:];p.write_text(s)
p=base/'source/selfhost/codegen_c.goose';s=p.read_text()
s=s.replace('cc_size_class(p, p.types[type_id].element) == 1 && !cc_image_constructible(p, p.types[type_id].element)', 'cc_size_class(p, p.types[type_id].element) == 1 && (!cc_image_constructible(p, p.types[type_id].element) || cc_relative_fields(p, p.types[type_id].element))',1)
needle='fn cc_load(p: Program&, f: CcBody&, ref: i64, type_id: i64) -> i64 {\n'
assert needle in s;s=s.replace(needle,needle+'    if cc_flat_relative_image(p, type_id) { cc_fail(p, f.function, "c: relative image load requires its bounded owner view"); return -1; }\n',1)
needle='    if place.form == CC_IMAGE && cc_relative_cell(p, place.type_id) && p.types[place.type_id].length_storage == 0 { cc_fail(p, node, "c: varint relative image cells require physical receiver cursors"); return -1; }\n'
replacement='''    if place.form == CC_IMAGE && place.image_end >= 0 {
        let value = cc_temp(p, f, place.type_id); cc_set(f, value); cc_id(f.out, "g_physical_load_", place.type_id); cc_text(f.out, "(g_address("); cc_id(f.out, "g_v", place.address); cc_text(f.out, "),g_address("); cc_id(f.out, "g_v", place.image_end); cc_text(f.out, "));\\n");
        return cc_convert(p, f, value, place.type_id, wanted, node);
    }
'''+needle
assert needle in s;s=s.replace(needle,replacement,1)
s=s.replace('fn cc_image_address(f: CcBody&, place: CcPlace) -> CcPlace {','fn cc_image_address(p: Program&, f: CcBody&, place: CcPlace) -> CcPlace {',1)
needle='    return CcPlace { type_id: place.type_id, address: address, form: CC_IMAGE, owner_header: place.address, image_base: address };'
replacement='''    var end = -1;
    if cc_flat_relative_image(p, place.type_id) {
        end = cc_ref_temp(f); cc_set(f, end); cc_text(f.out, "g_ref(((GImage*)g_address("); cc_id(f.out, "g_v", place.address); cc_text(f.out, "))->end);\\n");
    }
    return CcPlace { type_id: place.type_id, address: address, form: CC_IMAGE, owner_header: place.address, image_base: address, image_end: end };'''
assert needle in s;s=s.replace(needle,replacement,1);s=s.replace('cc_image_address(f, place)','cc_image_address(p, f, place)')
needle='        if base.form == CC_IMAGE {\n            cc_text(f.out, "g_ref(g_address(");'
replacement='''        if base.form == CC_IMAGE {
            if cc_flat_relative_image(p, base.type_id) && base.image_end < 0 { cc_fail(p, node, "c: relative image member requires its bounded owner view"); return CcPlace { type_id: -1, address: -1 }; }
            cc_text(f.out, "g_ref(g_address(");'''
assert needle in s;s=s.replace(needle,replacement,1)
needle='                if (previous.flags & F_PAD) != 0 { cc_text(f.out, "g_offset(");'
replacement='''                if base.image_end >= 0 {
                    cc_text(f.out, "g_ref(g_relative_cell_skip(g_address("); cc_id(f.out, "g_v", ref); cc_text(f.out, "),g_address("); cc_id(f.out, "g_v", base.image_end); cc_text(f.out, "),");
                    if (previous.flags & F_PAD) != 0 { cc_number(f.out, previous.aux); } else { cc_number(f.out, cc_physical_cell_width(p, previous.type_id)); }
                    cc_text(f.out, "));\\n");
                }
                else if (previous.flags & F_PAD) != 0 { cc_text(f.out, "g_offset(");'''
assert needle in s;s=s.replace(needle,replacement,1)
needle='            return CcPlace { type_id: type_id, address: ref, form: CC_IMAGE, stack: base.stack, owner_header: base.owner_header, image_base: base.image_base };'
replacement='''            if base.image_end >= 0 { cc_text(f.out, "(void)g_relative_cell_skip(g_address("); cc_id(f.out, "g_v", ref); cc_text(f.out, "),g_address("); cc_id(f.out, "g_v", base.image_end); cc_text(f.out, "),"); cc_number(f.out, cc_physical_cell_width(p, type_id)); cc_text(f.out, ");\\n"); }
            return CcPlace { type_id: type_id, address: ref, form: CC_IMAGE, stack: base.stack, owner_header: base.owner_header, image_base: base.image_base, image_end: base.image_end };'''
assert needle in s;s=s.replace(needle,replacement,1)
# Generate bounded scalar field loads only for the newly admitted flat images.
needle='}\nfn cc_emit_init(p: Program&, out: u8[>..]&, id: i64) {'
replacement='''    var physical: bool[>..] = []; physical.resize(p.types.len, false);
    for t, id in p.types {
        if !used[id] || !cc_flat_relative_image(p, id) { continue; }
        var field = p.nodes[t.declaration].first;
        while field >= 0 { let n = p.nodes[field]; if (n.flags & F_PAD) == 0 { physical[n.type_id] = true; } field = n.next; }
    }
    for t, id in p.types {
        if !physical[id] { continue; }
        out.format("static g_t", id, " g_physical_load_", id, "(const uint8_t *cell,const uint8_t *end){(void)g_relative_cell_skip(cell,end,", cc_physical_cell_width(p, id), ");\\n");
        if cc_relative_cell(p, id) {
            if t.length_storage == 0 { out.append("return g_relative_var_load(g_ref(cell),end,"); }
            else { out.format("return g_relative_load(g_ref(cell),", t.length_storage, ","); }
            if (t.flags & TF_OPTIONAL) != 0 { out.append("1,"); } else { out.append("0,"); }
            cc_relative_origin(p, out, id);
            if t.length_storage == 0 { out.append(",NULL);}"); } else { out.append(");}"); }
        } else { out.format("return g_load_", id, "(g_ref(cell));}"); }
        out.push(10);
    }
}
fn cc_emit_init(p: Program&, out: u8[>..]&, id: i64) {'''
assert needle in s;s=s.replace(needle,replacement,1)
# New records evaluate and validate leaves before writing their receiving bytes.
needle='recursive fn cc_image_record(p: Program&, f: CcBody&, node: i64, type_id: i64) -> i64 {\n'
new='''recursive fn cc_flat_image_record(p: Program&, f: CcBody&, node: i64, type_id: i64) -> i64 {
    let result = cc_result_temp(p, f, node, type_id); let owner = cc_temporary_ref(f, result);
    let start = f.work.len; let regions = f.region_live; var binding = -1;
    if node >= 0 { binding = p.nodes[node].first; }
    var field = p.nodes[p.types[type_id].declaration].first;
    while field >= 0 {
        let n = p.nodes[field]; field = n.next;
        if (n.flags & F_PAD) != 0 { continue; }
        var initializer = n.right;
        if binding >= 0 {
            if p.nodes[binding].symbol != field && p.nodes[binding].symbol != p.nodes.len { }
            initializer = p.nodes[binding].right; binding = p.nodes[binding].next;
        }
        var value = -1;
        if initializer >= 0 { value = cc_to(p, f, initializer, n.type_id); } else { value = cc_default(p, f, n.type_id); }
        if cc_relative_cell(p, n.type_id) {
            let encoded = f.serial; f.serial++; cc_storage_type(p, f.out, n.type_id); cc_id(f.out, " g_v", encoded); cc_text(f.out, "={0};\\n");
            let target = cc_temporary_ref(f, encoded); cc_store(p, f, target, value, n.type_id, initializer); value = encoded;
        }
        f.work.push(value);
    }
    let raw = f.serial; f.serial++;
    cc_id(f.out, "GImage *g_flat", raw); cc_text(f.out, "=(GImage*)g_address("); cc_id(f.out, "g_v", owner); cc_text(f.out, ");\\n");
    cc_id(f.out, "g_flat", raw); cc_text(f.out, "->region->stack.top="); cc_id(f.out, "g_flat", raw); cc_text(f.out, "->base;\\n");
    field = p.nodes[p.types[type_id].declaration].first; var ordinal = start;
    while field >= 0 {
        let n = p.nodes[field]; field = n.next;
        if (n.flags & F_PAD) != 0 { cc_image_padding(f, owner, n.aux); continue; }
        let value = f.work[ordinal]; ordinal++;
        if cc_relative_cell(p, n.type_id) {
            let width = p.types[n.type_id].length_storage; let cursor = cc_ref_temp(f);
            cc_set(f, cursor); cc_text(f.out, "g_ref(g_image_space("); cc_id(f.out, "g_flat", raw); cc_text(f.out, "->region,");
            if width == 0 { cc_id(f.out, "g_v", value); cc_text(f.out, ".extent"); } else { cc_number(f.out, width); } cc_text(f.out, "));\\n");
            cc_text(f.out, "memcpy(g_address("); cc_id(f.out, "g_v", cursor); cc_text(f.out, "),");
            if width == 0 { cc_id(f.out, "g_v", value); cc_text(f.out, ".bytes,"); cc_id(f.out, "g_v", value); cc_text(f.out, ".extent"); }
            else { cc_text(f.out, "&"); cc_id(f.out, "g_v", value); cc_text(f.out, ","); cc_number(f.out, width); }
            cc_text(f.out, ");g_image_advance("); cc_id(f.out, "g_flat", raw); cc_text(f.out, "->region,g_address("); cc_id(f.out, "g_v", cursor); cc_text(f.out, ")+");
            if width == 0 { cc_id(f.out, "g_v", value); cc_text(f.out, ".extent"); } else { cc_number(f.out, width); } cc_text(f.out, ");\\n");
        } else { cc_image_put_value(p, f, owner, value, n.type_id, node); }
    }
    cc_text(f.out, "g_image_finish("); cc_id(f.out, "g_v", owner); cc_text(f.out, ","); cc_id(f.out, "g_flat", raw); cc_text(f.out, "->region->stack.top);\\n");
    cc_restore(f, regions); f.region_live = regions; f.work.resize(start); return result;
}
recursive fn cc_image_record(p: Program&, f: CcBody&, node: i64, type_id: i64) -> i64 {
    if cc_flat_relative_image(p, type_id) { return cc_flat_image_record(p, f, node, type_id); }
'''
assert needle in s;s=s.replace(needle,new,1)
# Printing/equality use the bounded physical representation, not transfer helpers.
needle='    if cc_image_type(p, type_id) {\n        if (n.flags & F_PAD) != 0 { out.format("g_cursor+=", n.aux, ";\\n"); return; }'
replacement='''    if cc_flat_relative_image(p, type_id) {
        if (n.flags & F_PAD) != 0 { out.format("g_cursor=g_relative_cell_skip(g_cursor,v.end,", n.aux, ");\\n"); return; }
        if separator { cc_text(out, "g_print_text(out,\\\", \\\");\\n"); }
        out.format("g_nested_", n.type_id, "(out,g_physical_load_", n.type_id, "(g_cursor,v.end));g_cursor=g_relative_cell_skip(g_cursor,v.end,", cc_physical_cell_width(p, n.type_id), ");\\n"); return;
    }
    if cc_image_type(p, type_id) {
        if (n.flags & F_PAD) != 0 { out.format("g_cursor+=", n.aux, ";\\n"); return; }'''
assert needle in s;s=s.replace(needle,replacement,1)
needle='fn cc_equal_fields(p: Program&, out: u8[>..]&, type_id: i64, first: i64) {\n'
replacement=needle+'''    if cc_flat_relative_image(p, type_id) { out.append("int64_t n=g_image_span(a);if(n!=g_image_span(b) || (n && memcmp(a.base,b.base,(size_t)n)))return 0;\\n"); return; }
'''
assert needle in s;s=s.replace(needle,replacement,1)
p.write_text(s)
print('private flat-stage prototype written; no compiler build yet')
