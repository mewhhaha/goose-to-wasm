**Independent 46 plan: completed early-block values**

Start from frozen45 in a new private directory. Do not modify sealed45. The checker reviewed here is candidate8 SHA256 `919da950514d50ed0a98a702719cebd90dff9d120a6c051ff683bd7fda715741`.

1. Correct `check_bottom` at `checker.goose:1463`: recurse through a block's last node only when it is not `F_EARLY`. Completed early blocks use their own `F_DIVERGES` state, established after local breaks and fallthrough are joined. Preserve ordinary block/IF and actual return/break/continue/abort divergence behavior.
2. Complete early-block conversion at `checker.goose:1915–1919` inside `check_conversion`: a value-producing early block without a reachable tail must use the conversions of all its reachable break values, just as a loop does. The current code checks those conversions for failure, then falls through to the whole block's type and loses successful narrowing/reference binding. Tail-bearing early blocks must validate both breaks and tail. Empty/void blocks and valueless reachable exits must not become convertible to arbitrary types. Keep `check_expect` exit adaptation at `:2055–2058` aligned; do not bypass it as bottom.

The one-line predicate prototype already improves the readonly closure from 202/228 to 228/228, recovering 26 valid mutable early-block layout rows while preserving 114 readonly rejections. The index_of closure stays 228/228. It also properly rejects previously accepted 300, -1 and typed I64 block arguments passed to u8. **It cannot land alone:** valid small-literal, F32-literal and reference-parameter early-block arguments newly reject because of the conversion fall-through.

Required controls:

| Valid | Invalid |
| --- | --- |
| `take_u8(block { break 1; })`; untyped global named literal; nested completed blocks | Break 300 or -1 to u8; typed I64 or local `let` I64 to u8 without explicit cast |
| `take_f32(block { break 0.1; })`; explicit stored F32 widening | Incompatible typed numeric exits; mixed break ranges where any exit cannot fit |
| `take_ref(block { break a; })`, where take_ref has a typed reference parameter | Empty/void block or valueless reachable exit used as a value |
| Mutable array-reference exits joining a slice; every wrapper at depth 1–2 | Const array-reference exit joining a mutable tail then used for writing |
| Genuine abort/return divergence; nested loop/early-block break values | No-context index_of wrappers, even `&element` branches: these copy their pointees |
| Aggregate compound assignment with a completed early-block RHS; mutations visible afterward | Invalid reference identity/comparison involving completed non-reference values |

Use the existing grouped JSON closures in `astra-checker-45/`, plus the 10 focused sources and measured baseline comparisons in `astra-check-bottom-46/`. Extend the grouped controls for complete break sets, both arm orders and named-constant dependence; avoid hundreds of permanent fixture files. Primary authority: `typecheck_flow.h:1680–1716` joins tail/break reachability; `CheckBreak` preserves adaptable literal metadata; `typing/branch_reference_parameters.goose` demonstrates typed reference binding across constructs.

First run the cheap checker probe against the corrected controls and all 2800 frontend sources. Only after zero unexpected losses, build one full compiler and check exact runtime outputs on native/Wasmtime/V8 at O0/O2, including compound-assignment effects, numeric widths and nested exits. Preserve true divergences and all 45 proper-negative fixes. Qualify own-source and source/compiler/workload pins before proposing delivery; this is not part of 45.

The complete 17-line caller audit, one-line patch, source hashes and raw results are in `astra-check-bottom-46.md` and `astra-check-bottom-46/source-audit.json`. There are 15 external call expressions in 11 functions. The broader caller effects are understood; no general control-flow or lifetime rewrite is proposed.

The original `early_named_u8_call` local-let positive was misclassified: local lets retain I64. Preserve it as a negative and use an untyped global named constant as the positive; see `astra-check-bottom-46/named-expectation-correction.json`. Original probe evidence remains unchanged.
