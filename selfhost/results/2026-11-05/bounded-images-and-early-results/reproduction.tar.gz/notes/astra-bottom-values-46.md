**Completed early-block values review — 2026-11-05**

The paired checker source has no remaining review blocker. It implements the bounded plan without unrelated checker changes; the final sealed candidate is approved for root composition.

`check_bottom` now descends into an ordinary block's tail only. An early block's local break ends that break statement, but the completed construct produces a value; its own `F_DIVERGES` determines whether it is bottom. Genuine return, break, continue, abort and fully diverging constructs retain their existing classification. This follows primary `CheckEarlyBlock` (`typecheck_flow.h:1680–1716`), which joins reachable tails and local breaks.

The conversion change is necessary alongside that predicate. `check_conversion` first checks all early-block exits; when there is no reachable tail, it returns their conversion score instead of falling through to an already joined scalar type. The explicit VOID-to-value guard prevents an empty block or valueless completed construct from becoming an arbitrary value. With a reachable tail, the prior tail conversion remains required after all breaks pass. `check_expect` is unchanged and still adapts each break value to the selected destination; successful conversion does not bypass numeric width or reference binding.

The previous 17-line caller audit is in `astra-check-bottom-46.md`: 15 external call expressions across 11 functions, covering joins, numeric adaptation, readonly/reference discovery, dependency recording and aggregate compound assignment. The measured prototype's 26 mutable early-block false positives motivated this candidate; the final paired controls preserve readonly rejection and reject out-of-range/typed narrowing while recovering valid literal and reference destinations.

Reviewed evidence:

- Full frontend comparison: 2800 cases, no losses.
- Corrected focused layouts: 40/40. Grouped readonly, reference and conversion controls: 702/702; break/tail order, empty/void and mixed exits are represented.
- Exact runtime outputs: 36/36 native+Wasmtime and 18/18 V8. The same 36 native/Wasmtime rows pass only 8/36 on frozen45; the 28 gains include prior compiler refusals and incorrect aggregate/reference behavior. These are supplementary controls, not 28 original frozen-suite gains.
- Own-source check: exit0 in 62.113 seconds, with the exact reviewed checker hash.
- The existing 138 frozen failures remain separately accounted for; this review claims no original frozen contract gain from the paired change alone.

Two fixture corrections are explicit and preserved. A local `let n=1` remains I64 and must reject at u8; only an untyped global named constant supplies the adaptable positive. Reference identity is `.==`; the old `.=` input was a parser-negative, so the corrected fixture provides the intended semantic-negative control. Prior raw records remain unchanged and are not represented as valid semantic proof.

| Identity | SHA-256 |
| --- | --- |
| checker | `7677808b0ca5804c8c801b88fc96a38b1e7930b3263451dd1b53a46f84117e63` |
| paired patch | `ec57b225d604d7bd307b342192e9cabd9de2eb09b2108e29f8bf4cfe1c90077a` |
| candidate compiler | `c7d1af4b423d80157cc38f98265c6fb80477ddb92f1b36d2d8abf619fb1fdf74` |

`astra-bottom-values-46/review-pins.json` pins the inspected source, patch, compiler and qualification evidence. This independent follow-up reviewed source and existing measured evidence; it did not repeat broad gates or invoke the C++ oracle. No production files were edited.

Final seal verification: all 52 handoff evidence/source/compiler references match. Handoff SHA-256 `a59aba0dff83cd9850163a4488b86c30f8ed0c9f11fb537102d3aaba096e4c21`; verification details are in `astra-bottom-values-46/seal-verification.json`. The rejected bottom-only variant remains separately measured at 20/40 focus rows versus the paired candidate's 40/40.
