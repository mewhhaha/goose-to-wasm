from pathlib import Path
import hashlib,json,subprocess
w=Path('/home/jacobt/src/goose-to-wasm/build/completion-runs');out=w/'snapshot-46-reproduced-v2';out.mkdir(exist_ok=False);parent=json.loads((w/'c-only-bootstrap-45/report.json').read_text());names=['selfhost/'+n for n in parent['source_sha256']]+list(parent['asset_sha256'])+['native/tests/check.py','native/tests/var_relative.c']
for name in names:
 src=w/'snapshot-45'/name;dst=out/name;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(src.read_bytes())
for name in ['bottom-values-v1/bottom-conversion-snapshot45.patch','native-relative-images-v1/relative-images-owner8.patch','native-tests-46.patch']:
 r=subprocess.run(['patch','--fuzz=0','-p1','-i',str(w/name)],cwd=out,text=True,capture_output=True);assert r.returncode==0,(r.stdout,r.stderr)
proof=json.loads((w/'c-only-bootstrap-46/report.json').read_text());pins={'selfhost/'+name:value for name,value in proof['source_sha256'].items()};pins.update(proof['asset_sha256'])
for name in ['native/tests/check.py','native/tests/var_relative.c','native/tests/bounded_cells.c']:pins[name]=hashlib.sha256((w/'snapshot-46'/name).read_bytes()).hexdigest()
for name,value in pins.items():assert hashlib.sha256((out/name).read_bytes()).hexdigest()==value,name
(w/'reproduction-46-final.json').write_text(json.dumps(dict(status='passed',method='Two sealed source patches and permanent bounded-cell test integration independently reproduce every qualified compiler/runtime input and unchanged native tests',verified_sha256=pins),indent=2)+'\n');print('reproduced',len(pins),'inputs')
