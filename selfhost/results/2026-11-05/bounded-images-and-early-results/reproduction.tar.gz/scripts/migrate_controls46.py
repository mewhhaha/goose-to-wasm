from pathlib import Path
import copy,hashlib,json,shutil
root=Path('/home/jacobt/src/goose-to-wasm');w=root/'build/completion-runs';path=root/'tests/conformance/cases.json';manifest=json.loads(path.read_text());before=copy.deepcopy(manifest['cases']);ids={c['id'] for c in before};added=[];sources={}
def retain(original,prefix):
 c=copy.deepcopy(original);source=root/c['source'];assert source.is_file(),source
 target=root/'tests/fixtures/contracts'/prefix/source.name;target.parent.mkdir(parents=True,exist_ok=True)
 if target.exists():assert target.read_bytes()==source.read_bytes(),target
 else:shutil.copyfile(source,target)
 name=target.relative_to(root).as_posix();sources[name]=hashlib.sha256(target.read_bytes()).hexdigest();c['source']=name;c['id']='corpus/contracts/'+prefix+'/'+c['id'];assert c['id'] not in ids,c['id'];ids.add(c['id']);added.append(c)
b=w/'bottom-values-v1'
for c in json.loads((b/'runtime-manifest.json').read_text())['cases']:retain(c,'early-results')
for entry in json.loads((b/'contracts.json').read_text()):
 for target in ['native','wasm-direct']:
  retain(dict(id=entry['case']+'/'+target,source=entry['source'],target=target,phase='check' if entry['expected_accept'] else 'type-error',levels=[0,2],provenance=entry['authority']),'early-results')
for c in json.loads((w/'native-relative-images-v1/qualified-contracts44-v6.json').read_text())['cases']:
 if not c['id'].startswith('upstream/'):retain(c,'bounded-images')
manifest['cases'].extend(added);assert manifest['cases'][:len(before)]==before;path.write_text(json.dumps(manifest,indent=2)+'\n');meta=dict(status='migrated; composed46 execution pending',cases=len(added),rows=sum(len(c['levels']) for c in added),sources=sources)
(w/'new-controls-46.json').write_text(json.dumps(meta,indent=2)+'\n');print('new46 cases',meta['cases'],'rows',meta['rows'],'files',len(sources),'total',sum(len(c['levels']) for c in manifest['cases']))
