#define _GNU_SOURCE 1
#include <stdint.h>
#include <inttypes.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <limits.h>
#include <setjmp.h>
#include <time.h>
#include <unistd.h>
#include <sys/stat.h>
#include <dirent.h>
#include <dlfcn.h>
#include <errno.h>
#include <pthread.h>
typedef uint64_t GRef;
#define G_MOVING_REF UINT64_C(0x8000000000000000)
#define G_OWNER_REF UINT64_C(0x4000000000000000)
#define G_REF_TAGS (G_MOVING_REF|G_OWNER_REF)
#define G_REF_OFFSET UINT64_C(0xffffffff)
typedef struct { GRef slot; uint32_t id; } GRootSlot;
static GRootSlot *g_root_slots;
static GRef *g_roots;
static uint32_t g_root_count, g_root_capacity;
typedef struct { GRef base; int64_t len; } GSlice;
typedef struct { unsigned char *data; int64_t len, cap; } GArray;
typedef struct GClosure { void *function; int64_t count; GRef captures[]; } GClosure;
typedef struct GAllocation { struct GAllocation *next; void *data; } GAllocation;
static GAllocation *g_allocations;
static int g_argc; static char **g_argv;
static void g_panic(const char *s) { fprintf(stderr,"goose runtime error: %s\n",s); exit(1); }
static void g_panic_at(const char *s,const char *file,int line) { fprintf(stderr,"goose runtime error: %s (%s:%d)\n",s,file,line);exit(1); }
static _Thread_local uintptr_t g_native_stack_low;
static void g_stack_check(void) {
    unsigned char here;
    if(!g_native_stack_low) {
        pthread_attr_t attributes;void *base;size_t bytes;
        if(pthread_getattr_np(pthread_self(),&attributes)) g_panic("cannot inspect native stack");
        int status=pthread_attr_getstack(&attributes,&base,&bytes);pthread_attr_destroy(&attributes);
        if(status) g_panic("cannot inspect native stack");g_native_stack_low=(uintptr_t)base;
    }
    if((uintptr_t)&here-g_native_stack_low<131072) g_panic("native call stack overflow");
}
static void g_index_fail(int64_t index,int64_t len,const char *file,int line) {
    fprintf(stderr,"goose runtime error: index %" PRId64 " out of bounds (length %" PRId64 ")",index,len);
    if(file)fprintf(stderr," (%s:%d)",file,line);fputc('\n',stderr);exit(1);
}
static void *g_alloc(size_t n) {
    void *p=calloc(1,n+!n); if(!p) g_panic("out of memory");
    GAllocation *a=malloc(sizeof *a); if(!a) g_panic("out of memory");
    a->data=p; a->next=g_allocations; g_allocations=a; return p;
}
static void g_cleanup(void) { while(g_allocations) { GAllocation *a=g_allocations; g_allocations=a->next; free(a->data); free(a); } }
/* Direct locations are ordinary addresses. A location in a growable owner
   encodes the owner-header ID plus its byte offset, so table growth does not
   allocate a reference object for each read and retained views follow growth. */
static uint64_t g_root_hash(GRef value) {
    value^=value>>33; value*=UINT64_C(0xff51afd7ed558ccd);
    value^=value>>33; value*=UINT64_C(0xc4ceb9fe1a85ec53); return value^(value>>33);
}
static void g_root_grow(void) {
    uint32_t capacity=g_root_capacity*2;
    if(!capacity) capacity=1024;
    if(capacity<g_root_capacity) g_panic("too many array owners");
    GRootSlot *slots=g_alloc((size_t)capacity*sizeof *slots);
    GRef *roots=g_alloc((size_t)capacity*sizeof *roots);
    if(g_root_count) memcpy(roots,g_roots,(size_t)(g_root_count+1)*sizeof *roots);
    for(uint32_t i=0;i<g_root_capacity;i++) {
        GRootSlot item=g_root_slots[i]; if(!item.slot)continue;
        uint32_t at=(uint32_t)g_root_hash(item.slot)&(capacity-1);
        while(slots[at].slot) at=(at+1)&(capacity-1);
        slots[at]=item;
    }
    g_root_slots=slots;g_roots=roots;g_root_capacity=capacity;
}
static uint32_t g_root_id(GRef slot) {
    if(!slot)g_panic("null array owner");
    if(!g_root_capacity)g_root_grow();
    uint32_t at=(uint32_t)g_root_hash(slot)&(g_root_capacity-1);
    while(g_root_slots[at].slot) {
        if(g_root_slots[at].slot==slot)return g_root_slots[at].id;
        at=(at+1)&(g_root_capacity-1);
    }
    if((uint64_t)(g_root_count+1)*2>=g_root_capacity) {
        g_root_grow();at=(uint32_t)g_root_hash(slot)&(g_root_capacity-1);
        while(g_root_slots[at].slot)at=(at+1)&(g_root_capacity-1);
    }
    if(g_root_count>=UINT32_C(0x3ffffffe))g_panic("too many array owners");
    uint32_t id=++g_root_count;g_roots[id]=slot;
    g_root_slots[at].slot=slot;g_root_slots[at].id=id;return id;
}
static GRef g_ref(void *p) {
    GRef value=(GRef)(uintptr_t)p;
    if(value&G_REF_TAGS)g_panic("native address exceeds reference representation");return value;
}
static unsigned char *g_address(GRef ref) {
    if(!ref)g_panic("null reference");
    if(!(ref&G_REF_TAGS))return (unsigned char *)(uintptr_t)ref;
    uint32_t id=(uint32_t)((ref&~G_REF_TAGS)>>32);
    if(!id || id>g_root_count)g_panic("invalid array owner reference");
    unsigned char *base=g_address(g_roots[id]);
    if(ref&G_MOVING_REF)memcpy(&base,base,sizeof base);
    uint64_t offset=ref&G_REF_OFFSET;
    if(!offset)return base;
    if(!base)g_panic("null reference");return base+offset;
}
static GRef g_offset(GRef ref,int64_t offset) {
    if(offset<0)g_panic("negative reference offset");
    if(ref&G_REF_TAGS) {
        uint64_t sum=(ref&G_REF_OFFSET)+(uint64_t)offset;
        if(sum>G_REF_OFFSET)g_panic("array reference offset exceeds addressable memory");
        return (ref&~G_REF_OFFSET)|sum;
    }
    if(!ref && offset)g_panic("null reference");return ref+(uint64_t)offset;
}
static GRef g_owner(GRef root) {
    if(!root)return 0;
    if((root&G_REF_TAGS)==G_OWNER_REF && !(root&G_REF_OFFSET))return root;
    return G_OWNER_REF|((uint64_t)g_root_id(root)<<32);
}
static GRef g_moving(GRef root,int64_t offset) {
    if(offset<0 || (uint64_t)offset>G_REF_OFFSET)g_panic("array reference offset exceeds addressable memory");
    uint64_t owner;
    if((root&G_REF_TAGS)==G_OWNER_REF && !(root&G_REF_OFFSET)) owner=root&~G_REF_TAGS;
    else owner=(uint64_t)g_root_id(root)<<32;
    return G_MOVING_REF|owner|(uint64_t)offset;
}
static uint64_t g_read_length(const void *p,int n) { uint64_t v=0; memcpy(&v,p,n); return v; }
static void g_write_length(void *p,int n,uint64_t v) { memcpy(p,&v,n); }
static int64_t g_len(GRef r,int kind,int64_t fixed,int prefix) {
    if(kind==5) { GSlice s; memcpy(&s,g_address(r),sizeof s); return s.len; }
    if(kind==0) return fixed;
    if(kind==2 && fixed>=0) return (int64_t)g_read_length(g_address(r),prefix);
    GArray a; memcpy(&a,g_address(r),sizeof a); return a.len;
}
static int64_t g_cap(GRef r,int kind,int64_t fixed) {
    if(kind==0) return fixed;
    if(kind==2 && fixed>=0) return fixed;
    GArray a; memcpy(&a,g_address(r),sizeof a); return a.cap;
}
static GRef g_element_at(GRef r,int kind,int64_t fixed,int prefix,int64_t width,int64_t index,int allow_end,const char *file,int line) {
    int64_t len=g_len(r,kind,fixed,prefix);
    if(index<0 || index>len || (!allow_end && index==len))g_index_fail(index,len,file,line);
    if(width && index>INT64_MAX/width) g_panic("array offset overflow");
    if(kind==5) { GSlice s; memcpy(&s,g_address(r),sizeof s); return g_offset(s.base,index*width); }
    if(kind==0) return g_offset(r,index*width);
    if(kind==2 && fixed>=0) return g_offset(r,prefix+index*width);
    return g_moving(r,index*width);
}
static GRef g_element(GRef r,int kind,int64_t fixed,int prefix,int64_t width,int64_t index,int allow_end) {
    return g_element_at(r,kind,fixed,prefix,width,index,allow_end,NULL,0);
}
static GSlice g_view(GRef r,int kind,int64_t fixed,int prefix,int64_t width) {
    GSlice s={g_element(r,kind,fixed,prefix,width,0,1),g_len(r,kind,fixed,prefix)}; return s;
}
static void g_reserve(GRef r,int kind,int64_t fixed,int prefix,int64_t width,int64_t count) {
    if(count<0 || (width && count>INT64_MAX/width)) g_panic("invalid capacity");
    if(kind==1 && prefix>0 && prefix<8 && (uint64_t)count>((UINT64_C(1)<<(prefix*8))-1)) g_panic("array length exceeds storage range");
    if(kind==2 && fixed>=0) { if(count>fixed) g_panic("limited array capacity exceeded"); return; }
    if(kind!=1 && kind!=3 && kind!=4 && kind!=2) g_panic("array cannot grow");
    GArray a; memcpy(&a,g_address(r),sizeof a);
    if(kind==2) {
        if(!a.data) { a.data=g_alloc((size_t)(count*width));a.cap=count;memcpy(g_address(r),&a,sizeof a);return; }
        if(count>a.cap) g_panic("limited array capacity exceeded");return;
    }
    if(count>a.cap) {
        int64_t cap=a.cap*2+8; if(cap<count) cap=count;
        if(width && cap>INT64_MAX/width) g_panic("array capacity overflow");
        unsigned char *data=g_alloc((size_t)(cap*width));
        if(a.len) memcpy(data,a.data,(size_t)(a.len*width)); a.data=data; a.cap=cap;
        memcpy(g_address(r),&a,sizeof a);
    }
}
static void g_set_len(GRef r,int kind,int64_t fixed,int prefix,int64_t count) {
    if(kind==2 && fixed>=0) g_write_length(g_address(r),prefix,(uint64_t)count);
    else { GArray a; memcpy(&a,g_address(r),sizeof a); a.len=count; memcpy(g_address(r),&a,sizeof a); }
}
static GRef g_push(GRef r,int kind,int64_t fixed,int prefix,int64_t width,const void *v) {
    int64_t n=g_len(r,kind,fixed,prefix); g_reserve(r,kind,fixed,prefix,width,n+1);
    g_set_len(r,kind,fixed,prefix,n+1); GRef dst=g_element(r,kind,fixed,prefix,width,n,0);
    memcpy(g_address(dst),v,(size_t)width); return dst;
}
static void g_append_bytes(GRef r,int kind,int64_t fixed,int prefix,const void *data,int64_t count) {
    int64_t old=g_len(r,kind,fixed,prefix);
    if(count<0 || count>INT64_MAX-old)g_panic("array length overflow");
    if(kind==2 && count>g_cap(r,kind,fixed)-old)g_panic("limited array capacity exceeded");
    g_reserve(r,kind,fixed,prefix,1,old+count);
    if(count)memmove(g_address(g_element(r,kind,fixed,prefix,1,old,1)),data,(size_t)count);
    g_set_len(r,kind,fixed,prefix,old+count);
}
static void g_bytes(GArray *out,const void *p,int64_t n) {
    if(n<=0) return; GRef r=g_ref(out); g_reserve(r,3,-1,0,1,out->len+n);
    memmove(out->data+out->len,p,(size_t)n); out->len+=n;
}
static GClosure *g_closure(void *function,int64_t n) { GClosure *c=g_alloc(sizeof *c+(size_t)n*sizeof(GRef)); c->function=function; c->count=n; return c; }
typedef struct GReturnFrame { struct GReturnFrame *parent; int64_t function; jmp_buf jump; void *result; size_t size; } GReturnFrame;
static _Thread_local GReturnFrame *g_return_top;
static void g_throw(int64_t function,const void *value,size_t size) {
    GReturnFrame *f=g_return_top;
    while(f && f->function!=function) f=f->parent;
    if(!f || f->size!=size) g_panic("nonlocal return target is not active");
    if(size) memcpy(f->result,value,size); g_return_top=f; longjmp(f->jump,1);
}
static int64_t g_div(int64_t a,int64_t b,const char *file,int line) { if(!b) g_panic_at("division by zero",file,line); if(a==INT64_MIN && b==-1) g_panic_at("integer overflow in division",file,line); return a/b; }
static int64_t g_mod(int64_t a,int64_t b,const char *file,int line) { if(!b) g_panic_at("division by zero",file,line); if(a==INT64_MIN && b==-1) return 0; int64_t r=a%b; if(r<0) { uint64_t magnitude=(uint64_t)b; if(b<0) magnitude=0-magnitude; return (int64_t)((uint64_t)r+magnitude); } return r; }
static uint64_t g_udiv(uint64_t a,uint64_t b,const char *file,int line) { if(!b) g_panic_at("division by zero",file,line); return a/b; }
static uint64_t g_umod(uint64_t a,uint64_t b,const char *file,int line) { if(!b) g_panic_at("division by zero",file,line); return a%b; }
static double g_mul_add(double x,double y,double z) { volatile double product=x*y;return product+z; }
static float g_mul_addf(float x,float y,float z) { volatile float product=x*y;return product+z; }
static int64_t g_find_any(GSlice s,GRef set) { const unsigned char *p=g_address(s.base),*members=g_address(set);for(int64_t i=0;i<s.len;i++) if(members[p[i]]) return i;return -1; }
static int64_t g_find_pair(GSlice s,GRef a,int64_t d,GRef b) { if(d<0 || d>=s.len) return -1;const unsigned char *p=g_address(s.base),*first=g_address(a),*second=g_address(b);for(int64_t i=0;i<s.len-d;i++) if(first[p[i]] && second[p[i+d]]) return i;return -1; }
static uint64_t g_float_wrap(double a) { if(a!=a)return 0;if(!isfinite(a)) g_panic("float conversion is not finite");int negative=a<0;double magnitude=fmod(trunc(fabs(a)),18446744073709551616.0);uint64_t bits;if(magnitude>=9223372036854775808.0) bits=((uint64_t)(magnitude-9223372036854775808.0))+(UINT64_C(1)<<63);else bits=(uint64_t)magnitude;if(negative) bits=0-bits;return bits; }
static void g_print_bytes(GArray *out,const void *p,int64_t n) { if(out) g_bytes(out,p,n); else if(n) fwrite(p,1,(size_t)n,stdout); }
static void g_print_text(GArray *out,const char *s) { g_print_bytes(out,s,(int64_t)strlen(s)); }
static char *g_path(GSlice p) { if(p.len<0 || p.len>=4096) return NULL; char *s=g_alloc((size_t)p.len+1); if(p.len) memcpy(s,g_address(p.base),(size_t)p.len); if(memchr(s,0,(size_t)p.len)) return NULL; return s; }
static int g_os_read_file(GSlice path,GRef out) { char *s=g_path(path); if(!s) return 0; FILE *f=fopen(s,"rb"); if(!f) return 0; GArray a; memcpy(&a,g_address(out),sizeof a); unsigned char b[16384]; size_t n; while((n=fread(b,1,sizeof b,f))) g_bytes(&a,b,(int64_t)n); int ok=!ferror(f); fclose(f); memcpy(g_address(out),&a,sizeof a); return ok; }
static int g_os_write_file(GSlice path,GSlice data,const char *mode) { char *s=g_path(path); if(!s) return 0; FILE *f=fopen(s,mode); if(!f) return 0; int ok=fwrite(g_address(data.base),1,(size_t)data.len,f)==(size_t)data.len; return fclose(f)==0 && ok; }
static int g_os_write_atomic(GSlice path,GSlice data) { char *s=g_path(path); if(!s) return 0; size_t n=strlen(s); char *tmp=g_alloc(n+16); memcpy(tmp,s,n); memcpy(tmp+n,".tmp-XXXXXX",12); int fd=mkstemp(tmp); if(fd<0) return 0; FILE *f=fdopen(fd,"wb"); if(!f) { close(fd); unlink(tmp); return 0; } int ok=fwrite(g_address(data.base),1,(size_t)data.len,f)==(size_t)data.len; if(fflush(f)||fsync(fd)) ok=0; if(fclose(f)) ok=0; if(ok && rename(tmp,s)) ok=0; if(!ok) unlink(tmp); return ok; }
static int g_os_kind(GSlice path) { char *s=g_path(path); struct stat st; if(!s || stat(s,&st)) return 0; if(S_ISDIR(st.st_mode)) return 2; return 1; }
static int g_os_line(GRef out) { GArray a; memcpy(&a,g_address(out),sizeof a); int c; int any=0; while((c=fgetc(stdin))!=EOF) { any=1; if(c==10) break; unsigned char b=(unsigned char)c; g_bytes(&a,&b,1); } if(a.len && a.data[a.len-1]==13) a.len--; memcpy(g_address(out),&a,sizeof a); return any; }
static void g_os_stdin(GRef out) { GArray a; memcpy(&a,g_address(out),sizeof a); unsigned char b[16384]; size_t n; while((n=fread(b,1,sizeof b,stdin))) g_bytes(&a,b,(int64_t)n); memcpy(g_address(out),&a,sizeof a); }
static void g_os_arg(int64_t i,GRef out) { if(i<0 || i>=g_argc) return; GArray a; memcpy(&a,g_address(out),sizeof a); g_bytes(&a,g_argv[i],(int64_t)strlen(g_argv[i])); memcpy(g_address(out),&a,sizeof a); }
static int g_os_env(GSlice name,GRef out) { char *n=g_path(name); const char *v=NULL; if(n) v=getenv(n); if(!v) return 0; GArray a; memcpy(&a,g_address(out),sizeof a); g_bytes(&a,v,(int64_t)strlen(v)); memcpy(g_address(out),&a,sizeof a); return 1; }
static int64_t g_os_time(int monotonic) { struct timespec t; clockid_t c=CLOCK_REALTIME; if(monotonic) c=CLOCK_MONOTONIC; if(clock_gettime(c,&t)) return 0; return (int64_t)t.tv_sec*1000000000+t.tv_nsec; }
static void g_os_sleep(int64_t ms) { if(ms<0) return; struct timespec t={ms/1000,(ms%1000)*1000000}; while(nanosleep(&t,&t) && errno==EINTR) {} }
static uint64_t g_os_random(void) { uint64_t n=0; FILE *f=fopen("/dev/urandom","rb"); if(f) { if(fread(&n,1,sizeof n,f)!=sizeof n) n=0; fclose(f); } if(!n) n=(uint64_t)g_os_time(0)^(uint64_t)(uintptr_t)&n; n^=n>>30; n*=UINT64_C(0xbf58476d1ce4e5b9); n^=n>>27; n*=UINT64_C(0x94d049bb133111eb); return n^(n>>31); }
static int g_sort_names(const void *a,const void *b) { return strcmp(*(const char *const *)a,*(const char *const *)b); }
static int g_os_list(GSlice path,GRef out) { char *s=g_path(path); if(!s) return 0; DIR *d=opendir(s); if(!d) return 0; char **names=NULL; size_t n=0,cap=0; struct dirent *e; while((e=readdir(d))) { if(!strcmp(e->d_name,".") || !strcmp(e->d_name,"..") || strchr(e->d_name,10)) continue; if(n==cap) { cap=cap*2+16; names=realloc(names,cap*sizeof *names); if(!names) g_panic("out of memory"); } names[n]=strdup(e->d_name); n++; } closedir(d); qsort(names,n,sizeof *names,g_sort_names); GArray a; memcpy(&a,g_address(out),sizeof a); for(size_t i=0;i<n;i++) { g_bytes(&a,names[i],(int64_t)strlen(names[i])); g_bytes(&a,"\n",1); free(names[i]); } free(names); memcpy(g_address(out),&a,sizeof a); return 1; }

#define GS_CHECKED_STACKS 0
static void g_format_bounds(void *p,uint64_t n) { (void)p; (void)n; }
static const char gs_digit_pairs[201] =
    "00010203040506070809101112131415161718192021222324252627282930313233343536373839"
    "40414243444546474849505152535455565758596061626364656667686970717273747576777879"
    "8081828384858687888990919293949596979899";

static int gs_fmt_digits(uint64_t v) {
    int n = 1;
    for (;;) {
        if (v < 10) return n;
        if (v < 100) return n + 1;
        if (v < 1000) return n + 2;
        if (v < 10000) return n + 3;
        v /= 10000;
        n += 4;
    }
}

static int64_t gs_fmt_u64(uint8_t *dst, uint64_t v) {
    int n = gs_fmt_digits(v);

    uint8_t *p = dst + n;
    while (v >= 100) {
        unsigned r = (unsigned)(v % 100);
        v /= 100;
        p -= 2;
        p[0] = (uint8_t)gs_digit_pairs[2 * r];
        p[1] = (uint8_t)gs_digit_pairs[2 * r + 1];
    }
    if (v >= 10) {
        p[-2] = (uint8_t)gs_digit_pairs[2 * v];
        p[-1] = (uint8_t)gs_digit_pairs[2 * v + 1];
    } else {
        p[-1] = (uint8_t)('0' + v);
    }
    return n;
}

static int64_t gs_fmt_i64(uint8_t *dst, int64_t v) {
    if (v >= 0) return gs_fmt_u64(dst, (uint64_t)v);
    /* The magnitude in unsigned arithmetic, so i64.min needs no case. */

    dst[0] = '-';
    return 1 + gs_fmt_u64(dst + 1, 0 - (uint64_t)v);
}

/* A float's text is the fewest significant digits that read back as the
   same value of its own type and, of those, the ones nearest it, a tie going
   to the even digit (as Python's repr and Ryu choose). They are found in
   integers, by Burger and Dybvig's free-format algorithm, not through the C
   library: msvcrt, which tcc uses on Windows, rounds a printf tie away from
   zero, and below a power of two the gap to the next float is half the gap
   above, so the shortest text can lie above the value while the correctly
   rounded spelling of that length, below it, does not read back.

   The numbers are naturals in 32-bit limbs, least significant first. The
   denominator s stays below 2^1079 (ten times 2^1075, for the smallest
   doubles), and the others below eleven times s. */
typedef struct { int n; uint32_t d[36]; } gs_big;

/* a = v << sh, for v > 0. */
static void gs_big_set(gs_big *a, uint64_t v, int sh) {
    int w = sh >> 5, b = sh & 31, i;
    uint64_t lo = v << b, hi = b ? v >> (64 - b) : 0;
    for (i = 0; i < w; i++) a->d[i] = 0;
    a->d[w] = (uint32_t)lo;
    a->d[w + 1] = (uint32_t)(lo >> 32);
    a->d[w + 2] = (uint32_t)hi;
    a->n = w + 3;
    while (!a->d[a->n - 1]) a->n--;
}

static void gs_big_mul(gs_big *a, uint32_t m) {
    uint64_t c = 0;
    for (int i = 0; i < a->n; i++) {
        c += (uint64_t)a->d[i] * m;
        a->d[i] = (uint32_t)c;
        c >>= 32;
    }
    if (c) a->d[a->n++] = (uint32_t)c;
}

static void gs_big_mul_pow10(gs_big *a, int k) {
    for (; k >= 9; k -= 9) gs_big_mul(a, 1000000000u);
    for (; k > 0; k--) gs_big_mul(a, 10);
}

static int gs_big_cmp(const gs_big *a, const gs_big *b) {
    if (a->n != b->n) return a->n < b->n ? -1 : 1;
    for (int i = a->n - 1; i >= 0; i--)
        if (a->d[i] != b->d[i]) return a->d[i] < b->d[i] ? -1 : 1;
    return 0;
}

/* t = a + b */
static void gs_big_add(gs_big *t, const gs_big *a, const gs_big *b) {
    int n = a->n > b->n ? a->n : b->n;
    uint64_t c = 0;
    for (int i = 0; i < n; i++) {
        c += (uint64_t)(i < a->n ? a->d[i] : 0) + (i < b->n ? b->d[i] : 0);
        t->d[i] = (uint32_t)c;
        c >>= 32;
    }
    t->n = n;
    if (c) t->d[t->n++] = (uint32_t)c;
}

/* a -= b, for a >= b. */
static void gs_big_sub(gs_big *a, const gs_big *b) {
    uint64_t borrow = 0;
    for (int i = 0; i < a->n; i++) {
        uint64_t x = (uint64_t)a->d[i] - (i < b->n ? b->d[i] : 0) - borrow;
        a->d[i] = (uint32_t)x;
        borrow = x >> 63;
    }
    while (a->n && !a->d[a->n - 1]) a->n--;
}

/* The shortest digits of f * 2^e (f > 0) as a float of `bits` significant
   bits and least exponent emin, into dig; returns their count and sets *k
   so that the value they spell is 0.d1d2... * 10^*k. */
static int gs_float_digits(uint64_t f, int e, int bits, int emin, char *dig, int *k) {
    gs_big r, s, mp, mlo, t;
    /* Reading rounds a tie to the even significand, so the interval that
       reads back as f * 2^e includes its ends when f is even. */
    int even = !(f & 1);
    /* Below a power of two, the gap to the next float down is half the gap up. */
    int asym = f == (uint64_t)1 << (bits - 1) && e > emin;
    int up = e > 0 ? e : 0, lg = e - 1, n = 0, c;
    /* The value is r / s, and what reads back as it reaches from (r - *mm) / s
       to (r + mp) / s: half the gap to each neighbour. */
    gs_big *mm = asym ? &mlo : &mp;
    gs_big_set(&r, f, up + 1 + asym);
    gs_big_set(&s, 1, up - e + 1 + asym);
    gs_big_set(&mp, 1, up + asym);
    gs_big_set(&mlo, 1, up);
    /* Scale to 10^*k, the least power of ten above the interval: with
       lg = floor(log2 value), ceil(lg log10 2) is it or one short, and
       78913 / 2^18 is log10 2 closely enough to compute that for |lg| < 1650. */
    for (uint64_t g = f; g; g >>= 1) lg++;
    *k = lg > 0 ? ((lg * 78913) >> 18) + 1 : -((-lg * 78913) >> 18);
    if (*k >= 0) gs_big_mul_pow10(&s, *k);
    else {
        gs_big_mul_pow10(&r, -*k);
        gs_big_mul_pow10(&mp, -*k);
        if (asym) gs_big_mul_pow10(&mlo, -*k);
    }
    gs_big_add(&t, &r, &mp);
    c = gs_big_cmp(&t, &s);
    if (even ? c >= 0 : c > 0) {
        gs_big_mul(&s, 10);
        ++*k;
    }
    /* Each digit d leaves the remainder r: stop where the digits so far
       followed by d (r within *mm) or by d + 1 (r + mp past s) read back. */
    for (;;) {
        int d = 0, low, high;
        gs_big_mul(&r, 10);
        gs_big_mul(&mp, 10);
        if (asym) gs_big_mul(&mlo, 10);
        while (gs_big_cmp(&r, &s) >= 0) {
            gs_big_sub(&r, &s);
            d++;
        }
        c = gs_big_cmp(&r, mm);
        low = even ? c <= 0 : c < 0;
        gs_big_add(&t, &r, &mp);
        c = gs_big_cmp(&t, &s);
        high = even ? c >= 0 : c > 0;
        if (!low && !high) {
            dig[n++] = (char)('0' + d);
            continue;
        }
        if (low && high) {
            /* Both read back: the nearer, d + 1 when r is past half of s,
               and of two as near, the even one. */
            gs_big_add(&t, &r, &r);
            c = gs_big_cmp(&t, &s);
            high = c > 0 || (c == 0 && (d & 1));
        }
        dig[n++] = (char)('0' + d + high);
        return n;
    }
}

/* The text of a finite float from its fields: the sign, the significand
   without its implicit bit and the biased exponent, for a type of `bits`
   significant bits and least exponent emin. The digits are laid out as C's
   %g lays them out at a precision of max(15, digits): in exponent form, with
   at least two exponent digits, below 1e-4 or from that power of ten up. */
static int64_t gs_fmt_float_unchecked(uint8_t *dst, int neg, uint64_t frac, int bexp, int bits,
                            int emin) {
    char dig[20], *p = (char *)dst;
    int k, n, x, i;
    if (neg) *p++ = '-';
    if (!frac && !bexp) {
        memcpy(p, "0.0", 3);
        return p + 3 - (char *)dst;
    }
    n = gs_float_digits(bexp ? frac | (uint64_t)1 << (bits - 1) : frac,
                        (bexp ? bexp - 1 : 0) + emin, bits, emin, dig, &k);
    x = k - 1;
    if (x < -4 || x >= (n > 15 ? n : 15)) {
        *p++ = dig[0];
        if (n > 1) *p++ = '.';
        for (i = 1; i < n; i++) *p++ = dig[i];
        *p++ = 'e';
        *p++ = x < 0 ? '-' : '+';
        if (x < 0) x = -x;
        if (x >= 100) *p++ = (char)('0' + x / 100);
        *p++ = (char)('0' + x / 10 % 10);
        *p++ = (char)('0' + x % 10);
    } else if (x < 0) {
        *p++ = '0';
        *p++ = '.';
        for (i = -1; i > x; i--) *p++ = '0';
        for (i = 0; i < n; i++) *p++ = dig[i];
    } else {
        for (i = 0; i < n || i <= x; i++) {
            if (i == x + 1) *p++ = '.';
            *p++ = i < n ? dig[i] : '0';
        }
        /* A whole number still reads as a float: 1.0, not 1. */
        if (n <= x + 1) {
            *p++ = '.';
            *p++ = '0';
        }
    }
    return p - (char *)dst;
}

static int64_t gs_fmt_float(uint8_t *dst, int neg, uint64_t frac, int bexp, int bits,
                            int emin) {
#if GS_CHECKED_STACKS
    /* Determine the exact length before touching a data stack. The longest
       f64 spelling fits in 32 bytes, including sign and three exponent digits. */
    uint8_t text[32];
    int64_t n = gs_fmt_float_unchecked(text, neg, frac, bexp, bits, emin);

    memcpy(dst, text, (size_t)n);
    return n;
#else
    return gs_fmt_float_unchecked(dst, neg, frac, bexp, bits, emin);
#endif
}

static int64_t gs_fmt_f64(uint8_t *dst, double v) {
    uint64_t b;
    /* C libraries disagree here (msvcrt, which tcc uses on Windows, writes
       1.#INF and -1.#IND; others give a NaN's sign bit, which depends on
       the CPU that made it), so these are spelled by the runtime. */
    if (v != v) { g_format_bounds(dst, 3); memcpy(dst, "nan", 3); return 3; }
    if (isinf(v)) {
        if (v > 0) { g_format_bounds(dst, 3); memcpy(dst, "inf", 3); return 3; }
        g_format_bounds(dst, 4);
        memcpy(dst, "-inf", 4);
        return 4;
    }
    memcpy(&b, &v, sizeof b);
    return gs_fmt_float(dst, (int)(b >> 63), b & (((uint64_t)1 << 52) - 1),
                        (int)(b >> 52) & 0x7FF, 53, -1074);
}

/* The digits are the f32's own, laid out as an f64's are, so 0.1 as an f32
   prints as 0.1, not as the digits of the f64 it widens to. */
static int64_t gs_fmt_f32(uint8_t *dst, float v) {
    double d = v;
    uint32_t b;
    if (d != d || isinf(d)) return gs_fmt_f64(dst, d);
    memcpy(&b, &v, sizeof b);
    return gs_fmt_float(dst, (int)(b >> 31), b & 0x7FFFFF, (int)(b >> 23) & 0xFF, 24, -149);
}

static int64_t gs_fmt_bool(uint8_t *dst, int64_t v) {

    memcpy(dst, v ? "true" : "false", v ? 4 : 5);
    return v ? 4 : 5;
}

static int64_t gs_fmt_quoted(uint8_t *dst, const uint8_t *s, int64_t n) {
#if GS_CHECKED_STACKS
    uint64_t size = 2;
    for (int64_t i = 0; i < n; i++) {
        uint8_t c = s[i];
        uint64_t part = 1;
        if (c == '"' || c == '\\' || c == '\n' || c == '\r' || c == '\t') part++;
        if (size > UINT64_MAX - part) gs_panic("data stack overflow: quoted text size");
        size += part;
    }
    g_format_bounds(dst, size);
#endif
    uint8_t *d = dst;
    *d++ = '"';
    for (int64_t i = 0; i < n; i++) {
        uint8_t c = s[i];
        switch (c) {
            case '"': *d++ = '\\'; *d++ = '"'; break;
            case '\\': *d++ = '\\'; *d++ = '\\'; break;
            case '\n': *d++ = '\\'; *d++ = 'n'; break;
            case '\r': *d++ = '\\'; *d++ = 'r'; break;
            case '\t': *d++ = '\\'; *d++ = 't'; break;
            default: *d++ = c; break;
        }
    }
    *d++ = '"';
    return (int64_t)(d - dst);
}
static void g_debug_fail(const char *file,int line,const char *format,...) {
    fputs("goose runtime error: ",stderr); va_list args;va_start(args,format);
    vfprintf(stderr,format,args);va_end(args);fprintf(stderr," (%s:%d)\n",file,line);exit(1);
}
static void g_abort_value(GArray message,const char *file,int line) {
    fputs("goose runtime error: ",stderr);
    if(message.len)fwrite(message.data,1,(size_t)message.len,stderr);
    fprintf(stderr," (%s:%d)\n",file,line);exit(1);
}
static __int128 g_signed_min(int bits) { return -((__int128)1<<(bits-1)); }
static __int128 g_signed_max(int bits) { return ((__int128)1<<(bits-1))-1; }
static int64_t g_checked_binary(int64_t a,int64_t b,int bits,int op,const char *file,int line) {
    __int128 r=0;const char *text="?";
    if(op==21){r=(__int128)a+b;text="+";}
    else if(op==22){r=(__int128)a-b;text="-";}
    else if(op==23){r=(__int128)a*b;text="*";}
    else if(op==24){if(!b)g_debug_fail(file,line,"division by zero");if(a==INT64_MIN&&b==-1)g_debug_fail(file,line,"integer overflow in division");r=a/b;text="/";}
    if(r<g_signed_min(bits)||r>g_signed_max(bits))g_debug_fail(file,line,"integer overflow (debug): %" PRId64 " %s %" PRId64 " at i%d",a,text,b,bits);
    return (int64_t)r;
}
static int64_t g_checked_neg(int64_t a,int bits,const char *file,int line) {
    __int128 r=-(__int128)a;
    if(r<g_signed_min(bits)||r>g_signed_max(bits))g_debug_fail(file,line,"integer overflow (debug): -(%" PRId64 ") at i%d",a,bits);
    return (int64_t)r;
}
static uint64_t g_unsigned_max(int bits) { if(bits==64)return UINT64_MAX;return (UINT64_C(1)<<bits)-1; }
static uint64_t g_checked_cast_i(int64_t v,int bits,int uns,const char *file,int line) {
    int bad=0;if(uns){if(v<0||(uint64_t)v>g_unsigned_max(bits))bad=1;}
    else if((__int128)v<g_signed_min(bits)||(__int128)v>g_signed_max(bits))bad=1;
    if(bad){char kind='i';if(uns)kind='u';g_debug_fail(file,line,"as conversion out of range (debug): %" PRId64 " as %c%d",v,kind,bits);}
    return (uint64_t)v;
}
static uint64_t g_checked_cast_u(uint64_t v,int bits,int uns,const char *file,int line) {
    uint64_t hi=g_unsigned_max(bits);if(!uns)hi=(uint64_t)g_signed_max(bits);
    if(v>hi){char kind='i';if(uns)kind='u';g_debug_fail(file,line,"as conversion out of range (debug): %" PRIu64 " as %c%d",v,kind,bits);}
    return v;
}
static void g_cast_float_fail(const char *why,double v,int f32,int bits,int uns,const char *file,int line) {
    uint8_t text[64];int64_t count;char kind='i';if(uns)kind='u';
    if(f32)count=gs_fmt_f32(text,(float)v);else count=gs_fmt_f64(text,v);text[count]=0;
    g_debug_fail(file,line,"as conversion %s (debug): %s as %c%d",why,(char*)text,kind,bits);
}
static uint64_t g_checked_cast_f(double v,int f32,int bits,int uns,const char *file,int line) {
    if(uns&&bits==64){
        if(!(v>=0&&v<18446744073709551616.0))g_cast_float_fail("out of range",v,f32,bits,uns,file,line);
        uint64_t value=(uint64_t)v;
        if((double)value!=v)g_cast_float_fail("changes the value",v,f32,bits,uns,file,line);
        return value;
    }
    if(!(v>=-9223372036854775808.0&&v<9223372036854775808.0))g_cast_float_fail("out of range",v,f32,bits,uns,file,line);
    int64_t value=(int64_t)v;int bad=0;
    if(uns){if(value<0||(uint64_t)value>g_unsigned_max(bits))bad=1;}
    else if((__int128)value<g_signed_min(bits)||(__int128)value>g_signed_max(bits))bad=1;
    if(bad)g_cast_float_fail("out of range",v,f32,bits,uns,file,line);
    if((double)value!=v)g_cast_float_fail("changes the value",v,f32,bits,uns,file,line);
    return (uint64_t)value;
}
static unsigned char *g_nullable_address(GRef r) { if(!r)return NULL;return g_address(r); }
static double g_float_literal(uint64_t bits) { double v; memcpy(&v,&bits,sizeof v); return v; }
static int64_t g_clz(uint64_t x) { if(!x) return 64; return __builtin_clzll(x); }
static int64_t g_ctz(uint64_t x) { if(!x) return 64; return __builtin_ctzll(x); }
static int g_os_path_op(GSlice path,int op) { char *s=g_path(path); if(!s) return 0; if(op==0) return unlink(s)==0; if(op==1) return rmdir(s)==0; if(mkdir(s,0777)==0) return 1; return errno==EEXIST && g_os_kind(path)==2; }
static int g_os_rename(GSlice from,GSlice to) { char *a=g_path(from),*b=g_path(to); if(!a || !b) return 0; return rename(a,b)==0; }
static int g_os_resource(GRef out) { char path[4096]; ssize_t n=readlink("/proc/self/exe",path,sizeof path); if(n<=0 || n==(ssize_t)sizeof path) return 0; while(n>0 && path[n-1]!='/') n--; if(!n) return 0; GArray a; memcpy(&a,g_address(out),sizeof a); g_bytes(&a,path,n); memcpy(g_address(out),&a,sizeof a); return 1; }
static int g_trim_memory(void) { void *p=dlsym(RTLD_DEFAULT,"malloc_trim"); if(!p) return 0; return ((int (*)(size_t))p)(0); }
typedef struct { void *data; int64_t len; } GForeignSlice;
static GForeignSlice g_foreign_slice(GSlice s) { GForeignSlice r={g_address(s.base),s.len}; return r; }
static void *g_external(const char *library,const char *name) { void *handle=RTLD_DEFAULT; if(library) { handle=dlopen(library,RTLD_NOW|RTLD_LOCAL); if(!handle) g_panic(dlerror()); } void *p=dlsym(handle,name); if(!p) g_panic(dlerror()); return p; }static void g_initialize(void); static int g_initialized;
typedef void g_t0;
typedef uint8_t g_t1;
typedef int8_t g_t2;
typedef int16_t g_t3;
typedef int32_t g_t4;
typedef int64_t g_t5;
typedef uint8_t g_t6;
typedef uint16_t g_t7;
typedef uint32_t g_t8;
typedef uint64_t g_t9;
typedef float g_t10;
typedef double g_t11;
typedef GSlice g_t12;
typedef struct { unsigned char data[32]; } g_t13;
typedef struct { unsigned char data[24]; } g_t16;
typedef GClosure* g_t17;
typedef GClosure* g_t18;
typedef GClosure* g_t19;
typedef GClosure* g_t20;
typedef GClosure* g_t21;
typedef GClosure* g_t22;
typedef GClosure* g_t23;
typedef struct { unsigned char data[24]; } g_t24;
typedef struct { unsigned char data[184]; } g_t369;
typedef GRef g_t370;
typedef struct { unsigned char data[24]; } g_t375;
static g_t1 g_clone_1(g_t1 v);
static int g_equal_1(g_t1 a,g_t1 b);
static void g_print_1(GArray *out,g_t1 v);
static void g_nested_1(GArray *out,g_t1 v);
static g_t1 g_load_1(GRef p) {g_t1 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_1(GRef p,g_t1 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t2 g_clone_2(g_t2 v);
static int g_equal_2(g_t2 a,g_t2 b);
static void g_print_2(GArray *out,g_t2 v);
static void g_nested_2(GArray *out,g_t2 v);
static g_t2 g_load_2(GRef p) {g_t2 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_2(GRef p,g_t2 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t3 g_clone_3(g_t3 v);
static int g_equal_3(g_t3 a,g_t3 b);
static void g_print_3(GArray *out,g_t3 v);
static void g_nested_3(GArray *out,g_t3 v);
static g_t3 g_load_3(GRef p) {g_t3 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_3(GRef p,g_t3 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t4 g_clone_4(g_t4 v);
static int g_equal_4(g_t4 a,g_t4 b);
static void g_print_4(GArray *out,g_t4 v);
static void g_nested_4(GArray *out,g_t4 v);
static g_t4 g_load_4(GRef p) {g_t4 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_4(GRef p,g_t4 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t5 g_clone_5(g_t5 v);
static int g_equal_5(g_t5 a,g_t5 b);
static void g_print_5(GArray *out,g_t5 v);
static void g_nested_5(GArray *out,g_t5 v);
static g_t5 g_load_5(GRef p) {g_t5 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_5(GRef p,g_t5 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t6 g_clone_6(g_t6 v);
static int g_equal_6(g_t6 a,g_t6 b);
static void g_print_6(GArray *out,g_t6 v);
static void g_nested_6(GArray *out,g_t6 v);
static g_t6 g_load_6(GRef p) {g_t6 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_6(GRef p,g_t6 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t7 g_clone_7(g_t7 v);
static int g_equal_7(g_t7 a,g_t7 b);
static void g_print_7(GArray *out,g_t7 v);
static void g_nested_7(GArray *out,g_t7 v);
static g_t7 g_load_7(GRef p) {g_t7 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_7(GRef p,g_t7 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t8 g_clone_8(g_t8 v);
static int g_equal_8(g_t8 a,g_t8 b);
static void g_print_8(GArray *out,g_t8 v);
static void g_nested_8(GArray *out,g_t8 v);
static g_t8 g_load_8(GRef p) {g_t8 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_8(GRef p,g_t8 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t9 g_clone_9(g_t9 v);
static int g_equal_9(g_t9 a,g_t9 b);
static void g_print_9(GArray *out,g_t9 v);
static void g_nested_9(GArray *out,g_t9 v);
static g_t9 g_load_9(GRef p) {g_t9 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_9(GRef p,g_t9 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t10 g_clone_10(g_t10 v);
static int g_equal_10(g_t10 a,g_t10 b);
static void g_print_10(GArray *out,g_t10 v);
static void g_nested_10(GArray *out,g_t10 v);
static g_t10 g_load_10(GRef p) {g_t10 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_10(GRef p,g_t10 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t11 g_clone_11(g_t11 v);
static int g_equal_11(g_t11 a,g_t11 b);
static void g_print_11(GArray *out,g_t11 v);
static void g_nested_11(GArray *out,g_t11 v);
static g_t11 g_load_11(GRef p) {g_t11 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_11(GRef p,g_t11 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t12 g_clone_12(g_t12 v);
static int g_equal_12(g_t12 a,g_t12 b);
static void g_print_12(GArray *out,g_t12 v);
static void g_nested_12(GArray *out,g_t12 v);
static g_t12 g_load_12(GRef p) {g_t12 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_12(GRef p,g_t12 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t13 g_clone_13(g_t13 v);
static int g_equal_13(g_t13 a,g_t13 b);
static void g_print_13(GArray *out,g_t13 v);
static void g_nested_13(GArray *out,g_t13 v);
static g_t13 g_load_13(GRef p) {g_t13 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_13(GRef p,g_t13 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t16 g_clone_16(g_t16 v);
static int g_equal_16(g_t16 a,g_t16 b);
static void g_print_16(GArray *out,g_t16 v);
static void g_nested_16(GArray *out,g_t16 v);
static g_t16 g_load_16(GRef p) {g_t16 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_16(GRef p,g_t16 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t17 g_clone_17(g_t17 v);
static int g_equal_17(g_t17 a,g_t17 b);
static void g_print_17(GArray *out,g_t17 v);
static void g_nested_17(GArray *out,g_t17 v);
static g_t17 g_load_17(GRef p) {g_t17 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_17(GRef p,g_t17 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t18 g_clone_18(g_t18 v);
static int g_equal_18(g_t18 a,g_t18 b);
static void g_print_18(GArray *out,g_t18 v);
static void g_nested_18(GArray *out,g_t18 v);
static g_t18 g_load_18(GRef p) {g_t18 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_18(GRef p,g_t18 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t19 g_clone_19(g_t19 v);
static int g_equal_19(g_t19 a,g_t19 b);
static void g_print_19(GArray *out,g_t19 v);
static void g_nested_19(GArray *out,g_t19 v);
static g_t19 g_load_19(GRef p) {g_t19 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_19(GRef p,g_t19 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t20 g_clone_20(g_t20 v);
static int g_equal_20(g_t20 a,g_t20 b);
static void g_print_20(GArray *out,g_t20 v);
static void g_nested_20(GArray *out,g_t20 v);
static g_t20 g_load_20(GRef p) {g_t20 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_20(GRef p,g_t20 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t21 g_clone_21(g_t21 v);
static int g_equal_21(g_t21 a,g_t21 b);
static void g_print_21(GArray *out,g_t21 v);
static void g_nested_21(GArray *out,g_t21 v);
static g_t21 g_load_21(GRef p) {g_t21 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_21(GRef p,g_t21 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t22 g_clone_22(g_t22 v);
static int g_equal_22(g_t22 a,g_t22 b);
static void g_print_22(GArray *out,g_t22 v);
static void g_nested_22(GArray *out,g_t22 v);
static g_t22 g_load_22(GRef p) {g_t22 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_22(GRef p,g_t22 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t23 g_clone_23(g_t23 v);
static int g_equal_23(g_t23 a,g_t23 b);
static void g_print_23(GArray *out,g_t23 v);
static void g_nested_23(GArray *out,g_t23 v);
static g_t23 g_load_23(GRef p) {g_t23 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_23(GRef p,g_t23 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t24 g_clone_24(g_t24 v);
static int g_equal_24(g_t24 a,g_t24 b);
static void g_print_24(GArray *out,g_t24 v);
static void g_nested_24(GArray *out,g_t24 v);
static g_t24 g_load_24(GRef p) {g_t24 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_24(GRef p,g_t24 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t369 g_clone_369(g_t369 v);
static int g_equal_369(g_t369 a,g_t369 b);
static void g_print_369(GArray *out,g_t369 v);
static void g_nested_369(GArray *out,g_t369 v);
static g_t369 g_load_369(GRef p) {g_t369 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_369(GRef p,g_t369 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t370 g_clone_370(g_t370 v);
static int g_equal_370(g_t370 a,g_t370 b);
static void g_print_370(GArray *out,g_t370 v);
static void g_nested_370(GArray *out,g_t370 v);
static g_t370 g_load_370(GRef p) {g_t370 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_370(GRef p,g_t370 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t375 g_clone_375(g_t375 v);
static int g_equal_375(g_t375 a,g_t375 b);
static void g_print_375(GArray *out,g_t375 v);
static void g_nested_375(GArray *out,g_t375 v);
static g_t375 g_load_375(GRef p) {g_t375 v; memcpy(&v,g_address(p),sizeof v); return v;}
static void g_store_375(GRef p,g_t375 v) { memcpy(g_address(p),&v,sizeof v); }
static g_t1 g_clone_1(g_t1 v) {
return v;}
static int g_equal_1(g_t1 a,g_t1 b){
return a==b;
}
static void g_print_1(GArray *out,g_t1 v) {
g_stack_check();
unsigned char b[128]; int64_t n=gs_fmt_bool(b,v);g_print_bytes(out,b,n);
}
static void g_nested_1(GArray *out,g_t1 v){
g_print_1(out,v);
}
static g_t2 g_clone_2(g_t2 v) {
return v;}
static int g_equal_2(g_t2 a,g_t2 b){
return a==b;
}
static void g_print_2(GArray *out,g_t2 v) {
g_stack_check();
unsigned char b[128]; int64_t n=gs_fmt_i64(b,v);g_print_bytes(out,b,n);
}
static void g_nested_2(GArray *out,g_t2 v){
g_print_2(out,v);
}
static g_t3 g_clone_3(g_t3 v) {
return v;}
static int g_equal_3(g_t3 a,g_t3 b){
return a==b;
}
static void g_print_3(GArray *out,g_t3 v) {
g_stack_check();
unsigned char b[128]; int64_t n=gs_fmt_i64(b,v);g_print_bytes(out,b,n);
}
static void g_nested_3(GArray *out,g_t3 v){
g_print_3(out,v);
}
static g_t4 g_clone_4(g_t4 v) {
return v;}
static int g_equal_4(g_t4 a,g_t4 b){
return a==b;
}
static void g_print_4(GArray *out,g_t4 v) {
g_stack_check();
unsigned char b[128]; int64_t n=gs_fmt_i64(b,v);g_print_bytes(out,b,n);
}
static void g_nested_4(GArray *out,g_t4 v){
g_print_4(out,v);
}
static g_t5 g_clone_5(g_t5 v) {
return v;}
static int g_equal_5(g_t5 a,g_t5 b){
return a==b;
}
static void g_print_5(GArray *out,g_t5 v) {
g_stack_check();
unsigned char b[128]; int64_t n=gs_fmt_i64(b,v);g_print_bytes(out,b,n);
}
static void g_nested_5(GArray *out,g_t5 v){
g_print_5(out,v);
}
static g_t6 g_clone_6(g_t6 v) {
return v;}
static int g_equal_6(g_t6 a,g_t6 b){
return a==b;
}
static void g_print_6(GArray *out,g_t6 v) {
g_stack_check();
unsigned char b[128]; int64_t n=gs_fmt_u64(b,v);g_print_bytes(out,b,n);
}
static void g_nested_6(GArray *out,g_t6 v){
g_print_6(out,v);
}
static g_t7 g_clone_7(g_t7 v) {
return v;}
static int g_equal_7(g_t7 a,g_t7 b){
return a==b;
}
static void g_print_7(GArray *out,g_t7 v) {
g_stack_check();
unsigned char b[128]; int64_t n=gs_fmt_u64(b,v);g_print_bytes(out,b,n);
}
static void g_nested_7(GArray *out,g_t7 v){
g_print_7(out,v);
}
static g_t8 g_clone_8(g_t8 v) {
return v;}
static int g_equal_8(g_t8 a,g_t8 b){
return a==b;
}
static void g_print_8(GArray *out,g_t8 v) {
g_stack_check();
unsigned char b[128]; int64_t n=gs_fmt_u64(b,v);g_print_bytes(out,b,n);
}
static void g_nested_8(GArray *out,g_t8 v){
g_print_8(out,v);
}
static g_t9 g_clone_9(g_t9 v) {
return v;}
static int g_equal_9(g_t9 a,g_t9 b){
return a==b;
}
static void g_print_9(GArray *out,g_t9 v) {
g_stack_check();
unsigned char b[128]; int64_t n=gs_fmt_u64(b,v);g_print_bytes(out,b,n);
}
static void g_nested_9(GArray *out,g_t9 v){
g_print_9(out,v);
}
static g_t10 g_clone_10(g_t10 v) {
return v;}
static int g_equal_10(g_t10 a,g_t10 b){
return a==b;
}
static void g_print_10(GArray *out,g_t10 v) {
g_stack_check();
unsigned char b[128]; int64_t n=gs_fmt_f32(b,v);g_print_bytes(out,b,n);
}
static void g_nested_10(GArray *out,g_t10 v){
g_print_10(out,v);
}
static g_t11 g_clone_11(g_t11 v) {
return v;}
static int g_equal_11(g_t11 a,g_t11 b){
return a==b;
}
static void g_print_11(GArray *out,g_t11 v) {
g_stack_check();
unsigned char b[128]; int64_t n=gs_fmt_f64(b,v);g_print_bytes(out,b,n);
}
static void g_nested_11(GArray *out,g_t11 v){
g_print_11(out,v);
}
static g_t12 g_clone_12(g_t12 v) {
return v;}
static int g_equal_12(g_t12 a,g_t12 b){
GRef ar=g_ref(&a),br=g_ref(&b);int64_t n=g_len(ar,5,-1,0);if(n!=g_len(br,5,-1,0))return 0;
for(int64_t i=0;i<n;i++){if(!g_equal_6(g_load_6(g_element(ar,5,-1,0,1,i,0)),g_load_6(g_element(br,5,-1,0,1,i,0))))return 0;}return 1;
}
static void g_print_12(GArray *out,g_t12 v) {
g_stack_check();
GRef r=g_ref(&v); int64_t n=g_len(r,5,-1,0);
for(int64_t i=0;i<n;i++) {
g_print_bytes(out,g_address(g_element(r,5,-1,0,1,i,0)),1);
}
}
static void g_nested_12(GArray *out,g_t12 v){
GRef r=g_ref(&v);int64_t n=g_len(r,5,-1,0);if(n<0 || (uint64_t)n>(SIZE_MAX-2)/2)g_panic("text size overflow");unsigned char *b=g_alloc((size_t)n*2+2);int64_t written=gs_fmt_quoted(b,g_address(g_element(r,5,-1,0,1,0,1)),n);g_print_bytes(out,b,written);
}
static g_t13 g_clone_13(g_t13 v) {
g_store_16(g_offset(g_ref(&v),8),g_clone_16(g_load_16(g_offset(g_ref(&v),8))));
return v;}
static int g_equal_13(g_t13 a,g_t13 b){
if(!g_equal_5(g_load_5(g_offset(g_ref(&a),0)),g_load_5(g_offset(g_ref(&b),0))))return 0;
if(!g_equal_16(g_load_16(g_offset(g_ref(&a),8)),g_load_16(g_offset(g_ref(&b),8))))return 0;
return 1;
}
static void g_print_13(GArray *out,g_t13 v) {
g_stack_check();
g_print_text(out,"\102\141\147");g_print_text(out," { ");
g_nested_5(out,g_load_5(g_offset(g_ref(&v),0)));
g_print_text(out,", ");
g_nested_16(out,g_load_16(g_offset(g_ref(&v),8)));
g_print_text(out," }");
}
static void g_nested_13(GArray *out,g_t13 v){
g_print_13(out,v);
}
static g_t16 g_clone_16(g_t16 v) {
GRef src=g_ref(&v); int64_t n=g_len(src,3,-1,0);
GArray old; memcpy(&old,&v,sizeof old); GArray fresh={0}; fresh.len=old.len; fresh.cap=old.cap; fresh.data=g_alloc((size_t)fresh.cap*8); memcpy(&v,&fresh,sizeof fresh);
src=g_ref(&old);
if(old.len)memcpy(fresh.data,old.data,(size_t)old.len*8);return v;}
static int g_equal_16(g_t16 a,g_t16 b){
GRef ar=g_ref(&a),br=g_ref(&b);int64_t n=g_len(ar,3,-1,0);if(n!=g_len(br,3,-1,0))return 0;
for(int64_t i=0;i<n;i++){if(!g_equal_5(g_load_5(g_element(ar,3,-1,0,8,i,0)),g_load_5(g_element(br,3,-1,0,8,i,0))))return 0;}return 1;
}
static void g_print_16(GArray *out,g_t16 v) {
g_stack_check();
GRef r=g_ref(&v); int64_t n=g_len(r,3,-1,0);
g_print_text(out,"[");
for(int64_t i=0;i<n;i++) {
if(i)g_print_text(out,", ");
g_nested_5(out,g_load_5(g_element(r,3,-1,0,8,i,0)));
}
g_print_text(out,"]");
}
static void g_nested_16(GArray *out,g_t16 v){
g_print_16(out,v);
}
static g_t17 g_clone_17(g_t17 v) {
return v;}
static int g_equal_17(g_t17 a,g_t17 b){
return a==b;
}
static void g_print_17(GArray *out,g_t17 v) {
g_stack_check();
g_print_text(out,"fn");
}
static void g_nested_17(GArray *out,g_t17 v){
g_print_17(out,v);
}
static g_t18 g_clone_18(g_t18 v) {
return v;}
static int g_equal_18(g_t18 a,g_t18 b){
return a==b;
}
static void g_print_18(GArray *out,g_t18 v) {
g_stack_check();
g_print_text(out,"fn");
}
static void g_nested_18(GArray *out,g_t18 v){
g_print_18(out,v);
}
static g_t19 g_clone_19(g_t19 v) {
return v;}
static int g_equal_19(g_t19 a,g_t19 b){
return a==b;
}
static void g_print_19(GArray *out,g_t19 v) {
g_stack_check();
g_print_text(out,"fn");
}
static void g_nested_19(GArray *out,g_t19 v){
g_print_19(out,v);
}
static g_t20 g_clone_20(g_t20 v) {
return v;}
static int g_equal_20(g_t20 a,g_t20 b){
return a==b;
}
static void g_print_20(GArray *out,g_t20 v) {
g_stack_check();
g_print_text(out,"fn");
}
static void g_nested_20(GArray *out,g_t20 v){
g_print_20(out,v);
}
static g_t21 g_clone_21(g_t21 v) {
return v;}
static int g_equal_21(g_t21 a,g_t21 b){
return a==b;
}
static void g_print_21(GArray *out,g_t21 v) {
g_stack_check();
g_print_text(out,"fn");
}
static void g_nested_21(GArray *out,g_t21 v){
g_print_21(out,v);
}
static g_t22 g_clone_22(g_t22 v) {
return v;}
static int g_equal_22(g_t22 a,g_t22 b){
return a==b;
}
static void g_print_22(GArray *out,g_t22 v) {
g_stack_check();
g_print_text(out,"fn");
}
static void g_nested_22(GArray *out,g_t22 v){
g_print_22(out,v);
}
static g_t23 g_clone_23(g_t23 v) {
return v;}
static int g_equal_23(g_t23 a,g_t23 b){
return a==b;
}
static void g_print_23(GArray *out,g_t23 v) {
g_stack_check();
g_print_text(out,"fn");
}
static void g_nested_23(GArray *out,g_t23 v){
g_print_23(out,v);
}
static g_t24 g_clone_24(g_t24 v) {
GRef src=g_ref(&v); int64_t n=g_len(src,3,-1,0);
GArray old; memcpy(&old,&v,sizeof old); GArray fresh={0}; fresh.len=old.len; fresh.cap=old.cap; fresh.data=g_alloc((size_t)fresh.cap*1); memcpy(&v,&fresh,sizeof fresh);
src=g_ref(&old);
if(old.len)memcpy(fresh.data,old.data,(size_t)old.len*1);return v;}
static int g_equal_24(g_t24 a,g_t24 b){
GRef ar=g_ref(&a),br=g_ref(&b);int64_t n=g_len(ar,3,-1,0);if(n!=g_len(br,3,-1,0))return 0;
for(int64_t i=0;i<n;i++){if(!g_equal_6(g_load_6(g_element(ar,3,-1,0,1,i,0)),g_load_6(g_element(br,3,-1,0,1,i,0))))return 0;}return 1;
}
static void g_print_24(GArray *out,g_t24 v) {
g_stack_check();
GRef r=g_ref(&v); int64_t n=g_len(r,3,-1,0);
for(int64_t i=0;i<n;i++) {
g_print_bytes(out,g_address(g_element(r,3,-1,0,1,i,0)),1);
}
}
static void g_nested_24(GArray *out,g_t24 v){
GRef r=g_ref(&v);int64_t n=g_len(r,3,-1,0);if(n<0 || (uint64_t)n>(SIZE_MAX-2)/2)g_panic("text size overflow");unsigned char *b=g_alloc((size_t)n*2+2);int64_t written=gs_fmt_quoted(b,g_address(g_element(r,3,-1,0,1,0,1)),n);g_print_bytes(out,b,written);
}
static g_t369 g_clone_369(g_t369 v) {
return v;}
static int g_equal_369(g_t369 a,g_t369 b){
GRef ar=g_ref(&a),br=g_ref(&b);int64_t n=g_len(ar,0,23,0);if(n!=g_len(br,0,23,0))return 0;
for(int64_t i=0;i<n;i++){if(!g_equal_11(g_load_11(g_element(ar,0,23,0,8,i,0)),g_load_11(g_element(br,0,23,0,8,i,0))))return 0;}return 1;
}
static void g_print_369(GArray *out,g_t369 v) {
g_stack_check();
GRef r=g_ref(&v); int64_t n=g_len(r,0,23,0);
g_print_text(out,"[");
for(int64_t i=0;i<n;i++) {
if(i)g_print_text(out,", ");
g_nested_11(out,g_load_11(g_element(r,0,23,0,8,i,0)));
}
g_print_text(out,"]");
}
static void g_nested_369(GArray *out,g_t369 v){
g_print_369(out,v);
}
static g_t370 g_clone_370(g_t370 v) {
return v;}
static int g_equal_370(g_t370 a,g_t370 b){
return g_nullable_address(a)==g_nullable_address(b);
}
static void g_print_370(GArray *out,g_t370 v) {
g_stack_check();
if(!v) g_print_text(out,"null"); else g_print_5(out,g_load_5(v));
}
static void g_nested_370(GArray *out,g_t370 v){
if(!v)g_print_text(out,"null");else g_nested_5(out,g_load_5(v));
}
static g_t375 g_clone_375(g_t375 v) {
GRef src=g_ref(&v); int64_t n=g_len(src,4,-1,0);
GArray old; memcpy(&old,&v,sizeof old); GArray fresh={0}; fresh.len=old.len; fresh.cap=old.cap; fresh.data=g_alloc((size_t)fresh.cap*8); memcpy(&v,&fresh,sizeof fresh);
src=g_ref(&old);
if(old.len)memcpy(fresh.data,old.data,(size_t)old.len*8);return v;}
static int g_equal_375(g_t375 a,g_t375 b){
GRef ar=g_ref(&a),br=g_ref(&b);int64_t n=g_len(ar,4,-1,0);if(n!=g_len(br,4,-1,0))return 0;
for(int64_t i=0;i<n;i++){if(!g_equal_5(g_load_5(g_element(ar,4,-1,0,8,i,0)),g_load_5(g_element(br,4,-1,0,8,i,0))))return 0;}return 1;
}
static void g_print_375(GArray *out,g_t375 v) {
g_stack_check();
GRef r=g_ref(&v); int64_t n=g_len(r,4,-1,0);
g_print_text(out,"[");
for(int64_t i=0;i<n;i++) {
if(i)g_print_text(out,", ");
g_nested_5(out,g_load_5(g_element(r,4,-1,0,8,i,0)));
}
g_print_text(out,"]");
}
static void g_nested_375(GArray *out,g_t375 v){
g_print_375(out,v);
}
static g_t16 g_fn10(GClosure *g_env,g_t5 g_s168);
static g_t13 g_fn35(GClosure *g_env,g_t5 g_s169);
static g_t16 g_fn50(GClosure *g_env,g_t5 g_s170);
static g_t0 g_fn72(GClosure *g_env);
static g_t16 g_fn80(GClosure *g_env);
static g_t0 g_fn97(GClosure *g_env);
static g_t1 g_fn285(GClosure *g_env);
static g_t24 g_s29;
static g_t369 g_s149;
static g_t16 g_fn10(GClosure *g_env,g_t5 g_s168) {
g_stack_check();
g_t16 g_result={0};
g_t16 g_s525={0};
{
GRef g_v0=0;
g_v0=g_ref(&g_s525);
g_t16 g_v1={0};
GRef g_v2=0;
g_v2=g_ref(&g_v1);
g_t5 g_v3={0};
g_v3=2;
g_reserve(g_v2,3,-1,0,8,g_v3);
g_set_len(g_v2,3,-1,0,g_v3);
GRef g_v4=0;
g_v4=g_ref(&g_s168);
g_t5 g_v5={0};
g_v5=g_load_5(g_v4);
g_store_5(g_element(g_v2,3,-1,0,8,0,0),g_v5);
GRef g_v6=0;
g_v6=g_ref(&g_s168);
g_t5 g_v7={0};
g_v7=g_load_5(g_v6);
g_t5 g_v8={0};
g_v8=(g_t5)UINT64_C(1);
g_t5 g_v9={0};
g_v9=(g_t5)((uint64_t)g_v7+(uint64_t)g_v8);
g_store_5(g_element(g_v2,3,-1,0,8,1,0),g_v9);
g_t16 g_v10={0};
g_v10=g_clone_16(g_v1);
g_store_16(g_v0,g_v10);
GRef g_v11=0;
g_v11=g_ref(&g_s525);
GRef g_v12=0;
g_v12=g_ref(&g_s168);
g_t5 g_v13={0};
g_v13=g_load_5(g_v12);
g_t5 g_v14={0};
g_v14=(g_t5)UINT64_C(2);
g_t5 g_v15={0};
g_v15=(g_t5)((uint64_t)g_v13+(uint64_t)g_v14);
g_t370 g_v16={0};
g_v16=g_push(g_v11,3,-1,0,8,&g_v15);
GRef g_v17=0;
g_v17=g_ref(&g_s525);
g_t16 g_v18={0};
g_v18=g_load_16(g_v17);
g_t16 g_v19={0};
g_v19=g_clone_16(g_v18);
g_result=g_v19;
goto g_return;
}
g_return:;
return g_result;
}
static g_t13 g_fn35(GClosure *g_env,g_t5 g_s169) {
g_stack_check();
g_t13 g_result={0};
{
g_t13 g_v0={0};
GRef g_v1=0;
g_v1=g_ref(&g_v0);
GRef g_v2=0;
g_v2=g_ref(&g_s169);
g_t5 g_v3={0};
g_v3=g_load_5(g_v2);
GRef g_v4=0;
g_v4=g_offset(g_v1,0);
g_store_5(g_v4,g_v3);
GRef g_v5=0;
g_v5=g_ref(&g_s169);
g_t5 g_v6={0};
g_v6=g_load_5(g_v5);
g_t16 g_v7={0};
g_v7=g_fn10(NULL,g_v6);
g_t16 g_v8={0};
g_v8=g_clone_16(g_v7);
GRef g_v9=0;
g_v9=g_offset(g_v1,8);
g_store_16(g_v9,g_v8);
g_t13 g_v10={0};
g_v10=g_clone_13(g_v0);
g_result=g_v10;
goto g_return;
}
g_return:;
return g_result;
}
static g_t16 g_fn50(GClosure *g_env,g_t5 g_s170) {
g_stack_check();
g_t16 g_result={0};
{
GRef g_v0=0;
g_v0=g_ref(&g_s170);
g_t5 g_v1={0};
g_v1=g_load_5(g_v0);
g_t5 g_v2={0};
g_v2=(g_t5)UINT64_C(0);
g_t1 g_v3={0};
g_v3=(g_t1)(g_v1==g_v2);
if(g_v3){
{
g_t16 g_v4={0};
GRef g_v5=0;
g_v5=g_ref(&g_v4);
g_t5 g_v6={0};
g_v6=2;
g_reserve(g_v5,3,-1,0,8,g_v6);
g_set_len(g_v5,3,-1,0,g_v6);
g_t5 g_v7={0};
g_v7=(g_t5)UINT64_C(7);
g_store_5(g_element(g_v5,3,-1,0,8,0,0),g_v7);
g_t5 g_v8={0};
g_v8=(g_t5)UINT64_C(8);
g_store_5(g_element(g_v5,3,-1,0,8,1,0),g_v8);
g_t16 g_v9={0};
g_v9=g_clone_16(g_v4);
g_result=g_v9;
goto g_return;
}
}else{
}
GRef g_v10=0;
g_v10=g_ref(&g_s170);
g_t5 g_v11={0};
g_v11=g_load_5(g_v10);
g_t5 g_v12={0};
g_v12=(g_t5)UINT64_C(1);
g_t5 g_v13={0};
g_v13=(g_t5)((uint64_t)g_v11-(uint64_t)g_v12);
g_t16 g_v14={0};
g_v14=g_fn50(NULL,g_v13);
g_t16 g_v15={0};
g_v15=g_clone_16(g_v14);
g_result=g_v15;
goto g_return;
}
g_return:;
return g_result;
}
static g_t0 g_fn72(GClosure *g_env) {
g_stack_check();
GReturnFrame g_frame={0};g_frame.parent=g_return_top;g_frame.function=72;
g_return_top=&g_frame;if(setjmp(g_frame.jump))goto g_return;
{
g_t16 g_v0={0};
GRef g_v1=0;
g_v1=g_ref(&g_v0);
g_t5 g_v2={0};
g_v2=2;
g_reserve(g_v1,3,-1,0,8,g_v2);
g_set_len(g_v1,3,-1,0,g_v2);
g_t5 g_v3={0};
g_v3=(g_t5)UINT64_C(41);
g_store_5(g_element(g_v1,3,-1,0,8,0,0),g_v3);
g_t5 g_v4={0};
g_v4=(g_t5)UINT64_C(42);
g_store_5(g_element(g_v1,3,-1,0,8,1,0),g_v4);
g_t16 g_v5={0};
g_v5=g_clone_16(g_v0);
g_throw(80,&g_v5,sizeof(g_t16));
}
g_return:;
g_return_top=g_frame.parent;
return;
}
static g_t16 g_fn80(GClosure *g_env) {
g_stack_check();
volatile g_t16 g_result={0};
GReturnFrame g_frame={0};g_frame.parent=g_return_top;g_frame.function=80;
g_frame.result=(void*)&g_result;g_frame.size=sizeof g_result;
g_return_top=&g_frame;if(setjmp(g_frame.jump))goto g_return;
g_t16 g_s528={0};
{
GRef g_v0=0;
g_v0=g_ref(&g_s528);
g_t16 g_v1={0};
GRef g_v2=0;
g_v2=g_ref(&g_v1);
g_t5 g_v3={0};
g_v3=2;
g_reserve(g_v2,3,-1,0,8,g_v3);
g_set_len(g_v2,3,-1,0,g_v3);
g_t5 g_v4={0};
g_v4=(g_t5)UINT64_C(1);
g_store_5(g_element(g_v2,3,-1,0,8,0,0),g_v4);
g_t5 g_v5={0};
g_v5=(g_t5)UINT64_C(2);
g_store_5(g_element(g_v2,3,-1,0,8,1,0),g_v5);
g_t16 g_v6={0};
g_v6=g_clone_16(g_v1);
g_store_16(g_v0,g_v6);
g_fn72(NULL);
}
g_return:;
g_return_top=g_frame.parent;
return g_result;
}
static g_t0 g_fn97(GClosure *g_env) {
g_stack_check();
GReturnFrame g_frame={0};g_frame.parent=g_return_top;g_frame.function=97;
g_return_top=&g_frame;if(setjmp(g_frame.jump))goto g_return;
g_t16 g_s516={0};
g_t370 g_s517={0};
g_t5 g_s518={0};
g_t16 g_s519={0};
g_t5 g_s522={0};
g_t13 g_s526={0};
g_t16 g_s527={0};
g_t16 g_s529={0};
g_t375 g_s530={0};
{
GRef g_v0=0;
g_v0=g_ref(&g_s516);
g_t16 g_v1={0};
GRef g_v2=0;
g_v2=g_ref(&g_v1);
g_t5 g_v3={0};
g_v3=2;
g_reserve(g_v2,3,-1,0,8,g_v3);
g_set_len(g_v2,3,-1,0,g_v3);
g_t5 g_v4={0};
g_v4=(g_t5)UINT64_C(3);
g_store_5(g_element(g_v2,3,-1,0,8,0,0),g_v4);
g_t5 g_v5={0};
g_v5=(g_t5)UINT64_C(4);
g_store_5(g_element(g_v2,3,-1,0,8,1,0),g_v5);
g_t16 g_v6={0};
g_v6=g_clone_16(g_v1);
g_store_16(g_v0,g_v6);
GRef g_v7=0;
g_v7=g_ref(&g_s517);
GRef g_v8=0;
g_v8=g_ref(&g_s516);
g_t5 g_v9={0};
g_v9=(g_t5)UINT64_C(0);
GRef g_v10=0;
g_v10=g_element_at(g_v8,3,-1,0,8,g_v9,0,"\057\144\145\166\057\163\150\155\057\147\157\157\163\145\055\143\157\155\160\154\145\164\151\157\156\055\167\157\162\153\057\163\156\141\160\163\150\157\164\055\062\067\057\156\141\164\151\166\145\057\164\145\163\164\163\057\157\162\144\151\156\141\162\171\137\162\145\147\151\157\156\163\056\147\157\157\163\145",23);
g_store_370(g_v7,g_v10);
{
g_t5 g_v13={0};
g_v13=(g_t5)UINT64_C(0);
g_t5 g_v14={0};
g_v14=(g_t5)UINT64_C(20000);
for(; g_v13<g_v14;g_v13++) {
g_s518=g_v13;
{
GRef g_v15=0;
g_v15=g_ref(&g_s519);
g_t16 g_v16={0};
GRef g_v17=0;
g_v17=g_ref(&g_v16);
g_t5 g_v18={0};
g_v18=(g_t5)UINT64_C(1024);
g_reserve(g_v17,3,-1,0,8,g_v18);
g_set_len(g_v17,3,-1,0,g_v18);
GRef g_v19=0;
g_v19=g_ref(&g_s518);
g_t5 g_v20={0};
g_v20=g_load_5(g_v19);
if(g_v18>0){
unsigned char *g_fill21=g_address(g_element(g_v17,3,-1,0,8,0,1));
for(int64_t g_i21=0;g_i21<g_v18;g_i21++)memcpy(g_fill21+g_i21*8,&g_v20,8);
}
g_t16 g_v22={0};
g_v22=g_clone_16(g_v16);
g_store_16(g_v15,g_v22);
GRef g_v23=0;
g_v23=g_ref(&g_s519);
g_t5 g_v24={0};
g_v24=(g_t5)UINT64_C(0);
GRef g_v25=0;
g_v25=g_element_at(g_v23,3,-1,0,8,g_v24,0,"\057\144\145\166\057\163\150\155\057\147\157\157\163\145\055\143\157\155\160\154\145\164\151\157\156\055\167\157\162\153\057\163\156\141\160\163\150\157\164\055\062\067\057\156\141\164\151\166\145\057\164\145\163\164\163\057\157\162\144\151\156\141\162\171\137\162\145\147\151\157\156\163\056\147\157\157\163\145",26);
g_t5 g_v26={0};
g_v26=g_load_5(g_v25);
GRef g_v27=0;
g_v27=g_ref(&g_s518);
g_t5 g_v28={0};
g_v28=g_load_5(g_v27);
g_t1 g_v29={0};
g_v29=(g_t1)(g_v26==g_v28);
if(g_v29) {
GRef g_v30=0;
g_v30=g_ref(&g_s519);
g_t5 g_v31={0};
g_v31=g_len(g_v30,3,-1,0);
g_t5 g_v32={0};
g_v32=(g_t5)UINT64_C(1024);
g_t1 g_v33={0};
g_v33=(g_t1)(g_v31==g_v32);
g_v29=g_v33;}
if(!g_v29)g_debug_fail("\057\144\145\166\057\163\150\155\057\147\157\157\163\145\055\143\157\155\160\154\145\164\151\157\156\055\167\157\162\153\057\163\156\141\160\163\150\157\164\055\062\067\057\156\141\164\151\166\145\057\164\145\163\164\163\057\157\162\144\151\156\141\162\171\137\162\145\147\151\157\156\163\056\147\157\157\163\145",26,"assert failed");
}
g_label12:;
}
g_label11:;}
{
g_t5 g_v36={0};
g_v36=(g_t5)UINT64_C(0);
g_t5 g_v37={0};
g_v37=(g_t5)UINT64_C(4096);
for(; g_v36<g_v37;g_v36++) {
g_s522=g_v36;
{
GRef g_v38=0;
g_v38=g_ref(&g_s516);
GRef g_v39=0;
g_v39=g_ref(&g_s522);
g_t5 g_v40={0};
g_v40=g_load_5(g_v39);
g_t370 g_v41={0};
g_v41=g_push(g_v38,3,-1,0,8,&g_v40);
}
g_label35:;
}
g_label34:;}
GRef g_v42=0;
g_v42=g_ref(&g_s517);
g_t370 g_v43={0};
g_v43=g_load_370(g_v42);
g_t5 g_v44={0};
g_v44=g_load_5(g_v43);
g_t5 g_v45={0};
g_v45=(g_t5)UINT64_C(3);
g_t1 g_v46={0};
g_v46=(g_t1)(g_v44==g_v45);
if(g_v46) {
GRef g_v47=0;
g_v47=g_ref(&g_s516);
g_t5 g_v48={0};
g_v48=g_len(g_v47,3,-1,0);
g_t5 g_v49={0};
g_v49=(g_t5)UINT64_C(4098);
g_t1 g_v50={0};
g_v50=(g_t1)(g_v48==g_v49);
g_v46=g_v50;}
if(!g_v46)g_debug_fail("\057\144\145\166\057\163\150\155\057\147\157\157\163\145\055\143\157\155\160\154\145\164\151\157\156\055\167\157\162\153\057\163\156\141\160\163\150\157\164\055\062\067\057\156\141\164\151\166\145\057\164\145\163\164\163\057\157\162\144\151\156\141\162\171\137\162\145\147\151\157\156\163\056\147\157\157\163\145",29,"assert failed");
GRef g_v51=0;
g_v51=g_ref(&g_s516);
GRef g_v52=0;
g_v52=g_ref(&g_s516);
g_t5 g_v53={0};
g_v53=g_len(g_v52,3,-1,0);
g_t5 g_v54={0};
g_v54=g_len(g_v51,3,-1,0);
g_reserve(g_v51,3,-1,0,8,g_v54+g_v53);
if(g_v53)memmove(g_address(g_element(g_v51,3,-1,0,8,g_v54,1)),g_address(g_element(g_v52,3,-1,0,8,0,1)),(size_t)g_v53*8);
g_set_len(g_v51,3,-1,0,g_v54+g_v53);
GRef g_v55=0;
g_v55=g_ref(&g_s517);
g_t370 g_v56={0};
g_v56=g_load_370(g_v55);
g_t5 g_v57={0};
g_v57=g_load_5(g_v56);
g_t5 g_v58={0};
g_v58=(g_t5)UINT64_C(3);
g_t1 g_v59={0};
g_v59=(g_t1)(g_v57==g_v58);
if(g_v59) {
GRef g_v60=0;
g_v60=g_ref(&g_s516);
g_t5 g_v61={0};
g_v61=g_len(g_v60,3,-1,0);
g_t5 g_v62={0};
g_v62=(g_t5)UINT64_C(8196);
g_t1 g_v63={0};
g_v63=(g_t1)(g_v61==g_v62);
g_v59=g_v63;}
if(g_v59) {
GRef g_v64=0;
g_v64=g_ref(&g_s516);
g_t5 g_v65={0};
g_v65=(g_t5)UINT64_C(4098);
GRef g_v66=0;
g_v66=g_element_at(g_v64,3,-1,0,8,g_v65,0,"\057\144\145\166\057\163\150\155\057\147\157\157\163\145\055\143\157\155\160\154\145\164\151\157\156\055\167\157\162\153\057\163\156\141\160\163\150\157\164\055\062\067\057\156\141\164\151\166\145\057\164\145\163\164\163\057\157\162\144\151\156\141\162\171\137\162\145\147\151\157\156\163\056\147\157\157\163\145",31);
g_t5 g_v67={0};
g_v67=g_load_5(g_v66);
g_t5 g_v68={0};
g_v68=(g_t5)UINT64_C(3);
g_t1 g_v69={0};
g_v69=(g_t1)(g_v67==g_v68);
g_v59=g_v69;}
if(!g_v59)g_debug_fail("\057\144\145\166\057\163\150\155\057\147\157\157\163\145\055\143\157\155\160\154\145\164\151\157\156\055\167\157\162\153\057\163\156\141\160\163\150\157\164\055\062\067\057\156\141\164\151\166\145\057\164\145\163\164\163\057\157\162\144\151\156\141\162\171\137\162\145\147\151\157\156\163\056\147\157\157\163\145",31,"assert failed");
GRef g_v70=0;
g_v70=g_ref(&g_s526);
g_t5 g_v71={0};
g_v71=(g_t5)UINT64_C(11);
g_t13 g_v72={0};
g_v72=g_fn35(NULL,g_v71);
g_t13 g_v73={0};
g_v73=g_clone_13(g_v72);
g_store_13(g_v70,g_v73);
GRef g_v74=0;
g_v74=g_ref(&g_s526);
GRef g_v75=0;
g_v75=g_offset(g_v74,0);
g_t5 g_v76={0};
g_v76=g_load_5(g_v75);
g_t5 g_v77={0};
g_v77=(g_t5)UINT64_C(11);
g_t1 g_v78={0};
g_v78=(g_t1)(g_v76==g_v77);
if(g_v78) {
GRef g_v79=0;
g_v79=g_ref(&g_s526);
GRef g_v80=0;
g_v80=g_offset(g_v79,8);
g_t5 g_v81={0};
g_v81=(g_t5)UINT64_C(2);
GRef g_v82=0;
g_v82=g_element_at(g_v80,3,-1,0,8,g_v81,0,"\057\144\145\166\057\163\150\155\057\147\157\157\163\145\055\143\157\155\160\154\145\164\151\157\156\055\167\157\162\153\057\163\156\141\160\163\150\157\164\055\062\067\057\156\141\164\151\166\145\057\164\145\163\164\163\057\157\162\144\151\156\141\162\171\137\162\145\147\151\157\156\163\056\147\157\157\163\145",33);
g_t5 g_v83={0};
g_v83=g_load_5(g_v82);
g_t5 g_v84={0};
g_v84=(g_t5)UINT64_C(13);
g_t1 g_v85={0};
g_v85=(g_t1)(g_v83==g_v84);
g_v78=g_v85;}
if(!g_v78)g_debug_fail("\057\144\145\166\057\163\150\155\057\147\157\157\163\145\055\143\157\155\160\154\145\164\151\157\156\055\167\157\162\153\057\163\156\141\160\163\150\157\164\055\062\067\057\156\141\164\151\166\145\057\164\145\163\164\163\057\157\162\144\151\156\141\162\171\137\162\145\147\151\157\156\163\056\147\157\157\163\145",33,"assert failed");
GRef g_v86=0;
g_v86=g_ref(&g_s527);
g_t5 g_v87={0};
g_v87=(g_t5)UINT64_C(100);
g_t16 g_v88={0};
g_v88=g_fn50(NULL,g_v87);
g_t16 g_v89={0};
g_v89=g_clone_16(g_v88);
g_store_16(g_v86,g_v89);
GRef g_v90=0;
g_v90=g_ref(&g_s527);
g_t5 g_v91={0};
g_v91=(g_t5)UINT64_C(0);
GRef g_v92=0;
g_v92=g_element_at(g_v90,3,-1,0,8,g_v91,0,"\057\144\145\166\057\163\150\155\057\147\157\157\163\145\055\143\157\155\160\154\145\164\151\157\156\055\167\157\162\153\057\163\156\141\160\163\150\157\164\055\062\067\057\156\141\164\151\166\145\057\164\145\163\164\163\057\157\162\144\151\156\141\162\171\137\162\145\147\151\157\156\163\056\147\157\157\163\145",35);
g_t5 g_v93={0};
g_v93=g_load_5(g_v92);
g_t5 g_v94={0};
g_v94=(g_t5)UINT64_C(7);
g_t1 g_v95={0};
g_v95=(g_t1)(g_v93==g_v94);
if(g_v95) {
GRef g_v96=0;
g_v96=g_ref(&g_s527);
g_t5 g_v97={0};
g_v97=(g_t5)UINT64_C(1);
GRef g_v98=0;
g_v98=g_element_at(g_v96,3,-1,0,8,g_v97,0,"\057\144\145\166\057\163\150\155\057\147\157\157\163\145\055\143\157\155\160\154\145\164\151\157\156\055\167\157\162\153\057\163\156\141\160\163\150\157\164\055\062\067\057\156\141\164\151\166\145\057\164\145\163\164\163\057\157\162\144\151\156\141\162\171\137\162\145\147\151\157\156\163\056\147\157\157\163\145",35);
g_t5 g_v99={0};
g_v99=g_load_5(g_v98);
g_t5 g_v100={0};
g_v100=(g_t5)UINT64_C(8);
g_t1 g_v101={0};
g_v101=(g_t1)(g_v99==g_v100);
g_v95=g_v101;}
if(!g_v95)g_debug_fail("\057\144\145\166\057\163\150\155\057\147\157\157\163\145\055\143\157\155\160\154\145\164\151\157\156\055\167\157\162\153\057\163\156\141\160\163\150\157\164\055\062\067\057\156\141\164\151\166\145\057\164\145\163\164\163\057\157\162\144\151\156\141\162\171\137\162\145\147\151\157\156\163\056\147\157\157\163\145",35,"assert failed");
GRef g_v102=0;
g_v102=g_ref(&g_s529);
g_t16 g_v103={0};
g_v103=g_fn80(NULL);
g_t16 g_v104={0};
g_v104=g_clone_16(g_v103);
g_store_16(g_v102,g_v104);
GRef g_v105=0;
g_v105=g_ref(&g_s529);
g_t5 g_v106={0};
g_v106=(g_t5)UINT64_C(43);
g_t370 g_v107={0};
g_v107=g_push(g_v105,3,-1,0,8,&g_v106);
GRef g_v108=0;
g_v108=g_ref(&g_s529);
g_t5 g_v109={0};
g_v109=g_len(g_v108,3,-1,0);
g_t5 g_v110={0};
g_v110=(g_t5)UINT64_C(3);
g_t1 g_v111={0};
g_v111=(g_t1)(g_v109==g_v110);
if(g_v111) {
GRef g_v112=0;
g_v112=g_ref(&g_s529);
g_t5 g_v113={0};
g_v113=(g_t5)UINT64_C(0);
GRef g_v114=0;
g_v114=g_element_at(g_v112,3,-1,0,8,g_v113,0,"\057\144\145\166\057\163\150\155\057\147\157\157\163\145\055\143\157\155\160\154\145\164\151\157\156\055\167\157\162\153\057\163\156\141\160\163\150\157\164\055\062\067\057\156\141\164\151\166\145\057\164\145\163\164\163\057\157\162\144\151\156\141\162\171\137\162\145\147\151\157\156\163\056\147\157\157\163\145",38);
g_t5 g_v115={0};
g_v115=g_load_5(g_v114);
g_t5 g_v116={0};
g_v116=(g_t5)UINT64_C(41);
g_t1 g_v117={0};
g_v117=(g_t1)(g_v115==g_v116);
g_v111=g_v117;}
if(g_v111) {
GRef g_v118=0;
g_v118=g_ref(&g_s529);
g_t5 g_v119={0};
g_v119=(g_t5)UINT64_C(2);
GRef g_v120=0;
g_v120=g_element_at(g_v118,3,-1,0,8,g_v119,0,"\057\144\145\166\057\163\150\155\057\147\157\157\163\145\055\143\157\155\160\154\145\164\151\157\156\055\167\157\162\153\057\163\156\141\160\163\150\157\164\055\062\067\057\156\141\164\151\166\145\057\164\145\163\164\163\057\157\162\144\151\156\141\162\171\137\162\145\147\151\157\156\163\056\147\157\157\163\145",38);
g_t5 g_v121={0};
g_v121=g_load_5(g_v120);
g_t5 g_v122={0};
g_v122=(g_t5)UINT64_C(43);
g_t1 g_v123={0};
g_v123=(g_t1)(g_v121==g_v122);
g_v111=g_v123;}
if(!g_v111)g_debug_fail("\057\144\145\166\057\163\150\155\057\147\157\157\163\145\055\143\157\155\160\154\145\164\151\157\156\055\167\157\162\153\057\163\156\141\160\163\150\157\164\055\062\067\057\156\141\164\151\166\145\057\164\145\163\164\163\057\157\162\144\151\156\141\162\171\137\162\145\147\151\157\156\163\056\147\157\157\163\145",38,"assert failed");
GRef g_v124=0;
g_v124=g_ref(&g_s530);
g_t375 g_v125={0};
GRef g_v126=0;
g_v126=g_ref(&g_v125);
g_t5 g_v127={0};
g_v127=(g_t5)UINT64_C(8192);
g_reserve(g_v126,4,-1,0,8,g_v127);
g_set_len(g_v126,4,-1,0,g_v127);
g_t5 g_v128={0};
g_v128=(g_t5)UINT64_C(5);
if(g_v127>0){
unsigned char *g_fill129=g_address(g_element(g_v126,4,-1,0,8,0,1));
for(int64_t g_i129=0;g_i129<g_v127;g_i129++)memcpy(g_fill129+g_i129*8,&g_v128,8);
}
g_t375 g_v130={0};
g_v130=g_clone_375(g_v125);
g_store_375(g_v124,g_v130);
GRef g_v131=0;
g_v131=g_ref(&g_s530);
g_t5 g_v132={0};
g_v132=(g_t5)UINT64_C(1);
if(g_v132<0)g_panic_at("resize to a negative length","\057\144\145\166\057\163\150\155\057\147\157\157\163\145\055\143\157\155\160\154\145\164\151\157\156\055\167\157\162\153\057\163\156\141\160\163\150\157\164\055\062\067\057\156\141\164\151\166\145\057\164\145\163\164\163\057\157\162\144\151\156\141\162\171\137\162\145\147\151\157\156\163\056\147\157\157\163\145",40);
g_t5 g_v133={0};
g_v133=g_len(g_v131,4,-1,0);
g_t5 g_v134={0};
g_v134=g_v132;
if(g_v134<0)g_panic_at("resize to a negative length","\057\144\145\166\057\163\150\155\057\147\157\157\163\145\055\143\157\155\160\154\145\164\151\157\156\055\167\157\162\153\057\163\156\141\160\163\150\157\164\055\062\067\057\156\141\164\151\166\145\057\164\145\163\164\163\057\157\162\144\151\156\141\162\171\137\162\145\147\151\157\156\163\056\147\157\157\163\145",40);
g_reserve(g_v131,4,-1,0,8,g_v134);
if(g_v134>g_v133)g_panic("resize growth requires fill");
g_set_len(g_v131,4,-1,0,g_v134);
g_t1 g_v135={0};
g_v135=g_fn285(NULL);
if(!g_v135)g_debug_fail("\057\144\145\166\057\163\150\155\057\147\157\157\163\145\055\143\157\155\160\154\145\164\151\157\156\055\167\157\162\153\057\163\156\141\160\163\150\157\164\055\062\067\057\156\141\164\151\166\145\057\164\145\163\164\163\057\157\162\144\151\156\141\162\171\137\162\145\147\151\157\156\163\056\147\157\157\163\145",41,"assert failed");
GRef g_v136=0;
g_v136=g_ref(&g_s530);
g_t5 g_v137={0};
g_v137=(g_t5)UINT64_C(8192);
if(g_v137<0)g_panic_at("resize to a negative length","\057\144\145\166\057\163\150\155\057\147\157\157\163\145\055\143\157\155\160\154\145\164\151\157\156\055\167\157\162\153\057\163\156\141\160\163\150\157\164\055\062\067\057\156\141\164\151\166\145\057\164\145\163\164\163\057\157\162\144\151\156\141\162\171\137\162\145\147\151\157\156\163\056\147\157\157\163\145",42);
g_t5 g_v138={0};
g_v138=(g_t5)UINT64_C(9);
g_t5 g_v139={0};
g_v139=g_len(g_v136,4,-1,0);
g_t5 g_v140={0};
g_v140=g_v137;
if(g_v140<0)g_panic_at("resize to a negative length","\057\144\145\166\057\163\150\155\057\147\157\157\163\145\055\143\157\155\160\154\145\164\151\157\156\055\167\157\162\153\057\163\156\141\160\163\150\157\164\055\062\067\057\156\141\164\151\166\145\057\164\145\163\164\163\057\157\162\144\151\156\141\162\171\137\162\145\147\151\157\156\163\056\147\157\157\163\145",42);
g_reserve(g_v136,4,-1,0,8,g_v140);
g_set_len(g_v136,4,-1,0,g_v140);
for(int64_t g_i141=g_v139;g_i141<g_v140;g_i141++){g_store_5(g_element(g_v136,4,-1,0,8,g_i141,0),g_clone_5(g_v138));}
g_set_len(g_v136,4,-1,0,g_v140);
GRef g_v142=0;
g_v142=g_ref(&g_s530);
g_t5 g_v143={0};
g_v143=(g_t5)UINT64_C(0);
GRef g_v144=0;
g_v144=g_element_at(g_v142,4,-1,0,8,g_v143,0,"\057\144\145\166\057\163\150\155\057\147\157\157\163\145\055\143\157\155\160\154\145\164\151\157\156\055\167\157\162\153\057\163\156\141\160\163\150\157\164\055\062\067\057\156\141\164\151\166\145\057\164\145\163\164\163\057\157\162\144\151\156\141\162\171\137\162\145\147\151\157\156\163\056\147\157\157\163\145",43);
g_t5 g_v145={0};
g_v145=g_load_5(g_v144);
g_t5 g_v146={0};
g_v146=(g_t5)UINT64_C(5);
g_t1 g_v147={0};
g_v147=(g_t1)(g_v145==g_v146);
if(g_v147) {
GRef g_v148=0;
g_v148=g_ref(&g_s530);
g_t5 g_v149={0};
g_v149=(g_t5)UINT64_C(8191);
GRef g_v150=0;
g_v150=g_element_at(g_v148,4,-1,0,8,g_v149,0,"\057\144\145\166\057\163\150\155\057\147\157\157\163\145\055\143\157\155\160\154\145\164\151\157\156\055\167\157\162\153\057\163\156\141\160\163\150\157\164\055\062\067\057\156\141\164\151\166\145\057\164\145\163\164\163\057\157\162\144\151\156\141\162\171\137\162\145\147\151\157\156\163\056\147\157\157\163\145",43);
g_t5 g_v151={0};
g_v151=g_load_5(g_v150);
g_t5 g_v152={0};
g_v152=(g_t5)UINT64_C(9);
g_t1 g_v153={0};
g_v153=(g_t1)(g_v151==g_v152);
g_v147=g_v153;}
if(!g_v147)g_debug_fail("\057\144\145\166\057\163\150\155\057\147\157\157\163\145\055\143\157\155\160\154\145\164\151\157\156\055\167\157\162\153\057\163\156\141\160\163\150\157\164\055\062\067\057\156\141\164\151\166\145\057\164\145\163\164\163\057\157\162\144\151\156\141\162\171\137\162\145\147\151\157\156\163\056\147\157\157\163\145",43,"assert failed");
GArray g_output154={0};
GRef g_v155=0;
g_v155=g_ref(&g_output154);
GArray g_builder154;
g_t12 g_v156={0};
g_v156=(GSlice){g_ref((void*)"\157\162\144\151\156\141\162\171\040\162\145\147\151\157\156\163\040\157\153"),19};
memcpy(&g_builder154,g_address(g_v155),sizeof(GArray));
g_print_12(&g_builder154,g_v156);
memcpy(g_address(g_v155),&g_builder154,sizeof(GArray));
flockfile(stdout);g_print_bytes(NULL,g_output154.data,g_output154.len);g_print_text(NULL,"\n");funlockfile(stdout);
}
g_return:;
g_return_top=g_frame.parent;
return;
}
static g_t1 g_fn285(GClosure *g_env) {
return g_trim_memory();
}
static void g_initialize(void){if(g_initialized)return;g_initialized=1;
GRef g_v0=0;
g_v0=g_ref(&g_s29);
g_t24 g_v1={0};
GRef g_v2=0;
g_v2=g_ref(&g_v1);
g_t5 g_v3={0};
g_v3=0;
g_reserve(g_v2,3,-1,0,1,g_v3);
g_set_len(g_v2,3,-1,0,g_v3);
g_t24 g_v4={0};
g_v4=g_clone_24(g_v1);
g_store_24(g_v0,g_v4);
GRef g_v5=0;
g_v5=g_ref(&g_s149);
g_t369 g_v6={0};
GRef g_v7=0;
g_v7=g_ref(&g_v6);
g_t5 g_v8={0};
g_v8=23;
g_t11 g_v9={0};
g_v9=g_float_literal(UINT64_C(4607182418800017408));
g_store_11(g_element(g_v7,0,23,0,8,0,0),g_v9);
g_t11 g_v10={0};
g_v10=g_float_literal(UINT64_C(4621819117588971520));
g_store_11(g_element(g_v7,0,23,0,8,1,0),g_v10);
g_t11 g_v11={0};
g_v11=g_float_literal(UINT64_C(4636737291354636288));
g_store_11(g_element(g_v7,0,23,0,8,2,0),g_v11);
g_t11 g_v12={0};
g_v12=g_float_literal(UINT64_C(4652007308841189376));
g_store_11(g_element(g_v7,0,23,0,8,3,0),g_v12);
g_t11 g_v13={0};
g_v13=g_float_literal(UINT64_C(4666723172467343360));
g_store_11(g_element(g_v7,0,23,0,8,4,0),g_v13);
g_t11 g_v14={0};
g_v14=g_float_literal(UINT64_C(4681608360884174848));
g_store_11(g_element(g_v7,0,23,0,8,5,0),g_v14);
g_t11 g_v15={0};
g_v15=g_float_literal(UINT64_C(4696837146684686336));
g_store_11(g_element(g_v7,0,23,0,8,6,0),g_v15);
g_t11 g_v16={0};
g_v16=g_float_literal(UINT64_C(4711630319722168320));
g_store_11(g_element(g_v7,0,23,0,8,7,0),g_v16);
g_t11 g_v17={0};
g_v17=g_float_literal(UINT64_C(4726483295884279808));
g_store_11(g_element(g_v7,0,23,0,8,8,0),g_v17);
g_t11 g_v18={0};
g_v18=g_float_literal(UINT64_C(4741671816366391296));
g_store_11(g_element(g_v7,0,23,0,8,9,0),g_v18);
g_t11 g_v19={0};
g_v19=g_float_literal(UINT64_C(4756540486875873280));
g_store_11(g_element(g_v7,0,23,0,8,10,0),g_v19);
g_t11 g_v20={0};
g_v20=g_float_literal(UINT64_C(4771362005757984768));
g_store_11(g_element(g_v7,0,23,0,8,11,0),g_v20);
g_t11 g_v21={0};
g_v21=g_float_literal(UINT64_C(4786511204640096256));
g_store_11(g_element(g_v7,0,23,0,8,12,0),g_v21);
g_t11 g_v22={0};
g_v22=g_float_literal(UINT64_C(4801453603149578240));
g_store_11(g_element(g_v7,0,23,0,8,13,0),g_v22);
g_t11 g_v23={0};
g_v23=g_float_literal(UINT64_C(4816244402031689728));
g_store_11(g_element(g_v7,0,23,0,8,14,0),g_v23);
g_t11 g_v24={0};
g_v24=g_float_literal(UINT64_C(4831355200913801216));
g_store_11(g_element(g_v7,0,23,0,8,15,0),g_v24);
g_t11 g_v25={0};
g_v25=g_float_literal(UINT64_C(4846369599423283200));
g_store_11(g_element(g_v7,0,23,0,8,16,0),g_v25);
g_t11 g_v26={0};
g_v26=g_float_literal(UINT64_C(4861130398305394688));
g_store_11(g_element(g_v7,0,23,0,8,17,0),g_v26);
g_t11 g_v27={0};
g_v27=g_float_literal(UINT64_C(4876203697187506176));
g_store_11(g_element(g_v7,0,23,0,8,18,0),g_v27);
g_t11 g_v28={0};
g_v28=g_float_literal(UINT64_C(4891288408196988160));
g_store_11(g_element(g_v7,0,23,0,8,19,0),g_v28);
g_t11 g_v29={0};
g_v29=g_float_literal(UINT64_C(4906019910204099648));
g_store_11(g_element(g_v7,0,23,0,8,20,0),g_v29);
g_t11 g_v30={0};
g_v30=g_float_literal(UINT64_C(4921056587992461136));
g_store_11(g_element(g_v7,0,23,0,8,21,0),g_v30);
g_t11 g_v31={0};
g_v31=g_float_literal(UINT64_C(4936209963552724370));
g_store_11(g_element(g_v7,0,23,0,8,22,0),g_v31);
g_store_369(g_v5,g_v6);
}
int main(int argc,char **argv){g_argc=argc;g_argv=argv;atexit(g_cleanup);g_initialize();g_fn97(NULL);return 0;}
