from pathlib import Path
import hashlib,json,os,platform,shutil,statistics,subprocess,time
work=Path('/dev/shm/goose-completion-work');out=work/'ordinary-regions-27';out.mkdir(exist_ok=False)
source=work/'snapshot-27/native/tests/ordinary_regions.goose';library=Path('/home/jacobt/src/goose-to-wasm/stdlib');cc=Path(shutil.which('clang')).resolve()
compilers={'snapshot-26':work/'c-only-bootstrap-26/goose','snapshot-27':work/'c-only-bootstrap-27/goose'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
report={'schema':'goose-ordinary-regions-benchmark-v1','source':str(source),'source_sha256':sha(source),'method':'Five alternating fresh process runs on CPU7; equal source, Goose O0, Clang O2 and output checks. wait4 peak RSS includes launcher setup. Controls use two separately bootstrapped compiler snapshots.','compiler_sha256':{k:sha(v) for k,v in compilers.items()},'cc':str(cc),'cc_sha256':sha(cc),'cc_version':subprocess.check_output([cc,'--version'],text=True),'cpu_affinity':sorted(os.sched_getaffinity(0)),'host':platform.uname()._asdict(),'stdlib_sha256':{p.name:sha(p) for p in library.glob('*.goose')},'commands':[],'runs':[]}
flags=['-std=gnu11','-O2','-fno-strict-aliasing','-ffp-contract=off','-pthread']
for name,compiler in compilers.items():
 c=out/(name+'.c');binary=out/name
 for command in [[compiler,source,'--target','native','--stdlib',library,'-O0','-o',c],[cc,*flags,c,'-lm','-ldl','-o',binary]]:
  command=list(map(str,command));started=time.perf_counter();r=subprocess.run(command,capture_output=True,text=True)
  report['commands'].append({'command':command,'seconds':time.perf_counter()-started,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr});assert r.returncode==0,r.stderr
 report.setdefault('artifacts',{})[name]={'c_sha256':sha(c),'binary_sha256':sha(binary)}
for repeat in range(5):
 for name in compilers:
  prefix=out/(name+'-'+str(repeat));started=time.perf_counter()
  with prefix.with_suffix('.stdout').open('wb') as stdout,prefix.with_suffix('.stderr').open('wb') as stderr:
   process=subprocess.Popen([str(out/name)],stdout=stdout,stderr=stderr);_,status,usage=os.wait4(process.pid,0);process.returncode=os.waitstatus_to_exitcode(status)
  seconds=time.perf_counter()-started
  assert process.returncode==0 and prefix.with_suffix('.stdout').read_bytes()==b'ordinary regions ok\n'
  report['runs'].append({'snapshot':name,'repeat':repeat,'seconds':seconds,'user_seconds':usage.ru_utime,'system_seconds':usage.ru_stime,'peak_rss_kib':usage.ru_maxrss,'exit':process.returncode})
report['summary']={name:{'median_seconds':statistics.median(v['seconds'] for v in report['runs'] if v['snapshot']==name),'median_peak_rss_kib':statistics.median(v['peak_rss_kib'] for v in report['runs'] if v['snapshot']==name)} for name in compilers}
assert report['source_sha256']==sha(source)
report['status']='passed';(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report['summary'],indent=2))
