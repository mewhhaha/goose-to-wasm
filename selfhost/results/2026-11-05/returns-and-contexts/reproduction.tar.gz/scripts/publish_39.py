from pathlib import Path
import collections, gzip, hashlib, io, json, tarfile, shutil

root = Path('/home/jacobt/src/goose-to-wasm')
work = root / 'build/completion-runs'
bench = root / 'bench/results/2026-11-05/returns-and-contexts'
checks = root / 'selfhost/results/2026-11-05/returns-and-contexts'

def read(path): return json.loads(path.read_text())
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path, value): path.write_text(json.dumps(value, indent=2) + '\n')
def gzcopy(source, target): target.write_bytes(gzip.compress(source.read_bytes(), mtime=0))

examples = read(work / 'goose-examples-39/report.json')
host = read(work / 'goose-host-39/report.json')
full = read(work / 'c-only-conformance-39/report.json')
v8 = read(work / 'c-only-v8-39/report.json')
proof = read(work / 'c-only-bootstrap-39/report.json')
comparison = read(work / 'comparison-39.json')
assert examples['status'] == host['status'] == v8['status'] == proof['status'] == 'passed'
assert full['summary']['selected'] == 5043
assert not comparison['shared_regressions'] and not comparison['new_failures']
assert len(examples['observations']) == 410
assert len(host['observations']) == 360 and len(host['preparation']) == 150
assert proof['next_generation_c_sha256'] == proof['generated_c_sha256']
assert examples['environment']['compiler_sha256'] == proof['executable_sha256']
for report in (full, v8, proof): assert report['input_sha256'] == report['input_sha256_after']
for pins in (examples['environment']['input_sha256'], host['input_sha256']):
    for name, identity in pins.items(): assert sha(Path(name)) == identity, name
for row in host['preparation']: assert sha(Path(row['artifact'])) == row['sha256']

bench.mkdir(parents=True, exist_ok=False)
checks.mkdir(parents=True, exist_ok=False)
for source, target in [('goose-examples-39/report.json', 'examples.json'),
                       ('goose-host-39/report.json', 'host.json'),
                       ('benchmark-window-39.json', 'window.json')]:
    shutil.copyfile(work / source, bench / target)
rows = []
for example in examples['examples']:
    name = example['name']
    rows.append({'name': name,
        'build_ms': {r['backend']: r['wall_seconds']['median'] * 1000
            for r in examples['compile_summary'] if r['name'] == name},
        'process_ms': {r['backend'] + '/' + r['mode']: r['wall_seconds']['median'] * 1000
            for r in host['runtime_summary'] if r['name'] == name}})
save(bench / 'summary.json', {'schema': 'goose-compiler-benchmarks-v1',
    'source_base_commit': 'cffcdf299a25e4779d6ea56b7521946205d2fee5',
    'compiler_snapshot': '39', 'source_sha256': proof['source_sha256'],
    'asset_sha256': proof['asset_sha256'], 'stdlib_sha256': proof['stdlib_sha256'],
    'bootstrap_c_sha256': proof['executable_c_sha256'], 'compiler_sha256': proof['executable_sha256'],
    'compiler_builds': 'Both measured cohorts use the exact qualified executable.',
    'examples_status': examples['status'], 'host_status': host['status'],
    'compile_samples': 5, 'runtime_samples': 5, 'preparation_samples': 5,
    'compiler_comparison': 'Both targets use the Goose-written compiler. Native uses its C backend at GCC O2. Prior snapshots are separately collected references.',
    'rows': rows})

for folder, name in [('c-only-bootstrap-39', 'bootstrap'), ('c-only-bootstrap-38', 'parent-bootstrap'),
                     ('c-only-conformance-39', 'conformance'), ('c-only-v8-39', 'v8')]:
    gzcopy(work / folder / 'report.json', checks / (name + '.json.gz'))
gzcopy(work / 'public-39/build/bootstrap/report.json', checks / 'public-bootstrap.json.gz')
shutil.copyfile(work / 'public-39/build/smoke/report.json', checks / 'public-smoke.json')
failures = [r for r in full['results'] if r['status'] != 'pass']
threads = [r for r in full['results'] if r['case'].startswith('upstream/threads/')]
assert len(threads) == 52 and all(r['status'] == 'pass' for r in threads)
save(checks / 'summary.json', {'schema': 'goose-compiler-qualification-v1',
    'snapshot': '39', 'complete': not failures, 'bootstrap_status': proof['status'],
    'bootstrap_c_sha256': proof['executable_c_sha256'], 'source_sha256': proof['source_sha256'],
    'asset_sha256': proof['asset_sha256'], 'compiler_sha256': proof['executable_sha256'],
    'fixed_point_scope': 'Consecutive C generations match; the parent seed is verified snapshot38.',
    'contracts': full['summary'], 'curated_v8': v8['summary'], 'native_thread_checks': len(threads),
    'existing_contract_gains': len(comparison['shared_gains']), 'existing_contract_regressions': 0,
    'new_contract_rows': len(comparison['new_rows']), 'new_contract_failures': 0,
    'remaining_failure_phases': dict(collections.Counter(r['phase'] for r in failures)),
    'remaining_failure_groups': dict(collections.Counter('/'.join(r['case'].split('/')[:2]) for r in failures)),
    'gains': comparison['shared_gains'],
    'scope': ['returned own-local aggregate construction with checked ownership metadata',
              'nonlocal target contexts in ordinary and dispatched specializations',
              'native lowering of divergent tail expressions']})

def archive(path, files):
    assert all(p.is_file() for p in files.values())
    with path.open('wb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', mtime=0) as zipped, tarfile.open(fileobj=zipped, mode='w|') as bundle:
        seen = {}
        for name, source in sorted(files.items()):
            data = source.read_bytes(); identity = hashlib.sha256(data).hexdigest()
            item = tarfile.TarInfo(name); item.mode = 0o644
            if identity in seen:
                item.type = tarfile.LNKTYPE; item.linkname = seen[identity]; bundle.addfile(item)
            else:
                item.size = len(data); bundle.addfile(item, io.BytesIO(data)); seen[identity] = name

files = {}
for folder, prefix in [('goose-examples-39', 'examples'), ('goose-host-39', 'host')]:
    for path in (work / folder).rglob('*'):
        if path.is_file(): files[prefix + '/' + path.relative_to(work / folder).as_posix()] = path
for pins in (examples['environment']['input_sha256'], host['input_sha256']):
    for name in pins:
        path = Path(name)
        if path.suffix in ('.goose', '.py', '.mjs', '.json', '.c', '.h', '.gz', '.txt') and path.stat().st_size < 20000000:
            files['inputs/' + sha(path) + '/' + path.name] = path
for name in ('LICENSE', 'NOTICE'): files['native/runtime/' + name] = work / 'snapshot-39/native/runtime' / name
archive(bench / 'measurements.tar.gz', files)

files = {}
for path in (work / 'verified-seed-38').iterdir(): files['parent-seed/' + path.name] = path
for path in (work / 'snapshot-39').rglob('*'):
    if path.is_file() and '__pycache__' not in path.parts: files['sources/' + path.relative_to(work / 'snapshot-39').as_posix()] = path
for name in ('conformance_shards.py', 'front_gate.py', 'freeze_seed.py'):
    files['scripts/' + name] = Path('/dev/shm/goose-completion-work') / name
files['scripts/publish_39.py'] = Path(__file__)
for index in range(4):
    folder = work / 'c-only-conformance-39'
    gzcopy(folder / ('shard-' + str(index)) / 'report.json', checks / ('conformance-shard-' + str(index) + '.json.gz'))
    files['qualification/cases-' + str(index) + '.json'] = folder / ('cases-' + str(index) + '.json')
for name in ('snapshot-39-assembly.json', 'comparison-39.json', 'astra-next-contract-hills.md', 'astra-flow-capture-audit.md', 'astra-print-fastpath.md'):
    files['notes/' + name] = work / name
for folder, name in [('semantic-round-dw', 'qualification.json'), ('semantic-round-dw', 'return-move.patch'),
                     ('semantic-round-dx', 'dw-on38.patch'), ('semantic-round-dx', 'base-proof/qualification.json'),
                     ('dispatch-target-v2', 'handoff.json'), ('dispatch-target-v2', 'handoff.md'),
                     ('dispatch-target-v2', 'combined.patch')]:
    files['components/' + folder + '/' + name] = work / folder / name
for name in ('cases.json',): files['qualification/' + name] = root / 'tests/conformance' / name
files['qualification/conformance.py'] = root / 'tests/conformance.py'
for path in (root / 'tests/fixtures').glob('flow_*.goose'): files['qualification/fixtures/' + path.name] = path
for path in (work / 'readme-copy-39').iterdir():
    if path.is_file(): files['copy/' + path.name] = path
for path in (work / 'semantic-rejections/returned-loop-tail').iterdir():
    if path.is_file(): files['rejected/returned-loop-tail/' + path.name] = path
for name in ('rejected-sources/iteration1-checker.goose', 'build/report.json', 'front/comparison.json',
             'conformance/report.json', 'rejected-v1.txt', 'rejected-sources/iteration2-checker.goose',
             'build2/report.json', 'conformance2/report.json', 'trace/run.stderr', 'target-only.patch'):
    files['rejected/target-context/' + name] = work / 'dispatch-target-v2' / name
files['rejected/original-target-failure.json'] = work / 'dispatch-completion-v1/conformance/report.json'
archive(checks / 'reproduction.tar.gz', files)
print('published evidence', bench, checks)
