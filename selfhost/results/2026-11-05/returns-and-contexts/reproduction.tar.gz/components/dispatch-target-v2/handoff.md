# Dispatch target handoff

Final compiler: `build3/goose`. Apply `combined.patch` relative to snapshot37, or `target-only.patch` on top of sealed dispatch-completion-v1. Owned functions: checker.goose `check_try_dispatch` and `check_bind_effect_context`; codegen_c.goose `cc_block`. No runtime/header changes.

Generic originals acquire nonlocal effects from checked specializations but never become F_CHECKED. The old guard skipped their active-target context cache key. Choose a checked specialization matching all incoming type/callback bindings to discover its target names, then bind the currently active target. Dispatch arms now perform the same context-binding step as ordinary calls. C block tails use the existing divergence predicate, so an all-stopping inlined tail need not fabricate a value. Activation scope, unwind, restoration and runtime reentrancy behavior are unchanged.

Concrete trace in trace/run.stderr: the first seven throws found their handler; case_a correctly threw to handler933, but case_b reused throw933 while its active handler was984. The missing dispatch context step explains that exact stale target.

Recovered all six original frozen native rows at O0/O2: never_returns, never_returns_arguments, unreachable_statements. Their original sources and expected outputs are unchanged; all now compile and execute correctly. Six exception rejection controls and the mixed dispatch rejection still reject. Frontend gate: 2,800 rows, zero regressions against snapshot37. Independent all-stop, mixed, nonlocal owner, repeated catches, nested rethrow, recursive bodies and dispatch context controls improve 4/20 to 20/20 across native/Wasm and O0/O2. Supplementary original-source Wasm runs pass never_returns/unreachable (4 rows); arguments still has the identical baseline line22 addressability error (2 rows). Full stdlib_exception remains rejected by pre-existing explicit-copy/type errors (2 rows).

C-only final build: 48.95 s emit plus 26.93 s clang O2. Own-source native selfcheck: passed in 39.26 s. These are run timings, not a controlled performance comparison. Final source/harness pins all match (pins-before.json and pins-after.json); build3/report.json pins the producer, source, toolchain and embedded native files. Final snapshot remains in source/.

Rejected iteration1 selected an arbitrary generic representative and borrowed effects from unrelated callbacks; preserved its failed front gate and exact reconstructed pinned checker source. Iteration2 restricted the representative to matching bindings, clearing front regressions and recovering four rows, then tracing the remaining dispatch omission. Rejected/intermediate reports remain in build/, build2/, conformance/, conformance2/, front/, front2/, controls-output/, controls-output2/, and rejected-sources/.

No reference compiler execution, full integrated corpus run, live edits or commits. Root owns integration and full qualification.
