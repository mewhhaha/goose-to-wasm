**Batch 45 float-width review — 2026-11-05**

**No blocker found in the sealed V3 patch.** The patch exactly matches the source diff against frozen 44; `optimizer.goose` is the only changed file among the 21 baseline selfhost files. All 19 evidence hashes in the handoff match. This approval covers the private optimizer component; combined canonical45 qualification remains separate.

The three normalization points are appropriate. Literal visitation commits a checked F32 payload before propagation. `opt_set_float` commits the result of newly folded unary, binary and cast expressions. `opt_replace` first preserves the replacement's source width and then the destination's storage width, which handles both F32-to-F64 propagation and a const-qualified F32 binding whose initializer remains F64. `check_numeric_value_type` recognizes qualified F32 by float kind/count, so the helper does not depend on the canonical type ID alone. F64 payloads pass through unchanged. The existing direct integer-to-F32 cast path remains in place; the removed float rounding was redundant with the helper.

The new early return handles leaf `N_FLOAT` nodes only. The existing finite-result guard in binary folding remains unchanged, and unary/cast creation still uses the same checked node type. No new literal adaptation or unfitted expression retyping is introduced. Primary `typecheck_exprs.h` near 1254 distinguishes literal adaptation from stored F32 widening; `typecheck_flow.h` near 1229 retains committed F32 leaves when branches widen.

I ran one independent 23-row exact-bit program with both canonical44 and the sealed candidate, at O0/O2 on native and Wasmtime. **Candidate: 4/4 executions and 92/92 numeric rows match.** Baseline: the const-qualified widening row is wrong in all four executions; its other 88 numeric rows match. The expected bits were written before either compiler ran, using independent IEEE754 binary32 rounding and binary64 bit extraction. The program covers:

- Positive/negative zero, smallest signed subnormal, half-subnormal ties including negative zero, and minimum normal.
- Maximum signed finite F32, signed overflow, and midpoint ties rounding to even.
- Const-qualified local and global storage, implicit widening, and a named F64 value outside F32's finite range.
- An unfitted F64 literal/computation and a context-fitted F32 computation.

Raw commands, compiler outputs and per-row comparisons are in [boundary-results.json](/home/jacobt/src/goose-to-wasm/build/completion-runs/astra-float-width-45/boundary-results.json); the [source](/home/jacobt/src/goose-to-wasm/build/completion-runs/astra-float-width-45/boundaries.goose), [expected bits](/home/jacobt/src/goose-to-wasm/build/completion-runs/astra-float-width-45/boundaries.expected), and [expectation method](/home/jacobt/src/goose-to-wasm/build/completion-runs/astra-float-width-45/expected-method.json) are retained beside it. These were small generated-program checks, not a compiler rebuild, own-source check, or oracle run.

The owner's sealed evidence reports 36/36 native+Wasmtime rows, 18/18 V8 rows, 2,800 frontend sources with no change/loss, and the 62.264 s own-source pass. The baseline-matched 52 rows contain 24 gains and no regressions. Six supplementary failures remain unchanged: two Wasm rows require unsupported `env.gs_sin`; four `const_global_folding` rows retain the readonly-assignment refusal. Those are existing limitations, not passes or blockers caused by this patch.

| Reviewed artifact | SHA-256 |
| --- | --- |
| `stored-f32-literals-snapshot44.patch` | `3ebb4e701e72041dc7a25c1d5c1512469b44733ae0474f41de64644b36d7404c` |
| candidate `optimizer.goose` | `2ef09708d9eca9c420a070f91428c2d83368adab8c2401a9efbd7f472e1cc699` |
| candidate compiler | `5ed7f1681e40eacdd9171f3df3efbbccef0ff4e232a9654694ba6ef161dfe286` |
| frozen44 `optimizer.goose` | `adb9821476d8318659c19f8995270a528ae38666322dc8ac0e7fb66686ce1b3c` |
| `handoff.json` | `c7c85491966563d405867dde66d14558401ad7d39e089c636f0af6f47bb26b2c` |
| `qualification44.json` | `6005d1f402d598d332929aae33fa28d617cd01eb41a349aea3600f4b358f0ebd` |

[review-pins.json](/home/jacobt/src/goose-to-wasm/build/completion-runs/astra-float-width-45/review-pins.json) records all primary-source, compiler, tool, source, expectation and report hashes plus the exact-diff and evidence checks. Every shell invocation sourced `build/performance-env.sh`; no sealed evidence or production source was changed.
