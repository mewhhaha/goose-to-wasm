Candidate 8 corrects a mistaken private fixture classification in the initial scout and candidates 1–7. Selfhost44 accepted control expressions whose branches explicitly referenced an element; those acceptances were incorrectly treated as valid controls.

The independent contract is the frozen `build/source/test/typing/branch_reference_copies.goose:23–29`: without a destination type, a control construct copies its branch value, and a reference branch contributes its pointee even with explicit `&`. Primary `typecheck_exprs.h:936–958` implements that decay; `typecheck_builtins.h:442–459` checks index_of without a reference destination. MATCH checks each arm with CheckValue in `typecheck_flow.h:1423`.

The corrected private expectations reject these copied branch constructs. Candidate 8 removes the attempted reference restoration and checks MATCH arms as values. Genuine reference-valued names, calls and projected multi-results remain accepted; an ordinary function reference parameter still supplies its reference destination to its branches.

No committed expectation was changed. The old private expectations are retained in `contracts-rejected-v7.json`; their exact corrections and source hashes are in `fixture-correction.json`. Frozen output contracts are copied unchanged into the runtime manifests. No reference compiler or C++ oracle was executed.
