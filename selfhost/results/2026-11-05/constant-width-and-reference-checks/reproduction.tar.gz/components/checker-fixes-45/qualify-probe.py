from pathlib import Path
import concurrent.futures,hashlib,json,subprocess,time,sys
w=Path(__file__).parent.resolve();root=w.parents[2];exe=Path(sys.argv[1]).resolve();label=sys.argv[2];lib=root/'stdlib'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
inputs=[exe,*lib.rglob('*.goose'),*(w/'source/selfhost').glob('*.goose'),w/'contracts.json',*(w/'focus').glob('*.goose')]
pins={str(p):sha(p) for p in inputs}
rows=[]
for case in json.loads((w/'contracts.json').read_text()):
 if label.startswith('13') and case['case'] in ['slice_ref_readonly_slot_temp','default_argument_write','branch_join_const_ref']:continue
 for layout in ['wasm','native']:
  cmd=[str(exe),case['source'],str(lib)]
  if label in ['44','final','final-v4','candidate8']:cmd=[str(exe),case['source'],'--stdlib',str(lib),'--check']
  if layout=='native':
   if label in ['44','final','final-v4','candidate8']:cmd.extend(['--target','native'])
   else:cmd.append('native')
  start=time.monotonic();p=subprocess.run(cmd,capture_output=True,text=True,timeout=20);rows.append(dict(case,layout=layout,command=cmd,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr,seconds=time.monotonic()-start,match=(p.returncode==0)==case['expected_accept']))
(w/(label+'-focus.json')).write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps([r for r in rows if not r['match']],indent=2));print('matched',sum(r['match'] for r in rows),'/',len(rows),flush=True)
if '--front' in sys.argv:
 result={}
 for suite in ['semantic-all-valid','typing','negative-type','upstream-positive']:
  old=json.loads((w.parent/'semantic-round-em'/('front43-before-'+suite+'.json')).read_text())
  def run(row):
   cmd=[str(exe),row['source'],str(lib)]
   if label in ['44','final','final-v4','candidate8']:cmd=[str(exe),row['source'],'--stdlib',str(lib),'--check']
   start=time.monotonic();p=subprocess.run(cmd,capture_output=True,text=True,timeout=20);return dict(source=row['source'],exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr,seconds=time.monotonic()-start)
  with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:out=list(pool.map(run,old))
  result[suite]=out;print(suite,sum(x['exit_code']==0 for x in out),'/',len(out),flush=True)
 (w/(label+'-front.json')).write_text(json.dumps(result,indent=2)+'\n')
assert pins=={str(p):sha(p) for p in inputs}
(w/(label+'-pins.json')).write_text(json.dumps(pins,indent=2)+'\n')
