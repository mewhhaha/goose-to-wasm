from pathlib import Path
import copy,hashlib,json,shutil,subprocess
root=Path('/home/jacobt/src/goose-to-wasm');w=root/'build/completion-runs';path=root/'tests/conformance/cases.json';manifest=json.loads(path.read_text());ids={c['id'] for c in manifest['cases']};added=[];sources={}
def retain(original,prefix):
 c=copy.deepcopy(original);source=root/c['source'];assert source.is_file(),source
 target=root/'tests/fixtures/contracts'/prefix/source.name;target.parent.mkdir(parents=True,exist_ok=True)
 if target.exists():assert target.read_bytes()==source.read_bytes(),target
 else:shutil.copyfile(source,target)
 name=target.relative_to(root).as_posix();sources[name]=hashlib.sha256(target.read_bytes()).hexdigest();c['source']=name;c['id']='corpus/contracts/'+prefix+'/'+c['id'];assert c['id'] not in ids,c['id'];ids.add(c['id']);added.append(c)
for c in json.loads((w/'named-float-width-v3/targeted-manifest.json').read_text())['cases']:retain(c,'float-width')
for target in ['native','wasm-direct']:
 retain(dict(id='ieee-boundaries/'+target,source=str(w/'astra-float-width-45/boundaries.goose'),target=target,phase='run',levels=[0,2],expect=dict(stdout=(w/'astra-float-width-45/boundaries.expected').read_text(),exit=0),provenance='Independent exact IEEE binary32 boundary patterns; source and expected-bit method reviewed by Astra.'),'float-width')
runtime=json.loads((w/'checker-fixes-45/runtime-manifest-candidate8.json').read_text())['cases'];by_source_target={(str((root/c['source']).resolve()),c['target']):c for c in runtime}
for entry in json.loads((w/'checker-fixes-45/contracts.json').read_text()):
 for target in ['native','wasm-direct']:
  if entry['expected_accept']:
   c=by_source_target[(str(Path(entry['source']).resolve()),target)]
  else:
   c=dict(id=entry['case']+'/'+target,source=entry['source'],target=target,phase='type-error',levels=[0,2],provenance=entry.get('classification_authority','Source-authored readonly, reference identity or whole-local inference rejection contract.'))
  retain(c,'reference-values')
manifest['cases'].extend(added);path.write_text(json.dumps(manifest,indent=2)+'\n');meta=dict(status='migrated; composed45 execution pending',cases=len(added),rows=sum(len(c['levels']) for c in added),sources=sources)
(w/'new-controls-45.json').write_text(json.dumps(meta,indent=2)+'\n');print('new45cases',meta['cases'],'rows',meta['rows'],'files',len(sources),'total',sum(len(c['levels']) for c in manifest['cases']))
