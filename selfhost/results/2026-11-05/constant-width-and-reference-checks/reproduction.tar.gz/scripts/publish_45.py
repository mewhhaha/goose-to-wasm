from pathlib import Path
import collections, gzip, hashlib, io, json, tarfile, shutil, subprocess

root = Path('/home/jacobt/src/goose-to-wasm')
work = root / 'build/completion-runs'
bench = root / 'bench/results/2026-11-05/constant-width-and-reference-checks'
checks = root / 'selfhost/results/2026-11-05/constant-width-and-reference-checks'

def read(path): return json.loads(path.read_text())
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path, value): path.write_text(json.dumps(value, indent=2) + '\n')
def gzcopy(source, target): target.write_bytes(gzip.compress(source.read_bytes(), mtime=0))

examples = read(work / 'goose-examples-45/report.json')
host = read(work / 'goose-host-45/report.json')
full = read(work / 'c-only-conformance-45-qualified/report.json')
v8 = read(work / 'c-only-v8-45-qualified/report.json')
proof = read(work / 'c-only-bootstrap-45/report.json')
comparison = read(work / 'comparison-45.json')
assert examples['status'] == host['status'] == v8['status'] == proof['status'] == 'passed'
assert full['summary']['selected'] == sum(len(r['levels']) for r in read(root / 'tests/conformance/cases.json')['cases'])
assert not comparison['shared_regressions'] and not comparison['new_failures']
assert len(examples['observations']) == 410
assert len(host['observations']) == 360 and len(host['preparation']) == 150
assert proof['fixed_point'] and proof['executable_c_sha256'] == proof.get('third_generation_c_sha256', proof['next_generation_c_sha256'])
assert examples['environment']['compiler_sha256'] == proof['executable_sha256']
assert proof['asset_sha256'] == read(work / 'c-only-bootstrap-44/report.json')['asset_sha256']
for report in (full, v8, proof): assert report['input_sha256'] == report['input_sha256_after']
for pins in (examples['environment']['input_sha256'], host['input_sha256']):
    for name, identity in pins.items(): assert sha(Path(name)) == identity, name
for row in host['preparation']: assert sha(Path(row['artifact'])) == row['sha256']

# Resume only an uncommitted publication preflight; delivered records are immutable.
assert not subprocess.check_output(['git', 'ls-files', '--', str(bench.relative_to(root)), str(checks.relative_to(root))], cwd=root).strip(), 'evidence paths are already tracked'
bench.mkdir(parents=True, exist_ok=True)
checks.mkdir(parents=True, exist_ok=True)
for source, target in [('goose-examples-45/report.json', 'examples.json'),
                       ('goose-host-45/report.json', 'host.json'),
                       ('benchmark-window-45.json', 'window.json')]:
    shutil.copyfile(work / source, bench / target)
rows = []
for example in examples['examples']:
    name = example['name']
    rows.append({'name': name,
        'build_ms': {r['backend']: r['wall_seconds']['median'] * 1000
            for r in examples['compile_summary'] if r['name'] == name},
        'process_ms': {r['backend'] + '/' + r['mode']: r['wall_seconds']['median'] * 1000
            for r in host['runtime_summary'] if r['name'] == name}})
save(bench / 'summary.json', {'schema': 'goose-compiler-benchmarks-v1',
    'source_base_commit': 'efcbc494f60db7a9fabfb5abebd1a491108786e9',
    'compiler_snapshot': '45', 'source_sha256': proof['source_sha256'],
    'asset_sha256': proof['asset_sha256'], 'stdlib_sha256': proof['stdlib_sha256'],
    'bootstrap_c_sha256': proof['executable_c_sha256'], 'compiler_sha256': proof['executable_sha256'],
    'compiler_builds': 'Both measured cohorts use the exact qualified executable.',
    'examples_status': examples['status'], 'host_status': host['status'],
    'compile_samples': 5, 'runtime_samples': 5, 'preparation_samples': 5,
    'compiler_comparison': 'Both targets use the Goose-written compiler. Native uses its C backend at GCC O2. Prior snapshots are separately collected references.',
    'rows': rows})

for folder, name in [('native-var-relative-V1/runtime43', 'native-runtime'), ('c-only-bootstrap-45', 'bootstrap'), ('c-only-bootstrap-44', 'parent-bootstrap'),
                     ('c-only-conformance-45-qualified', 'conformance'), ('c-only-v8-45-qualified', 'v8')]:
    gzcopy(work / folder / 'report.json', checks / (name + '.json.gz'))
gzcopy(work / 'public-45/build/bootstrap/report.json', checks / 'public-bootstrap.json.gz')
shutil.copyfile(work / 'public-45/build/smoke/report.json', checks / 'public-smoke.json')
cross = read(work / 'public-cross-45/report.json')
assert cross['status'] == 'passed' and cross['c_sha256'] == proof['executable_c_sha256']
shutil.copyfile(work / 'public-cross-45/report.json', checks / 'public-cross.json')
failures = [r for r in full['results'] if r['status'] != 'pass']
threads = [r for r in full['results'] if r['case'].startswith('upstream/threads/')]
case_targets = {r['id']: r['target'] for r in read(root / 'tests/conformance/cases.json')['cases']}
curated_wasm = [r for r in v8['results'] if case_targets[r['case']] == 'wasm-direct']
curated_native = [r for r in v8['results'] if case_targets[r['case']] == 'native']
assert len(curated_wasm) + len(curated_native) == v8['summary']['selected']
assert all(r['status'] == 'pass' for r in curated_wasm + curated_native)
assert len(threads) == 52 and all(r['status'] == 'pass' for r in threads)
save(checks / 'summary.json', {'schema': 'goose-compiler-qualification-v1',
    'snapshot': '45', 'complete': not failures, 'bootstrap_status': proof['status'],
    'bootstrap_c_sha256': proof['executable_c_sha256'], 'source_sha256': proof['source_sha256'],
    'asset_sha256': proof['asset_sha256'], 'compiler_sha256': proof['executable_sha256'],
    'public_compiler_sha256': cross['compiler_sha256'], 'public_same_path_c_sha256': cross['c_sha256'],
    'fixed_point_scope': 'Consecutive C generations match; the parent seed is verified snapshot44.',
    'contracts': full['summary'], 'original_contract_rows': 5043, 'curated_v8_driver': v8['summary'], 'curated_wasm_per_engine': len(curated_wasm), 'curated_native_controls': len(curated_native), 'native_thread_checks': len(threads),
    'existing_contract_gains': len(comparison['shared_gains']), 'existing_contract_regressions': 0,
    'new_contract_rows': len(comparison['new_rows']), 'new_contract_failures': 0,
    'remaining_failure_phases': dict(collections.Counter(r['phase'] for r in failures)),
    'remaining_runtime_failure_detail': read(work / 'remaining-phases-45.json'),
    'remaining_failure_groups': dict(collections.Counter('/'.join(r['case'].split('/')[:2]) for r in failures)),
    'gains': comparison['shared_gains'],
    'permanent_controls': read(work / 'new-controls-45.json'),
    'scope': ['preserve stored F32 values across literal propagation, folding and widening',
              'index_of consumes actual element-reference identity',
              'readonly temporary storage and control-result qualifiers',
              'inferred owning results require a whole local variable'],
    'native_runtime_reference': 'All native runtime assets match qualified44 exactly; its 37-command direct C header qualification is reused.'})

def archive(path, files):
    assert all(p.is_file() for p in files.values())
    with path.open('wb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', mtime=0) as zipped, tarfile.open(fileobj=zipped, mode='w|') as bundle:
        seen = {}
        for name, source in sorted(files.items()):
            data = source.read_bytes(); identity = hashlib.sha256(data).hexdigest()
            item = tarfile.TarInfo(name); item.mode = 0o644
            if identity in seen:
                item.type = tarfile.LNKTYPE; item.linkname = seen[identity]; bundle.addfile(item)
            else:
                item.size = len(data); bundle.addfile(item, io.BytesIO(data)); seen[identity] = name

files = {}
for folder, prefix in [('goose-examples-45', 'examples'), ('goose-host-45', 'host')]:
    for path in (work / folder).rglob('*'):
        if path.is_file(): files[prefix + '/' + path.relative_to(work / folder).as_posix()] = path
for pins in (examples['environment']['input_sha256'], host['input_sha256']):
    for name in pins:
        path = Path(name)
        if path.suffix in ('.goose', '.py', '.mjs', '.json', '.c', '.h', '.gz', '.txt') and path.stat().st_size < 20000000:
            files['inputs/' + sha(path) + '/' + path.name] = path
for name in ('LICENSE', 'NOTICE'): files['native/runtime/' + name] = work / 'snapshot-45/native/runtime' / name
archive(bench / 'measurements.tar.gz', files)

files = {}
for path in (work / 'verified-seed-44').iterdir(): files['parent-seed/' + path.name] = path
for path in (work / 'snapshot-45').rglob('*'):
    if path.is_file() and '__pycache__' not in path.parts: files['sources/' + path.relative_to(work / 'snapshot-45').as_posix()] = path
for name in ('conformance_shards.py', 'front_gate.py', 'freeze_seed.py'):
    files['scripts/' + name] = Path('/dev/shm/goose-completion-work') / name
files['scripts/publish_45.py'] = Path(__file__)
for name in ('prepare_delivery.py', 'render_copy_45.py', 'compare_batch.py'): files['scripts/' + name] = work / name
for index in range(4):
    folder = work / 'c-only-conformance-45-qualified'
    gzcopy(folder / ('shard-' + str(index)) / 'report.json', checks / ('conformance-shard-' + str(index) + '.json.gz'))
    files['qualification/cases-' + str(index) + '.json'] = folder / ('cases-' + str(index) + '.json')
for name in ('snapshot-45-assembly.json', 'reproduction-45.json', 'comparison-45.json', 'new-controls-45.json', 'public-smoke-context-45.json', 'remaining-phases-45.json', 'astra-next-45.md', 'astra-float-width-45.md', 'astra-checker-45.md'):
    files['notes/' + name] = work / name
for name in ('cases.json',): files['qualification/' + name] = root / 'tests/conformance' / name
for name in read(work / 'new-controls-45.json')['sources']: files['qualification/' + name] = root / name
files['qualification/conformance.py'] = root / 'tests/conformance.py'
for path in (work / 'readme-copy-45').iterdir():
    if path.is_file(): files['copy/' + path.name] = path
# Include selected source, controls, raw targeted reports and rejected checkpoints.
for folder in ('named-float-width-v1', 'named-float-width-v2', 'named-float-width-v3', 'checker-fixes-45', 'astra-next-45', 'astra-float-width-45', 'astra-checker-45'):
    for path in (work / folder).rglob('*'):
        if path.is_file() and '__pycache__' not in path.parts and path.suffix in ('.goose', '.h', '.c', '.py', '.json', '.md', '.patch', '.stdout', '.stderr', '.txt', '.log', '.gdb'):
            parts = path.relative_to(work / folder).parts
            if 'artifacts' in parts: continue
            if path.suffix == '.c' and not ('source' in parts and 'native' in parts and 'tests' in parts) and not (folder == 'native-static-globals-S2' and 'measurement' in parts): continue
            if 'upstream' in path.relative_to(work / folder).parts: continue
            files['components/' + folder + '/' + path.relative_to(work / folder).as_posix()] = path
for name in ('public-smoke-45.py', 'compare_batch_qualified45.py', 'benchmark_45.py', 'stage_45.py', 'install_45.py', 'public-cross45.py', 'migrate_controls45.py', 'reproduce_45.py'):
    files['scripts/' + name] = work / name
archive(checks / 'reproduction.tar.gz', files)
print('published evidence', bench, checks)
