from pathlib import Path
import hashlib,json,os,re,shutil,statistics,subprocess,time
root=Path('/home/jacobt/src/goose-to-wasm');work=Path('/dev/shm/goose-completion-work');out=work/'inline-compiler-probe';out.mkdir(exist_ok=False)
source=work/'c-only-bootstrap-29/next-generation.c';cc=Path(shutil.which('clang')).resolve();target=work/'snapshot-27/selfhost/main.goose';library=root/'stdlib'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
text=source.read_text();changed=text
for name in ('g_element_at','g_element'):
 changed,count=re.subn(r'\bstatic GRef '+name+r'\(',r'static __attribute__((always_inline)) inline GRef '+name+'(',changed);assert count==1,(name,count)
(out/'inline.c').write_text(changed)
r={'scope':'Exploratory same compiler C source/Clang O2 control. Runtime helper attribute only; embedded output-runtime bytes unchanged.','compiler_c_sha256':sha(source),'cc_sha256':sha(cc),'cpu_affinity':sorted(os.sched_getaffinity(0)),'load_before':os.getloadavg(),'input_sha256':{str(p):sha(p) for p in [*target.parent.glob('*.goose'),*(target.parent.parent/'native').rglob('*.h'),*library.rglob('*.goose')]},'commands':[],'runs':[]}
executables={'baseline':work/'c-only-bootstrap-29/goose'}
# The selected canonical binary was compiled from this exact C source with these same flags.
proof=json.loads((work/'c-only-bootstrap-29/report.json').read_text());assert sha(source)==proof['executable_c_sha256']
name='inline';binary=out/name;cmd=[str(cc),'-std=gnu11','-O2',str(out/'inline.c'),'-lm','-ldl','-pthread','-o',str(binary)];started=time.perf_counter();p=subprocess.run(cmd,capture_output=True);assert p.returncode==0,p.stderr;r['commands'].append({'command':cmd,'seconds':time.perf_counter()-started});executables[name]=binary
for repeat in range(3):
 for name,binary in executables.items():
  cmd=list(map(str,[binary,target,'--target','native','--stdlib',library,'--check']));started=time.perf_counter();p=subprocess.run(cmd,capture_output=True,timeout=90);elapsed=time.perf_counter()-started
  assert p.returncode==0 and p.stdout==b'' and p.stderr==b'',p.stderr[-4000:]
  r['runs'].append({'variant':name,'repeat':repeat,'command':cmd,'seconds':elapsed})
r['medians']={name:statistics.median(v['seconds'] for v in r['runs'] if v['variant']==name) for name in executables};r['load_after']=os.getloadavg();r['input_sha256_after']={name:sha(Path(name)) for name in r['input_sha256']};assert r['input_sha256_after']==r['input_sha256'];r['binary_sha256']={name:sha(p) for name,p in executables.items()};r['status']='passed';(out/'report.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r['medians']))
