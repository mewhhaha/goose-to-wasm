from pathlib import Path
import hashlib,json,os,re,shutil,statistics,subprocess,time
root=Path('/home/jacobt/src/goose-to-wasm');work=Path('/dev/shm/goose-completion-work');out=work/'inline-elements-probe';out.mkdir(exist_ok=False)
compiler=work/'c-only-bootstrap-29/goose';cc=Path(shutil.which('gcc')).resolve();source=root/'examples/sorting.goose';expected=(root/'examples/expected/sorting.out').read_bytes()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
r={'scope':'Exploratory same-generated-C control: generic runtime helper inlining only; no production source changed.','producer_sha256':sha(compiler),'source_sha256':sha(source),'cc_sha256':sha(cc),'cpu_affinity':sorted(os.sched_getaffinity(0)),'load_before':os.getloadavg(),'commands':[],'runs':[]}
c=out/'baseline.c';cmd=[str(compiler),str(source),'--target','native','--stdlib',str(root/'stdlib'),'-O2','-o',str(c)];p=subprocess.run(cmd,capture_output=True);assert p.returncode==0,p.stderr;r['commands'].append(cmd)
s=c.read_text()
for name in ('g_element_at','g_element'):
 s,n=re.subn(r'\bstatic GRef '+name+r'\(',r'static __attribute__((always_inline)) inline GRef '+name+'(',s);assert n==1,(name,n)
(out/'inline.c').write_text(s)
for name in ('baseline','inline'):
 cmd=[str(cc),'-std=gnu11','-O2','-fno-strict-aliasing','-ffp-contract=off','-rdynamic',str(out/(name+'.c')),'-lm','-ldl','-pthread','-o',str(out/name)];start=time.perf_counter();p=subprocess.run(cmd,capture_output=True);assert p.returncode==0,p.stderr;r['commands'].append(cmd);r.setdefault('compile_seconds',{})[name]=time.perf_counter()-start
for repeat in range(5):
 for name in ('baseline','inline'):
  start=time.perf_counter();p=subprocess.run([out/name],capture_output=True);elapsed=time.perf_counter()-start;assert p.returncode==0 and p.stdout==expected and not p.stderr
  r['runs'].append({'variant':name,'repeat':repeat,'seconds':elapsed})
r['medians']={name:statistics.median(v['seconds'] for v in r['runs'] if v['variant']==name) for name in ('baseline','inline')};r['load_after']=os.getloadavg();r['files']={p.name:sha(p) for p in out.iterdir() if p.is_file()};r['status']='passed';(out/'report.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r['medians']))
