from pathlib import Path
import collections, gzip, hashlib, io, json, shutil, tarfile

root = Path('/home/jacobt/src/goose-to-wasm')
work = Path('/dev/shm/goose-completion-work')
bench = root / 'bench/results/2026-11-05/threads-pools-and-access'
checks = root / 'selfhost/results/2026-11-05/threads-pools-and-contracts'

def read(path): return json.loads(path.read_text())
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path, value): path.write_text(json.dumps(value, indent=2) + '\n')
def gzcopy(source, target): target.write_bytes(gzip.compress(source.read_bytes(), mtime=0))

examples = read(work / 'goose-examples-32/report.json')
host = read(work / 'goose-host-32/report.json')
full = read(work / 'c-only-conformance-32/report.json')
v8 = read(work / 'c-only-v8-32/report.json')
proof = read(work / 'c-only-bootstrap-32/report.json')
comparison = read(work / 'comparison-32.json')
assert examples['status'] == host['status'] == v8['status'] == proof['status'] == 'passed'
assert full['summary'] == {'selected': 5021, 'passed': 4558, 'failed': 463}
assert not comparison['regressions'] and len(comparison['gains']) == 198
assert len(examples['observations']) == 410
assert len(host['observations']) == 360 and len(host['preparation']) == 150
assert proof['generated_c_sha256'] == proof['next_generation_c_sha256']
assert examples['environment']['compiler_sha256'] == proof['executable_sha256']
for report in (full, v8, proof): assert report['input_sha256'] == report['input_sha256_after']
for pins in (examples['environment']['input_sha256'], host['input_sha256']):
    for name, identity in pins.items(): assert sha(Path(name)) == identity, name
for row in host['preparation']: assert sha(Path(row['artifact'])) == row['sha256']

bench.mkdir(parents=True, exist_ok=True)
checks.mkdir(parents=True, exist_ok=True)
shutil.copyfile(work / 'goose-examples-32/report.json', bench / 'examples.json')
shutil.copyfile(work / 'goose-host-32/report.json', bench / 'host.json')
shutil.copyfile(work / 'benchmark-window-32.json', bench / 'window.json')
rows = []
for example in examples['examples']:
    name = example['name']
    rows.append({'name': name,
        'build_ms': {r['backend']: r['wall_seconds']['median'] * 1000
            for r in examples['compile_summary'] if r['name'] == name},
        'process_ms': {r['backend'] + '/' + r['mode']: r['wall_seconds']['median'] * 1000
            for r in host['runtime_summary'] if r['name'] == name}})
save(bench / 'summary.json', {'schema': 'goose-compiler-benchmarks-v1',
    'source_base_commit': '099e9fbf2745c9fa6a48938f3e742be97138b831',
    'compiler_snapshot': '32', 'source_sha256': proof['source_sha256'],
    'asset_sha256': proof['asset_sha256'], 'bootstrap_c_sha256': proof['executable_c_sha256'],
    'compiler_sha256': proof['executable_sha256'],
    'compiler_builds': 'The exact qualified executable was copied to the benchmark installation; both cohorts use this binary.',
    'examples_status': examples['status'], 'host_status': host['status'],
    'compile_samples': 5, 'runtime_samples': 5, 'preparation_samples': 5,
    'compiler_comparison': 'Both targets use the Goose-written compiler. Native uses its C backend at GCC O2. Snapshot27 and earlier C++ runs were collected separately.',
    'rows': rows})

for folder, name in [('c-only-bootstrap-32', 'bootstrap'), ('c-only-bootstrap-31', 'parent-bootstrap'),
                     ('c-only-conformance-32', 'conformance'), ('c-only-v8-32', 'v8')]:
    gzcopy(work / folder / 'report.json', checks / (name + '.json.gz'))
gzcopy(work / 'public-32/build/bootstrap/report.json', checks / 'public-bootstrap.json.gz')
shutil.copyfile(work / 'public-32/build/smoke/report.json', checks / 'public-smoke.json')
failures = [r for r in full['results'] if r['status'] != 'pass']
threads = [r for r in full['results'] if r['case'].startswith('upstream/threads/')]
assert len(threads) == 52 and all(r['status'] == 'pass' for r in threads)
save(checks / 'summary.json', {'schema': 'goose-compiler-qualification-v1',
    'snapshot': '32', 'complete': False, 'bootstrap_status': proof['status'],
    'bootstrap_c_sha256': proof['executable_c_sha256'], 'source_sha256': proof['source_sha256'],
    'asset_sha256': proof['asset_sha256'], 'compiler_sha256': proof['executable_sha256'],
    'fixed_point_scope': 'Two consecutive C outputs match. Parent snapshot31 separately passed three generations.',
    'contracts': full['summary'], 'curated_v8': v8['summary'], 'native_thread_checks': len(threads),
    'existing_contract_gains': 198, 'existing_contract_regressions': 0,
    'remaining_failure_phases': dict(collections.Counter(r['phase'] for r in failures)),
    'remaining_failure_groups': dict(collections.Counter('/'.join(r['case'].split('/')[:2]) for r in failures)),
    'known_gaps': ['105 invalid typing contracts still accepted', '358 valid runtime contracts still fail during compilation or execution',
        'Packed relative cells and general variable images remain unfinished; frontend lifetime and construction gaps remain'],
    'gains': comparison['gains']})

def archive(path, files):
    with path.open('wb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', mtime=0) as zipped, tarfile.open(fileobj=zipped, mode='w|') as bundle:
        seen = {}
        for name, source in sorted(files.items()):
            data = source.read_bytes(); identity = hashlib.sha256(data).hexdigest()
            item = tarfile.TarInfo(name); item.mode = 0o644
            if identity in seen:
                item.type = tarfile.LNKTYPE; item.linkname = seen[identity]; bundle.addfile(item)
            else:
                item.size = len(data); bundle.addfile(item, io.BytesIO(data)); seen[identity] = name

files = {}
for folder, prefix in [('goose-examples-32', 'examples'), ('goose-host-32', 'host')]:
    for path in (work / folder).rglob('*'):
        if path.is_file(): files[prefix + '/' + path.relative_to(work / folder).as_posix()] = path
for pins in (examples['environment']['input_sha256'], host['input_sha256']):
    for name, identity in pins.items():
        path = Path(name)
        if path.suffix in ('.goose', '.py', '.mjs', '.json', '.c', '.h', '.gz', '.txt') and path.stat().st_size < 20000000:
            files['inputs/' + identity + '/' + path.name] = path
for name in ('LICENSE', 'NOTICE'): files['native/runtime/' + name] = work / 'snapshot-32/native/runtime' / name
archive(bench / 'measurements.tar.gz', files)

files = {}
for path in (work / 'verified-seed-31').iterdir(): files['parent-seed/' + path.name] = path
for top in ('selfhost', 'native'):
    for path in (work / 'snapshot-32' / top).rglob('*'):
        if path.is_file() and '__pycache__' not in path.parts:
            files['sources/' + path.relative_to(work / 'snapshot-32').as_posix()] = path
for folder in ('inline-elements-probe', 'inline-compiler-probe', 'imported-entry-probe'):
    for path in (work / folder).iterdir():
        if path.is_file(): files[folder + '/' + path.name] = path
for name in ('inline_elements_probe.py', 'inline_compiler_probe.py', 'freeze_seed.py', 'publish_32.py'):
    files['scripts/' + name] = work / name
for folder in ('c-only-bootstrap-30', 'c-only-conformance-30', 'c-only-conformance-31', 'c-only-v8-31'):
    files['interrupted/' + folder + '.json'] = work / folder / 'report.json'
    path = work / folder / 'interrupted-report.json.gz'
    if path.exists(): files['interrupted/' + folder + '.json.gz'] = path
archive(checks / 'reproduction.tar.gz', files)
print(bench, sha(bench / 'measurements.tar.gz'))
print(checks, sha(checks / 'reproduction.tar.gz'))
