from pathlib import Path
import hashlib,json,statistics,subprocess,time
r=Path(__file__).resolve().parent;root=Path('/home/jacobt/src/goose-to-wasm');source=r/'lookup-workload.goose'
compilers={'snapshot38':root/'build/completion-runs/c-only-bootstrap-38/goose','first_candidate':r/'build/goose','final_candidate':r/'build3/goose'}
report={'method':'Seven alternating paired frontend checks after one warm-up per compiler; same source and stdlib. Wall-clock observations, concurrent host activity may affect absolute time.','sources':str(source),'input_sha256':{},'observations':[]}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
for p in [source,Path(__file__),*compilers.values(),*(root/'stdlib').rglob('*.goose')]:report['input_sha256'][str(p)]=sha(p)
for run in range(8):
 names=list(compilers)
 if run%2:names.reverse()
 for name in names:
  cmd=[str(compilers[name]),str(source),'--target','native','--stdlib',str(root/'stdlib'),'--check'];start=time.monotonic();p=subprocess.run(cmd,capture_output=True,text=True);seconds=time.monotonic()-start
  assert p.returncode==0,(name,p.stderr)
  if run:report['observations'].append({'compiler':name,'round':run,'seconds':seconds,'exit_code':p.returncode})
report['medians']={name:statistics.median(x['seconds'] for x in report['observations'] if x['compiler']==name) for name in compilers}
report['ratio_final_over_first']=report['medians']['final_candidate']/report['medians']['first_candidate']
report['ratio_final_over_snapshot38']=report['medians']['final_candidate']/report['medians']['snapshot38']
report['input_sha256_after']={p:sha(p) for p in report['input_sha256']};assert report['input_sha256']==report['input_sha256_after'];(r/'lookup-measurement.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'medians':report['medians'],'ratio_final_over_first':report['ratio_final_over_first'],'ratio_final_over_snapshot38':report['ratio_final_over_snapshot38']}))
