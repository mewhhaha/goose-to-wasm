from pathlib import Path
import json,subprocess
r=Path(__file__).parent.resolve();d=r/'focus';d.mkdir(exist_ok=True)
cases={
'fixed_reference':(True,'fn main(){var a=1;let r:i64&;r .= &a;r=7;assert(a==7);print(r);}'),
'optional_branches':(True,'fn value(c:bool)->i64{var a=1;var b=2;let r:i64?;if c{r .= &a;}else{r .= &b;}if r{return r;}return 0;}fn main(){print(value(true),value(false));}'),
'optional_static_branch':(True,'fn value(c:bool)->i64{var a=7;let r:i64?;if c{r .= &a;}else{r .= null;}if r{return r;}return 0;}fn main(){print(value(true),value(false));}'),
'late_slice':(True,'fn main(){var xs=[1,2];let s:i64[:];s .= xs[..];s[1]=9;assert(xs[1]==9);print(s);}'),
'late_slice_assignment':(True,'fn main(){var xs=[1,2];let s:i64[:];s=xs[..];print(s);}'),
'const_reference':(True,'fn main(){var a=1;let r:const i64&;r .= &a;print(r);}'),
'const_slice':(True,'fn main(){let s:const u8[:];s .= "abc";print(s);}'),
'captured_initialize':(True,'fn main(){var a=7;let r:i64&;fn init(){r .= &a;}init();print(r);}'),
'break_assignment':(True,'fn main(){var a=7;let r:i64&;loop{r .= &a;break;}print(r);}'),
'unknown_read':(False,'fn main(){let r:i64&;print(r);}'),
'partial_read':(False,'fn value(c:bool){var a=1;let r:i64&;if c{r .= &a;}print(r);}fn main(){value(true);}'),
'pointee_write_before_binding':(False,'fn main(){let r:i64&;r=1;}'),
'pointee_compound_before_binding':(False,'fn main(){let r:i64&;r+=1;}'),
'optional_pointee_without_narrow':(False,'fn main(){var r:i64?=null;r=1;}'),
'let_rebind_again':(False,'fn main(){var a=1;var b=2;let r:i64&;r .= &a;r .= &b;print(r);}'),
'loop_binding_again':(False,'fn main(){var a=1;let r:i64&;for i in 2{r .= &a;}print(r);}'),
'const_pointee_write':(False,'fn main(){var a=1;let r:const i64&;r .= &a;r=2;}'),
'reference_escape':(False,'fn main(){let r:i64&;{var a=7;r .= &a;}print(r);}'),
'slice_escape':(False,'fn main(){let s:i64[:];{var a=[1,2];s .= a[..];}print(s);}'),
'readonly_slice_store':(False,'fn main(){let s:u8[:];s .= "abc";print(s);}'),
'nonfixed_array':(False,'fn main(){let xs:i64[];xs=[1];print(xs);}'),
'resizable_array':(False,'fn main(){var xs:i64[>..];xs=[1];print(xs);}'),
'varint_value':(False,'fn main(){let n:varint;n=1;print(n);}'),
'varint_reference':(False,'fn main(){let r:i64&<varint>?;r .= null;print(r);}'),
}
cases.update({
'cached_scalar_unassigned':(False,'fn run(c:bool){let x:i64;fn rd(){print(x);}if c{x=7;rd();}rd();}fn main(){run(false);}'),
'cached_reference_unassigned':(False,'struct Cell{v:i64} var cells:Cell[>..]=[];fn run(c:bool){var r:Cell&;fn rd(){print(r.v);}if c{r .= cells[0];rd();}rd();}fn main(){cells.push(Cell{5});run(false);}'),
'cached_reference_assigned':(True,'fn main(){var x=7;let r:i64&;fn rd(){print(r);}r .= &x;rd();rd();}'),
'initialize_before_read':(True,'fn main(){var x:i64;fn init(){x=7;print(x);}init();init();print(x);}'),
'cached_callback_unassigned':(False,'fn apply<F>(){F();} fn run(c:bool){let x:i64;fn rd(){print(x);}if c{x=7;apply(rd);}apply(rd);}fn main(){run(false);}'),
'cached_optional':(False,'fn apply<F>(){F();}fn main(){var n=41;var opt:i64?=n;fn use(){print(opt+1);}if opt{apply(use);}opt .= null;apply(use);}'),
'cached_global_optional':(False,'var n=41;var opt:i64?=n;fn use(){print(opt+1);}fn main(){if opt{use();}opt .= null;use();}'),
'callback_initializes_before_read':(True,'fn apply<F>(){F();}fn main(){var x:i64;fn init(){x=7;print(x);}apply(init);apply(init);print(x);}'),
'guarded_optional':(True,'fn main(){var n=7;var opt:i64?=n;fn read()->i64{if opt{return opt;}return 0;}print(read());opt .= null;print(read());}'),
'context_pruned_tail':(True,'fn stop(x:i64&){abort("unused");}fn stop(x:i64?){print("empty");}fn main(){var n=7;var opt:i64?=n;fn work(){stop(opt);print("tail");}if false{if opt{work();}}opt .= null;work();}'),
})
cases.update({
'newly_unpruned_hof_capture':(True,'fn stop(x:i64&){abort("unused");}fn stop(x:i64?){print("empty");}fn apply<F>(){F();}fn main(){var a=11;var b=22;var branch=true;var n=7;var opt:i64?=n;fn work(){if branch{stop(opt);print(a);}else{print(b);}}if false{if opt{apply(work);}}opt .= null;apply(work);}'),
'recursive_rechecked_raw_tail':(True,'fn stop(x:i64&){abort("unused");}fn stop(x:i64?){print("empty");}fn main(){var n=7;var opt:i64?=n;var other:i64?=n;recursive fn work(i:i64)->i64{if i>0{work(i-1);}other .= null;stop(opt);print("tail");return 0;}if false{if opt{work(0);}}opt .= null;work(0);}'),
'delayed_fixed_pool_foreign':(False,'struct N{v:i64}var nodes:N[>..]=[N{7}];var other:N[>..]=[N{8}];fn main(){let r:N&<u32 in nodes>?;r .= &other[0];print(r);}'),
'delayed_fixed_pool_same':(True,'struct N{v:i64}var nodes:N[>..]=[N{7}];fn main(){let r:N&<u32 in nodes>?;r .= &nodes[0];if r{print(r.v);}}'),
})
rows=[]
for name,(accept,text) in cases.items():
 p=d/(name+'.goose');p.write_text(text+'\n');x=subprocess.run([str(r/'probe2'),str(p),'/home/jacobt/src/goose-to-wasm/stdlib'],capture_output=True,text=True,timeout=6)
 rows.append(dict(id=name,expected_accept=accept,exit_code=x.returncode,stdout=x.stdout,stderr=x.stderr,match=(accept and x.returncode==0)or(not accept and x.returncode!=0 and ': error:' in x.stdout+x.stderr)))
(r/'focus-after-poolguard.json').write_text(json.dumps(rows,indent=2)+'\n');print('focus',sum(x['match'] for x in rows),'/',len(rows))
for x in rows:
 if not x['match']:print(json.dumps(x,indent=2))
