import concurrent.futures,json,subprocess,time
from pathlib import Path
root=Path('/home/jacobt/src/goose-to-wasm/build/completion-runs/semantic-round-ec');prev=Path('/dev/shm/goose-selfhost-work/semantic-round-z')
probe=str(root/'probe');stdlib='/home/jacobt/src/goose-to-wasm/build/bin/stdlib'
def run(row):
 try:
  p=subprocess.run([probe,row['source'],stdlib],capture_output=True,text=True,timeout=4)
  return dict(source=row['source'],exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr)
 except subprocess.TimeoutExpired:return dict(source=row['source'],exit_code=124,stdout='',stderr='TIMEOUT')
for name in ['semantic-all-valid','typing','negative-type','upstream-positive']:
 rows=json.loads((prev/(name+'.json')).read_text());start=time.monotonic()
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool: results=list(pool.map(run,rows))
 (root/(name+'.json')).write_text(json.dumps(results,indent=2))
 print(name,len(results),'accepted',sum(x['exit_code']==0 for x in results),'timeout',sum(x['exit_code']==124 for x in results),'seconds',round(time.monotonic()-start,2),flush=True)

rows=json.loads((root/'negative-type.json').read_text())
failures=[x for x in rows if x['exit_code']!=0 and ': error:' not in x['stdout'] and ': error:' not in x['stderr']]
proper=sum(x['exit_code']!=0 for x in rows)-len(failures)
(root/'negative-validity.json').write_text(json.dumps(dict(proper_refusals=proper,compiler_failures=failures),indent=2)+'\n')
print('negative proper_refusals',proper,'compiler_failures',len(failures),flush=True)
