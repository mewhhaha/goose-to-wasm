from pathlib import Path
import json,subprocess,hashlib,os,signal,time
r=Path(__file__).parent.resolve();source=Path('build/completion-runs/snapshot-40/selfhost/main.goose').resolve();rows=[]
def timed_out(*_):raise TimeoutError('fixed-source check exceeded150s')
signal.signal(signal.SIGALRM,timed_out)
for name,exe in [('before',r.parent/'semantic-round-eb/control/probe'),('after',r/'probe2')]:
 with (r/(name+'-fixedinput.stdout')).open('wb') as out,(r/(name+'-fixedinput.stderr')).open('wb') as err:
  start=time.monotonic();p=subprocess.Popen([str(exe),str(source),str(Path('stdlib').resolve())],stdout=out,stderr=err);signal.alarm(150);timeout=False
  try:_,status,usage=os.wait4(p.pid,0)
  except TimeoutError:
   timeout=True;p.kill();_,status,usage=os.wait4(p.pid,0)
  finally:signal.alarm(0)
  p.returncode=os.waitstatus_to_exitcode(status)
 x=dict(name=name,executable=str(exe),sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),input=str(source),input_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),exit_code=p.returncode,timeout=timeout,user_seconds=usage.ru_utime,system_seconds=usage.ru_stime,wall_seconds=time.monotonic()-start,maxrss_kib=usage.ru_maxrss,stdout=(r/(name+'-fixedinput.stdout')).read_text(),stderr=(r/(name+'-fixedinput.stderr')).read_text())
 (r/(name+'-cost.json')).write_text(json.dumps(x,indent=2)+'\n');rows.append(x);print(json.dumps(x),flush=True)
(r/'paired-cost.json').write_text(json.dumps(rows,indent=2)+'\n')
