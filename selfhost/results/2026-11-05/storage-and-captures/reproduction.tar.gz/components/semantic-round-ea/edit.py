from pathlib import Path
r=Path(__file__).parent/'source/selfhost';p=r/'checker.goose';s=p.read_text()
def ch(a,b,n=1):
 global s
 assert s.count(a)==n,(a,s.count(a));s=s.replace(a,b)
ch('struct CheckRoot { value: i64, root: i64, kind: i64 = 0, next: i64 = -1 }','''struct CheckEnvironment {
    symbol: i64, assigned: bool, maybeassigned: bool, narrowed: i64, readonly: bool, next: i64 = -1,
}
struct CheckRoot { value: i64, root: i64, kind: i64 = 0, next: i64 = -1 }''')
ch('''    roots: CheckRoot[>..]&, root_nodes: i64[>..]&, root_symbols: i64[>..]&, effects: CheckEffect[>..]&,''','''    roots: CheckRoot[>..]&, root_nodes: i64[>..]&, root_symbols: i64[>..]&, effects: CheckEffect[>..]&,
    environments: CheckEnvironment[>..]&, environment_heads: i64[>..]&,
    syntax_nodes: Node[>..]&, syntax_lookup: i64[>..]&,
    clone_syntax: bool = false, optional_globals: bool = false,''')
anchor='recursive fn check_clone(p: Program&, c: Checker&, node: i64, bindings: CheckList&) -> i64 {'
helper='''fn check_clone_node(p: Program&, c: Checker&, node: i64) -> Node {
    if c.clone_syntax && node < c.syntax_lookup.len && c.syntax_lookup[node] >= 0 { return c.syntax_nodes[c.syntax_lookup[node]]; }
    return p.nodes[node];
}
fn check_function_syntax(p: Program&, c: Checker&, function_node: i64) {
    let n = p.nodes[function_node]; var preserve = c.optional_globals;
    var original = function_node;
    while original >= 0 && !preserve {
        let f = p.nodes[original]; let symbol = f.symbol;
        if f.kind == N_FUNCTION_VALUE { preserve = true; }
        if symbol >= 0 {
            let s = p.symbols[symbol];
            if s.owner >= 0 || s.scope > 0 && c.scopes[s.scope].namespace_node < 0 { preserve = true; }
        }
        original = f.origin;
    }
    var parameter = n.first;
    while parameter >= 0 && !preserve {
        let ty = p.nodes[parameter].type_id;
        if ty >= 0 && p.types[ty].kind == TY_FN { preserve = true; }
        parameter = p.nodes[parameter].next;
    }
    if !preserve || n.right < 0 { return; }
    var pending: i64[>..] = [n.right];
    while pending.len > 0 {
        let node = pending.pop(); if node < 0 { continue; }
        while c.syntax_lookup.len <= node { c.syntax_lookup.push(-1); }
        if c.syntax_lookup[node] >= 0 { continue; }
        let value = p.nodes[node]; c.syntax_lookup[node] = c.syntax_nodes.len; c.syntax_nodes.push(value);
        if value.kind == N_IMPORT { continue; }
        pending.push(value.first); pending.push(value.left); pending.push(value.right); pending.push(value.third); pending.push(value.next);
    }
}
'''
ch(anchor,helper+anchor)
start=s.index(anchor);end=s.index('\nstruct CheckConstant',start);body=s[start:end]
body=body.replace('var copy = p.nodes[node];','var copy = check_clone_node(p, c, node);').replace('p.nodes[child].next','check_clone_node(p, c, child).next').replace('p.nodes[old].next','check_clone_node(p, c, old).next')
s=s[:start]+body+s[end:]
anchor='fn check_function_reached(p: Program&, c: Checker&, function_node: i64, token: i64) -> bool {'
helper='''fn check_environment_head(c: Checker&, function_node: i64) -> i64 {
    if function_node < 0 || function_node >= c.environment_heads.len { return -1; }
    return c.environment_heads[function_node];
}
fn check_environment_add(p: Program&, c: Checker&, value: CheckEnvironment) {
    let function_node = c.function_node;
    if function_node < 0 || value.symbol < 0 { return; }
    let symbol = p.symbols[value.symbol];
    if symbol.owner == function_node || (symbol.flags & (S_TYPE | S_FUNCTION)) != 0 { return; }
    if (symbol.flags & S_GLOBAL) != 0 && (symbol.type_id < 0 || p.types[symbol.type_id].kind != TY_REF || (p.types[symbol.type_id].flags & TF_OPTIONAL) == 0) { return; }
    let head = check_environment_head(c, function_node); var at = head;
    while at >= 0 { let old = c.environments[at]; if old.symbol == value.symbol { return; } at = old.next; }
    while c.environment_heads.len <= function_node { c.environment_heads.push(-1); }
    var entry = value; entry.next = head;
    let id = c.environments.len; c.environments.push(entry); c.environment_heads[function_node] = id;
}
fn check_environment_note(p: Program&, c: Checker&, symbol: i64) {
    let vi = check_variable_index(c, symbol); if vi < 0 { return; }
    let v = c.variables[vi];
    check_environment_add(p, c, CheckEnvironment { symbol: symbol, assigned: v.assigned, maybeassigned: v.maybeassigned, narrowed: v.narrowed, readonly: v.readonly });
}
fn check_environment_callee(p: Program&, c: Checker&, function_node: i64) {
    if function_node == c.function_node { return; }
    var at = check_environment_head(c, function_node);
    while at >= 0 { let value = c.environments[at]; at = value.next; check_environment_add(p, c, value); }
}
fn check_environment_same(p: Program&, c: Checker&, function_node: i64, token: i64) -> bool {
    var active = false;
    for index in 0..c.checking_count { if c.checking[index] == function_node { active = true; } }
    var at = check_environment_head(c, function_node);
    while at >= 0 {
        let previous = c.environments[at]; at = previous.next;
        let vi = check_variable_index(c, previous.symbol); if vi < 0 { return false; }
        let current = c.variables[vi];
        if active {
            if previous.narrowed >= 0 && !check_same_type(p, previous.narrowed, current.narrowed) {
                diagnose(p, token, "recursive call requires a captured optional to remain narrowed");
            }
        } else if current.assigned != previous.assigned ||
           (p.symbols[previous.symbol].flags & S_MUTABLE) == 0 && current.maybeassigned != previous.maybeassigned ||
           !check_same_type(p, current.narrowed, previous.narrowed) || current.readonly != previous.readonly { return false; }
    }
    return true;
}
'''
ch(anchor,helper+anchor)
ch('''    if bindings.count == 0 { return p.nodes[original].symbol; }
    for spec in c.specializations {''','''    if bindings.count == 0 && check_environment_same(p, c, original, token) { return p.nodes[original].symbol; }
    for spec in c.specializations {''')
ch('''        if equal { return spec.symbol; }
    }
    var same_declaration = 0;
    for active_index''','''        if equal && check_environment_same(p, c, p.symbols[spec.symbol].node, token) { return spec.symbol; }
    }
    var same_declaration = 0;
    for active_index''')
ch('''    c.inference_depth += 1;
    let copy = check_clone(p, c, original, bindings);''','''    c.inference_depth += 1;
    let saved_syntax = c.clone_syntax; c.clone_syntax = true;
    let copy = check_clone(p, c, original, bindings); c.clone_syntax = saved_syntax;''')
ch('''fn check_apply_call_effects(p: Program&, c: Checker&, node: i64, function_node: i64, args: CheckList&) {
    let roots_end''','''fn check_apply_call_effects(p: Program&, c: Checker&, node: i64, function_node: i64, args: CheckList&) {
    check_environment_callee(p, c, function_node);
    let roots_end''')
ch('''                    let vi = check_variable_index(c, symbol);
                    if vi >= 0 && c.variables[vi].narrowed >= 0''','''                    let vi = check_variable_index(c, symbol); check_environment_note(p, c, symbol);
                    if vi >= 0 && c.variables[vi].narrowed >= 0''')
ch('''        if symbol >= 0 { p.nodes[n.left].symbol = symbol; ty = p.symbols[symbol].type_id; p.nodes[n.left].type_id = ty; }''','''        if symbol >= 0 { check_environment_note(p, c, symbol); p.nodes[n.left].symbol = symbol; ty = p.symbols[symbol].type_id; p.nodes[n.left].type_id = ty; }''')
ch('''        let symbol = check_declare(p, c, binding, c.scope); p.symbols[symbol].type_id = ty;
        if index == 0''','''        let symbol = check_declare(p, c, binding, c.scope); p.symbols[symbol].type_id = ty;
        if (p.symbols[symbol].flags & S_GLOBAL) != 0 && ty >= 0 && p.types[ty].kind == TY_REF && (p.types[ty].flags & TF_OPTIONAL) != 0 { c.optional_globals = true; }
        if index == 0''')
ch('''    if n.right < 0 { p.nodes[function_node].flags |= F_CHECKED; return; }
    var entry_flow''','''    if n.right < 0 { p.nodes[function_node].flags |= F_CHECKED; return; }
    check_function_syntax(p, c, function_node);
    var entry_flow''')
ch('''    var checker_effects: CheckEffect[>..] = [];''','''    var checker_environments: CheckEnvironment[>..] = []; var checker_environment_heads: i64[>..] = [];
    var checker_syntax_nodes: Node[>..] = []; var checker_syntax_lookup: i64[>..] = [];
    var checker_effects: CheckEffect[>..] = [];''')
a='''effects: checker_effects, return_roots: checker_return_roots''';b='''effects: checker_effects, environments: checker_environments, environment_heads: checker_environment_heads, syntax_nodes: checker_syntax_nodes, syntax_lookup: checker_syntax_lookup, return_roots: checker_return_roots''';ch(a,b)
p.write_text(s)
