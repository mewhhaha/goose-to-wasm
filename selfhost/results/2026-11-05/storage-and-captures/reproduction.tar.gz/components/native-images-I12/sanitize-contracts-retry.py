from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
base=Path(__file__).resolve().parent
root=Path('/home/jacobt/src/goose-to-wasm');out=base/'sanitized-contracts';out.mkdir(exist_ok=False)
cc=Path(shutil.which('clang')).resolve();compiler=base/'build/goose'
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
pins={str(p):sha(p) for p in (cc,compiler,Path(__file__).resolve())}
r={'status':'running','method':'Recompile unchanged generated C from focused frozen contracts with Clang ASan/UBSan; compare fresh executions against original manifest expectations. Unsupported frontend rows remain recorded in the focused conformance report.','input_sha256':pins,'commands':[],'results':[]}
def save():(out/'report.json').write_text(json.dumps(r,indent=2)+'\n')
def run(label,command,cwd,stdin=''):
 command=list(map(str,command));start=time.monotonic()
 child=subprocess.run(command,cwd=cwd,input=stdin,text=True,capture_output=True,timeout=90)
 (out/(label+'.stdout')).write_text(child.stdout);(out/(label+'.stderr')).write_text(child.stderr)
 row=dict(command=command,cwd=str(cwd),exit_code=child.returncode,seconds=time.monotonic()-start,stdout=child.stdout,stderr=child.stderr)
 r['commands'].append(row);save();return row
try:
 for group,manifest in [('focus-retry',base/'cases.json'),('regressions-retry',base/'regression-cases.json'),('limited-final',base/'limited-cases.json')]:
  report=base/group/'report.json';pins[str(report)]=sha(report);pins[str(manifest)]=sha(manifest)
  data=json.loads(report.read_text());cases={c['id']:c for c in json.loads(manifest.read_text())['cases']}
  if group=='focus-retry':
   refused={(row['case'],row['level']) for row in data['results'] if row['status']!='pass'}
   assert refused=={(name,level) for name in ('upstream/storage/serialize','upstream/storage/serialize_image_checks') for level in (0,2)},refused
   r['outside_supported_family']=sorted(refused)
  else:assert data['summary']['failed']==0
  for index,row in enumerate(data['results']):
   if row['status']!='pass':continue
   case=cases[row['case']];assert case['phase']=='run' and case['expect']['exit']==0
   command=data['commands'][row['native_command']]['command'];source=Path(command[3]);pins[str(source)]=sha(source)
   label=group+'-'+str(index);binary=out/label
   extra=[]
   if group=='limited-final':
    host=root/'bench/host_input.c';pins[str(host)]=sha(host);extra=[host,'-Wl,--export-dynamic']
   built=run(label+'-cc',[cc,'-std=gnu11','-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer',source,*extra,'-pthread','-lm','-ldl','-o',binary],root)
   assert built['exit_code']==0,built['stderr']
   observed=run(label,[binary],Path(data['commands'][row['run_command']]['cwd']),case.get('stdin',''))
   expected=case['expect'].get('stdout','')
   if 'stdout_file' in case['expect']:
    path=root/case['expect']['stdout_file'];pins[str(path)]=sha(path);expected=path.read_text()
   actual=observed['stdout']
   if case['expect'].get('normalize')=='trailing-newlines':actual=actual.rstrip('\n');expected=expected.rstrip('\n')
   passed=observed['exit_code']==0 and actual==expected and not observed['stderr']
   r['results'].append(dict(case=row['case'],level=row['level'],passed=passed));save();assert passed,(row['case'],observed)
 r['input_sha256_after']={p:sha(p) for p in pins};assert pins==r['input_sha256_after'];r['status']='passed';save()
except BaseException as error:r.update(status='failed',error=repr(error));save();raise
