from pathlib import Path
import hashlib,json,os,shutil,subprocess,time,threading
base=Path(__file__).resolve().parent
root=Path('/home/jacobt/src/goose-to-wasm');output=base/'compatibility-retry';output.mkdir(exist_ok=False)
source=base/'source/native/tests/results.goose';compiler=base/'build/goose';cc=Path(shutil.which('clang')).resolve()
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
pins={str(path):sha(path) for path in (source,compiler,cc,Path(__file__))}
r={'status':'running','input_sha256':pins,'commands':[]}
def save():(output/'report.json').write_text(json.dumps(r,indent=2)+'\n')
def run(name,command,expected=None):
 command=list(map(str,command));start=time.monotonic()
 with (output/(name+'.stdout')).open('w') as stdout,(output/(name+'.stderr')).open('w') as stderr:
  child=subprocess.Popen(command,stdout=stdout,stderr=stderr,cwd=root);timer=threading.Timer(60,child.kill);timer.start();_,status,usage=os.wait4(child.pid,0);timer.cancel();child.returncode=os.waitstatus_to_exitcode(status)
 r['commands'].append(dict(name=name,command=command,exit_code=child.returncode,seconds=time.monotonic()-start,max_rss_kib=usage.ru_maxrss));save()
 assert child.returncode==0,(output/(name+'.stderr')).read_text()[-4000:]
 if expected is not None:assert (output/(name+'.stdout')).read_text()==expected
try:
 for filename,expected in [('results.goose','native result channels ok\n'),('relative.goose','native fixed relatives ok\n'),('images.goose','native images ok\n'),('ordinary_regions.goose','ordinary regions ok\n')]:
  source=base/'source/native/tests'/filename
  pins[str(source)]=sha(source)
  for level in ('O0','O2'):
   stem=source.stem+'-'+level;c=output/(stem+'.c');run(stem+'-emit',[compiler,source,'--stdlib',root/'stdlib','--target','native','--standalone','-'+level,'-o',c])
   for mode,flags in [('release',['-O2']),('sanitized',['-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer'])]:
    name=stem+'-'+mode;binary=output/name
    run(name+'-cc',[cc,'-std=gnu11',*flags,c,'-pthread','-lm','-ldl','-o',binary]);run(name,[binary],expected)
 r['input_sha256_after']={p:sha(p) for p in pins};assert pins==r['input_sha256_after'];r['status']='passed';save()
except BaseException as error:r.update(status='failed',error=repr(error));save();raise
