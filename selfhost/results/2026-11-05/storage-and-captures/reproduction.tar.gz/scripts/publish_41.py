from pathlib import Path
import collections, gzip, hashlib, io, json, tarfile, shutil

root = Path('/home/jacobt/src/goose-to-wasm')
work = root / 'build/completion-runs'
bench = root / 'bench/results/2026-11-05/storage-and-captures'
checks = root / 'selfhost/results/2026-11-05/storage-and-captures'

def read(path): return json.loads(path.read_text())
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path, value): path.write_text(json.dumps(value, indent=2) + '\n')
def gzcopy(source, target): target.write_bytes(gzip.compress(source.read_bytes(), mtime=0))

examples = read(work / 'goose-examples-41/report.json')
host = read(work / 'goose-host-41/report.json')
full = read(work / 'c-only-conformance-41/report.json')
v8 = read(work / 'c-only-v8-41/report.json')
proof = read(work / 'c-only-bootstrap-41/report.json')
comparison = read(work / 'comparison-41.json')
assert examples['status'] == host['status'] == v8['status'] == proof['status'] == 'passed'
assert full['summary']['selected'] == 5118
assert not comparison['shared_regressions'] and not comparison['new_failures']
assert len(examples['observations']) == 410
assert len(host['observations']) == 360 and len(host['preparation']) == 150
assert proof['fixed_point'] and proof['executable_c_sha256'] == proof.get('third_generation_c_sha256', proof['next_generation_c_sha256'])
assert examples['environment']['compiler_sha256'] == proof['executable_sha256']
for report in (full, v8, proof): assert report['input_sha256'] == report['input_sha256_after']
for pins in (examples['environment']['input_sha256'], host['input_sha256']):
    for name, identity in pins.items(): assert sha(Path(name)) == identity, name
for row in host['preparation']: assert sha(Path(row['artifact'])) == row['sha256']

bench.mkdir(parents=True, exist_ok=False)
checks.mkdir(parents=True, exist_ok=False)
for source, target in [('goose-examples-41/report.json', 'examples.json'),
                       ('goose-host-41/report.json', 'host.json'),
                       ('benchmark-window-41.json', 'window.json')]:
    shutil.copyfile(work / source, bench / target)
rows = []
for example in examples['examples']:
    name = example['name']
    rows.append({'name': name,
        'build_ms': {r['backend']: r['wall_seconds']['median'] * 1000
            for r in examples['compile_summary'] if r['name'] == name},
        'process_ms': {r['backend'] + '/' + r['mode']: r['wall_seconds']['median'] * 1000
            for r in host['runtime_summary'] if r['name'] == name}})
save(bench / 'summary.json', {'schema': 'goose-compiler-benchmarks-v1',
    'source_base_commit': 'c196ee8c022d59101488e821b61865c11d69c9d8',
    'compiler_snapshot': '41', 'source_sha256': proof['source_sha256'],
    'asset_sha256': proof['asset_sha256'], 'stdlib_sha256': proof['stdlib_sha256'],
    'bootstrap_c_sha256': proof['executable_c_sha256'], 'compiler_sha256': proof['executable_sha256'],
    'compiler_builds': 'Both measured cohorts use the exact qualified executable.',
    'examples_status': examples['status'], 'host_status': host['status'],
    'compile_samples': 5, 'runtime_samples': 5, 'preparation_samples': 5,
    'compiler_comparison': 'Both targets use the Goose-written compiler. Native uses its C backend at GCC O2. Prior snapshots are separately collected references.',
    'rows': rows})

for folder, name in [('native-runtime-41', 'native-runtime'), ('c-only-bootstrap-41', 'bootstrap'), ('c-only-bootstrap-40', 'parent-bootstrap'),
                     ('c-only-conformance-41', 'conformance'), ('c-only-v8-41', 'v8')]:
    gzcopy(work / folder / 'report.json', checks / (name + '.json.gz'))
gzcopy(work / 'public-41/build/bootstrap/report.json', checks / 'public-bootstrap.json.gz')
shutil.copyfile(work / 'public-41/build/smoke/report.json', checks / 'public-smoke.json')
failures = [r for r in full['results'] if r['status'] != 'pass']
threads = [r for r in full['results'] if r['case'].startswith('upstream/threads/')]
case_targets = {r['id']: r['target'] for r in read(root / 'tests/conformance/cases.json')['cases']}
curated_wasm = [r for r in v8['results'] if case_targets[r['case']] == 'wasm-direct']
curated_native = [r for r in v8['results'] if case_targets[r['case']] == 'native']
assert len(curated_wasm) == 1993 and len(curated_native) == 34
assert all(r['status'] == 'pass' for r in curated_wasm + curated_native)
assert len(threads) == 52 and all(r['status'] == 'pass' for r in threads)
save(checks / 'summary.json', {'schema': 'goose-compiler-qualification-v1',
    'snapshot': '41', 'complete': not failures, 'bootstrap_status': proof['status'],
    'bootstrap_c_sha256': proof['executable_c_sha256'], 'source_sha256': proof['source_sha256'],
    'asset_sha256': proof['asset_sha256'], 'compiler_sha256': proof['executable_sha256'],
    'fixed_point_scope': 'Consecutive C generations match; the parent seed is verified snapshot40.',
    'contracts': full['summary'], 'original_contract_rows': 5043, 'curated_v8_driver': v8['summary'], 'curated_wasm_per_engine': len(curated_wasm), 'curated_native_controls': len(curated_native), 'native_thread_checks': len(threads),
    'existing_contract_gains': len(comparison['shared_gains']), 'existing_contract_regressions': 0,
    'new_contract_rows': len(comparison['new_rows']), 'new_contract_failures': 0,
    'remaining_failure_phases': dict(collections.Counter(r['phase'] for r in failures)),
    'remaining_runtime_failure_detail': read(work / 'remaining-phases-41.json'),
    'remaining_failure_groups': dict(collections.Counter('/'.join(r['case'].split('/')[:2]) for r in failures)),
    'gains': comparison['shared_gains'],
    'permanent_controls': read(work / 'new-controls-41.json'),
    'scope': ['canonical native variable images and byte cursor iteration/copy',
              'aggregate compound assignment evaluation order',
              'full-width free indices and stack instrumentation contracts',
              'captured-function specialization environments and delayed fixed bindings']})

def archive(path, files):
    assert all(p.is_file() for p in files.values())
    with path.open('wb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', mtime=0) as zipped, tarfile.open(fileobj=zipped, mode='w|') as bundle:
        seen = {}
        for name, source in sorted(files.items()):
            data = source.read_bytes(); identity = hashlib.sha256(data).hexdigest()
            item = tarfile.TarInfo(name); item.mode = 0o644
            if identity in seen:
                item.type = tarfile.LNKTYPE; item.linkname = seen[identity]; bundle.addfile(item)
            else:
                item.size = len(data); bundle.addfile(item, io.BytesIO(data)); seen[identity] = name

files = {}
for folder, prefix in [('goose-examples-41', 'examples'), ('goose-host-41', 'host')]:
    for path in (work / folder).rglob('*'):
        if path.is_file(): files[prefix + '/' + path.relative_to(work / folder).as_posix()] = path
for pins in (examples['environment']['input_sha256'], host['input_sha256']):
    for name in pins:
        path = Path(name)
        if path.suffix in ('.goose', '.py', '.mjs', '.json', '.c', '.h', '.gz', '.txt') and path.stat().st_size < 20000000:
            files['inputs/' + sha(path) + '/' + path.name] = path
for name in ('LICENSE', 'NOTICE'): files['native/runtime/' + name] = work / 'snapshot-41/native/runtime' / name
archive(bench / 'measurements.tar.gz', files)

files = {}
for path in (work / 'verified-seed-40').iterdir(): files['parent-seed/' + path.name] = path
for path in (work / 'snapshot-41').rglob('*'):
    if path.is_file() and '__pycache__' not in path.parts: files['sources/' + path.relative_to(work / 'snapshot-41').as_posix()] = path
for name in ('conformance_shards.py', 'front_gate.py', 'freeze_seed.py'):
    files['scripts/' + name] = Path('/dev/shm/goose-completion-work') / name
files['scripts/publish_41.py'] = Path(__file__)
for name in ('prepare_delivery.py', 'render_copy_41.py', 'compare_batch.py'): files['scripts/' + name] = work / name
for index in range(4):
    folder = work / 'c-only-conformance-41'
    gzcopy(folder / ('shard-' + str(index)) / 'report.json', checks / ('conformance-shard-' + str(index) + '.json.gz'))
    files['qualification/cases-' + str(index) + '.json'] = folder / ('cases-' + str(index) + '.json')
for name in ('snapshot-41-assembly.json', 'comparison-41.json', 'new-controls-41.json', 'public-smoke-preflight-41.json', 'remaining-phases-41.json', 'astra-remaining-41.md', 'astra-next-contract-hills.md', 'astra-flow-capture-audit.md', 'astra-print-fastpath.md'):
    files['notes/' + name] = work / name
for folder, names in {
    'native-images-I12': ['qualification.json', 'changed-paths.json'],
    'aggregate-compound-v1': ['handoff.json', 'handoff.md', 'aggregate-compound.patch'],
    'runtime-contracts-v2': ['qualification.json', 'checker.goose.patch', 'storage.h.patch', 'selfcheck.json'],
    'semantic-round-ec': ['qualification.json', 'delayed-captured-flow.patch'],
}.items():
    for name in names:
        files['components/' + folder + '/' + name] = work / folder / name
for name in ('cases.json',): files['qualification/' + name] = root / 'tests/conformance' / name
files['qualification/conformance.py'] = root / 'tests/conformance.py'
for pattern in ('flow_*.goose', 'compound_*.goose', 'free_*.goose', 'captures_*.goose'):
    for path in (root / 'tests/fixtures').glob(pattern): files['qualification/fixtures/' + path.name] = path
for path in (work / 'readme-copy-41').iterdir():
    if path.is_file(): files['copy/' + path.name] = path
# Include selected source, controls, raw targeted reports and rejected checkpoints.
for folder in ('semantic-round-ea', 'native-images-I12', 'aggregate-compound-v1', 'runtime-contracts-v1', 'runtime-contracts-v2', 'semantic-round-ec'):
    for path in (work / folder).rglob('*'):
        if path.is_file() and '__pycache__' not in path.parts and path.suffix in ('.goose', '.h', '.c', '.py', '.json', '.md', '.patch'):
            parts = path.relative_to(work / folder).parts
            if 'artifacts' in parts: continue
            if path.suffix == '.c' and not ('source' in parts and 'native' in parts and 'tests' in parts): continue
            if 'upstream' in path.relative_to(work / folder).parts: continue
            files['components/' + folder + '/' + path.relative_to(work / folder).as_posix()] = path
archive(checks / 'reproduction.tar.gz', files)
print('published evidence', bench, checks)
