from pathlib import Path
import hashlib
import json

root = Path('/home/jacobt/src/goose-to-wasm')
work = root / 'build/completion-runs'

def read(path):
    return json.loads(path.read_text())

examples = read(work / 'goose-examples-41/report.json')
host = read(work / 'goose-host-41/report.json')
proof = read(work / 'c-only-bootstrap-41/report.json')
comparison = read(work / 'comparison-41.json')
assert examples['status'] == host['status'] == proof['status'] == 'passed'
assert not comparison['shared_regressions'] and not comparison['new_failures']

build = {(r['name'], r['backend']): r['wall_seconds']['median'] * 1000 for r in examples['compile_summary']}
runtime = {(r['name'], r['backend'], r['mode']): r['wall_seconds']['median'] * 1000 for r in host['runtime_summary']}
direct = [value for (name, backend), value in build.items() if backend == 'direct']
native = [value for (name, backend), value in build.items() if backend == 'native']
summary = comparison['candidate_summary']
facts = {
    'PASSED': f"{summary['passed']:,}",
    'TOTAL': f"{summary['selected']:,}",
    'FAILED': str(summary['failed']),
    'MACHINE': 'AMD Ryzen 7 3800X pinned to CPU 7',
    'SAMPLES': 'Five',
    'DIRECT_BUILD_RANGE': f'{min(direct):.1f}–{max(direct):.1f}',
    'NATIVE_BUILD_RANGE': f'{min(native):.1f}–{max(native):.1f}',
    'SORTING_AOT': f"{runtime['sorting', 'direct', 'precompiled-minimal']:.1f}",
    'SORTING_NATIVE': f"{runtime['sorting', 'native', 'native-C']:.1f}",
    'BENCHMARK_CONTEXT': "The native column uses this compiler's C backend. Snapshot 40 was measured separately; these runs do not establish a matched runtime improvement.",
    'BOOTSTRAP_STATUS': 'Snapshot 41 passed C-only fixed-point verification; its final two generated C outputs match.',
    'CHANGE_SCOPE': 'Canonical native variable storage, aggregate assignments, captured function state and delayed bindings.',
    'CONFORMANCE_CONTEXT': 'Against snapshot 40, 41 of 5,043 shared checks improved and none regressed. All 75 new source-authored checks passed.',
    'WASM_CORPUS_CONTEXT': 'The curated Wasm corpus passed 1,993/1,993 checks each in Wasmtime and V8; all 34 curated native controls also passed.',
    'KNOWN_GAPS': 'Remaining gaps include 38 accepted invalid programs and 166 runtime contracts that fail to compile or execute. Lifetimes, control flow and native image operations remain incomplete.',
    'FAILURE_PHASES': 'The 204 remaining failures comprise 38 invalid-program checks and 166 runtime contracts.',
    'GENERATED_C_SHA256': proof['executable_c_sha256'],
    'COMPILER_SHA256': proof['executable_sha256'],
    'RUNTIME_WARMUPS': 'one',
    'METHOD_AND_IDENTITIES': 'Both targets use the exact qualified Goose compiler at Goose O2; native C uses GCC 16.2.1 O2. Engines are Wasmtime 50.0.1 and Node 24.22.1. The operating-system page cache is retained.',
    'COHORT_CONTEXT': 'The compiler, source, standard library, workload and tool identities are pinned in the raw reports. Agents paused expensive work during this shared-machine measurement window.',
    'GUARD_EVIDENCE_LINK': 'The [qualification source capsule](../../../../selfhost/results/2026-11-05/storage-and-captures/reproduction.tar.gz) retains the paired checker guard, exact commands and sources.',
    'REJECTED_EXPERIMENTS_AND_EVIDENCE': 'The same capsule retains rejected aggregate-assignment, stopped-index and captured-state attempts, targeted raw reports and their tradeoffs.',
}
rows = []
for example in examples['examples']:
    name = example['name']
    rows.append(f"| {name} | {build[name, 'direct']:.2f} | {build[name, 'native']:.2f} | {runtime[name, 'direct', 'precompiled-minimal']:.2f} | {runtime[name, 'native', 'native-C']:.2f} |")
facts['EXAMPLE_ROWS'] = '\n'.join(rows)
targets = {
    'README.md.in': root / 'README.md',
    'selfhost-README.md.in': root / 'selfhost/README.md',
    'bench-README.md.in': root / 'bench/README.md',
    'dated-results-README.md.in': root / 'bench/results/2026-11-05/storage-and-captures/README.md',
}
for template, target in targets.items():
    text = (work / 'readme-copy-41' / template).read_text()
    for key, value in facts.items():
        text = text.replace('{{' + key + '}}', value)
    assert '{{' not in text, template
    target.write_text(text)
(root / 'bench/results/2026-11-05/storage-and-captures/copy-facts.json').write_text(json.dumps(facts, indent=2) + '\n')
for name, report in [('examples-latest.json', 'examples.json'), ('wasmtime-host-latest.json', 'host.json')]:
    path = root / 'bench/results' / name
    current = read(path)
    report_path = '2026-11-05/storage-and-captures/' + report
    current.update(report=report_path,
                   sha256=hashlib.sha256((root / 'bench/results' / report_path).read_bytes()).hexdigest())
    path.write_text(json.dumps(current, indent=2) + '\n')
print('Rendered Terra41 templates from qualified measurements')
