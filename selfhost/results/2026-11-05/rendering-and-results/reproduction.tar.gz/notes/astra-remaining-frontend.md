# Remaining frontend: loop assignment and captured flow

Read-only review, 2026-11-05. No compiler, oracle, benchmark, or suite was run. Sources inspected: qualified semantic DH `/dev/shm/goose-selfhost-work/semantic-round-dh/source/selfhost/checker.goose`; frozen primary `build/source/src/typecheck_{flow,calls,exprs}.h`, `build/source/docs/goose_spec.md`, and frozen test fixtures. Live compiler files were not edited. Candidate36 reports were still running when inspected; the three requested negatives were present among its failures. Those reports do not measure the proposed change.

## Exact gaps

- `CheckFlow` already stores all needed assignment facts: `assigned`, `maybeassigned`, `narrowed` (line 25). No second assignment lattice is needed.
- `check_loop` (4199) takes an entry snapshot, checks once, and only retries if an optional narrowing weakened. It never compares or feeds assignment facts across backedges.
- `check_jump` (4314) saves break flow but discards continue flow. `check_loop_continue` merely finds syntax, which cannot recover the state at that continue and cannot distinguish reachable edges correctly.
- `check_apply_call_effects` (3273) already propagates kind 6 (may assign; checks immutable reassignment), kind 4 (definitely assigned on normal exits), and kind 5 (rebind/un-narrow). `check_assignment_target` (4807) records kind 6. A new special HOF assignment effect is unnecessary.
- `check_flow_save` (3530) normally captures lexical function frames only. In `each<F>`, the lexical parent is global; the calling `main` activation's `x` is missing although calling F changes its `CheckVariable`. `active_callers=true` exists and is used by `check_function` entry snapshots; loop entry and edge snapshots need that coverage too.
- This caller omission also affects `check_if`, logical expressions, and exit joins inside a HOF. Fixing only the loop snapshots catches the direct fixture but does not establish correct captured flow through branches.

## Smallest useful patch: validate real backedges without replaying assignments

Recommend this bounded patch before a general flow fixed point. It uses the existing assignment lattice and avoids cloning loops solely to rediscover a reassignment.

1. Extend `CheckLoop` with an entry `CheckSpan` (captured before a while condition) or keep that span local and inspect saved edges at `check_loop` end. Capture the entry with active callers. Symbols declared in the body are deliberately absent.
2. Record every reachable continue with its actual flow, and record body fallthrough only when `c.reachable`. Do not infer either from AST occurrence. The continue must target the resolved loop chosen by `check_jump`, preserving the const-for boundary and early-block skipping rules.
3. For each entry symbol and each matching backedge, diagnose if it is immutable, entry `maybeassigned` is false, and edge `maybeassigned` is true. This means the binding was initialized on a path that can enter another iteration. A binding already maybeassigned at entry is covered by existing assignment/call checks. A `var` is excluded. A body-local `let` is excluded by the entry projection. A break/return-only write is excluded because it reaches no backedge.
4. Report at the loop or saved edge token, with the existing let-reassignment diagnostic class. If precise assignment locations are wanted later, add a provenance token separately; it is not needed for this semantic repair.
5. Reuse the actual backedge states for narrowing weakening and remove `check_loop_continue`. The current final-body state misses a rebind present only on a continue path.

Why the direct test is sufficient for this immutable rule: a surviving new may-assignment at a backedge would make that assignment illegal on a subsequent checker pass. Conversely, writes that leave only by break/return are absent from the backedge projection. This is a path analysis, not a blanket rule forbidding writes anywhere in a loop.

### CheckExit representation

Two reasonable representations; choose one, not both.

- Smallest structural delta: add `backedge: bool = false` to `CheckExit`. Continue pushes `{target: loop.node, flow, backedge: true}`; normal fallthrough can be inspected directly or recorded similarly. `check_join_control_exits` (3593) must skip backedges, or continue would incorrectly make a nonterminating `loop` exit and give it assignment guarantees. `check_function`'s exit-summary scan (4901) should also explicitly skip backedges. Returns and breaks keep default false. The new `CheckLoop` entry field is then optional because `check_loop` can examine records from its local `exit_start`.
- More localized alternative: `CheckLoop { backedge: CheckSpan, has_backedge: bool }` plus one helper to join each arriving edge. The helper must restore the current edge's flow after joining so bookkeeping cannot alter subsequent branch checking. This leaves `CheckExit` unchanged and naturally separates breaks and backedges.

Do not encode continue targets as negative node IDs. Explicit edge kind/presence is simpler to audit.

### Active caller coverage and branch joins

The invariant is: a flow save/restore/join must cover every variable a checked call on that path can mutate, including a caller variable reached through a static function value. The simplest correct coverage change is `check_flow_save(... active_callers: bool = true)` for all control-flow snapshots, with explicit false only where lexical-only behavior is intentional. The existing function entry caller-save remains unchanged. Audit caller coverage of break and return snapshots too: `check_jump`, `check_return` (4631), and normal function exits (4897) currently use the default false.

Measure this choice: active mode enumerates frame variables beyond lexical visibility, including old locals from cloned scopes. It increases flow snapshot size. A later optimization can track each suspended caller's actual lexical scope, or use a capture projection, but neither is required to express the rule. Do not silently use lexical-only branch snapshots between active-caller loop entry and backedge snapshots: a conditional F call can otherwise manufacture definite assignment or retain a write from an unreachable branch.

### Literal zero/one iteration policy

Primary `TypeCheck::CheckLoopPasses` (`typecheck_flow.h:1727-1776`) reaches a flow fixed point for every loop. `CheckFor` invokes it without a constant 0/1 bypass (1980-2016). Its own specification says assignment is illegal if any path may already have assigned the binding (§4.4, spec lines 1367-1374). The DH `count.value <= 1` repeated-loop shortcut has no counterpart in that implementation.

Do not accidentally declare new acceptance rules for `for i in 0/1`, `0..1`, or a length-one array. Treat these as explicit policy gates against frozen primary behavior. Source-based conformance favors removing the shortcut for static repeat analysis. Runtime zero/one behavior still must be preserved for loops that are well typed, and assignment-free zero/one loops must not acquire definite-assignment guarantees from executing the body during checking. No oracle was run in this review, so these newly authored gate outcomes are source-derived, not measured.

## If implementing the full loop fixed point instead

Primary model: `head = entry join every real backedge`; repeat only if projected facts changed, recheck while condition at the head, and use only the settled pass's breaks and false-condition exit. A `for` exits at its head; `loop` exits only through breaks. Snapshot/compare only entry symbols; fresh cloned body symbols are not part of convergence.

Important existing append-only state:

- `exit_work` is grow-only. Replaying clones appends returns and breaks from provisional passes. Merely moving a loop-local `exit_start` is insufficient: the enclosing function later scans all its exits and would still see provisional return records. Invalidate those provisional records (e.g. `target=-1`) or give records an active pass identity honored by every consumer. Do not clear unrelated exits from an enclosing checker invocation.
- `check_clone` clears checked/symbol/scope/capture facts and creates fresh function-value identities. Repeating checked syntax can therefore grow specialization tables and capture/effect tables. `check_note_effect` deduplicates only identical `(function_node, root, kind)`, not fresh clone identities.
- Function kind-4 summaries reflect normal exits; stale summaries from a provisional function body cannot be treated as settled facts. Generic/closure cached effects require care when assignment state changes. Direct backedge validation avoids introducing this problem for the three requested cases.
- Fresh loop-body declarations must remain fresh per iteration/activation. Never replay by retaining their assigned bits as loop-entry facts.

I would land the direct backedge assignment check and real continue state first, then pursue general reference/root convergence as a separately measured hill.

## Gates

Frozen negatives that must reject: `errors_tc/let_assign_in_while`, `let_assign_after_continue`, `let_assign_funval_loop`. Keep the full existing let-error family as controls: after-block-break, after-andand, in-own-value, nested_fn_reused/key/return_from, recursive.

Frozen positive that must retain exact output: `typing/let_assigned_once.goose`, especially `declared_in_loop`, `assigned_at_break`, `nested_init`, `block_once`, `per_activation`, and `far_exit`. Keep `codegen/continue_restores` and `optimizer/bce_block_continue` as control-flow controls.

Small new complementary probes:

- Positive: outer `let` assigned before an unconditional `break`; outer `let` assigned before unconditional function `return`; both inside nested plain/early blocks. A continue path that does not assign must not import the assignment from a different break-only branch.
- Positive: fresh inner `let` assigned once in each loop iteration; nested/static closures assigning their own newly declared local; recursive function assigning its own local per activation.
- Negative: assignment then conditional continue with a separate fallthrough path; assignment in a while condition through a nested call; nested inner-loop continue must affect its own loop, not outer target.
- Negative: `each(2)` invokes a block that calls another nested initializer of caller `x`; an intermediary generic HOF forwards the same block; an F call on either branch may assign `x`.
- Branch controls for caller snapshots: HOF calls F on one branch and returns on the other (not definitely assigned); mutually exclusive branches call F once each (definitely assigned on normal exit); assignment on only a terminating branch must not contaminate the surviving loop backedge.
- Literal 0/1 count, singleton range/array, `while false`: retain source-derived acceptance/rejection policy explicitly; do not claim runtime cardinality makes the binding definitely initialized after a possibly empty loop.
- Recursive closure control: external captured let cannot be assigned by a recursive cycle; a let freshly declared within each activation remains valid. Include assignment after the recursive call, since the current repeat trigger only scans kind 5 and may not discover delayed kind 6 transitively.

Measure bootstrap stage equality, focused exact stdout/error phases, full conformance, flow-work growth if instrumented, and wall time/peak RSS against the same compiler/source/workload. The direct patch should add linear entry/edge comparison, not whole-loop AST replay. Do not claim a suite-total gain from the running snapshot36 reports.

## Three other precise frontend hills

1. **Logical right-operand invalidation.** `check_expression` logical handling (3987) merges immediate states, but `check_narrow_condition` (1813) later recursively re-applies the left test and loses the fact that the right call rebound the variable. Primary `CheckLogical` stores `rightkills` and `NarrowCond` reapplies those kills. Capture the narrowed-middle span before checking RHS; persist killed symbol IDs per logical node in a checker side table/list; apply those kills after recursive condition narrowing. Use active-caller coverage. Gates: `optional_andand_local_rebind`, `optional_oror_rebind`, plus successful ordinary `if opt && predicate()` where predicate does not rebind. Existing joins already carry maybeassignment; preserve that.
2. **Parameter-default lexical validation.** `check_parameter_default` (1865) moves directly to the declaration's parent and checks cloned syntax, which can silently choose a global where a prohibited parameter shadows it, or allow captured outer locals/functions. Primary `DefaultScopeName` (`typecheck_flow.h:640+`) first diagnoses forbidden meanings in declaration scope. Add an explicit parameter-default context and validate ordinary name/call lookup against parameters, enclosing locals, and nested functions before top-level resolution. Preserve qualified `::name`, generic type substitution, permitted global calls, and locals declared inside the default's own nested expression. Gates: `param_default_names_param`, `param_default_names_local`, `param_default_names_nested_fn`; do not fix by merely searching token spellings.
3. **Nested declaration reached at call time.** `check_function_shadowed` (2987) filters an unreached nested candidate only when `s.owner == c.function_node`, so a sibling's body can bind an as-yet-unreached nested function and use it too early through a call. Keep lexical overload resolution, then check the resolved nested declaration's reached marker (`Symbol.index`) against its active owning activation before applying/checking the call. A cached specialization must still revalidate this at each call. Primary `CheckCall` validation is `typecheck_calls.h:1370-1398`. Gates: `nested_fn_called_before_declaration`, `init_nested_fn_called_before_declaration`, plus valid mutually recursive nested declarations reached before the first call and later overload shadowing.
