# Native variable-storage continuation

Read-only review, 2026-11-05. Only this plan was written. No compiler, C++ oracle, build, benchmark, or golden updater was executed. The six inspected native/codegen files match the immutable H5 source hashes in `native-relative-H5/qualification.json`; H5 compiler SHA256 is `0fd5913af774e6928794b91a9c94bd4b481828229987600f3793cfe78f58106d`. Frontend work and the combined qualification are separate.

## Recommendation

Complete **one physical-image location and construction path**, reusing `CcPlace`, `CcDestination`, the existing image walkers, and stable `GRegion` stacks. Start with nonrelative varint fields and variable records, then variable element runs, frame tails, relative cells, and verified loading. Keep fixed H5 lowering intact while each new shape is gated. Removing `cc_temp`'s refusal and setting `cc_frame_size(varint)=8` is not a solution: it leaves field addresses, array strides, `varint&`, `bytes_of`, and relative origins wrong.

The useful distinction is storage versus value, not small versus large. A varint expression is decoded `i64`; a varint place is an address of canonical zigzag bytes. A relative-reference expression is `GRef`; its place is a canonical cell at its real address. A variable aggregate expression is an image location, not an unpacked C struct. A frame object's native header is never canonical image data.

## Evidence and likely gains

H5 has 24/44 relative rows passing. Seven remaining contracts are stopped by native refusals: `storage/relative_block_results`, `storage/self_relative_adt_payloads`, `codegen/relative_declarations`, `relative_operands`, `relative_optional_null`, `relative_reference_of`, and `relative_results` (14 O0/O2 rows). `typing/const_for_constructors` and `const_for_control` add four rows stopped by varint fields. These **18 rows are the directly evidenced next targets**, not promised passes; lowering can expose subsequent bugs.

Three other H5 relative contracts still have frontend errors: `relative_copy_forms`, `relative_destination_results`, `stdlib_relative_elements`. Do not weaken copy/root checking in native code to claim them.

Snapshot 32 contains 110 rows / 55 contracts with the old shared encoded-integer/reference refusal. That count includes fixed-relative cases H5 already repaired, so it is not a remaining-gain estimate. High-value additional probes are `varint_field_references`, `rendered_varint_storage`, `rendered_varint_results`, `varint_elements`, `print_variable_size_elements`, `fill_evaluation`, `push_argument_order`, `frame_pool_references`, `variable_prefix_frame_tail`, `serialize`, and `serialize_image_checks`. Recount from the combined report before assigning a delivery target.

## 1. Make locations carry their representation

In `codegen_c_storage.goose`, name the existing `form` meanings and add a canonical-image form alongside decoded scalar/native-frame storage. Derive physical size class independently of `Type.size`: the current checker uses zero for varint size and frame/owner footprints for some variable records and ADTs. Preserve those IR facts and H5 packed fixed offsets; never substitute `sizeof(g_t)` for a dynamic image extent.

Change `cc_place` / `cc_base` to preserve the complete `CcPlace`, rather than discarding everything except its address. Use its existing `stack`, `owner_header`, and `image_base`; add information only where an actual call/reference boundary needs it. `cc_read`, `cc_write`, `cc_construct_into`, field access, dereference, match/dispatch, and array views must consume the same place representation.

For native frames, `cc_field_offset` retains its current meaning. For image places, emit a field cursor: combine consecutive fixed byte spans, then call `g_image_skip_<field>` over each preceding variable field. Explicit pads advance by their explicit byte count; bare alignment pads do not align a bytes layout. Keep the original aggregate address through self-relative reads, printing, equality, generic reference arguments, and payload binders.

Extend `cc_images_used` beyond serialization/thread builtins: ordinary variable-storage programs need skip/walk helpers too. Generate only reachable helper types, with prototypes before recursive definitions. Reuse the field walk in `ci_fields`; do not create independent layout algorithms for field access, print, equality and serialization.

**First acceptance:** fixed H5 probes still pass; a `{n: varint, text: u8[], tail: i64[]}` record can construct, read each field through `T&`, and preserve `varint&` identity. This is the minimum real fix for the two const-for cases.

## 2. Build varints and variable records at a byte cursor

Add a byte reserve/commit adapter over `GRegion.stack`, not another allocator. Keep element count and byte end separate. `g_reserve`/`g_set_len` currently derive the top from `count * width`; variable storage must use an explicit end cursor. Do not make `width=0` a hidden alternate ABI. A small `g_image_commit(owner, end, count)` can update the existing header/publication chain while retaining the actual byte top.

A root variable image needs a region allocated by the region plan even if it contains no resizable field. Nested image fields use that root's cursor and do not allocate one region each. Adjust `cc_region_width`, `cc_seed`, `cc_result_temp`, and `cc_restore` around this ownership distinction; keep a borrowed image view separate from its owner. An `A_VAR` image contains its actual count prefix. A resizable array's element run has its count in the native owner header. Do not conflate those forms.

In `cc_read` / scalar helpers, decode a physical varint with existing `gs_zig_read`; when the wanted type is `varint&`, return its physical address. An unannotated read is `i64`. Formatting a decoded read via `i64&` materializes a readonly i64 temporary; structurally formatting a varint field retains varint formatting. Existing pinned `gs_zig_write`, `gs_uleb_write`, `gs_uleb_size` and checked variants already supply the codec.

In `cc_construct_into`, evaluate the scalar expression first, reserve at most ten bytes, encode once at the final cursor, and advance by the actual length. Apply to literals, defaults, calls, control expressions, globals and generic instantiations. An exit during evaluation must leave no partially committed cell. For a record, write fields in the checked declaration order, capturing the literal start before its first prefix/tag. Fixed-width fields in a variable image use unaligned-safe stores.

Stop calling the current `g_image_unpack_varint` into ordinary record offsets: it writes eight decoded bytes, while the current encoded field size is zero. Keep any required frame-to-image adapters explicitly named/typed; the image-view path should copy/view canonical bytes, not unpack them.

**Gate:** varint extrema, 63/-64/64/-65/8191/-8192 transitions, sentinel bytes after fields, mixed prefixes, nested records, generic references, rendering hooks, all constructor/control exits. Then the two complete const-for contracts, O0/O2.

## 3. Variable element runs and array adaptation

Replace stride-based paths only for variable elements. `cc_loop`, structural print/equality, array copy/append, and slice iteration need parallel cursors advanced with `g_image_skip_<element>`. Keep an integer ordinal separately. Put cursor advance on the `continue` path as well as ordinary fallthrough; `break` must skip it. Variable-element indexing and pop remain checker-rejected where upstream rejects them; do not silently add linear indexing as a workaround.

In `cc_array`, push and append, claim the final element address after evaluating scalar arguments that may grow the receiver. Construct aggregates at that address. Publish count only after successful construction. Freeze fill leaves once and encode each destination separately; do not evaluate a side effect once per element. For loop growth/reference rebind behavior, preserve the existing checked reread semantics instead of unconditionally caching a header or stale count.

For the same element layout, a legal whole element-run/root copy is one `memmove` over the actual byte span, including self-relative bytes. Array prefix adaptation changes only the outer prefix. Reserve/patch or slide it as a unit, retaining every internal distance. Never decode/re-encode relative leaves while copying an established root. Capacity checks still use the natural result's contract before adapting a fixed/limited result into another array kind.

**Gate:** full `varint_elements` (including 130-element varint prefix, 200-element returned array, fill-once, reference results, nested arrays and global tail), `print_variable_size_elements`, `slot_type_construction`, `push_argument_order`; inspect exact byte images, not only printed values.

## 4. Frame objects behind variable prefixes

Keep the useful native frame form for fixed-prefix resizable objects, but give it an explicit bytes view/constructor when embedded behind a variable prefix. Port the *rules*, not the C++ machinery, of `FoBytes`, `FoView`, `GenFoAsBytes` and `FieldLocAt`.

Fixed fields of the embedded frame are bytes at the cursor. Its nested resizable tail's count/region belongs to the enclosing owner; no `GArray` or region pointer is written into the image. The same type held independently can retain its native frame and tail header. Distinguish root entry, aggregate start, and tail start: clearing/reassigning a tail rewinds only to the tail start, preserving preceding fields/prefixes.

`CcPlace.owner_header` is sufficient for an immediate field operation, but compile-time metadata alone does not survive an escaping reference, function argument, closure capture or returned reference. Decide this ABI deliberately: reuse the current header-based `GRef` when it names the genuine owner; for a resizable subview with a different data start, transport the necessary owner/stack relationship in a typed reference adapter. Do not return a pointer to a statement-local proxy header or copy a tail header whose mutations never publish back. Ordinary references and relative expressions remain eight-byte `GRef`; no widening of canonical relative cells.

Audit `cc_emit_map`, `cc_emit_store`, `cc_emit_clone`, `cc_match`, `cc_dispatch`, nonlocal-return publication and activation restore. Whole-copy semantics copy the owner and tail into the receiver; views retain the original tail and count. By-value parameters must not accidentally become mutating views of caller storage.

**Gate:** `variable_prefix_frame_tail`, `shrink_frame_prefix`, `frame_pool_references`, nested frame defaults, whole/subtail reassignment, returned/named/captured tails, and early return abandoning a partly constructed prefix. Retain old flat/thread gates after changing ownership.

## 5. Relative cells in images, then verified loading

Extend `native/relative.h` with cursor-oriented varint load/store using the existing codecs: self offsets use zigzag; named-pool offsets use ULEB from the current thread's pool data base minus one **byte**. Use integer overflow checks before address addition. Optional zero alone is null; nonoptional zero may name the current cell. Optional nonnull zero offset aborts. Existing fixed narrow checks remain mandatory.

A varint-relative cell is construction-only where upstream says so. Standalone explicitly relative declarations/parameters still encode storage and check conversions at argument evaluation time. Their private storage capacity may exceed the actual encoded length, but must never become an element stride or field width. Scalar/generic function results stay decoded references. `self` uses the captured owning literal start; ADT-vs-payload targets differ by the tag, and pool `self` requires the final pool element address.

The current `ci_verifiable` must not simply return true for relative types. Separate serialization eligibility from native transfer eligibility: public byte builtins reject plain references, slices and named-pool links, even where private thread transfers permit some of those forms. `ci_emit_type`'s current relative panic must be replaced only for the valid image form.

Extend the existing typed verifier with root payload base/end and root element identity. Fixed relative roots need bounds plus element-start modulo/tag checks; variable relative roots need one framing pass marking starts, then a link pass. Reuse pinned `gs_uleb_check` / `gs_zig_check` and bitmap macros. Bound offsets numerically before adding them. Check variant-target payload offset and the expected tag. Preserve rejection of links into arbitrary typed subfields. The documentation's broad zero-null wording is less precise than `EmitVerifyLink`: nonoptional zero is accepted when it actually names a valid element start.

`cc_from_bytes` must validate the entire payload before exposing pointers or changing the visible result. On success copy the whole canonical payload into the final region and publish the returned element count; do not unpack relative elements into unrelated frames. On failure return empty/false. `bytes_of` returns the original element span without allocation; `to_bytes` prefixes its byte length and copies it. Preserve the public endian check, canonical ULEB, exact-end check, active-slot-only limited validation, zero-size-element rule and bounded bitmap allocation.

**Gate:** all seven native-blocked H5 relative contracts, full serialization contracts, plus malformed corpus for unterminated/overlong/overflowing ULEB, truncated tags/fields, links into cell interiors/end/outside root, wrong variant tags, optional zero, valid nonoptional self-zero and nested limited slots. ASan/UBSan direct helper probes cover both fixed and varint paths. Do not infer relative verifier coverage from the old nonrelative mutation run.

## Result-channel ABI seam: implement independently, before general variable forwarding

The current natural result is one `g_t<tuple>` and `cc_convert` can only adapt equal-arity tuples. A single contextual receiver cannot safely receive the first natural channel of a tuple and preserve other channel effects/ownership. Use the existing `CcReceiving.ordinal` as the authoritative mapping; it currently serves mostly named locals.

Build receiving entries from the **natural function signature**, before contextual conversion. Each ordinal chooses a real caller receiver or a scratch/discard destination. Emit calls with independently addressable receiving channels; keep single scalar returns fast. This requires coordinated changes to `cc_function_type`, function signatures/bodies, `cc_call`, `cc_dispatch`, `cc_values`, `cc_return`, named results, closures and nonlocal-return publication. A whole-tuple output pointer or a `memcpy` of its prefix cannot provide this guarantee. Dropped results must still be evaluated and may need live receiving regions until their effects are complete.

Then select/adapt natural channel zero for scalar contexts, and forward matching channels directly into nested receivers. Relative/varint scalar channels hold decoded values; encode only at a storage destination. Cross this seam once for fixed H5 and variable images, rather than creating a second special call ABI for varints. Focus on `dispatch_result_prefix`, `discarded_resizable_results`, `forward_adaptation`, `multi_value_reference_results`, `reference_element_results`, `named_result_destinations`, then mixed fixed-relative/image/scalar tuples with discarded channels and nonlocal returns.

## Qualification and rejected shortcuts

Keep explicit refusals for every not-yet-covered form and retain H5 and failed candidate evidence. This review rejected alternatives by semantic inspection; it did not benchmark experiments. Rejected: decoded eight-byte fields masquerading as image cells; serialized temporary per read/`bytes_of`; per-element unpack/repack for root copies; fixed stride for variable elements; runtime owner headers inside canonical bytes; counting bytes as elements; advancing owner top by `len * width` after variable growth; using the 4096-byte optimization threshold as a semantic ABI rule; and prefix `memcpy` for tuple-to-scalar adaptation.

Qualify each coherent stage at O0/O2, then freeze one combined source for all 5021 contracts, the complete prior native-pass set, all 53 thread contracts, own selfcheck, and the three-generation C-only proof. Preserve frozen inputs. Measure compiler emit wall/RSS, emitted-C compile wall/size, variable traversal/construction/copy time, region peak/high-water and legacy allocation bytes; use the same source/compiler/workload/engine pins. Pay particular attention to accidental quadratic cursor rescans: iteration must advance once, not locate element i by starting at zero each time. Only qualified delivered changes enter README text/charts/dated evidence and a verified `origin/main` push.

Primary anchors: `build/source/src/codegen_values.h::{FieldPtr,RawArrayView,FieldLocAt,RelParts,LoadLoc}`; `codegen_construct.h::{GenConstruct,ConstructFromLoc,GenArrayFromLoc,FoBytes,FoView,GenFoAsBytes,GenFieldInits}`; `codegen_calls.h::{EmitCall,EmitReprefix}`; `codegen_frames.h` natural-result signature loop; `codegen_types.h::{Cls,VerifyFn,EmitVerifyWalk,EmitVerifyLink}`; `build/source/docs/design/serialization.md`; frozen upstream cases under `/dev/shm/goose-completion-work/c-only-conformance-32/upstream/test`.
