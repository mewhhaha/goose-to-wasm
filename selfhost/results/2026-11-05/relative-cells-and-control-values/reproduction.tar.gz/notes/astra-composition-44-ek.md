Batch 44 replacement review — 2026-11-05

**EM passes source review and the independent targeted runtime checks.** Use `semantic-round-em/break-join-snapshot43.patch`, not the rejected EJ v4, EK or EL artifacts. The owner has sealed these exact bytes after 2,800 frontend cases with no regression, 454/454 layout probes, 82/82 native/Wasmtime rows, 32/32 V8 rows, and the own-source check (57.703 seconds). Final handoff/source-seal hashes were added to the reviewed pins. Combined canonical release qualification remains the publisher's responsibility.

Three demonstrated defects were corrected:

- **Accumulated integer range:** EJ v4 rejected reachable exits `300, 1, typed u8` after retaining only the last literal's range. EK keeps every accumulated value available, applies the primary signed-integer-constant common-type rule, validates a proposed changed type against the entire prefix, and falls back only to a previously valid common type that accepts the new value. The explicit I64-fit guard keeps unsigned constants above I64.max out of signed range aggregation, matching primary `IntConsts`. Selection does not adapt AST nodes or record named reliance early. The typed-first constraint remains in `check_jump`; later typed f64 still cannot replace an established typed-f32 break.
- **Committed float width:** EK accepted a typed-f32 break, then `break 0.1`, then an f64 early-block tail, but printed `0.1` after retyping the committed f32 literal back to f64. EL's one-line validated F32-to-F64 return preserves the operand AST width; the receiving operation widens the already rounded value. Primary `CheckBreak`/`CheckValue` establish the f32 node, while `RetypeBranch` only recomputes floating branch nodes when the destination is f32. This also preserves unary, nested IF/early-block and loop-result rounding. A literal that occurs before the typed anchor remains uncommitted and correctly yields f64 `0.1` where the final result is f64.
- **Inferred early-block result:** EL's final `check_inferred_result` traversed an early block as if it were a plain tail-only block, replacing the checked joined I64 type with its u8 tail. Both O0 and O2 then printed `44 1 8` for the inferred early-block result expected to print `300 1 8`. EM excludes `F_EARLY` from that plain-tail recursion and retains the whole construct's joined result and roots. Primary `CheckInferredResult` likewise consumes the checked construct value. Owner controls cover direct, IF, MATCH and explicit-return wrappers.

Independent verification performed here:

- `astra-review-44/ek-pre-floatfix-probes.json` records the original integer regression fixed in EK and the bare-float width mismatch reproduced with its full compiler.
- `astra-review-44/el-review-probes.json` records native O0/O2 loop-range success, inferred early-block `300 -> 44` failures, and the correctly rounded float output line alongside the separate existing named-countervalue failure.
- `astra-review-44/em-review-probes.json` records 21 successful commands: native O0/O2 generation, GCC compilation and exact execution for loop range, inferred early-block range, and float-width controls, plus preserved typed-f32-first, nested-typed-f32-first and nested-named-reliance refusals. Compiler/source/patch hashes and source bytes are pinned in that report.
- Owner EM evidence reports 82/82 native plus Wasmtime and 32/32 V8 rows at O0/O2. Its grouped integer program executes 93 valid permutation/nested/wrapper rows; the original controls' expectations were not replaced by candidate output. `early-result-type-proof.json` confirms all four representative inferred results stay I64.

**Existing named-constant widening bug remains separate.** `let f: f32 = 0.1; let d = f as f64; print(d, d + 0.0);` prints unrounded f64 tenths in both canonical43 and EL, at O0/O2 on native and Wasmtime. The first float-width comparison control encountered that pre-existing path in its stored countervalue; the actual returned early-block values already printed the correct widened f32 numbers. Original failed controls and expectations are preserved in EL. EM uses independently specified exact f64 countervalues (`0.10000000149011612`, and its negative) so the newly supported path can be checked without silently approving that unrelated constant-propagation bug. Do not count that existing failure as solved by batch44.

**Frame-reference component also passes source review.** The sealed `frame-tail-reference-v1` classifier matches primary `Referenceable`/`FieldsInFrame` and frame-object construction: ordinary structs only, a fixed prefix without relative references, and an array or recursively proper frame-object tail. Variable names and proper frame tails remain referenceable; variable-prefix and ADT payload interiors do not acquire independent headers. Explicit and implicit user reference formations call the same guard. The raw-render permission is scoped to argument conversion; function, callback and field/parameter-default evaluation clear it. Six independent `--check` probes pass in `astra-review-44/frame-render-context-probes.json` (five illegal user/default/callback paths reject, proper-frame defaults accept). Patch/compiler hashes match the seal. Existing relative-image backend refusals stay explicitly separate in the owner handoff.

Composition must preserve both `Checker.default_body` and `Checker.render_reference`, including each flag's independent default/function save, clear and restore operations. Frame/default patches textually overlap those locations; neither semantic boundary can replace the other. The earlier default-return, slice-readonly and native-relative review conclusions are unchanged.

The optional `pool-rebind-v1` draft was also read: capturing the target kind before RHS effects, stripping only contextual reusable flags, and comparing with source-derived proof fit the primary rebinding contract. Optional/plain targets do not invent a prior pool proof; the opt-in expression-root walk rejects unknown/nonzero-kind expression roots. No concrete source blocker was found, but this is not a sealed-component or runtime approval; it may remain batch45 without affecting the EM verdict. Exact provisional pool source/probe/build hashes are in `astra-review-44/pool-source-review-pins.json`; approval of its source applies only to the checker hash recorded there.

Reviewed final identities (SHA-256):

| Artifact | SHA-256 |
|---|---|
| EM checker | `feb833117995d706ddcc39ea0e68a28a0af02caaade7bbf6a49024cd19a31aad` |
| EM patch | `a9a21075966bf836c989d966743d75fa609504af47388fbf5044895f863bf3d7` |
| EM compiler | `68d92e9402fa120700a7f61f194c989822eeaf9ef7dc1ab9bbc0e0a2b01787ff` |
| frame-reference checker | `cac4dafe9f388bf38ceca2f8c16413e9f716d3d469ef91888da1a8dd7c949211` |
| frame-reference patch | `9bc877c6eaa099259d7ca8165e33b1fd66dfd38a9673b2f226e4f131bafe551f` |
| frame-reference compiler | `1cb61662b36df64bed7ef10043406197813d45235100043af1fbca4ba27def2b` |

Full primary-source, rejected-stage and evidence hashes: `astra-review-44/reviewed-pins-em.json` and `frame-reviewed-pins.json`. Every shell first sourced `build/performance-env.sh`; no primary C++ oracle ran, no production source changed, no `/dev/shm` output was created, and no costly full gate was launched by this review.
