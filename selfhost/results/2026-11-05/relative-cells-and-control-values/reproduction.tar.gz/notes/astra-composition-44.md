Batch 44 composition review — 2026-11-05

**Hold the EJ v4 component.** The other three sealed components have no demonstrated correctness blocker from this review. This is a private source and focused-probe review, not combined release qualification. No production source, expected-output corpus, primary C++ source, or `/dev/shm` output was changed. No C++ oracle or full compiler gate ran.

**P1: EJ v4 loses the accumulated integer-constant range.** In `semantic-round-ej/source/selfhost/checker.goose:4914`, `check_join_break_values` keeps one AST `anchor`; lines 4925–4927 replace an earlier literal with the last literal. With reachable break values `300`, `1`, then a typed `u8`, the last literal `1` permits selecting `u8`, after which final adaptation rejects `300`. The previously merged range must still include 300. Reversing the first two exits happens to succeed.

Reproducer, saved as `astra-review-44/merged-range-300.goose`:

```goose
fn choose(n: i64) {
    let byte: u8 = 8;
    loop {
        if n == 0 { break 300; }
        if n == 1 { break 1; }
        break byte;
    }
}
fn main() { print(choose(0), " ", choose(1), " ", choose(2)); }
```

Canonical C-only43 compiles this at native O0, GCC compiles its C, and execution prints `300 1 8\n`. Sealed EJ v4 refuses it with `value cannot implicitly convert to the required type` at 300. The mirrored `1, 300, u8` control prints `1 300 8\n` with both compilers. Exact commands and results: `astra-review-44/merged-range-probes.json`. The expected behavior also follows primary read-only `build/source/src/typecheck_flow.h:952`: `MergeVals` retains `litlo=min`/`lithi=max` (lines 996–1004), and `adapt` checks the whole constant range through `ConstsFit` before narrowing. This is a confirmed regression from 43, not an extrapolated risk.

Owner and publisher were notified before canonical44 proof started. Owner is correcting this in sibling `semantic-round-ek`; the reviewed EJ v4 is sealed and must remain rejected. A replacement needs all-prefix range checks before adaptation and named-reliance mutations, preserving typed-first anchoring. Review permutations, signed boundaries, early-block tail exits and nested joins. Existing typed-f32-first/f64-later rejection must stay intact.

The three other components:

- `default-return-v1`: the lexical default flag stays separate from `c.function_node`, preserving caller effect ownership. Only directly default-declared function symbols lose the named lexical owner; `check_function` clears/restores the flag for their bodies. Direct default returns reject before explicit-from selection. Primary `DefaultScope` and `CheckReturn` support that distinction. Existing evidence covers both default kinds, named helper captures, explicit callback `from` targets, both targets/levels and 2,800 frontend cases. The cyclic-field error path still fails to restore the pre-existing parameter-context fields; that behavior predates this patch and runs after an emitted cycle diagnostic, so it is not identified as a new batch blocker.
- `slice-element-readonly-v1`: the loop passes its peeled sequence type to the existing `check_argument_readonly` helper. That helper preserves both the descriptor-reference qualifier and the underlying slice qualifier. It leaves mutable slice behavior and descriptor-slot rules alone. Repeated reference syntax canonicalizes, so no invented nested-reference runtime representation is required. Existing evidence covers direct/native, both levels and V8 controls with no frontend regression.
- `native-var-relative-V1`: natural expression/parameter/return types remain `GRef`; only standalone declaration controls become `GVarRelative` with 10 data bytes plus explicit extent. The raw `(cell,end)` APIs validate minimal ULEB128 via `gs_uleb_check`, bound writes, use zigzag for self-relative offsets, and use unsigned offsets for pool-relative references. Load arithmetic guards address overflow. The 11-byte control is not a canonical image. `cc_read`/`cc_write` explicitly refuse a width-zero relative `CC_IMAGE` place, and aggregate construction/verification guards remain present. Sealed evidence records original six gains, 3,218 preserved native passing pairs, byte fixture sanitizers, and byte-identical self-emitted C; no performance win is inferred from wall time.

A native transfer-helper concern was tested and does **not** establish a blocker: extending `cc_relative_cell` means `ci_direct` sees varint references while `cc_frame_size` still describes their zero fixed image prefix. Actual thread parameters and accessed globals in the tested var-relative shapes are refused by the unchanged frontend before this helper can be used. Private probes cover worker parameter, var pool-relative global, let self-relative global and optional-null let global; fixed-width let controls also refuse. Both canonical43 and V1 agree. Reports: `astra-review-44/thread-probes.json`, `thread-let-probes.json`, `thread-null-probes.json`. A future thread-contract expansion must not serialize `GVarRelative` through zero-prefix helpers, but no current accepted path was demonstrated here.

Existing limitations remain separate from the new blocker: `slice_ref_readonly_slot_temp` is accepted in both 43 and the slice candidate and remains a temporary/descriptor provenance bug; varint relative aggregate fields and arrays still require physical cursor lowering; the delivered43 residual of 166 failures (28 accepted-invalid and 138 compiler-refused runtime cases) is not solved by this review. Rejected EJ runtime/anchor/reliance attempts remain archived under the owner directory.

Reviewed identities (SHA-256):

| Artifact | SHA-256 |
|---|---|
| frozen43 checker | `032fe40ee8ee468967b027b266d3a9cf5e628cb1c65423b3517d6ab6f2217370` |
| default-return patch | `57cdcc1cc245041194ab0c678510a53dc71ddb4b985a4fa91663c3611dee7fc4` |
| slice-readonly patch | `9479bb6a652599ee16ec2868ef06ad9aae987326495c2b7210505e8cf177ff12` |
| native V1 patch | `c3522f671c217d6621746752ad665c67a39bd6c4afaf635efa2601dcca1649a4` |
| rejected EJ v4 patch | `95f36a03b8cab8eab94c2ad5a497e6b873329dcf3b8558140b06747989d13360` |
| rejected EJ v4 checker | `bf5f6c98deed2dc8f9d5bb93f91d34eb260359dd64c2ddb52bd494c4ae599431` |

`astra-review-44/reviewed-pins-v1.json` contains exact compiler, candidate source, handoff, probe and primary-source hashes. Default, slice and V1 handoff compiler/patch/evidence/source hashes were independently recomputed and matched. All shell commands first sourced `build/performance-env.sh`; compiler probes had a 15-second timeout and used only small private inputs. The publication owner must reassemble and run its usual canonical combined qualification after the blocker is corrected; component pass counts are not a combined-release pass.
