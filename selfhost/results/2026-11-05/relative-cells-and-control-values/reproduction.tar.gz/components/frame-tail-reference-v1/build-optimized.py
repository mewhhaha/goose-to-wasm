from pathlib import Path
import json,hashlib,subprocess,shutil,time
r=Path(__file__).parent.resolve();source=r/'build-scoped';out=r/'build-final';out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
proof=json.loads((source/'report.json').read_text());assert proof['status']=='passed'
assert all(sha(p)==h for p,h in proof['input_sha256_after'].items())
c=source/'compiler.c';assert sha(c)==proof['generated_c_sha256'];cc=Path(shutil.which('clang')).resolve();exe=out/'goose'
report={'status':'running','source_build':str(source/'report.json'),'source_build_sha256':sha(source/'report.json'),'input_sha256':{str(c):sha(c),str(cc):sha(cc),**proof['input_sha256_after']},'command':list(map(str,[cc,'-std=gnu11','-O2',c,'-lm','-ldl','-pthread','-o',exe]))}
def save():(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
save();start=time.monotonic();p=subprocess.run(report['command'],capture_output=True,timeout=180)
(out/'cc.stdout').write_bytes(p.stdout);(out/'cc.stderr').write_bytes(p.stderr);report.update(exit_code=p.returncode,seconds=time.monotonic()-start,input_sha256_after={p:sha(p) for p in report['input_sha256']});assert p.returncode==0 and report['input_sha256']==report['input_sha256_after'];report.update(status='passed',executable=str(exe),executable_sha256=sha(exe),generated_c_sha256=sha(c));save();print(exe)
