# Source-derived referenceability boundary

Frozen primary build/source/src/typecheck_exprs.h: Referenceable (795), FieldsInFrame (806), NoResizableRef (818), AutoRef (738), CheckRefOf (1429). No C++ oracle executes.

A resizable value may be referenced as a name, or a member whose owner is a frame object held as one. A reference pointee establishes the owner only after confirming that owner is itself a frame-object struct. A member owner that is a value recurses through FieldsInFrame. This forbids a frame tail behind a variable prefix or ADT payload, while preserving whole owner references.

Frozen typecheck_types.h: frameobj requires a resizable struct, a tail that is an array or a frame-object struct, and prefix fields that are fixed and contain no relative references. The private checker helper must mirror those requirements; size class alone is insufficient.

## Suggested small implementation (not yet applied or built)

- Add `check_frame_object(p, ty)`: require TY_STRUCT and check_size_class==2; walk `p.types[ty].first` fields, ignoring F_PAD, find last real field. Prefix fields require size class zero and no check_type_property(...,3) relative refs. Tail requires TY_ARRAY or a recursive frame-object struct. Primary also forbids trailing pad through existing layout validation. Use checked instantiated fields, not generic declaration fields.
- Add `check_referenceable(p,node)`: non-resizable node type passes; N_NAME passes; N_MEMBER walks its owners as primary FieldsInFrame does. For each member, owner must be frame-object struct after one reference peel. A reference pointee terminates successfully only after confirming that owner frame classification. A nonmember owner also terminates; otherwise recurse into the owner member.
- Add shared diagnostic function that emits the exact NoResizableRef message, called for explicit `&` after check_single_expression, only when the child is not already TY_REF. For implicit formation, guarding `check_wrap_unary` when op==T_BITAND covers check_expect, inferred borrowed results, identity conversion, .= bindings and inferred non-fixed bindings. This centralization should be audited for synthetic internal references and retained with meaningful controls. Generic argument inference forms a provisional reference type but should eventually pass check_expect/wrap; verify a generic negative.

## Required controls

Original source negatives are `frame_tail_prefix_ref` and `frame_tail_prefix_arg` (not `_ref_arg`). Explicit/implicit paths through both Named value and Named&; implicit inferred alias, .= alias, generic identity/parameter, identity comparison where applicable. Positive standalone Stack&, &stack.items, implicit stack.items parameter, nested frame-object tails, whole Named&, fixed-size normal fields, plain-reference prefix, and ordinary variable-size non-resizable fields. A relative-reference prefix must deny tail reference per exact primary frame classification. ADT resizable-payload paths must remain denied without a blanket resizable-member prohibition.

No prefix candidate source, build, fixture or gate exists yet. Work stopped at the parent request to release an agent slot for Astra review. Frozen snapshot43 and canonical compiler43 remain the intended base; readonly-element patch is separately sealed and unchanged.
