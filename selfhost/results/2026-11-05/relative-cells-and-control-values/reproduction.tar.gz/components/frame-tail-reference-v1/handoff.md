# Frame tail referenceability — sealed

Private snapshot43 checker patch mirrors frozen primary Referenceable/FieldsInFrame/frameobj: a resizable tail has a referenceable header only through a proper frame-object owner path. Prefix fields must be fixed and contain no relative references; tail must be an array or another frame object. Variant payloads are excluded despite the selfhost representing them as TY_STRUCT.

Explicit and implicit lvalue references share the predicate. Whole Named&, standalone Stack&, nested proper frame tails and in-place prefix/ADT tail writes remain accepted. Trusted raw rendering argument conversion is scoped to already-checked places and cleared across user functions and parameter/field defaults; formatter/callback/default bypass negatives reject.

- Original two negatives: baseline0/8, candidate8/8, native/Wasm O0/O2.
- Focused matrix: baseline36/108, candidate108/108; V8 repeat108/108.
- Whole-owner and in-place frontend positives:12/12 in both.
- Matched frontend2800:3 negative gains, no positive losses or crashes. Gains are both original frame-tail fixtures plus const_for_resizable_reference, all with exact NoResizableRef diagnostic class.
- Four frozen rendering/temporary regression programs execute8/8 in both. Two other relative-image programs remain physical backend containment failures at both levels in both compilers; all12 statuses match. These are recorded as missing runtime coverage, not passes.
- Own-source final passes with unchanged pins:61.52 user seconds,61.87 wall seconds,556480KiB peak RSS under concurrent qualification. No comparative performance claim.

Rejected broad wrapper and helper-body-only rendering guards caused11 and6 positive frontend losses respectively; patches/evidence are retained under rejected-authoring. Fast O0 compiler was used only for35 cheap probes; final qualification uses O2 compiled from its exact pinned generated C.

Only private checker source changed. No C++ oracle executed. Parent performs composition/full qualification. The Base43 patch touches the Checker boolean line and function/default context boundaries also touched by default-return; preserve both state fields and state restores when composing.
