Future45, private frozen43 candidate; NativeV1 seal untouched.

59-line checker-only patch captures prior pool kind before RHS, removes only contextual pool-proof flags while preserving expected value typing, validates actual source kind before publishing roots, and preserves specialized parameter proof. An opt-in expression-root walk handles branch/call sources without changing existing pool queries. Optional references retain no pool proof; standalone unreached parameters remain uncommitted until rooted proof settles.

Actual full compiler:54/54 targeted native/Wasm cases (baseline32/54), V8 runtime14/14, frontend2800 exactly2 proper-negative recoveries and zero losses/compiler failures. Same-kind pool, plain-only specialization, globals/aliases/params, optional refs, branches/generic returns, and distinct slot/slice freelist reuse are covered. Own-source native/Wasm checks currently run in isolated group575644.

Rejected harness: initial checker-only C compiled at-O0 hit native stack guard on stdlib_json; identical generated C compiled at-O1 accepted it. Both O0 failure and O1 success reports are retained. Probe build emitted in13.3s; no performance claim compares its smaller entry surface with the full compiler.

Core reports: full43-probe-qualification43.json, contracts43-candidate/report.json, contracts43-v8/report.json. No full release suite or publication is claimed; root will compose the checker patch after44. No oracle run or live source edits.
