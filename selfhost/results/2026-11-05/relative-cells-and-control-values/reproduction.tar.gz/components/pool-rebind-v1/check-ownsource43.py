from pathlib import Path
import os,json,time,hashlib
import subprocess
base=Path(__file__).resolve().parent;root=base.parents[2];out=base/'own-source43';out.mkdir(exist_ok=False);compiler=base/'build43/goose'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
pins=dict(json.loads((base/'build43/report.json').read_text())['input_sha256']);pins[str(compiler)]=sha(compiler);pins[str(Path(__file__).resolve())]=sha(Path(__file__))
r=dict(status='running',method='Actual full candidate checks frozen own source with native and wasm-direct data models. Correctness only; wall time may include benchmark holds.',input_sha256=pins,commands=[])
def save():(out/'report.json').write_text(json.dumps(r,indent=2)+'\n')
save()
try:
 for target in ['native','wasm-direct']:
  command=list(map(str,[compiler,base/'source/selfhost/main.goose','--target',target,'--stdlib',root/'stdlib','--check','--library']));start=time.monotonic()
  with (out/(target+'.stdout')).open('w') as stdout,(out/(target+'.stderr')).open('w') as stderr:
   child=subprocess.Popen(command,stdout=stdout,stderr=stderr);_,status,usage=os.wait4(child.pid,0);child.returncode=os.waitstatus_to_exitcode(status)
  r['commands'].append(dict(command=command,exit_code=child.returncode,seconds=time.monotonic()-start,max_rss_kib=usage.ru_maxrss));save();assert child.returncode==0,(out/(target+'.stderr')).read_text()[-4000:]
 r['input_sha256_after']={p:sha(p) for p in pins};assert pins==r['input_sha256_after'];r['status']='passed';save();print('own-source checks passed for both target data models')
except BaseException as e:r.update(status='failed',error=repr(e));save();raise
