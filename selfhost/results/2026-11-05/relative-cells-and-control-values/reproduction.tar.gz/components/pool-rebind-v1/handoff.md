Qualified future45 pool-rebind checker patch:2 proper-negative recoveries, zero losses across2800 original frontend sources.

`pool-rebind.patch` changes only `selfhost/checker.goose` (59 diff lines), against frozen43. Capture prior kind before RHS; retain contextual value typing without treating expected pool flags as source proof; check actual kind before root publication. Specialization, optional and unknown proof distinctions remain.

Full canonical43-built candidate passed54/54 native/Wasm O0/O2 contracts, V8 runtime14/14, actual own-source checks under both data models. Same-kind pool freelist behavior is asserted and the original pool_reference_rebinds output is preserved.

Migrate13 short authored controls under `controls/` with `contracts43.json`; preserve the two original upstream rows unchanged. `source/selfhost/probe.goose` is a private fast checker harness, excluded from the production patch.

Rejected O0 probe stack-limit failure and subsequent O1 success remain as evidence. No speed claim, pool ABI change, live source edit or oracle execution. Full source/compiler/workload/engine pins are in `handoff.json` and linked reports.
