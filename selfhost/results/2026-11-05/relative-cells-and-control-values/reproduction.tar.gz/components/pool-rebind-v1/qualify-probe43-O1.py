from pathlib import Path
import concurrent.futures,hashlib,json,subprocess,time
base=Path(__file__).resolve().parent;root=base.parents[2]
producer=root/'build/completion-runs/c-only-bootstrap-43/goose';candidate=base/'probe43-O1/goose';library=root/'stdlib'
suites=root/'build/completion-runs/default-return-v1/front-baseline43'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(name,value):(base/('O1-'+name)).write_text(json.dumps(value,indent=2)+'\n')
names=['semantic-all-valid','typing','negative-type','upstream-positive']
inputs={n:json.loads((suites/(n+'.json')).read_text()) for n in names}
source_paths={Path(x['source']) for rows in inputs.values() for x in rows}
pins={str(p):sha(p) for p in [producer,candidate,Path(__file__).resolve(),*source_paths,*library.rglob('*.goose'),*(base/'source/selfhost').glob('*.goose'),base/'probe-cases.json',*(base/'controls').glob('*.goose')]}
pins.update({str(base/('front-before-'+n+'.json')):sha(base/('front-before-'+n+'.json')) for n in names})
observations={};start=time.monotonic()
for label,exe in [('before',producer),('after',candidate)]:
 observations[label]={}
 if label=='before':
  observations[label]={n:json.loads((base/('front-before-'+n+'.json')).read_text()) for n in names}
  for rows in observations[label].values():
   for row in rows:assert sha(row['source'])==row['source_sha256']
  continue
 def run(row):
  source=Path(row['source']);command=[str(exe),str(source),'--stdlib',str(library),'--check']
  if label=='after':command=[str(exe),str(source),str(library)]
  started=time.monotonic()
  try:p=subprocess.run(command,capture_output=True,text=True,timeout=20);return dict(source=str(source),source_sha256=sha(source),command=command,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr,seconds=time.monotonic()-started)
  except subprocess.TimeoutExpired:return dict(source=str(source),source_sha256=sha(source),command=command,exit_code=124,stdout='',stderr='TIMEOUT',seconds=time.monotonic()-started)
 for name,rows in inputs.items():
  with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:found=list(pool.map(run,rows))
  observations[label][name]=found;save('front-'+label+'-'+name+'.json',found);print(label,name,sum(x['exit_code']==0 for x in found),'/',len(found),flush=True)
losses=[];changes=[];invalid=[]
for name in names:
 for before,after in zip(observations['before'][name],observations['after'][name]):
  if before['exit_code']!=after['exit_code']:
   row=dict(suite=name,source=after['source'],before=before['exit_code'],after=after['exit_code']);changes.append(row)
   if name=='negative-type' and before['exit_code']!=0 and after['exit_code']==0 or name!='negative-type' and before['exit_code']==0 and after['exit_code']!=0:losses.append(row)
  if after['exit_code'] not in [0,1]:invalid.append(after)
focus=[]
for row in json.loads((base/'probe-cases.json').read_text()):
 command=[str(candidate),row['source'],str(library)];p=subprocess.run(command,capture_output=True,text=True,timeout=20);focus.append(dict(row,command=command,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr,match=(p.returncode==0)==row['expected_accept']))
save('probe-focus43.json',focus)
comparison=dict(status='passed',method='Actual unchanged frozen43 compiler versus checker-only candidate probe;2800 original sources, unchanged expected accept/reject direction, fresh processes. Unchanged baseline source fingerprints and prior fresh baseline observations reused. No oracle.',total=sum(map(len,inputs.values())),changes=changes,losses=losses,compiler_failures=invalid,focus_passed=sum(x['match'] for x in focus),focus_selected=len(focus),seconds=time.monotonic()-start,input_sha256=pins,input_sha256_after={p:sha(p) for p in pins})
if losses or invalid or not all(x['match'] for x in focus):comparison['status']='failed'
assert comparison['input_sha256']==comparison['input_sha256_after'];save('probe-qualification43.json',comparison);print(comparison['status'],changes,losses,flush=True)
assert comparison['status']=='passed'
