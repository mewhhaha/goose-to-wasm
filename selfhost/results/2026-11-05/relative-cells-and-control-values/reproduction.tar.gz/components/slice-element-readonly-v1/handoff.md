# Slice element readonly qualification — sealed

One line in `check_loop` reuses `check_argument_readonly` with the peeled sequence type, preserving the readonly slice behind a writable descriptor reference. Frozen snapshot43 plus this patch only; compiler and source hashes in `pin-validation.json`.

- Original negative: baseline 0/4, candidate 4/4 (native/Wasm, O0/O2).
- Focused explicit/implicit references, local references, nested fields, automatic variable-size element references, both qualifier layers, descriptor writes, mutable elements and reads: baseline 32/56, candidate 56/56. V8 repeat 56/56.
- Matched frontend 2800: one original negative gain, no regressions or crashes; exact fixture hashes match.
- Own-source passes with unchanged pins: 77.19 user seconds, 78.43 wall seconds, 479072 KiB peak RSS under concurrent qualification. No comparative performance claim.

Repeated reference annotations canonicalize by frozen spec and `N_TYPE_REF`; the repeated-ref control rejects without a new helper walk. An unneeded helper-walk experiment was cancelled at the parent's benchmark hold and discarded. Harness/fixture authoring mistakes are preserved in `rejected-authoring/notes.json`; corrected focused controls all pass.

`slice_ref_readonly_slot_temp` remains a separate temporary/place-provenance failure in both compilers. No C++ oracle executed. No live compiler or test edits. Parent performs composition and full qualification.
