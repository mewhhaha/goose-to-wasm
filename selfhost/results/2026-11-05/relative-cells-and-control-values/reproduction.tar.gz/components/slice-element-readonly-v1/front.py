from pathlib import Path
import concurrent.futures,json,subprocess,time,hashlib
r=Path(__file__).parent.resolve();root=r.parents[2];fixtures=r.parent/'default-return-v1/front-baseline43';library=root/'stdlib'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for label,exe in [('baseline43',r.parent/'c-only-bootstrap-43/goose'),('candidate',r/'build/goose')]:
 d=r/('front-'+label);d.mkdir(exist_ok=True)
 def run(row):
  source=Path(row['source']); assert source.is_file(),source
  cmd=[str(exe),str(source),'--stdlib',str(library),'--check']
  try:
   p=subprocess.run(cmd,capture_output=True,text=True,timeout=12);return dict(source=str(source),source_sha256=sha(source),exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr)
  except subprocess.TimeoutExpired:return dict(source=str(source),source_sha256=sha(source),exit_code=124,stdout='',stderr='TIMEOUT')
 for name in ['semantic-all-valid','typing','negative-type','upstream-positive']:
  rows=json.loads((fixtures/(name+'.json')).read_text());start=time.monotonic()
  with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,rows))
  (d/(name+'.json')).write_text(json.dumps(results,indent=2)+'\n');print(label,name,'accepted',sum(x['exit_code']==0 for x in results),'/',len(results),'seconds',round(time.monotonic()-start,3),flush=True)
