from pathlib import Path
import concurrent.futures,hashlib,json,subprocess,time
r=Path(__file__).parent.resolve();root=r.parents[2];exe=r/'probe43/goose';base=r.parent/'c-only-bootstrap-43/goose';library=root/'stdlib'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(name,value):(r/name).write_text(json.dumps(value,indent=2)+'\n')
original=Path('/dev/shm/goose-selfhost-work/semantic-round-z');names=['semantic-all-valid','typing','negative-type','upstream-positive']
suites={n:json.loads((original/(n+'.json')).read_text()) for n in names}
paths={Path(row['source']) for rows in suites.values() for row in rows};paths.update([exe,base,Path(__file__),*library.rglob('*.goose'),*(r/'source/selfhost').glob('*.goose')]);paths.update([r/'contracts.json',*(r/'focus').glob('*.goose')]);pins={str(p):sha(p) for p in paths};save('qualification-input-pins-probe43.json',pins)
results={}
for label,compiler in [('before',base),('after',exe)]:
 def run(row):
  command=[str(compiler),row['source'],'--stdlib',str(library),'--check']
  if label=='after':command=[str(compiler),row['source'],str(library)]
  try:
   started=time.monotonic();p=subprocess.run(command,capture_output=True,text=True,timeout=20);return dict(source=row['source'],command=command,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr,seconds=time.monotonic()-started)
  except subprocess.TimeoutExpired:return dict(source=row['source'],command=command,exit_code=124,stdout='',stderr='TIMEOUT')
 results[label]={}
 for name,rows in suites.items():
  with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:out=list(pool.map(run,rows))
  results[label][name]=out;save('front-probe43-'+label+'-'+name+'.json',out);print(label,name,sum(x['exit_code']==0 for x in out),'/',len(out),flush=True)
changes=[];losses=[];invalid=[]
for name in names:
 for before,after in zip(results['before'][name],results['after'][name]):
  if before['exit_code']!=after['exit_code']:
   row=dict(suite=name,source=after['source'],before=before['exit_code'],after=after['exit_code']);changes.append(row)
   if name=='negative-type' and before['exit_code']!=0 and after['exit_code']==0 or name!='negative-type' and before['exit_code']==0 and after['exit_code']!=0:losses.append(row)
  if after['exit_code'] not in [0,1]:invalid.append(after)
comparison=dict(changes=changes,losses=losses,compiler_failures=invalid,total=sum(map(len,suites.values())))
save('front-probe43-comparison.json',comparison);save('qualification-input-pins-probe43-after.json',{name:sha(name) for name in pins});assert pins=={name:sha(name) for name in pins};print(comparison,flush=True)
assert not losses and not invalid

focus=json.loads((r/'contracts.json').read_text());rows=[]
for case in focus:
 command=[str(exe),case['source'],str(library)];p=subprocess.run(command,capture_output=True,text=True,timeout=20);rows.append(dict(case,command=command,exit_code=p.returncode,stdout_actual=p.stdout,stderr=p.stderr,match=(p.returncode==0)==case['expected_accept']))
save('probe-focus43-wasm.json',rows);assert all(x['match'] for x in rows)
save('qualification-input-pins-probe43-final.json',{name:sha(name) for name in pins});assert pins=={name:sha(name) for name in pins}
