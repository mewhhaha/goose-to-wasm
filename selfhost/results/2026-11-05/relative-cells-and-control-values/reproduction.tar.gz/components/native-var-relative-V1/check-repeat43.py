from pathlib import Path
import hashlib,json,subprocess,time
base=Path(__file__).resolve().parent
out=base/'selfemit43'
compiler=out/'goose';original=out/'compiler.c';target=out/'repeat.c'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
pins={str(p):sha(p) for p in [compiler,original,Path(__file__).resolve(),out/'report.json']}
r={'status':'running','method':'New-ABI actual compiler re-emits frozen own source; generated C must equal first candidate emission byte-for-byte. Correctness only; benchmark hold is excluded from claims.','input_sha256':pins,'commands':[]}
def save():(out/'repeat-report.json').write_text(json.dumps(r,indent=2)+'\n')
try:
 command=list(map(str,[compiler,base/'source/selfhost/main.goose','--stdlib','/home/jacobt/src/goose-to-wasm/stdlib','--target','native','--standalone','-O0','-o',target]));start=time.monotonic()
 p=subprocess.run(command,capture_output=True,timeout=180)
 (out/'repeat.stdout').write_bytes(p.stdout);(out/'repeat.stderr').write_bytes(p.stderr)
 r['commands'].append(dict(command=command,exit_code=p.returncode,seconds=time.monotonic()-start));save();assert p.returncode==0,p.stderr.decode()[-4000:]
 assert original.read_bytes()==target.read_bytes(),'compiler emission changed'
 r['input_sha256_after']={p:sha(p) for p in pins};assert pins==r['input_sha256_after'];r.update(status='passed',generated_c_sha256=sha(target));save();print('new-ABI compiler repeat C byte-identical')
except BaseException as e:r.update(status='failed',error=repr(e));save();raise
