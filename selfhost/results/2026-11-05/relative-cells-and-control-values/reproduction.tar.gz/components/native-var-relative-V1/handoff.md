Qualified V1 against frozen43: +6 native contract pairs, 0 losses across 3,218 prior native passes.

`var-relative.patch` changes two C codegen files, the relative runtime header, the direct native test runner, and its new bounded fixture. It applies cleanly to frozen43. Natural references remain 8 bytes; scalar encoded declarations use an 11-byte extent-bearing control. Aggregate images retain existing refusal.

Canonical C-only43 built this prototype with Clang -O1. Actual candidate emitted its own compiler; Clang -O2 built it, it checked its own source, and repeated C was byte-identical. Focused Clang/GCC O0/O2 ASan/UBSan and full direct runtime checks passed.

Permanent Goose controls to migrate: `controls/scalar_abi.goose` and `controls/rejected_recursive_varparam.goose`; expectations and IDs in `control-cases43.json`. Keep the recursive case as a type-error. Existing original fixture contracts need no expectation changes.

No speed claim. The own-source Clang wall time includes the benchmark hold. All detailed source, compiler, C compiler, expectation and evidence identities are in `handoff.json`. Initial seed27 evidence and rejected harness experiments remain in place.
