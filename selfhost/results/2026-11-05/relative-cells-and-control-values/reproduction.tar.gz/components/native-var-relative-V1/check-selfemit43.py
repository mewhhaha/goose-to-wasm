from pathlib import Path
import json,subprocess,time,hashlib,shutil,os
base=Path(__file__).resolve().parent;out=base/'selfemit43';out.mkdir(exist_ok=False);producer=base/'build43/goose';cc=Path(shutil.which('clang')).resolve()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
pins=dict(json.loads((base/'build43/report.json').read_text())['input_sha256']);pins[str(producer)]=sha(producer);pins[str(cc)]=sha(cc);pins[str(Path(__file__).resolve())]=sha(Path(__file__))
r={'status':'running','method':'Actual candidate Goose emits the frozen compiler source; Clang builds it and that new-ABI compiler selfchecks its source.','input_sha256':pins,'commands':[]}
def save():(out/'report.json').write_text(json.dumps(r,indent=2)+'\n')
save()
try:
    for label,command in [('emit',[producer,base/'source/selfhost/main.goose','--stdlib','/home/jacobt/src/goose-to-wasm/stdlib','--target','native','--standalone','-O0','-o',out/'compiler.c']),('cc',[cc,'-std=gnu11','-O2',out/'compiler.c','-lm','-ldl','-pthread','-o',out/'goose']),('check',[out/'goose',base/'source/selfhost/main.goose','--stdlib','/home/jacobt/src/goose-to-wasm/stdlib','--check','--library'])]:
        command=list(map(str,command));start=time.monotonic()
        with (out/(label+'.stdout')).open('w') as stdout,(out/(label+'.stderr')).open('w') as stderr:
            child=subprocess.Popen(command,stdout=stdout,stderr=stderr);_,status,usage=os.wait4(child.pid,0);child.returncode=os.waitstatus_to_exitcode(status)
        r['commands'].append({'command':command,'exit_code':child.returncode,'seconds':time.monotonic()-start,'max_rss_kib':usage.ru_maxrss});save()
        assert child.returncode==0,(out/(label+'.stderr')).read_text()[-4000:]
    r['input_sha256_after']={p:sha(p) for p in pins};assert r['input_sha256']==r['input_sha256_after'];r.update(status='passed',compiler_sha256=sha(out/'goose'),generated_c_sha256=sha(out/'compiler.c'),generated_c_bytes=(out/'compiler.c').stat().st_size);save();print('selfemit/Clang/new-ABI selfcheck passed')
except BaseException as error:r.update(status='failed',error=repr(error));save();raise
