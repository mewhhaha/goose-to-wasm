from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

base = Path(__file__).resolve().parent
root = Path('/home/jacobt/src/goose-to-wasm')
out = base / 'focused43'
out.mkdir(exist_ok=False)
cc = Path(shutil.which('clang')).resolve()
gcc = Path(shutil.which('gcc')).resolve()
pins = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__), cc, gcc, base / 'build43/goose']}
report = {'status': 'running', 'input_sha256': pins, 'commands': []}

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def save():
    (out / 'report.json').write_text(json.dumps(report, indent=2) + '\n')

def run(label, command, expected=None, failures=0):
    command = list(map(str, command))
    environment = dict(os.environ, ASAN_OPTIONS='detect_leaks=1:halt_on_error=1', UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    result = subprocess.run(command, capture_output=True, timeout=120, env=environment)
    (out / (label + '.stdout')).write_bytes(result.stdout)
    (out / (label + '.stderr')).write_bytes(result.stderr)
    report['commands'].append({'command': command, 'exit_code': result.returncode, 'stdout': label + '.stdout', 'stderr': label + '.stderr'})
    save()
    assert result.returncode == 0, result.stderr.decode()
    if expected is not None:
        assert result.stdout == expected, result.stdout
        assert result.stderr.count(b'goose runtime error:') == failures, result.stderr
        assert b'ERROR: AddressSanitizer' not in result.stderr and b'runtime error:' not in result.stderr.replace(b'goose runtime error:', b''), result.stderr
    return result

try:
    # Unchanged fixed-width source and byte-for-byte diagnostics with the baseline.
    fixed = []
    for label, tree in [('baseline43', root / 'build/completion-runs/snapshot-43'), ('candidate', base / 'source')]:
        source = tree / 'native/tests/relative.c'
        pins[str(source)] = sha(source)
        binary = out / (label + '-fixed')
        run(label + '-fixed-cc', [cc, '-std=gnu11', '-O2', '-fsanitize=address,undefined', source, '-pthread', '-lm', '-ldl', '-o', binary])
        fixed.append(run(label + '-fixed-run', [binary], b'native relative cells ok\n', 13))
    assert fixed[0].stdout == fixed[1].stdout and fixed[0].stderr == fixed[1].stderr
    for compiler, name in [(cc, 'clang'), (gcc, 'gcc')]:
        source = base / 'source/native/tests/var_relative.c'
        pins[str(source)] = sha(source)
        for level in [0, 2]:
            label = name + '-var-O' + str(level)
            binary = out / label
            run(label + '-cc', [compiler, '-std=gnu11', '-O' + str(level), '-g', '-fsanitize=address,undefined', '-fno-omit-frame-pointer', source, '-pthread', '-lm', '-ldl', '-o', binary])
            run(label + '-run', [binary], b'bounded varint relative cells ok\n', 13)
    for manifest_name, report_name in [('entry-cases43.json', 'entries43/report.json'), ('control-cases43.json', 'controlled43/report.json')]:
        manifest = json.loads((base / manifest_name).read_text())
        results = json.loads((base / report_name).read_text())
        assert results['status'] == 'passed'
        for row in results['results']:
            if row['phase'] != 'run': continue
            name = row['case'].replace('/', '-') + '-O' + str(row['level'])
            case = next(c for c in manifest['cases'] if c['id'] == row['case'])
            source = Path(results['commands'][row['compile_command']]['command'][-1])
            pins[str(source)] = sha(source)
            binary = out / name
            run(name + '-cc', [cc, '-std=gnu11', '-O' + str(row['level']), '-fsanitize=address,undefined', '-fno-omit-frame-pointer', source, '-pthread', '-lm', '-ldl', '-o', binary])
            command = [str(binary)]
            observed = subprocess.run(command, capture_output=True, timeout=120, env=dict(os.environ, ASAN_OPTIONS='detect_leaks=1:halt_on_error=1', UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1'))
            (out / (name + '-run.stdout')).write_bytes(observed.stdout)
            (out / (name + '-run.stderr')).write_bytes(observed.stderr)
            report['commands'].append({'command': command, 'exit_code': observed.returncode})
            expected = case['expect']
            assert observed.stdout == expected['stdout'].encode(), (name, observed.stdout)
            if expected['exit'] == 'nonzero':
                assert observed.returncode == 1 and observed.stderr.count(b'goose runtime error:') == 1, (name, observed.stderr)
            else:
                assert observed.returncode == expected['exit'] and not observed.stderr, (name, observed.stderr)
            assert b'ERROR: AddressSanitizer' not in observed.stderr and b'runtime error:' not in observed.stderr.replace(b'goose runtime error:', b''), observed.stderr
            save()
    report['input_sha256_after'] = {p: sha(p) for p in pins}
    assert pins == report['input_sha256_after']
    report['status'] = 'passed'
    save()
except BaseException as error:
    report.update(status='failed', error=repr(error))
    save()
    raise
