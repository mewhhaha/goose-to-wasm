Sealed default lexical return boundary, based on frozen43.

Patch: default-return.patch (checker.goose only). Default evaluation retains the caller effect owner, while functions/values declared in the actual default expression get no lexical named owner. Named helper bodies clear the direct-default flag and keep ordinary/callback returns. Direct `return ... from` in a default rejects; explicit-from in an invoked callback retains primary dynamic-call semantics.

Original2 negatives recovered. Controls68/68 plus supplemental16/16 (baseline52/68 plus16/16), native+Wasm O0/O2. Front2800 exactly2 proper-negative gains, zero losses/crashes. Own-source exit0,59.97s wall,554492KiB peak; unchanged source pins. No comparative cost claim under concurrent root publication/gates.

All source/patch/compiler identities and rejected control-authoring inputs retained in handoff.json, source-freeze.json, pin-validation.json. No live production changes.
