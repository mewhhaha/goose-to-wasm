from pathlib import Path
import hashlib,json,shutil
root=Path('/home/jacobt/src/goose-to-wasm');w=root/'build/completion-runs';path=root/'tests/conformance/cases.json'
r=json.loads(path.read_text());old={c['id'] for c in r['cases']};new=[];sources={}
for folder,manifest,prefix in [('default-return-v1','controls-manifest.json','default-return'),('default-return-v1','supplemental-manifest.json','default-return'),('slice-element-readonly-v1','controls-manifest.json','readonly-elements'),('native-var-relative-V1','control-cases43.json','relative-cells'),('frame-tail-reference-v1','controls-manifest.json','frame-tail-reference'),('frame-tail-reference-v1','frontend-controls-manifest.json','frame-tail-reference')]:
 for case in json.loads((w/folder/manifest).read_text())['cases']:
  c=dict(case);src=root/c['source'];assert src.is_file(),src
  relative=src.relative_to(w/folder/'controls');dest=root/'tests/fixtures/contracts'/prefix/relative;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dest)
  name=dest.relative_to(root).as_posix();sources[name]=hashlib.sha256(dest.read_bytes()).hexdigest();c['source']=name;c['id']='corpus/contracts/'+prefix+'/'+c['id'];assert c['id'] not in old,c['id'];old.add(c['id']);new.append(c)
r['cases'].extend(new);path.write_text(json.dumps(r,indent=2)+'\n');(w/'new-controls-44.json').write_text(json.dumps(dict(status='initial controls migrated; breakjoinpending',cases=len(new),rows=sum(len(x['levels']) for x in new),sources=sources),indent=2)+'\n');print('appended',len(new),'cases',sum(len(x['levels']) for x in new),'rows;',len(sources),'files')
