from pathlib import Path
import hashlib,json,shutil,subprocess
w=Path('/home/jacobt/src/goose-to-wasm/build/completion-runs');dst=w/'snapshot-44';shutil.copytree(w/'snapshot-43',dst);records=[]
for folder,name,strip in [('default-return-v1','default-return.patch',2),('slice-element-readonly-v1','slice-element-readonly.patch',2),('native-var-relative-V1','var-relative.patch',1)]:
 patch=w/folder/name;r=subprocess.run(['patch','--fuzz=0','-p'+str(strip),'-i',str(patch)],cwd=dst,text=True,capture_output=True);records.append(dict(patch=str(patch),sha256=hashlib.sha256(patch.read_bytes()).hexdigest(),strip=strip,exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr));assert r.returncode==0
frame=w/'frame-tail-reference-v1/source/selfhost/checker.goose';base=w/'snapshot-43/selfhost/checker.goose';current=dst/'selfhost/checker.goose'
r=subprocess.run(['git','merge-file','-p',str(current),str(base),str(frame)],text=True,capture_output=True);assert r.returncode in (0,1,2,3,4,5,6),r.stderr
(w/'snapshot-44-frame-merge.goose').write_text(r.stdout)
records.append(dict(component='frame-tail-reference-v1',method='3waymerge; context overlaps will be resolved preserving both lexical default and trusted rendering states',source_sha256=hashlib.sha256(frame.read_bytes()).hexdigest(),merge_conflicts=r.returncode))
(w/'snapshot-44-assembly.json').write_text(json.dumps(dict(status='partial4components; framecontextmergepending; finalnumericpending',base_commit='9efdf93047d4363b2d3163cf59f5c4bc41446524',patches=records),indent=2)+'\n');print('frame mergeconflicts',r.returncode)
