from pathlib import Path
import json,hashlib,shutil
root=Path('/home/jacobt/src/goose-to-wasm');w=root/'build/completion-runs';p=root/'tests/conformance/cases.json';r=json.loads(p.read_text());ids={c['id'] for c in r['cases']};meta=json.loads((w/'new-controls-44.json').read_text());added=[]
for folder,filename,prefix,leaf in [('semantic-round-em','runtime-manifest43.json','break-joins','focus'),('pool-rebind-v1','contracts43.json','pool-rebind','controls')]:
 source_root=w/folder/leaf
 for old in json.loads((w/folder/filename).read_text())['cases']:
  c=dict(old)
  if c['source'].startswith('upstream:'):continue
  src=root/c['source']
  if not src.is_relative_to(source_root):continue
  rel=src.relative_to(source_root);dst=root/'tests/fixtures/contracts'/prefix/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst);name=dst.relative_to(root).as_posix();meta['sources'][name]=hashlib.sha256(dst.read_bytes()).hexdigest();c['source']=name;c['id']='corpus/contracts/'+prefix+'/'+c['id'];assert c['id'] not in ids,c['id'];ids.add(c['id']);added.append(c)
r['cases'].extend(added);p.write_text(json.dumps(r,indent=2)+'\n');meta['cases']+=len(added);meta['rows']+=sum(len(c['levels']) for c in added);meta['status']='all6component controls migrated; composedqualificationpending';(w/'new-controls-44.json').write_text(json.dumps(meta,indent=2)+'\n');print('allnewcontrols',meta['cases'],meta['rows'],len(meta['sources']),'suiterows',sum(len(c['levels']) for c in r['cases']))
