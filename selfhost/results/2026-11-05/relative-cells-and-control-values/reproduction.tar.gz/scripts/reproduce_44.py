from pathlib import Path
import hashlib,json,re,shutil,subprocess
w=Path('/home/jacobt/src/goose-to-wasm/build/completion-runs');out=w/'snapshot-44-reproduced';shutil.copytree(w/'snapshot-43',out)
def apply(folder,name,strip):
 p=w/folder/name;r=subprocess.run(['patch','--fuzz=0','-p'+str(strip),'-i',str(p)],cwd=out,text=True,capture_output=True);assert r.returncode==0,(folder,r.stdout,r.stderr)
for folder,name,strip in [('default-return-v1','default-return.patch',2),('slice-element-readonly-v1','slice-element-readonly.patch',2),('native-var-relative-V1','var-relative.patch',1)]:apply(folder,name,strip)
current=out/'selfhost/checker.goose';r=subprocess.run(['git','merge-file','-p',str(current),str(w/'snapshot-43/selfhost/checker.goose'),str(w/'frame-tail-reference-v1/source/selfhost/checker.goose')],text=True,capture_output=True);assert r.returncode==5
resolution=json.loads((w/'snapshot-44-frame-resolution.json').read_text());resolved={(x['left'],x['right']):x['resolved'] for x in resolution['conflicts']}
def resolve(m):return resolved[(m.group(1),m.group(2))]
s,count=re.subn(r'^<<<<<<<[^\n]*\n(.*?)^=======\n(.*?)^>>>>>>>[^\n]*\n',resolve,r.stdout,flags=re.M|re.S);assert count==5;assert hashlib.sha256(s.encode()).hexdigest()==resolution['result_sha256'];current.write_text(s)
for folder,name,strip in [('semantic-round-em','break-join-snapshot43.patch',1),('pool-rebind-v1','pool-rebind.patch',1)]:apply(folder,name,strip)
proof=json.loads((w/'c-only-bootstrap-44/report.json').read_text());pins={'selfhost/'+name:value for name,value in proof['source_sha256'].items()};pins.update(proof['asset_sha256'])
for name in ['native/tests/check.py','native/tests/var_relative.c']:pins[name]=hashlib.sha256((w/'snapshot-44'/name).read_bytes()).hexdigest()
for name,value in pins.items():assert hashlib.sha256((out/name).read_bytes()).hexdigest()==value,name
(w/'reproduction-44.json').write_text(json.dumps(dict(status='passed',method='All six sealed patches plus exact five-conflict state merge independently reproduce the frozen qualification inputs',verified_sha256=pins),indent=2)+'\n');print('independentlyreproduced',len(pins),'qualifiedsource/runtime/testinputs')
