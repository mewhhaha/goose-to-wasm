# Iteration profile scout

## Fastest useful first measurement

Use the installed current compiler directly; do not bootstrap or compile the compiler executable first. This records parse, typecheck, optimize and backend wall-clock phase times in one fresh stats file:

```sh
source build/performance-env.sh
build/bin/goose selfhost/main.goose --stdlib stdlib --target native -O0 \
  --wasm-stats build/completion-runs/iteration-profile-stats.json \
  -o build/completion-runs/iteration-profile.c
```

The stats option is named `--wasm-stats` even for native output. For a cheaper frontend-only pass, add `--check`; it records parse/check/optimize times but omits code generation. Use a fresh stats filename each run. Existing driver stats are phase durations (`parse_ns`, `typecheck_ns`, `optimize_ns`, `backend_ns`), not sampled call stacks. The underlying selfhost compiler invocation in `bootstrap.py` is `seed selfhost/main.goose --stdlib <copied-stdlib> --target native -O0 -o compiler.c`.

`perf` is not installed in this environment (`command not found`), so no CPU sample profile was collected. Do not infer hotspots from the phase totals.

## Source-based hypotheses to test

- `check_lookup_scope` walks every symbol linked to a scope and calls `same_name`; repeated identifier resolution could amplify this on the 13k-symbol compiler source. Confirm with samples or narrow counters before changing the representation.
- `intern_type` linearly scans `p.types` for structural equality. Type construction volume times pool size could be costly; measure call count and cumulative time.
- Lifetime checking repeatedly traverses control-flow/lifetime structures (`life_branch`, `life_merge`, scope/future processing) on a large AST. The code is complex enough to warrant sampling, but source complexity is not evidence of CPU cost.

## Small next step

Capture one full self-compile phase-stats run and one `--check` run using the same compiler/source/stdlib, then compare phases. This cheaply distinguishes frontend cost from backend cost and gives a repeatable baseline. If the check phase dominates, use an available sampling profiler in a profiling-enabled environment before selecting one of the hypotheses; avoid adding permanent instrumentation until that evidence exists.
