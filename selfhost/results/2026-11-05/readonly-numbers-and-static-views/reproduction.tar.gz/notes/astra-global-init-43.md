# Global-init V1 source review

**Approved to compose and test; no concrete defect found.** This is bounded source review plus tiny checker probes, not canonical qualification or a runtime-gain claim. No C++ oracle, expensive gate, live source edit, or frozen-helper mutation ran.

Pins:

- Patch: `global-init-v1/global-init.patch`, SHA256 `b16ff1ea6f364b57e20ffe61d8e1b7ad456bd712fc344848634f92e0f3bab4ae`.
- Candidate compiler: `598af493d74f8e2e63995898bddd5a03d35794b32d8cd334e7696bcd08cd354c`.
- Frozen42 compiler: `6e82bc259a95ac02f017eb78804dc3f9b8be5a758faedcf59bf35940967d3adb`.
- All 56 source files hashed before/after: **zero drift**. Exact manifests and raw checks: `astra-global-init-43-probes/`.

## Schedule and source identity

`source_request` and `load_sources` in `source/selfhost/sources.goose` maintain a separate declaration postorder through `Source.next_decl` and `Program.first_decl_source`. A pending request already queued elsewhere is promoted for a newly discovered importing child; the authoritative `seen[index].source` prevents duplicate loads. Active/loaded sources are not queued again, so cycles terminate and each successfully parsed source contributes one postvisit marker. Imports are visited in written order; declarations retain their within-file order.

This matches the primary import-graph postorder rule in `build/source/src/main.cpp:435`, including its once-visited cycle behavior. Source records are never reordered after IDs are assigned; root remains source 0, and token/source links remain coherent. Other files' discovery order can differ from frozen42. Imported `main` removal still uses `source_id > 0`, independently of declaration order. A new helper with an intentionally invalid imported main is ignored successfully while its global initializes before the root's use (`imported-main-checks.json`). Existing root dump identity checks also pass.

`check_program` predeclares in the linked order, then checks globals in symbol order. Both existing backends initialize globals in that same symbol order (`codegen_c.goose:2865`, `codegen.goose:2960`); there is no separate backend sort to disagree with the checker. Existing owner qualification covers chain, diamond, queued shared dependency, repeated import, siblings, and cycles at native/Wasm O0/O2.

## Readiness versus checking and execution

`CheckVariable.global_initialized` is separate from `assigned`, `maybeassigned`, and `F_CHECKED`. Only the scheduled global-declaration pass establishes readiness. Flow restore cannot manufacture or revoke initialization. `check_global_use` guards resolved/cached name reads and bare assignment targets; the global phase cannot initialize a future declaration on demand. This is consistent with primary `RequireAssigned` and `CheckLValue` rules for globals.

Pending global uses record effect kind 7. `check_apply_call_effects` rechecks that obligation at callers, including cached callees; write/rebind effects also pass the readiness gate. Ready globals avoid growing a transitive read-effect table. This is a monotone declaration-readiness proof, not a substitute for ordinary flow assignment or mutation analysis.

Creating a callback only prepares its type; it does not check/invoke its body through `check_function`. New paired probes verify the crucial distinction:

| Control | Candidate result |
| --- | --- |
| Global initializer passes unused anonymous callback mentioning future B | accepts |
| Same with named callback | accepts |
| Global initializer actually invokes callback reading future B | rejects |
| Callback first invoked from main after B initializes | accepts |
| Callee assigns B before B's declaration | rejects; frozen42 accepted |
| Same assignment after B's declaration | accepts |

Raw native checker commands/results are in `checks.json`. These establish acceptance/refusal only; no new execution result is claimed. Four exploratory typeof-spelling probes were syntactically unsupported by both compilers and contribute no coverage (`prechecked-checks.json`).

## Composition controls

Retain the three original global-before-init negatives and stdlib_vec native/Wasm outputs, plus the new callback and imported-main controls. Run the normal composed focused/full qualifications. Combine with V3 by placing a valid array equality and an invalid literal-view construction in callbacks reached from global initializers; mode restoration must remain independent of initialization state. Combine with static-global codecs by initializing an immutable owner before a dependent global view through an import chain, then checking worker alias identity and private owner mutation. Apply this narrow three-file patch to the current composed source; replacing its frozen checker wholesale would discard other selected43 changes.
