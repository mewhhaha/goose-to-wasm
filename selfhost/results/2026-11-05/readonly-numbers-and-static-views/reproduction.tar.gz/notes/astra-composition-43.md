# Selected43 composition review

**Hold EG numeric proof until the MATCH dependency defect below is repaired.** The identity half of EG and the other three patches are approved to compose and test on source-review evidence. This is not canonical qualification. No C++ oracle or expensive gate ran for this review; no live source or frozen helper fixture changed.

Reviewed patch SHA256 values (full compiler pins in `astra-composition-43-probes/pins.json`):

| Patch | SHA256 |
| --- | --- |
| EG combined numeric/identity | `e95fce12bc4a4e2738b4d42108bd0678cc145d57540d37f47c5d2da00b3e0484` |
| Native S2 static globals | `09f3fbe462bf0e263c5498ecb7edc7f117c1c3f7e9c6fd00065d14049facd934` |
| Literal construction V3 | `5785c021b7acf9ba3fa7c83b2e4d8a9ad32a8205565f46089facea0f246ed972` |
| Integer count V1 | `ff8423b243ce29ce6b1578da956cace2adbc7e46d3b3f5b856ab8f8175a63e49` |

## 1. Confirmed blocker: MATCH proofs forget named-constant writes

In `semantic-round-eg/source/selfhost/checker.goose:1678`, `check_nonnegative_result` derives an independent proof (`-1`) from nonnegative MATCH constant bounds after calling `check_rely_named`. But `check_rely_named` at line 1605 only visits `left/right/third` and tail-block `last`; MATCH arm values live in the `first` linked list. Their dependencies are never marked.

The EG compiler accepts this checker probe; frozen42 rejects the signed/u64 comparison:

```goose
let K = 3;
fn neg(x: i64&) { x = -1; }
fn main() {
    var flag = 1;
    let u: u64 = 18446744073709551615;
    for i in 2 {
        let n = match flag { 1 => K, _ => 0 };
        print(u > n);
        neg(K);
    }
}
```

The second iteration can load a negative K, contradicting the proof used to select unsigned comparison. Moving `neg(K)` between the initializer and comparison also passes EG. These are confirmed checker acceptances, not claimed executed mismatches. Raw commands/results: `astra-composition-43-probes/match-checks.json`. The equivalent IF proof correctly rejects writable exposure.

Repair: make reliance traverse every value-contributing live MATCH arm recursively before committing an independent proof, including nested MATCH inside IF/block arms; alternatively withhold MATCH proof. Require both write orders, nested MATCH, reversed arm order, a no-write positive, and readonly exposure positive. Preserve AST ownership boundaries; do not scan called function bodies as if they were the result expression. The initial bool-pattern MATCH experiment was malformed and rejected by both compilers; it is retained in `numeric-checks.json` and is not evidence for this finding.

Other EG checks passed: ordinary struct fields named `len` and `cap` receive no proof; the hook requires a resolved property call to builtin 21/22. A copied builtin array length remains nonnegative after array mutation, correctly. Immutable alias-chain writable exposure rejects both before and after comparison. Plain readonly identity does not spuriously invalidate numeric proof. These raw probes are in `numeric-checks.json`.

`check_identity_operand` (line 4413) normalizes both operands, preserves pointee/storage qualification separately from reference constness, and avoids writable-exposure marking for comparison-only addresses. No additional defect found. Apply the narrow EG patch to current42; its older source snapshot must not replace the live checker wholesale.

## 2. Native S2: static descriptors remain a private worker codec

No confirmed defect in `cc_static_global`, `cc_thread_static_types`, `ci_direct`, or `cc_global_image_emit`.

Eligibility requires immutable globals, lifetime provenance `-2`, and frame borrows. The lifetime exporter establishes exact static-root alternatives over initialized cells; existing thread-global checking additionally excludes relative cells. Thus a const type alone does not authorize pointer sharing. Keep those guards intact.

The private codec closes over owning aggregate/array children and stops at Ref/Slice descriptors. Owning bytes remain deep copies; only proven-static descriptors retain identity. The scoped size/skip/write/unpack/read aliases redirect private recursive codec calls and are undefined afterward. Ordinary codecs are emitted separately; verifier/check helpers are not aliased. Existing qualification includes mixed owner/view state, enums, varint-plus-view records, empty/subviews, and preserved ordinary public byte-codec refusal. This does not add general relative-image or fat-reference support.

Compose controls: nested owning arrays with static views, worker mutation leaving parent owners unchanged, repeated worker aliases compared in both readonly identity operand orders, null refs, and static views into immutable global owners. Retain negatives for external/mutable roots, a later nonstatic store into a global holder, and ordinary `from_bytes` of pointer-bearing data.

## 3. Literal V3: comparison exception is contained

No confirmed defect. `literal_comparison` is saved/restored around generated aggregate equality adaptation, and cleared/restored around every fresh function body. Syntax/signature preparation before the clear does not check the executable body. The append path supplies owning-array context for variable elements, including varint; unknown empty literals retain their existing treatment.

Three new checker controls in `literal-checks.json` all reject correctly: an invalid view literal inside a function first checked during equality, inside a callback reached from equality, and after a valid equality in the same body. Frozen42 accepts those invalid constructions. These discriminate callee/callback leakage and failed restoration, rather than merely retesting the direct guard.

Existing V3 corrected focused report is 32/32 and original targeted negatives 2/2. The variable-element fixture uses foreach because its earlier indexing form was unsupported; that malformed predecessor is not positive coverage. Combined controls should keep direct equality/inequality of variable records, valid owned append, empty literals, callback defaults, and nested equality alongside those three negatives.

## 4. Integer count V1: classification and physical read are separate

No confirmed defect in the narrow `cc_loop` patch. It peels Ref wrappers before deciding numeric versus collection iteration, obtains the count place once, and reads the leaf through `cc_read` before conversion. The leaf type retains physical storage metadata, so narrow count references and encoded varint references do not become raw i64 loads. Collection iteration stays on the existing path; ordinary sequence C identity is recorded in qualification.

Compose controls: u8 count with adjacent sentinel, mutable count changed inside the body (initial count evaluated once), encoded varint count, nested references, zero count, and numeric count loops enclosing variable-element traversals. Keep ordinary array/slice loop controls to distinguish this classification fix from variable-prefix frame work.

## Delivery boundary

Fix and requalify the MATCH dependency hole before composing EG. Then run the selected43 focused matrix and the normal frozen full qualification on the composed compiler; isolated results cannot establish cross-patch correctness. Source overlap is concentrated in checker state/variable tracking between EG and V3. Native static codec and count handling touch separate functions but should share identity and physical-read controls above. Existing EG measurements disclose additional CPU/RSS cost; no review result here establishes a performance gain.
