# Selected43 EH review addendum

**EH repairs the confirmed EG MATCH dependency defect. Approved to compose and test.** No new defect found in this bounded followup. This supersedes the EG blocker in `astra-composition-43.md` for the exact replacement below; it does not establish canonical qualification.

| Artifact | SHA256 |
| --- | --- |
| `semantic-round-eh/match-reliance-fix.patch` | `e84b7522f3a00509b333fa6dfaa681af5aacc43ada491fb3078b3926ba104c7b` |
| `semantic-round-eh/combined-numeric-identity-match.patch` | `217821e954ac263390328c2a4c70c18a6964fa08031998b35d3e1f24ce35e839` |
| EH `source/selfhost/checker.goose` | `dde2f7e9a4d57bf06e8fffed1b04816ecea7f4c67145be79de42c2724fa90699` |
| EH `build/goose` | `74826bee3c44e2ee39b95ca1e8ce09057f6625c96b990d5c3fe575f582028b5a` |

All four hashes remained unchanged during this review. Raw commands/results and before/after pins: `astra-composition-43-eh-probes/`.

`check_rely_named` now traverses MATCH arm values through the `first` list, recurses through IF result branches, and excludes bottom expressions. This matches the value contributors used by `check_integer_constants` and `check_flex_integer`: those calculate bounds over result branches, not the scrutinee/predicate. Existing tail-block handling excludes preceding statements. Called function bodies retain their separate ownership boundary. Nested MATCH dependencies therefore reach `check_named_writable` without falsely freezing selection state.

Eight fresh checker checks all behaved as required:

- Both original Astra K-write probes, previously accepted by EG, now reject with named-constant writable-exposure diagnostics.
- Mutating a named global used only as MATCH selector or IF predicate remains accepted when every result arm is nonnegative.
- Nested MATCH writable-result dependency and MATCH-inside-IF writable dependency reject.
- Readonly result dependencies and a noncontributing return arm remain accepted.

These are checker results, not newly executed runtime results. The owner's sealed evidence separately records 16/16 new static controls, 268/268 native/Wasmtime and 134/134 V8 focus, with no frontend loss. I did not rerun those gates or the C++ oracle, and changed no live source.

Compose the exact combined replacement against current42; avoid layering a whole older EG checker over the final source. Retain these eight controls and the earlier ordinary-struct len/cap and alias-chain mutation controls in the composed qualification. No additional approval blocker remains from this review.
