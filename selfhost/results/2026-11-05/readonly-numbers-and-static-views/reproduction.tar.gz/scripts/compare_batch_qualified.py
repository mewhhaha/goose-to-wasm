from pathlib import Path
import collections, json, sys
w=Path(__file__).resolve().parent
v=int(sys.argv[1]);old=json.loads((w/f'c-only-conformance-{v-1}/report.json').read_text());new=json.loads((w/f'c-only-conformance-{v}-qualified/report.json').read_text())
def rows(r):
 result={(x['case'],x['level']):x for x in r['results']};assert len(result)==len(r['results']);return result
a=rows(old);b=rows(new);shared=a.keys()&b.keys()
r={'baseline':v-1,'candidate':v,'baseline_summary':old['summary'],'candidate_summary':new['summary'],
 'shared_gains':[b[k] for k in sorted(shared) if a[k]['status']!='pass' and b[k]['status']=='pass'],
 'shared_regressions':[b[k] for k in sorted(shared) if a[k]['status']=='pass' and b[k]['status']!='pass'],
 'new_rows':[b[k] for k in sorted(b.keys()-a.keys())],
 'new_failures':[b[k] for k in sorted(b.keys()-a.keys()) if b[k]['status']!='pass'],
 'removed_rows':[a[k] for k in sorted(a.keys()-b.keys())]}
assert not r['removed_rows']
(w/f'comparison-{v}.json').write_text(json.dumps(r,indent=2)+'\n')
print(new['summary'],'gains',len(r['shared_gains']),'regressions',len(r['shared_regressions']),'new',len(r['new_rows']))
print('Failure phases',dict(collections.Counter(x['phase'] for x in b.values() if x['status']!='pass')))
for x in r['shared_regressions']:print('REGRESSION',x)
