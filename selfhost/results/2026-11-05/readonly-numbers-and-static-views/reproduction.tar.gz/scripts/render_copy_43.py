from pathlib import Path
import hashlib
import json

root = Path('/home/jacobt/src/goose-to-wasm')
work = root / 'build/completion-runs'

def read(path):
    return json.loads(path.read_text())

examples = read(work / 'goose-examples-43/report.json')
host = read(work / 'goose-host-43/report.json')
proof = read(work / 'c-only-bootstrap-43/report.json')
comparison = read(work / 'comparison-43.json')
full = read(work / 'c-only-conformance-43-qualified/report.json')
v8 = read(work / 'c-only-v8-43-qualified/report.json')
remaining = read(work / 'remaining-phases-43.json')
case_targets = {r['id']: r['target'] for r in read(root / 'tests/conformance/cases.json')['cases']}
wasm_count = sum(case_targets[r['case']] == 'wasm-direct' for r in v8['results'])
native_count = sum(case_targets[r['case']] == 'native' for r in v8['results'])
invalid_count = sum(r['status'] != 'pass' and r['phase'] == 'type-error' for r in full['results'])

assert examples['status'] == host['status'] == proof['status'] == 'passed'
assert not comparison['shared_regressions'] and not comparison['new_failures']

build = {(r['name'], r['backend']): r['wall_seconds']['median'] * 1000 for r in examples['compile_summary']}
runtime = {(r['name'], r['backend'], r['mode']): r['wall_seconds']['median'] * 1000 for r in host['runtime_summary']}
direct = [value for (name, backend), value in build.items() if backend == 'direct']
native = [value for (name, backend), value in build.items() if backend == 'native']
summary = comparison['candidate_summary']
facts = {
    'PASSED': f"{summary['passed']:,}",
    'TOTAL': f"{summary['selected']:,}",
    'FAILED': str(summary['failed']),
    'MACHINE': 'AMD Ryzen 7 3800X pinned to CPU 7',
    'SAMPLES': 'Five',
    'DIRECT_BUILD_RANGE': f'{min(direct):.1f}–{max(direct):.1f}',
    'NATIVE_BUILD_RANGE': f'{min(native):.1f}–{max(native):.1f}',
    'SORTING_AOT': f"{runtime['sorting', 'direct', 'precompiled-minimal']:.1f}",
    'SORTING_NATIVE': f"{runtime['sorting', 'native', 'native-C']:.1f}",
    'BENCHMARK_CONTEXT': "The native column uses this compiler's C backend. Snapshot 42 was measured separately; these runs do not establish a matched runtime improvement.",
    'BOOTSTRAP_STATUS': 'Snapshot 43 passed C-only fixed-point verification; its final two generated C outputs match (C2 = C3).',
    'CHANGE_SCOPE': 'This batch corrects numeric and identity checks, literal borrowing, loop counts, initializer order and worker snapshots.',
    'CONFORMANCE_CONTEXT': f"Against snapshot 42, {len(comparison['shared_gains'])} of {comparison['baseline_summary']['selected']:,} shared checks improved and none regressed. All {len(comparison['new_rows'])} new source-authored checks passed.",
    'WASM_CORPUS_CONTEXT': f'The curated Wasm corpus passed {wasm_count:,}/{wasm_count:,} checks each in Wasmtime and V8; all {native_count:,} curated native controls also passed.',
    'KNOWN_GAPS': f'The remaining failures are {invalid_count} accepted invalid programs and {remaining["compiler_refusal"]} runtime contracts rejected during Goose compilation. Every runtime check that reached execution passed.',
    'FAILURE_PHASES': f'The {summary["failed"]} remaining failures comprise {invalid_count} invalid-program checks and {remaining["compiler_refusal"]} runtime contracts; none failed C compilation or execution.',
    'GENERATED_C_SHA256': proof['executable_c_sha256'],
    'COMPILER_SHA256': proof['executable_sha256'],
    'RUNTIME_WARMUPS': 'one',
    'METHOD_AND_IDENTITIES': 'Both targets use the exact qualified Goose compiler at Goose O2; native C uses GCC 16.2.1 O2. Engines are Wasmtime 50.0.1 and Node 24.22.1. The operating-system page cache is retained.',
    'COHORT_CONTEXT': 'The compiler, source, standard library, workload and tool identities are pinned in the raw reports. Agents paused expensive work during this shared-machine measurement window.',
    'GUARD_EVIDENCE_LINK': 'The qualification capsule retains paired checker guards, exact commands and sources.',
    'REJECTED_EXPERIMENTS_AND_EVIDENCE': 'Astra reviewed the composition and initializer order. The retained failed migration run documents seven restored transitive helper files; expected outputs and compiler sources were unchanged.',
}
rows = []
for example in examples['examples']:
    name = example['name']
    rows.append(f"| {name} | {build[name, 'direct']:.2f} | {build[name, 'native']:.2f} | {runtime[name, 'direct', 'precompiled-minimal']:.2f} | {runtime[name, 'native', 'native-C']:.2f} |")
facts['EXAMPLE_ROWS'] = '\n'.join(rows)
facts['COST_GUARD_CONTEXT'] = 'A separate matched numeric/identity checker guard measured a 2.13% peak-RSS increase; shared-machine CPU results do not establish a speedup.'
facts['DEBUG_EVIDENCE_LINK'] = 'This isolated codec comparison uses the snapshot-42-based component compiler; exact GDB scripts, commands, tool identities and raw observations are in the batch 43 capsule.'
facts['PRIOR_REJECTIONS_LINK'] = '../../../../selfhost/results/2026-11-05/match-render-and-views/reproduction.tar.gz'
facts['CAPSULE_LINK'] = '../../../../selfhost/results/2026-11-05/readonly-numbers-and-static-views/reproduction.tar.gz'
targets = {
    'README.md.in': root / 'README.md',
    'selfhost-README.md.in': root / 'selfhost/README.md',
    'bench-README.md.in': root / 'bench/README.md',
    'dated-results-README.md.in': root / 'bench/results/2026-11-05/readonly-numbers-and-static-views/README.md',
}
for template, target in targets.items():
    text = (work / 'readme-copy-43' / template).read_text()
    for key, value in facts.items():
        text = text.replace('{{' + key + '}}', value)
    assert '{{' not in text, template
    target.write_text(text)
(root / 'bench/results/2026-11-05/readonly-numbers-and-static-views/copy-facts.json').write_text(json.dumps(facts, indent=2) + '\n')
for name, report in [('examples-latest.json', 'examples.json'), ('wasmtime-host-latest.json', 'host.json')]:
    path = root / 'bench/results' / name
    current = read(path)
    report_path = '2026-11-05/readonly-numbers-and-static-views/' + report
    current.update(report=report_path,
                   sha256=hashlib.sha256((root / 'bench/results' / report_path).read_bytes()).hexdigest())
    path.write_text(json.dumps(current, indent=2) + '\n')
print('Rendered Terra43 templates from qualified measurements')
