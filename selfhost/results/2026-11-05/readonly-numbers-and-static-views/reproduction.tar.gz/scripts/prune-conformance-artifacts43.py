from pathlib import Path
import hashlib,json,shutil,time
w=Path('/home/jacobt/src/goose-to-wasm/build/completion-runs');rows=[]
for version in range(37,42):
 for prefix in ('c-only-conformance-','c-only-v8-'):
  p=w/(prefix+str(version));report=p/'report.json'
  if not report.is_file(): continue
  data=json.loads(report.read_text())
  assert 'summary' in data and data.get('input_sha256')==data.get('input_sha256_after')
  for folder in p.rglob('artifacts'):
   if folder.is_symlink() or not folder.is_dir(): continue
   files=[x for x in folder.rglob('*') if x.is_file()]
   for f in files: assert str(f) not in data['input_sha256'],str(f)
   rows.append(dict(path=str(folder),files=len(files),bytes=sum(f.stat().st_size for f in files),report_sha256=hashlib.sha256(report.read_bytes()).hexdigest()))
   shutil.rmtree(folder)
print('removed only reproducible unpinned emitted conformance artifacts',sum(r['files'] for r in rows),sum(r['bytes'] for r in rows),flush=True)
(w/'artifact-pruning-43.json').write_text(json.dumps(dict(status='passed',scope='Generated C/Wasm/native program files only; report bytes and all pinned inputs preserved',folders=rows),indent=2)+'\n')
