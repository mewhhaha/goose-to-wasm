# Snapshot 42 checker interval diagnostic

One privately instrumented diagnostic run, captured during concurrent qualification. It is not comparative performance evidence, and the interval prints are not sampled CPU hotspots. No changes were made to the frozen workload, stdlib, or production source.

## Instrumentation

The verified snapshot 42 producer compiled the private `source/` copy, whose only source modification is recorded in `instrumentation.diff` (checker interval clock checkpoints plus stdout formatter). The generated C and private O2 executable are `compiler.c` and `goose-profiled`; exact build commands and wait4 usage are recorded in `emit-c.command.json`, `clang-o2.command.json` and their resource files. Build workload hashes are in `inputs-before.json` and `inputs-after-build.json`.

The one workload command and cwd are in `workload.command.json`. It checked the unmodified frozen `build/completion-runs/snapshot-42/selfhost/main.goose` with current stdlib, native target, O0, and `--check --wasm-stats`; it did not compile C output. Before/after hashes for all frozen selfhost source files, stdlib files and the profiling executable match (`workload-inputs-before.json`, `workload-inputs-after.json`). Captured stdout is the phase log; stderr is empty.

## Observed intervals

- Declaration preparation and global checks: 0.165 s
- Main and worker checks: 2.584 s
- Unreached functions: 0.043 s
- Type and program validation: 0.023 s
- Scope/pool preparation plus lifetime check: 55.519 s
- Thread global validation: 0.003 s

The compiler phase stats report typecheck 58.380 s, parse 0.243 s, optimize 0.103 s, backend 0 (check-only). Workload wait4 usage: 58.74 s wall, 58.48 s user+system CPU, 528,932 KiB peak RSS. Workload size: 282,534 nodes, 1,927 types, 31 source files.

The interval after type/program validation includes building scope lifetime arrays and pool references before `check_lifetimes`, so it attributes that setup together with lifetime checking. It isolates the dominant lifetime segment from ordinary declaration/function/unreached/validation checking, but does not split setup from the lifetime algorithm.
