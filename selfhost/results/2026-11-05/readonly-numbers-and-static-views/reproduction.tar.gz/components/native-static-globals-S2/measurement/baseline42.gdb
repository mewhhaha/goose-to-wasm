set pagination off
set debuginfod enabled off
set confirm off
python
import gdb,json
packets=[]
workers=[]
exit_code=None
def slices():
 obj=gdb.parse_and_eval('(GGlobals*)gs_gl').dereference()
 result={}
 for field in obj.type.strip_typedefs().fields():
  value=obj[field.name]
  typ=value.type.strip_typedefs()
  if typ.code!=gdb.TYPE_CODE_STRUCT:continue
  names={item.name for item in typ.fields()}
  if names=={'base','len'}:result[field.name]={'base':int(value['base']),'len':int(value['len'])}
 return result
class Packet(gdb.Breakpoint):
 def stop(self):
  packets.append({'bytes':int(gdb.parse_and_eval('bytes')),'slices':slices()})
  return False
class Release(gdb.Breakpoint):
 def stop(self):
  node=gdb.parse_and_eval('g_allocations');count=0
  while int(node):count+=1;node=node.dereference()['next']
  regions=gdb.parse_and_eval('g_regions');slots=int(gdb.parse_and_eval('g_region_count'));initialized=0
  for index in range(slots):
   if int((regions+index).dereference()['base']):initialized+=1
  current=slices();identity={key:value==packets[-1]['slices'][key] for key,value in current.items()}
  workers.append({'legacy_bytes':int(gdb.parse_and_eval('g_legacy_bytes')),'managed_allocations':count,'initialized_regions':initialized,'slices':current,'slice_identity':identity})
  return False
def exited(event):
 global exit_code
 exit_code=getattr(event,'exit_code',None)
gdb.events.exited.connect(exited)
Packet('g_worker_start');Release('g_worker_release')
gdb.execute('run > /home/jacobt/src/goose-to-wasm/build/completion-runs/native-static-globals-S2/measurement/baseline42-program.stdout')
with open('/home/jacobt/src/goose-to-wasm/build/completion-runs/native-static-globals-S2/measurement/baseline42-observed.json',"w") as output:json.dump({"exit_code":exit_code,"packets":packets,"workers":workers},output,indent=2)
end
