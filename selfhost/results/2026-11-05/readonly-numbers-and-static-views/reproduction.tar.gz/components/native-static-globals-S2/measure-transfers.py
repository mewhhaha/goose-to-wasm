from pathlib import Path
import hashlib,json,subprocess,shutil,time
base=Path(__file__).resolve().parent;root=Path('/home/jacobt/src/goose-to-wasm');out=base/'measurement';out.mkdir(exist_ok=False)
source=base/'measurement.goose';cc=Path(shutil.which('clang')).resolve();gdb=Path(shutil.which('gdb')).resolve()
compilers=[('baseline42',root/'build/completion-runs/c-only-bootstrap-42/goose'),('candidate',base/'build/goose')]
def sha(path):
 with Path(path).open('rb') as file:return hashlib.file_digest(file,'sha256').hexdigest()
pins={str(path):sha(path) for path in [source,cc,gdb,Path(__file__).resolve(),*[path for _,path in compilers],*root.joinpath('stdlib').rglob('*.goose')]}
r={'status':'running','method':'Same Goose workload and Clang O0/g flags. GDB children observe packet bytes at g_worker_start, and TLS managed allocation bytes/count, initialized regions and static slice descriptors at g_worker_release. No debugger runtime comparison. Generated C is unmodified.','input_sha256':pins,'commands':[],'observations':{}}
def save():(out/'report.json').write_text(json.dumps(r,indent=2)+'\n')
def run(label,command):
 command=list(map(str,command));start=time.monotonic();child=subprocess.run(command,cwd=root,text=True,capture_output=True,timeout=120)
 (out/(label+'.stdout')).write_text(child.stdout);(out/(label+'.stderr')).write_text(child.stderr)
 r['commands'].append(dict(command=command,exit_code=child.returncode,seconds=time.monotonic()-start));save();assert child.returncode==0,child.stderr[-3000:]
try:
 for label,compiler in compilers:
  c=out/(label+'.c');exe=out/label;observed=out/(label+'-observed.json');stdout=out/(label+'-program.stdout')
  run(label+'-emit',[compiler,source,'--stdlib',root/'stdlib','--target','native','--standalone','-O0','-o',c]);pins[str(c)]=sha(c)
  run(label+'-cc',[cc,'-std=gnu11','-O0','-g',c,'-pthread','-lm','-ldl','-o',exe]);pins[str(exe)]=sha(exe)
  script=out/(label+'.gdb')
  script.write_text('set pagination off\nset debuginfod enabled off\nset confirm off\npython\n'+'''import gdb,json
packets=[]
workers=[]
exit_code=None
def slices():
 obj=gdb.parse_and_eval('(GGlobals*)gs_gl').dereference()
 result={}
 for field in obj.type.strip_typedefs().fields():
  value=obj[field.name]
  typ=value.type.strip_typedefs()
  if typ.code!=gdb.TYPE_CODE_STRUCT:continue
  names={item.name for item in typ.fields()}
  if names=={'base','len'}:result[field.name]={'base':int(value['base']),'len':int(value['len'])}
 return result
class Packet(gdb.Breakpoint):
 def stop(self):
  packets.append({'bytes':int(gdb.parse_and_eval('bytes')),'slices':slices()})
  return False
class Release(gdb.Breakpoint):
 def stop(self):
  node=gdb.parse_and_eval('g_allocations');count=0
  while int(node):count+=1;node=node.dereference()['next']
  regions=gdb.parse_and_eval('g_regions');slots=int(gdb.parse_and_eval('g_region_count'));initialized=0
  for index in range(slots):
   if int((regions+index).dereference()['base']):initialized+=1
  current=slices();identity={key:value==packets[-1]['slices'][key] for key,value in current.items()}
  workers.append({'legacy_bytes':int(gdb.parse_and_eval('g_legacy_bytes')),'managed_allocations':count,'initialized_regions':initialized,'slices':current,'slice_identity':identity})
  return False
def exited(event):
 global exit_code
 exit_code=getattr(event,'exit_code',None)
gdb.events.exited.connect(exited)
Packet('g_worker_start');Release('g_worker_release')
'''+'gdb.execute('+repr('run > '+str(stdout))+')\n'+'with open('+repr(str(observed))+',"w") as output:json.dump({"exit_code":exit_code,"packets":packets,"workers":workers},output,indent=2)\nend\n')
  pins[str(script)]=sha(script);run(label+'-gdb',[gdb,'-q','--batch','-x',script,'--args',exe]);observation=json.loads(observed.read_text());r['observations'][label]=observation;save()
  assert observation['exit_code']==0 and len(observation['packets'])==4 and len(observation['workers'])==4,observation
  assert stdout.read_text()=='static view measurement ok\n'
 assert all(all(worker['slice_identity'].values()) for worker in r['observations']['candidate']['workers'])
 r['input_sha256_after']={p:sha(p) for p in pins};assert pins==r['input_sha256_after'];r['status']='passed';save()
except BaseException as error:r.update(status='failed',error=repr(error));save();raise
