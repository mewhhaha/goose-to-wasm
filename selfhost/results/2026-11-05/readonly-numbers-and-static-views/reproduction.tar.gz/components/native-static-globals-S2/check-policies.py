from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

base = Path(__file__).resolve().parent
root = Path('/home/jacobt/src/goose-to-wasm')
out = base / 'policies-v2'
out.mkdir(exist_ok=False)
cc = Path(shutil.which('clang')).resolve()
compilers = {'baseline42': root / 'build/completion-runs/c-only-bootstrap-42/goose', 'candidate': base / 'build/goose'}

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

pins = {str(p): sha(p) for p in [Path(__file__), cc, *compilers.values(), base / 'ordinary-policy.goose', base / 'controls-v2/deserialize_views.goose']}
report = {'status': 'running', 'input_sha256': pins, 'commands': [], 'checks': []}

def save():
    (out / 'report.json').write_text(json.dumps(report, indent=2) + '\n')

def run(label, command, environment=None):
    result = subprocess.run(list(map(str, command)), capture_output=True, timeout=120, env=environment)
    (out / (label + '.stdout')).write_bytes(result.stdout)
    (out / (label + '.stderr')).write_bytes(result.stderr)
    report['commands'].append({'command': list(map(str, command)), 'exit_code': result.returncode, 'stdout': label + '.stdout', 'stderr': label + '.stderr'})
    save()
    return result

try:
    for label, compiler in compilers.items():
        result = run(label + '-ordinary', [compiler, base / 'ordinary-policy.goose', '--stdlib', root / 'stdlib', '--target', 'native', '--standalone', '-O0', '-o', out / (label + '-ordinary.c')])
        assert result.returncode == 0, result.stderr.decode()
        result = run(label + '-deserialize', [compiler, base / 'controls-v2/deserialize_views.goose', '--stdlib', root / 'stdlib', '--target', 'native', '--standalone', '-O0', '-o', out / (label + '-deserialize.c')])
        assert result.returncode == 1 and b'needs packed/relative image verification' in result.stderr.lower(), result.stderr.decode()
    assert (out / 'baseline42-ordinary.c').read_bytes() == (out / 'candidate-ordinary.c').read_bytes()
    assert (out / 'baseline42-deserialize.stderr').read_bytes() == (out / 'candidate-deserialize.stderr').read_bytes()
    report['checks'].append('Ordinary owner/pool thread program emits byte-identical C; public from_bytes Slice refusal is byte-identical.')
    for name, expected in [('static_aliases', b'main static identities ok\nworker static identities ok\n'), ('owning_snapshots', b'private owners and shared static views ok\n')]:
        source = base / 'controls-v2' / (name + '.goose')
        pins[str(source)] = sha(source)
        for level in [0, 2]:
            label = name + '-O' + str(level)
            artifact = out / (label + '.c')
            binary = out / label
            result = run(label + '-emit', [compilers['candidate'], source, '--stdlib', root / 'stdlib', '--target', 'native', '--standalone', '-O' + str(level), '-o', artifact])
            assert result.returncode == 0, result.stderr.decode()
            result = run(label + '-cc', [cc, '-std=gnu11', '-O' + str(level), '-g', '-fsanitize=address,undefined', '-fno-omit-frame-pointer', artifact, '-pthread', '-lm', '-ldl', '-o', binary])
            assert result.returncode == 0, result.stderr.decode()
            environment = dict(os.environ, ASAN_OPTIONS='detect_leaks=1:halt_on_error=1', UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
            result = run(label + '-run', [binary], environment)
            assert result.returncode == 0 and result.stdout == expected and result.stderr == b'', (label, result.returncode, result.stderr.decode())
            report['checks'].append(label + ' ASan/UBSan exact output, no diagnostics')
    report['input_sha256_after'] = {p: sha(p) for p in pins}
    assert pins == report['input_sha256_after']
    report['status'] = 'passed'
    save()
except BaseException as error:
    report.update(status='failed', error=repr(error))
    save()
    raise
