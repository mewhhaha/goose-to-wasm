from pathlib import Path
import hashlib,json,subprocess,time
base=Path(__file__).resolve().parent
out=base/'selfemit'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
pins=dict(json.loads((out/'report.json').read_text())['input_sha256'])
pins[str(out/'goose')]=sha(out/'goose')
pins[str(out/'compiler.c')]=sha(out/'compiler.c')
pins[str(Path(__file__).resolve())]=sha(__file__)
command=list(map(str,[out/'goose',base/'source/selfhost/main.goose','--stdlib','/home/jacobt/src/goose-to-wasm/stdlib','--target','native','--standalone','-O0','-o',out/'repeat.c']))
start=time.monotonic()
with (out/'repeat.stdout').open('w') as stdout,(out/'repeat.stderr').open('w') as stderr:
 result=subprocess.run(command,stdout=stdout,stderr=stderr,timeout=180)
r={'status':'failed','input_sha256':pins,'commands':[{'command':command,'exit_code':result.returncode,'seconds':time.monotonic()-start}]}
try:
 assert result.returncode==0
 assert sha(out/'repeat.c')==sha(out/'compiler.c')
 r['input_sha256_after']={p:sha(p) for p in pins};assert pins==r['input_sha256_after']
 r.update(status='passed',repeat_c_sha256=sha(out/'repeat.c'))
finally:(out/'repeat-report.json').write_text(json.dumps(r,indent=2)+'\n')
