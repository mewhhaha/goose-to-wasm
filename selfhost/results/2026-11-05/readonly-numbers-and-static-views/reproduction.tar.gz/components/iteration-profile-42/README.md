# Snapshot 42 own-source phase profile

A single diagnostic self-compile of frozen snapshot 42's `selfhost/main.goose` with the qualified snapshot 42 binary and current stdlib. Run during concurrent qualification; do not use as a comparative timing claim. No sampled hotspot profile was collected.

Command argv and cwd are in `command.json`. `inputs-before.json` and `inputs-after.json` record SHA-256 for the compiler binary, requested source entry, and every stdlib `.goose` file; they compare identical. Captured compiler stdout/stderr are empty. `resource-usage.json` records wall, child CPU, and peak RSS from `wait4`. `stats.json` contains the compiler's actual phase measurements.

Result: 54.50 s wall, 54.27 s user+system CPU, 562,840 KiB peak RSS. Parse 0.248 s; typecheck 53.669 s; optimize 0.091 s; backend 0.464 s. Output C is 17,841,547 bytes. Workload reported 31 source files, 282,534 nodes, 1,927 types, and 1,108 functions.
