EH qualified: final42 numeric proof and identity correction

Use `combined-numeric-identity-match.patch` on final42; only `selfhost/checker.goose` changes. The complete sealed source retains final42 member-call, lexical-target and rendering work. No live files were edited.

`match-reliance-fix.patch` isolates the correction to rejected EG. The dependency visitor now follows each live match-arm value and each IF result branch recursively, including named initializer ancestry. It skips bottom values, predicates, selectors and block prefix statements. EG is preserved unchanged; `rejected-predecessor-eg.json` records why its earlier green gates were insufficient. New controls preserve their original expectations: EG8/16, EH16/16.

Actual gates:268/268 focused native+Wasmtime,134/134 focused V8;2229/2229 regression rows in each Wasmtime and V8. Frontend310 valid,89 typing,540 upstream;1767 proper negative refusals retained, zero positive regressions/crashes/timeouts. Original u64_cmp_readonly_refs and syntax_additions execute correctly at O0/O2. The debug scalar-identity module validates and runs in both engines; its main uses i32.eq/ne with no i64 equality. The readonly-to-writable cast bypass remains refused.

Own-source check passes in57.967s. Same-producer41/Clang23-O2 ABBA checks on pinned final42 source use CPU7, with root canonical jobs excluding it: baseline61.994CPU seconds/540514KiB, EH58.428CPU seconds/552042KiB. RSS+2.13%; the measured CPU decrease is not a speedup claim on a shared workstation. Checked IR counts match exactly.

Exact hashes, source/tool/workload pins, commands and raw reports are linked from qualification.json. Source and patch hashes remain identical to source-seal.json; full canonical43 composition and overall compiler completion remain parent work.
