from pathlib import Path
import hashlib,json,os,signal,time,statistics
root=Path(__file__).resolve().parent
repo=root.parents[2]
work=root.parent/'snapshot-42'
library=repo/'stdlib'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
inputs=[p for base in [work/'selfhost',work/'native',library] for p in base.rglob('*') if p.is_file()]
pins={str(p):digest(p) for p in inputs}
(root/'cost-input-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
rows=[]
def run(name,exe,args):
 cmd=['/usr/bin/taskset','-c','7',str(exe),*map(str,args)]
 stdout=root/(name+'.stdout');stderr=root/(name+'.stderr');start=time.monotonic()
 pid=os.fork()
 if pid==0:
  os.setsid()
  out=os.open(stdout,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
  err=os.open(stderr,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
  os.dup2(out,1);os.dup2(err,2)
  os.execv(cmd[0],cmd)
 timeout=False
 while True:
  done,status,usage=os.wait4(pid,os.WNOHANG)
  if done:break
  if time.monotonic()-start>180:
   timeout=True;os.killpg(pid,signal.SIGKILL);done,status,usage=os.wait4(pid,0);break
  time.sleep(.1)
 row=dict(name=name,command=cmd,executable_sha256=digest(exe),exit_code=os.waitstatus_to_exitcode(status),timeout=timeout,user_seconds=usage.ru_utime,system_seconds=usage.ru_stime,wall_seconds=time.monotonic()-start,maxrss_kib=usage.ru_maxrss,stdout=stdout.read_text(),stderr=stderr.read_text())
 rows.append(row);(root/'cost.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,json.dumps(row),flush=True)
 if row['exit_code']!=0:raise RuntimeError(name+' failed')
main=work/'selfhost/main.goose'
for label in ['before-1','after-1','after-2','before-2']:
 exe=root/'probe'
 if label.startswith('before'):exe=root/'control/probe'
 run(label,exe,[main,library])
run('own-source',root/'build/goose',[root/'source/selfhost/main.goose','--stdlib',library,'--check'])
assert pins=={str(p):digest(p) for p in inputs},'input source changed'
before=[r for r in rows if r['name'].startswith('before')];after=[r for r in rows if r['name'].startswith('after')]
mean=lambda rs,key:statistics.mean(r[key] for r in rs)
summary={}
for key in ['user_seconds','system_seconds','maxrss_kib']:
 b=mean(before,key);a=mean(after,key);summary[key]={'before':b,'after':a,'change_percent':(a/b-1)*100}
b=sum(mean(before,k) for k in ['user_seconds','system_seconds']);a=sum(mean(after,k) for k in ['user_seconds','system_seconds'])
summary['cpu_seconds']={'before':b,'after':a,'change_percent':(a/b-1)*100}
summary['own_source']=rows[-1];summary['method']='Two same-producer41 ClangO2 probes; ABBA sequential per-child wait4; fixed final42 workload pinned recursively; CPU7; semantic-fix cost, no speedup claim.'
(root/'cost-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print('SUMMARY',json.dumps(summary),flush=True)
