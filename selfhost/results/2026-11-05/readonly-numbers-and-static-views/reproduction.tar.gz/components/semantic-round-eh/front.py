from pathlib import Path
import concurrent.futures,json,subprocess,time
r=Path(__file__).parent.resolve();previous=Path('/dev/shm/goose-selfhost-work/semantic-round-z');library=Path('stdlib').resolve()
for label,exe in [('before',r.parent/'c-only-bootstrap-42/goose'),('after',r/'probe')]:
 d=r/('front-'+label);d.mkdir(exist_ok=True)
 def run(row):
  command=[str(exe),row['source'],str(library)]
  if label=='before':command=[str(exe),row['source'],'--stdlib',str(library),'--check']
  try:
   p=subprocess.run(command,capture_output=True,text=True,timeout=8);return dict(source=row['source'],exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr)
  except subprocess.TimeoutExpired:return dict(source=row['source'],exit_code=124,stdout='',stderr='TIMEOUT')
 for name in ['semantic-all-valid','typing','negative-type','upstream-positive']:
  rows=json.loads((previous/(name+'.json')).read_text());start=time.monotonic()
  with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,rows))
  (d/(name+'.json')).write_text(json.dumps(results,indent=2)+'\n');print(label,name,'accepted',sum(x['exit_code']==0 for x in results),'/',len(results),'seconds',round(time.monotonic()-start,3),flush=True)
