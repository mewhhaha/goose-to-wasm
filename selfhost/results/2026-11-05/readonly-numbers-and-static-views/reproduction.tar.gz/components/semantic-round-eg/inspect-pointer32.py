from pathlib import Path
import json,hashlib
root=Path(__file__).parent
binary=(root/'pointer32-debug.wasm').read_bytes()
def leb(data,pos):
 value=0;shift=0
 while True:
  b=data[pos];pos+=1;value|=(b&127)<<shift
  if not b&128:return value,pos
  shift+=7
  if shift>70:raise ValueError('invalid LEB')
def name(data,pos):
 n,pos=leb(data,pos);return data[pos:pos+n].decode(),pos+n
names={};bodies=[];imports=0;pos=8
while pos<len(binary):
 section=binary[pos];size,start=leb(binary,pos+1);end=start+size;at=start
 if section==0:
  title,at=name(binary,at)
  if title=='name':
   while at<end:
    kind=binary[at];n,sub=leb(binary,at+1);stop=sub+n
    if kind==1:
     count,sub=leb(binary,sub)
     for _ in range(count):index,sub=leb(binary,sub);text,sub=name(binary,sub);names[index]=text
    at=stop
 elif section==2:
  count,at=leb(binary,at)
  for _ in range(count):
   _,at=name(binary,at);_,at=name(binary,at);kind=binary[at];at+=1
   if kind!=0:raise ValueError('unexpected non-function import')
   _,at=leb(binary,at);imports+=1
 elif section==10:
  count,at=leb(binary,at)
  for _ in range(count):
   n,begin=leb(binary,at);bodies.append((begin,begin+n));at=begin+n
 pos=end
index=next(k for k,v in names.items() if v=='main');pos,end=bodies[index-imports];count,pos=leb(binary,pos)
for _ in range(count):_,pos=leb(binary,pos);pos+=1
instructions=[]
while pos<end:
 start=pos;op=binary[pos];pos+=1;detail=None
 if op in (2,3,4,6,0xd0):detail,pos=leb(binary,pos)
 elif op in (0x0c,0x0d,0x10,0x12,0x14,0x20,0x21,0x22,0x23,0x24,0x25,0x26,0x3f,0x40,0x41,0x42,0xd2):detail,pos=leb(binary,pos)
 elif op in (0x11,0x13):a,pos=leb(binary,pos);b,pos=leb(binary,pos);detail=[a,b]
 elif op==0x0e:
  n,pos=leb(binary,pos);detail=[]
  for _ in range(n+1):a,pos=leb(binary,pos);detail.append(a)
 elif 0x28<=op<=0x3e:a,pos=leb(binary,pos);b,pos=leb(binary,pos);detail=[a,b]
 elif op==0x43:pos+=4
 elif op==0x44:pos+=8
 elif op==0x1c:
  n,pos=leb(binary,pos);pos+=n
 elif op==0xfc:
  sub,pos=leb(binary,pos);detail=sub
  if sub in (8,10,12,14):_,pos=leb(binary,pos);_,pos=leb(binary,pos)
  elif sub in (9,11,13,15,16,17):_,pos=leb(binary,pos)
  elif sub>7:raise ValueError('unsupported extended instruction')
 elif not(op in (0,1,5,0x0b,0x0f,0x1a,0x1b,0xd1) or 0x45<=op<=0xc4):raise ValueError('unsupported opcode '+hex(op))
 instructions.append(dict(offset=start,opcode=hex(op),immediate=detail))
assert pos==end
comparisons=[]
for i,v in enumerate(instructions):
 if v['opcode'] in ['0x46','0x47','0x51','0x52']:
  comparisons.append(dict(**v,name={'0x46':'i32.eq','0x47':'i32.ne','0x51':'i64.eq','0x52':'i64.ne'}[v['opcode']],context=instructions[max(0,i-5):i+1]))
assert any(x['name']=='i32.eq' for x in comparisons)
assert any(x['name']=='i32.ne' for x in comparisons)
assert not any(x['name'].startswith('i64.') for x in comparisons)
report=dict(status='passed',module_sha256=hashlib.sha256(binary).hexdigest(),function_index=index,function_name=names[index],body_instruction_count=len(instructions),comparisons=comparisons,method='Parse name/code sections and walk every main instruction, skipping its specified immediates. Reference identity uses i32.eq/ne, with no i64 equality in this scalar storage identity body. Actual module validation/execution is separately recorded for Wasmtime and V8.')
(root/'pointer32-inspection.json').write_text(json.dumps(report,indent=2)+'\n');print([(x['name'],x['offset']) for x in comparisons])
