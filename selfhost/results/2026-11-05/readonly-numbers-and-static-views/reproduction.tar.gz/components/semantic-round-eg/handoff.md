Qualified numeric proof and identity companion

Apply the narrow patches to the final checker; do not replace its whole file from this early42 source copy. Member-call, lexical return-target and final renderer work remain root-owned. No live files were edited.

- `numeric-proof.patch`: syntactic nonnegative facts for integer literals, length/capacity properties and immutable initializer chains, kept separate from literal adaptability. Private node facts preserve source form before contextual rewriting. A fact is -2 (unknown), -1 (independent), or a dependency Symbol ID. Writable exposure and reliance marks persist across flow, in either order. Only the final numeric comparison fallback joins a signed operand with u64; ordinary arithmetic and literal fit rules remain unchanged.
- `identity-normalization.patch`: normalizes both addressable operands independently in left-to-right order. Address comparison does not record writable exposure. References/null remain references; nonaddressable values are rejected, and pointee types must match. Both backends consume the resulting references through their existing pointer paths. No i64-to-pointer truncation or backend patch was added.

The numeric-only EF attempt recovered checking but exposed the old unnormalized identity path in the original Wasm module. Those failed module reports remain in semantic-round-ef. Initial authored fixtures also had `&=` token spacing and a grow-array `.cap` mistake; corrected sources keep the same intended outputs, and original attempts remain. Only final phase-checked/runtime evidence is coverage.

Qualification: 49/49 focused sources; 204/204 native+Wasmtime and 102/102 V8 rows; both original u64_cmp_readonly_refs and syntax_additions execute correctly at O0/O2. The matched 2119-row regression guard passes before/after and under V8. All 1763 existing negative checks remain proper refusals. Debug scalar identity validates in both engines, and the recorded main-instruction walk uses i32.eq/ne rather than i64 equality.

Own-source check passes. Two same-producer41 ABBA pairs on the frozen early42 workload measure +3.94% CPU and +1.76% peak RSS, with identical checked IR counts. This is a disclosed semantic-fix cost. Passing only the five used scalar fields instead of a full Node to the proof hook is a possible future measured optimization; it is not included.

Authoritative details, hashes and commands are in qualification.json, the two patches, source-pins-final.json, build/report.json, front-comparison.json, cost-summary.json and the conformance reports. Frozen expectations were not updated from candidate output.
