from pathlib import Path
import os,signal,subprocess,time,json,hashlib
r=Path(__file__).parent.resolve();fixed=r.parent/'composition-controls-42/source-freeze/selfhost/main.goose';library=Path('stdlib').resolve();rows=[]
def timeout(*_):raise TimeoutError('check exceeded180s')
signal.signal(signal.SIGALRM,timeout)
jobs=[('before-1',r.parent/'semantic-round-ef/control/probe',fixed),('after-1',r/'probe',fixed),('after-2',r/'probe',fixed),('before-2',r.parent/'semantic-round-ef/control/probe',fixed),('own-source',r/'build/goose',r/'source/selfhost/main.goose')]
for name,exe,source in jobs:
 command=[str(exe),str(source),str(library)]
 if name=='own-source':command=[str(exe),str(source),'--stdlib',str(library),'--check']
 with (r/(name+'.stdout')).open('wb') as out,(r/(name+'.stderr')).open('wb') as err:
  start=time.monotonic();p=subprocess.Popen(command,stdout=out,stderr=err);signal.alarm(180);timed=False
  try:_,status,usage=os.wait4(p.pid,0)
  except TimeoutError:timed=True;p.kill();_,status,usage=os.wait4(p.pid,0)
  finally:signal.alarm(0)
  p.returncode=os.waitstatus_to_exitcode(status)
 x=dict(name=name,command=command,executable_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),input_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),exit_code=p.returncode,timeout=timed,user_seconds=usage.ru_utime,system_seconds=usage.ru_stime,wall_seconds=time.monotonic()-start,maxrss_kib=usage.ru_maxrss,stdout=(r/(name+'.stdout')).read_text(),stderr=(r/(name+'.stderr')).read_text());rows.append(x);(r/(name+'.json')).write_text(json.dumps(x,indent=2)+'\n');(r/'cost.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(x),flush=True)
