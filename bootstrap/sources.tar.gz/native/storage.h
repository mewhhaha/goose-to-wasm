/* Native frame adapters over the pinned plain-C Goose region runtime. */
#ifndef _WIN32
#ifndef _GNU_SOURCE
#define _GNU_SOURCE 1
#endif
#endif
#include <stddef.h>
#include <stdint.h>
#include <inttypes.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <limits.h>
#include <setjmp.h>
#include <time.h>
#include <errno.h>
#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#define flockfile(f) _lock_file(f)
#define funlockfile(f) _unlock_file(f)
#else
#include <unistd.h>
#include <sys/stat.h>
#include <dirent.h>
#include <dlfcn.h>
#include <pthread.h>
#ifdef __APPLE__
#include <mach-o/dyld.h>
#endif
#endif
/* Mutable native state is G_SHARED (units.h): this unit's own in a single
   unit, defined by unit 0 and declared by the others in a split program. */
#ifndef G_SHARED
#define G_SPLIT 0
#define G_SHARED static
#define G_INIT(value) =value
#endif
#if G_SPLIT
/* runtime.h's instance globals pointer is static: every unit uses one. */
#define gs_gl g_instance_globals
G_SHARED GS_TLS void *gs_gl;
#endif
#ifdef GS_SEPARATE_RUNTIME
/* What the runtime body keeps to itself, from the runtime unit (runtime_unit.h). */
GS_API size_t g_runtime_region_usable(void);
GS_API long g_runtime_region_count(void);
GS_API int64_t g_runtime_span_depth(void);
GS_API int g_runtime_float_digits(uint64_t f,int e,int bits,int emin,char *dig,int *k);
#define gs_float_digits g_runtime_float_digits
GS_API uint8_t gs_trim_memory(void);
#define G_REGION_USABLE() g_runtime_region_usable()
#define G_REGION_COUNT() g_runtime_region_count()
#define G_SPAN_DEPTH g_runtime_span_depth()
#else
#define G_REGION_USABLE() (gs_regions[gs_nregions-1].usable)
#define G_REGION_COUNT() gs_nregions
#define G_SPAN_DEPTH GS_SPAN_DEPTH
#endif
typedef uintptr_t GRef;
typedef struct GRegion { gs_stack stack; unsigned char *base; int64_t capacity, width; size_t usable; unsigned char *entry; uint64_t high_water; struct GRegion *freelist; int64_t free_count,free_mode; } GRegion;
typedef struct { unsigned char *top; int64_t capacity, width; unsigned char *entry; GRegion *freelist; int64_t free_count,free_mode; } GWatermark;
G_SHARED GS_TLS GRegion *g_regions;
G_SHARED GS_TLS int64_t g_region_count, g_region_peak;
G_SHARED GS_TLS GRegion g_fixed_region;
typedef struct { unsigned char *data,*previous; } GFixed;

typedef struct { GRef base; int64_t len; } GSlice;
typedef struct { unsigned char *data; int64_t len; GRegion *region; } GArray;
typedef struct GClosure { void *function; int64_t count; GRef captures[]; } GClosure;
typedef struct GAllocation { struct GAllocation *next; void *data; } GAllocation;
G_SHARED GS_TLS GAllocation *g_allocations;
G_SHARED GS_TLS uint64_t g_legacy_bytes;
G_SHARED int g_argc; G_SHARED char **g_argv;
static GS_NORETURN GS_NOINLINE __attribute__((cold)) void g_panic(const char *message) {
    gs_abort_msg((const uint8_t*)message,(int64_t)strlen(message),"<native>",0);
}
static GS_NORETURN GS_NOINLINE __attribute__((cold)) void g_panic_at(const char *message,const char *file,int line) {
    gs_abort_msg((const uint8_t*)message,(int64_t)strlen(message),file,line);
}
G_SHARED GS_TLS uintptr_t g_native_stack_low;
static GS_NOINLINE __attribute__((cold)) void g_stack_check_init(void) {
#if defined(_WIN32)
    MEMORY_BASIC_INFORMATION mbi;
    if(!VirtualQuery(&mbi,&mbi,sizeof mbi)) gs_panic("cannot inspect native stack");
    g_native_stack_low=(uintptr_t)mbi.AllocationBase;
#elif defined(__APPLE__)
    pthread_t self=pthread_self();
    void *top=pthread_get_stackaddr_np(self);
    size_t bytes=pthread_get_stacksize_np(self);
    if(!top || !bytes) gs_panic("cannot inspect native stack");
    g_native_stack_low=(uintptr_t)top-bytes;
#else
    pthread_attr_t attributes;void *base;size_t bytes;
    if(pthread_getattr_np(pthread_self(),&attributes)) gs_panic("cannot inspect native stack");
    int status=pthread_attr_getstack(&attributes,&base,&bytes);pthread_attr_destroy(&attributes);
    if(status) gs_panic("cannot inspect native stack");g_native_stack_low=(uintptr_t)base;
#endif
}
#if defined(__linux__) && defined(__x86_64__) && !defined(__TINYC__) && defined(__has_builtin)
#if __has_builtin(__builtin_stack_address)
#define GS_NATIVE_STACK_ADDRESS 1
#endif
#endif
static GS_INLINE void g_stack_check(void) {
#if GS_NEED_THREADS
    if(__builtin_expect(!g_native_stack_low,0))g_stack_check_init();
#endif
#ifdef GS_NATIVE_STACK_ADDRESS
    // Keep the SysV AMD64 red zone outside the 128 KiB safety reserve.
    uintptr_t here=(uintptr_t)__builtin_stack_address();
    if(__builtin_expect(here-g_native_stack_low<131072+128,0)) g_panic("native call stack overflow");
#else
    unsigned char here;
    if(__builtin_expect((uintptr_t)&here-g_native_stack_low<131072,0)) g_panic("native call stack overflow");
#endif
}
#undef GS_NATIVE_STACK_ADDRESS
static GS_NORETURN GS_NOINLINE __attribute__((cold)) void g_index_fail(int64_t index,int64_t length,const char *file,int line) {
    if(!file)file="<native>";gs_idxfail(index,length,file,line);
}
static void *g_alloc(size_t n) {
    void *p=calloc(1,n+!n); if(!p) gs_panic("out of memory");
    GAllocation *a=malloc(sizeof *a); if(!a) gs_panic("out of memory");
    a->data=p; a->next=g_allocations; g_allocations=a;g_legacy_bytes+=n;return p;
}
static void g_region_pool_begin(int64_t regions) {
    g_region_count=regions;g_region_peak=0;g_legacy_bytes=0;g_fixed_region=(GRegion){0};
    g_regions=calloc((size_t)(regions+1),sizeof *g_regions);
    if(!g_regions)gs_panic("out of memory allocating native region plan");
}
static void g_region_pool_release(void) {
    while(g_allocations) {GAllocation *a=g_allocations;g_allocations=a->next;free(a->data);free(a);}
    free(g_regions);g_regions=NULL;g_region_count=0;g_region_peak=0;g_legacy_bytes=0;
}
#if GS_NEED_THREADS
static void g_transfer_drop(void);
#endif
static void g_region_stats(void) {
#if GS_STACK_STATS
    uint64_t live=0,high_water=0;
    int64_t stacks=gs_nstks;
    if(g_fixed_region.base)stacks++;
    for(int64_t i=0;i<g_region_count;i++) {
        GRegion *region=&g_regions[i];
        if(region->base)stacks++;
        if(region->base && region->stack.top)live+=(uint64_t)(region->stack.top-region->base);
        high_water+=region->high_water;
    }
    gs_stack_stats(stacks);
    fprintf(stderr,"native region stats: plan=%lld reserved=%ld peak_slot=%lld live_bytes=%llu sum_region_high_water_bytes=%llu legacy_bytes=%llu\n",
        (long long)g_region_count,G_REGION_COUNT(),(long long)g_region_peak,(unsigned long long)live,
        (unsigned long long)high_water,(unsigned long long)g_legacy_bytes);
#endif
}
static GS_NORETURN void g_exit(int64_t code) {
    g_region_stats();gs_exit(code);
}
G_SHARED int g_runtime_active;
static void g_runtime_stop(void) {
    if(!g_runtime_active)return;
    g_runtime_active=0;
    g_region_stats();
#if GS_NEED_THREADS
    g_transfer_drop();
#endif
    gs_release_regions();g_region_pool_release();
    g_argc=0;g_argv=NULL;
}
static void g_cleanup(void) { g_runtime_stop(); }
static void g_runtime_start(int argc,char **argv,int64_t regions,int64_t worker_regions) {
    // glibc reads the main stack's bounds from /proc/self/maps; read them before
    // any region mapping lengthens it.
    static int g_atexit_registered;
    g_stack_check_init();
    g_argc=argc;g_argv=argv;g_region_count=regions;g_runtime_active=1;
    gs_rt_start(argc,argv,GS_STACK_RESERVE,GS_STACK_GAP,GS_STACK_BUDGET,regions+1,worker_regions+1);
    g_region_pool_begin(regions);
    if(!g_atexit_registered){g_atexit_registered=1;atexit(g_cleanup);}
}
static GRegion *g_region_slot(int64_t slot) {
    if(slot<0 || slot>=g_region_count)g_panic("native region plan exhausted");
    if(slot+1>g_region_peak)g_region_peak=slot+1;
    return &g_regions[slot];
}
/* A slot's address space is reserved when something first needs bytes there,
   and stays reserved for every later use of the slot. Until then the region
   has no base and no top, and the runtime does not know it. */
static GS_NOINLINE void g_region_map(GRegion *region) {
    gs_stack_init(&region->stack);region->base=region->stack.top;region->usable=G_REGION_USABLE();
}
static GRegion *g_region(int64_t slot) {
    GRegion *region=g_region_slot(slot);
    if(!region->base)g_region_map(region);
    return region;
}
static unsigned char *g_fixed_alloc(size_t bytes) {
    GRegion *region=&g_fixed_region;
    if(!region->base) {
        gs_stack_init(&region->stack);region->base=region->stack.top;
        region->usable=G_REGION_USABLE();
    }
    size_t offset=(size_t)(region->stack.top-region->base);
    if(offset>SIZE_MAX-15)g_panic("fixed value size overflow");
    offset=(offset+15)&~(size_t)15;
    if(bytes>region->usable || offset>region->usable-bytes)g_panic("fixed value region exhausted");
    unsigned char *data=region->base+offset;region->stack.top=data+bytes;
    uint64_t used=(uint64_t)(region->stack.top-region->base);
    if(used>region->high_water)region->high_water=used;
    return data;
}
static GFixed g_fixed_begin(size_t bytes,int zero) {
    unsigned char *previous=g_fixed_region.stack.top;
    unsigned char *data=g_fixed_alloc(bytes);
    if(zero && bytes)memset(data,0,bytes);
    return (GFixed){data,previous};
}
static void g_fixed_release(GFixed *value) {
    unsigned char *previous=value->previous;
    if(!previous)previous=g_fixed_region.base;
    if(g_fixed_region.stack.top>previous)g_fixed_region.stack.top=previous;
}
/* The data of an array whose region is not reserved yet: a valid address for
   its zero bytes. */
G_SHARED unsigned char g_empty_byte;
/* An empty growable array. Its region is reserved only when the array first
   needs bytes (g_reserve), so an array that never grows maps nothing. Image
   and run writers take the region's top as their cursor before anything
   reserves, so theirs start from g_mapped_array. */
static GArray g_array(int64_t slot) {
    GRegion *region=g_region_slot(slot);region->capacity=0;region->width=0;region->freelist=NULL;region->free_count=0;region->free_mode=0;
    region->entry=region->stack.top;unsigned char *data=region->stack.top;if(!region->base)data=&g_empty_byte;
    GArray value={data,0,region};return value;
}
static GArray g_mapped_array(int64_t slot) {
    g_region(slot);return g_array(slot);
}
static GS_INLINE void g_mark_regions(int64_t base,int64_t count,GWatermark *marks) {
    if(__builtin_expect(base<0 || count<0 || base>g_region_count-count,0))g_panic("invalid native region watermark");
    for(int64_t i=0;i<count;i++) {
        GRegion *r=&g_regions[base+i];
        marks[i]=(GWatermark){r->stack.top,r->capacity,r->width,r->entry,r->freelist,r->free_count,r->free_mode};
    }
}
static GS_INLINE void g_restore_regions(int64_t base,int64_t count,const GWatermark *marks) {
    for(int64_t i=0;i<count;i++) {
        GRegion *r=&g_regions[base+i];r->stack.top=marks[i].top;
        if(!r->stack.top)r->stack.top=r->base;
        r->capacity=marks[i].capacity;r->width=marks[i].width;r->entry=marks[i].entry;r->freelist=marks[i].freelist;r->free_count=marks[i].free_count;r->free_mode=marks[i].free_mode;
    }
}
typedef struct GPublication { struct GPublication *parent;uintptr_t source,target; } GPublication;
G_SHARED GS_TLS GPublication *g_publication_top;
static GS_NOINLINE __attribute__((cold)) void g_header_changed_slow(uintptr_t address) {
    for(;;) {
        GPublication *link=g_publication_top;
        while(link && link->source!=address)link=link->parent;
        if(!link)return;
        memcpy((void *)link->target,(const void *)address,sizeof(GArray));address=link->target;
    }
}
static GS_INLINE void g_header_changed(uintptr_t address) {
    if(__builtin_expect(!g_publication_top,1))return;
    g_header_changed_slow(address);
}
static GS_INLINE void g_map_header(GPublication *link,uintptr_t source,uintptr_t target) {
    if(source==target)return;
    *link=(GPublication){g_publication_top,source,target};g_publication_top=link;
}
static GS_INLINE GRef g_ref(const void *p) { return (GRef)(uintptr_t)p; }
static GS_INLINE unsigned char *g_ptr(GRef ref) { return (unsigned char *)(uintptr_t)ref; }
static GS_INLINE unsigned char *g_address(GRef ref) { if(__builtin_expect(!ref,0))g_panic("null reference");return (unsigned char *)(uintptr_t)ref; }
static GS_INLINE GRegion *g_array_region(GRef header) {
    GRegion *reg;memcpy(&reg,g_address(header)+offsetof(GArray,region),sizeof reg);return reg;
}
static GS_INLINE GRef g_offset(GRef ref,int64_t offset) {
    if(__builtin_expect(offset<0,0))g_panic("negative reference offset");
    if(__builtin_expect(!ref && offset,0))g_panic("null reference");
#if (defined(__GNUC__) || defined(__clang__)) && !defined(__TINYC__)
    unsigned char *base=(unsigned char *)(uintptr_t)ref;
    size_t bytes=__builtin_object_size(base,2);
    if(ref && bytes && (uint64_t)offset<=bytes)return g_ref(base+offset);
#endif
    return ref+(uintptr_t)offset;
}
static GS_INLINE GRef g_owner(GRef root) { return root; }
static GS_INLINE GRef g_moving(GRef root,int64_t offset) {
    unsigned char *base;memcpy(&base,g_address(root),sizeof base);
    if(__builtin_expect(offset<0,0))g_panic("negative reference offset");if(!base && !offset)return g_ref(&g_empty_byte);return g_ref(base+offset);
}
static GS_INLINE uint64_t g_read_length(const void *p,int n) { uint64_t v=0; memcpy(&v,p,n); return v; }
static GS_INLINE void g_write_length(void *p,int n,uint64_t v) { memcpy(p,&v,n); }
static GS_INLINE int64_t g_len_ptr(const unsigned char *p,int kind,int64_t fixed,int prefix) {
    if(kind==3 || kind==4) { int64_t len; memcpy(&len,p+offsetof(GArray,len),sizeof len); return len; }
    if(kind==5) { int64_t len; memcpy(&len,p+offsetof(GSlice,len),sizeof len); return len; }
    if(kind==0) return fixed;
    if(kind==2 && fixed<0)return (int64_t)g_read_length(p+4,4);
    if(kind==2) return (int64_t)g_read_length(p,prefix);
    uint64_t count;if(prefix)count=g_read_length(p,prefix);else count=gs_uleb_read(p);
    if(__builtin_expect(count>INT64_MAX,0))g_panic("array length exceeds native range");return (int64_t)count;
}
static GS_INLINE int64_t g_len(GRef r,int kind,int64_t fixed,int prefix) {
    if(kind==0) return fixed;
    return g_len_ptr(g_address(r),kind,fixed,prefix);
}
static GS_INLINE int64_t g_len_nn(GRef r,int kind,int64_t fixed,int prefix) {
    if(kind==0) return fixed;
    return g_len_ptr(g_ptr(r),kind,fixed,prefix);
}
static GS_INLINE int64_t g_cap(GRef r,int kind,int64_t fixed) {
    if(kind==2 && fixed<0)return (int64_t)g_read_length(g_address(r),4);
    if(kind==0) return fixed;
    if(kind==2 && fixed>=0) return fixed;
    GRegion *reg; memcpy(&reg,g_address(r)+offsetof(GArray,region),sizeof reg);if(!reg)return 0;return reg->capacity;
}
static GS_INLINE GRef g_element_unchecked_ptr(unsigned char *p,int kind,int64_t fixed,int prefix,int64_t width,int64_t index) {
    if(kind==3 || kind==4) {
        unsigned char *base; memcpy(&base,p+offsetof(GArray,data),sizeof base);
        if(!width) return base?(GRef)(uintptr_t)base:(GRef)(uintptr_t)&g_empty_byte;
        return (GRef)(uintptr_t)(base+(uint64_t)index*(uint64_t)width);
    }
    if(kind==5) { GRef base; memcpy(&base,p+offsetof(GSlice,base),sizeof base); return base+(uintptr_t)((uint64_t)index*(uint64_t)width); }
    if(kind==0) return (GRef)(uintptr_t)(p+(uint64_t)index*(uint64_t)width);
    int64_t bytes=prefix;
    if(kind==1 && !bytes)bytes=gs_uleb_size(p);
    if(kind==2 && fixed<0)bytes=8;
    return (GRef)(uintptr_t)(p+(uint64_t)bytes+(uint64_t)index*(uint64_t)width);
}
static GS_INLINE GRef g_element_unchecked(GRef r,int kind,int64_t fixed,int prefix,int64_t width,int64_t index) {
    return g_element_unchecked_ptr(g_address(r),kind,fixed,prefix,width,index);
}
static GS_INLINE GRef g_element_unchecked_nn(GRef r,int kind,int64_t fixed,int prefix,int64_t width,int64_t index) {
    return g_element_unchecked_ptr(g_ptr(r),kind,fixed,prefix,width,index);
}
static GS_INLINE GRef g_element_at_ptr(unsigned char *p,int kind,int64_t fixed,int prefix,int64_t width,int64_t index,int allow_end,const char *file,int line) {
    if(kind==3 || kind==4) {
        int64_t len; memcpy(&len,p+offsetof(GArray,len),sizeof len);
        if(__builtin_expect(allow_end?((uint64_t)index>(uint64_t)len):((uint64_t)index>=(uint64_t)len),0)) g_index_fail(index,len,file,line);
        unsigned char *data; memcpy(&data,p+offsetof(GArray,data),sizeof data);
        if(!width) return data?(GRef)(uintptr_t)data:(GRef)(uintptr_t)&g_empty_byte;
        if(allow_end && !data) return (GRef)(uintptr_t)&g_empty_byte;
        return (GRef)(uintptr_t)(data+(uint64_t)index*(uint64_t)width);
    }
    if(kind==5) {
        int64_t len; memcpy(&len,p+offsetof(GSlice,len),sizeof len);
        if(__builtin_expect(allow_end?((uint64_t)index>(uint64_t)len):((uint64_t)index>=(uint64_t)len),0)) g_index_fail(index,len,file,line);
        GRef base; memcpy(&base,p+offsetof(GSlice,base),sizeof base);
        return base+(uintptr_t)((uint64_t)index*(uint64_t)width);
    }
    if(kind==0) {
        if(__builtin_expect(allow_end?((uint64_t)index>(uint64_t)fixed):((uint64_t)index>=(uint64_t)fixed),0)) g_index_fail(index,fixed,file,line);
        return (GRef)(uintptr_t)(p+(uint64_t)index*(uint64_t)width);
    }
    int64_t len=g_len_ptr(p,kind,fixed,prefix);
    if(__builtin_expect(allow_end?((uint64_t)index>(uint64_t)len):((uint64_t)index>=(uint64_t)len),0)) g_index_fail(index,len,file,line);
    int64_t bytes=prefix;
    if(kind==1 && !bytes)bytes=gs_uleb_size(p);
    if(kind==2 && fixed<0)bytes=8;
    if(__builtin_expect(width && index>(INT64_MAX-bytes)/width,0))g_panic("array offset overflow");
    return (GRef)(uintptr_t)(p+(uint64_t)bytes+(uint64_t)index*(uint64_t)width);
}
static GS_INLINE GRef g_element_at(GRef r,int kind,int64_t fixed,int prefix,int64_t width,int64_t index,int allow_end,const char *file,int line) {
    return g_element_at_ptr(g_address(r),kind,fixed,prefix,width,index,allow_end,file,line);
}
static GS_INLINE GRef g_element_at_nn(GRef r,int kind,int64_t fixed,int prefix,int64_t width,int64_t index,int allow_end,const char *file,int line) {
    return g_element_at_ptr(g_ptr(r),kind,fixed,prefix,width,index,allow_end,file,line);
}
static GS_INLINE GRef g_element(GRef r,int kind,int64_t fixed,int prefix,int64_t width,int64_t index,int allow_end) {
    return g_element_at(r,kind,fixed,prefix,width,index,allow_end,NULL,0);
}
static GS_INLINE GRef g_slot(GRef header,int kind,int64_t fixed,int prefix,int64_t width,int64_t index) {
    if(kind==2 && fixed<0)return g_offset(header,8+index*width);
    if(kind==0)return g_offset(header,index*width);
    if(kind==2 && fixed>=0)return g_offset(header,prefix+index*width);
    return g_moving(header,index*width);
}
static GS_INLINE GSlice g_view(GRef r,int kind,int64_t fixed,int prefix,int64_t width) {
    unsigned char *p=g_address(r);
    if(kind==3 || kind==4) {
        unsigned char *data; int64_t len;
        memcpy(&data,p+offsetof(GArray,data),sizeof data);
        memcpy(&len,p+offsetof(GArray,len),sizeof len);
        GRef base=data?(GRef)(uintptr_t)data:(GRef)(uintptr_t)&g_empty_byte;
        return (GSlice){base,len};
    }
    if(kind==5) { GSlice s; memcpy(&s,p,sizeof s); return s; }
    GSlice s={g_element_at_ptr(p,kind,fixed,prefix,width,0,1,NULL,0),g_len_ptr(p,kind,fixed,prefix)};
    return s;
}
/* Every array made in a region before its first bytes starts at its base, as
   the arrays made there afterwards start at its top. Several headers can
   share a region (a call's result is built in its destination's), so one
   made while the region was unreserved may find it reserved since. */
static GS_INLINE void g_array_resolve(GArray *a) {
    if(a->data==&g_empty_byte && a->region && a->region->base)a->data=a->region->base;
}
/* Points an array made before its region was reserved at the region's base,
   reserving the region first if it is not, and republishes the header. */
static GS_NOINLINE void g_array_place(GRef r) {
    GArray a;memcpy(&a,g_address(r),sizeof a);
    if(!a.region->base) { g_region_map(a.region);a.region->entry=a.region->base; }
    a.data=a.region->base;memcpy(g_address(r),&a,sizeof a);g_header_changed(r);
}
static GS_INLINE void g_reserve(GRef r,int kind,int64_t fixed,int prefix,int64_t width,int64_t count);
/* What g_reserve finds outside its array's reservation: an array made before
   its region was reserved, which it places (reserving the region unless the
   array needs no bytes, as zero-width elements do), or an overflow. Taken from
   the bounds check's branch, so the reserves inlined everywhere stay as they
   were. */
static GS_NOINLINE __attribute__((cold)) void g_reserve_outside(GRef r,int64_t width,int64_t count) {
    GArray a;memcpy(&a,g_address(r),sizeof a);
    if(a.data!=&g_empty_byte)g_panic("data stack overflow");
    if(!a.region->base && (!count || !width)) {
        if(count>a.region->capacity)a.region->capacity=count;
        a.region->width=width;return;
    }
    g_array_place(r);g_reserve(r,3,-1,0,width,count);
}
static GS_INLINE void g_reserve(GRef r,int kind,int64_t fixed,int prefix,int64_t width,int64_t count) {
    if(count<0 || (width && count>INT64_MAX/width)) g_panic("invalid capacity");
    if(kind==2) { if(count>g_cap(r,kind,fixed)) g_panic("limited array capacity exceeded"); return; }
    if(kind!=3 && kind!=4) g_panic("array cannot grow");
    GArray a; memcpy(&a,g_address(r),sizeof a);
    if(!a.region)g_panic("array has no receiving region");
    uint64_t bytes=(uint64_t)count*(uint64_t)width;
    // g_empty_byte lies outside every region (and an unreserved one has no
    // usable bytes), so unplaced arrays fail this check too.
    size_t offset=(size_t)((uintptr_t)a.data-(uintptr_t)a.region->base);
    if(bytes>a.region->usable || offset>a.region->usable-bytes) { g_reserve_outside(r,width,count);return; }
    if(count>a.region->capacity)a.region->capacity=count;
    a.region->width=width;
    a.region->stack.top=a.data+(size_t)a.region->capacity*(size_t)width;
    uint64_t used=(uint64_t)(a.region->stack.top-a.region->base);
    if(used>a.region->high_water)a.region->high_water=used;

}
/* An array that has not been placed holds no bytes, so its length and builder
   resets leave its region's top alone: unreserved, the region keeps no top;
   reserved since by another header, the top stays above whatever that one
   holds, until g_reserve or a watermark moves it. */
static GS_INLINE void g_set_len(GRef r,int kind,int64_t fixed,int prefix,int64_t count) {
    if(kind==2 && fixed<0){if(__builtin_expect(count<0 || count>g_cap(r,kind,fixed),0))g_panic("limited array capacity exceeded");g_write_length(g_address(r)+4,4,(uint64_t)count);}
    else if(kind==2 && fixed>=0) g_write_length(g_address(r),prefix,(uint64_t)count);
    else {
        unsigned char *hp=g_address(r);
        memcpy(hp+offsetof(GArray,len),&count,sizeof count);
        if(kind==3 || kind==4) {
            GRegion *reg; unsigned char *data;
            memcpy(&reg,hp+offsetof(GArray,region),sizeof reg);
            memcpy(&data,hp+offsetof(GArray,data),sizeof data);
            if(reg && data!=&g_empty_byte)reg->stack.top=data+(size_t)count*(size_t)reg->width;
        }
        g_header_changed(r);
    }
}
static GS_INLINE void g_begin_builder(GRef ref) {
    unsigned char *hp=g_address(ref); GArray value;memcpy(&value,hp,sizeof value);value.len=0;
    if(value.region && value.data!=&g_empty_byte)value.region->stack.top=value.data;
    memcpy(hp,&value,sizeof value);
}
static GS_NOINLINE __attribute__((cold)) GRef g_push_slot_slow(GRef r,int kind,int64_t fixed,int prefix,int64_t width) {
    int64_t n=g_len(r,kind,fixed,prefix);if(n==INT64_MAX)g_panic("array length overflow");g_reserve(r,kind,fixed,prefix,width,n+1);
    g_set_len(r,kind,fixed,prefix,n+1); return g_element(r,kind,fixed,prefix,width,n,0);
}
static GS_INLINE GRef g_push_slot_ptr(unsigned char *hp,GRef r,int kind,int64_t fixed,int prefix,int64_t width) {
    if((kind==3 || kind==4) && width>0 && (uint64_t)width<=GS_STACK_GAP) {
        unsigned char *data; GRegion *reg;
        memcpy(&data,hp+offsetof(GArray,data),sizeof data);
        memcpy(&reg,hp+offsetof(GArray,region),sizeof reg);
        if(__builtin_expect(data!=&g_empty_byte && reg!=NULL,1)) {
            int64_t len; memcpy(&len,hp+offsetof(GArray,len),sizeof len);
            unsigned char *dst=data+(uint64_t)len*(uint64_t)width;
            int64_t next=len+1;
            memcpy(hp+offsetof(GArray,len),&next,sizeof next);
            if(next>reg->capacity)reg->capacity=next;
            reg->width=width;
            reg->stack.top=dst+(size_t)width;
#if GS_STACK_STATS
            uint64_t nused=(uint64_t)((uintptr_t)(dst+(size_t)width)-(uintptr_t)reg->base);
            if(nused>reg->high_water)reg->high_water=nused;
#endif
            g_header_changed(r);
            return (GRef)(uintptr_t)dst;
        }
    }
    return g_push_slot_slow(r,kind,fixed,prefix,width);
}
static GS_INLINE GRef g_push_slot(GRef r,int kind,int64_t fixed,int prefix,int64_t width) {
    return g_push_slot_ptr(g_address(r),r,kind,fixed,prefix,width);
}
static GS_INLINE GRef g_push_slot_nn(GRef r,int kind,int64_t fixed,int prefix,int64_t width) {
    return g_push_slot_ptr(g_ptr(r),r,kind,fixed,prefix,width);
}
static GS_NOINLINE __attribute__((cold)) GRef g_push_slow(GRef r,int kind,int64_t fixed,int prefix,int64_t width,const void *v) {
    int64_t n=g_len(r,kind,fixed,prefix);if(n==INT64_MAX)g_panic("array length overflow");g_reserve(r,kind,fixed,prefix,width,n+1);
    g_set_len(r,kind,fixed,prefix,n+1); GRef dst=g_element(r,kind,fixed,prefix,width,n,0);
    if(width)memcpy(g_address(dst),v,(size_t)width); return dst;
}
static GS_INLINE GRef g_push_ptr(unsigned char *hp,GRef r,int kind,int64_t fixed,int prefix,int64_t width,const void *v) {
    if((kind==3 || kind==4) && width>0) {
        GArray a; memcpy(&a,hp,sizeof a);
        GRegion *reg=a.region;
        if(__builtin_expect(reg!=NULL,1)) {
            unsigned char *dst=a.data+(size_t)a.len*(size_t)width;
            size_t avail=reg->usable;
            size_t used=(size_t)((uintptr_t)dst-(uintptr_t)reg->base);
            if(__builtin_expect(avail>=(size_t)width && used<=avail-(size_t)width,1)) {
                memcpy(dst,v,(size_t)width);
                int64_t next=a.len+1;
                a.len=next;
                if(next>reg->capacity)reg->capacity=next;
                reg->width=width;
                reg->stack.top=dst+(size_t)width;
                uint64_t nused=(uint64_t)(used+(size_t)width);
                if(nused>reg->high_water)reg->high_water=nused;
                memcpy(hp,&a,sizeof a);
                g_header_changed(r);
                return (GRef)(uintptr_t)dst;
            }
        }
    }
    return g_push_slow(r,kind,fixed,prefix,width,v);
}
static GS_INLINE GRef g_push(GRef r,int kind,int64_t fixed,int prefix,int64_t width,const void *v) {
    return g_push_ptr(g_address(r),r,kind,fixed,prefix,width,v);
}
static GS_INLINE GRef g_push_nn(GRef r,int kind,int64_t fixed,int prefix,int64_t width,const void *v) {
    return g_push_ptr(g_ptr(r),r,kind,fixed,prefix,width,v);
}
static GS_NOINLINE __attribute__((cold)) void g_append_fixed_slow(GRef dst,int kind,int64_t fixed,int prefix,int64_t width,GRef src,int skind,int64_t sfixed,int sprefix) {
    int64_t count=g_len(src,skind,sfixed,sprefix);
    int64_t old=g_len(dst,kind,fixed,prefix);
    if(count<0 || count>INT64_MAX-old)g_panic("array length overflow");
    g_reserve(dst,kind,fixed,prefix,width,old+count);
    if(count && width)memmove(g_address(g_element(dst,kind,fixed,prefix,width,old,1)),g_address(g_element(src,skind,sfixed,sprefix,width,0,1)),(size_t)count*(size_t)width);
    g_set_len(dst,kind,fixed,prefix,old+count);
}
static GS_NOINLINE __attribute__((cold)) void g_append_slice_slow(GRef dst,int kind,int64_t width,GSlice src) {
    g_append_fixed_slow(dst,kind,-1,0,width,g_ref(&src),5,-1,0);
}
static GS_INLINE void g_append_slice_ptr(unsigned char *hp,GRef dst,int kind,int64_t width,GSlice src) {
    int64_t count=src.len;
    if(__builtin_expect(count<=0,0)) { if(!count) return; g_panic("array length overflow"); }
    GRegion *reg; memcpy(&reg,hp+offsetof(GArray,region),sizeof reg);
    if(__builtin_expect(reg!=NULL,1)) {
        unsigned char *data; int64_t len;
        memcpy(&data,hp+offsetof(GArray,data),sizeof data);
        memcpy(&len,hp+offsetof(GArray,len),sizeof len);
        unsigned char *out=data+(size_t)len*(size_t)width;
        size_t avail=reg->usable;
        size_t used=(size_t)((uintptr_t)out-(uintptr_t)reg->base);
        uint64_t bytes=(uint64_t)count*(uint64_t)width;
        if(__builtin_expect((uint64_t)count<=(uint64_t)(avail/(size_t)width) && used<=avail-(size_t)bytes,1)) {
            memmove(out,g_ptr(src.base),(size_t)bytes);
            int64_t next=len+count;
            memcpy(hp+offsetof(GArray,len),&next,sizeof next);
            if(next>reg->capacity)reg->capacity=next;
            reg->width=width;
            reg->stack.top=out+(size_t)bytes;
#if GS_STACK_STATS
            uint64_t nused=(uint64_t)(used+(size_t)bytes);
            if(nused>reg->high_water)reg->high_water=nused;
#endif
            g_header_changed(dst);
            return;
        }
    }
    g_append_slice_slow(dst,kind,width,src);
}
static GS_INLINE void g_append_slice(GRef dst,int kind,int64_t width,GSlice src) {
    g_append_slice_ptr(g_address(dst),dst,kind,width,src);
}
static GS_INLINE void g_append_slice_nn(GRef dst,int kind,int64_t width,GSlice src) {
    g_append_slice_ptr(g_ptr(dst),dst,kind,width,src);
}
static GS_INLINE void g_append_fixed_ptr(unsigned char *hp,GRef dst,int kind,int64_t fixed,int prefix,int64_t width,unsigned char *sp,GRef src,int skind,int64_t sfixed,int sprefix) {
    if((kind==3 || kind==4) && width>0) {
        int64_t count=g_len_ptr(sp,skind,sfixed,sprefix);
        if(__builtin_expect(!count,0)) return;
        GRegion *reg; memcpy(&reg,hp+offsetof(GArray,region),sizeof reg);
        if(__builtin_expect(reg!=NULL && count>0,1)) {
            unsigned char *data; int64_t len;
            memcpy(&data,hp+offsetof(GArray,data),sizeof data);
            memcpy(&len,hp+offsetof(GArray,len),sizeof len);
            unsigned char *out=data+(size_t)len*(size_t)width;
            size_t avail=reg->usable;
            size_t used=(size_t)((uintptr_t)out-(uintptr_t)reg->base);
            uint64_t bytes=(uint64_t)count*(uint64_t)width;
            if(__builtin_expect((uint64_t)count<=(uint64_t)(avail/(size_t)width) && used<=avail-(size_t)bytes,1)) {
                const unsigned char *in=g_ptr(g_element_unchecked_ptr(sp,skind,sfixed,sprefix,width,0));
                memmove(out,in,(size_t)bytes);
                int64_t next=len+count;
                memcpy(hp+offsetof(GArray,len),&next,sizeof next);
                if(next>reg->capacity)reg->capacity=next;
                reg->width=width;
                reg->stack.top=out+(size_t)bytes;
#if GS_STACK_STATS
                uint64_t nused=(uint64_t)(used+(size_t)bytes);
                if(nused>reg->high_water)reg->high_water=nused;
#endif
                g_header_changed(dst);
                return;
            }
        }
    }
    g_append_fixed_slow(dst,kind,fixed,prefix,width,src,skind,sfixed,sprefix);
}
static GS_INLINE void g_append_fixed(GRef dst,int kind,int64_t fixed,int prefix,int64_t width,GRef src,int skind,int64_t sfixed,int sprefix) {
    g_append_fixed_ptr(g_address(dst),dst,kind,fixed,prefix,width,g_address(src),src,skind,sfixed,sprefix);
}
static GS_INLINE void g_append_fixed_nn(GRef dst,int kind,int64_t fixed,int prefix,int64_t width,GRef src,int skind,int64_t sfixed,int sprefix) {
    g_append_fixed_ptr(g_ptr(dst),dst,kind,fixed,prefix,width,g_ptr(src),src,skind,sfixed,sprefix);
}
static void g_append_bytes(GRef r,int kind,int64_t fixed,int prefix,const void *data,int64_t count) {
    int64_t old=g_len(r,kind,fixed,prefix);
    if(count<0 || count>INT64_MAX-old)g_panic("array length overflow");
    if(kind==2 && count>g_cap(r,kind,fixed)-old)g_panic("limited array capacity exceeded");
    g_reserve(r,kind,fixed,prefix,1,old+count);
    if(count)memmove(g_address(g_element(r,kind,fixed,prefix,1,old,1)),data,(size_t)count);
    g_set_len(r,kind,fixed,prefix,old+count);
}
static GS_NOINLINE __attribute__((cold)) void g_bytes_slow(GArray *out,const void *p,int64_t n) {
    GRef r=g_ref(out); g_reserve(r,3,-1,0,1,out->len+n);
    memmove(out->data+out->len,p,(size_t)n); out->len+=n;
}
static GS_INLINE void g_bytes(GArray *out,const void *p,int64_t n) {
    if(__builtin_expect(n<=0,0)) return;
    GRegion *reg=out->region;
    if(__builtin_expect(reg!=NULL,1)) {
        unsigned char *dst=out->data+(size_t)out->len;
        size_t avail=reg->usable;
        size_t used=(size_t)((uintptr_t)dst-(uintptr_t)reg->base);
        if(__builtin_expect((uint64_t)n<=(uint64_t)avail && used<=avail-(size_t)n,1)) {
            memmove(dst,p,(size_t)n);
            int64_t next=out->len+n;
            out->len=next;
            if(next>reg->capacity)reg->capacity=next;
            reg->width=1;
            reg->stack.top=dst+(size_t)n;
#if GS_STACK_STATS
            uint64_t nused=(uint64_t)(used+(size_t)n);
            if(nused>reg->high_water)reg->high_water=nused;
#endif
            return;
        }
    }
    g_bytes_slow(out,p,n);
}
static GClosure *g_closure(void *function,int64_t n) { GClosure *c=g_alloc(sizeof *c+(size_t)n*sizeof(GRef)); c->function=function; c->count=n; return c; }
typedef struct GActivation {
    struct GActivation *parent; int64_t base,count; GWatermark *marks;GPublication *publications;unsigned char *fixed;
} GActivation;
G_SHARED GS_TLS GActivation *g_activation_top;
static GS_INLINE void g_activation_enter(GActivation *frame,int64_t base,int64_t count,GWatermark *marks) {
    *frame=(GActivation){g_activation_top,base,count,marks,g_publication_top,g_fixed_region.stack.top};
    g_mark_regions(base,count,marks);g_activation_top=frame;
}
static GS_INLINE void g_activation_leave(GActivation *frame) {
    g_fixed_region.stack.top=frame->fixed;if(!g_fixed_region.stack.top)g_fixed_region.stack.top=g_fixed_region.base;
    g_restore_regions(frame->base,frame->count,frame->marks);g_activation_top=frame->parent;g_publication_top=frame->publications;
}
typedef struct GReturnFrame {
    struct GReturnFrame *parent;int64_t function;jmp_buf jump;void *result;size_t size;
    void (*publish)(void *,const void *);GActivation *activation;
} GReturnFrame;
G_SHARED GS_TLS GReturnFrame *g_return_top;
static void *g_return_destination(int64_t function) {
    GReturnFrame *frame=g_return_top;while(frame && frame->function!=function)frame=frame->parent;
    if(!frame)g_panic("nonlocal return target is not active");return frame->result;
}
static void g_throw(int64_t function,const void *value,size_t size) {
    GReturnFrame *f=g_return_top;
    while(f && f->function!=function)f=f->parent;
    if(!f || f->size!=size)g_panic("nonlocal return target is not active");
    if(size)f->publish(f->result,value);
    while(g_activation_top && g_activation_top!=f->activation)g_activation_leave(g_activation_top);
    g_return_top=f;longjmp(f->jump,1);
}
static GS_INLINE int64_t g_div(int64_t a,int64_t b,const char *file,int line) { if(__builtin_expect(!b,0)) g_panic_at("division by zero",file,line); if(__builtin_expect(a==INT64_MIN && b==-1,0)) g_panic_at("integer overflow in division",file,line); return a/b; }
static GS_INLINE int64_t g_mod(int64_t a,int64_t b,const char *file,int line) { if(__builtin_expect(!b,0)) g_panic_at("division by zero",file,line); if(__builtin_expect(a==INT64_MIN && b==-1,0)) return 0; int64_t r=a%b; if(r<0) { uint64_t magnitude=(uint64_t)b; if(b<0) magnitude=0-magnitude; return (int64_t)((uint64_t)r+magnitude); } return r; }
static GS_INLINE uint64_t g_udiv(uint64_t a,uint64_t b,const char *file,int line) { if(__builtin_expect(!b,0)) g_panic_at("division by zero",file,line); return a/b; }
static GS_INLINE uint64_t g_umod(uint64_t a,uint64_t b,const char *file,int line) { if(__builtin_expect(!b,0)) g_panic_at("division by zero",file,line); return a%b; }
static double g_mul_add(double x,double y,double z) { volatile double product=x*y;return product+z; }
static float g_mul_addf(float x,float y,float z) { volatile float product=x*y;return product+z; }
static int64_t g_find_any(GSlice s,GRef set) { const unsigned char *p=g_address(s.base),*members=g_address(set);for(int64_t i=0;i<s.len;i++) if(members[p[i]]) return i;return -1; }
static int64_t g_find_pair(GSlice s,GRef a,int64_t d,GRef b) { if(d<0 || d>=s.len) return -1;const unsigned char *p=g_address(s.base),*first=g_address(a),*second=g_address(b);for(int64_t i=0;i<s.len-d;i++) if(first[p[i]] && second[p[i+d]]) return i;return -1; }
static uint64_t g_float_wrap(double a) { if(a!=a)return 0;if(!isfinite(a)) g_panic("float conversion is not finite");int negative=a<0;double magnitude=fmod(trunc(fabs(a)),18446744073709551616.0);uint64_t bits;if(magnitude>=9223372036854775808.0) bits=((uint64_t)(magnitude-9223372036854775808.0))+(UINT64_C(1)<<63);else bits=(uint64_t)magnitude;if(negative) bits=0-bits;return bits; }
static inline void g_print_bytes(GArray *out,const void *p,int64_t n) { if(out) g_bytes(out,p,n); else if(n) fwrite(p,1,(size_t)n,stdout); }
static inline void g_print_text(GArray *out,const char *s) { g_print_bytes(out,s,(int64_t)strlen(s)); }
static char *g_path(GSlice p) { if(p.len<0 || p.len>=4096) return NULL; char *s=g_alloc((size_t)p.len+1); if(p.len) memcpy(s,g_address(p.base),(size_t)p.len); if(memchr(s,0,(size_t)p.len)) return NULL; return s; }
static int g_os_read_file(GSlice path,GRef out) { char *s=g_path(path); if(!s) return 0; FILE *f=fopen(s,"rb"); if(!f) return 0; GArray a; memcpy(&a,g_address(out),sizeof a); unsigned char b[16384]; size_t n; while((n=fread(b,1,sizeof b,f))) g_bytes(&a,b,(int64_t)n); int ok=!ferror(f); fclose(f); memcpy(g_address(out),&a,sizeof a); return ok; }
static int g_os_write_file(GSlice path,GSlice data,const char *mode) { char *s=g_path(path); if(!s) return 0; FILE *f=fopen(s,mode); if(!f) return 0; int ok=fwrite(g_address(data.base),1,(size_t)data.len,f)==(size_t)data.len; return fclose(f)==0 && ok; }
#ifdef _WIN32
static int g_os_write_atomic(GSlice path,GSlice data) {
    char *s=g_path(path); if(!s) return 0;
    size_t n=strlen(s); char *tmp=g_alloc(n+48);
    static volatile LONG64 g_tmp_seq;
    unsigned long long seq=(unsigned long long)InterlockedIncrement64(&g_tmp_seq);
    snprintf(tmp,n+48,"%s.tmp-%lu-%llu",s,(unsigned long)GetCurrentProcessId(),seq);
    FILE *f=fopen(tmp,"wb"); if(!f) return 0;
    int ok=fwrite(g_address(data.base),1,(size_t)data.len,f)==(size_t)data.len;
    if(fflush(f)) ok=0;
    if(fclose(f)) ok=0;
    if(ok) {
        ok=0;
        for(DWORD wait=0;;wait=wait?wait*2:1) {
            if(MoveFileExA(tmp,s,MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)) { ok=1; break; }
            DWORD e=GetLastError(),a=GetFileAttributesA(s);
            if((e!=ERROR_ACCESS_DENIED && e!=ERROR_SHARING_VIOLATION) || wait>512 ||
               (a!=INVALID_FILE_ATTRIBUTES && (a&(FILE_ATTRIBUTE_DIRECTORY|FILE_ATTRIBUTE_READONLY)))) break;
            Sleep(wait);
        }
    }
    if(!ok) DeleteFileA(tmp);
    return ok;
}
static int g_os_kind(GSlice path) { char *s=g_path(path); if(!s) return 0; DWORD a=GetFileAttributesA(s); if(a==INVALID_FILE_ATTRIBUTES) return 0; return (a&FILE_ATTRIBUTE_DIRECTORY)?2:1; }
static int g_os_line(GRef out) { GArray a; memcpy(&a,g_address(out),sizeof a); int c; int any=0; while((c=fgetc(stdin))!=EOF) { any=1; if(c==10) break; unsigned char b=(unsigned char)c; g_bytes(&a,&b,1); } if(a.len && a.data[a.len-1]==13) a.len--; memcpy(g_address(out),&a,sizeof a); return any; }
static void g_os_stdin(GRef out) { GArray a; memcpy(&a,g_address(out),sizeof a); unsigned char b[16384]; size_t n; while((n=fread(b,1,sizeof b,stdin))) g_bytes(&a,b,(int64_t)n); memcpy(g_address(out),&a,sizeof a); }
static void g_os_arg(int64_t i,GRef out) { if(i<0 || i>=g_argc) return; GArray a; memcpy(&a,g_address(out),sizeof a); g_bytes(&a,g_argv[i],(int64_t)strlen(g_argv[i])); memcpy(g_address(out),&a,sizeof a); }
static int g_os_env(GSlice name,GRef out) { char *n=g_path(name); const char *v=NULL; if(n) v=getenv(n); if(!v) return 0; GArray a; memcpy(&a,g_address(out),sizeof a); g_bytes(&a,v,(int64_t)strlen(v)); memcpy(g_address(out),&a,sizeof a); return 1; }
static int64_t g_os_time(int monotonic) {
    if(monotonic) { LARGE_INTEGER f,c; if(!QueryPerformanceFrequency(&f) || !QueryPerformanceCounter(&c)) return 0; return (int64_t)((double)c.QuadPart*(1000000000.0/(double)f.QuadPart)); }
    FILETIME ft; GetSystemTimeAsFileTime(&ft);
    uint64_t t=((uint64_t)ft.dwHighDateTime<<32)|ft.dwLowDateTime;
    return (int64_t)(t-116444736000000000ULL)*100;
}
static void g_os_sleep(int64_t ms) { if(ms<=0) return; while(ms>0) { DWORD part=ms>0x7fffffff?0x7fffffff:(DWORD)ms; Sleep(part); ms-=part; } }
static uint64_t g_os_random(void) {
    static volatile LONG64 g_rng_seq;
    uint64_t n=(uint64_t)g_os_time(0)^(uint64_t)g_os_time(1)^(uint64_t)GetCurrentProcessId()^(uint64_t)(uintptr_t)&n^(uint64_t)InterlockedIncrement64(&g_rng_seq);
    n+=UINT64_C(0x9e3779b97f4a7c15); n^=n>>30; n*=UINT64_C(0xbf58476d1ce4e5b9); n^=n>>27; n*=UINT64_C(0x94d049bb133111eb); return n^(n>>31);
}
static int g_sort_names(const void *a,const void *b) { return strcmp(*(const char *const *)a,*(const char *const *)b); }
static int g_os_list(GSlice path,GRef out) {
    char *s=g_path(path); if(!s || !s[0]) return 0;
    size_t len=strlen(s); char *pat=g_alloc(len+4); memcpy(pat,s,len);
    if(pat[len-1]!='/' && pat[len-1]!='\\' && pat[len-1]!=':') pat[len++]='\\';
    pat[len++]='*'; pat[len]=0;
    WIN32_FIND_DATAA e; HANDLE h=FindFirstFileA(pat,&e);
    if(h==INVALID_HANDLE_VALUE) return GetLastError()==ERROR_FILE_NOT_FOUND && g_os_kind(path)==2;
    char **names=NULL; size_t n=0,cap=0;
    do {
        if(!strcmp(e.cFileName,".") || !strcmp(e.cFileName,"..") || strchr(e.cFileName,10)) continue;
        if(n==cap) { cap=cap*2+16; names=realloc(names,cap*sizeof *names); if(!names) gs_panic("out of memory"); }
        size_t nl=strlen(e.cFileName)+1; names[n]=malloc(nl); if(!names[n]) gs_panic("out of memory"); memcpy(names[n],e.cFileName,nl); n++;
    } while(FindNextFileA(h,&e));
    FindClose(h);
    qsort(names,n,sizeof *names,g_sort_names);
    GArray a; memcpy(&a,g_address(out),sizeof a);
    for(size_t i=0;i<n;i++) { g_bytes(&a,names[i],(int64_t)strlen(names[i])); g_bytes(&a,"\n",1); free(names[i]); }
    free(names); memcpy(g_address(out),&a,sizeof a); return 1;
}
#else
static int g_os_write_atomic(GSlice path,GSlice data) { char *s=g_path(path); if(!s) return 0; size_t n=strlen(s); char *tmp=g_alloc(n+16); memcpy(tmp,s,n); memcpy(tmp+n,".tmp-XXXXXX",12); int fd=mkstemp(tmp); if(fd<0) return 0; FILE *f=fdopen(fd,"wb"); if(!f) { close(fd); unlink(tmp); return 0; } int ok=fwrite(g_address(data.base),1,(size_t)data.len,f)==(size_t)data.len; if(fflush(f)||fsync(fd)) ok=0; if(fclose(f)) ok=0; if(ok && rename(tmp,s)) ok=0; if(!ok) unlink(tmp); return ok; }
static int g_os_kind(GSlice path) { char *s=g_path(path); struct stat st; if(!s || stat(s,&st)) return 0; if(S_ISDIR(st.st_mode)) return 2; return 1; }
static int g_os_line(GRef out) { GArray a; memcpy(&a,g_address(out),sizeof a); int c; int any=0; while((c=fgetc(stdin))!=EOF) { any=1; if(c==10) break; unsigned char b=(unsigned char)c; g_bytes(&a,&b,1); } if(a.len && a.data[a.len-1]==13) a.len--; memcpy(g_address(out),&a,sizeof a); return any; }
static void g_os_stdin(GRef out) { GArray a; memcpy(&a,g_address(out),sizeof a); unsigned char b[16384]; size_t n; while((n=fread(b,1,sizeof b,stdin))) g_bytes(&a,b,(int64_t)n); memcpy(g_address(out),&a,sizeof a); }
static void g_os_arg(int64_t i,GRef out) { if(i<0 || i>=g_argc) return; GArray a; memcpy(&a,g_address(out),sizeof a); g_bytes(&a,g_argv[i],(int64_t)strlen(g_argv[i])); memcpy(g_address(out),&a,sizeof a); }
static int g_os_env(GSlice name,GRef out) { char *n=g_path(name); const char *v=NULL; if(n) v=getenv(n); if(!v) return 0; GArray a; memcpy(&a,g_address(out),sizeof a); g_bytes(&a,v,(int64_t)strlen(v)); memcpy(g_address(out),&a,sizeof a); return 1; }
static int64_t g_os_time(int monotonic) { struct timespec t; clockid_t c=CLOCK_REALTIME; if(monotonic) c=CLOCK_MONOTONIC; if(clock_gettime(c,&t)) return 0; return (int64_t)t.tv_sec*1000000000+t.tv_nsec; }
static void g_os_sleep(int64_t ms) { if(ms<0) return; struct timespec t={ms/1000,(ms%1000)*1000000}; while(nanosleep(&t,&t) && errno==EINTR) {} }
static uint64_t g_os_random(void) { uint64_t n=0; FILE *f=fopen("/dev/urandom","rb"); if(f) { if(fread(&n,1,sizeof n,f)!=sizeof n) n=0; fclose(f); } if(!n) n=(uint64_t)g_os_time(0)^(uint64_t)(uintptr_t)&n; n^=n>>30; n*=UINT64_C(0xbf58476d1ce4e5b9); n^=n>>27; n*=UINT64_C(0x94d049bb133111eb); return n^(n>>31); }
static int g_sort_names(const void *a,const void *b) { return strcmp(*(const char *const *)a,*(const char *const *)b); }
static int g_os_list(GSlice path,GRef out) { char *s=g_path(path); if(!s) return 0; DIR *d=opendir(s); if(!d) return 0; char **names=NULL; size_t n=0,cap=0; struct dirent *e; while((e=readdir(d))) { if(!strcmp(e->d_name,".") || !strcmp(e->d_name,"..") || strchr(e->d_name,10)) continue; if(n==cap) { cap=cap*2+16; names=realloc(names,cap*sizeof *names); if(!names) gs_panic("out of memory"); } names[n]=strdup(e->d_name); n++; } closedir(d); qsort(names,n,sizeof *names,g_sort_names); GArray a; memcpy(&a,g_address(out),sizeof a); for(size_t i=0;i<n;i++) { g_bytes(&a,names[i],(int64_t)strlen(names[i])); g_bytes(&a,"\n",1); free(names[i]); } free(names); memcpy(g_address(out),&a,sizeof a); return 1; }
#endif

