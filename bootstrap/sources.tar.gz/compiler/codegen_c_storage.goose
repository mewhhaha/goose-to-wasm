import model;

// These describe native frames. Image sizes and field offsets remain separate.
struct CcPlace { type_id: i64, address: i64, form: i64 = 0, stack: i64 = -1, owner_header: i64 = -1, image_base: i64 = -1, image_end: i64 = -1, nonnull: bool = false }
struct CcDestination {
    type_id: i64, header: i64, stack: i64, lifetime: i64, form: i64 = 0,
    entry: i64 = -1, start: i64 = -1, receiver: i64 = -1,
    publication: i64 = -1, construction: i64 = -1, run_capability: i64 = -1,
}
struct CcReceiving { ordinal: i64, destination: i64, symbol: i64 = -1, call: i64 = -1 }
struct CcChannels { value: i64, address: i64, run_capability: i64 = -1 }
struct CcCursor { symbol: i64, index: i64, address: i64, type_id: i64, node: i64 = -1, owner_header: i64 = -1 }
let CC_NATIVE: i64 = 0;
let CC_REGISTER: i64 = 1;
let CC_IMAGE: i64 = 2;
let CC_CHANNELS: i64 = 3;

// Per-type C layout cache stored on Type (keyed by own type ID).
// Two-bit fields in cc_memo_flags:
//  0..1:  cc_size_class (0 unknown, 1 => 0, 2 => 1, 3 => 2)
//  2..3:  cc_image_type (0 unknown, 1 false, 2 true)
//  4..5:  cc_self_relative_image
//  6..7:  cc_flat_relative_image
//  8..9:  cc_relative_fields(self_only=false)
// 10..11: cc_relative_fields(self_only=true)
// 12..13: cc_fixed_storage
// 14..15: cc_variable_prefix_frame
// 16..17: cc_result_location
// 18..19: cc_needs_clone
// 20:     cc_region_width_cache valid
// 21:     cc_frame_size_cache valid
inline fn cc_memo_prepare(p: Program&, id: i64) {
    if p.types[id].cc_memo_id != (id as i32) {
        p.types[id].cc_memo_id = id as i32;
        p.types[id].cc_memo_flags = 0;
    }
}
inline fn cc_memo_get2(p: Program&, id: i64, shift: u32) -> u32 {
    if p.types[id].cc_memo_id != (id as i32) { return 0; }
    return (p.types[id].cc_memo_flags >> shift) & 3;
}
inline fn cc_memo_set2(p: Program&, id: i64, shift: u32, val: u32) {
    cc_memo_prepare(p, id);
    p.types[id].cc_memo_flags = (p.types[id].cc_memo_flags & ~(3 << shift)) | (val << shift);
}

recursive fn cc_size_class(p: Program&, id: i64) -> i64 {
    if id < 0 { return 0; }
    let cached = cc_memo_get2(p, id, 0);
    if cached != 0 { return (cached - 1) as i64; }
    let t: const Type& = p.types[id];
    var result: i64 = 0;
    if t.kind == TY_INT { if t.storage != 0 { result = 1; } }
    else if t.kind == TY_REF { if t.length_storage == 0 { result = 1; } }
    else if t.kind == TY_ARRAY {
        if t.array_kind == A_FIXED || t.array_kind == A_LIMITED && t.count >= 0 { result = 0; }
        else if t.array_kind == A_VAR || t.array_kind == A_LIMITED { result = 1; }
        else { result = 2; }
    } else if t.kind == TY_ENUM && (t.flags & F_VARIABLE_MODE) == 0 {
        result = 0;
    } else {
        var field = -1;
        if t.kind == TY_ENUM { result = 1; }
        if (t.kind == TY_STRUCT || t.kind == TY_ENUM) && t.declaration >= 0 { field = p.nodes[t.declaration].first; }
        while field >= 0 {
            let n: const Node& = p.nodes[field];
            if (n.flags & F_PAD) == 0 { let size_class = cc_size_class(p, n.type_id); if size_class > result { result = size_class; } }
            field = n.next;
        }
        // A root owner's frame holds each component's own header: never an image.
        if result > 0 && root_struct_type(p, id) { result = 2; }
    }
    cc_memo_set2(p, id, 0, (result + 1) as u32);
    return result;
}
fn cc_image_type(p: Program&, id: i64) -> bool {
    if id < 0 || id >= p.types.len { return false; }
    let cached = cc_memo_get2(p, id, 2);
    if cached != 0 { return cached == 2; }
    let kind = cc_kind(p, id);
    var res = false;
    if kind == TY_ARRAY { res = p.types[id].array_kind == A_VAR || p.types[id].array_kind == A_LIMITED && p.types[id].count < 0; }
    else { res = (kind == TY_STRUCT || kind == TY_ENUM) && cc_size_class(p, id) == 1 && (kind == TY_ENUM || cc_image_fields(p, id)); }
    if res { cc_memo_set2(p, id, 2, 2); } else { cc_memo_set2(p, id, 2, 1); }
    return res;
}
recursive fn cc_image_fields(p: Program&, id: i64) -> bool {
    let t: const Type& = p.types[id];
    if t.kind == TY_ENUM && (t.flags & F_VARIABLE_MODE) != 0 { return true; }
    if t.kind == TY_INT { return t.storage != 0; }
    if t.kind == TY_REF { return t.length_storage == 0; }
    if t.kind == TY_ARRAY { return t.array_kind == A_VAR || t.array_kind == A_LIMITED && t.count < 0 || cc_image_fields(p, t.element); }
    var field = -1;
    if (t.kind == TY_STRUCT || t.kind == TY_ENUM) && t.declaration >= 0 { field = p.nodes[t.declaration].first; }
    while field >= 0 { let n: const Node& = p.nodes[field]; if (n.flags & F_PAD) == 0 && cc_image_fields(p, n.type_id) { return true; } field = n.next; }
    return false;
}
// Local pure-self images carry owner bounds; arrays require separate root authority.
fn cc_self_relative_image(p: Program&, id: i64) -> bool {
    if id < 0 || id >= p.types.len { return false; }
    let cached = cc_memo_get2(p, id, 4);
    if cached != 0 { return cached == 2; }
    var res = false;
    if p.types[id].kind == TY_STRUCT && cc_size_class(p, id) == 1 {
        var field = p.nodes[p.types[id].declaration].first; var self_link = false; var text = false; var ok = true;
        while field >= 0 {
            let n: const Node& = p.nodes[field]; field = n.next;
            if (n.flags & F_PAD) != 0 { continue; } let t: const Type& = p.types[n.type_id];
            if t.kind == TY_REF && t.element == id && t.length_storage > 0 && t.pool < 0 && (t.flags & TF_OPTIONAL) == 0 { self_link = true; }
            else if t.kind == TY_ARRAY && t.array_kind == A_VAR && t.element == TYPE_U8 && field < 0 { text = true; }
            else if t.kind != TY_INT && t.kind != TY_BOOL || t.storage != 0 { ok = false; break; }
        }
        res = ok && self_link && text;
    }
    if res { cc_memo_set2(p, id, 4, 2); } else { cc_memo_set2(p, id, 4, 1); }
    return res;
}
fn cc_self_run(p: Program&, id: i64) -> bool {
    if id < 0 || p.types[id].kind != TY_ARRAY || p.types[id].array_kind != A_GROW { return false; }
    return cc_self_relative_image(p, p.types[id].element);
}
fn cc_run_reference(p: Program&, id: i64) -> bool {
    return id >= 0 && p.types[id].kind == TY_REF && p.types[id].length_storage < 0 && (p.types[id].flags & TF_OPTIONAL) == 0 && cc_self_run(p, p.types[id].element);
}
fn cc_self_run_inside(p: Program&, id: i64) -> bool {
    var work: i64[>..] = [id]; var seen: bool[>..] = []; seen.resize(p.types.len, false);
    while work.len > 0 {
        let current = work.pop(); if current < 0 || seen[current] { continue; } seen[current] = true;
        if cc_self_run(p, current) { return true; } let t = p.types[current];
        if t.kind == TY_REF || t.kind == TY_ARRAY || t.kind == TY_SLICE { work.push(t.element); }
        else {
            var field = -1;
            if (t.kind == TY_STRUCT || t.kind == TY_ENUM) && t.declaration >= 0 { field = p.nodes[t.declaration].first; }
            if t.kind == TY_TUPLE { field = t.first; }
            while field >= 0 { let n = p.nodes[field]; if (n.flags & F_PAD) == 0 { work.push(n.type_id); } field = n.next; }
        }
    }
    return false;
}
fn cc_bounded_relative_image(p: Program&, id: i64) -> bool {
    return cc_flat_relative_image(p, id) || cc_self_relative_image(p, id);
}
// This first physical stage has no nested owner or self-relative field.
fn cc_flat_relative_image(p: Program&, id: i64) -> bool {
    if id < 0 || id >= p.types.len { return false; }
    let cached = cc_memo_get2(p, id, 6);
    if cached != 0 { return cached == 2; }
    var res = false;
    if p.types[id].kind == TY_STRUCT && cc_size_class(p, id) == 1 {
        var field = p.nodes[p.types[id].declaration].first; var relative = false; var ok = true;
        while field >= 0 {
            let n: const Node& = p.nodes[field]; field = n.next;
            if (n.flags & F_PAD) != 0 { continue; }
            let t: const Type& = p.types[n.type_id];
            if t.kind == TY_REF && t.length_storage >= 0 && t.pool >= 0 {
                if !cc_image_type(p, t.element) &&
                   (!cc_fixed_storage(p, t.element) || cc_region_width(p, t.element) != 0 || cc_frame_size(p, t.element) != p.types[t.element].size) { ok = false; break; }
                relative = true;
            } else if t.kind != TY_INT && t.kind != TY_BOOL { ok = false; break; }
        }
        res = ok && relative;
    }
    if res { cc_memo_set2(p, id, 6, 2); } else { cc_memo_set2(p, id, 6, 1); }
    return res;
}
fn cc_flat_image_reference(p: Program&, id: i64) -> bool {
    return id >= 0 && p.types[id].kind == TY_REF && p.types[id].length_storage < 0 && (p.types[id].flags & TF_OPTIONAL) == 0 && cc_bounded_relative_image(p, p.types[id].element);
}
fn cc_flat_image_abi_pending(p: Program&, id: i64) -> bool {
    if cc_bounded_relative_image(p, id) { return true; }
    return id >= 0 && p.types[id].kind == TY_REF && cc_bounded_relative_image(p, p.types[id].element);
}
fn cc_render_unbounded_image(p: Program&, id: i64) -> bool {
    if cc_self_relative_image(p, id) { return true; }
    let kind = cc_kind(p, id);
    if kind == TY_VOID || kind == TY_BOOL || kind == TY_INT || kind == TY_FLOAT || kind == TY_FN { return false; }
    var work: i64[>..] = [id]; var seen: bool[>..] = []; seen.resize(p.types.len, false);
    while work.len > 0 {
        let current = work.pop(); if current < 0 || seen[current] { continue; } seen[current] = true;
        let t = p.types[current];
        if t.kind == TY_REF {
            if cc_bounded_relative_image(p, t.element) { return true; }
            work.push(t.element);
        } else if t.kind == TY_ARRAY || t.kind == TY_SLICE { work.push(t.element); }
        else {
            var field = -1;
            if (t.kind == TY_STRUCT || t.kind == TY_ENUM) && t.declaration >= 0 { field = p.nodes[t.declaration].first; }
            if t.kind == TY_TUPLE { field = t.first; }
            while field >= 0 { let n = p.nodes[field]; if (n.flags & F_PAD) == 0 { work.push(n.type_id); } field = n.next; }
        }
    }
    return false;
}
fn cc_physical_cell_width(p: Program&, id: i64) -> i64 {
    let t = p.types[id];
    if t.kind == TY_REF || t.kind == TY_ARRAY && t.array_kind == A_VAR && t.element == TYPE_U8 { return t.length_storage; }
    if t.kind == TY_INT && t.storage != 0 { return 0; }
    return t.size;
}
inline fn cc_packed_pool_ref(p: Program&, id: i64) -> bool {
    return id >= 0 && p.types[id].kind == TY_REF && p.types[id].length_storage == 0 && p.types[id].pool >= 0;
}
fn cc_variable_enum_image(p: Program&, id: i64) -> bool {
    return cc_kind(p, id) == TY_ENUM && cc_image_type(p, id);
}
fn cc_image_constructible(p: Program&, id: i64) -> bool {
    if cc_bounded_relative_image(p, id) { return true; }
    let root = p.types[id];
    if root.kind == TY_REF { return root.length_storage < 0 || cc_packed_pool_ref(p, id); }
    if root.kind != TY_ARRAY && root.kind != TY_STRUCT && root.kind != TY_ENUM { return true; }
    var work: i64[>..] = [id]; var seen: bool[>..] = []; seen.resize(p.types.len, false);
    while work.len > 0 {
        let current = work.pop(); if current < 0 || seen[current] { continue; } seen[current] = true; let t = p.types[current];
        if t.kind == TY_REF { continue; }
        if t.kind == TY_ARRAY {
            if t.array_kind != A_FIXED && t.array_kind != A_VAR && t.array_kind != A_LIMITED { return false; }
            if cc_fixed_storage(p, t.element) { continue; }
            if t.array_kind != A_VAR { return false; } work.push(t.element); continue;
        }
        var field = -1;
        if (t.kind == TY_STRUCT || t.kind == TY_ENUM) && t.declaration >= 0 { field = p.nodes[t.declaration].first; }
        while field >= 0 { let n = p.nodes[field]; if (n.flags & F_PAD) == 0 { work.push(n.type_id); } field = n.next; }
    }
    return true;
}
recursive fn cc_variable_prefix_frame(p: Program&, id: i64) -> bool {
    if id < 0 || id >= p.types.len { return false; }
    let cached = cc_memo_get2(p, id, 14);
    if cached != 0 { return cached == 2; }
    var res = false;
    if cc_size_class(p, id) == 2 && !root_struct_type(p, id) {
        let t: const Type& = p.types[id];
        if t.kind == TY_STRUCT || t.kind == TY_ENUM {
            var field = p.nodes[t.declaration].first;
            while field >= 0 {
                let n: const Node& = p.nodes[field];
                if (n.flags & F_PAD) == 0 && (cc_size_class(p, n.type_id) == 1 && !cc_image_type(p, n.type_id) || cc_variable_prefix_frame(p, n.type_id)) { res = true; break; }
                field = n.next;
            }
        }
    }
    if res { cc_memo_set2(p, id, 14, 2); } else { cc_memo_set2(p, id, 14, 1); }
    return res;
}

recursive fn cc_region_width(p: Program&, type_id: i64) -> i64 {
    if type_id < 0 || type_id >= p.types.len { return 0; }
    if p.types[type_id].cc_memo_id == (type_id as i32) && (p.types[type_id].cc_memo_flags & (1 << 20)) != 0 {
        return p.types[type_id].cc_region_width_cache as i64;
    }
    var result: i64 = 0;
    if cc_image_type(p, type_id) { result = 1; }
    else {
        let t: const Type& = p.types[type_id];
        if t.kind == TY_ARRAY {
            if t.array_kind == A_FIXED || t.array_kind == A_VAR || t.array_kind == A_LIMITED { result = 0; }
            else { result = 1; }
        } else if t.kind == TY_STRUCT && t.declaration >= 0 {
            var field = p.nodes[t.declaration].first;
            while field >= 0 {
                if (p.nodes[field].flags & F_PAD) == 0 { result += cc_region_width(p, p.nodes[field].type_id); }
                field = p.nodes[field].next;
            }
        } else if t.kind == TY_TUPLE {
            var field = t.first;
            while field >= 0 { result += cc_region_width(p, p.nodes[field].type_id); field = p.nodes[field].next; }
        } else if t.kind == TY_ENUM && t.declaration >= 0 {
            var variant = p.nodes[t.declaration].first;
            while variant >= 0 {
                let width = cc_region_width(p, p.nodes[variant].type_id);
                if width > result { result = width; }
                variant = p.nodes[variant].next;
            }
        }
    }
    cc_memo_prepare(p, type_id);
    p.types[type_id].cc_region_width_cache = result as i32;
    p.types[type_id].cc_memo_flags |= (1 << 20);
    return result;
}

recursive fn cc_frame_size(p: Program&, type_id: i64) -> i64 {
    if type_id < 0 || type_id >= p.types.len { return 0; }
    if p.types[type_id].cc_memo_id == (type_id as i32) && (p.types[type_id].cc_memo_flags & (1 << 21)) != 0 {
        return p.types[type_id].cc_frame_size_cache;
    }
    var size: i64 = 0;
    if cc_image_type(p, type_id) { size = 24; }
    else if cc_self_run(p, type_id) { size = 32; }
    else {
        let t: const Type& = p.types[type_id];
        // A root owner's frame places its components' frames side by side; the
        // checked layout (one reference per field) only describes the owner.
        if root_struct_type(p, type_id) {
            var field = p.nodes[t.declaration].first;
            while field >= 0 { if (p.nodes[field].flags & F_PAD) == 0 { size += cc_root_component_size(p, p.nodes[field].type_id); } field = p.nodes[field].next; }
        } else if t.kind == TY_STRUCT && t.declaration >= 0 {
            size = t.size; var field = p.nodes[t.declaration].first;
            while field >= 0 {
                let n: const Node& = p.nodes[field];
                if (n.flags & F_PAD) == 0 { size += cc_frame_size(p, n.type_id) - p.types[n.type_id].size; }
                field = n.next;
            }
        } else if t.kind == TY_TUPLE {
            var field = t.first;
            while field >= 0 {
                let id = p.nodes[field].type_id;
                if p.types[id].kind == TY_REF || p.types[id].kind == TY_INT && p.types[id].storage != 0 { size += 8; }
                else { size += cc_frame_size(p, id); } field = p.nodes[field].next;
            }
        } else if t.kind == TY_ENUM && t.declaration >= 0 {
            var payload = 0; var variant = p.nodes[t.declaration].first;
            while variant >= 0 {
                let vsize = cc_frame_size(p, p.nodes[variant].type_id); if vsize > payload { payload = vsize; }
                variant = p.nodes[variant].next;
            }
            size = t.length_storage + payload;
            if cc_region_width(p, type_id) > 0 { size += 8; }
        } else {
            size = t.size;
        }
    }
    cc_memo_prepare(p, type_id);
    p.types[type_id].cc_frame_size_cache = size;
    p.types[type_id].cc_memo_flags |= (1 << 21);
    return size;
}
// A root owner's frame bytes for one component: its own frame, or for an
// encoded integer (sized 0) room for its widest encoding, a zigzag ULEB128
// of 10 bytes, as direct Wasm lays it out (cg_root_layouts).
recursive fn cc_root_component_size(p: Program&, type_id: i64) -> i64 {
    if type_id >= 0 && p.types[type_id].kind == TY_INT && p.types[type_id].storage == 1 { return 10; }
    return cc_frame_size(p, type_id);
}
fn cc_field_offset(p: Program&, type_id: i64, field: i64) -> i64 {
    var id = type_id;
    while id >= 0 && p.types[id].kind == TY_REF { id = p.types[id].element; }
    let n: const Node& = p.nodes[field];
    if id < 0 || p.types[id].kind != TY_STRUCT || p.types[id].declaration < 0 { return n.integer; }
    if root_struct_type(p, id) {
        var offset = 0; var previous = p.nodes[p.types[id].declaration].first;
        while previous >= 0 && previous != field {
            if (p.nodes[previous].flags & F_PAD) == 0 { offset += cc_root_component_size(p, p.nodes[previous].type_id); } previous = p.nodes[previous].next;
        }
        return offset;
    }
    var offset = n.integer; var previous = p.nodes[p.types[id].declaration].first;
    while previous >= 0 && previous != field {
        let value: const Node& = p.nodes[previous];
        if (value.flags & F_PAD) == 0 { offset += cc_frame_size(p, value.type_id) - p.types[value.type_id].size; }
        previous = value.next;
    }
    return offset;
}

fn cc_frame_borrows(p: Program&, type_id: i64) -> bool {
    if type_id < 0 || type_id >= p.types.len { return false; }
    if p.types[type_id].cc_memo_id == (type_id as i32) && (p.types[type_id].cc_memo_flags & (1 << 22)) != 0 {
        return (p.types[type_id].cc_memo_flags & (1 << 23)) != 0;
    }
    let root_kind = p.types[type_id].kind;
    var ans = false;
    if root_kind == TY_REF || root_kind == TY_SLICE || root_kind == TY_FN { ans = true; }
    else if root_kind == TY_ARRAY || root_kind == TY_STRUCT || root_kind == TY_ENUM || root_kind == TY_TUPLE {
        var work: i64[>..] = [type_id]; var seen: bool[>..] = []; seen.resize(p.types.len, false);
        while work.len > 0 {
            let current = work.pop(); if current < 0 || seen[current] { continue; } seen[current] = true;
            let t: const Type& = p.types[current];
            if t.kind == TY_REF || t.kind == TY_SLICE || t.kind == TY_FN { ans = true; break; }
            if t.kind == TY_ARRAY { work.push(t.element); }
            var field = -1;
            if (t.kind == TY_STRUCT || t.kind == TY_ENUM) && t.declaration >= 0 { field = p.nodes[t.declaration].first; }
            else if t.kind == TY_TUPLE { field = t.first; }
            while field >= 0 { let n: const Node& = p.nodes[field]; if (n.flags & F_PAD) == 0 { work.push(n.type_id); } field = n.next; }
        }
    }
    cc_memo_prepare(p, type_id);
    if ans { p.types[type_id].cc_memo_flags |= (3 << 22); } else { p.types[type_id].cc_memo_flags |= (1 << 22); }
    return ans;
}

inline fn cc_kind(p: Program&, type_id: i64) -> i64 {
    if type_id < 0 || type_id >= p.types.len { return TY_UNKNOWN; } return p.types[type_id].kind;
}
recursive fn cc_concrete_walk(p: Program&, id: i64, seen: i32[64]&, seen_len: i64&) -> bool {
    if id < 0 || id >= p.types.len { return false; }
    let key = id * 8 + 7;
    if key < p.type_properties.len && p.type_properties[key] != 0 { return p.type_properties[key] == 2; }
    let kind = p.types[id].kind;
    if kind == TY_UNKNOWN || kind == TY_GENERIC || kind == TY_NAME { return false; }
    if kind == TY_VOID || kind == TY_BOOL || kind == TY_INT || kind == TY_FLOAT { return true; }
    let t = p.types[id];
    if kind == TY_ARRAY || kind == TY_SLICE || kind == TY_REF {
        return cc_concrete_walk(p, t.element, seen, seen_len);
    }
    if kind == TY_FN {
        if !cc_concrete_walk(p, t.element, seen, seen_len) { return false; }
        var param = t.first;
        while param >= 0 {
            if !cc_concrete_walk(p, p.nodes[param].type_id, seen, seen_len) { return false; }
            param = p.nodes[param].next;
        }
        return true;
    }
    if kind == TY_TUPLE {
        var part = t.first;
        while part >= 0 {
            if !cc_concrete_walk(p, p.nodes[part].type_id, seen, seen_len) { return false; }
            part = p.nodes[part].next;
        }
        return true;
    }
    if kind == TY_STRUCT || kind == TY_ENUM {
        if t.declaration < 0 { return false; }
        let id32 = id as i32;
        for i in 0..seen_len { if seen[i] == id32 { return true; } }
        if seen_len >= 64 { return true; }
        seen[seen_len] = id32; seen_len += 1;
        var arg = t.arguments;
        while arg >= 0 {
            let at = p.nodes[arg].type_id;
            if at >= 0 && !cc_concrete_walk(p, at, seen, seen_len) { return false; }
            arg = p.nodes[arg].next;
        }
        var field = p.nodes[t.declaration].first;
        while field >= 0 {
            let n = p.nodes[field];
            if n.kind == N_VARIANT && n.type_id < 0 { return false; }
            if (n.kind == N_FIELD && (n.flags & F_PAD) == 0) || n.kind == N_VARIANT {
                if !cc_concrete_walk(p, n.type_id, seen, seen_len) { return false; }
            }
            field = n.next;
        }
    }
    return true;
}
fn cc_concrete(p: Program&, id: i64) -> bool {
    if id < 0 || id >= p.types.len { return false; }
    let key = id * 8 + 7;
    if key < p.type_properties.len && p.type_properties[key] != 0 { return p.type_properties[key] == 2; }
    let root_kind = p.types[id].kind;
    if root_kind == TY_VOID || root_kind == TY_BOOL || root_kind == TY_INT || root_kind == TY_FLOAT { return true; }
    var ok = false;
    if root_kind != TY_UNKNOWN && root_kind != TY_GENERIC && root_kind != TY_NAME {
        var seen: i32[64] = [0; 64];
        var seen_len: i64 = 0;
        ok = cc_concrete_walk(p, id, seen, seen_len);
    }
    if p.type_properties.len <= key { p.type_properties.resize(p.types.len * 8, 0); }
    if ok { p.type_properties[key] = 2; } else { p.type_properties[key] = 1; }
    return ok;
}

inline fn cc_indirect(p: Program&, type_id: i64) -> bool {
    let kind = cc_kind(p, type_id);
    return (kind == TY_ARRAY || kind == TY_STRUCT || kind == TY_ENUM || kind == TY_TUPLE) && cc_frame_size(p, type_id) > 4096;
}
inline fn cc_receives(p: Program&, type_id: i64) -> bool {
    return cc_region_width(p, type_id) > 0 || cc_result_indirect(p, type_id);
}
inline fn cc_array_kind(p: Program&, type_id: i64) -> i64 {
    if cc_kind(p, type_id) == TY_SLICE { return A_SLICE; }
    return p.types[type_id].array_kind;
}
fn cc_prefix(p: Program&, type_id: i64) -> i64 {
    let t: const Type& = p.types[type_id];
    if t.array_kind == A_VAR && t.length_storage > 0 { return t.length_storage; }
    if t.array_kind != A_LIMITED || t.count < 0 { return 0; }
    if t.length_storage > 0 { return t.length_storage; } return 1;
}
fn cc_pool_mode(p: Program&, symbol: i64) -> i64 {
    if symbol < 0 || p.symbols[symbol].node < 0 { return 0; }
    let flags = p.nodes[p.symbols[symbol].node].flags;
    if (flags & F_REUSABLE) == 0 { return 0; }
    if (flags & F_REUSABLE_SLICES) != 0 { return 2; } return 1;
}

inline fn cc_relative_cell(p: Program&, type_id: i64) -> bool {
    return cc_kind(p, type_id) == TY_REF && p.types[type_id].length_storage >= 0;
}
fn cc_storage_type(p: Program&, out: u8[>..]&, type_id: i64) {
    if cc_relative_cell(p, type_id) && p.types[type_id].length_storage == 0 { out.append("GVarRelative"); }
    else if cc_relative_cell(p, type_id) { out.format("uint", p.types[type_id].length_storage * 8, "_t"); }
    else { out.format("g_t", type_id); }
}
fn cc_place_type(p: Program&, node: i64) -> i64 {
    let n: const Node& = p.nodes[node];
    if n.kind == N_NAME && n.symbol >= 0 { return p.symbols[n.symbol].type_id; }
    if n.kind == N_MEMBER && n.symbol >= 0 { return p.nodes[n.symbol].type_id; }
    if n.kind == N_INDEX {
        var array = p.nodes[n.left].type_id; while cc_kind(p, array) == TY_REF { array = p.types[array].element; }
        if cc_kind(p, array) == TY_ARRAY || cc_kind(p, array) == TY_SLICE { return p.types[array].element; }
    }
    if n.kind == N_UNARY && n.integer == T_MUL && cc_kind(p, p.nodes[n.left].type_id) == TY_REF { return p.types[p.nodes[n.left].type_id].element; }
    return n.type_id;
}

recursive fn cc_relative_fields(p: Program&, type_id: i64, self_only: bool = false) -> bool {
    if type_id < 0 || type_id >= p.types.len { return false; }
    var shift: u32 = 8; if self_only { shift = 10; }
    let cached = cc_memo_get2(p, type_id, shift);
    if cached != 0 { return cached == 2; }
    let t: const Type& = p.types[type_id];
    var res = false;
    if t.kind == TY_REF { res = t.length_storage >= 0 && (!self_only || t.pool < 0); }
    else if t.kind == TY_ARRAY {
        if t.array_kind == A_FIXED || t.array_kind == A_LIMITED && t.count >= 0 { res = cc_relative_fields(p, t.element, self_only); }
    } else {
        var field = -1;
        if t.kind == TY_STRUCT && t.declaration >= 0 { field = p.nodes[t.declaration].first; }
        else if t.kind == TY_ENUM && t.declaration >= 0 { field = p.nodes[t.declaration].first; }
        else if t.kind == TY_TUPLE { field = t.first; }
        while field >= 0 {
            let n: const Node& = p.nodes[field];
            if (n.flags & F_PAD) == 0 && !(t.kind == TY_TUPLE && cc_kind(p, n.type_id) == TY_REF) && cc_relative_fields(p, n.type_id, self_only) { res = true; break; }
            field = n.next;
        }
    }
    if res { cc_memo_set2(p, type_id, shift, 2); } else { cc_memo_set2(p, type_id, shift, 1); }
    return res;
}
recursive fn cc_fixed_storage(p: Program&, type_id: i64) -> bool {
    if type_id < 0 || type_id >= p.types.len { return true; }
    let cached = cc_memo_get2(p, type_id, 12);
    if cached != 0 { return cached == 2; }
    let t: const Type& = p.types[type_id];
    var res = true;
    if t.kind == TY_INT { res = t.storage == 0; }
    else if t.kind == TY_REF { res = t.length_storage != 0; }
    else if t.kind == TY_ARRAY { res = (t.array_kind == A_FIXED || t.array_kind == A_LIMITED && t.count >= 0) && cc_fixed_storage(p, t.element); }
    else if t.kind == TY_ENUM && (t.flags & F_VARIABLE_MODE) != 0 { res = false; }
    else {
        var field = -1;
        if (t.kind == TY_STRUCT || t.kind == TY_ENUM) && t.declaration >= 0 { field = p.nodes[t.declaration].first; }
        else if t.kind == TY_TUPLE { field = t.first; }
        while field >= 0 {
            let n: const Node& = p.nodes[field]; if (n.flags & F_PAD) == 0 && !cc_fixed_storage(p, n.type_id) { res = false; break; } field = n.next;
        }
    }
    if res { cc_memo_set2(p, type_id, 12, 2); } else { cc_memo_set2(p, type_id, 12, 1); }
    return res;
}
fn cc_result_location(p: Program&, type_id: i64) -> bool {
    if type_id < 0 || type_id >= p.types.len { return false; }
    let cached = cc_memo_get2(p, type_id, 16);
    if cached != 0 { return cached == 2; }
    var res = false;
    if cc_image_type(p, type_id) || cc_self_run(p, type_id) { res = true; }
    else {
        let kind = cc_kind(p, type_id);
        if kind == TY_TUPLE {
            var ok = true; var field = p.types[type_id].first;
            while field >= 0 {
                let child = p.nodes[field].type_id;
                if cc_kind(p, child) != TY_REF && cc_relative_fields(p, child) && !cc_fixed_storage(p, child) { ok = false; break; } field = p.nodes[field].next;
            }
            res = ok && cc_relative_fields(p, type_id);
        } else {
            res = (kind == TY_ARRAY || kind == TY_STRUCT || kind == TY_ENUM) && cc_fixed_storage(p, type_id) && cc_relative_fields(p, type_id);
        }
    }
    if res { cc_memo_set2(p, type_id, 16, 2); } else { cc_memo_set2(p, type_id, 16, 1); }
    return res;
}
fn cc_tuple_channels(p: Program&, type_id: i64) -> bool {
    if cc_kind(p, type_id) != TY_TUPLE { return false; }
    if cc_indirect(p, type_id) { return true; }
    var field = p.types[type_id].first;
    while field >= 0 {
        let kind = cc_kind(p, p.nodes[field].type_id);
        if kind == TY_ARRAY || kind == TY_STRUCT || kind == TY_ENUM || kind == TY_TUPLE { return true; }
        field = p.nodes[field].next;
    }
    return false;
}
fn cc_result_indirect(p: Program&, type_id: i64) -> bool { return cc_tuple_channels(p, type_id) || cc_indirect(p, type_id) || cc_result_location(p, type_id); }
fn cc_helper_indirect(p: Program&, type_id: i64) -> bool {
    if cc_image_type(p, type_id) || cc_self_run(p, type_id) { return false; }
    let kind = cc_kind(p, type_id);
    return cc_indirect(p, type_id) || (kind == TY_ARRAY || kind == TY_STRUCT || kind == TY_ENUM || kind == TY_TUPLE) && cc_relative_fields(p, type_id, true);
}

struct CcFill { node: i64, type_id: i64, value: i64 }
recursive fn cc_field_defaults(p: Program&, type_id: i64) -> bool {
    let t = p.types[type_id];
    if t.kind == TY_ARRAY { return t.array_kind == A_FIXED && t.count > 0 && cc_field_defaults(p, t.element); }
    if t.kind == TY_ENUM && t.declaration >= 0 {
        let first = p.nodes[t.declaration].first; return first >= 0 && cc_field_defaults(p, p.nodes[first].type_id);
    }
    if t.kind != TY_STRUCT || t.declaration < 0 { return false; }
    var field = p.nodes[t.declaration].first;
    while field >= 0 {
        let n = p.nodes[field];
        if (n.flags & F_PAD) == 0 && (n.right >= 0 || cc_field_defaults(p, n.type_id)) { return true; } field = n.next;
    }
    return false;
}

// The frontend exports -2 only for exact static/null roots and rejects
// relative cells in these globals. Owning fields still need private copies.
fn cc_static_global(p: Program&, symbol: i64) -> bool {
    let s = p.symbols[symbol];
    return (s.flags & (S_GLOBAL | S_MUTABLE)) == S_GLOBAL && s.provenance == -2 && cc_frame_borrows(p, s.type_id);
}
