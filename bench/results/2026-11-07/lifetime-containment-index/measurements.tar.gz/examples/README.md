# Example program benchmarks

Status: **passed**.

2026-11-07 · AMD Ryzen 7 3800X 8-Core Processor.

Goose O2. Direct Wasm uses memory32; Native C is emitted by the Goose compiler. The selected programs, their constant inputs and all printing are unchanged from the [example catalog](../../../../examples/README.md). Compiler constant folding is allowed.

Builds are complete uncached Python-driver invocations, including any C compilation/linking. OS page caches remain warm.

Runtime is **whole-process launch-to-exit time**, including host startup, Wasm compilation/instantiation, program initialization, computation, output delivery and teardown. Each observation starts a fresh process/instance and calls the entrypoint once. This measures CLI cost, not warmed kernel throughput.

Each cell has 5 build samples or 5 runtime samples. Untimed fresh-process warmups per runtime cell: 1. Orders are shuffled with the recorded seed; builds and runtime never overlap. Every used artifact must pass its golden output. Values are median milliseconds ± median absolute deviation (MAD).

Headline runtime samples use the ordinary runners without timing-file instrumentation. The Wasm supplements use a separate shuffled set of fresh processes, with the same sample count; timing files are written after their engine intervals end.

## Compilation

| Example | Direct Wasm | Goose Native C |
| --- | ---: | ---: |
| squares | 50.868 ±0.730 | 263.586 ±0.534 |
| tour | 64.492 ±0.956 | 938.794 ±8.968 |
| functions | 131.623 ±0.983 | 1680.047 ±65.236 |
| errors | 82.883 ±0.301 | 732.276 ±11.651 |
| sieve | 75.003 ±0.931 | 412.605 ±2.893 |
| sorting | 137.182 ±0.557 | 1853.639 ±7.445 |
| sudoku | 78.450 ±4.553 | 490.690 ±2.594 |
| maze | 87.498 ±0.155 | 720.969 ±3.161 |
| vm | 84.067 ±0.341 | 593.357 ±2.681 |
| life | 75.827 ±0.720 | 547.424 ±6.757 |

## Whole-process runtime

| Example | Direct / V8 | Direct / Wasmtime | Goose Native C |
| --- | ---: | ---: | ---: |
| squares | 27.751 ±0.525 | 73.826 ±0.912 | 0.850 ±0.014 |
| tour | 58.579 ±1.450 | 132.216 ±0.310 | 0.939 ±0.013 |
| functions | 62.819 ±2.135 | 260.107 ±0.946 | 0.989 ±0.052 |
| errors | 33.667 ±0.566 | 109.402 ±0.573 | 0.828 ±0.049 |
| sieve | 64.834 ±0.677 | 96.478 ±0.371 | 1.999 ±0.037 |
| sorting | 410.564 ±1.647 | 400.564 ±2.240 | 118.009 ±0.317 |
| sudoku | 49.715 ±0.586 | 102.787 ±0.655 | 9.011 ±0.046 |
| maze | 52.995 ±1.718 | 161.662 ±0.342 | 0.943 ±0.081 |
| vm | 62.216 ±1.012 | 148.737 ±0.624 | 0.976 ±0.008 |
| life | 68.620 ±0.369 | 134.285 ±3.829 | 21.371 ±0.041 |

## Supplement: Wasm entrypoint

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.199 ±0.001 | 0.130 ±0.009 |
| tour | 25.631 ±0.507 | 1.066 ±0.001 |
| functions | 28.058 ±0.674 | 1.026 ±0.012 |
| errors | 4.285 ±0.060 | 0.864 ±0.007 |
| sieve | 13.479 ±1.794 | 2.119 ±0.012 |
| sorting | 378.983 ±0.694 | 172.326 ±0.163 |
| sudoku | 20.190 ±0.108 | 12.278 ±0.034 |
| maze | 23.437 ±0.387 | 0.780 ±0.007 |
| vm | 28.924 ±0.101 | 0.922 ±0.003 |
| life | 39.481 ±0.134 | 28.601 ±0.087 |

## Supplement: Wasm engine compilation and instantiation

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.298 ±0.034 | 4.334 ±0.048 |
| tour | 0.568 ±0.008 | 61.839 ±0.299 |
| functions | 1.153 ±0.019 | 190.201 ±0.146 |
| errors | 0.515 ±0.030 | 39.532 ±0.019 |
| sieve | 0.392 ±0.016 | 24.596 ±0.109 |
| sorting | 1.129 ±0.009 | 161.969 ±0.847 |
| sudoku | 0.382 ±0.008 | 21.446 ±0.033 |
| maze | 0.731 ±0.019 | 91.773 ±0.225 |
| vm | 0.663 ±0.017 | 77.207 ±0.300 |
| life | 0.444 ±0.020 | 35.412 ±0.242 |

The entrypoint interval includes Goose initialization, host output callbacks and any lazy JIT work. It excludes final Wasm-host output concatenation/delivery. Native Goose prints unbuffered, so no native entrypoint column or cross-boundary speedup is presented. Process time minus engine time also includes loading, bookkeeping and teardown; it is not a pure startup measurement.

These fresh-process examples have different timing rules from LangArena's warmed computational regions. Raw samples, commands, artifact/source/compiler identities and engine versions are in [report.json](report.json). [Method and reproduction](../../../examples.md).
