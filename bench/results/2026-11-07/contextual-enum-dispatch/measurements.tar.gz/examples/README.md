# Example program benchmarks

Status: **passed**.

2026-11-07 · AMD Ryzen 7 3800X 8-Core Processor.

Goose O2. Direct Wasm uses memory32; Native C is emitted by the Goose compiler. The selected programs, their constant inputs and all printing are unchanged from the [example catalog](../../../../examples/README.md). Compiler constant folding is allowed.

Builds are complete uncached Python-driver invocations, including any C compilation/linking. OS page caches remain warm.

Runtime is **whole-process launch-to-exit time**, including host startup, Wasm compilation/instantiation, program initialization, computation, output delivery and teardown. Each observation starts a fresh process/instance and calls the entrypoint once. This measures CLI cost, not warmed kernel throughput.

Each cell has 5 build samples or 5 runtime samples. Untimed fresh-process warmups per runtime cell: 1. Orders are shuffled with the recorded seed; builds and runtime never overlap. Every used artifact must pass its golden output. Values are median milliseconds ± median absolute deviation (MAD).

Headline runtime samples use the ordinary runners without timing-file instrumentation. The Wasm supplements use a separate shuffled set of fresh processes, with the same sample count; timing files are written after their engine intervals end.

## Compilation

| Example | Direct Wasm | Goose Native C |
| --- | ---: | ---: |
| squares | 49.261 ±0.159 | 247.877 ±0.323 |
| tour | 61.637 ±0.075 | 888.105 ±1.432 |
| functions | 129.037 ±0.010 | 1588.701 ±2.864 |
| errors | 78.364 ±0.191 | 711.913 ±1.599 |
| sieve | 71.534 ±0.071 | 390.058 ±1.265 |
| sorting | 131.166 ±0.134 | 1820.089 ±8.006 |
| sudoku | 72.583 ±0.291 | 469.743 ±6.046 |
| maze | 86.125 ±0.479 | 712.052 ±1.700 |
| vm | 79.990 ±0.277 | 584.473 ±0.469 |
| life | 73.999 ±0.266 | 516.914 ±0.710 |

## Whole-process runtime

| Example | Direct / V8 | Direct / Wasmtime | Goose Native C |
| --- | ---: | ---: | ---: |
| squares | 26.117 ±0.396 | 68.347 ±0.118 | 0.795 ±0.013 |
| tour | 55.971 ±1.359 | 124.820 ±0.184 | 0.866 ±0.028 |
| functions | 58.526 ±0.375 | 244.799 ±0.040 | 0.911 ±0.015 |
| errors | 30.364 ±1.649 | 102.519 ±0.270 | 0.751 ±0.005 |
| sieve | 59.810 ±1.094 | 89.763 ±0.082 | 1.940 ±0.009 |
| sorting | 397.170 ±2.272 | 381.271 ±1.885 | 113.730 ±0.157 |
| sudoku | 45.632 ±0.408 | 95.670 ±0.296 | 8.761 ±0.052 |
| maze | 50.313 ±1.001 | 150.681 ±0.414 | 0.793 ±0.043 |
| vm | 59.248 ±0.480 | 139.744 ±0.755 | 0.877 ±0.005 |
| life | 65.365 ±1.027 | 125.055 ±0.152 | 20.680 ±0.044 |

## Supplement: Wasm entrypoint

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.188 ±0.001 | 0.126 ±0.004 |
| tour | 24.679 ±0.068 | 1.034 ±0.004 |
| functions | 32.096 ±1.578 | 1.009 ±0.005 |
| errors | 4.026 ±0.015 | 0.829 ±0.013 |
| sieve | 14.800 ±0.947 | 2.031 ±0.006 |
| sorting | 367.413 ±1.851 | 162.068 ±0.138 |
| sudoku | 19.350 ±0.352 | 11.685 ±0.018 |
| maze | 22.091 ±0.170 | 0.781 ±0.004 |
| vm | 28.270 ±0.405 | 0.902 ±0.007 |
| life | 37.039 ±0.550 | 27.060 ±0.277 |

## Supplement: Wasm engine compilation and instantiation

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.256 ±0.007 | 4.230 ±0.046 |
| tour | 0.530 ±0.010 | 58.144 ±0.100 |
| functions | 1.132 ±0.018 | 178.240 ±0.510 |
| errors | 0.449 ±0.012 | 37.142 ±0.116 |
| sieve | 0.351 ±0.005 | 23.173 ±0.012 |
| sorting | 1.087 ±0.007 | 152.121 ±0.498 |
| sudoku | 0.389 ±0.025 | 20.142 ±0.064 |
| maze | 0.700 ±0.024 | 86.222 ±0.472 |
| vm | 0.604 ±0.020 | 73.051 ±0.332 |
| life | 0.471 ±0.021 | 33.122 ±0.109 |

The entrypoint interval includes Goose initialization, host output callbacks and any lazy JIT work. It excludes final Wasm-host output concatenation/delivery. Native Goose prints unbuffered, so no native entrypoint column or cross-boundary speedup is presented. Process time minus engine time also includes loading, bookkeeping and teardown; it is not a pure startup measurement.

These fresh-process examples have different timing rules from LangArena's warmed computational regions. Raw samples, commands, artifact/source/compiler identities and engine versions are in [report.json](report.json). [Method and reproduction](../../../examples.md).
