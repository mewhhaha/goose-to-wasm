# Example program benchmarks

Status: **passed**.

2026-11-07 · AMD Ryzen 7 3800X 8-Core Processor.

Goose O2. Direct Wasm uses memory32; Native C is emitted by the Goose compiler. The selected programs, their constant inputs and all printing are unchanged from the [example catalog](../../../../examples/README.md). Compiler constant folding is allowed.

Builds are complete uncached Python-driver invocations, including any C compilation/linking. OS page caches remain warm.

Runtime is **whole-process launch-to-exit time**, including host startup, Wasm compilation/instantiation, program initialization, computation, output delivery and teardown. Each observation starts a fresh process/instance and calls the entrypoint once. This measures CLI cost, not warmed kernel throughput.

Each cell has 5 build samples or 5 runtime samples. Untimed fresh-process warmups per runtime cell: 1. Orders are shuffled with the recorded seed; builds and runtime never overlap. Every used artifact must pass its golden output. Values are median milliseconds ± median absolute deviation (MAD).

Headline runtime samples use the ordinary runners without timing-file instrumentation. The Wasm supplements use a separate shuffled set of fresh processes, with the same sample count; timing files are written after their engine intervals end.

## Compilation

| Example | Direct Wasm | Goose Native C |
| --- | ---: | ---: |
| squares | 51.892 ±1.656 | 250.744 ±1.307 |
| tour | 61.999 ±0.230 | 964.961 ±67.670 |
| functions | 137.466 ±1.079 | 1609.794 ±10.688 |
| errors | 79.206 ±0.658 | 762.830 ±2.224 |
| sieve | 71.766 ±0.079 | 391.931 ±2.774 |
| sorting | 133.161 ±0.958 | 1944.040 ±44.062 |
| sudoku | 78.075 ±0.560 | 477.320 ±13.871 |
| maze | 90.980 ±0.898 | 762.259 ±45.905 |
| vm | 84.395 ±2.047 | 624.817 ±0.671 |
| life | 79.365 ±5.103 | 519.461 ±0.810 |

## Whole-process runtime

| Example | Direct / V8 | Direct / Wasmtime | Goose Native C |
| --- | ---: | ---: | ---: |
| squares | 25.824 ±0.133 | 68.650 ±0.143 | 0.802 ±0.015 |
| tour | 54.836 ±0.402 | 125.033 ±0.382 | 0.767 ±0.009 |
| functions | 57.782 ±0.530 | 247.266 ±0.432 | 0.908 ±0.022 |
| errors | 30.893 ±0.572 | 103.174 ±0.184 | 0.773 ±0.038 |
| sieve | 59.826 ±0.322 | 90.036 ±0.281 | 1.946 ±0.003 |
| sorting | 403.703 ±2.664 | 385.922 ±0.560 | 115.466 ±0.186 |
| sudoku | 45.885 ±0.088 | 96.780 ±0.129 | 8.801 ±0.073 |
| maze | 50.231 ±0.175 | 152.698 ±0.031 | 0.779 ±0.012 |
| vm | 59.480 ±0.580 | 140.084 ±0.634 | 0.889 ±0.008 |
| life | 65.099 ±0.787 | 126.100 ±0.068 | 20.809 ±0.107 |

## Supplement: Wasm entrypoint

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.187 ±0.002 | 0.121 ±0.003 |
| tour | 24.719 ±0.190 | 1.038 ±0.003 |
| functions | 26.747 ±0.106 | 1.005 ±0.005 |
| errors | 4.054 ±0.066 | 0.832 ±0.014 |
| sieve | 15.646 ±1.077 | 2.030 ±0.016 |
| sorting | 366.390 ±0.645 | 165.437 ±0.213 |
| sudoku | 19.545 ±0.143 | 11.596 ±0.021 |
| maze | 22.182 ±0.312 | 0.764 ±0.005 |
| vm | 28.123 ±0.143 | 0.909 ±0.001 |
| life | 37.883 ±0.117 | 27.788 ±0.150 |

## Supplement: Wasm engine compilation and instantiation

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.257 ±0.003 | 4.154 ±0.036 |
| tour | 0.551 ±0.037 | 58.688 ±0.161 |
| functions | 1.085 ±0.004 | 179.811 ±0.353 |
| errors | 0.531 ±0.003 | 37.773 ±0.148 |
| sieve | 0.427 ±0.011 | 23.203 ±0.002 |
| sorting | 1.152 ±0.005 | 153.385 ±0.353 |
| sudoku | 0.335 ±0.005 | 20.178 ±0.047 |
| maze | 0.705 ±0.010 | 87.522 ±0.855 |
| vm | 0.576 ±0.012 | 73.066 ±0.298 |
| life | 0.409 ±0.008 | 33.307 ±0.237 |

The entrypoint interval includes Goose initialization, host output callbacks and any lazy JIT work. It excludes final Wasm-host output concatenation/delivery. Native Goose prints unbuffered, so no native entrypoint column or cross-boundary speedup is presented. Process time minus engine time also includes loading, bookkeeping and teardown; it is not a pure startup measurement.

These fresh-process examples have different timing rules from LangArena's warmed computational regions. Raw samples, commands, artifact/source/compiler identities and engine versions are in [report.json](report.json). [Method and reproduction](../../../examples.md).
