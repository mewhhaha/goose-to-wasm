# Example program benchmarks

Status: **passed**.

2026-11-07 · AMD Ryzen 7 3800X 8-Core Processor.

Goose O2. Direct Wasm uses memory32; Native C is emitted by the Goose compiler. The selected programs, their constant inputs and all printing are unchanged from the [example catalog](../../../../examples/README.md). Compiler constant folding is allowed.

Builds are complete uncached Python-driver invocations, including any C compilation/linking. OS page caches remain warm.

Runtime is **whole-process launch-to-exit time**, including host startup, Wasm compilation/instantiation, program initialization, computation, output delivery and teardown. Each observation starts a fresh process/instance and calls the entrypoint once. This measures CLI cost, not warmed kernel throughput.

Each cell has 5 build samples or 5 runtime samples. Untimed fresh-process warmups per runtime cell: 1. Orders are shuffled with the recorded seed; builds and runtime never overlap. Every used artifact must pass its golden output. Values are median milliseconds ± median absolute deviation (MAD).

Headline runtime samples use the ordinary runners without timing-file instrumentation. The Wasm supplements use a separate shuffled set of fresh processes, with the same sample count; timing files are written after their engine intervals end.

## Compilation

| Example | Direct Wasm | Goose Native C |
| --- | ---: | ---: |
| squares | 49.103 ±0.201 | 247.345 ±0.393 |
| tour | 61.726 ±0.150 | 884.230 ±2.084 |
| functions | 129.727 ±0.187 | 1588.754 ±5.173 |
| errors | 79.210 ±1.193 | 710.083 ±0.650 |
| sieve | 71.669 ±0.358 | 389.279 ±1.949 |
| sorting | 130.931 ±0.178 | 1803.809 ±1.705 |
| sudoku | 72.864 ±0.273 | 461.555 ±0.252 |
| maze | 86.610 ±0.422 | 712.247 ±2.512 |
| vm | 79.985 ±0.155 | 582.322 ±0.462 |
| life | 74.166 ±0.294 | 514.744 ±0.384 |

## Whole-process runtime

| Example | Direct / V8 | Direct / Wasmtime | Goose Native C |
| --- | ---: | ---: | ---: |
| squares | 24.548 ±0.465 | 68.016 ±0.150 | 0.788 ±0.019 |
| tour | 55.478 ±1.506 | 124.219 ±0.211 | 0.757 ±0.013 |
| functions | 58.642 ±0.271 | 244.657 ±0.313 | 0.911 ±0.011 |
| errors | 30.619 ±0.605 | 101.799 ±0.151 | 0.741 ±0.007 |
| sieve | 59.191 ±0.148 | 89.658 ±0.177 | 1.933 ±0.009 |
| sorting | 395.669 ±2.481 | 379.647 ±0.549 | 113.916 ±0.063 |
| sudoku | 45.765 ±0.159 | 95.116 ±0.292 | 8.705 ±0.057 |
| maze | 49.788 ±1.189 | 150.193 ±0.063 | 0.870 ±0.098 |
| vm | 58.905 ±0.135 | 138.721 ±0.599 | 0.900 ±0.018 |
| life | 64.085 ±0.448 | 124.539 ±0.168 | 20.674 ±0.095 |

## Supplement: Wasm entrypoint

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.188 ±0.002 | 0.116 ±0.001 |
| tour | 24.571 ±0.194 | 1.033 ±0.011 |
| functions | 26.558 ±0.042 | 1.000 ±0.001 |
| errors | 4.012 ±0.013 | 0.814 ±0.001 |
| sieve | 17.615 ±0.094 | 2.030 ±0.013 |
| sorting | 367.341 ±1.144 | 163.168 ±0.681 |
| sudoku | 19.339 ±0.163 | 11.584 ±0.058 |
| maze | 21.748 ±0.374 | 0.762 ±0.001 |
| vm | 28.088 ±0.207 | 0.898 ±0.005 |
| life | 37.303 ±0.034 | 27.135 ±0.076 |

## Supplement: Wasm engine compilation and instantiation

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.277 ±0.032 | 4.039 ±0.007 |
| tour | 0.535 ±0.016 | 58.162 ±0.078 |
| functions | 1.088 ±0.003 | 178.556 ±0.640 |
| errors | 0.480 ±0.029 | 36.889 ±0.016 |
| sieve | 0.404 ±0.027 | 23.082 ±0.120 |
| sorting | 1.083 ±0.002 | 151.269 ±0.077 |
| sudoku | 0.362 ±0.023 | 19.786 ±0.033 |
| maze | 0.670 ±0.008 | 84.604 ±0.038 |
| vm | 0.578 ±0.015 | 72.801 ±0.409 |
| life | 0.398 ±0.007 | 32.999 ±0.084 |

The entrypoint interval includes Goose initialization, host output callbacks and any lazy JIT work. It excludes final Wasm-host output concatenation/delivery. Native Goose prints unbuffered, so no native entrypoint column or cross-boundary speedup is presented. Process time minus engine time also includes loading, bookkeeping and teardown; it is not a pure startup measurement.

These fresh-process examples have different timing rules from LangArena's warmed computational regions. Raw samples, commands, artifact/source/compiler identities and engine versions are in [report.json](report.json). [Method and reproduction](../../../examples.md).
