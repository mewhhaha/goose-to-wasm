# Example program benchmarks

Status: **passed**.

2026-11-07 · AMD Ryzen 7 3800X 8-Core Processor.

Goose O2. Direct Wasm uses memory32; Native C is emitted by the Goose compiler. The selected programs, their constant inputs and all printing are unchanged from the [example catalog](../../../../examples/README.md). Compiler constant folding is allowed.

Builds are complete uncached Python-driver invocations, including any C compilation/linking. OS page caches remain warm.

Runtime is **whole-process launch-to-exit time**, including host startup, Wasm compilation/instantiation, program initialization, computation, output delivery and teardown. Each observation starts a fresh process/instance and calls the entrypoint once. This measures CLI cost, not warmed kernel throughput.

Each cell has 5 build samples or 5 runtime samples. Untimed fresh-process warmups per runtime cell: 1. Orders are shuffled with the recorded seed; builds and runtime never overlap. Every used artifact must pass its golden output. Values are median milliseconds ± median absolute deviation (MAD).

Headline runtime samples use the ordinary runners without timing-file instrumentation. The Wasm supplements use a separate shuffled set of fresh processes, with the same sample count; timing files are written after their engine intervals end.

## Compilation

| Example | Direct Wasm | Goose Native C |
| --- | ---: | ---: |
| squares | 50.280 ±0.519 | 251.287 ±1.136 |
| tour | 62.204 ±0.105 | 934.883 ±32.300 |
| functions | 132.059 ±0.504 | 1625.215 ±6.100 |
| errors | 80.014 ±0.388 | 722.044 ±2.256 |
| sieve | 72.556 ±0.034 | 405.033 ±11.271 |
| sorting | 133.063 ±0.522 | 1844.216 ±6.383 |
| sudoku | 73.454 ±0.181 | 469.827 ±1.159 |
| maze | 87.425 ±0.136 | 722.975 ±1.156 |
| vm | 81.320 ±0.469 | 592.132 ±1.261 |
| life | 75.711 ±0.550 | 524.305 ±1.101 |

## Whole-process runtime

| Example | Direct / V8 | Direct / Wasmtime | Goose Native C |
| --- | ---: | ---: | ---: |
| squares | 27.242 ±1.074 | 73.073 ±2.097 | 0.826 ±0.046 |
| tour | 56.669 ±0.854 | 126.776 ±0.769 | 0.782 ±0.018 |
| functions | 59.671 ±1.309 | 249.396 ±0.582 | 0.939 ±0.011 |
| errors | 31.709 ±0.664 | 110.635 ±0.569 | 0.750 ±0.016 |
| sieve | 58.991 ±0.542 | 96.233 ±1.091 | 1.981 ±0.035 |
| sorting | 417.990 ±15.288 | 409.640 ±2.517 | 116.764 ±0.118 |
| sudoku | 47.047 ±2.997 | 97.656 ±0.875 | 9.164 ±0.063 |
| maze | 52.479 ±0.165 | 162.757 ±1.868 | 0.903 ±0.040 |
| vm | 59.814 ±1.305 | 145.962 ±5.403 | 0.900 ±0.012 |
| life | 65.806 ±1.140 | 135.400 ±0.530 | 21.180 ±0.080 |

## Supplement: Wasm entrypoint

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.204 ±0.001 | 0.137 ±0.002 |
| tour | 25.390 ±0.232 | 1.086 ±0.009 |
| functions | 27.421 ±0.082 | 1.048 ±0.003 |
| errors | 4.401 ±0.044 | 0.861 ±0.002 |
| sieve | 17.528 ±0.249 | 2.158 ±0.002 |
| sorting | 386.492 ±1.893 | 175.161 ±0.122 |
| sudoku | 19.016 ±0.195 | 12.414 ±0.059 |
| maze | 22.812 ±0.232 | 0.799 ±0.005 |
| vm | 28.888 ±0.331 | 0.943 ±0.007 |
| life | 40.143 ±0.319 | 28.981 ±0.070 |

## Supplement: Wasm engine compilation and instantiation

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.267 ±0.010 | 4.479 ±0.041 |
| tour | 0.552 ±0.020 | 62.643 ±0.013 |
| functions | 1.143 ±0.013 | 192.579 ±0.310 |
| errors | 0.488 ±0.015 | 39.419 ±0.043 |
| sieve | 0.466 ±0.029 | 24.885 ±0.047 |
| sorting | 1.175 ±0.023 | 163.675 ±0.267 |
| sudoku | 0.363 ±0.011 | 21.263 ±0.124 |
| maze | 0.770 ±0.064 | 92.093 ±0.418 |
| vm | 0.665 ±0.033 | 78.931 ±0.082 |
| life | 0.446 ±0.026 | 35.695 ±0.319 |

The entrypoint interval includes Goose initialization, host output callbacks and any lazy JIT work. It excludes final Wasm-host output concatenation/delivery. Native Goose prints unbuffered, so no native entrypoint column or cross-boundary speedup is presented. Process time minus engine time also includes loading, bookkeeping and teardown; it is not a pure startup measurement.

These fresh-process examples have different timing rules from LangArena's warmed computational regions. Raw samples, commands, artifact/source/compiler identities and engine versions are in [report.json](report.json). [Method and reproduction](../../../examples.md).
