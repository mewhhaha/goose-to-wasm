# Example program benchmarks

Status: **passed**.

2026-11-07 · AMD Ryzen 7 3800X 8-Core Processor.

Goose O2. Direct Wasm uses memory32; Native C is emitted by the Goose compiler. The selected programs, their constant inputs and all printing are unchanged from the [example catalog](../../../../examples/README.md). Compiler constant folding is allowed.

Builds are complete uncached Python-driver invocations, including any C compilation/linking. OS page caches remain warm.

Runtime is **whole-process launch-to-exit time**, including host startup, Wasm compilation/instantiation, program initialization, computation, output delivery and teardown. Each observation starts a fresh process/instance and calls the entrypoint once. This measures CLI cost, not warmed kernel throughput.

Each cell has 5 build samples or 5 runtime samples. Untimed fresh-process warmups per runtime cell: 1. Orders are shuffled with the recorded seed; builds and runtime never overlap. Every used artifact must pass its golden output. Values are median milliseconds ± median absolute deviation (MAD).

Headline runtime samples use the ordinary runners without timing-file instrumentation. The Wasm supplements use a separate shuffled set of fresh processes, with the same sample count; timing files are written after their engine intervals end.

## Compilation

| Example | Direct Wasm | Goose Native C |
| --- | ---: | ---: |
| squares | 49.239 ±0.132 | 248.205 ±0.980 |
| tour | 61.349 ±0.095 | 885.917 ±3.028 |
| functions | 130.295 ±1.470 | 1582.560 ±0.903 |
| errors | 82.209 ±0.061 | 799.511 ±0.518 |
| sieve | 71.506 ±0.162 | 387.222 ±0.220 |
| sorting | 130.602 ±0.100 | 1806.533 ±1.604 |
| sudoku | 72.674 ±0.122 | 460.088 ±0.531 |
| maze | 85.845 ±0.159 | 709.394 ±0.547 |
| vm | 80.594 ±0.795 | 588.826 ±7.296 |
| life | 74.091 ±0.536 | 513.724 ±0.609 |

## Whole-process runtime

| Example | Direct / V8 | Direct / Wasmtime | Goose Native C |
| --- | ---: | ---: | ---: |
| squares | 26.170 ±0.301 | 67.956 ±0.119 | 0.803 ±0.017 |
| tour | 55.160 ±0.843 | 124.740 ±0.625 | 0.812 ±0.046 |
| functions | 57.452 ±0.757 | 244.928 ±0.837 | 0.903 ±0.012 |
| errors | 33.020 ±0.153 | 119.446 ±0.751 | 0.736 ±0.003 |
| sieve | 60.010 ±0.655 | 90.290 ±0.745 | 1.949 ±0.008 |
| sorting | 399.479 ±4.418 | 388.046 ±9.511 | 115.540 ±0.617 |
| sudoku | 47.858 ±1.166 | 95.640 ±0.626 | 8.787 ±0.097 |
| maze | 50.594 ±0.338 | 150.145 ±0.456 | 0.772 ±0.018 |
| vm | 58.495 ±1.034 | 138.737 ±0.747 | 0.907 ±0.025 |
| life | 65.378 ±0.640 | 124.794 ±0.182 | 20.667 ±0.035 |

## Supplement: Wasm entrypoint

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.185 ±0.001 | 0.117 ±0.001 |
| tour | 24.502 ±0.082 | 1.037 ±0.003 |
| functions | 26.942 ±0.392 | 1.005 ±0.003 |
| errors | 5.507 ±0.051 | 0.817 ±0.002 |
| sieve | 16.970 ±0.836 | 2.011 ±0.003 |
| sorting | 360.510 ±0.576 | 162.579 ±0.404 |
| sudoku | 19.317 ±0.093 | 11.527 ±0.003 |
| maze | 21.865 ±0.019 | 0.769 ±0.008 |
| vm | 27.855 ±0.074 | 0.892 ±0.000 |
| life | 37.562 ±0.246 | 27.121 ±0.043 |

## Supplement: Wasm engine compilation and instantiation

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.312 ±0.021 | 4.059 ±0.005 |
| tour | 0.540 ±0.008 | 57.824 ±0.020 |
| functions | 1.121 ±0.038 | 177.659 ±0.151 |
| errors | 0.556 ±0.008 | 53.846 ±0.029 |
| sieve | 0.354 ±0.006 | 22.985 ±0.003 |
| sorting | 1.081 ±0.013 | 151.057 ±0.197 |
| sudoku | 0.342 ±0.003 | 19.710 ±0.016 |
| maze | 0.749 ±0.012 | 84.467 ±0.029 |
| vm | 0.577 ±0.004 | 72.207 ±0.070 |
| life | 0.414 ±0.009 | 32.847 ±0.021 |

The entrypoint interval includes Goose initialization, host output callbacks and any lazy JIT work. It excludes final Wasm-host output concatenation/delivery. Native Goose prints unbuffered, so no native entrypoint column or cross-boundary speedup is presented. Process time minus engine time also includes loading, bookkeeping and teardown; it is not a pure startup measurement.

These fresh-process examples have different timing rules from LangArena's warmed computational regions. Raw samples, commands, artifact/source/compiler identities and engine versions are in [report.json](report.json). [Method and reproduction](../../../examples.md).
