# Example program benchmarks

Status: **passed**.

2026-11-07 · AMD Ryzen 7 3800X 8-Core Processor.

Goose O2. Direct Wasm uses memory32; Native C is emitted by the Goose compiler. The selected programs, their constant inputs and all printing are unchanged from the [example catalog](../../../../examples/README.md). Compiler constant folding is allowed.

Builds are complete uncached Python-driver invocations, including any C compilation/linking. OS page caches remain warm.

Runtime is **whole-process launch-to-exit time**, including host startup, Wasm compilation/instantiation, program initialization, computation, output delivery and teardown. Each observation starts a fresh process/instance and calls the entrypoint once. This measures CLI cost, not warmed kernel throughput.

Each cell has 5 build samples or 5 runtime samples. Untimed fresh-process warmups per runtime cell: 1. Orders are shuffled with the recorded seed; builds and runtime never overlap. Every used artifact must pass its golden output. Values are median milliseconds ± median absolute deviation (MAD).

Headline runtime samples use the ordinary runners without timing-file instrumentation. The Wasm supplements use a separate shuffled set of fresh processes, with the same sample count; timing files are written after their engine intervals end.

## Compilation

| Example | Direct Wasm | Goose Native C |
| --- | ---: | ---: |
| squares | 52.806 ±0.154 | 264.187 ±3.673 |
| tour | 65.400 ±1.267 | 961.533 ±7.616 |
| functions | 137.569 ±0.894 | 1704.153 ±3.519 |
| errors | 83.962 ±0.484 | 771.055 ±1.132 |
| sieve | 76.560 ±2.909 | 397.300 ±3.834 |
| sorting | 139.134 ±1.047 | 1950.149 ±56.565 |
| sudoku | 77.733 ±0.687 | 494.626 ±4.497 |
| maze | 91.868 ±0.261 | 764.773 ±3.894 |
| vm | 84.742 ±0.401 | 629.611 ±1.586 |
| life | 79.067 ±0.092 | 523.944 ±1.133 |

## Whole-process runtime

| Example | Direct / V8 | Direct / Wasmtime | Goose Native C |
| --- | ---: | ---: | ---: |
| squares | 27.178 ±1.455 | 68.926 ±0.117 | 0.816 ±0.016 |
| tour | 56.634 ±0.622 | 126.185 ±0.198 | 0.785 ±0.028 |
| functions | 59.864 ±0.967 | 250.573 ±1.540 | 0.900 ±0.008 |
| errors | 31.312 ±0.890 | 103.836 ±0.361 | 0.746 ±0.007 |
| sieve | 60.391 ±0.549 | 90.843 ±0.357 | 1.963 ±0.014 |
| sorting | 405.584 ±2.421 | 390.648 ±0.777 | 117.359 ±0.451 |
| sudoku | 45.906 ±1.053 | 97.133 ±0.177 | 8.845 ±0.109 |
| maze | 50.790 ±1.082 | 153.746 ±0.442 | 0.784 ±0.019 |
| vm | 60.495 ±0.667 | 140.963 ±0.283 | 0.899 ±0.010 |
| life | 66.342 ±0.210 | 126.972 ±0.276 | 20.903 ±0.075 |

## Supplement: Wasm entrypoint

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.186 ±0.001 | 0.123 ±0.002 |
| tour | 25.007 ±0.090 | 1.056 ±0.005 |
| functions | 26.915 ±0.081 | 1.015 ±0.011 |
| errors | 4.052 ±0.018 | 0.860 ±0.005 |
| sieve | 16.325 ±0.140 | 2.052 ±0.010 |
| sorting | 371.628 ±1.015 | 183.284 ±13.704 |
| sudoku | 19.614 ±0.099 | 11.970 ±0.038 |
| maze | 22.180 ±0.166 | 0.775 ±0.006 |
| vm | 28.488 ±0.133 | 0.915 ±0.006 |
| life | 38.099 ±0.463 | 27.955 ±0.018 |

## Supplement: Wasm engine compilation and instantiation

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.259 ±0.003 | 4.218 ±0.011 |
| tour | 0.541 ±0.035 | 59.173 ±0.052 |
| functions | 1.099 ±0.014 | 182.455 ±0.715 |
| errors | 0.461 ±0.004 | 37.729 ±0.133 |
| sieve | 0.355 ±0.005 | 23.414 ±0.024 |
| sorting | 1.114 ±0.018 | 154.789 ±0.446 |
| sudoku | 0.410 ±0.019 | 20.089 ±0.020 |
| maze | 0.749 ±0.019 | 86.690 ±0.100 |
| vm | 0.618 ±0.026 | 73.930 ±0.294 |
| life | 0.415 ±0.004 | 33.553 ±0.055 |

The entrypoint interval includes Goose initialization, host output callbacks and any lazy JIT work. It excludes final Wasm-host output concatenation/delivery. Native Goose prints unbuffered, so no native entrypoint column or cross-boundary speedup is presented. Process time minus engine time also includes loading, bookkeeping and teardown; it is not a pure startup measurement.

These fresh-process examples have different timing rules from LangArena's warmed computational regions. Raw samples, commands, artifact/source/compiler identities and engine versions are in [report.json](report.json). [Method and reproduction](../../../examples.md).
