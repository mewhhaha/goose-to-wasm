# Example program benchmarks

Status: **passed**.

2026-11-07 · AMD Ryzen 7 3800X 8-Core Processor.

Goose O2. Direct Wasm uses memory32; Native C is emitted by the Goose compiler. The selected programs, their constant inputs and all printing are unchanged from the [example catalog](../../../../examples/README.md). Compiler constant folding is allowed.

Builds are complete uncached Python-driver invocations, including any C compilation/linking. OS page caches remain warm.

Runtime is **whole-process launch-to-exit time**, including host startup, Wasm compilation/instantiation, program initialization, computation, output delivery and teardown. Each observation starts a fresh process/instance and calls the entrypoint once. This measures CLI cost, not warmed kernel throughput.

Each cell has 5 build samples or 5 runtime samples. Untimed fresh-process warmups per runtime cell: 1. Orders are shuffled with the recorded seed; builds and runtime never overlap. Every used artifact must pass its golden output. Values are median milliseconds ± median absolute deviation (MAD).

Headline runtime samples use the ordinary runners without timing-file instrumentation. The Wasm supplements use a separate shuffled set of fresh processes, with the same sample count; timing files are written after their engine intervals end.

## Compilation

| Example | Direct Wasm | Goose Native C |
| --- | ---: | ---: |
| squares | 49.239 ±0.109 | 247.630 ±0.656 |
| tour | 62.335 ±0.732 | 888.147 ±1.344 |
| functions | 129.242 ±0.064 | 1589.591 ±1.451 |
| errors | 78.016 ±0.070 | 710.019 ±0.479 |
| sieve | 71.473 ±0.121 | 388.936 ±1.276 |
| sorting | 130.632 ±0.246 | 1810.749 ±3.348 |
| sudoku | 72.479 ±0.391 | 463.824 ±3.344 |
| maze | 85.922 ±0.415 | 711.066 ±0.624 |
| vm | 79.689 ±0.170 | 584.438 ±1.905 |
| life | 73.687 ±0.186 | 517.172 ±0.896 |

## Whole-process runtime

| Example | Direct / V8 | Direct / Wasmtime | Goose Native C |
| --- | ---: | ---: | ---: |
| squares | 24.574 ±0.222 | 68.136 ±0.105 | 0.789 ±0.004 |
| tour | 54.684 ±0.561 | 124.480 ±0.312 | 0.752 ±0.010 |
| functions | 58.497 ±0.795 | 245.269 ±0.147 | 0.891 ±0.008 |
| errors | 31.521 ±0.454 | 102.183 ±0.091 | 0.734 ±0.015 |
| sieve | 59.809 ±0.274 | 89.907 ±0.234 | 1.950 ±0.018 |
| sorting | 397.442 ±2.833 | 381.098 ±0.740 | 113.978 ±0.079 |
| sudoku | 47.765 ±0.898 | 95.437 ±0.126 | 8.801 ±0.079 |
| maze | 49.864 ±0.387 | 150.798 ±0.066 | 0.805 ±0.045 |
| vm | 57.946 ±0.097 | 139.994 ±0.388 | 0.898 ±0.021 |
| life | 64.364 ±0.595 | 124.996 ±0.015 | 20.814 ±0.137 |

## Supplement: Wasm entrypoint

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.187 ±0.003 | 0.123 ±0.005 |
| tour | 25.115 ±0.482 | 1.041 ±0.003 |
| functions | 26.598 ±0.139 | 1.011 ±0.005 |
| errors | 3.986 ±0.065 | 0.813 ±0.004 |
| sieve | 14.181 ±0.863 | 2.030 ±0.005 |
| sorting | 362.167 ±2.215 | 162.830 ±0.269 |
| sudoku | 19.323 ±0.065 | 11.670 ±0.057 |
| maze | 22.059 ±0.057 | 0.771 ±0.003 |
| vm | 28.071 ±0.055 | 0.900 ±0.004 |
| life | 37.378 ±0.190 | 27.138 ±0.023 |

## Supplement: Wasm engine compilation and instantiation

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.251 ±0.003 | 4.183 ±0.023 |
| tour | 0.582 ±0.017 | 58.165 ±0.066 |
| functions | 1.099 ±0.010 | 178.462 ±0.137 |
| errors | 0.472 ±0.027 | 37.031 ±0.014 |
| sieve | 0.353 ±0.004 | 23.132 ±0.039 |
| sorting | 1.082 ±0.007 | 151.594 ±0.142 |
| sudoku | 0.347 ±0.010 | 19.919 ±0.021 |
| maze | 0.721 ±0.026 | 84.800 ±0.031 |
| vm | 0.581 ±0.033 | 72.652 ±0.046 |
| life | 0.407 ±0.007 | 33.134 ±0.048 |

The entrypoint interval includes Goose initialization, host output callbacks and any lazy JIT work. It excludes final Wasm-host output concatenation/delivery. Native Goose prints unbuffered, so no native entrypoint column or cross-boundary speedup is presented. Process time minus engine time also includes loading, bookkeeping and teardown; it is not a pure startup measurement.

These fresh-process examples have different timing rules from LangArena's warmed computational regions. Raw samples, commands, artifact/source/compiler identities and engine versions are in [report.json](report.json). [Method and reproduction](../../../examples.md).
