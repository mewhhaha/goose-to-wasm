# Example program benchmarks

Status: **passed**.

2026-11-07 · AMD Ryzen 7 3800X 8-Core Processor.

Goose O2. Direct Wasm uses memory32; Native C is emitted by the Goose compiler. The selected programs, their constant inputs and all printing are unchanged from the [example catalog](../../../../examples/README.md). Compiler constant folding is allowed.

Builds are complete uncached Python-driver invocations, including any C compilation/linking. OS page caches remain warm.

Runtime is **whole-process launch-to-exit time**, including host startup, Wasm compilation/instantiation, program initialization, computation, output delivery and teardown. Each observation starts a fresh process/instance and calls the entrypoint once. This measures CLI cost, not warmed kernel throughput.

Each cell has 5 build samples or 5 runtime samples. Untimed fresh-process warmups per runtime cell: 1. Orders are shuffled with the recorded seed; builds and runtime never overlap. Every used artifact must pass its golden output. Values are median milliseconds ± median absolute deviation (MAD).

Headline runtime samples use the ordinary runners without timing-file instrumentation. The Wasm supplements use a separate shuffled set of fresh processes, with the same sample count; timing files are written after their engine intervals end.

## Compilation

| Example | Direct Wasm | Goose Native C |
| --- | ---: | ---: |
| squares | 49.154 ±0.110 | 247.476 ±0.302 |
| tour | 61.525 ±0.061 | 887.515 ±2.000 |
| functions | 129.211 ±0.154 | 1585.442 ±2.229 |
| errors | 78.361 ±0.142 | 712.453 ±1.526 |
| sieve | 71.574 ±0.091 | 389.700 ±0.363 |
| sorting | 130.781 ±0.343 | 1808.846 ±0.166 |
| sudoku | 72.688 ±0.056 | 462.373 ±0.675 |
| maze | 85.989 ±0.129 | 710.799 ±0.568 |
| vm | 79.773 ±0.136 | 582.074 ±0.186 |
| life | 74.286 ±0.124 | 516.144 ±0.122 |

## Whole-process runtime

| Example | Direct / V8 | Direct / Wasmtime | Goose Native C |
| --- | ---: | ---: | ---: |
| squares | 25.569 ±0.566 | 68.098 ±0.026 | 0.795 ±0.011 |
| tour | 55.849 ±0.244 | 124.803 ±0.589 | 0.762 ±0.020 |
| functions | 59.190 ±1.246 | 246.797 ±2.203 | 0.902 ±0.010 |
| errors | 31.187 ±0.591 | 102.638 ±0.281 | 0.744 ±0.002 |
| sieve | 60.946 ±1.813 | 89.738 ±0.373 | 1.934 ±0.015 |
| sorting | 395.784 ±2.328 | 378.559 ±0.184 | 113.583 ±0.163 |
| sudoku | 45.732 ±0.584 | 95.705 ±0.342 | 8.801 ±0.121 |
| maze | 50.132 ±1.238 | 151.502 ±0.550 | 0.799 ±0.040 |
| vm | 59.220 ±1.148 | 139.264 ±0.608 | 0.906 ±0.025 |
| life | 64.331 ±0.881 | 125.109 ±0.131 | 20.606 ±0.060 |

## Supplement: Wasm entrypoint

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.190 ±0.003 | 0.123 ±0.002 |
| tour | 24.523 ±0.036 | 1.038 ±0.003 |
| functions | 26.702 ±0.126 | 1.000 ±0.003 |
| errors | 4.001 ±0.067 | 0.822 ±0.002 |
| sieve | 15.186 ±1.349 | 2.019 ±0.001 |
| sorting | 359.703 ±0.896 | 161.336 ±0.359 |
| sudoku | 19.502 ±1.144 | 11.515 ±0.016 |
| maze | 22.040 ±0.004 | 0.767 ±0.001 |
| vm | 28.172 ±0.376 | 0.888 ±0.005 |
| life | 37.541 ±0.179 | 27.086 ±0.023 |

## Supplement: Wasm engine compilation and instantiation

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.254 ±0.002 | 4.160 ±0.013 |
| tour | 0.529 ±0.003 | 58.149 ±0.101 |
| functions | 1.177 ±0.024 | 178.155 ±0.016 |
| errors | 0.460 ±0.022 | 37.508 ±0.160 |
| sieve | 0.360 ±0.015 | 23.138 ±0.076 |
| sorting | 1.081 ±0.001 | 151.648 ±0.138 |
| sudoku | 0.337 ±0.004 | 20.139 ±0.033 |
| maze | 0.727 ±0.025 | 85.493 ±0.011 |
| vm | 0.567 ±0.004 | 72.628 ±0.115 |
| life | 0.405 ±0.013 | 32.977 ±0.007 |

The entrypoint interval includes Goose initialization, host output callbacks and any lazy JIT work. It excludes final Wasm-host output concatenation/delivery. Native Goose prints unbuffered, so no native entrypoint column or cross-boundary speedup is presented. Process time minus engine time also includes loading, bookkeeping and teardown; it is not a pure startup measurement.

These fresh-process examples have different timing rules from LangArena's warmed computational regions. Raw samples, commands, artifact/source/compiler identities and engine versions are in [report.json](report.json). [Method and reproduction](../../../examples.md).
