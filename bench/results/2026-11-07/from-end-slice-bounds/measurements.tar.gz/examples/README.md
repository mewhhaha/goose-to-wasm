# Example program benchmarks

Status: **passed**.

2026-11-07 · AMD Ryzen 7 3800X 8-Core Processor.

Goose O2. Direct Wasm uses memory32; Native C is emitted by the Goose compiler. The selected programs, their constant inputs and all printing are unchanged from the [example catalog](../../../../examples/README.md). Compiler constant folding is allowed.

Builds are complete uncached Python-driver invocations, including any C compilation/linking. OS page caches remain warm.

Runtime is **whole-process launch-to-exit time**, including host startup, Wasm compilation/instantiation, program initialization, computation, output delivery and teardown. Each observation starts a fresh process/instance and calls the entrypoint once. This measures CLI cost, not warmed kernel throughput.

Each cell has 5 build samples or 5 runtime samples. Untimed fresh-process warmups per runtime cell: 1. Orders are shuffled with the recorded seed; builds and runtime never overlap. Every used artifact must pass its golden output. Values are median milliseconds ± median absolute deviation (MAD).

Headline runtime samples use the ordinary runners without timing-file instrumentation. The Wasm supplements use a separate shuffled set of fresh processes, with the same sample count; timing files are written after their engine intervals end.

## Compilation

| Example | Direct Wasm | Goose Native C |
| --- | ---: | ---: |
| squares | 57.659 ±0.976 | 287.205 ±2.697 |
| tour | 71.146 ±0.493 | 1096.557 ±27.833 |
| functions | 149.453 ±2.777 | 1939.297 ±102.895 |
| errors | 89.689 ±1.163 | 895.431 ±51.348 |
| sieve | 81.956 ±0.780 | 452.228 ±3.697 |
| sorting | 152.089 ±3.890 | 2217.095 ±98.400 |
| sudoku | 83.313 ±0.811 | 538.213 ±4.211 |
| maze | 102.072 ±1.391 | 845.198 ±23.260 |
| vm | 91.414 ±0.856 | 822.919 ±105.588 |
| life | 85.206 ±0.729 | 680.754 ±82.692 |

## Whole-process runtime

| Example | Direct / V8 | Direct / Wasmtime | Goose Native C |
| --- | ---: | ---: | ---: |
| squares | 28.453 ±0.715 | 77.582 ±1.970 | 0.838 ±0.003 |
| tour | 60.199 ±0.528 | 144.190 ±2.232 | 0.969 ±0.053 |
| functions | 64.324 ±1.467 | 285.990 ±12.107 | 1.053 ±0.040 |
| errors | 33.647 ±1.327 | 117.038 ±5.178 | 0.896 ±0.040 |
| sieve | 67.279 ±1.369 | 104.052 ±4.405 | 2.122 ±0.016 |
| sorting | 446.579 ±0.808 | 455.338 ±17.555 | 127.990 ±0.296 |
| sudoku | 51.086 ±0.309 | 111.260 ±0.745 | 9.468 ±0.074 |
| maze | 54.042 ±0.959 | 169.195 ±3.309 | 0.941 ±0.081 |
| vm | 65.730 ±0.966 | 166.719 ±0.402 | 1.004 ±0.050 |
| life | 72.278 ±1.065 | 144.510 ±2.129 | 22.320 ±0.088 |

## Supplement: Wasm entrypoint

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.197 ±0.001 | 0.134 ±0.004 |
| tour | 25.871 ±0.278 | 1.115 ±0.007 |
| functions | 28.304 ±0.120 | 1.070 ±0.005 |
| errors | 4.346 ±0.013 | 0.890 ±0.009 |
| sieve | 17.499 ±0.340 | 2.225 ±0.006 |
| sorting | 397.669 ±0.270 | 179.554 ±0.142 |
| sudoku | 20.427 ±0.434 | 12.688 ±0.053 |
| maze | 23.379 ±0.225 | 0.807 ±0.001 |
| vm | 29.591 ±0.301 | 0.961 ±0.001 |
| life | 40.691 ±0.888 | 29.912 ±0.081 |

## Supplement: Wasm engine compilation and instantiation

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.274 ±0.024 | 4.439 ±0.032 |
| tour | 0.565 ±0.010 | 63.635 ±0.342 |
| functions | 1.178 ±0.019 | 195.727 ±0.489 |
| errors | 0.468 ±0.003 | 41.006 ±0.086 |
| sieve | 0.386 ±0.012 | 25.343 ±0.420 |
| sorting | 1.291 ±0.018 | 166.187 ±0.576 |
| sudoku | 0.377 ±0.025 | 21.983 ±0.070 |
| maze | 0.833 ±0.069 | 94.273 ±0.398 |
| vm | 0.624 ±0.026 | 79.835 ±0.511 |
| life | 0.436 ±0.020 | 36.244 ±0.094 |

The entrypoint interval includes Goose initialization, host output callbacks and any lazy JIT work. It excludes final Wasm-host output concatenation/delivery. Native Goose prints unbuffered, so no native entrypoint column or cross-boundary speedup is presented. Process time minus engine time also includes loading, bookkeeping and teardown; it is not a pure startup measurement.

These fresh-process examples have different timing rules from LangArena's warmed computational regions. Raw samples, commands, artifact/source/compiler identities and engine versions are in [report.json](report.json). [Method and reproduction](../../../examples.md).
