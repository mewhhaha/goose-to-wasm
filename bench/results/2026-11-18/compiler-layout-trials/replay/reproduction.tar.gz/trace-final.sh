#!/bin/bash
set -euo pipefail
root=$PWD
d=${REPLAY_STAGE:-$root/build/three-levers-replay}
old=${REPLAY_CONTROL:-$root/build/header-trial/reader/own}
proj=${REPLAY_PROJECT:-$root/build/six-hills-1118/selfhost-chart}/source
taskset -pc 5 $$ > /dev/null
ulimit -s 262144
mkdir "$d/probe-final"
cp -a "$old/source/." "$d/probe-final/"
python "$d/probe.py" "$d/probe-final"
cd "$d/probe-final"
"$old/emitter" selfhost/main.goose --stdlib stdlib --target native -O2 -o "$d/probe-final.c"
clang-23 -std=gnu11 -w -O0 "$d/probe-final.c" -lm -ldl -pthread -o "$d/goose-probe-final"
cd "$proj"
"$d/goose-probe-final" selfhost/main.goose --stdlib stdlib --target wasm-direct -O2 --wasm-memory64 --wasm-max-pages 262144 -o "$d/probed-output.wasm" >"$d/final.log"
cmp "$d/probed-output.wasm" "$d/expected.wasm"
