"""Build a single-use discovery certificate for the already-stamped non-read list."""
from pathlib import Path
import sys
path = Path(sys.argv[1]) / 'selfhost/checker_lifetimes.goose'
s = path.read_text()
def replace(old,new):
    global s
    assert s.count(old)==1, old
    s = s.replace(old,new)
replace('    first_exit: i64 = -1,','    first_exit: i64 = -1, replay_stamp: i64 = -1,')
replace('l.summaries[previous].walked = walked; l.summaries[previous].replayed = -1;', 'l.frames[frame].replay_stamp = -1;\n            l.summaries[previous].walked = walked; l.summaries[previous].replayed = -1;')
replace('l.frames[frame].last_summary = index; l.revision += 1;', 'l.frames[frame].replay_stamp = -1;\n                    l.frames[frame].last_summary = index; l.revision += 1;')
replace('    var complete = chain >= 0 && !others;', '''    // A hit in the chain table accounts for every read. Remember when the
    // non-read list also consisted entirely of stamps for this activation.
    // Replaying a different way, updating an entry, or appending invalidates it.
    var all_stamped = others && l.compact && at >= 0 && !l.frames[frame].active;
    let stamp = activation * 4294967296 + replay_epoch;
    if all_stamped && l.frames[frame].replay_stamp == stamp { return; }
    l.frames[frame].replay_stamp = -1;
    var complete = chain >= 0 && !others;''')
replace('            if s.kind == 3 && s.leaf >= 0 && life_leaf_offered_in(l, s.leaf as i64, activation, replay_epoch, stamp_chain) { at = s.after; continue; }\n        }\n        if quick', '            all_stamped = false;\n            if s.kind == 3 && s.leaf >= 0 && life_leaf_offered_in(l, s.leaf as i64, activation, replay_epoch, stamp_chain) { at = s.after; continue; }\n        }\n        if quick')
replace('    if complete && l.frames[frame].reads_version == version', '    if all_stamped { l.frames[frame].replay_stamp = stamp; }\n    if complete && l.frames[frame].reads_version == version')
path.write_text(s)
