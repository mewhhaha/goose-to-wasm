#!/usr/bin/env bash
# From repo root: bash PATH/TO/reproduce.sh EMPTY_STAGE [CONTROL_BUILD_STAGE] [FROZEN_PROJECT_STAGE]
set -euo pipefail
export REPLAY_STAGE=$(realpath -m "${1:?supply a fresh stage path}")
export REPLAY_CONTROL=$(realpath "${2:-build/header-trial/reader/own}")
export REPLAY_PROJECT=$(realpath "${3:-build/six-hills-1118/selfhost-chart}")
here=$(cd "$(dirname "$0")" && pwd)
mkdir "$REPLAY_STAGE"
cp "$here"/{candidate.py,probe.py,summarize.py,trial.sh,proof.sh,trace-final.sh} "$REPLAY_STAGE/"
if [[ -f build/performance-env.sh ]]; then source build/performance-env.sh; fi
bash "$REPLAY_STAGE/trial.sh"
bash "$REPLAY_STAGE/trace-final.sh"
bash "$REPLAY_STAGE/proof.sh"
taskset -c 5 python "$REPLAY_STAGE/summarize.py" "$REPLAY_STAGE"
