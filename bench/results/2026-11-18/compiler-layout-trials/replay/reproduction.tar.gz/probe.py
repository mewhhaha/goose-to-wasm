"""Annotate the frozen compiler's effect merges and replay calls in a scratch source tree."""
from pathlib import Path
import sys
src = Path(sys.argv[1]) / 'selfhost/checker_lifetimes.goose'
s = src.read_text()
def replace(old, new, count=1):
    global s
    assert s.count(old) == count, old
    s = s.replace(old, new)
replace('struct LifeFrame { function_node:', 'struct LifeFrame { probe_head: i64 = -1, probe_summary: i64 = 0, probe_effects: i64 = 0, function_node:')
for old in ['|| !life_equal(l, value_places, old_place) { l.revision += 1;',
            '|| !life_equal(l, place, value.place) { l.revision += 1;',
            'l.revision += 1; l.frames[frame].reads_version += 1;',
            'l.frames[frame].last_summary = index; l.revision += 1;']:
    replace(old, old.replace('l.revision += 1;', 'l.revision += 1; l.frames[frame].probe_summary += 1;'))
replace('l.frames[frame].last_effect = index;', 'l.frames[frame].last_effect = index; l.frames[frame].probe_effects += 1;')
replace('struct Lifetimes {', "struct ProbePair { caller: i64, phase: i64, destination: i64, next: i64 }\nstruct Lifetimes { probe_pairs: ProbePair[>..]&,")
replace('    var l = Lifetimes { parents:', '    var probe_pairs: ProbePair[>..] = [];\n    var l = Lifetimes { probe_pairs: probe_pairs, parents:')
replace('fn life_replay(p: Program&, l: Lifetimes&, frame: i64, summary:', 'fn life_replay(p: Program&, l: Lifetimes&, frame: i64, site: i64, destination: i64, summary:')
for old in ['target, l.discovery || back_edge, m, call', 'target', 'target, true']:
    count = 2 if old.endswith('true') else 1
    replace('life_replay(p, l, ' + old + ');', 'life_replay(p, l, ' + old.replace('target', 'target, call, destination') + ');', count)
r = s.index('fn life_replay(')
first = s.index('    var at =', r)
s = s[:first]+'''    var visits = 0; var applied = 0;
    let added = l.effects.len + l.summary_reads.len;
    let before_rev = l.revision; let version_in = l.frames[frame].probe_summary;
    let effect_in = l.frames[frame].probe_effects; let epoch_in = l.frames[frame].effect_epoch;
    var empty = l.frames[frame].first_effect < 0;
    if summary { empty = l.frames[frame].first_summary < 0 && (!l.compact || l.frames[frame].first_read < 0); }
'''+s[first:]
replace('let entry = read; let item: const LifeReadEntry&', 'visits += 1; let entry = read; let item: const LifeReadEntry&')
replace('            if memo { l.offer_count', '            applied += 1; if memo { l.offer_count')
replace('        passed = at; open = read >= 0;', '        visits += 1; passed = at; open = read >= 0;')
replace('        if effect.kind == 1 { life_shrink(p, l, effect.node, effect.value); }', '        applied += 1; if effect.kind == 1 { life_shrink(p, l, effect.node, effect.value); }')
end='    if complete && l.frames[frame].reads_version == version { life_chain_replay(l, chain, version); }'
replace(end, end+'''
    var phase = 0; if !l.discovery { phase += 1; } if !summary { phase += 2; }
    var flags = 0; if empty { flags += 1; } if others { flags += 2; } if m.count > 0 { flags += 4; }
    if l.frames[frame].active { flags += 8; } if l.reading_place != 0 { flags += 16; }
    if l.frames[frame].first_other < 0 { flags += 32; } if complete { flags += 64; }
    if l.compact { flags += 128; }
    var pair = l.frames[frame].probe_head;
    while pair >= 0 && (l.probe_pairs[pair].caller != l.frame || l.probe_pairs[pair].phase != phase) { pair = l.probe_pairs[pair].next; }
    var dest_change = -1;
    if pair < 0 {
        pair = l.probe_pairs.len;
        l.probe_pairs.push(ProbePair { caller: l.frame, phase: phase, destination: destination, next: l.frames[frame].probe_head });
        l.frames[frame].probe_head = pair;
    } else {
        dest_change = 0; if !life_equal(l, l.probe_pairs[pair].destination, destination) { dest_change = 1; }
        l.probe_pairs[pair].destination = destination;
    }
    print("EV ", phase, " ", l.frame, " ", frame, " ", version_in, " ", effect_in, " ", epoch_in, " ", l.frames[l.frame].context, " ", activation, " ", replay_epoch, " ", destination, " ", flags, " ", visits, " ", applied, " ", l.effects.len + l.summary_reads.len - added, " ", l.revision - before_rev, " ", site, " ", dest_change);
''')
old='    if p.diagnostics.len == 0 { life_export_provenance(p, l); life_refresh_named_results(p); }'
replace(old,old+'''
    for f, id in l.frames { if f.function_node >= 0 { print("FM ", id, " ", f.function_node, " ", token_text(p, p.nodes[f.function_node].token)); } }
''')
src.write_text(s)
