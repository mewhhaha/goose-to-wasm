#!/bin/bash
set -euo pipefail
repo=$PWD
d=${REPLAY_STAGE:-$repo/build/three-levers-replay}
old=${REPLAY_CONTROL:-$repo/build/header-trial/reader/own}
project=${REPLAY_PROJECT:-$repo/build/six-hills-1118/selfhost-chart}/source
neg=$repo/tests/fixtures/contracts/upstream-differential/harvest/private_snapshot_parameters/98f0101e11.goose
node=${REPLAY_NODE:-$(command -v node)}
taskset -pc 5 $$ > /dev/null
ulimit -s 262144
for label in control certificate; do
 src=$old/source
 if [[ $label == certificate ]]; then src=$d/candidate; fi
 tree=$d/proof-$label
 mkdir "$tree"
 cp -a "$src/." "$tree/"
 python bench/results/2026-11-17/lifetime-compact-reads/tools/logicalfp.py "$tree/selfhost" fingerprint
 python bench/results/2026-11-18/lifetime-exit-index/tools/exitfp.py "$tree/selfhost"
 if [[ $label == certificate ]]; then
   python - "$tree/selfhost/checker_lifetimes.goose" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]);s=p.read_text()
s=s.replace("fn life_replay(", "var replay_check_calls: i64 = 0; var replay_check_entries: i64 = 0; var replay_check_misses: i64 = 0;\nfn life_replay(")
old = "if all_stamped && l.frames[frame].replay_stamp == stamp { return; }"
assert s.count(old)==1
s=s.replace(old,"""if all_stamped && l.frames[frame].replay_stamp == stamp {
        replay_check_calls += 1;
        var scan = at;
        while scan >= 0 {
            replay_check_entries += 1;
            let cs: const LifeSummary& = l.summaries[scan];
            if cs.replayed != into || cs.replayed_epoch != epoch { replay_check_misses += 1; }
            scan = cs.other;
        }
        return;
    }""")
old = "    if p.diagnostics.len == 0 { life_export_provenance"
assert s.count(old)==1
s=s.replace(old, '    print("CERT ", replay_check_calls, " ", replay_check_entries, " ", replay_check_misses);\n'+old)
p.write_text(s)
PY
 fi
 (cd "$tree" && "$old/emitter" selfhost/main.goose --stdlib stdlib --target wasm-direct -O2 --wasm-memory64 --wasm-max-pages 262144 -o "$d/$label-proof.wasm")
 (cd "$project" && "$node" --stack-size=65500 "$repo/scripts/run_wasm.mjs" "$d/$label-proof.wasm" -- selfhost/main.goose --stdlib stdlib --check >"$d/$label-fp.out" 2>"$d/$label-fp.err")
 bin=$d/replay.wasm
 if [[ $label == control ]]; then bin=$old/build-1/compiler.wasm; fi
 set +e
 (cd "$project" && "$node" --stack-size=65500 "$repo/scripts/run_wasm.mjs" "$bin" -- "$neg" --stdlib stdlib --check >"$d/$label-negative.out" 2>"$d/$label-negative.err")
 status=$?
 set -e
 [[ $status == 1 ]]
done
cmp "$d/control-fp.err" "$d/certificate-fp.err"
cmp "$d/control-negative.out" "$d/certificate-negative.out"
cmp "$d/control-negative.err" "$d/certificate-negative.err"
cat "$d/certificate-fp.out"
