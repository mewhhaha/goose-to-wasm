#!/bin/bash
set -euo pipefail
root=$PWD
d=${REPLAY_STAGE:-$root/build/three-levers-replay}
old=${REPLAY_CONTROL:-$root/build/header-trial/reader/own}
project=${REPLAY_PROJECT:-$root/build/six-hills-1118/selfhost-chart}
taskset -pc 5 $$ > /dev/null
ulimit -s 262144
mkdir "$d/candidate"
cp -a "$old/source/." "$d/candidate/"
python "$d/candidate.py" "$d/candidate"
src=selfhost/checker_lifetimes.goose
diff -u --label a/$src --label b/$src "$old/source/$src" "$d/candidate/$src" > "$d/replay.patch" || [[ $? -eq 1 ]]
(cd "$d/candidate" && "$old/emitter" selfhost/main.goose --stdlib stdlib --target wasm-direct -O2 --wasm-memory64 --wasm-max-pages 262144 -o "$d/replay.wasm")
(cd "$project/source" && "$old/build-1/compiler-native" selfhost/main.goose --stdlib stdlib --target wasm-direct -O2 --wasm-memory64 --wasm-max-pages 262144 -o "$d/expected.wasm")
export XDG_CACHE_HOME=$d/cache
"$root/.venv/bin/python" bench/results/2026-11-18/compiler-record-access/tools/compare.py "$project" "$d/paired.json" "control=$old/build-1/compiler.wasm" "certificate=$d/replay.wasm" --expected "control=$d/expected.wasm" --expected "certificate=$d/expected.wasm" --cpu 5 --rounds 3
