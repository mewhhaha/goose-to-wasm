"""Summarize the frozen compiler's replay trace; preserve all caller/callee frame counts."""
from collections import Counter, defaultdict
from pathlib import Path
import gzip, hashlib, json, os, statistics, sys
d = Path(sys.argv[1])
root = Path.cwd()
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def write(name, value):
    (d / name).write_text(json.dumps(value, indent=2) + '\n')
def stats():
    return defaultdict(Counter)
counts = defaultdict(stats)
pairs = defaultdict(stats)
functions = {0: (-1, '<globals>')}
prev = {}
witnesses = []
for line in (d / 'final.log').open():
    kind, *fields = line.split()
    if kind == 'FM':
        frame, node = map(int, fields[:2])
        functions[frame] = (node, ' '.join(fields[2:]))
        continue
    assert kind == 'EV'
    phase, caller, callee, version, effect_version, generation, context, activation, epoch, dest, flags, visits, applied, additions, revisions, call, dest_change = map(int, fields)
    key = phase, caller, callee
    old = prev.get(key)
    observed = version if phase < 2 else (effect_version, generation)
    label = 'first'
    if old:
        label = 'stable'
        if old[0] != observed:
            label = 'changed'
            if phase >= 2 and old[0][1] != generation:
                label = 'new_effect_list_generation'
        assert dest_change != -1
    else:
        assert dest_change == -1
    row = counts[phase][label]
    row['calls'] += 1
    row['visited_entries'] += visits
    row['reached_application'] += applied
    row['added_records'] += additions
    row['global_revision_delta'] += revisions
    row['calls_applying_entries'] += bool(applied)
    row['calls_changing_revision_or_adding_records'] += bool(revisions or additions)
    row['empty'] += bool(flags & 1)
    row['chain_hits'] += bool(flags & 2)
    row['mapped'] += bool(flags & 4)
    row['active_callee'] += bool(flags & 8)
    if old:
        row['changed_caller_chain'] += context != old[1]
        row['changed_caller_activation'] += activation != old[2]
        row['changed_recursion_epoch'] += epoch != old[3]
        row['changed_semantic_destination'] += dest_change
        row['changed_call_site'] += call != old[4]
        row['changed_chain_activation_epoch_or_destination'] += (context, activation, epoch) != old[1:4] or dest_change
    if phase == 1 and label == 'stable' and (additions or revisions):
        witnesses.append(dict(caller_frame=caller,callee_frame=callee,added_records=additions,
                              visits=visits, site=call, previous_site=old[4], changed_destination=bool(dest_change),
                              changed_activation=activation != old[2], changed_epoch=epoch != old[3], active_callee=bool(flags&8)))
    prev[key] = observed, context, activation, epoch, call
    pair = pairs[key][label]
    for field, value in [('calls', 1), ('visited_entries', visits), ('reached_application', applied), ('added_records', additions), ('global_revision_delta', revisions)]:
        pair[field] += value
assert 0 in counts and 1 in counts and 3 in counts and len(functions) > 1, 'incomplete self-host trace'
assert sum(row['calls'] for phase in counts.values() for row in phase.values()) == 151103, 'frozen workload replay count changed'
by_function = defaultdict(stats)
for (phase, caller, callee), states in pairs.items():
    for label, sums in states.items():
        counts[phase][label]['distinct_frame_pairs'] += 1
        if phase == 0:
            by_function[functions[caller], functions[callee]][label].update(sums)
family = Counter()
for (p,u,f), states in pairs.items():
    if p == 0:
        family['+'.join(sorted(set(states) - {'first'})) or 'no_revisit'] += 1
result = {'phases': {label: counts[key] for key,label in [(0,'discovery_summary'), (1,'validation_summary'), (3,'validation_effect_list')]},
          'discovery_pairs_by_type_of_revisit':family}
for witness in witnesses:
    witness['caller'] = functions[witness['caller_frame']][1]
    witness['callee'] = functions[witness['callee_frame']][1]
result['validation_unchanged_productive_witnesses'] = witnesses
for state in ['stable', 'changed']:
    top = sorted(by_function, key=lambda k:-by_function[k][state]['visited_entries'])[:10]
    result['top_discovery_function_edges_' + state] = [dict(caller=u[1], caller_node=u[0], callee=v[1], callee_node=v[0], **by_function[u,v][state]) for u,v in top]
packed = {'phase_ids': {'0':'discovery_summary', '1':'validation_summary', '3':'validation_effect_list'}, 'frames':functions, 'pairs':[
    [phase, caller, callee, states] for (phase,caller,callee), states in sorted(pairs.items())]}
(d / 'frame-pairs.json.gz').write_bytes(gzip.compress(json.dumps(packed,separators=(',', ':')).encode(),mtime=0))
stage = Path(os.getenv('REPLAY_CONTROL', root / 'build/header-trial/reader/own'))
trial = json.loads((d/'paired.json').read_text())
assert len(trial['samples']) == 12
summary = {}
for mode in ['check', 'emit']:
    summary[mode] = {}
    for label in ['control','certificate']:
        rows = [r for r in trial['samples'] if r['mode'] == mode and r['label'] == label]
        summary[mode][label] = {field:statistics.median([r[field] for r in rows]) for field in ['cpu_ns', 'wall_ns']}
        summary[mode][label]['instructions'] = statistics.median([r['counters']['instructions']['value'] for r in rows])
    summary[mode]['delta_percent'] = {field:100*(summary[mode]['certificate'][field]/summary[mode]['control'][field]-1) for field in ['cpu_ns','wall_ns','instructions']}
proof = (d/'certificate-fp.err').read_bytes()
assert proof == (d/'control-fp.err').read_bytes()
hits, entries, misses = map(int,(d/'certificate-fp.out').read_text().strip().split()[1:])
assert misses == 0
negative = (d/'certificate-negative.err').read_bytes()
assert negative == (d/'control-negative.err').read_bytes() and negative
assert sha(d/'expected.wasm') == sha(d/'probed-output.wasm')
result.update({'trial_medians':summary, 'certificate_shadow':dict(hits=hits,checked_non_read_entries=entries,stamp_mismatches=misses), 'proof':dict(
    logical_fingerprints=proof.count(b'LIFEFP '),logical_fingerprints_sha256=sha(d/'control-fp.err'),
    negative_exit=1,negative_stderr_sha256=sha(d/'control-negative.err'),
    emitted_bytes=(d/'expected.wasm').stat().st_size,emitted_sha256=sha(d/'expected.wasm')),
    'pins':dict(compiler_commit=json.loads((stage/'builds.json').read_text())['source_commit'],
    compiler_archive=json.loads((stage/'builds.json').read_text())['source_archive_sha256'],
    emitter=sha(stage/'emitter'), control_native=sha(stage/'build-1/compiler-native'),
    workload_commit=trial['workload'],workload_archive=trial['archive_sha256'],
    control_wasm=sha(stage/'build-1/compiler.wasm'), candidate_wasm=sha(d/'replay.wasm'),
    counts_source=sha(d/'probe-final/selfhost/checker_lifetimes.goose'), counts_native=sha(d/'goose-probe-final'),
    patch=sha(d/'replay.patch'), counts_trace=sha(d/'final.log'), cpu=trial['cpu'], wasmtime=trial['wasmtime'],engine=trial['engine'],
    native_probe_cc='clang-23 -O0 -std=gnu11',fingerprint_engine='Node 24.22.1 / V8 13.6.233.17-node.58 --stack-size=65500')})
write('evidence.json', result)
