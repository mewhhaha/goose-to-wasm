from cases import *
BUNDLE=['--wasm-bundled-host','--wasm-initial-pages','65535','--wasm-max-pages','65535','--wasm-region-profile',B/'final/training.profile']
src=B/'final-own/source'
work=B/'deployment-checks'
work.mkdir(exist_ok=True)
os.sched_setaffinity(0,{2})
resource.setrlimit(resource.RLIMIT_STACK,(256<<20,resource.getrlimit(resource.RLIMIT_STACK)[1]))
results={}
for name in ['final-fixed','final-o3','final-o4']:
    command=[H,B/name/'compiler.wasm','--cache',work/(name+'.cwasm'),'--']
    subprocess.run([*command,'--version'],stdout=subprocess.DEVNULL,cwd=src,check=True)
    cells={}
    for case in sorted((B/'holder-cases').glob('*.goose')):
        p=subprocess.run([*command,case,'--check'],capture_output=True,cwd=src,timeout=40)
        cells[case.name]={'status':p.returncode,'stdout':p.stdout.decode(),'stderr':p.stderr.decode().replace(str(case.parent)+'/','')}
        assert (p.returncode!=0)==(case.stem in ['nested','changed'])
    out=work/(name+'-emitted.wasm')
    subprocess.run([*command,*source,'--target','wasm-direct','-O2',*BUNDLE,'-o',out],cwd=src,check=True)
    cells['self']=sha(out)
    assert cells['self']==sha(B/'final-fixed/compiler.wasm')
    if results: assert cells==next(iter(results.values()))
    results[name]=cells
d=R/'bench/results/2026-11-18/compiler-frame-cost'
(d/'deployment-checks.json').write_text(json.dumps(dict(cases=results,optimizer=subprocess.check_output(['wasm-opt','--version'],text=True).strip(),tool_sha256=sha(Path(shutil.which('wasm-opt'))),preparation={s:json.loads((B/('final-'+s)/'cost.json').read_text()) for s in ['o3','o4']}),indent=2)+'\n')
