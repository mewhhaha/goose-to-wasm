from cases import *
from itertools import product
srcdir=B/'backend-work/stack/controls'
out=B/'release/controls';out.mkdir(exist_ok=True)
cases=[('stack',4,[1,4]),('stack-regions',4,[1,4])]
before=B/'backend-work/fixed-memory/safe-emitter.wasm'
# Use baseline native and qualified candidate native directly.
after=B/'release/compiler-native'
rows=[]
for name,maxpages,minimums in cases:
 for wide,minimum,level in product([False,True],minimums,[0,2]):
  stem=f'{name}-{wide}-{minimum}-{level}'
  args0=[str(srcdir/(name+'.goose')),'--stdlib',str(S/'stdlib'),'--target','wasm-direct',f'-O{level}','--wasm-initial-pages',str(minimum),'--wasm-max-pages',str(maxpages)]
  if wide:args0+=['--wasm-memory64']
  mods=[]
  for v,comp in [('previous',N),('current',after)]:
   mod=out/(stem+v+'.wasm')
   subprocess.run([comp,*args0,'-o',mod],cwd=R,check=True,capture_output=True);mods.append(mod)
  for depth in ['0','10','2000']:
   observations=[]
   for mod in mods:
    c=subprocess.run([H,mod,'--cache',mod.with_suffix('.cwasm')],cwd=R,input=(depth+'\n').encode(),capture_output=True,timeout=20)
    observations.append([c.returncode,c.stdout.decode(),c.stderr.decode()])
   assert observations[0]==observations[1],(stem,depth,observations)
   rows.append(dict(fixture=name,wide=wide,minimum=minimum,maximum=maxpages,optimization=level,depth=depth,result=observations[0]))
(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print('matched',len(rows))
