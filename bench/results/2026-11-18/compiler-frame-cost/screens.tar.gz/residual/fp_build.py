from cases import *
for name in sys.argv[1:]:
 d=B/'fingerprints'/name;src=d/'source'; src_parent=S if name=='base' else B/name/'source'
 shutil.copytree(src_parent,src,dirs_exist_ok=True); sh=src/'selfhost'; tools=R/'bench/results'
 subprocess.run([sys.executable,tools/'2026-11-17/lifetime-compact-reads/tools/logicalfp.py',sh,'fingerprint'],cwd=R,check=True)
 subprocess.run([sys.executable,tools/'2026-11-18/lifetime-exit-index/tools/exitfp.py',sh],cwd=R,check=True)
 reference=R/'build/header-trial/layout/local2-proof/candidate'; C=d/'probe.c'
 prior=reference/'selfhost'
 resource.setrlimit(resource.RLIMIT_STACK,(256<<20,resource.getrlimit(resource.RLIMIT_STACK)[1]))
 if name=='base' and all((prior/p.name).read_bytes()==p.read_bytes() for p in sh.glob('*.goose')):
  print('reusing identical instrumented sources',flush=True);(d/'probe').symlink_to(reference/'goose')
 else:
  subprocess.run([N,*source,'--target','native','-O2','-o',C],cwd=src,check=True)
  subprocess.run(['clang-23','-w','-O0','-std=gnu11',C,'-lm','-ldl','-pthread','-o',d/'probe'],check=True)
 for key,flags in [('self',[]),('class',['--class'])]:
  module=d/(key+'.wasm')
  if key=='class':
   p=sh/'checker_lifetimes.goose';s=p.read_text();old='LIFE_CONCRETE_FRAMES: i64 = 4096';assert old in s;p.write_text(s.replace(old,'LIFE_CONCRETE_FRAMES: i64 = 64'))
  subprocess.run([N,*emitted,'-o',module],cwd=src,check=True)
  case=R/'bench/results/2026-11-18/compiler-array-views/lifetime/class-exits.goose' if key=='class' else source[0]
  result=subprocess.run([H,module,'--cache',d/(key+'.cwasm'),'--',case,'--stdlib','stdlib','--target','native','--check'],cwd=S,capture_output=True)
  (d/(key+'.out')).write_bytes(result.stdout);(d/(key+'.err')).write_bytes(result.stderr);(d/(key+'.exit')).write_text(str(result.returncode)+'\n'); print(name,key,result.returncode,len(result.stderr.splitlines()),flush=True)
