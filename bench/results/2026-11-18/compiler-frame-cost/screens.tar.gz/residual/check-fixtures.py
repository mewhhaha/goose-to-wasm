from cases import *
from re import search
import itertools
d=B/'holder-cases'; rows=[]
for f in sorted(d.glob('*.goose')):
 cmdsets={'upstream':[R/'build/langbench-native/goose','check',f,'--stdlib',R/'build/langbench-goose-source/stdlib'],'previous':[N,f,'--check'],'candidate':[B/'release/compiler-native',f,'--check'],'shadow':[H,B/'release-shadow/wide.wasm','--cache',B/'release-shadow/wide.cwasm','--',f,'--check']}
 row={'name':f.name,'source':f.read_text(),'sha256':sha(f),'observations':{}}
 for key,cmd in cmdsets.items():
  p=subprocess.run(cmd,capture_output=True,timeout=20);row['observations'][key]=dict(status=p.returncode,diagnostics=p.stderr.decode().replace(str(d)+'/',''),stdout=p.stdout.decode().replace(str(d)+'/','')); assert bool(p.returncode)==(f.stem in ('changed','nested')),(key,f,row)
 assert row['observations']['previous']==row['observations']['candidate']
 rows.append(row)
(d/'controls.json').write_text(json.dumps({'upstream_sha256':sha(R/'build/langbench-native/goose'),'cases':rows},indent=2)+'\n')
