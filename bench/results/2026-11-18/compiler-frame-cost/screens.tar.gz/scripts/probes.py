from cases import *
d=B/'counter/source';shutil.copytree(S,d,dirs_exist_ok=True);p=d/'selfhost/checker_lifetimes.goose';s=p.read_text().replace('struct Lifetimes {','var pair_counts: i64[12];\nstruct Lifetimes {')
marker='    // Two cached pairs per bucket at most, on average.'
s=s.replace(marker,'''    pair_counts[0] += 1;
    if owner == pointee { pair_counts[1] += 1; }
    let tk = p.types[owner].kind;
    if tk != TY_ARRAY && tk != TY_ENUM && tk != TY_STRUCT && tk != TY_TUPLE { pair_counts[2] += 1; }
    if !l.types_frozen { pair_counts[3] += 1; }
'''+marker)
s=s.replace('        let q = l.pairs[pair];','        pair_counts[4] += 1; let q = l.pairs[pair];')
s=s.replace('if q.owner == owner && q.pointee == pointee { return q.answer; }','if q.owner == owner && q.pointee == pointee { if q.answer { pair_counts[5] += 1; } return q.answer; }')
s=s.replace('    if p.diagnostics.len == 0 { life_export_provenance','    pair_counts[6] = l.pairs.len; pair_counts[7] = l.pair_heads.len; print("pair_counts ", pair_counts);\n    if p.diagnostics.len == 0 { life_export_provenance')
p.write_text(s)
resource.setrlimit(resource.RLIMIT_STACK,(256<<20,resource.getrlimit(resource.RLIMIT_STACK)[1]))
m=B/'counter/wide.wasm';subprocess.run([N,*emitted,'-o',m],cwd=d,check=True);subprocess.run([H,m,'--cache',B/'counter/wide.cwasm','--',*source,'--check'],cwd=S,check=True)
