from cases import *
import argparse
a=argparse.ArgumentParser();a.add_argument('label');a.add_argument('frontend');a.add_argument('emitter',type=Path);a.add_argument('--pages',default='65535');a.add_argument('--profile',type=Path);z=a.parse_args()
d=B/z.label;d.mkdir(parents=True,exist_ok=True);stage=S if z.frontend=='base' else B/z.frontend/'source'; profile=z.profile or P
if not z.profile and z.frontend!='base' and (B/z.frontend/'training.profile').exists():profile=B/z.frontend/'training.profile'
emitter=z.emitter.resolve();cmd=[emitter]
if emitter.suffix=='.wasm':cmd=[H,emitter,'--cache',B/(sha(emitter)[:14]+'.cwasm'),'--']
subprocess.run([*cmd,*source,'--target','wasm-direct','-O2','--wasm-initial-pages',z.pages,'--wasm-max-pages','65535','--wasm-bundled-host','--wasm-region-profile',profile,'-o',compiler(z.label)],cwd=stage,check=True)
subprocess.run(args(z.label)+['--version'],cwd=S,check=True)
