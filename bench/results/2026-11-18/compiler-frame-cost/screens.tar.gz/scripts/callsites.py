from cases import *
import re
d=B/'callsites/source';shutil.copytree(S,d,dirs_exist_ok=True);p=d/'selfhost/checker_lifetimes.goose';s=p.read_text().replace('struct Lifetimes {','var site_hits: i64[48];\nstruct Lifetimes {')
sites=[]
def rep(m):
 sites.append((len(sites),s[:m.start()].count('\n')+1));return f'count_contains(p, l, {len(sites)-1}, '
s=re.sub(r'\blife_contains\(p, l, ',rep,s)
s=s.replace('fn life_contains(p:','fn count_contains(p: Program&, l: Lifetimes&, site: i64, owner: i64, pointee: i64) -> bool { site_hits[site] += 1; return life_contains(p, l, owner, pointee); }\nfn life_contains(p:').replace('    if p.diagnostics.len == 0 { life_export_provenance','    print("site_hits ", site_hits);\n    if p.diagnostics.len == 0 { life_export_provenance')
p.write_text(s);print(sites,flush=True)
resource.setrlimit(resource.RLIMIT_STACK,(256<<20,resource.getrlimit(resource.RLIMIT_STACK)[1]))
m=B/'callsites/wide.wasm';subprocess.run([N,*emitted,'-o',m],cwd=d,check=True);subprocess.run([H,m,'--cache',B/'callsites/wide.cwasm','--',*source,'--check'],cwd=S,check=True)
