from cases import *
cmd=['wasm-opt','--enable-bulk-memory','--enable-bulk-memory-opt','--enable-sign-ext','--enable-multivalue','--enable-nontrapping-float-to-int','--enable-simd','--enable-tail-call','-O3',compiler('release-fixed'),'-o',compiler('release-o3')]
t=time.monotonic();proc=subprocess.run(cmd,env=dict(os.environ,BINARYEN_CORES='3'),capture_output=True);rc=resource.getrusage(resource.RUSAGE_CHILDREN)
(B/'release-o3/cost.json').write_text(json.dumps(dict(wall_sec=time.monotonic()-t,cpu_sec=rc.ru_utime+rc.ru_stime,exit=proc.returncode,stderr=proc.stderr.decode()[:1000]),indent=2));proc.check_returncode();subprocess.run(args('release-o3')+['--version'],check=True)
