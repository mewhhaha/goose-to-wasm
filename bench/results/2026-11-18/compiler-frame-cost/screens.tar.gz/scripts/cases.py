from pathlib import Path
import os, sys, subprocess, shutil, resource, json, hashlib, time
R=Path(__file__).resolve().parents[2]; B=R/'build/life-parity'; S=R/'build/header-trial/reader/own/source'
N=S.parent/'build-1/compiler-native'; H=R/'host/rust/target/release/goose-wasmtime'; W=R/'build/compile-gap-trial/run1/bundled32.wasm'
P=R/'bench/results/2026-11-18/compiler-layout-trials/memory/training-root.profile'
source=['selfhost/main.goose','--stdlib','stdlib']; emitted=[*source,'--target','wasm-direct','-O2','--wasm-memory64','--wasm-max-pages','262144']
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def compiler(name):
 if name=='base':return W
 return B/name/'compiler.wasm'
def build(name):
 d=B/name; m=compiler(name)
 subprocess.run([N,*source,'--target','wasm-direct','-O2','--wasm-max-pages','65535','--wasm-region-profile',P,'--wasm-bundled-host','-o',m],cwd=d/'source',check=True)
def args(name):
 if name=='native':return [N]
 if name.startswith('native_'):return [B/name.removeprefix('native_')/'compiler-native']
 inline=name.endswith('_inline'); compact=name.endswith('_compact'); case=name.removesuffix('_inline').removesuffix('_compact'); host=H
 if inline:host=B/'host-inline'
 if compact:host=B/'host-compact'
 return [host,compiler(case),'--cache',B/(name+'.cwasm'),'--']
def run(name,mode):
 out=B/'emitted.wasm'; out.unlink(missing_ok=True)
 cmd=args(name)+([*emitted,'-o',out] if mode=='emit' else [*source,'--check'])
 before=resource.getrusage(resource.RUSAGE_CHILDREN);t=time.perf_counter();proc=subprocess.run(cmd,cwd=S,capture_output=True);wall=time.perf_counter()-t;after=resource.getrusage(resource.RUSAGE_CHILDREN)
 if proc.returncode:raise RuntimeError((str(cmd),proc.stderr.decode()[-2000:]))
 digest=sha(out) if mode=='emit' else None
 if digest:assert digest=='4a5a91997c4a8614484f23f44c07284c3d249d9d7274199d8be6a009ce7dde13',digest
 return dict(case=name,mode=mode,wall=wall,cpu=(after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime),sha256=digest)
if __name__=='__main__':
 resource.setrlimit(resource.RLIMIT_STACK,(256<<20,resource.getrlimit(resource.RLIMIT_STACK)[1]))
 op,*rest=sys.argv[1:]
 if op=='build':
  for n in rest: build(n)
 elif op=='warm':
  for n in rest: subprocess.run(args(n)+['--version'],cwd=S,check=True,stdout=subprocess.DEVNULL)
 elif op=='bench':
  dest,rounds,mode,*names=rest;os.sched_setaffinity(0,{7});rs=[]
  for i in range(int(rounds)):
   for n in (names if i%2==0 else names[::-1]):
    try:r=run(n,mode)
    except RuntimeError as err:r=dict(case=n,mode=mode,wall=-1,cpu=-1,error=str(err))
    r['round']=i;rs.append(r);print(i,n,round(r['wall'],3),round(r['cpu'],3),flush=True);(B/(dest+'.json')).write_text(json.dumps(rs,indent=2)+'\n')
