from cases import *
sys.path[:0]=[str(R/'scripts'),str(R/'bench/results/2026-11-18/selfhost-wasm-runtime/tools')]
from measure import measured
resource.setrlimit(resource.RLIMIT_STACK,(256<<20,resource.getrlimit(resource.RLIMIT_STACK)[1]))
out,rounds,*names=sys.argv[1:];result=[];os.sched_setaffinity(0,{7})
for i in range(int(rounds)):
 for n in (names if i%2==0 else names[::-1]):
  r={'round':i,'case':n}
  try:
   argv=args(n)+[*emitted,'-o',B/'count-out.wasm'];start=resource.getrusage(resource.RUSAGE_CHILDREN);(B/'count-out.wasm').unlink(missing_ok=True)
   proc,ns,counts=measured(lambda:subprocess.run(argv,cwd=S,capture_output=True),child=True);end=resource.getrusage(resource.RUSAGE_CHILDREN)
   assert proc.returncode==0,proc.stderr.decode()
   r.update(wall=ns/1e9,cpu=end.ru_utime+end.ru_stime-start.ru_utime-start.ru_stime,sha256=sha(B/'count-out.wasm'),counters=counts)
   assert r['sha256']==sha(S.parent/'build-1/compiler.wasm')
  except Exception as e:r['error']=repr(e)
  print(i,n,round(r.get('wall',0),3),round(r.get('counters',{}).get('instructions',{}).get('value',0)/1e9,3),str(r.get('error',''))[:130],flush=True)
  result.append(r);(B/(out+'.json')).write_text(json.dumps(result,indent=2)+'\n')
