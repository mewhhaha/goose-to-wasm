from cases import *
from math import isqrt
resource.setrlimit(resource.RLIMIT_STACK,(256<<20,resource.getrlimit(resource.RLIMIT_STACK)[1]))
for name in sys.argv[1:]:
 d=B/name;src=d/'source'; flags=['--target','wasm-direct','-O2']; wide=['--wasm-memory64','--wasm-max-pages','262144']; work=d/'training';work.mkdir(exist_ok=True)
 def call(cmd,cwd,**kwargs):subprocess.run(cmd,cwd=cwd,check=True,**kwargs)
 stats=d/'stats.wasm';call([N,*source,*flags,*wide,'--wasm-region-stats','-o',stats],src)
 maximum={}
 for label in ['squares','sorting','tour']:
  rel='examples/'+label+'.goose';input=work/rel;input.parent.mkdir(exist_ok=True);input.write_bytes(subprocess.check_output(['git','show','4e9b78e:'+rel],cwd=R));profile=work/(label+'.profile');out=work/(label+'.wasm');ref=work/(label+'.ref')
  opts=[rel,'--stdlib',src/'stdlib',*flags,*wide];call([H,stats,'--cache',d/'stats.cwasm','--',*opts,'-o',out],work,env=dict(os.environ,GOOSE_REGION_PROFILE=str(profile)));call([N,*opts,'-o',ref],work);assert sha(out)==sha(ref)
  for l in profile.read_text().splitlines():
   i,n=map(int,l.split());maximum[i]=max(maximum.get(i,0),n)
 training=d/'training.profile';training.write_text(''.join(f'{i} {isqrt(n<<16)}\n' for i,n in sorted(maximum.items())))
 call([N,*source,*flags,'--wasm-max-pages','65535','--wasm-region-profile',training,'--wasm-bundled-host','-o',compiler(name)],src)
 call(args(name)+['--version'],src,stdout=subprocess.DEVNULL)
