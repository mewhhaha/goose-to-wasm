import json
from trace import out,prior
from diagnose import region_table
width,_,bounds=region_table((prior/'root32.wasm').read_bytes())
assert width==4
(out/'root-homes.json').write_text(json.dumps(bounds[:-1]))
