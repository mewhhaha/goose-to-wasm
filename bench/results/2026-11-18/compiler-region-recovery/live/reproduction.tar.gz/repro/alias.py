from trace import compiler_stage,project,shape,tools_dir
from trace import repo,out,export_globals
from runtime import prepare
import os,subprocess
os.sched_setaffinity(0,{2})
stage=compiler_stage
opts=[out/'alias.goose','--stdlib',stage/'source/stdlib','--target','wasm-direct','-O2','--wasm-max-pages','65535']
host=repo/'host/rust/target/release/goose-wasmtime'
subprocess.run([host,out/'emitter.wasm','--cache',out/'emitter.cwasm','--',*opts,'-o',out/'alias.raw.wasm'],cwd=out,check=True)
extra={b'probe.next':3,b'probe.table':9,b'probe.count':8,b'probe.floor':1}
(out/'alias.wasm').write_bytes(export_globals((out/'alias.raw.wasm').read_bytes(),extra))
native=stage/'build-1/compiler-native'
subprocess.run([native,out/'alias.goose','--stdlib',stage/'source/stdlib','--target','native','-O2','-o',out/'alias.c'],cwd=out,check=True)
subprocess.run(['cc','-O2',out/'alias.c','-lm','-o',out/'alias.native'],cwd=out,check=True)
subprocess.run([out/'alias.native'],cwd=out,check=True)
