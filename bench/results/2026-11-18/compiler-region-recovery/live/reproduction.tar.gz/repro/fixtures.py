from trace import compiler_stage,project,shape,tools_dir
from trace import repo,out,prior,export_globals
from runtime import prepare
import os,subprocess,sys,json
os.sched_setaffinity(0,{2})
from diagnose import region_table
prepare()
stage=compiler_stage
native=stage/'build-1/compiler-native'
host=repo/'host/rust/target/release/goose-wasmtime'
d=out/'fixtures'
d.mkdir(exist_ok=True)
rows={}
source_dir=repo/'tests/fixtures'
sources=list((source_dir/'contracts/bounded-images').glob('*.goose'))
for case in ['component-encoded','component-heap','storage-scopes']:
    sources.append(source_dir/'contracts/root-struct'/(case+'.goose'))
for pattern in ['combined_varint_*.goose','nonlocal_image_*.goose','nonlocal_enum_*.goose']:
    sources.extend(sorted(source_dir.glob(pattern)))
sources.append(out/'finish-boundary.goose')
for source in sources:
    case=source.stem
    row={}
    rows[case]=row
    args=[source,'--stdlib',stage/'source/stdlib','--target','wasm-direct','-O2','--wasm-max-pages','65535']
    for eng,command in [('control',[native]),('live',[host,out/'emitter.wasm','--cache',out/'emitter.cwasm','--'])]:
        f=d/(case.replace('/','-')+'-'+eng+'.wasm')
        r=subprocess.run([*command,*args,'-o',f],cwd=d,capture_output=True)
        if r.returncode: row[eng]={'compile_error':r.stderr.decode()}; continue
        file=f.read_bytes()
        try: w,_,bounds=region_table(file); region=True
        except (IndexError,UnboundLocalError,ValueError): region=False
        if eng=='live' and region:
            f.write_bytes(export_globals(file,{b'probe.next':3,b'probe.table':9,b'probe.count':8,b'probe.floor':1}))
        env={**os.environ,'ELASTIC_OUT':str(out),'ELASTIC_TRACE':'1','ELASTIC_POLICY':'smoke','ELASTIC_LOG':str(d/(case.replace('/','-')+'.ndjson'))}
        runner=out/('elastic_host.py' if eng=='live' else 'pinned_host.py')
        r=subprocess.run([repo/'.venv/bin/python',runner,f,'--'],cwd=d,capture_output=True,env=env)
        row[eng]=dict(region=region,status=r.returncode,stdout=r.stdout.decode(),stderr=r.stderr.decode())
    print(case,row['live']==row['control'],flush=True)
    (out/'fixtures.json').write_text(json.dumps(rows,indent=2)+'\n')
