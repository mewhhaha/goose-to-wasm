recursive fn escape(depth: i64) {
    if depth > 0 { escape(depth-1); return; }
    return [7; 65532] from value;
}
recursive fn value() -> u8[] {
    escape(2);
    return [];
}
fn main() {
    let longer: u8[u64] = value();
    assert(longer.len == 65532 && longer[65531] == 7);
    print(longer.len);
}
