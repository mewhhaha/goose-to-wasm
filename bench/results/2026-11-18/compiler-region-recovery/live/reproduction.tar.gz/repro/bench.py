from trace import compiler_stage,project,shape,tools_dir
from pathlib import Path
import hashlib,os,sys,subprocess,json
from trace import repo,out,prior
from runtime import prepare
os.sched_setaffinity(0,{2})
prepare()
stage=compiler_stage
case_dir=shape
ref_sha='66798403ae7eb64fcd6da5490114b2d6ae82072d3f8c7fab2519713ee2f7190f'
target=out/'bench-emission.wasm'
cases={'self':(project,['selfhost/main.goose','--stdlib','stdlib','--check']),'emit':(project,['selfhost/main.goose','--stdlib','stdlib','--target','wasm-direct','-O2','--wasm-memory64','--wasm-max-pages','262144','-o',target]),'blot':(prior/'heldout/blot/compiler-goose',['src/main.goose','--stdlib','../stdlib','--target','native','--parse'])}
for name in ('compact','padded'):
    cases[name]=(case_dir,[name+'.goose','--stdlib',stage/'source/stdlib','--parse'])
blot_only='--blot-only' in sys.argv
results=[]
def run(name,mode,round):
    cwd,args=cases[name]
    if mode=='live':
        mod=out/'candidate.wasm'
        cache=out/'candidate.cwasm'
        host=out/'elastic_host.py'
    else:
        mod=prior/'root32.wasm'
        if name=='blot':
            mod=prior/'two-project-fit.wasm'
            if blot_only:
                mod=prior/'diagnostics/blot-oracle32.wasm'
        host=out/'pinned_host.py'
        cache=out/f'fixed-{mod.stem}.cwasm'
    logfile=out/'bench-hooks.ndjson'
    logfile.write_text('')
    env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','ELASTIC_POLICY':'striped','ELASTIC_OUT':str(out),'ELASTIC_LOG':str(logfile),'ELASTIC_TRACE':'0'}
    metric=out/'timing.json'
    metric.unlink(missing_ok=True)
    if name=='emit': target.unlink(missing_ok=True)
    r=subprocess.run([repo/'.venv/bin/python',host,mod,'--cache',cache,'--timing-json',metric,'--',*args],cwd=cwd,capture_output=True,env=env)
    row=dict(case=name,mode=mode,round=round,status=r.returncode,stdout=r.stdout.decode(),stderr=r.stderr.decode(),time=json.loads(metric.read_text()) if metric.exists() else {})
    if logfile.stat().st_size: row['hooks']=json.loads(logfile.read_text().splitlines()[-1])
    if name=='emit' and target.exists(): row['emission']=hashlib.sha256(target.read_bytes()).hexdigest()
    results.append(row)
    (out/('blot-only-pairs.json' if blot_only else 'pairs.json')).write_text(json.dumps(results,indent=2)+'\n')
    print(name,mode,round,row['status'],row.get('emission',''),row.get('stderr',''),flush=True)
for name in ([] if blot_only else ['compact','padded']):
    run(name,'live',0)
    run(name,'fixed',0)
for name in (['blot'] if blot_only else ['blot','self','emit']):
    for n in range(3):
        for mode in (['fixed','live'] if n%2==0 else ['live','fixed']):
            run(name,mode,n+1)
