from trace import compiler_stage,project,shape,tools_dir
from pathlib import Path
import json
from trace import prior,out
ends=json.loads((out/'root-homes.json').read_text())+[65535*65536]
weights=dict(tuple(map(int,l.split())) for l in (prior/'training-root.profile').read_text().splitlines())
n=len(ends)-1
hot=sorted(i for i,w in weights.items() if w>4*sum(weights.values())/n and i<n//2)
print('hot',hot)
children={i:[] for i in hot}
for n_child,i in enumerate(reversed(range(n//2,n))):
    children[hot[n_child%len(hot)]].append(i)
order=[]
for index in range(n//2):
    order.append(index)
    order.extend(children.get(index,[]))
assert sorted(order)==list(range(n))
ptr=ends[0]; homes=[None]*n
for index in order:
    homes[index]=ptr
    ptr+=ends[index+1]-ends[index]
assert ptr==ends[-1]
(out/'striped-homes.json').write_text(json.dumps(homes))
print('first neighbors',[(i,order[order.index(i)+1]) for i in hot])
