from trace import compiler_stage,project,shape,tools_dir
from pathlib import Path
import os,sys,subprocess,json,struct,bisect
from trace import prior,out,repo
def prepare():
    code=(out/'pinned_host.py').read_text()
    src=(tools_dir/'hooks.txt').read_text()
    pos='    def abort(caller, pointer, length, line):\n'
    code=code.replace(pos,src).replace('    ended = time.perf_counter_ns()', '''    ended = time.perf_counter_ns()
    print(json.dumps(dict(event="hooks",acquires=hook_counts[-1],grows=hook_counts[-2]+hook_counts[-3],image_grows=hook_counts[-3],acquire_ns=hook_ns[-1],grow_ns=hook_ns[-2]+hook_ns[-3])),file=log)''')
    (out/'elastic_host.py').write_text(code)
if __name__=='__main__':
    prepare()
    os.sched_setaffinity(0,{2})
    policy,case=sys.argv[1:3]
    cases={'self':(project,['selfhost/main.goose','--stdlib','stdlib','--check']),
           'emit':(project,['selfhost/main.goose','--stdlib','stdlib','--target','wasm-direct','-O2','--wasm-memory64','--wasm-max-pages','262144','-o',out/f'{policy}-emission.wasm']),
           'blot':(prior/'heldout/blot/compiler-goose',['src/main.goose','--stdlib','../stdlib','--target','native','--parse']),
           'alias':(out,['alias.wasm'])}
    cwd,argv=cases[case]
    module=out/'candidate.wasm'
    if case=='alias':
        module=out/'alias.wasm'
        argv=[]
    dest=out/f'{policy}-{case}.ndjson'
    env={**os.environ,'ELASTIC_LOG':str(dest),'ELASTIC_POLICY':policy,'ELASTIC_OUT':str(out),'PYTHONDONTWRITEBYTECODE':'1'}
    dest.write_text('')
    cmd=[repo/'.venv/bin/python',out/'elastic_host.py',module,'--cache',out/(module.stem+'.cwasm'),'--timing-json',out/f'{policy}-{case}-time.json','--',*argv]
    result=subprocess.run(cmd,cwd=cwd,env=env,capture_output=True)
    (out/f'{policy}-{case}.result').write_text(json.dumps({'status':result.returncode,'stdout':result.stdout.decode(),'stderr':result.stderr.decode()})+'\n')
    print(policy,case,result.returncode,result.stdout[:200],result.stderr[-1200:],flush=True)
