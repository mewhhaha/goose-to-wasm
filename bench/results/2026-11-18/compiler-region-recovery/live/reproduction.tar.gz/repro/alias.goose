struct Cell { value: i64 }
var cells: Cell[>..] = [];

fn temporary(seed: i64) -> i64 {
    var temp: Cell[>..] = [];
    for i in 16384 { temp.push(Cell { seed + i }); }
    return temp[0].value + temp[16383].value;
}

fn main() {
    cells.push(Cell { 7 });
    let first = &cells[0];
    let slice = cells[..];
    for i in 200000 { cells.push(Cell { i }); }
    assert(first .== &cells[0] && &slice[0] .== first);
    first.value = 83;
    assert(slice[0].value == 83);
    for i in 8 { assert(temporary(i) == 16383 + i * 2); }
    assert(first .== &cells[0] && &slice[0] .== first && cells[0].value == 83);
    print("alias and slot reuse ok");
}
