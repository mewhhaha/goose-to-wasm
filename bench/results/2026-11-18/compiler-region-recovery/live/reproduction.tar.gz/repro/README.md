# A single-instance memory32 region allocator

Run `run.sh` from the goose-to-wasm repository root using CPU 2, Python Wasmtime 50.0.1, and the Rust Wasmtime host from the compiler-layout-trials investigation. The script takes its compiler source and native emitter from one frozen stage, its self-check source from a second stage, and its three-example training profile and frozen Blot2 checkout from the existing memory study. It writes to a fresh stage.

| Variable | Default under the repository |
| --- | --- |
| REGION_LIVE_OUT | build/region-live-replay |
| REGION_LIVE_COMPILER | build/header-trial/reader/own |
| REGION_LIVE_PROJECT | build/six-hills-1118/selfhost-chart |
| REGION_LIVE_MEMORY | build/three-levers-memory |
| REGION_LIVE_SHAPES | build/region-estimate |

The compiler commit is 4e9b78e6fc3d1294f31582600b62f7eea9f0e946, the self project is 90e086fe61f9ce019d6a6ef543212be63f6e1f57, and the frozen Blot2 archive is 09b5189cc5f61756e3c851870606149c2fd826658b74bca73c8cc34165919d27. The launcher extracts the Python host at c131e7c. For rebuilding the prerequisite compiler and memory stages, see the repository's compiler-record-access and compiler-layout-trials results under bench/results/2026-11-18. The compact and padded fixture source can be reproduced with shape_control.py from the adjacent region-estimate investigation.

The memory32 compiler carries one stable 16-byte descriptor per slot. A first acquisition gets 64 KiB of physical linear address space. Extensions double the assigned interval up to the next previously acquired owner's base. A new owner whose preferred base is already taken acquires space at the midpoint of the largest free gap. The slow operations cross the Python host through experimental negative-line instrumentation on the existing abort import. Each callback checks the available address interval against every previously assigned owner. A slot's physical base survives for the entire Wasm instance. Lexical release restores the guest's next-region index and a subsequent acquisition of the same slot resets its cursor. The allocator keeps the old extent reserved, even after the owner leaves scope. The experiment never lends a slot just because it currently holds zero bytes.

Placement uses the frozen root-weight profile trained on squares, sorting and tour. The algorithm interleaves the deeper half of the slots, highest ordinal first, after early slots whose training weight exceeds four times the mean. This leaves cold potential homes where early large owners can grow. The policy was designed after observing failure behavior on the frozen projects. The three-example training weights are independent of both projects.

The cold absolute-end path in correct.py claims space for sparse publication, redirected nonlocal returns and array-prefix growth. A numerical image bound can be an ordinary byte-end address or a region descriptor. The guest recognizes descriptors by their separately reserved address interval. Ordinary fixed-size image bounds remain exact. The host performs a second range and alignment check before accepting a descriptor.

pairs.json records three alternating fixed/live pairs for the self workloads and a Blot2 control fitted to both projects. blot-only-pairs.json compares against the separate fixed layout trained on Blot2 alone. Execution timing brackets the guest's _start, including synchronous host calls. It excludes compilation and instantiation. The timed runs disable per-event file logging. Callback measurements include Python work inside the hook, memory.grow on acquisition and dictionary construction. They exclude Wasmtime-to-Python dispatch and include no timing for the Wasm fast path. Detailed NDJSON traces come from separate runs.

The scratch emitter targets the memory32 region ABI and assumes statistics are disabled. Region statistics reuse the old third footer word and require their own implementation. The frozen compile workloads and focused fixtures do not cover every language feature, the browser host, the Rust host or memory64. Host geometries are heuristic. A previously acquired neighbor can still prevent growth, and stack or address-space exhaustion remains possible. No runtime restart or rollback occurs. The probe's host reserves program-owned memory32 pages on first acquisition and keeps dead intervals conservative. The reference ABI, runtime, and deployment are unchanged outside the scratch stage.
