"""Check physical disjointness, frozen output equality and paired timing observations."""
from trace import repo,out,prior,compiler_stage,project,shape
import hashlib,json,statistics
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def read(name):
    return json.loads((out/name).read_text())
def trace(name):
    return [json.loads(line) for line in (out/name).read_text().splitlines()]
def audit(rows):
    live={}
    relocated=[]
    grew=0
    sources={}
    for e in rows:
        if e['event'] not in ('grow','acquire'): continue
        i=e['slot']; lo=e['base']; hi=e['limit']
        assert lo<hi
        if e['event']=='acquire':
            assert i not in live
            if e['planned']!=lo: relocated.append(i)
        else:
            assert live[i]==(lo,e['old']) and e['old']<e['needed']<=hi
            grew+=1
            key=str(e.get('source',-2))
            sources[key]=sources.get(key,0)+1
        assert all(j==i or lo>=b or hi<=a for j,(a,b) in live.items())
        live[i]=(lo,hi)
    return dict(acquisitions=len(live),unchanged_bases=True,disjoint_at_every_event=True,extensions=grew,extension_paths=sources,
                displaced_before_first_use=relocated,physical_capacity_bytes={i:b-a for i,(a,b) in live.items() if i in (0,1,6,7,53)})
r={'pins':{},'runs':{},'timing':{},'focused_fixtures':{}}
pins={'compiler':compiler_stage/'build-1/compiler-native','candidate':out/'candidate.wasm','emitter':out/'emitter.wasm','pinned_host':out/'pinned_host.py','experimental_host':out/'elastic_host.py','blot_fixed':prior/'diagnostics/blot-oracle32.wasm','combined_fixed':prior/'two-project-fit.wasm','self_fixed':prior/'root32.wasm','tiny_profile':prior/'training-root.profile','compact':shape/'compact.goose','padded':shape/'padded.goose'}
for name,path in pins.items():r['pins'][name]={'sha256':sha(path),'size':path.stat().st_size}
for name,path in [('compiler',compiler_stage),('self',project.parent)]:
    manifest=json.loads((path/'builds.json').read_text())
    r['pins'][name+'_source']=[manifest['source_commit'],manifest['source_archive_sha256']]
r['pins']['blot_archive_sha256']=json.loads((prior/'validation-root.json').read_text())['fixture_sha256']
for case in ['blot','self','emit']:
    r['runs'][case]=audit(trace(f'striped-{case}.ndjson'))
    assert read(f'striped-{case}.result')=={'status':0,'stdout':'','stderr':''}
r['runs']['emit']['output_sha256']=sha(out/'striped-emission.wasm')
assert r['runs']['emit']['output_sha256']=='66798403ae7eb64fcd6da5490114b2d6ae82072d3f8c7fab2519713ee2f7190f'
r['runs']['alias_and_retirement']=audit(trace('alias-alias.ndjson'))
assert read('alias-alias.result')['stdout']=='alias and slot reuse ok\n'
r['focused_fixtures']={'total':len(read('fixtures.json')),'matched':sum(v['control']==v['live'] for v in read('fixtures.json').values()),'mismatches':{k:v for k,v in read('fixtures.json').items() if v['control']!=v['live']}}
for case,rows in [('blot_exact',read('blot-only-pairs.json')),('blot_combined',read('pairs.json')),('self',read('pairs.json')),('emit',read('pairs.json')),('compact',read('pairs.json')),('padded',read('pairs.json'))]:
    name=case.split('_')[0]
    results={}
    for mode in ['fixed','live']:
        subset=[v for v in rows if v['case']==name and v['mode']==mode]
        ns=[v['time']['start_function_ns'] for v in subset]
        result=dict(n=len(ns),median_ns=statistics.median(ns),outcomes=[q['status'] for q in subset],observed_ns=ns)
        if mode=='live':
            result['callbacks']={k:statistics.median(q['hooks'][k] for q in subset) for k in subset[0]['hooks'] if k!='event'}
        results[mode]=result
    if not any(results['fixed']['outcomes'] + results['live']['outcomes']):
        results['pct_change']=100*(results['live']['median_ns']/results['fixed']['median_ns']-1)
    r['timing'][case]=results
(out/'summary.json').write_text(json.dumps(r,indent=2)+'\n')
