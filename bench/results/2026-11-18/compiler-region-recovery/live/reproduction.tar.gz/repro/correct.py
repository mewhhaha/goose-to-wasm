"""Make numeric bounds work with both fixed image ends and region descriptors; claim sparse extents."""
def correct(s):
    marker='fn cg_region_cursor_slot('
    pos=s.index(marker)
    helper='''fn cg_live_limit(m: CgModule&, f: CgBody&) {
    let word = cg_save(f, wa()); cg_get(f, word);
    if !m.regions_enabled { return; }
    wb_op(f.code, 0x23, 9); wb_op(f.code, 0x23, 8); wb_i32(f.code, 1); wb_byte(f.code, 0x6a); wb_i32(f.code, 4); wb_byte(f.code, 0x6c); wb_byte(f.code, 0x6a); let descriptors = cg_save(f, wa());
    cg_get(f, descriptors); wa_op(f.code, 0x4f); cg_get(f, word); cg_get(f, descriptors);
    wb_op(f.code, 0x23, 8); wb_i32(f.code, 16); wb_byte(f.code, 0x6c); wa_op(f.code, 0x6a); wa_op(f.code, 0x49); wb_byte(f.code, 0x71);
    cg_begin(f, 0x04, wa()); cg_get(f, word); wa_load(f.code, ww(2)); wb_byte(f.code, 0x05); cg_get(f, word); cg_end(f);
}
fn cg_live_require(p: Program&, m: CgModule&, f: CgBody&, header: i64, requested: i64, node: i64) {
    cg_get(f, requested); cg_get(f, header); wc_load(f.code, 2); cg_live_limit(m, f); wa_extend(f.code); wb_byte(f.code, 0x56); cg_begin(f, 0x04, 0x40);
    cg_get(f, requested); wb_i64(f.code, 4294901760); wb_byte(f.code, 0x56); cg_trap_if(p, m, f, node, "data region exhausted");
    cg_get(f, header); wc_load(f.code, 2); cg_get(f, requested); wa_wrap(f.code); wb_i32(f.code, -3); wb_op(f.code, 0x10, CG_ABORT); cg_end(f);
}
'''
    s=s[:pos]+helper+s[pos:]
    s=s.replace('wc_load(f.code, 2); wa_load(f.code, ww(2));','wc_load(f.code, 2); cg_live_limit(m, f);')
    # The non-region varint-array heap code operates on an actual bound.
    # Its existing capacity computation already consumes the raw word 2.
    for name,owner,end in [('cg_region_limited_assignment','header','end'),('cg_finish_value_array','header','end64'),('cg_finish_enum','owner','top64'),('cg_finish_record_image','header','top64'),('cg_patch_uleb_length','header','end'),('cg_enum_image_bytes','owner','end')]:
        start=s.index('fn '+name+'(')
        stop=s.index('\n}',start)
        body=s[start:stop]
        raw=body.splitlines()
        i=next(i for i,line in enumerate(raw) if 'cg_live_limit(m, f)' in line)
        raw.insert(i,'    cg_live_require(p, m, f, '+owner+', '+end+', node);')
        s=s[:start]+'\n'.join(raw)+s[stop:]
    a=s.index('fn cg_validate_region_array(')
    b=s.index('    cg_get(f, extent); wa_extend(f.code); cg_get(f, limit);',a)
    s=s[:b]+'''    cg_get(f, extent); wa_extend(f.code); wb_i64(f.code, 4294901760); cg_get(f, base); wa_extend(f.code); wb_byte(f.code, 0x7d); wb_i64(f.code, stride); wb_byte(f.code, 0x80); wb_byte(f.code, 0x56); cg_trap_if(p, m, f, node, "array image exceeds data region");
    cg_get(f, base); wa_extend(f.code); cg_get(f, extent); wa_extend(f.code); wb_i64(f.code, stride); wb_byte(f.code, 0x7e); wb_byte(f.code, 0x7c); let requested = cg_save(f, 0x7e);
    cg_live_require(p, m, f, header, requested, node);
    cg_get(f, header); wc_load(f.code, 2); cg_live_limit(m, f); cg_set(f, limit);
'''+s[b:]
    return s
