#!/usr/bin/env bash
# Run from the repository root. Dependencies are the frozen stages described in README.
set -euo pipefail
tools_dir=$(cd "$(dirname "$0")" && pwd)
export REGION_LIVE_REPO=${REGION_LIVE_REPO:-"$(pwd)"}
export REGION_LIVE_OUT=${REGION_LIVE_OUT:-"$REGION_LIVE_REPO/build/region-live-replay"}
mkdir -p "$REGION_LIVE_OUT"
export PYTHONDONTWRITEBYTECODE=1
export REGION_LIVE_VERSION=${REGION_LIVE_VERSION:-2}
python="$REGION_LIVE_REPO/.venv/bin/python"
git -C "$REGION_LIVE_REPO" show c131e7c:scripts/run_wasmtime.py >"$REGION_LIVE_OUT/pinned_host.py"
cp "$tools_dir/alias.goose" "$tools_dir/finish-boundary.goose" "$REGION_LIVE_OUT/"
run() { taskset -c 2 "$python" "$tools_dir/$1.py" "${@:2}"; }
run trace
run build_candidate
run prepare_homes
run place
for workload in self emit blot; do run runtime striped "$workload"; done
run alias
run runtime alias alias
run fixtures
run bench
run bench --blot-only
run summarize
