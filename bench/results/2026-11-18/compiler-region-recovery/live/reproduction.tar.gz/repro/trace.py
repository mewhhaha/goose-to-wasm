from pathlib import Path
import os, sys, subprocess, json
tools_dir=Path(__file__).resolve().parent
repo=Path(os.environ.get('REGION_LIVE_REPO',Path.cwd())).resolve()
out=Path(os.environ.get('REGION_LIVE_OUT',repo/'build/region-live-replay')).resolve()
prior=Path(os.environ.get('REGION_LIVE_MEMORY',repo/'build/three-levers-memory')).resolve()
compiler_stage=Path(os.environ.get('REGION_LIVE_COMPILER',repo/'build/header-trial/reader/own')).resolve()
project=Path(os.environ.get('REGION_LIVE_PROJECT',repo/'build/six-hills-1118/selfhost-chart')).resolve()/'source'
shape=Path(os.environ.get('REGION_LIVE_SHAPES',repo/'build/region-estimate')).resolve()
sys.path.insert(0,str(repo/'bench/results/2026-11-18/compiler-layout-trials/memory'))
from diagnose import leb
def ul(n):
    a=[]
    while n>127:
        a.append(128+n%128)
        n//=128
    return bytes(a+[n])
def export_globals(wasm, extra):
    sections=[]
    at=8
    while at<len(wasm):
        typ=wasm[at]
        size,start=leb(wasm,at+1)
        end=start+size
        body=wasm[start:end]
        if typ==7:
            count,skip=leb(body,0)
            add=b''.join(ul(len(k))+k+bytes([3])+ul(v) for k,v in extra.items())
            body=ul(count+len(extra))+body[skip:]+add
        sections.append(bytes([typ])+ul(len(body))+body)
        at=end
    return wasm[:8]+b''.join(sections)
def make_dump():
    src=(out/'pinned_host.py').read_text()
    key='        raise RuntimeError(f"goose runtime error: {message} (line {line})")'
    dump='''        if message=="data region exhausted":
            read=lambda a:int.from_bytes(memory_bytes(caller,a,4),"little")
            next_idx=caller.get("probe.next").value(caller)
            count=caller.get("probe.count").value(caller)
            table=caller.get("probe.table").value(caller)
            bounds=[read(table+i*4) for i in range(count+1)]
            rows=[]
            for i in range(next_idx):
                end=bounds[i+1]
                cursor,base,peak=[read(end-12+j*4) for j in range(3)]
                rows.append({"slot":i,"base":bounds[i],"limit":end-12,"metadata_base":base,"used":cursor-bounds[i]})
            Path(os.environ["DUMP"]).write_text(json.dumps({"next":next_idx,"regions":count,"active":rows},indent=2)+"\\n")
'''
    (out/'host.py').write_text(src.replace(key,dump+key))
if __name__=='__main__':
    os.sched_setaffinity(0,{2})
    make_dump()
    for ident in ['uniform32','trained32','root32','calibrated32']:
        data=(prior/'diagnostics'/f'{ident}-trace.wasm').read_bytes()
        file=out/(ident+'.wasm')
        file.write_bytes(export_globals(data,{b'probe.next':3,b'probe.count':8,b'probe.table':9}))
        for name,cwd,args in [('self',project,['selfhost/main.goose','--stdlib','stdlib','--check']),('blot',prior/'heldout/blot/compiler-goose',['src/main.goose','--stdlib','../stdlib','--target','native','--parse'])]:
            if name=='self' and ident not in ['uniform32','trained32']:
                continue
            path=out/f'{ident}-{name}.json'
            r=subprocess.run([repo/'.venv/bin/python',out/'host.py',file,'--cache',out/f'{ident}.cwasm','--',*args],cwd=cwd,capture_output=True,env={**os.environ,'DUMP':str(path)})
            print(ident,name,r.returncode,r.stdout,r.stderr[-200:],flush=True)
            if path.exists():
                info=json.loads(path.read_text())
                print(info['next'],[(x['slot'],x['used']) for x in info['active'] if 4<=x['slot']<=12 or 51<=x['slot']<=56],flush=True)
