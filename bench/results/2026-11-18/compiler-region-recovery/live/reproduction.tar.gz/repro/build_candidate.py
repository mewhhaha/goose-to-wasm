from pathlib import Path
import os, sys, subprocess, shutil, resource
from trace import export_globals,repo,out,compiler_stage
stage=compiler_stage
src=stage/'source'
os.sched_setaffinity(0,{2})
resource.setrlimit(resource.RLIMIT_STACK,(256<<20,resource.getrlimit(resource.RLIMIT_STACK)[1]))
test=out/'source'
shutil.copytree(src,test,dirs_exist_ok=True)
f=test/'selfhost/codegen.goose'
s=f.read_text()
s=s.replace('table + ww(m.region_count + 1), 16','table + ww(m.region_count * 5 + 1), 16').replace('m.next_data = table + encoded.len;', 'm.next_data = table + encoded.len + ww(4 * m.region_count);')
# The experiment's sole compiler target is the direct memory32 compiler, with region stats off.
before=s.index('    wb_op(f.code, 0x23, 9); cg_get(f, region);',s.index('fn cg_region_acquire('))
after=s.index('    cg_get(f, header); wb_i32(f.code, 0);',before)
s=s[:before]+'''    wb_op(f.code, 0x23, 9); wb_op(f.code, 0x23, 8); wb_i32(f.code, 1); wb_byte(f.code, 0x6a); wb_i32(f.code, 4); wb_byte(f.code, 0x6c); wb_byte(f.code, 0x6a);
    cg_get(f, region); wb_i32(f.code, 16); wb_byte(f.code, 0x6c); wb_byte(f.code, 0x6a); let limit = cg_save(f, wa());
    cg_get(f, limit); wa_load(f.code, ww(1)); wa_op(f.code, 0x45); cg_begin(f, 0x04, 0x40);
    var stride: i64 = 1; if cg_owner(p, id) { stride = cg_size(p, p.types[id].element); }
    cg_get(f, limit); wb_i32(f.code, stride); wb_i32(f.code, -1); wb_op(f.code, 0x10, CG_ABORT); cg_end(f);
    cg_get(f, limit); wa_load(f.code, ww(1)); let base = cg_save(f, wa());
'''+s[after:]
# Only numerical comparisons of a region capability load the limit from it.
for l in s.splitlines():
    if 'wc_load(f.code, 2);' not in l: continue
    if 'wa_extend(f.code); wb_byte(f.code, 0x56)' in l or 'wc_load(f.code, 2); wa_op(f.code, 0x4b)' in l or 'cg_owner_read_base' in l and 'let limit =' in l:
        if l in s:
            s=s.replace(l,l.replace('wc_load(f.code, 2);','wc_load(f.code, 2); wa_load(f.code, ww(2));'))
a=s.index('    let cursor = ',s.index('fn cg_region_reserve('))
b=s.index('    cg_get(f, top64); wa_wrap',a)
s=s[:a]+'''    let descriptor = cg_region_cursor_slot(f, header);
    cg_get(f, descriptor); wa_load(f.code, 0); let cursor = cg_save(f, wa()); cg_get(f, descriptor); wa_load(f.code, ww(2)); let limit = cg_save(f, wa());
    cg_get(f, cursor); cg_get(f, descriptor); wa_load(f.code, ww(1)); wa_op(f.code, 0x49);
    cg_get(f, cursor); cg_get(f, limit); wa_op(f.code, 0x4b); wb_byte(f.code, 0x72); cg_trap_if(p, m, f, node, "data region exhausted");
    cg_get(f, cursor); wa_extend(f.code); cg_get(f, bytes); wb_byte(f.code, 0x7c); let top64 = cg_save(f, 0x7e);
    cg_get(f, top64); cg_get(f, limit); wa_extend(f.code); wb_byte(f.code, 0x56); cg_begin(f, 0x04, 0x40);
    cg_get(f, top64); wb_i64(f.code, 4294901760); wb_byte(f.code, 0x56); cg_trap_if(p, m, f, node, "data region exhausted");
    cg_get(f, descriptor); cg_get(f, top64); wa_wrap(f.code); wb_i32(f.code, -2); wb_op(f.code, 0x10, CG_ABORT); cg_end(f);
'''+s[b:]
if os.environ.get('REGION_LIVE_VERSION','2')=='2':
    from correct import correct
    s=correct(s)
f.write_text(s)
opts=['selfhost/main.goose','--stdlib','stdlib','--target','wasm-direct','-O2']
native=stage/'build-1/compiler-native'
wide=['--wasm-memory64','--wasm-max-pages','262144']
subprocess.run([native,*opts,*wide,'-o',out/'emitter.wasm'],cwd=test,check=True)
host=repo/'host/rust/target/release/goose-wasmtime'
subprocess.run([host,out/'emitter.wasm','--cache',out/'emitter.cwasm','--',*opts,'--wasm-max-pages','65535','-o',out/'candidate.raw.wasm'],cwd=src,check=True)
candidate=export_globals((out/'candidate.raw.wasm').read_bytes(),{b'probe.next':3,b'probe.table':9,b'probe.count':8,b'probe.floor':1})
(out/'candidate.wasm').write_bytes(candidate)
