# Example program benchmarks

Status: **passed**.

2026-11-03 · AMD Ryzen 7 3800X, shared desktop host.

Goose O2. Direct Wasm uses memory32; C-Wasm uses memory64. The selected programs, their constant inputs and all printing are unchanged from the [example catalog](../../../../examples/README.md). Compiler constant folding is allowed.

Builds are complete uncached Python-driver invocations, including any C compilation/linking. OS page caches and Emscripten's installed system-library cache remain warm.

Runtime is **whole-process launch-to-exit time**, including host startup, Wasm compilation/instantiation, program initialization, computation, output delivery and teardown. Each observation starts a fresh process/instance and calls the entrypoint once. This measures CLI cost, not warmed kernel throughput.

Each cell has 5 build samples or 15 runtime samples. Untimed fresh-process warmups per runtime cell: 1. Orders are shuffled with the recorded seed; builds and runtime never overlap. Every used artifact must pass its golden output. Values are median milliseconds ± median absolute deviation (MAD).

Headline runtime samples use the ordinary runners without timing-file instrumentation. The Wasm supplements use a separate shuffled set of fresh processes, with the same sample count; timing files are written after their engine intervals end.

## Compilation

| Example | Direct | C-Wasm | Native C |
| --- | ---: | ---: | ---: |
| squares | 61.616 ±0.667 | 495.850 ±16.190 | 226.979 ±28.178 |
| tour | 63.658 ±2.711 | 898.571 ±29.438 | 413.788 ±11.193 |
| functions | 108.752 ±8.511 | 896.778 ±11.899 | 487.254 ±13.544 |
| errors | 69.254 ±3.570 | 685.183 ±16.581 | 341.908 ±20.005 |
| sieve | 71.706 ±5.400 | 567.011 ±19.136 | 259.502 ±6.802 |
| sorting | 85.973 ±1.524 | 839.652 ±28.250 | 561.679 ±19.866 |
| sudoku | 67.711 ±1.467 | 532.294 ±16.906 | 263.874 ±7.484 |
| maze | 70.155 ±0.602 | 713.388 ±36.773 | 358.891 ±3.633 |
| vm | 92.158 ±2.415 | 706.756 ±38.618 | 311.222 ±5.406 |
| life | 72.998 ±5.659 | 624.725 ±48.238 | 320.345 ±5.045 |

## Whole-process runtime

| Example | Direct / V8 | C-Wasm / V8 | Direct / Wasmtime | C-Wasm / Wasmtime | Native C |
| --- | ---: | ---: | ---: | ---: | ---: |
| squares | 27.713 ±2.600 | 29.724 ±3.819 | 69.605 ±2.428 | 87.558 ±10.792 | 1.083 ±0.140 |
| tour | 43.599 ±2.103 | 40.728 ±9.603 | 121.786 ±12.708 | 106.459 ±7.653 | 1.243 ±0.365 |
| functions | 35.145 ±4.318 | 32.413 ±1.476 | 103.519 ±5.785 | 120.626 ±2.917 | 0.874 ±0.136 |
| errors | 30.229 ±2.314 | 33.633 ±5.955 | 80.488 ±4.502 | 90.275 ±6.151 | 0.941 ±0.216 |
| sieve | 39.493 ±7.940 | 34.601 ±4.220 | 80.063 ±7.846 | 96.678 ±12.176 | 1.638 ±0.148 |
| sorting | 74.048 ±7.401 | 238.041 ±11.172 | 117.681 ±9.964 | 249.708 ±25.565 | 45.960 ±0.578 |
| sudoku | 55.284 ±8.195 | 36.673 ±3.250 | 78.262 ±2.551 | 95.422 ±4.837 | 4.189 ±0.187 |
| maze | 28.751 ±1.282 | 33.208 ±5.140 | 85.037 ±8.882 | 95.986 ±10.972 | 0.892 ±0.137 |
| vm | 31.231 ±3.580 | 39.031 ±10.583 | 93.005 ±8.036 | 91.675 ±4.179 | 1.299 ±0.170 |
| life | 43.117 ±5.842 | 42.539 ±3.802 | 95.028 ±9.973 | 98.517 ±3.196 | 18.170 ±0.234 |

## Supplement: Wasm entrypoint

| Example | Direct / V8 | C-Wasm / V8 | Direct / Wasmtime | C-Wasm / Wasmtime |
| --- | ---: | ---: | ---: | ---: |
| squares | 0.193 ±0.018 | 0.966 ±0.022 | 0.128 ±0.003 | 0.632 ±0.013 |
| tour | 13.629 ±0.591 | 3.736 ±1.075 | 1.724 ±0.014 | 1.714 ±0.008 |
| functions | 5.648 ±0.166 | 2.644 ±0.112 | 1.342 ±0.005 | 1.907 ±0.013 |
| errors | 2.205 ±0.664 | 1.750 ±0.015 | 0.848 ±0.013 | 1.696 ±0.014 |
| sieve | 1.956 ±0.059 | 2.526 ±0.737 | 1.153 ±0.020 | 1.342 ±0.007 |
| sorting | 22.673 ±0.654 | 195.952 ±4.113 | 14.987 ±0.177 | 123.545 ±1.122 |
| sudoku | 6.144 ±0.966 | 6.572 ±0.267 | 3.772 ±0.022 | 8.324 ±0.068 |
| maze | 2.392 ±0.369 | 1.939 ±0.064 | 0.770 ±0.012 | 2.236 ±0.034 |
| vm | 3.022 ±0.366 | 2.221 ±0.077 | 0.903 ±0.009 | 2.973 ±0.019 |
| life | 4.814 ±0.653 | 9.888 ±0.204 | 2.774 ±0.021 | 9.544 ±0.046 |

## Supplement: Wasm engine compilation and instantiation

| Example | Direct / V8 | C-Wasm / V8 | Direct / Wasmtime | C-Wasm / Wasmtime |
| --- | ---: | ---: | ---: | ---: |
| squares | 0.259 ±0.031 | 0.554 ±0.022 | 3.004 ±0.272 | 11.301 ±1.673 |
| tour | 0.522 ±0.066 | 0.701 ±0.133 | 32.379 ±2.493 | 32.487 ±1.463 |
| functions | 0.352 ±0.050 | 0.568 ±0.063 | 19.356 ±1.985 | 29.133 ±2.085 |
| errors | 0.380 ±0.068 | 0.559 ±0.049 | 11.475 ±1.355 | 15.815 ±1.161 |
| sieve | 0.266 ±0.018 | 0.572 ±0.050 | 8.519 ±1.125 | 12.911 ±2.320 |
| sorting | 0.391 ±0.056 | 0.684 ±0.112 | 18.570 ±3.498 | 30.237 ±1.373 |
| sudoku | 0.329 ±0.024 | 0.545 ±0.054 | 6.439 ±1.002 | 14.521 ±2.003 |
| maze | 0.350 ±0.028 | 0.605 ±0.067 | 12.370 ±2.809 | 17.750 ±3.894 |
| vm | 0.370 ±0.078 | 0.632 ±0.089 | 21.396 ±5.231 | 15.416 ±0.920 |
| life | 0.318 ±0.042 | 0.628 ±0.104 | 12.201 ±0.455 | 13.327 ±0.788 |

The entrypoint interval includes Goose initialization, host output callbacks and any lazy JIT work. It excludes final Wasm-host output concatenation/delivery. Native Goose prints unbuffered, so no native entrypoint column or cross-boundary speedup is presented. Process time minus engine time also includes loading, bookkeeping and teardown; it is not a pure startup measurement.

These fresh-process examples have different timing rules from LangArena's warmed computational regions. Raw samples, commands, artifact/source/compiler identities and engine versions are in [report.json](report.json). [Method and reproduction](../../../examples.md).
