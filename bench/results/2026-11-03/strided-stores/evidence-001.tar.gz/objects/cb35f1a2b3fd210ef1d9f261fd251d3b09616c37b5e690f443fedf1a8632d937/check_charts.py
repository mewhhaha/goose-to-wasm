"""Match public SVG labels to retained raw-summary cells in their plot order."""
from pathlib import Path
import hashlib,json,re,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'bench/results/2026-11-03/strided-stores';CHARTS=ROOT/'bench/charts'
def load(p):return json.loads(p.read_bytes())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def index(rows,fields):return{tuple(r[f]for f in fields):r for r in rows}
def label(summary):return f"{summary['median']*1000:.3g} ±{summary['mad']*1000:.2g}"
def check(name,expected,plain=False):
 root=ET.parse(CHARTS/name).getroot();texts=[e for e in root.iter()if e.tag.endswith('}text')]
 if plain:observed=[''.join(e.itertext())for e in texts if re.search(r'(?:font-size:\s*|font:\s*)8\.5px',e.attrib.get('style',''))]
 else:observed=[''.join(e.itertext())for e in texts if re.fullmatch(r'[\d.e+−-]+ ±[\d.e+−-]+',''.join(e.itertext()))]
 assert observed==expected,(name,len(observed),len(expected),observed[:3],expected[:3]);return{'chart':name,'labels_checked':len(expected),'sha256':digest(CHARTS/name)}
results=[];backends=['direct','c-wasm','native'];examples=load(OUT/'examples.json');names=[e['name']for e in examples['examples']]
build=index(examples['compile_summary'],['name','backend']);runtime=index(examples['runtime_summary'],['name','backend','engine'])
results.append(check('examples-compilation.svg',[label(build[n,b]['wall_seconds'])for b in backends for n in names]))
for filename,metric,bs in [('examples-python-runtime.svg','process_wall_seconds',backends),('examples-entry.svg','entry_function_seconds',backends[:2])]:
 results.append(check(filename,[label(runtime[n,b,'native'if b=='native'else engine][metric])for engine in ['v8','wasmtime']for b in bs for n in names]))
host=load(OUT/'host.json');runtime=index(host['runtime_summary'],['name','backend','mode']);prep=index(host['preparation_summary'],['name','backend','configuration'])
results.append(check('examples-runtime.svg',[label(runtime[n,b,'native-C'if b=='native'else mode]['wall_seconds'])for mode in ['native','precompiled']for b in backends for n in names]))
for backend,filename in [('direct','wasmtime-host-runtime.svg'),('c-wasm','wasmtime-host-c-wasm.svg')]:
 results.append(check(filename,[label(runtime[n,'native'if mode=='native-C'else backend,mode]['wall_seconds'])for mode in ['python','native','precompiled','native-C']for n in names]))
results.append(check('wasmtime-host-preparation.svg',[label(prep[n,b,c]['wall_seconds'])for b in ['direct','c-wasm']for c in ['parallel','serial']for n in names]))
cohort=load(OUT/'cohort.json');tasks=['CLBG::Fannkuchredux','CLBG::Mandelbrot','Etc::Sieve','Hash::CRC32','Hash::SHA256','Sort::Merge','Sort::Quick'];build=index([r for r in cohort['compile_summary']if r['track']=='adapted'and r['phase']=='cold'],['task','backend']);runtime=index([r for r in cohort['runtime_summary']if r['track']=='adapted'and r['profile']=='run'],['task','backend','engine'])
results.append(check('compilation.svg',[f"{build[t,b]['wall_seconds']['median']*1000:.0f}"for b in backends for t in tasks],True))
results.append(check('runtime.svg',[f"{runtime[t,b,'native'if b=='native'else e]['timed_region_seconds']['median']:.2f}"for e in ['v8','wasmtime']for b in backends for t in tasks],True))
for p in ['latest.json','examples-latest.json','wasmtime-host-latest.json']:
 pointer=load(ROOT/'bench/results'/p);assert digest(ROOT/'bench/results'/pointer['report'])==pointer['sha256']
target=load(OUT/'target-chart-verification.json')
assert len(target['numeric_labels'])==30
assert target['chart_sha256']==digest(CHARTS/'runtime-targets.svg')
results.append({'chart':'runtime-targets.svg','labels_checked':30,'sha256':target['chart_sha256']})
pointer=load(ROOT/'bench/results/runtime-targets-latest.json')
for record in [pointer,pointer['comparison'],pointer['chart_verification']]:
 assert digest(ROOT/'bench/results'/record['report'])==record['sha256']
lifecycle=load(OUT/'lifecycle.json')
chart=ET.parse(CHARTS/'runtime-lifecycle.svg').getroot()
description=next(e.text for e in chart.iter() if e.tag.endswith('}description'))
proof=json.loads(description)
expected=[f"{case['modes'][mode]['median_seconds']*1000:.2f}" for mode in ['ordinary','cache-hit','precompiled','native-C','worker-hit'] for case in lifecycle['examples']]
assert proof['numeric_labels']==expected and proof['numeric_label_count']==50
assert proof['report_sha256']==digest(OUT/'lifecycle.json')
texts=[''.join(e.itertext()) for e in chart.iter() if e.tag.endswith('}text')]
observed=[t for t in texts if re.fullmatch(r'\d+\.\d{2}',t)]
assert observed==expected,('lifecycle numeric SVG order',observed,expected)
results.append({'chart':'runtime-lifecycle.svg','labels_checked':50,'sha256':digest(CHARTS/'runtime-lifecycle.svg')})
pointer=load(ROOT/'bench/results/runtime-lifecycle-latest.json')
assert digest(ROOT/'bench/results'/pointer['report'])==pointer['sha256']
(OUT/'chart-verification.json').write_text(json.dumps({'status':'passed','charts':results,'total_numeric_bar_labels':sum(r['labels_checked']for r in results),'method':'Exact SVG text order and rounded values matched to retained summary cells; chart generators validate their source fingerprints. Pointer hashes checked. Visual inspection recorded separately after rendering.'},indent=2)+'\n')
print('Verified',sum(r['labels_checked']for r in results),'labels across',len(results),'charts')
