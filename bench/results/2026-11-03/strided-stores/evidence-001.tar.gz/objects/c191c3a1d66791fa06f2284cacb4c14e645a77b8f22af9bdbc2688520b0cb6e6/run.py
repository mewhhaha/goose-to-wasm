import hashlib,json,subprocess,sys
from pathlib import Path
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tests'));import test_strided_stores as tests
from test_fill_loops import function_body
variants={'baseline':root/'build/next-hills/final/bin/goose','four':root/'build/stride-hills/four/bin/goose'}
fixtures={'slice':(tests.source_for('u8'),'paint'),'fixed-global':(tests.closed_source('u32','fixed-global'),'work'),'raw-owner-frame':(tests.closed_source('u8','owner-frame'),'work'),'raw-owner-global':(tests.closed_source('u8','owner-global'),'work'),'sieve':((root/'examples/sieve.goose').read_text(),'main')};rows={};commands=[]
for name,(source,function)in fixtures.items():
 path=out/(name+'.goose');path.write_text(source);rows[name]={}
 for variant,compiler in variants.items():
  wasm=out/(name+'-'+variant+'.wasm');stats=wasm.with_suffix('.json');command=[str(compiler),str(path),'--offline','--target','wasm-direct','-O2','--wasm-stats',str(stats),'-o',str(wasm)];result=subprocess.run(command,capture_output=True);(out/(name+'-'+variant+'.stdout')).write_bytes(result.stdout);(out/(name+'-'+variant+'.stderr')).write_bytes(result.stderr);commands.append({'command':command,'exit_status':result.returncode});assert result.returncode==0,(name,variant,result.stdout,result.stderr)
  body=function_body(wasm,json.loads(stats.read_text()),function);rows[name][variant]={'module_bytes':wasm.stat().st_size,'body_bytes':len(body),'body_sha256':hashlib.sha256(body).hexdigest()}
 assert rows[name]['baseline']['body_sha256']!=rows[name]['four']['body_sha256'],(name,'optimization not emitted')
value={'status':'passed','engine_execution':False,'commands':commands,'fixtures':rows};(out/'report.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value,indent=2))
