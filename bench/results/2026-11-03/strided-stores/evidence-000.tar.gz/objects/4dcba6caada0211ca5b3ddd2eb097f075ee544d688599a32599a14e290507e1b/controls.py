#!/usr/bin/env python3
"""Prepare one matched predicate control; builds require a separate CPU grant."""
from pathlib import Path
import argparse
import difflib
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parent
CONTROLS={
    'scan':('direct_wasm_scan.h','inline bool Function::ByteScan(While *loop) {\n','    return false;\n'),
    'stride':('direct_wasm_stride.h','inline bool Function::GroupedStores(While *loop) {\n','    return false;\n'),
    'merge':('direct_wasm_merge.h','inline bool Function::BoundedMerge(While *loop) {\n','    return false;\n'),
    'resource':('direct_wasm_temps.h','inline bool Function::ResourceFreeBlock(Block *block) {\n','    return false;\n'),
    'named':('direct_wasm_funvals.h','    if (!tail->fvbody) {\n','        return nullptr;\n'),
    'private':('direct_wasm_emit.h','inline void Compiler::AnalyzePrivateSnapshots() {\n','    return;\n'),
    'stencil':('direct_wasm_stencil.h','inline bool Function::ByteStencilLoop(ForLoop *loop, const Slot &binding, TypeExpr *ct, uint32_t lo, uint32_t hi) {\n','    return false;\n'),
}

KEYS=('CMAKE_C_COMPILER','CMAKE_CXX_COMPILER','CMAKE_C_FLAGS','CMAKE_CXX_FLAGS',
      'CMAKE_C_FLAGS_RELEASE','CMAKE_CXX_FLAGS_RELEASE','CMAKE_EXE_LINKER_FLAGS','CMAKE_BUILD_TYPE','CMAKE_GENERATOR')

def control_root(name):
    if name=='stride':return HERE.parent/'count-only'
    return HERE/(name+'-control')


def load(path):return json.loads(Path(path).read_bytes())


def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


def require(value,message):
    if not value:raise RuntimeError(message)


def save(path,value):
    require(not path.exists(),'refusing to replace '+str(path))
    path.write_text(json.dumps(value,indent=2)+'\n')


def cache(path):
    rows={}
    for line in path.read_text().splitlines():
        if line.startswith(('#','//')) or '=' not in line or ':' not in line:continue
        name,value=line.split('=',1);rows[name.split(':',1)[0]]=value
    require(all(name in rows for name in KEYS),'incomplete CMake compiler configuration')
    return {name:rows[name] for name in KEYS}


def prepare(args,folder):
    selected=args.selected_root.resolve();shadow=folder/'shadow'
    require(not folder.exists(),'preserve prior control and use a new output directory')
    source=load(selected/'source.json');toolchain=load(selected/'toolchain.json')
    require(source['headers']==toolchain['headers'] and source['patches']==toolchain['patches'],'selected source metadata differs')
    require(source['headers'] and source['patches'],'selected source inventory is empty')
    require(sha(selected/'bin/goose')==toolchain['compiler_sha256'],'selected compiler differs')
    settings=cache(args.selected_cache)
    require(settings['CMAKE_GENERATOR']=='Ninja' and settings['CMAKE_BUILD_TYPE']=='Release','selected build must be Ninja Release')
    require(settings['CMAKE_C_FLAGS_RELEASE']==settings['CMAKE_CXX_FLAGS_RELEASE']=='-O3 -DNDEBUG','unexpected Release flags')
    require(all('clang' in Path(settings[name]).name for name in ('CMAKE_C_COMPILER','CMAKE_CXX_COMPILER')),'control requires selected Clang toolchain')
    shadow.mkdir(parents=True);inputs={}
    def copy(original,relative,expected):
        require(sha(original)==expected,'source differs: '+str(original))
        target=shadow/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(original,target)
        inputs[str(target)]=expected
    for name,expected in source['headers'].items():copy(selected/'compiler'/name,'compiler/'+name,expected)
    for name,expected in source['patches'].items():
        original=selected/name
        if not original.is_file():original=ROOT/name
        copy(original,name,expected)
    for name in ('scripts/bootstrap.py','toolchain.json'):copy(ROOT/name,name,sha(ROOT/name))
    header,marker,inserted=CONTROLS[args.control]
    path=shadow/'compiler'/header;before=path.read_text()
    require(before.count(marker)==1,'control predicate marker differs')
    after=before.replace(marker,marker+inserted,1);path.write_text(after)
    (folder/'before.h').write_text(before)
    (folder/'disable.patch').write_text(''.join(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),
        fromfile='a/compiler/'+header,tofile='b/compiler/'+header)))
    inputs[str(path)]=sha(path)
    command=[sys.executable,str(shadow/'scripts/bootstrap.py'),'--build-dir',str(folder/'build'),
             '--source-repo',str(args.source_repo.resolve()),'--generator','Ninja','--jobs','2']
    environment={'CC':settings['CMAKE_C_COMPILER'],'CXX':settings['CMAKE_CXX_COMPILER'],
                 'CFLAGS':settings['CMAKE_C_FLAGS'],'CXXFLAGS':settings['CMAKE_CXX_FLAGS'],'LDFLAGS':settings['CMAKE_EXE_LINKER_FLAGS']}
    save(folder/'preparation.json',{'status':'prepared','control':args.control,'selected_root':str(selected),
        'selected_compiler_sha256':toolchain['compiler_sha256'],'header_count':len(source['headers']),
        'patch_count':len(source['patches']),'changed_header':header,'before_sha256':sha(folder/'before.h'),
        'after_sha256':sha(path),'input_sha256':inputs,'selected_cmake':settings,'command':command,'environment':environment})
    print('PREPARED',args.control,len(source['headers']),'headers; no build executed',flush=True)


def match(folder):
    record=load(folder/'preparation.json');selected=Path(record['selected_root']);current=load(selected/'toolchain.json')
    control=load(folder/'build/toolchain.json');source=load(folder/'build/source.json')
    require(current['compiler_sha256']==record['selected_compiler_sha256'],'selected compiler metadata changed')
    require(control['headers']==source['headers'] and control['patches']==source['patches'],'control metadata differs')
    require(set(current['headers'])==set(control['headers']) and len(control['headers'])==record['header_count'],'control inventory differs')
    changed={name for name,expected in current['headers'].items() if control['headers'][name]!=expected}
    require(changed=={record['changed_header']},'control changes unrelated headers')
    require(control['headers'][record['changed_header']]==record['after_sha256'],'control predicate differs')
    require(control['revision']==current['revision'] and control['patches']==current['patches'],'control upstream/patches differ')
    settings=cache(folder/'build/native/CMakeCache.txt');require(settings==record['selected_cmake'],'control compiler flags differ')
    target=folder/'build/compiler';target.mkdir(exist_ok=True)
    for name,expected in control['headers'].items():
        original=folder/'shadow/compiler'/name;require(sha(original)==expected,'compiled control header differs')
        shutil.copyfile(original,target/name)
    require(sha(folder/'build/bin/goose')==control['compiler_sha256'],'control binary differs')
    proof={'status':'matched','control':record['control'],
        'selected_compiler_sha256':current['compiler_sha256'],'control_compiler_sha256':control['compiler_sha256'],
        'changed_headers':sorted(changed),'header_count':len(control['headers']),'patch_count':len(control['patches']),
        'selected_cmake':record['selected_cmake'],'control_cmake':settings,
        'compiler_tool_sha256':{settings[name]:sha(settings[name]) for name in ('CMAKE_C_COMPILER','CMAKE_CXX_COMPILER')}}
    path=folder/'build/control-toolchain-match.json'
    if path.exists():require(load(path)==proof,'existing matched proof differs')
    else:save(path,proof)
    print('CONTROL READY',record['control'],control['compiler_sha256'],flush=True)


def build(folder):
    record=load(folder/'preparation.json')
    require(not (folder/'build-execution.json').exists(),'preserve prior control build before retrying')
    require(all(sha(path)==expected for path,expected in record['input_sha256'].items()),'prepared control source changed')
    environment=os.environ.copy();environment.update(record['environment']);started=time.monotonic()
    with (folder/'build.log').open('w') as stream:result=subprocess.run(record['command'],cwd=ROOT,env=environment,stdout=stream,stderr=subprocess.STDOUT)
    save(folder/'build-execution.json',{'command':record['command'],'environment':record['environment'],
        'exit_status':result.returncode,'wall_seconds':time.monotonic()-started,'measurement':False})
    require(result.returncode==0,'control build failed; inspect preserved log');match(folder)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('phase',choices=['prepare','build','match'])
    parser.add_argument('--control',choices=CONTROLS,required=True)
    parser.add_argument('--selected-root',type=Path,required=True)
    parser.add_argument('--selected-cache',type=Path,required=True)
    parser.add_argument('--source-repo',type=Path,default=ROOT/'build/source');parser.add_argument('--output',type=Path)
    args=parser.parse_args();folder=args.output
    if folder is None:folder=control_root(args.control)
    folder=folder.resolve()
    if args.phase=='prepare':prepare(args,folder)
    elif args.phase=='build':build(folder)
    else:match(folder)


if __name__=='__main__':main()
