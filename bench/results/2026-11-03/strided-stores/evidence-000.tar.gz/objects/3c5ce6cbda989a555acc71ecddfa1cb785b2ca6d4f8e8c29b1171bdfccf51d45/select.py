"""Select the two independent loop lowerings from frozen factorial rounds."""
from pathlib import Path
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
BUILD=ROOT/'build/stride-hills'
FINAL='f76ea0f4bfa57949f5b04d42884f8316546a7eb50720b31e564afafcad9a0af8'
BASELINE='b53aaf097e0ea47b3f3efea158db3520aa03f9ab1fb1625efd21fff31d49319d'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

out=BUILD/'campaign-selection.json'
assert not out.exists(), 'Preserve previous decisions.'
reports={engine:BUILD/('factorial-'+engine)/'report.json' for engine in ('wasmtime','v8')}
selection={
    'schema':'goose-strided-stores-selection-v1','status':'selected',
    'selected_root':str(BUILD/'final'),'selected_compiler_sha256':FINAL,
    'baseline_root':str(ROOT/'build/next-hills/final'),'baseline_compiler_sha256':BASELINE,
    'scope':'Guarded constant integer stores group four ordered positive-stride writes. Guarded byte equality reductions count selected stride lanes and remember the last matching index with SIMD128. Both retain original scalar tails and failed-guard/debug behavior.',
    'criteria':'At least 5% repeated improvement on the affected unchanged workload, both engines checked, investigate control regressions over 3%. Full correctness and fresh delivery cohorts required before publication.',
    'decision':'Keep both lowerings: the combination improves Sieve materially over baseline and over either change alone on both engines. Grouping alone helps V8 but is flat/slightly slower on Wasmtime. The combination interaction is measured; no hardware cause is established.',
    'factorial':{},'input_sha256':{str(path):sha(path) for path in reports.values()},
    'retained_experiments':[
        'four: grouping only; initial matched-control screen and both later factorials retained.',
        'count-only: SIMD scan with grouping disabled; both factorials retained.',
        'combined: selected compiler, complete source snapshot and matched controls retained.',
        'development/attempt-1: unbuilt C++ scope error; no engine/performance result.',
        'test-development: illegal indexed-varint fixture failure and legal corrected reruns retained.',
        'scan-tests: host ARG_MAX setup failure before any engine cases and corrected runs retained.'
    ],
    'qualification_status':'Pending complete 76-command gates, differential/native/host/worker matrices and six fresh delivery cohorts.'
}
for engine,path in reports.items():
    report=json.loads(path.read_bytes())
    assert report['status']=='passed' and not report['failures'] and report['coverage_exact']
    assert report['input_sha256']==report['input_sha256_after']
    assert len(report['observations'])==72
    assert report['compilers']['baseline']['sha256']==BASELINE
    assert report['compilers']['combined']['sha256']==FINAL
    summaries={row['task']:row for row in report['summary']}
    row=summaries['Etc::Sieve']
    pairs={(p['numerator'],p['denominator']):p['ratio'] for p in row['paired_ratios']}
    assert pairs['baseline','combined']['median']>=1.05
    assert pairs['counted','combined']['median']>=1.05
    for task in ('Sort::Merge','Example::Sorting'):
        artifacts=report['artifacts'][task]
        assert len({a['sha256'] for a in artifacts.values()})==1
    selection['factorial'][engine]={'report_sha256':sha(path),'tasks':report['summary'],
        'checksums_qualified':True,'input_pins_unchanged':True,'unrelated_control_guests_identical':True}
old=json.loads((BUILD/'screen-wasmtime/report.json').read_bytes())
new=json.loads(reports['wasmtime'].read_bytes())
assert old['artifacts']['Etc::Sieve']['candidate']['sha256']==new['artifacts']['Etc::Sieve']['grouped']['sha256']
final=json.loads((BUILD/'final/toolchain.json').read_bytes())
assert final['compiler_sha256']==FINAL and len(final['headers'])==36 and len(final['patches'])==2
assert sha(BUILD/'final/bin/goose')==sha(ROOT/'build/bin/goose')==FINAL
out.write_text(json.dumps(selection,indent=2)+'\n')
print('Selected combined f76; both factorials and unchanged control guests verified.')
