#!/usr/bin/env python3
"""Audit retained first-screen numbers and machine evidence; runs no engines."""
import datetime
import hashlib
import json
import math
from pathlib import Path
import statistics

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent


def pin(path):
    path = Path(path)
    if not path.is_absolute():
        path = ROOT / path
    return dict(path=str(path.relative_to(ROOT)),
                sha256=hashlib.sha256(path.read_bytes()).hexdigest(), bytes=path.stat().st_size)


def stats(values):
    middle = statistics.median(values)
    return dict(n=len(values), median=middle,
                mad=statistics.median(abs(value-middle) for value in values), samples=values)


def same(actual, expected):
    assert math.isclose(actual, expected, rel_tol=1e-12, abs_tol=1e-15), (actual, expected)


screens = []
artifacts = None
for engine in ['wasmtime', 'v8']:
    report_path = ROOT / 'build/stride-hills' / ('screen-' + engine) / 'report.json'
    report = json.loads(report_path.read_text())
    assert report['status'] == 'passed' and not report['failures']
    assert report['input_sha256'] == report['input_sha256_after']
    rows = report['observations']
    assert len(rows) == 54
    assert all(row['checksum'] == row['expected_checksum'] and row['revision_exit'] == 0 for row in rows)
    measured = [row for row in rows if row['phase'] == 'measure']
    assert len(measured) == 45
    tasks = []
    for published in report['summary']:
        name = published['task']
        timings = {}
        for variant in ['baseline', 'control', 'candidate']:
            selected = sorted([row for row in measured if row['task'] == name and row['variant'] == variant],
                              key=lambda row: row['round'])
            assert [row['round'] for row in selected] == list(range(5))
            values = [row['timed_region_seconds'] for row in selected]
            timings[variant] = stats(values)
            for field in ['median', 'mad']:
                same(timings[variant][field], published['times'][variant][field])
            assert values == published['times'][variant]['samples']
        ratios = []
        for published_ratio in published['paired_ratios']:
            a = published_ratio['numerator']
            b = published_ratio['denominator']
            values = [x/y for x, y in zip(timings[a]['samples'], timings[b]['samples'], strict=True)]
            result = stats(values)
            for field in ['median', 'mad']:
                same(result[field], published_ratio['ratio'][field])
            ratios.append(dict(numerator=a, denominator=b, ratio=result))
        guests = {variant: report['artifacts'][name][variant]['sha256'] for variant in timings}
        assert guests['baseline'] == guests['control']
        if name != 'Etc::Sieve':
            assert guests['baseline'] == guests['candidate']
        tasks.append(dict(task=name, seconds=timings, paired_ratios=ratios, guest_sha256=guests))
    screen = dict(engine=engine, report=pin(report_path), configuration=report['configuration'],
                  observations=54, measured=45, qualifier=9, tasks=tasks,
                  input_pins_unchanged=True, compilers=report['compilers'])
    if engine == 'wasmtime':
        screen['host_build'] = report['host_build']
        artifacts = report['artifacts']['Etc::Sieve']
    else:
        screen['v8'] = report['v8']
        screen['runtime_engine'] = report['runtime_engine']
    screens.append(screen)

machine_artifacts = {}
for variant, stem in [('baseline', 'baseline'), ('candidate', 'group4')]:
    recorded = artifacts[variant]
    aot = pin(recorded['aot_path'])
    wasm = pin(recorded['path'])
    assert aot['sha256'] == recorded['aot_sha256']
    assert wasm['sha256'] == recorded['sha256']
    machine_artifacts[variant] = dict(aot=aot, wasm=wasm,
        compiler_sha256=recorded['compiler_sha256'],
        disassembly=pin(HERE / 'grouped-machine' / (stem + '-aot.txt')))

result = dict(schema='goose-grouped-stores-machine-screen-review-v1', status='passed',
    created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), reviewer='astra_campaign',
    method='Read retained first-screen reports, independently recompute five-round medians/MAD and paired ratios; llvm-objdump -d of exact retained AOT artifacts. No builds, engines, tests or timing runs.',
    reproduction=pin(__file__), screens=screens, artifacts=machine_artifacts,
    symbol='wasm[0]::function[14]::run#3',
    machine_findings=[
        dict(region='baseline 0x5da..0x5f2', finding='Seven instructions per scalar store: cmp, conditional exit, zero register, address LEA, store8, cursor add, unconditional backedge. No language bounds check in this loop.'),
        dict(region='candidate 0x66d..0x6b2', finding='Four ordered scalar store8 instructions in fourteen static instructions: one zero-register instruction, seven LEAs, four stores, one compare and one conditional backedge. No per-store or per-group multiply occurs inside this loop.'),
        dict(region='candidate 0x654 and0x669', finding='Two multiply-by3 instructions compute group offsets before the hot group loop. Both are setup, not repeated hot-loop multiplies.'),
        dict(region='candidate 0x5fb..0x663', finding='Guard and group setup are added per eligible marking loop; original scalar tail remains0x6b8..0x6d3.'),
        dict(region='run#3 prologue and loops', finding='Both variants reserve0x30 native stack bytes; neither marking hot loop has stack spills. Register assignments and surrounding code placement change.'),
        dict(region='Wasm module', finding='Sieve grows3098 to3325 bytes (+227). Merge and insertion control guest bytes are unchanged in both screens.')
    ],
    interpretation=[
        'The generated Wasmtime code performs the intended branch amortization. It does not support the hypothesis that per-store multiplies erased the gain.',
        'Wasmtime first-screen paired speedup is near1 with a small observed loss; V8 shows a material roughly14% speedup. Static instruction counts do not establish causes for either measured percentage.',
        'No hardware counters, phase attribution or V8 native disassembly were collected. Do not describe this evidence as proving a memory-bound loop, a register-allocation regression, or a V8 tier change.',
        'Retain group4 as a candidate for baseline/group4/count-only/combined factorial confirmation; this initial screen is not final production selection.'
    ])
out = HERE / 'grouped-machine.json'
assert not out.exists()
out.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(pin(out)))
