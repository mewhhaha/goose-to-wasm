"""Analyze existing measured guest bytes after the timing window closes."""
from pathlib import Path
import hashlib,json,subprocess
ROOT=Path(__file__).resolve().parents[2];BUILD=ROOT/'build/stride-hills'
def load(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def shape(path,stats,label,out):
 text=subprocess.check_output(['llvm-objdump','-d',str(path)],text=True)
 target=out/(label+'.disassembly');target.write_text(text)
 return {'wasm':str(path),'sha256':sha(path),'bytes':path.stat().st_size,'static_memory_copy':text.count('memory.copy'),'static_widened_loads':text.count('i16x8.load8x8_u')+text.count('v128.load8x8_u'),'disassembly':str(target),'disassembly_sha256':sha(target),'functions':[{k:f[k]for k in ['name','index','code_bytes','body_hash']}for f in stats['function_info']]}
def main():
 previous=ROOT/'bench/results/2026-11-03/merge-bounds/examples.json';old=load(previous)
 current=BUILD/'current/examples/report.json';new=load(current)
 warmed_path=BUILD/'delivered-warmed/report.json';warmed=load(warmed_path)
 out=BUILD/'module-analysis';out.mkdir(exist_ok=True)
 result={'schema':'goose-strided-store-module-analysis-v1','status':'passed','method':'Existing measured unchanged-source O2 modules and compiler statistics; no extra compilations. Static counts are not dynamic operation counts. Full Sieve and its adapted timed kernel remain distinct unchanged workloads.','source_reports':{str(p):sha(p)for p in [previous,current,warmed_path]},'compiler_sha256':new['environment']['compiler_sha256'],'baseline_compiler_sha256':old['environment']['compiler_sha256'],'examples':[],'warmed':[]}
 for case in new['examples']:
  name=case['name'];row={'task':name}
  for label,report in [('baseline',old),('final',new)]:
   entry=next(r for r in report['observations']if r['kind']=='build'and r['name']==name and r['backend']=='direct'and r['sample']==0)
   path=Path(entry['artifact']);assert entry['status']=='passed'and sha(path)==entry['artifact_sha256']==entry['driver_stats']['module_sha256']
   row[label]=shape(path,entry['driver_stats']['backend_stats'],name+'-'+label,out)
  row['bytes_delta']=row['final']['bytes']-row['baseline']['bytes'];row['byte_identical']=row['final']['sha256']==row['baseline']['sha256'];result['examples'].append(row)
 for name in warmed['artifacts']:
  row={'task':name}
  for label in ['baseline','final']:
   entry=warmed['artifacts'][name][label];path=Path(entry['path']);stats=Path(entry['stats_path'])
   assert sha(path)==entry['sha256']and sha(stats)==entry['stats_sha256']
   row[label]=shape(path,load(stats),name.replace('::','-')+'-'+label,out)
  row['bytes_delta']=row['final']['bytes']-row['baseline']['bytes'];row['byte_identical']=row['final']['sha256']==row['baseline']['sha256'];result['warmed'].append(row)
 (BUILD/'module-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
if __name__=='__main__':main()
