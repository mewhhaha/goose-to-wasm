from pathlib import Path
import hashlib,json,os,random,statistics,sys,time
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.wasmtime_session import RuntimeSession
OUT=ROOT/'build/next-hills/worker-pre-screen';OUT.mkdir(exist_ok=True)
assert not(OUT/'report.json').exists()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def summary(xs):
 m=statistics.median(xs);return {'n':len(xs),'median':m,'mad':statistics.median(abs(x-m)for x in xs),'samples':xs}
hosts={'baseline':ROOT/'build/next-hills/host-pre/baseline/goose-wasmtime','candidate':ROOT/'build/next-hills/host-pre/goose-wasmtime'}
source=ROOT/'bench/results/2026-11-03/runtime-stencil/examples.json';prior=json.loads(source.read_bytes())
artifacts={x['name']:Path(x['artifact'])for x in prior['observations']if x['kind']=='build'and x['backend']=='direct'and x['sample']==0}
pins={str(p):sha(p)for p in [*hosts.values(),source,Path(__file__),ROOT/'scripts/wasmtime_session.py',*artifacts.values()]}
old=sorted(os.sched_getaffinity(0));assert 2 in old;os.sched_setaffinity(0,{2})
rng=random.Random(9211);rows=[];results={};sessions={}
try:
 for v,h in hosts.items():sessions[v]=RuntimeSession(h)
 names=list(artifacts);rng.shuffle(names)
 for name in names:
  expected=(ROOT/'examples/expected'/(name+'.out')).read_bytes();n=31
  if name=='functions':n=201
  for i in range(n+3):
   order=list(hosts);rng.shuffle(order)
   for v in order:
    started=time.perf_counter_ns();r=sessions[v].run(artifacts[name]);wall=time.perf_counter_ns()-started
    assert r.returncode==0 and r.stdout==expected and not r.stderr
    if i:assert r.module_cache_hit
    rows.append({'name':name,'variant':v,'round':i-3,'phase':'measure'if i>=3 else'qualify','wall_ns':wall,'prepare_ns':r.prepare_ns,'start_ns':r.start_ns,'module_cache_hit':r.module_cache_hit,'returncode':r.returncode,'stdout':r.stdout.decode(),'stderr':r.stderr.decode()})
  measured=[r for r in rows if r['name']==name and r['phase']=='measure'];indexed={(r['round'],r['variant']):r for r in measured}
  result={metric:{v:summary([r[metric]for r in measured if r['variant']==v])for v in hosts}for metric in ['wall_ns','prepare_ns','start_ns']}
  result['paired_speedup']={metric:summary([indexed[i,'baseline'][metric]/indexed[i,'candidate'][metric]for i in range(n)])for metric in ['wall_ns','prepare_ns','start_ns']}
  results[name]=result;print(name,round(result['paired_speedup']['wall_ns']['median'],4),round(result['paired_speedup']['prepare_ns']['median'],4),flush=True)
finally:
 for s in sessions.values():s.close()
 os.sched_setaffinity(0,set(old))
assert all(sha(Path(p))==h for p,h in pins.items())
report={'status':'passed','method':'CPU2 paired randomized serial requests, existing compiled module in each of two resident hosts, fresh State/Store/instance each request; process startup excluded. Three warmup/qualification requests per example and variant.31pairs each except201Functions. Native/CWasm unchanged guest bytes.','hosts':{v:{'path':str(h),'sha256':sha(h),'metadata':json.loads(h.with_suffix('.json').read_bytes())}for v,h in hosts.items()},'input_sha256':pins,'affinity':[2],'observations':rows,'summary':results}
(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
