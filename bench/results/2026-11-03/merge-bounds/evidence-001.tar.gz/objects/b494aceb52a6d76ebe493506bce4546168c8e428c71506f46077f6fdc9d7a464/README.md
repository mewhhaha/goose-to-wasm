# Example program benchmarks

Status: **passed**.

2026-11-03 · AMD Ryzen 7 3800X, shared desktop host.

Goose O2. Direct Wasm uses memory32; C-Wasm uses memory64. The selected programs, their constant inputs and all printing are unchanged from the [example catalog](../../../../examples/README.md). Compiler constant folding is allowed.

Builds are complete uncached Python-driver invocations, including any C compilation/linking. OS page caches and Emscripten's installed system-library cache remain warm.

Runtime is **whole-process launch-to-exit time**, including host startup, Wasm compilation/instantiation, program initialization, computation, output delivery and teardown. Each observation starts a fresh process/instance and calls the entrypoint once. This measures CLI cost, not warmed kernel throughput.

Each cell has 5 build samples or 15 runtime samples. Untimed fresh-process warmups per runtime cell: 1. Orders are shuffled with the recorded seed; builds and runtime never overlap. Every used artifact must pass its golden output. Values are median milliseconds ± median absolute deviation (MAD).

Headline runtime samples use the ordinary runners without timing-file instrumentation. The Wasm supplements use a separate shuffled set of fresh processes, with the same sample count; timing files are written after their engine intervals end.

## Compilation

| Example | Direct | C-Wasm | Native C |
| --- | ---: | ---: | ---: |
| squares | 62.259 ±1.292 | 539.480 ±25.287 | 187.287 ±0.807 |
| tour | 64.204 ±1.065 | 897.335 ±7.283 | 408.075 ±4.456 |
| functions | 98.826 ±8.294 | 870.258 ±29.645 | 490.666 ±5.845 |
| errors | 74.260 ±5.894 | 703.892 ±18.492 | 343.396 ±4.852 |
| sieve | 66.655 ±0.497 | 540.017 ±10.193 | 273.196 ±31.815 |
| sorting | 88.855 ±4.442 | 838.874 ±12.911 | 542.505 ±17.314 |
| sudoku | 68.007 ±0.725 | 512.219 ±11.327 | 267.632 ±6.880 |
| maze | 71.026 ±0.285 | 656.446 ±27.198 | 354.916 ±6.133 |
| vm | 73.317 ±5.597 | 696.571 ±34.287 | 285.767 ±3.246 |
| life | 68.382 ±0.512 | 591.720 ±8.430 | 297.749 ±9.223 |

## Whole-process runtime

| Example | Direct / V8 | C-Wasm / V8 | Direct / Wasmtime | C-Wasm / Wasmtime | Native C |
| --- | ---: | ---: | ---: | ---: | ---: |
| squares | 25.429 ±1.113 | 30.298 ±4.784 | 69.906 ±1.882 | 81.766 ±2.898 | 0.846 ±0.089 |
| tour | 46.717 ±5.741 | 39.924 ±7.075 | 124.272 ±19.595 | 108.105 ±7.075 | 1.095 ±0.239 |
| functions | 31.835 ±2.026 | 31.560 ±2.419 | 104.643 ±13.371 | 104.814 ±4.683 | 1.164 ±0.240 |
| errors | 28.977 ±2.935 | 28.074 ±1.678 | 83.620 ±6.170 | 103.058 ±13.043 | 1.219 ±0.087 |
| sieve | 39.637 ±8.302 | 39.507 ±8.360 | 77.237 ±2.652 | 92.041 ±11.631 | 1.564 ±0.240 |
| sorting | 64.729 ±6.104 | 235.344 ±6.617 | 117.061 ±13.056 | 244.850 ±17.810 | 47.083 ±1.240 |
| sudoku | 43.920 ±12.084 | 33.997 ±2.917 | 83.955 ±8.544 | 95.690 ±7.102 | 4.555 ±0.499 |
| maze | 29.876 ±1.976 | 29.950 ±2.889 | 83.647 ±3.820 | 89.727 ±4.647 | 1.110 ±0.225 |
| vm | 30.921 ±4.244 | 30.431 ±2.236 | 97.663 ±10.383 | 94.933 ±7.512 | 1.169 ±0.167 |
| life | 38.941 ±5.458 | 49.515 ±11.279 | 93.429 ±12.077 | 101.438 ±8.982 | 27.403 ±8.190 |

## Supplement: Wasm entrypoint

| Example | Direct / V8 | C-Wasm / V8 | Direct / Wasmtime | C-Wasm / Wasmtime |
| --- | ---: | ---: | ---: | ---: |
| squares | 0.178 ±0.019 | 0.965 ±0.045 | 0.134 ±0.005 | 0.648 ±0.006 |
| tour | 14.288 ±0.857 | 2.721 ±0.076 | 1.775 ±0.013 | 1.744 ±0.013 |
| functions | 5.514 ±0.818 | 2.709 ±0.129 | 1.366 ±0.008 | 1.967 ±0.026 |
| errors | 1.552 ±0.046 | 1.768 ±0.053 | 0.870 ±0.019 | 1.764 ±0.028 |
| sieve | 3.323 ±1.031 | 3.094 ±1.261 | 1.231 ±0.017 | 1.384 ±0.021 |
| sorting | 22.898 ±2.011 | 206.734 ±4.257 | 15.544 ±0.210 | 130.892 ±1.045 |
| sudoku | 5.377 ±0.140 | 6.532 ±0.254 | 3.872 ±0.031 | 8.544 ±0.062 |
| maze | 2.346 ±0.067 | 2.102 ±0.220 | 0.789 ±0.016 | 2.272 ±0.025 |
| vm | 3.026 ±0.308 | 2.273 ±0.157 | 0.933 ±0.012 | 3.054 ±0.036 |
| life | 5.185 ±1.082 | 9.958 ±0.202 | 2.844 ±0.027 | 9.797 ±0.080 |

## Supplement: Wasm engine compilation and instantiation

| Example | Direct / V8 | C-Wasm / V8 | Direct / Wasmtime | C-Wasm / Wasmtime |
| --- | ---: | ---: | ---: | ---: |
| squares | 0.258 ±0.044 | 0.517 ±0.062 | 2.856 ±0.101 | 10.404 ±0.538 |
| tour | 0.401 ±0.053 | 0.537 ±0.066 | 33.741 ±3.521 | 32.159 ±1.081 |
| functions | 0.362 ±0.047 | 0.550 ±0.065 | 23.563 ±6.071 | 28.330 ±0.769 |
| errors | 0.301 ±0.030 | 0.569 ±0.062 | 10.084 ±1.313 | 15.196 ±1.521 |
| sieve | 0.264 ±0.040 | 0.616 ±0.034 | 7.369 ±1.475 | 12.344 ±0.604 |
| sorting | 0.355 ±0.037 | 0.615 ±0.085 | 16.308 ±1.187 | 30.986 ±1.103 |
| sudoku | 0.270 ±0.025 | 0.527 ±0.039 | 5.501 ±0.249 | 11.504 ±0.637 |
| maze | 0.304 ±0.034 | 0.637 ±0.097 | 11.562 ±1.282 | 16.517 ±1.543 |
| vm | 0.303 ±0.052 | 0.577 ±0.054 | 16.748 ±1.901 | 17.782 ±2.486 |
| life | 0.283 ±0.030 | 0.579 ±0.098 | 12.319 ±0.408 | 14.283 ±1.289 |

The entrypoint interval includes Goose initialization, host output callbacks and any lazy JIT work. It excludes final Wasm-host output concatenation/delivery. Native Goose prints unbuffered, so no native entrypoint column or cross-boundary speedup is presented. Process time minus engine time also includes loading, bookkeeping and teardown; it is not a pure startup measurement.

These fresh-process examples have different timing rules from LangArena's warmed computational regions. Raw samples, commands, artifact/source/compiler identities and engine versions are in [report.json](report.json). [Method and reproduction](../../../examples.md).
