"""Read-only independent postmeasurement arithmetic and identity audit."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import itertools
import json
import math
import statistics

ROOT = Path(__file__).resolve().parents[3]
BUILD = ROOT / 'build/next-hills'
OUT = Path(__file__).resolve().parent


def load(path):
    return json.loads(Path(path).read_bytes())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def pin(path):
    return {'path': str(Path(path).relative_to(ROOT)), 'sha256': sha(path)}


checked = 0


def check(values, recorded):
    global checked
    assert values and all(math.isfinite(x) for x in values)
    mid = statistics.median(values)
    assert recorded['n'] == len(values)
    assert recorded['median'] == mid
    assert recorded['mad'] == statistics.median(abs(x - mid) for x in values)
    assert recorded['samples'] == values
    for key, value in [('min', min(values)), ('max', max(values))]:
        if key in recorded:
            assert recorded[key] == value
    ordered = sorted(values)
    for key, fraction in [('p25', .25), ('p75', .75)]:
        at = (len(values) - 1) * fraction
        lo, hi = math.floor(at), math.ceil(at)
        value = ordered[lo] + (ordered[hi] - ordered[lo]) * (at - lo)
        if key in recorded:
            assert math.isclose(recorded[key], value, rel_tol=1e-14, abs_tol=1e-15)
    checked += 1


paths = {
    'wasmtime': 'delivered-warmed/report.json', 'v8': 'delivered-v8/report.json',
    'examples': 'current/examples/report.json', 'host': 'current/host/report.json',
    'langarena': 'current/langarena/report.json', 'lifecycle': 'current/lifecycle/report.json',
}
reports = {name: load(BUILD / path) for name, path in paths.items()}
selected = 'b53aaf097e0ea47b3f3efea158db3520aa03f9ab1fb1625efd21fff31d49319d'
baseline = '1b1ec504894d387ae0bbed287d2d3214e250e6dc9bbff2ffd2893a69c06a8874'
delivery = load(BUILD / 'delivery-execution/report.json')
assert delivery['status'] == 'passed' and delivery['compiler_sha256'] == selected
assert delivery['input_sha256'] == delivery['input_sha256_after']
assert len(delivery['phases']) == 6
assert {Path(p['report']).resolve() for p in delivery['phases']} == {(BUILD / p).resolve() for p in paths.values()}
for p in delivery['phases']:
    assert p['status'] == 'passed' and p['exit_status'] == 0
    assert sha(p['report']) == p['report_sha256']
    assert sha(BUILD / 'delivery-execution' / (p['name'] + '.stdout')) == p['stdout_sha256']
    assert sha(BUILD / 'delivery-execution' / (p['name'] + '.stderr')) == p['stderr_sha256']
for report in reports.values():
    assert report['status'] == 'passed' and not report.get('failures')

findings = {}
for engine in ['wasmtime', 'v8']:
    r = reports[engine]
    assert r['configuration']['samples'] == 9 and r['input_sha256'] == r['input_sha256_after']
    assert r['compilers']['baseline']['sha256'] == baseline and r['compilers']['final']['sha256'] == selected
    assert set(r['compilers']) == {'baseline', 'final'}
    indexed = {(x['task'], x['variant'], x['round']): x['timed_region_seconds']
               for x in r['observations'] if x['phase'] == 'measure'}
    expected = {(t, v, phase, i) for t, variants in r['artifacts'].items() for v in variants
                for phase, n in [('qualify', 1), ('measure', 9)] for i in range(n)}
    actual = [(x['task'], x['variant'], x['phase'], x['round']) for x in r['observations']]
    assert len(actual) == len(set(actual)) and set(actual) == expected
    for x in r['observations']:
        assert x['checksum'] == x['expected_checksum'] and x['runtime_affinity'] == [2]
        lines = (Path(x['log_directory']) / 'stdout.txt').read_text().splitlines()
        assert len(lines) == 2 and int(lines[0]) == x['checksum']
        assert int(lines[1]) / 1e9 == x['timed_region_seconds']
    task_findings = []
    for row in r['summary']:
        task = row['task']
        variants = list(r['artifacts'][task])
        for v in variants:
            check([indexed[task, v, i] for i in range(9)], row['times'][v])
        assert {(x['numerator'], x['denominator']) for x in row['paired_ratios']} == set(itertools.combinations(variants, 2))
        for p in row['paired_ratios']:
            values = [indexed[task, p['numerator'], i] / indexed[task, p['denominator'], i] for i in range(9)]
            assert p['per_round'] == [{'round': i, 'ratio': v} for i, v in enumerate(values)]
            check(values, p['ratio'])
        for v in ['baseline', 'final']:
            artifact = r['artifacts'][task][v]
            assert sha(artifact['path']) == artifact['sha256']
            if engine == 'wasmtime':
                assert sha(artifact['aot_path']) == artifact['aot_sha256']
        paired = next(p['ratio'] for p in row['paired_ratios'] if p['numerator'] == 'baseline' and p['denominator'] == 'final')
        task_findings.append({'task': task, 'baseline_ms': row['times']['baseline']['median'] * 1000,
                              'final_ms': row['times']['final']['median'] * 1000,
                              'paired_speedup': paired['median'], 'mad': paired['mad'],
                              'guest_identical': r['artifacts'][task]['baseline']['sha256'] == r['artifacts'][task]['final']['sha256']})
    for g in r['geometric_ratios']:
        values = []
        for i in range(9):
            ratios = []
            for task in g['tasks']:
                target = g['denominator']
                if g['kind'] == 'reference_role':
                    target = r['reference_roles'][task][target]
                ratios.append(indexed[task, g['numerator'], i] / indexed[task, target, i])
            values.append(math.exp(sum(map(math.log, ratios)) / len(ratios)))
        assert g['per_round'] == [{'round': i, 'ratio': v} for i, v in enumerate(values)]
        check(values, g['ratio'])
    assert sum(x['guest_identical'] for x in task_findings) == 9
    findings[engine] = {'tasks': task_findings, 'host_sha256': r['host_build']['host_sha256']}

ex, host, arena, lifecycle = [reports[k] for k in ['examples', 'host', 'langarena', 'lifecycle']]
for r, count in [(ex, 1600), (host, 1440), (arena, 315), (lifecycle, 960)]:
    assert len(r['observations']) == count
for row in ex['compile_summary']:
    rows = [x for x in ex['observations'] if x['kind'] == 'build' and x['name'] == row['name'] and x['backend'] == row['backend']]
    check([x['wall_seconds'] for x in rows], row['wall_seconds'])
for row in ex['runtime_summary']:
    rows = [x for x in ex['observations'] if x['kind'] == 'execution' and all(x[k] == row[k] for k in ['name', 'backend', 'engine'])]
    check([x['process_wall_seconds'] for x in rows if x['phase'] == 'measure'], row['process_wall_seconds'])
    if row['engine'] != 'native':
        for metric, raw in [('entry_function_seconds', 'start_function_ns'), ('engine_compile_instantiate_seconds', 'compile_instantiate_ns')]:
            check([x['wasm_timing'][raw] / 1e9 for x in rows if x['phase'] == 'measure-engine'], row[metric])
for row in host['runtime_summary']:
    values = [x['wall_seconds'] for x in host['observations'] if x['phase'] == 'measure' and all(x[k] == row[k] for k in ['name', 'backend', 'mode'])]
    check(values, row['wall_seconds'])
assert len(host['preparation']) == 200
for row in host['preparation_summary']:
    check([x['wall_seconds'] for x in host['preparation'] if all(x[k] == row[k] for k in ['name', 'backend', 'configuration'])], row['wall_seconds'])
for row in arena['compile_summary']:
    check([x['wall_seconds'] for x in arena['observations'] if x['kind'] == 'build' and all(x[k] == row[k] for k in ['track', 'task', 'backend', 'phase'])], row['wall_seconds'])
for row in arena['runtime_summary']:
    rows = [x for x in arena['observations'] if x['kind'] == 'execution' and all(x[k] == row[k] for k in ['track', 'task', 'backend', 'engine', 'profile'])]
    for metric, raw in [('timed_region_seconds', 'timed_region_seconds'), ('process_wall_seconds', 'wall_seconds')]:
        check([x[raw] for x in rows], row[metric])
    for metric, raw in [('entry_function_seconds', 'start_function_ns'), ('engine_compile_instantiate_seconds', 'compile_instantiate_ns')]:
        if row[metric] is not None:
            check([x['engine_timing'][raw] / 1e9 for x in rows if 'engine_timing' in x], row[metric])
for case in lifecycle['examples']:
    for mode, s in case['modes'].items():
        vals = [x['wall_seconds'] for x in lifecycle['observations'] if x['name'] == case['name'] and x['mode'] == mode and x['phase'] == 'measure']
        check(vals, {'n': s['n'], 'median': s['median_seconds'], 'mad': s['mad_seconds'], 'samples': s['samples_seconds']})

analysis = load(BUILD / 'module-analysis.json')
assert analysis['compiler_sha256'] == selected and analysis['baseline_compiler_sha256'] == baseline
assert [x['task'] for x in analysis['examples'] if not x['byte_identical']] == ['sorting']
for row in analysis['examples'] + analysis['warmed']:
    for v in ['baseline', 'final']:
        a = row[v]
        assert sha(a['wasm']) == a['sha256'] and Path(a['wasm']).stat().st_size == a['bytes']
        assert sha(a['disassembly']) == a['disassembly_sha256']
    assert row['byte_identical'] == (row['baseline']['sha256'] == row['final']['sha256'])
    assert row['bytes_delta'] == row['final']['bytes'] - row['baseline']['bytes']
source = load(BUILD / 'final/source.json')
assert len(source['headers']) == 34 and len(source['patches']) == 2
for name, value in source['headers'].items():
    assert sha(ROOT / 'compiler' / name) == value
for name, value in source['patches'].items():
    assert sha(ROOT / name) == value
review = {'schema': 'goose-merge-independent-arithmetic-v1', 'status': 'passed',
          'created_utc': datetime.now(timezone.utc).isoformat(), 'reviewer': 'astra_campaign',
          'compiler_sha256': selected, 'baseline_compiler_sha256': baseline,
          'scope': 'Independent read-only calculation from raw observations and exact guest/source identities; no compiler/test/engine execution. Final public prose/chart/archive review remains separate.',
          'summary_cells_recomputed': checked, 'cohorts': {k: len(v['observations']) for k, v in reports.items()},
          'warmed': findings, 'source_inventory': {'headers': 34, 'patches': 2},
          'interpretation': ['Only Merge changes among ten warmed guests; nine byte-identical guests are noise controls, including the noisy V8 Life result.',
                             'Only full Sorting changes among ten full-example direct modules. Its merge function and the Merge port grow313bytes. Full Sorting and the insertion-only warmed adapter are different workloads.',
                             'Full-process host and lifecycle observations are separate nonpaired cohorts; do not form cross-cohort speedups or mix native reference medians.',
                             'Warmed Wasmtime uses the frozen reference host; normal host/lifecycle use canonicale303. Engine configuration and boundaries remain explicitly separate.'],
          'inputs': [pin(BUILD / path) for path in paths.values()] + [pin(BUILD / 'delivery-execution/report.json'), pin(BUILD / 'module-analysis.json'), pin(Path(__file__))],
          'blockers': []}
path = OUT / 'independent-arithmetic.json'
assert not path.exists()
path.write_text(json.dumps(review, indent=2) + '\n')
print(json.dumps({'status': 'passed', 'summary_cells': checked, 'review': pin(path),
                  'merge': {k: next(x for x in v['tasks'] if x['task'] == 'Sort::Merge') for k, v in findings.items()}}, indent=2))
