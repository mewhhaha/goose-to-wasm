#!/usr/bin/env python3
"""Build the five already audited controls, at most two builds of two jobs."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import json
import time
from controls import CONTROLS, build

HERE=Path(__file__).resolve().parent
started=time.monotonic()
rows=[]
def execute(name):
    print('START',name,flush=True)
    build(HERE/(name+'-control'))
    print('READY',name,flush=True)
    return {'control':name,'status':'passed'}
with ThreadPoolExecutor(max_workers=2) as pool:
    futures={pool.submit(execute,name):name for name in CONTROLS}
    for future in as_completed(futures):
        try:rows.append(future.result())
        except Exception as error:rows.append({'control':futures[future],'status':'failed','error':repr(error)})
status='passed'
if any(row['status']!='passed' for row in rows):status='failed'
(HERE/'controls-execution.json').write_text(json.dumps({'status':status,'controls':rows,'maximum_concurrent_controls':2,'ninja_jobs_per_control':2,'wall_seconds':time.monotonic()-started},indent=2)+'\n')
raise SystemExit(status!='passed')
