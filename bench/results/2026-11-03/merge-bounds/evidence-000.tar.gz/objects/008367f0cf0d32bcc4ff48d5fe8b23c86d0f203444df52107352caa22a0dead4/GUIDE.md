# Goose to Wasm guide

Run the commands in this guide from the repository root.

## Quick start: direct compilation

Requirements: Git, a C++20 compiler, Python 3.10+, CMake 3.27+, Ninja (or another
CMake generator), and Node 24.22.1 for the V8 runner. To reproduce the qualified
Python/build-tool versions:

```sh
python3 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt cmake==4.4.4 ninja==1.13.2
python scripts/bootstrap.py --generator Ninja --jobs 2

python scripts/goose_wasm.py build examples/squares.goose \
  --backend direct -o build/squares.wasm
node scripts/run_wasm.mjs build/squares.wasm
python scripts/run_wasmtime.py build/squares.wasm
```

Both engines print:

```text
sum=140
```

The [example catalog](../examples/README.md) adds a language tour, functions,
errors, a prime sieve, sorting, Sudoku, maze search, a bytecode VM and Life. Each entry records
its upstream source and adaptations. Check the direct examples on both engines:

```sh
python examples/run.py
```

The pinned host versions are Node **24.22.1** (V8 **13.6.233.17-node.58**) and
Wasmtime's Python package **50.0.1**. `toolchain.json` records every upstream/SDK
pin. Bootstrap downloads one immutable Goose revision, applies the reviewable
patches, copies `compiler/*.h`, and builds `build/bin/goose`. It verifies managed
sources before refreshing them and preserves manual edits rather than silently
overwriting them.

For the smallest invocation overhead, use the native compiler directly:

```sh
build/bin/goose examples/squares.goose --target wasm-direct \
  -O2 -o build/squares.wasm --wasm-stats build/squares.stats.json
```

The Python driver adds dependency caching, output preservation, and a common
interface to the reference pipelines. Direct compilation needs no Emscripten
installation. A qualification test runs it with an empty `PATH` and unavailable
C-compiler paths.

## Optional native Wasmtime host

On Linux x86_64, build with C++20 `clang++`. The builder checks the official
Wasmtime 50.0.1 SDK archive and links its full static library, with section
collection and static C++ runtimes. Both ordinary execution and AOT preparation
remain available. `--linkage python-shared` instead links the installed pinned
Python package's library; benchmark reports record both library identities.

```sh
python scripts/build_wasmtime_host.py
build/bin/goose-wasmtime build/squares.wasm
build/bin/goose-wasmtime --compile build/squares.wasm build/squares.cwasm
build/bin/goose-wasmtime --precompiled build/squares.cwasm
```

Normal execution enables Wasmtime's SDK compilation cache by default. Use
`--no-cache` for an uncached run, or `--cache-config FILE` to select a cache
configuration. If the default cache cannot be loaded, execution continues
without it; an invalid explicit configuration is an error. Precompiled artifacts
contain native code and depend on the Wasmtime version and CPU; load only
trusted artifacts you produced for the target. [Wasmtime documents serialization](https://docs.wasmtime.dev/examples-serialize.html).

For repeated requests, keep a native runtime resident:

```python
from scripts.wasmtime_session import RuntimeSession

with RuntimeSession() as session:
    result = session.run("build/squares.wasm", stdin=b"")
    print(result.stdout.decode(), end="")
```

Each request gets fresh guest state, store and instance. The session rereads the
Wasm file and reuses a compiled module only for exactly matching bytes. Its LRU
retains at most eight entries and 64 MiB of raw Wasm; this is not a bound on
process RSS. `result` includes `returncode`, `stdout`, `stderr`,
`module_cache_hit`, `prepare_ns` and `start_ns`. The session disables the SDK
cache by default; use `RuntimeSession(cache=True)` to enable it, or pass
`cache_config=...` for an explicit configuration. Session module reuse is
separate from both the SDK disk cache and precompiled artifacts. See the
[host measurements](../bench/wasmtime-host.md) for timing boundaries and coverage.

## The three compilation paths

| Driver backend | Pipeline | Output |
| --- | --- | --- |
| `direct` | Goose frontend → direct binary emitter | `.wasm`, with explicit scalar host imports |
| `native` | Goose frontend/C backend → native C compiler | Native executable |
| `c-wasm` | Goose frontend/C backend → Emscripten | Standalone memory64 `.wasm`, or Emscripten `.mjs` plus `.wasm` |

Install the oracle SDK only when using C-to-Wasm or running the complete tests:

```sh
python scripts/install_emsdk.py --jobs 2
. build/emsdk/emsdk_env.sh

python scripts/goose_wasm.py build examples/squares.goose \
  --backend native -o build/squares-native
python scripts/goose_wasm.py build examples/squares.goose \
  --backend c-wasm -o build/squares-c.wasm

./build/squares-native
node scripts/run_wasm.mjs build/squares-c.wasm
python scripts/run_wasmtime.py build/squares-c.wasm
```

The standalone oracle is the same binary on both engines. It uses an explicit
LP64/WASI64 host adapter in the supplied runners; it is not an ordinary WASI32
command. Its runtime workloads execute in Wasm, while the adapters implement
boundary services such as stdin/stdout and clocks. The `.mjs` oracle retains the
previous Emscripten integration and its broader portability corpus.

`--c-source`, `--c-include-dir`, and `--include` supply C extern implementations
for the reference paths. Direct scalar externs are `env` imports supplied by a
host. `-O0`, `-O1`, and `-O2` select the same Goose semantic optimizations on all
paths; the C paths additionally invoke their C compiler at the corresponding
optimization level.

## Backend scope

This is an explicitly bounded backend. It supports scalar functions, recursion,
control flow, fixed arrays,
static-capacity resizable arrays, struct fields, fixed-mode enums and payload matches, owned fixed aggregate returns,
slices, references, and named growable arrays of supported fixed-layout elements.
Variable arrays with default/u8/u16/u32/u64 length storage use these regions for owned
construction, calls and returns, while keeping their length frozen.
Their unsigned length prefixes, and runtime-limited capacity/length prefixes,
live in the data region; [physical-mode accessors](ARRAY_IMAGES.md) distinguish
these values from raw element-run result channels.
Runtime-capacity arrays preserve logical capacity through copies and assignment,
with checked mutation and conversions between supported array kinds.
Standalone structs with fixed fields and one variable/runtime-capacity array tail
support owned construction, independent copies, calls and named-result aliasing.
Growable-tail frame structs also support whole-object reconstruction, with
private prefix/length snapshots and shared tail elements for named returns.
Supported structs may nest through their final field to a single array tail;
each enclosing prefix remains fixed-layout. Non-frame prefixes and terminal
arrays now form [contiguous record images](RECORD_IMAGES.md), with stable
prefix references and independent full-image copies.
Nonresizable variable-mode enums with fixed or single-tail payloads use independent region images,
mode conversions, owned calls/results and copied or borrowed payload matches.
Standalone variable-size variants share the single-tail record walker, including
nested tails and supported payloads whose siblings require other storage forms.
Fixed struct and variant fields are packed; enum replacements with supported
recursive integer records and arrays preserve native byte overlap through saved
payload references.
Nested functions receive hidden addresses for their captured bindings, including
transitive and recursive captures, mutable reference/slice bindings and supported
owned values. Static function-value calls support fixed and supported owned
parameters/results with independent copies and scoped cleanup. See [static captures](STATIC_CAPTURES.md)
for qualification and the remaining ownership/nonlocal-return boundaries.
Runtime enum overload dispatch saves arguments in source order, snapshots value
payloads and shares result destinations across case functions. Reference cases
retain the original payload storage; [the dispatch contract](FUNCTION_DISPATCH.md)
describes the supported layouts and natural result checks.
Nonlocal returns cross ordinary and dispatched calls for fixed target results,
including mixed aggregates and recursive target activations, with cleanup of
dying storage. [Owned nonlocal results](NONLOCAL_RETURNS.md) support growable-array and
single-tail frame result groups alongside fixed results, with staged construction
and independent landing. Standalone scalar and recursively packed integer
aggregate Var/runtime-limited results preserve byte-authoritative length/capacity
prefixes across nonlocal returns. Other owned
image kinds remain pending.
Growable owners use stable checked data regions, borrowed calls, independent
by-value parameters, mixed/multiple owned results and named-result construction.
Owned results also construct through conditional, block, loop and match expressions.
Whole-array assignment reconstructs growable owners in their existing regions.
Forwarded results can adapt fixed arrays and slices into growable receivers.
Single growable temporaries support immediate views, indexing, rendering and
scoped argument use, and discarded mixed/multiple owned results. Unsupported constructs produce compile
errors, with no fallback to the C backend. It is not yet full Goose parity; see
[the target contract](TARGET.md) and [next milestones](ROADMAP.md).
The [completion plan](IMPLEMENTATION_PLAN.md) and checked
[capability inventory](capabilities.json) track the remaining work.

## Correctness qualification

```sh
python scripts/check_engines.py --output build/engine-probes.json
python tests/run_differential.py --engines v8 wasmtime \
  --backends direct c-wasm native
python tests/test_backend_extensions.py
python tests/test_static_data.py
python tests/test_fill_loops.py
python tests/test_merge_bounds.py
python tests/test_strip_loops.py
python tests/test_regions.py
python tests/test_prefix_resolution.py
python tests/test_uleb_accessor_helpers.py
python tests/test_dynamic_boundaries.py
python tests/test_incremental.py
python tests/test_input_dependencies.py
python tests/test_compiler_session.py
python tests/test_lexical_cache.py
python tests/test_syntax_cache.py
python tests/test_syntax_importer.py
python tests/test_checked_leaf_cache.py
python tests/test_checked_scalar_cache.py
python tests/test_checked_leaf_ownership.py
python tests/test_langarena.py

python oracle/tests/test_bootstrap.py
python oracle/tests/test_target.py
python oracle/tests/test_driver.py
python oracle/tests/run_tests.py --full --jobs 2
```

The differential harness checks stdout, exit status, selected diagnostics, and
independently derived answers. Native C supplies an independent reference; both
Wasm backends execute on both engines. Tests cover optimization levels O0/O2,
numeric edge cases, narrow integer wrapping, checked arithmetic/casts, floating
formatting, control flow, recursion, references, aggregate operations, and target
refusals. A refused program is not counted as a successful execution.

For a faster local run of the same differential matrix, shard by backend and
optimization level. The merger checks exact coverage and all native stdout
comparisons before writing a passing report:

```sh
python bench/qualify_compiler.py --jobs 6 --output-dir build/differential-sharded
```

The retained oracle corpus also checks the fixed data-stack runtime, capacity
boundaries, serialization, relative references, builders, and other Goose features
that the new direct backend does not yet implement. Passing that corpus validates
the reference path, not direct-backend coverage.

Direct modules omit zero-filled static storage from their data segments while
preserving its addresses and memory limits. On the seven adapted LangArena
entrypoints, this reduces six modules from 1.0–4.8 MB to 3.2–6.6 KB. All seven
pass the official small-input checks on V8 and Wasmtime. See the
[artifact-size comparison](../bench/results/2026-10-30/README.md); this measures
file size, not execution speed or a reduction in runtime memory.

GitHub Actions builds from the immutable inputs, executes qualification, runs
benchmark correctness smoke tests, and publishes reports plus the compiler and
its corresponding source.

## Compilation speed and incremental work

The [runtime optimization record](RUNTIME_PERFORMANCE.md) has the current paired
measurements, implementation choices and rejected experiments.

To regenerate the README charts without rerunning benchmarks, install Matplotlib in an isolated environment and run `python bench/charts.py` from the repository root. `bench/results/latest.json` selects the dated measurements. The script writes `bench/charts/compilation.svg` and `bench/charts/runtime.svg`.

```sh
python bench/benchmark.py
python bench/incremental.py
```

The [benchmark guide](../bench/README.md) defines cold build, timed kernel, and
process wall time separately. Runtime inputs prevent whole-program constant
folding; every sample must match an independent checksum. Results retain raw
samples, median, dispersion, flags, tool versions, compiler hashes, and engine
identities. The native/C-Wasm paths benefit from C/LLVM optimizations; direct
emission does not promise faster program execution.

### Measured baseline (2026-10-26)

Five complete uncached builds per cell on an AMD EPYC 9V74 KVM guest, using the pinned toolchain. Values are median wall milliseconds, including Python driver startup:

| Workload | C → native | C → Wasm | Direct Wasm |
| --- | ---: | ---: | ---: |
| Integer recurrence | 250.8 | 663.0 | 56.8 |
| Recursive Fibonacci | 276.6 | 638.3 | 58.2 |
| Float recurrence | 257.5 | 592.0 | 56.4 |
| Fixed-array updates | 246.7 | 635.6 | 58.5 |

Direct builds were 10.5–11.7× faster than C-to-Wasm on these four inputs. Runtime results depend on the workload and engine; the full table includes a large native-GCC optimization advantage on recursive Fibonacci. [Measurements, raw samples, and qualification evidence](../bench/results/2026-10-26/README.md) record the exact source/tool hashes and limitations.

The [Fibonacci follow-up](../bench/results/2026-10-26/fibonacci-followup/README.md)
separates Goose and GCC optimization levels. GCC recursively inlines the
Goose-optimized function, shares overlapping recursive results, and introduces
an accumulator loop. This sharply reduces the computation performed; its speedup
is specific to that redundant recursive workload. Generated C, GCC optimization
reports, assembly, and the four-way experiment are retained.

A separate 32-function `-O0` experiment measured 8.84 ms for a raw compiler invocation, 2.12 ms for an unchanged persistent-server request, and 15.08 ms after a one-function edit. Edits still compile the entire program. [Full rebuild measurements](../bench/results/2026-10-26/incremental.md).

### LangArena gauntlet

The [LangArena integration](../bench/langarena/README.md) pins the complete
50-task upstream Goose suite and its official test/production configurations.
It records whole-suite builds separately from seven adapted entrypoints that
can run across all three backends and both Wasm engines. Fannkuch keeps its
fixed-array kernel; six ports replace growable storage with disclosed bounds.
The adapted sources, input sizes, iteration counts, and expected checksums are
identical across the compared backends.

```sh
python bench/langarena.py fetch
python bench/langarena.py check --emcc /path/to/emcc
python bench/langarena.py measure --emcc /path/to/emcc \
  --machine-label "observed machine description"
```

The harness retains all 50 coverage rows, explicit Wasm refusals, complete cold
builds, observable marker-edit rebuilds, computational regions, engine startup,
and process wall times. Wrong checksums fail qualification. These measurements
are local backend comparisons, not published LangArena ranks or a claim of
complete Goose support. Those edited builds reran the complete frontend.

The [2026-10-26 gauntlet results](../bench/results/2026-10-26/langarena/README.md)
retain all raw evidence. The seven direct cold builds took 73–94 ms each,
8.4–13.3× faster than C-to-Wasm on the same sources. All 50 original native cases
and all seven adapted cases passed their full production checksums. Runtime
results are mixed: hashing and V8's sieve have substantial direct-backend gaps.
Observable direct rebuilds took 61–77 ms and still recompile the whole program.

### Incremental foundation

The current incremental foundation is:

- A content-checked module cache, including parsed configurations, resolved
  imports, missing-path probes, symlink targets, module-search candidates,
  compiler identity, flags, and relevant environment.
- A persistent JSON-lines build server that avoids Python startup on repeated
  requests and validates source content before reusing a module.
- An optional native worker with source overlays and bounded parsed-module
  reuse, importing syntax into a fresh request AST.
- Per-function bytecode fingerprints and call dependencies in compiler statistics,
  providing a concrete basis for a future function cache.

**Edits still rerun resolution, caller checking, optimization, and emission.**
Optional checked caches skip unchanged closed scalar leaves and restricted callers.
The function hashes measure unchanged output; they do not skip function emission. Unchanged-build
cache hits and edited builds are reported as separate measurements. See
[incremental architecture](INCREMENTAL.md).

```sh
python scripts/goose_wasm.py serve
```

Each stdin line is a request, and each stdout line is a response:

```json
{"id":1,"args":["build","examples/squares.goose","--backend","direct","-o","build/squares.wasm"]}
```

Use `serve --native-worker` to retain the native compiler process too. This
mode also accepts a `sources` object mapping existing absolute file paths to
unsaved source text. Each request supplies the complete overlay set; omitting
it restores disk contents. Overlay builds bypass the disk module cache and do
not modify source files. New virtual files are not supported by import discovery.

The native worker owns a fresh compilation AST for every changed build.
Add `--syntax-cache` to reuse unchanged files' parsed syntax while rebuilding
all semantic results. `parsed_files` and `parsed_cache_hits` expose actual
parsing and reuse; no checked syntax survives into the next request.
`python tests/test_compiler_session.py` checks request isolation, module
equivalence, recovery, aliases, process restart, and retained memory.
`tests/test_syntax_cache.py` checks cache invalidation and context;
`tests/test_syntax_importer.py` destroys templates before checking/emitting
their imported syntax under sanitizers. Compare session timings with
`python bench/incremental.py --native-worker`, adding `--syntax-cache` to
measure parsed-module reuse.
The retained [O0/O2 syntax-cache comparison](../bench/results/2026-10-30/syntax-cache.md)
shows less parsing but no established edited-build wall-time improvement.

Add `--checked-leaf-cache` to reuse checked numeric/bool leaf functions with one
explicit scalar result and explicitly typed scalar parameters. Their bodies may
contain arithmetic, parameter reads, conditionals, blocks, and local returns.
Calls, globals, captures, locals, loops, explicit casts, generic functions, and
aggregate/reference types recheck normally. Entries contain values and indices;
each request recreates its own nodes, types, parameters, and source origins.
`checked_leaf_cache_hits` counts skipped body checks, and `semantic_reused`
records this limited reuse. Caller overload resolution and all later passes
still run. Compare this mode using `bench/incremental.py --shape leaves
--native-worker --syntax-cache --checked-leaf-cache`.
The [retained comparison](../bench/results/2026-10-30/checked-leaves.md) shows
smaller type-check phase medians and mixed O2 edited-build wall times.

Use `--checked-scalar-cache` to include a restricted class of scalar callers.
These have canonical `i64` signatures and one straight-line arithmetic result;
direct named callees must resolve uniquely, and call arguments must be parameter
identifiers. Every request revalidates the closed, acyclic source graph and
binds current callee specializations. Editing a callee's body can therefore
preserve its callers' checked arithmetic while optimization sees the new body.
`checked_scalar_caller_hits` counts those reused callers. Overloads, namespace
shadowing, changed signatures, effects, or excluded syntax trigger normal
checking. This option includes the leaf support and supersedes
`--checked-leaf-cache` when both are selected.
The [chain comparison](../bench/results/2026-10-30/checked-callers.md) verifies
31 reused callers but does not establish an end-to-end speedup.

`--no-cache` disables whole-module artifact reuse; explicitly enabled native
syntax/token caches remain active. A failed compile leaves the previous output
intact. `--stats FILE` writes driver timings and backend statistics as JSON.
Unsaved overlays and `--no-cache` retain publication guards while skipping
extra disk-cache validation. Benchmark unsaved edits with
`--edit-source-mode overlay`; disk edits remain the benchmark default.
On the retained 32-function local comparison, driver changes reduce unsaved-edit
medians from 12.3–14.7 ms to 9.5–10.9 ms. [Raw timings and limitations](../bench/results/2026-10-30/driver-overhead.md).

## Source organization

| Path | Purpose |
| --- | --- |
| `compiler/` | Direct binary emitter and AST lowering |
| `patches/direct-target.patch` | Hook into the upstream compiler before C code generation |
| `oracle/` | Checked C runtime patch, Emscripten driver, and retained qualification corpus |
| `scripts/bootstrap.py` | Reproducible compiler build and source verification |
| `scripts/goose_wasm.py` | Common driver, module cache, and persistent build server |
| `scripts/run_wasm.mjs`, `scripts/run_wasmtime.py`, `host/wasmtime.cpp` | Engine hosts and explicit runtime services |
| `tests/` | Direct/reference comparisons and incremental contracts |
| `bench/` | Runtime-input workloads and reproducible measurement harnesses |

The new backend and upstream Goose source are Apache-2.0 licensed. The retained
oracle integration keeps its [MIT license](../oracle/INTEGRATION-LICENSE).
Imported LangArena configurations and adapted kernels retain the upstream
[MIT notice](../bench/langarena/UPSTREAM_LICENSE), also included beside the ports.
Bootstrap
packages the upstream runtime/header and bundled dependency notices with the
native compiler. Full native platform packages, a browser-hosted compiler, and
incremental semantic analysis are subsequent work, documented separately from
the implemented target.
