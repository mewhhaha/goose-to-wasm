# LangArena qualification and measurements

Status: **passed**.

Upstream pin: `aab9b14998231ba905523b5ba3990ee03c46f64d`. Catalog: **50 tasks**. Adapted entrypoints: **7 tasks**, including six storage adaptations.

Mode: `measure`. Machine: AMD Ryzen 7 3800X, shared desktop host.
Compiler SHA-256: `b53aaf097e0ea47b3f3efea158db3520aa03f9ab1fb1625efd21fff31d49319d`.

## Measurement contract

Whole-suite results use all original Goose kernel sources. The only staging patch changes the marker destination from `/tmp/recompile_marker` to a relative file inside the isolated run directory. The original checkout is hash-verified and never edited. Whole-suite compile times include all 50 tasks.

The adapted track uses the same seven port sources across native C, direct Wasm, and C-Wasm. Six ports replace growable storage; Fannkuch keeps its original fixed-array kernel. Official test/run inputs and checksums are unchanged. Preparation stays outside the clock; warmups mutate the same state used for measurement; the deterministic RNG is reset before measured iterations. Existing checksum work retains its original placement.

Cold builds and marker-edit builds launch fresh driver/compiler processes with `--no-cache`. OS caches and installed compiler/system-library caches are retained. A port marker edit changes its exit status from 0 to 1 after its two output lines, and the edited executable must retain the official checksum. Whole-suite edits change the actual marker file contents. Source bytes are restored in all cases. Optional unchanged cache hits are a separate phase. Edited sources still rerun the complete frontend.

The official whole-suite timer prints milliseconds; adapted ports print integer nanoseconds. Timed regions exclude process startup and preparation. Process wall time is retained separately. Sample counts below five are preliminary estimates; raw values and MAD are provided. These are local comparisons, not LangArena leaderboard scores or claims of complete direct-backend language support.

## Whole-suite compilation

| Backend | Phase | Samples | Median ms | MAD ms | Artifact bytes |
| --- | --- | ---: | ---: | ---: | ---: |

## Original-source correctness and runtime

| Task | Backend / engine | Profile | Samples | Region median ms | MAD ms | Process median ms |
| --- | --- | --- | ---: | ---: | ---: | ---: |

## Adapted workload compilation

| Task | Backend | Phase | Samples | Median ms | MAD ms | Artifact bytes |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| CLBG::Fannkuchredux | c-wasm | cold | 5 | 686.839 | 13.444 | 51975 |
| CLBG::Fannkuchredux | direct | cold | 5 | 69.914 | 0.863 | 3917 |
| CLBG::Fannkuchredux | native | cold | 5 | 300.737 | 10.380 | 22984 |
| CLBG::Mandelbrot | c-wasm | cold | 5 | 634.213 | 13.070 | 52049 |
| CLBG::Mandelbrot | direct | cold | 5 | 70.282 | 3.160 | 4467 |
| CLBG::Mandelbrot | native | cold | 5 | 283.726 | 15.665 | 23160 |
| Etc::Sieve | c-wasm | cold | 5 | 656.956 | 25.815 | 51597 |
| Etc::Sieve | direct | cold | 5 | 69.222 | 1.182 | 3098 |
| Etc::Sieve | native | cold | 5 | 287.386 | 4.875 | 23128 |
| Hash::CRC32 | c-wasm | cold | 5 | 617.340 | 10.180 | 51807 |
| Hash::CRC32 | direct | cold | 5 | 67.482 | 0.759 | 3132 |
| Hash::CRC32 | native | cold | 5 | 267.295 | 7.518 | 23008 |
| Hash::SHA256 | c-wasm | cold | 5 | 662.719 | 7.283 | 51822 |
| Hash::SHA256 | direct | cold | 5 | 74.180 | 3.810 | 6611 |
| Hash::SHA256 | native | cold | 5 | 308.596 | 29.162 | 23008 |
| Sort::Merge | c-wasm | cold | 5 | 662.991 | 13.402 | 52474 |
| Sort::Merge | direct | cold | 5 | 67.609 | 0.475 | 5527 |
| Sort::Merge | native | cold | 5 | 306.049 | 2.682 | 27416 |
| Sort::Quick | c-wasm | cold | 5 | 660.570 | 11.073 | 52033 |
| Sort::Quick | direct | cold | 5 | 67.763 | 0.220 | 4356 |
| Sort::Quick | native | cold | 5 | 317.634 | 12.405 | 23168 |

## Adapted workload runtime

| Task | Backend / engine | Profile | Samples | Region median ms | MAD ms | Engine compile + instantiate ms | Process median ms | Checksum |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| CLBG::Fannkuchredux | c-wasm / v8 | run | 5 | 2154.269 | 11.595 | 0.516 | 2604.855 | 135762480 |
| CLBG::Fannkuchredux | c-wasm / v8 | test | 1 | 0.041 | 0.000 | 0.677 | 52.172 | 4428 |
| CLBG::Fannkuchredux | c-wasm / wasmtime | run | 5 | 1509.566 | 7.436 | 23.688 | 1927.952 | 135762480 |
| CLBG::Fannkuchredux | c-wasm / wasmtime | test | 1 | 0.055 | 0.000 | 22.737 | 105.185 | 4428 |
| CLBG::Fannkuchredux | direct / v8 | run | 5 | 1291.673 | 8.044 | 0.228 | 1583.951 | 135762480 |
| CLBG::Fannkuchredux | direct / v8 | test | 1 | 0.059 | 0.000 | 0.384 | 33.586 | 4428 |
| CLBG::Fannkuchredux | direct / wasmtime | run | 5 | 1394.474 | 9.783 | 4.326 | 1755.972 | 135762480 |
| CLBG::Fannkuchredux | direct / wasmtime | test | 1 | 0.025 | 0.000 | 4.826 | 83.406 | 4428 |
| CLBG::Fannkuchredux | native / native | run | 5 | 1349.684 | 6.720 | — | 1606.148 | 135762480 |
| CLBG::Fannkuchredux | native / native | test | 1 | 0.011 | 0.000 | — | 0.791 | 4428 |
| CLBG::Mandelbrot | c-wasm / v8 | run | 5 | 964.152 | 7.488 | 0.587 | 1208.464 | 3455988829 |
| CLBG::Mandelbrot | c-wasm / v8 | test | 1 | 0.337 | 0.000 | 0.467 | 27.176 | 2236342953 |
| CLBG::Mandelbrot | c-wasm / wasmtime | run | 5 | 1086.955 | 8.163 | 28.273 | 1415.515 | 3455988829 |
| CLBG::Mandelbrot | c-wasm / wasmtime | test | 1 | 0.238 | 0.000 | 23.792 | 109.550 | 2236342953 |
| CLBG::Mandelbrot | direct / v8 | run | 5 | 980.870 | 1.918 | 0.254 | 1225.340 | 3455988829 |
| CLBG::Mandelbrot | direct / v8 | test | 1 | 0.374 | 0.000 | 0.282 | 27.227 | 2236342953 |
| CLBG::Mandelbrot | direct / wasmtime | run | 5 | 1021.082 | 9.775 | 3.716 | 1313.252 | 3455988829 |
| CLBG::Mandelbrot | direct / wasmtime | test | 1 | 0.189 | 0.000 | 3.928 | 87.011 | 2236342953 |
| CLBG::Mandelbrot | native / native | run | 5 | 944.259 | 3.061 | — | 1138.144 | 3455988829 |
| CLBG::Mandelbrot | native / native | test | 1 | 0.158 | 0.000 | — | 2.755 | 2236342953 |
| Etc::Sieve | c-wasm / v8 | run | 5 | 6629.064 | 509.032 | 0.558 | 7922.260 | 1042248060 |
| Etc::Sieve | c-wasm / v8 | test | 1 | 0.019 | 0.000 | 0.891 | 32.257 | 4660 |
| Etc::Sieve | c-wasm / wasmtime | run | 5 | 5463.682 | 48.786 | 25.674 | 6667.928 | 1042248060 |
| Etc::Sieve | c-wasm / wasmtime | test | 1 | 0.049 | 0.000 | 24.630 | 109.797 | 4660 |
| Etc::Sieve | direct / v8 | run | 5 | 1358.324 | 11.156 | 0.238 | 1684.585 | 1042248060 |
| Etc::Sieve | direct / v8 | test | 1 | 0.016 | 0.000 | 0.251 | 26.094 | 4660 |
| Etc::Sieve | direct / wasmtime | run | 5 | 1370.489 | 8.565 | 3.420 | 1734.507 | 1042248060 |
| Etc::Sieve | direct / wasmtime | test | 1 | 0.022 | 0.000 | 3.541 | 87.943 | 4660 |
| Etc::Sieve | native / native | run | 5 | 868.408 | 5.689 | — | 1046.011 | 1042248060 |
| Etc::Sieve | native / native | test | 1 | 0.003 | 0.000 | — | 3.594 | 4660 |
| Hash::CRC32 | c-wasm / v8 | run | 5 | 460.192 | 1.181 | 0.548 | 589.947 | 2318723244 |
| Hash::CRC32 | c-wasm / v8 | test | 1 | 0.014 | 0.000 | 0.605 | 27.912 | 3031698216 |
| Hash::CRC32 | c-wasm / wasmtime | run | 5 | 414.344 | 1.342 | 36.393 | 622.360 | 2318723244 |
| Hash::CRC32 | c-wasm / wasmtime | test | 1 | 0.054 | 0.000 | 27.000 | 112.912 | 3031698216 |
| Hash::CRC32 | direct / v8 | run | 5 | 507.180 | 2.253 | 0.212 | 650.507 | 2318723244 |
| Hash::CRC32 | direct / v8 | test | 1 | 0.027 | 0.000 | 0.274 | 37.235 | 3031698216 |
| Hash::CRC32 | direct / wasmtime | run | 5 | 441.715 | 3.146 | 3.817 | 622.096 | 2318723244 |
| Hash::CRC32 | direct / wasmtime | test | 1 | 0.025 | 0.000 | 3.749 | 103.420 | 3031698216 |
| Hash::CRC32 | native / native | run | 5 | 1387.836 | 2.192 | — | 1669.254 | 2318723244 |
| Hash::CRC32 | native / native | test | 1 | 0.056 | 0.000 | — | 2.607 | 3031698216 |
| Hash::SHA256 | c-wasm / v8 | run | 5 | 1091.520 | 0.547 | 0.622 | 1360.931 | 2844672256 |
| Hash::SHA256 | c-wasm / v8 | test | 1 | 0.007 | 0.000 | 0.621 | 42.919 | 1036619072 |
| Hash::SHA256 | c-wasm / wasmtime | run | 5 | 978.492 | 4.481 | 30.524 | 1301.558 | 2844672256 |
| Hash::SHA256 | c-wasm / wasmtime | test | 1 | 0.045 | 0.000 | 26.671 | 108.309 | 1036619072 |
| Hash::SHA256 | direct / v8 | run | 5 | 272.877 | 4.973 | 0.262 | 367.587 | 2844672256 |
| Hash::SHA256 | direct / v8 | test | 1 | 0.003 | 0.000 | 0.260 | 24.306 | 1036619072 |
| Hash::SHA256 | direct / wasmtime | run | 5 | 342.231 | 1.712 | 5.336 | 505.006 | 2844672256 |
| Hash::SHA256 | direct / wasmtime | test | 1 | 0.017 | 0.000 | 5.375 | 88.638 | 1036619072 |
| Hash::SHA256 | native / native | run | 5 | 609.309 | 8.426 | — | 737.508 | 2844672256 |
| Hash::SHA256 | native / native | test | 1 | 0.002 | 0.000 | — | 1.505 | 1036619072 |
| Sort::Merge | c-wasm / v8 | run | 5 | 1349.457 | 16.058 | 0.604 | 1650.526 | 61757772 |
| Sort::Merge | c-wasm / v8 | test | 1 | 12.583 | 0.000 | 0.594 | 50.686 | 2548773 |
| Sort::Merge | c-wasm / wasmtime | run | 5 | 2749.743 | 2.612 | 23.881 | 3409.657 | 61757772 |
| Sort::Merge | c-wasm / wasmtime | test | 1 | 25.304 | 0.000 | 32.629 | 169.275 | 2548773 |
| Sort::Merge | direct / v8 | run | 5 | 1455.480 | 3.316 | 0.281 | 1789.921 | 61757772 |
| Sort::Merge | direct / v8 | test | 1 | 13.824 | 0.000 | 3.397 | 56.441 | 2548773 |
| Sort::Merge | direct / wasmtime | run | 5 | 1519.371 | 6.156 | 3.945 | 1937.212 | 61757772 |
| Sort::Merge | direct / wasmtime | test | 1 | 14.062 | 0.000 | 5.725 | 112.864 | 2548773 |
| Sort::Merge | native / native | run | 5 | 1418.723 | 20.761 | — | 1707.952 | 61757772 |
| Sort::Merge | native / native | test | 1 | 13.825 | 0.000 | — | 24.015 | 2548773 |
| Sort::Quick | c-wasm / v8 | run | 5 | 1429.613 | 13.716 | 0.590 | 1749.748 | 61757772 |
| Sort::Quick | c-wasm / v8 | test | 1 | 14.167 | 0.000 | 0.676 | 53.512 | 2548773 |
| Sort::Quick | c-wasm / wasmtime | run | 5 | 1662.445 | 16.414 | 24.839 | 2099.239 | 61757772 |
| Sort::Quick | c-wasm / wasmtime | test | 1 | 16.178 | 0.000 | 27.647 | 142.472 | 2548773 |
| Sort::Quick | direct / v8 | run | 5 | 1379.171 | 0.375 | 0.253 | 1685.707 | 61757772 |
| Sort::Quick | direct / v8 | test | 1 | 13.599 | 0.000 | 0.226 | 53.246 | 2548773 |
| Sort::Quick | direct / wasmtime | run | 5 | 1697.284 | 49.035 | 3.873 | 2099.004 | 61757772 |
| Sort::Quick | direct / wasmtime | test | 1 | 15.730 | 0.000 | 4.556 | 111.519 | 2548773 |
| Sort::Quick | native / native | run | 5 | 1214.794 | 5.082 | — | 1464.141 | 61757772 |
| Sort::Quick | native / native | test | 1 | 13.116 | 0.000 | — | 23.092 | 2548773 |

## Qualification and limits

- Seven adapted entrypoints (six change storage, one changes only the harness) are a subset of the 50-task catalog; they do not establish unmodified whole-suite Wasm support.
- No local result is a LangArena leaderboard rank: source/compiler versions, target layout, host, flags, and coverage differ.
- Cold builds retain OS and compiler system-library caches; they are complete uncached driver builds, not disk-cold experiments.

The full 50-task coverage matrix, raw commands/output, source and artifact hashes, tool versions, input values, environment overrides (including `EM_NODE_JS`), and phase timings are in `report.json` and adjacent logs. `Hash::SHA256` retains LangArena's custom hash workload; it is not standard cryptographic SHA-256.
