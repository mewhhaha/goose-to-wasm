#!/usr/bin/env python3
"""Prepare a private qualification for the merge-bounds candidate; never measure it.

Source preparation is safe during measurement. Every phase below needs the
coordinator's separate CPU window. Existing results are never overwritten.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import concurrent.futures
import hashlib
import json
import os
import shutil
import signal
import subprocess
import sys
import threading
import time

ROOT=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parent
CAPS={name:'1' for name in ('EMCC_CORES','BINARYEN_CORES','RAYON_NUM_THREADS','OMP_NUM_THREADS')}
EXPECTED={'focused_commands':74,'differential_observations':9573,'native_stdout_comparisons':7656,'cases':978,'host_observations':11484}
NAMED_REFERENCE=HERE/'named-control/build/bin/goose'
MEMORY_REFERENCE=ROOT/'build/functions-next/forward-v3/bin/goose'
MEMORY_REFERENCE_SHA='19d377d68530e0cf5b59f6d28f7b1a2ca207b9ed981dfad29dedf7fa5723473b'
FRESH_REFERENCE=ROOT/'build/functions-grow/body-growth/bin/goose'
FRESH_REFERENCE_SHA='353a3f1bd547330c8ecd32e9084ae92d616340f81f83a5cc30f2e657d577652e'


def require(value,message):
    if not value: raise RuntimeError(message)


def load(path): return json.loads(Path(path).read_bytes())


def sha(path):
    with Path(path).open('rb') as source: return hashlib.file_digest(source,'sha256').hexdigest()


def save(path,value): Path(path).write_text(json.dumps(value,indent=2)+'\n')


def small_snapshot(compiler_sha,source_root,provisional=False):
    """Copy the declared headers, two patches, build metadata and focused regression sources."""
    metadata=load(source_root/'toolchain.json'); source=load(source_root/'source.json')
    require(metadata['compiler_sha256']==compiler_sha,'snapshot compiler identity differs')
    require(source['headers']==metadata['headers'] and source['patches']==metadata['patches'],'snapshot source metadata differs')
    require(source['headers'] and source['patches'],'empty source inventory')
    require(sha(source_root/'bin/goose')==compiler_sha,'snapshot compiler bytes differ')
    folder=HERE/'sources'/compiler_sha
    inputs={}
    for name,expected in source['headers'].items():
        paths=[source_root/'compiler'/name,ROOT/'compiler'/name,ROOT/'build/source/src'/name]
        original=next((path for path in paths if path.is_file() and sha(path)==expected),None)
        require(original is not None,'matching header unavailable: '+name)
        inputs['compiler/'+name]=(original,expected)
    for name,expected in source['patches'].items():
        original=ROOT/name
        require(sha(original)==expected,'patch differs: '+name)
        inputs[name]=(original,expected)
    for name,original in [('source.json',source_root/'source.json'),('toolchain.json',source_root/'toolchain.json'),
                          ('toolchain-pin.json',ROOT/'toolchain.json'),('test_local_tee.py',ROOT/'tests/test_local_tee.py'),
                          ('test_function_value_forwarding.py',ROOT/'tests/test_function_value_forwarding.py'),
                          ('test_named_callback_forwarding.py',ROOT/'tests/test_named_callback_forwarding.py'),
                          ('test_memory_growth_helper.py',ROOT/'tests/test_memory_growth_helper.py'),
                          ('test_fresh_initialization.py',ROOT/'tests/test_fresh_initialization.py'),
                          ('test_private_snapshot_parameters.py',ROOT/'tests/test_private_snapshot_parameters.py'),
                          ('test_byte_stencil.py',ROOT/'tests/test_byte_stencil.py'),
                          ('test_merge_bounds.py',ROOT/'tests/test_merge_bounds.py'),
                          ('test_runtime_session.py',ROOT/'tests/test_runtime_session.py')]:
        inputs[name]=(original,sha(original))
    folder.mkdir(parents=True,exist_ok=True)
    for name,(original,expected) in inputs.items():
        destination=folder/name;destination.parent.mkdir(parents=True,exist_ok=True)
        if destination.exists(): require(sha(destination)==expected,'refusing to replace source snapshot: '+name)
        else: shutil.copyfile(original,destination)
    manifest={'status':'source-snapshot','compiler_sha256':compiler_sha,'compiler_bytes_verified':True,
              'provisional':provisional,'source_root':str(source_root),'input_sha256':{name:value[1] for name,value in inputs.items()},
              'resolved_sources':{name:str(value[0]) for name,value in inputs.items()},
              'header_count':len(source['headers']),'patch_count':len(source['patches']),
              'scope':'Declared headers/patches, metadata and focused regression sources only; no repository or old results tree copy.'}
    path=folder/'snapshot.json'
    if not path.exists(): save(path,manifest)
    return folder


def inputs(run,selected):
    paths={Path(__file__).resolve(),HERE/'controls.py',HERE/'build-controls.py',HERE/'control-source-audit.json',HERE/'controls-execution.json',
           HERE/'worker-replay.py',HERE/'environment-preflight.py',HERE/'environment-preflight.json',ROOT/'build/performance-env.sh',
           ROOT/'build/next-hills/measure_delivery.py',
           ROOT/'build/emsdk/goose-to-wasm-sdk.json',ROOT/'build/emsdk/.emscripten',
           HERE/'plan.json',run/'plan.json',
           ROOT/'build/bin/goose',ROOT/'build/bin/goose-wasmtime',ROOT/'build/bin/goose-wasmtime.json',
           ROOT/'build/source.json',ROOT/'build/toolchain.json',ROOT/'toolchain.json',ROOT/'requirements.txt',
           ROOT/'docs/capabilities.json',ROOT/'.github/workflows/ci.yml',ROOT/'build/native/CMakeCache.txt'}
    for folder,patterns in [('compiler',('*.h',)),('scripts',('*.py','*.mjs')),('oracle',('*.py',)),
                            ('oracle/tests',('*.py',)),
                            ('tests',('*.py',)),('tests/fixtures',('*.goose','*.json')),
                            ('bench',('*.py','*.c')),('bench/langarena',('*.json',)),
                            ('bench/langarena/ports',('*.goose',)),('examples',('*.goose','*.py','*.json')),
                            ('examples/expected',('*.out',)),('capabilities',('*.json',)),('host',('*.cpp','*.json')),
                            ('build/bin/stdlib',('*.goose',)),('build/bin/include',('**/*.h',))]:
        for pattern in patterns: paths.update((ROOT/folder).glob(pattern))
    source=load(ROOT/'build/source.json')
    paths.update(ROOT/name for name in source['patches'])
    paths.update(ROOT/'build/source/src'/name for name in ('ast.h','builtins.h','clone.h'))
    snapshot=Path(selected['source_snapshot'])
    paths.update(snapshot/name for name in load(snapshot/'snapshot.json')['input_sha256'])
    paths.add(snapshot/'snapshot.json')
    paths.update(Path(path) for path in selected['review_inputs'])
    for reference in selected['baseline_references'].values():
        baseline=Path(reference);base_root=baseline.parent.parent
        paths.update((baseline,base_root/'source.json',base_root/'toolchain.json'))
    for reference in selected['control_references'].values():
        baseline=Path(reference);control=baseline.parent.parent.parent
        paths.update(control/name for name in ('preparation.json','before.h','disable.patch','build-execution.json','build.log'))
        paths.add(control/'build/control-toolchain-match.json')
        for part in ('shadow','build/compiler'):
            for pattern in ('*.h','*.patch','*.py'):paths.update((control/part).rglob(pattern))
        paths.add(control/'shadow/toolchain.json')
        paths.update(control/'build'/name for name in ('source.json','toolchain.json','native/CMakeCache.txt'))
        paths.update((control/'build/bin/stdlib').glob('*.goose'))
        paths.update((control/'build/bin/include').glob('**/*.h'))
    for name in ('node','emcc','gcc','c++','clang'):
        location=shutil.which(name)
        if location: paths.add(Path(location).resolve())
    paths.add(Path(sys.executable).resolve())
    import wasmtime._ffi as ffi
    paths.add(Path(ffi.dll._name).resolve())
    host=load(ROOT/'build/bin/goose-wasmtime.json')
    paths.add(Path(host['library']))
    paths.update(Path(name) for name in host['input_sha256'])
    require(all(path.is_file() for path in paths),'one or more bounded qualification inputs are unavailable')
    return sorted(paths)


def verify(run,selected,pins):
    require(sha(ROOT/'build/bin/goose')==selected['compiler_sha256'],'selected compiler changed')
    require({str(path) for path in inputs(run,selected)}==set(pins),'qualification input inventory changed')
    require(all(sha(path)==value for path,value in pins.items()),'qualification input bytes changed')


def seal(args,run):
    from controls import CONTROLS
    require(args.compiler_sha,'seal requires the explicit selected compiler SHA')
    require(not (run/'selected.json').exists(),'preserve prior sealed run; select another output directory')
    require(shutil.which('emcc') is not None,'source build/performance-env.sh before qualification')
    preflight=load(HERE/'environment-preflight.json');require(preflight['status']=='passed','environment preflight failed')
    for row in preflight['tools'].values():require(sha(row['path'])==row['sha256'],'preflight tool changed')
    require(sha(ROOT/'build/bin/goose')==args.compiler_sha,'selected compiler differs')
    current=load(ROOT/'build/toolchain.json');references={};proofs={}
    for name,(header,marker,inserted) in CONTROLS.items():
        reference=getattr(args,name+'_reference')
        require(reference is not None,'missing matched control: '+name)
        reference=reference.resolve();expected=(HERE/(name+'-control/build/bin/goose')).resolve()
        require(reference==expected and os.access(reference,os.X_OK),'control path differs: '+name)
        build=reference.parent.parent;folder=build.parent
        metadata=load(build/'toolchain.json');source=load(build/'source.json');preparation=load(folder/'preparation.json')
        require(metadata['headers']==source['headers'] and metadata['patches']==source['patches'],'control source metadata differs')
        require(set(metadata['headers'])==set(current['headers']),'control header inventory differs')
        require(metadata['revision']==current['revision'] and metadata['patches']==current['patches'],'control upstream/patches differ')
        changed={key for key,value in current['headers'].items() if metadata['headers'][key]!=value}
        require(changed=={header},'control changes unrelated headers')
        before=(folder/'before.h').read_text()
        require(before==(ROOT/'compiler'/header).read_text() and before.count(marker)==1,'control baseline differs')
        require((build/'compiler'/header).read_text()==before.replace(marker,marker+inserted,1),'unexpected control edit')
        proof=load(build/'control-toolchain-match.json')
        require(proof['status']=='matched' and proof['selected_compiler_sha256']==args.compiler_sha and
                proof['control_compiler_sha256']==metadata['compiler_sha256']==sha(reference),'matched control identity differs')
        require(preparation['header_count']==len(current['headers'])==proof['header_count'],'control header count differs')
        references[name]=str(reference);proofs[name]=proof
    baselines={'memory':(MEMORY_REFERENCE,MEMORY_REFERENCE_SHA),'fresh':(FRESH_REFERENCE,FRESH_REFERENCE_SHA),
               'accepted':(ROOT/'build/next-levers/final/bin/goose','1b1ec504894d387ae0bbed287d2d3214e250e6dc9bbff2ffd2893a69c06a8874')}
    baseline_references={};baseline_headers={}
    for name,(path,expected) in baselines.items():
        require(os.access(path,os.X_OK) and sha(path)==expected,'baseline compiler differs: '+name)
        source=load(path.parent.parent/'source.json');metadata=load(path.parent.parent/'toolchain.json')
        require(metadata['compiler_sha256']==expected and metadata['headers']==source['headers'] and
                metadata['patches']==source['patches'],'baseline source metadata differs')
        baseline_references[name]=str(path);baseline_headers[name]=len(source['headers'])
    snapshot=small_snapshot(args.compiler_sha,ROOT/'build')
    selected={'compiler_sha256':args.compiler_sha,'compiler_bytes_verified':True,'source_snapshot':str(snapshot),
              'header_count':len(current['headers']),'control_references':references,'control_proofs':proofs,
              'baseline_references':baseline_references,'baseline_header_counts':baseline_headers,
              'resource_reference':references['resource'],'named_reference':references['named'],
              'private_reference':references['private'],'stencil_reference':references['stencil'],
              'merge_reference':references['merge'],
              'memory_reference':str(MEMORY_REFERENCE),'fresh_reference':str(FRESH_REFERENCE),
              'expected':EXPECTED,'created_utc':datetime.now(timezone.utc).isoformat(),
              'coverage':'74 focused commands, six differential shards, 11484 stateless host observations and a worker replay whose effective count is derived from verified module/input groups over 3828 aliases.',
              'unique_host_module_policy':'Fresh-run byte catalog only; no historical report or alias closure.'}
    run.mkdir(parents=True,exist_ok=True);shutil.copyfile(HERE/'plan.json',run/'plan.json')
    reviews=[HERE/'static-review.json',HERE/'test-static-review.json']
    require(all(path.is_file() for path in reviews),'campaign-specific source reviews must exist before sealing')
    (run/'reviews').mkdir()
    selected['review_inputs']=[];selected['review_source_sha256']={}
    for review in reviews:
        target=run/'reviews'/review.name;shutil.copyfile(review,target)
        selected['review_inputs'].append(str(target));selected['review_source_sha256'][str(review)]=sha(review)
    pins={str(path):sha(path) for path in inputs(run,selected)}
    save(run/'input-pins.json',pins);save(run/'selected.json',selected)
    print('SEALED',args.compiler_sha,len(pins),'inputs;',len(current['headers']),'declared headers; no tests executed',flush=True)


def focused(run,selected,pins,environment):
    output=run/'focused';output.mkdir(parents=True,exist_ok=True)
    report={'status':'running','compiler_sha256':selected['compiler_sha256'],'commands':[]}
    commands=load(run/'plan.json')['commands'];require(len(commands)==EXPECTED['focused_commands'],'focused inventory differs')
    require(not (output/'report.json').exists(),'refusing to replace focused results')
    for index,parts in enumerate(commands):
        require(sha(ROOT/'build/bin/goose')==selected['compiler_sha256'],'compiler changed during focused gates')
        require(not (run/'stop').exists(),'qualification stop marker exists')
        command=[sys.executable,*[part.format(run=str(run),resource_reference=selected['resource_reference'],
                                            named_reference=selected['named_reference'],
                                            memory_reference=selected['memory_reference'],
                                            fresh_reference=selected['fresh_reference'],
                                            private_reference=selected['private_reference'],
                                            stencil_reference=selected['stencil_reference'],
                                            merge_reference=selected['merge_reference'],
                                            host=str(ROOT/'build/bin/goose-wasmtime')) for part in parts]]
        log=output/(str(index).zfill(2)+'-'+Path(parts[0]).stem+'.log')
        print('START',index,parts[0],flush=True);started=time.monotonic()
        with log.open('w') as stream: result=subprocess.run(command,cwd=ROOT,env=environment,stdout=stream,stderr=subprocess.STDOUT)
        row={'command':command,'exit_status':result.returncode,'wall_seconds':time.monotonic()-started,'log':str(log),'script_sha256':pins[str(ROOT/parts[0])]}
        report['commands'].append(row);save(output/'report.json',report)
        print('DONE',index,result.returncode,flush=True)
        if result.returncode:
            report['status']='failed';save(output/'report.json',report);return result.returncode
    report['status']='passed';save(output/'report.json',report);return 0


def gates(args,run,selected,pins,environment):
    require(not (run/'execution.json').exists(),'refusing to replace prior gate results')
    verify(run,selected,pins)
    sys.path.insert(0,str(ROOT/'bench'));import qualify_compiler as merger
    sys.path.insert(0,str(ROOT/'tests'));from run_differential import cases
    matrix=cases();require(len(matrix)==EXPECTED['cases'],'differential case inventory changed')
    diff=run/'differential';diff.mkdir(parents=True,exist_ok=True)
    jobs=[('focused',[sys.executable,str(Path(__file__).resolve()),'focused','--output-dir',str(run)],run/'focused-runner.log')]
    configurations={};commands={}
    for backend in merger.BACKENDS:
        for level in merger.LEVELS:
            key=(backend,level);name=f'{backend}-O{level}';configuration=merger.expected_configuration(backend,level,'')
            configurations[key]=configuration
            command=[sys.executable,str(ROOT/'tests/run_differential.py'),'--goose',str(ROOT/'build/bin/goose'),
                     '--backends',backend,'--levels',str(level),'--engines','v8','wasmtime','--output-dir',str(diff/'shards'/name)]
            if configuration['skip_refusals']: command.append('--skip-refusals')
            commands[key]=command;jobs.append((name,command,diff/(name+'.log')))
    order={'c-wasm-O2':0,'c-wasm-O0':1,'focused':2,'native-O0':3,'direct-O2':4,'direct-O0':5,'native-O2':6}
    jobs.sort(key=lambda job:order[job[0]])
    lock=threading.Lock();abort=threading.Event();active={};rows=[]
    def stop():
        abort.set();(run/'stop').write_text('Stopped after a qualification failure; preserve this run.\n')
        with lock: processes=list(active.values())
        for process in processes:
            if process.poll() is None:
                try: os.killpg(process.pid,signal.SIGTERM)
                except ProcessLookupError: pass
    def execute(job):
        name,command,log=job
        if abort.is_set(): return {'name':name,'status':'not-started'}
        print('START',name,flush=True);started=time.monotonic()
        with log.open('w') as stream:
            process=subprocess.Popen(command,cwd=ROOT,env=environment,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,start_new_session=True)
            with lock: active[name]=process
            for line in process.stdout:
                stream.write(line);stream.flush()
                if name=='focused': print(line.rstrip(),flush=True)
                if line.startswith(('FAIL ','FAIL:','ERROR:','FAILED (')): stop()
            code=process.wait()
        with lock: active.pop(name,None)
        if code: stop()
        print('DONE',name,code,flush=True)
        return {'name':name,'command':command,'exit_status':code,'wall_seconds':time.monotonic()-started,'log':str(log)}
    started=time.monotonic()
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.jobs) as pool:
        for future in concurrent.futures.as_completed([pool.submit(execute,job) for job in jobs]):
            rows.append(future.result());save(run/'execution.json',{'status':'running','jobs':args.jobs,'observations':rows})
    if abort.is_set():
        save(run/'execution.json',{'status':'failed','jobs':args.jobs,'observations':rows});raise RuntimeError('qualification failed; inspect retained logs')
    reports={}
    for key in configurations:
        path=diff/'shards'/f'{key[0]}-O{key[1]}'/'report.json';report=load(path)
        report['_report_sha256']=sha(path);report['_command']=commands[key];reports[key]=report
    combined,shards=merger.combine(reports,matrix,configurations,selected['compiler_sha256'],False)
    comparisons=sum(row['backend']!='native' and row.get('kind')!='compile-refusal' for row in combined['results'])
    require(combined['observations']==9573 and combined['failures']==0 and comparisons==7656,'differential exact counts differ')
    require(load(run/'focused/report.json')['status']=='passed' and len(load(run/'focused/report.json')['commands'])==EXPECTED['focused_commands'],'focused gate coverage differs')
    verify(run,selected,pins)
    combined['qualification_execution']={'method':'At most four total jobs: one sequential focused pipeline and six backend/O0,O2 shards; all qualification internal pools capped1.',
        'wall_seconds':time.monotonic()-started,'jobs':args.jobs,'shards':shards,'native_stdout_comparisons':comparisons,'input_sha256':pins,'internal_thread_limits':CAPS}
    save(diff/'report.json',combined)
    save(run/'execution.json',{'status':'passed','compiler_sha256':selected['compiler_sha256'],'expected':EXPECTED,
         'jobs':args.jobs,'observations':rows,'wall_seconds':time.monotonic()-started,'input_sha256':pins})
    print('PASS74 focused;9573 differential;7656 native comparisons',flush=True)


def host(args,run,selected,pins,environment):
    require(load(run/'execution.json')['status']=='passed','host replay requires passing gates')
    require(not (run/'host/report.json').exists(),'refusing to replace prior host replay')
    verify(run,selected,pins)
    command=[sys.executable,str(ROOT/'bench/qualify_wasmtime_host.py'),'--baseline-dir',str(run/'differential'),
             '--host',str(ROOT/'build/bin/goose-wasmtime'),'--output-dir',str(run/'host'),'--jobs',str(args.jobs)]
    started=time.monotonic()
    with (run/'host-runner.log').open('w') as stream: result=subprocess.run(command,cwd=ROOT,env=environment,stdout=stream,stderr=subprocess.STDOUT)
    execution={'command':command,'exit_status':result.returncode,'wall_seconds':time.monotonic()-started,'log':str(run/'host-runner.log')}
    save(run/'host-execution.json',execution);require(result.returncode==0,'host replay failed; inspect retained logs')
    report=load(run/'host/report.json')
    require(report['coverage_exact'] and report['failures']==0 and report['observations']==11484,'host replay exact coverage differs')
    verify(run,selected,pins)
    catalog(run)
    print('PASS11484 host observations;',report['unique_wasm'],'current unique modules',flush=True)


def catalog(run):
    # Record only guests produced in this bounded run. Historical archive
    # indexes use a different format and are left for the packager to assess.
    require(not (run/'artifact-catalog.json').exists(),'refusing to replace artifact catalog')
    objects={}
    paths=[path for path in run.rglob('*') if path.is_file() and path.suffix in {'.wasm','.bin','.cwasm'}]
    for path in sorted(paths):
        value=sha(path)
        if value in objects:
            objects[value]['fresh_paths'].append(str(path));continue
        row={'sha256':value,'bytes':path.stat().st_size,'fresh_paths':[str(path)]}
        row['retention']='fresh-run-byte-object'
        objects[value]=row
    save(run/'artifact-catalog.json',{'status':'catalogued','policy':'Only guests in this run were scanned; no historical aliases or archives are reused.',
        'fresh_paths':len(paths),'unique_objects':len(objects),'objects':objects})


def worker(args,run,selected,pins,environment):
    require(load(run/'host/report.json')['status']=='pass','worker replay requires passing standard host replay')
    verify(run,selected,pins)
    command=[sys.executable,'-B',str(HERE/'worker-replay.py'),'--baseline-dir',str(run/'differential'),
             '--host-report',str(run/'host/report.json'),'--host',str(ROOT/'build/bin/goose-wasmtime'),
             '--output',str(run/'worker-replay')]
    started=time.monotonic()
    with (run/'worker-runner.log').open('w') as stream:result=subprocess.run(command,cwd=ROOT,env=environment,stdout=stream,stderr=subprocess.STDOUT)
    save(run/'worker-execution.json',{'command':command,'exit_status':result.returncode,
         'wall_seconds':time.monotonic()-started,'log':str(run/'worker-runner.log')})
    require(result.returncode==0,'worker replay failed; inspect preserved logs')
    report=load(run/'worker-replay/report.json')
    require(report['status']=='passed' and report['coverage_exact'] and
            report['observations']==report['derived_effective_cases'] and report['underlying_aliases']==3828 and
            report['failures']==0,'worker replay exact coverage differs')
    verify(run,selected,pins)
    print('PASS',report['observations'],'derived effective worker observations;3828 underlying aliases',flush=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('phase',choices=['seal','gates','focused','host','worker'])
    parser.add_argument('--output-dir',type=Path,default=HERE/'attempt-1')
    parser.add_argument('--compiler-sha')
    parser.add_argument('--resource-reference',type=Path)
    parser.add_argument('--named-reference',type=Path)
    parser.add_argument('--private-reference',type=Path)
    parser.add_argument('--stencil-reference',type=Path)
    parser.add_argument('--merge-reference',type=Path)
    parser.add_argument('--jobs',type=int,default=4)
    args=parser.parse_args();require(1<=args.jobs<=4,'jobs must be1..4')
    require(__debug__,'assertions must remain enabled');run=args.output_dir.resolve()
    require(run.is_relative_to(HERE.resolve()),'qualification output must remain beneath bounded campaign directory')
    if load(HERE/'plan.json').get('status')!='approved':
        raise RuntimeError('qualification plan is planned/unmeasured; coordinator review is required before execution')
    if args.phase=='seal': seal(args,run);return
    selected=load(run/'selected.json');pins=load(run/'input-pins.json');environment=os.environ.copy();environment.update(CAPS)
    if args.phase=='focused': raise SystemExit(focused(run,selected,pins,environment))
    if args.phase=='gates': gates(args,run,selected,pins,environment)
    if args.phase=='host': host(args,run,selected,pins,environment)
    if args.phase=='worker': worker(args,run,selected,pins,environment)


if __name__=='__main__': main()
