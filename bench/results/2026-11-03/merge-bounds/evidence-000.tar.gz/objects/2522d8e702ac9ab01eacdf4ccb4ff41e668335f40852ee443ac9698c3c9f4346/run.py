import hashlib,json,subprocess,sys
from pathlib import Path
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tests'))
from test_function_value_forwarding import function_bodies
import test_merge_bounds as tests
variants={'baseline':root/'build/next-levers/final/bin/goose','merge':root/'build/next-hills/merge/bin/goose','matched-control':root/'build/next-hills/merge-control/build/bin/goose'}
rows={};commands=[]
for source_name,source in [('port',root/'bench/langarena/ports/sort_merge.goose'),('full-example',root/'examples/sorting.goose'),('named-adapter',root/'build/runtime-reference/inputs/sorting.goose')]:
 rows[source_name]={};(out/(source_name+'.goose')).write_bytes(source.read_bytes())
 for label,compiler in variants.items():
  wasm=out/(source_name+'-'+label+'.wasm');stats=wasm.with_suffix('.json');command=[str(compiler),str(source),'--offline','--target','wasm-direct','-O2','--wasm-stats',str(stats),'-o',str(wasm)]
  result=subprocess.run(command,capture_output=True);(out/(source_name+'-'+label+'.stdout')).write_bytes(result.stdout);(out/(source_name+'-'+label+'.stderr')).write_bytes(result.stderr)
  commands.append({'command':command,'exit_status':result.returncode})
  assert result.returncode==0,(command,result.stderr)
  bodies={name:{'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}for name,body in function_bodies(wasm,json.loads(stats.read_text()))if 'merge'in name}
  rows[source_name][label]={'source':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'module_bytes':wasm.stat().st_size,'module_sha256':hashlib.sha256(wasm.read_bytes()).hexdigest(),'bodies':bodies}
counts={'numeric':4*4*14,'invalid_guards':2*4*(len(tests.cases('i64'))-14),'renamed_exclusive':4*14,'fallback':3*4*3}
scenarios=sum(counts.values());value={'status':'passed','commands':commands,'results':rows,'case_counts':{'per_kind':len(tests.cases('i64')),'configurations':40,'scenario_configurations_per_compiler_engine':counts,'total_scenario_configurations_per_compiler_engine':scenarios,'candidate_and_reference_two_engine_runs':scenarios*4,'native_runs':40,'ordinary_candidate_two_engine_runs':80},'claim':'Static merge-body differences only; no performance or guest execution in this proof.'}
(out/'report.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value,indent=2))
