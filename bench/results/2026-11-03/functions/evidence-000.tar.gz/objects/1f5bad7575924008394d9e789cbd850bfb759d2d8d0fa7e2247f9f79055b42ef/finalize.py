"""Finalize passed Functions qualification without changing any raw report."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json

ROOT=Path(__file__).resolve().parents[3]
Q=Path(__file__).resolve().parent
RUN=Q/'attempt-1'
EXPECTED='5e3b87720d24f3285a5f9df57989c200bf7152a28f296cfd3af0220db1cc2edf'


def load(path):return json.loads(path.read_text())


def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


pins=load(RUN/'input-pins.json');assert all(sha(path)==value for path,value in pins.items())
selected=load(RUN/'selected.json');assert sha(ROOT/'build/bin/goose')==selected['compiler_sha256']==EXPECTED
focused=load(RUN/'focused/report.json');diff=load(RUN/'differential/report.json');host=load(RUN/'host/report.json');catalog=load(RUN/'artifact-catalog-all.json')
assert focused['status']=='passed' and len(focused['commands'])==66 and all(row['exit_status']==0 for row in focused['commands'])
assert diff['observations']==9573 and diff['cases']==978 and diff['failures']==0 and diff['qualification_execution']['native_stdout_comparisons']==7656
assert host['status']=='pass' and host['observations']==11484 and host['failures']==0 and host['coverage_exact']
assert host['input_sha256']==host['input_sha256_after'] and host['aot_sha256']==host['aot_sha256_after']
assert len(host['preparations'])==host['unique_wasm']==1574
control=load(Q/'resource-control/build/toolchain.json')
reports={name:str(path) for name,path in [('focused',RUN/'focused/report.json'),('differential',RUN/'differential/report.json'),('host',RUN/'host/report.json'),('artifact_catalog',RUN/'artifact-catalog-all.json'),('resource_control',Q/'resource-control/build/control-toolchain-match.json')]}
record={'status':'passed','finished_utc':datetime.now(timezone.utc).isoformat(),'compiler_sha256':EXPECTED,'source_snapshot':selected['source_snapshot'],
    'input_pin_count':len(pins),'all_input_pins_unchanged':True,'focused_commands':66,'differential_observations':9573,'cases':978,
    'native_stdout_comparisons':7656,'host_observations':11484,'host_unique_modules':1574,'failures':0,'jobs_max':4,
    'qualification_only_pool_caps':{'EMCC_CORES':'1','BINARYEN_CORES':'1','RAYON_NUM_THREADS':'1','OMP_NUM_THREADS':'1'},
    'resource_control_compiler_sha256':control['compiler_sha256'],
    'control_scope':'Matched Clang/Ninja Release, same32headers except one ResourceFreeBlock early return. Exact negative byte comparisons and positive watermark count checks passed.',
    'unused_gcc_control':'First control build selected GCC by default; never used for comparisons. Binary/cache omitted; hash, flags, metadata and actual log retained.',
    'artifact_fresh_paths':catalog['fresh_paths'],'artifact_unique_objects':catalog['unique_objects'],'artifact_new_byte_objects':catalog['new_objects'],
    'artifact_reused_byte_objects':catalog['unique_objects']-catalog['new_objects'],'reports':reports,'report_sha256':{name:sha(path) for name,path in reports.items()},
    'measurements':False,'cpu_work_stopped':True}
assert not (Q/'summary.json').exists()
(Q/'summary.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
