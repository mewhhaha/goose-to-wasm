"""Interleaved Functions diagnostics; no claims about other workload cohorts."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import random
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'build/functions-hill/screen-none'
BASE = ROOT / 'build/functions-hill/baseline'
HOST = ROOT / 'build/bin/goose-wasmtime'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def run(argv, name):
    folder = OUT / 'logs' / name
    folder.mkdir(parents=True, exist_ok=True)
    start = time.perf_counter_ns()
    result = subprocess.run(list(map(str, argv)), input=b'', capture_output=True, cwd=ROOT, timeout=120)
    elapsed = (time.perf_counter_ns() - start) / 1e9
    (folder / 'command.json').write_text(json.dumps(list(map(str, argv)), indent=2) + '\n')
    (folder / 'stdout').write_bytes(result.stdout)
    (folder / 'stderr').write_bytes(result.stderr)
    assert result.returncode == 0, (argv, result.stderr[-1500:])
    return result, elapsed


def main():
    sys.path.insert(0, str(ROOT / 'bench'))
    import benchmark as common
    OUT.mkdir(parents=True, exist_ok=True)
    old = json.loads((ROOT / 'bench/results/2026-11-02/full-hills/examples.json').read_bytes())
    native = next(Path(r['artifact']) for r in old['observations'] if r['kind'] == 'build'
                  and r['name'] == 'functions' and r['backend'] == 'native')
    golden = (ROOT / 'examples/expected/functions.out').read_bytes()
    node = Path(os.environ['FUNCTIONS_NODE']).resolve()
    wasm = ROOT / 'build/functions-hill/dead/O2.wasm'
    fast_host = ROOT / 'build/functions-hill/none-screen/host'
    paths = [Path(__file__), HOST, fast_host, native, ROOT/'examples/functions.goose', ROOT/'examples/expected/functions.out', wasm]
    pins = {str(p): sha(p) for p in paths}
    report = {'status':'running','started_utc':datetime.now(timezone.utc).isoformat(),
              'method':'Shuffled back-to-back fresh full-process runs, identical Functions Wasm; Cranelift speed vs none. Native C built earlier, freshly executed. Default affinity/pools.',
              'input_sha256':pins,'observations':[],'phase_probes':[]}
    commands = {'native-C':[native], 'speed':[HOST,wasm], 'none':[fast_host,wasm]}
    rng = random.Random(832347)
    for phase, count in [('warmup', 2), ('measure', 61)]:
        for sample in range(count):
            cells = list(commands)
            rng.shuffle(cells)
            for cell in cells:
                result, elapsed = run(commands[cell], f'{phase}/{sample}/{cell}')
                assert result.stdout == golden and result.stderr == b'', cell
                report['observations'].append({'phase': phase, 'sample': sample, 'cell': cell, 'seconds': elapsed})
    for sample in range(31):
        modes = ['speed','none'];rng.shuffle(modes)
        for mode in modes:
            timing=OUT/f'phase-{sample}-{mode}.json'
            result,elapsed=run([*commands[mode],'--timing-json',timing],f'phases/{sample}/{mode}')
            assert result.stdout==golden and result.stderr==b''
            report['phase_probes'].append({'sample':sample,'mode':mode,'wall_seconds':elapsed,'timing':json.loads(timing.read_bytes())})
    report['summary'] = {cell: common.summary([r['seconds'] for r in report['observations']
                                             if r['phase'] == 'measure' and r['cell'] == cell]) for cell in commands}
    indexed = {(r['sample'],r['cell']):r['seconds'] for r in report['observations'] if r['phase']=='measure'}
    report['paired_speedup']=common.summary([indexed[i,'speed']/indexed[i,'none'] for i in range(61)])
    assert pins == {str(p): sha(p) for p in paths}
    report['status'] = 'passed'
    report['finished_utc'] = datetime.now(timezone.utc).isoformat()
    (OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'status': report['status'], 'paired_speedup': report['paired_speedup'],
                      'medians_ms': {k: v['median'] * 1000 for k, v in report['summary'].items()}}, indent=2))


if __name__ == '__main__':
    main()
