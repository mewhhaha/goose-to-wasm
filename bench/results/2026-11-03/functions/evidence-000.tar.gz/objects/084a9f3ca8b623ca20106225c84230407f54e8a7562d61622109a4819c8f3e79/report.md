# LangArena qualification and measurements

Status: **passed**.

Upstream pin: `aab9b14998231ba905523b5ba3990ee03c46f64d`. Catalog: **50 tasks**. Adapted entrypoints: **7 tasks**, including six storage adaptations.

Mode: `measure`. Machine: AMD Ryzen 7 3800X, shared desktop host.
Compiler SHA-256: `5e3b87720d24f3285a5f9df57989c200bf7152a28f296cfd3af0220db1cc2edf`.

## Measurement contract

Whole-suite results use all original Goose kernel sources. The only staging patch changes the marker destination from `/tmp/recompile_marker` to a relative file inside the isolated run directory. The original checkout is hash-verified and never edited. Whole-suite compile times include all 50 tasks.

The adapted track uses the same seven port sources across native C, direct Wasm, and C-Wasm. Six ports replace growable storage; Fannkuch keeps its original fixed-array kernel. Official test/run inputs and checksums are unchanged. Preparation stays outside the clock; warmups mutate the same state used for measurement; the deterministic RNG is reset before measured iterations. Existing checksum work retains its original placement.

Cold builds and marker-edit builds launch fresh driver/compiler processes with `--no-cache`. OS caches and installed compiler/system-library caches are retained. A port marker edit changes its exit status from 0 to 1 after its two output lines, and the edited executable must retain the official checksum. Whole-suite edits change the actual marker file contents. Source bytes are restored in all cases. Optional unchanged cache hits are a separate phase. Edited sources still rerun the complete frontend.

The official whole-suite timer prints milliseconds; adapted ports print integer nanoseconds. Timed regions exclude process startup and preparation. Process wall time is retained separately. Sample counts below five are preliminary estimates; raw values and MAD are provided. These are local comparisons, not LangArena leaderboard scores or claims of complete direct-backend language support.

## Whole-suite compilation

| Backend | Phase | Samples | Median ms | MAD ms | Artifact bytes |
| --- | --- | ---: | ---: | ---: | ---: |

## Original-source correctness and runtime

| Task | Backend / engine | Profile | Samples | Region median ms | MAD ms | Process median ms |
| --- | --- | --- | ---: | ---: | ---: | ---: |

## Adapted workload compilation

| Task | Backend | Phase | Samples | Median ms | MAD ms | Artifact bytes |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| CLBG::Fannkuchredux | c-wasm | cold | 5 | 720.876 | 16.083 | 51983 |
| CLBG::Fannkuchredux | direct | cold | 5 | 68.076 | 1.025 | 4067 |
| CLBG::Fannkuchredux | native | cold | 5 | 299.462 | 10.897 | 22984 |
| CLBG::Mandelbrot | c-wasm | cold | 5 | 658.317 | 31.734 | 52059 |
| CLBG::Mandelbrot | direct | cold | 5 | 93.944 | 9.856 | 4650 |
| CLBG::Mandelbrot | native | cold | 5 | 295.077 | 12.998 | 23160 |
| Etc::Sieve | c-wasm | cold | 5 | 662.643 | 19.254 | 51597 |
| Etc::Sieve | direct | cold | 5 | 69.416 | 1.923 | 3281 |
| Etc::Sieve | native | cold | 5 | 296.196 | 21.790 | 23128 |
| Hash::CRC32 | c-wasm | cold | 5 | 647.184 | 11.335 | 51817 |
| Hash::CRC32 | direct | cold | 5 | 66.991 | 1.203 | 3309 |
| Hash::CRC32 | native | cold | 5 | 271.204 | 7.323 | 23008 |
| Hash::SHA256 | c-wasm | cold | 5 | 647.572 | 40.227 | 51826 |
| Hash::SHA256 | direct | cold | 5 | 68.616 | 1.066 | 6788 |
| Hash::SHA256 | native | cold | 5 | 300.623 | 7.238 | 23008 |
| Sort::Merge | c-wasm | cold | 5 | 678.286 | 39.580 | 52484 |
| Sort::Merge | direct | cold | 5 | 67.543 | 1.589 | 5453 |
| Sort::Merge | native | cold | 5 | 317.441 | 12.807 | 27416 |
| Sort::Quick | c-wasm | cold | 5 | 650.931 | 15.478 | 52043 |
| Sort::Quick | direct | cold | 5 | 67.860 | 2.096 | 4566 |
| Sort::Quick | native | cold | 5 | 285.072 | 4.458 | 23168 |

## Adapted workload runtime

| Task | Backend / engine | Profile | Samples | Region median ms | MAD ms | Engine compile + instantiate ms | Process median ms | Checksum |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| CLBG::Fannkuchredux | c-wasm / v8 | run | 5 | 2176.949 | 32.951 | 0.573 | 2641.513 | 135762480 |
| CLBG::Fannkuchredux | c-wasm / v8 | test | 1 | 0.021 | 0.000 | 0.566 | 27.157 | 4428 |
| CLBG::Fannkuchredux | c-wasm / wasmtime | run | 5 | 1504.677 | 4.325 | 24.648 | 1909.938 | 135762480 |
| CLBG::Fannkuchredux | c-wasm / wasmtime | test | 1 | 0.054 | 0.000 | 23.825 | 129.314 | 4428 |
| CLBG::Fannkuchredux | direct / v8 | run | 5 | 1272.616 | 13.317 | 0.267 | 1557.672 | 135762480 |
| CLBG::Fannkuchredux | direct / v8 | test | 1 | 0.029 | 0.000 | 0.256 | 24.439 | 4428 |
| CLBG::Fannkuchredux | direct / wasmtime | run | 5 | 1383.671 | 10.334 | 4.481 | 1762.774 | 135762480 |
| CLBG::Fannkuchredux | direct / wasmtime | test | 1 | 0.025 | 0.000 | 3.925 | 83.157 | 4428 |
| CLBG::Fannkuchredux | native / native | run | 5 | 1329.537 | 10.920 | — | 1582.245 | 135762480 |
| CLBG::Fannkuchredux | native / native | test | 1 | 0.011 | 0.000 | — | 0.773 | 4428 |
| CLBG::Mandelbrot | c-wasm / v8 | run | 5 | 957.460 | 3.456 | 0.579 | 1194.785 | 3455988829 |
| CLBG::Mandelbrot | c-wasm / v8 | test | 1 | 0.665 | 0.000 | 0.849 | 58.447 | 2236342953 |
| CLBG::Mandelbrot | c-wasm / wasmtime | run | 5 | 1082.361 | 3.680 | 24.134 | 1409.539 | 3455988829 |
| CLBG::Mandelbrot | c-wasm / wasmtime | test | 1 | 0.222 | 0.000 | 28.454 | 139.958 | 2236342953 |
| CLBG::Mandelbrot | direct / v8 | run | 5 | 966.678 | 2.403 | 0.251 | 1210.290 | 3455988829 |
| CLBG::Mandelbrot | direct / v8 | test | 1 | 0.365 | 0.000 | 0.296 | 29.243 | 2236342953 |
| CLBG::Mandelbrot | direct / wasmtime | run | 5 | 1020.769 | 1.766 | 3.802 | 1314.547 | 3455988829 |
| CLBG::Mandelbrot | direct / wasmtime | test | 1 | 0.189 | 0.000 | 4.424 | 86.035 | 2236342953 |
| CLBG::Mandelbrot | native / native | run | 5 | 935.667 | 3.940 | — | 1127.992 | 3455988829 |
| CLBG::Mandelbrot | native / native | test | 1 | 0.236 | 0.000 | — | 4.469 | 2236342953 |
| Etc::Sieve | c-wasm / v8 | run | 5 | 6807.659 | 449.581 | 0.561 | 8033.357 | 1042248060 |
| Etc::Sieve | c-wasm / v8 | test | 1 | 0.019 | 0.000 | 0.668 | 28.552 | 4660 |
| Etc::Sieve | c-wasm / wasmtime | run | 5 | 5436.468 | 14.012 | 24.794 | 6623.504 | 1042248060 |
| Etc::Sieve | c-wasm / wasmtime | test | 1 | 0.050 | 0.000 | 24.311 | 107.420 | 4660 |
| Etc::Sieve | direct / v8 | run | 5 | 1345.704 | 8.605 | 0.231 | 1692.841 | 1042248060 |
| Etc::Sieve | direct / v8 | test | 1 | 0.028 | 0.000 | 0.375 | 51.382 | 4660 |
| Etc::Sieve | direct / wasmtime | run | 5 | 1384.552 | 4.397 | 3.940 | 1749.739 | 1042248060 |
| Etc::Sieve | direct / wasmtime | test | 1 | 0.022 | 0.000 | 3.883 | 91.847 | 4660 |
| Etc::Sieve | native / native | run | 5 | 873.886 | 4.905 | — | 1052.035 | 1042248060 |
| Etc::Sieve | native / native | test | 1 | 0.005 | 0.000 | — | 4.943 | 4660 |
| Hash::CRC32 | c-wasm / v8 | run | 5 | 459.645 | 2.329 | 0.584 | 590.280 | 2318723244 |
| Hash::CRC32 | c-wasm / v8 | test | 1 | 0.014 | 0.000 | 0.726 | 45.731 | 3031698216 |
| Hash::CRC32 | c-wasm / wasmtime | run | 5 | 413.156 | 5.684 | 24.296 | 610.829 | 2318723244 |
| Hash::CRC32 | c-wasm / wasmtime | test | 1 | 0.053 | 0.000 | 24.965 | 107.950 | 3031698216 |
| Hash::CRC32 | direct / v8 | run | 5 | 503.582 | 3.655 | 0.269 | 648.968 | 2318723244 |
| Hash::CRC32 | direct / v8 | test | 1 | 0.034 | 0.000 | 0.348 | 48.368 | 3031698216 |
| Hash::CRC32 | direct / wasmtime | run | 5 | 441.785 | 1.881 | 3.620 | 622.074 | 2318723244 |
| Hash::CRC32 | direct / wasmtime | test | 1 | 0.025 | 0.000 | 4.559 | 85.865 | 3031698216 |
| Hash::CRC32 | native / native | run | 5 | 1383.231 | 8.445 | — | 1666.774 | 2318723244 |
| Hash::CRC32 | native / native | test | 1 | 0.056 | 0.000 | — | 3.605 | 3031698216 |
| Hash::SHA256 | c-wasm / v8 | run | 5 | 1048.547 | 9.234 | 0.585 | 1307.300 | 2844672256 |
| Hash::SHA256 | c-wasm / v8 | test | 1 | 0.007 | 0.000 | 0.607 | 29.852 | 1036619072 |
| Hash::SHA256 | c-wasm / wasmtime | run | 5 | 977.929 | 8.155 | 24.645 | 1296.479 | 2844672256 |
| Hash::SHA256 | c-wasm / wasmtime | test | 1 | 0.045 | 0.000 | 26.441 | 108.791 | 1036619072 |
| Hash::SHA256 | direct / v8 | run | 5 | 265.384 | 0.754 | 0.274 | 360.330 | 2844672256 |
| Hash::SHA256 | direct / v8 | test | 1 | 0.005 | 0.000 | 0.425 | 53.113 | 1036619072 |
| Hash::SHA256 | direct / wasmtime | run | 5 | 333.704 | 0.505 | 5.420 | 494.716 | 2844672256 |
| Hash::SHA256 | direct / wasmtime | test | 1 | 0.017 | 0.000 | 5.508 | 84.060 | 1036619072 |
| Hash::SHA256 | native / native | run | 5 | 598.643 | 6.644 | — | 723.782 | 2844672256 |
| Hash::SHA256 | native / native | test | 1 | 0.002 | 0.000 | — | 1.561 | 1036619072 |
| Sort::Merge | c-wasm / v8 | run | 5 | 1334.007 | 8.028 | 0.560 | 1637.523 | 61757772 |
| Sort::Merge | c-wasm / v8 | test | 1 | 17.254 | 0.000 | 0.838 | 79.179 | 2548773 |
| Sort::Merge | c-wasm / wasmtime | run | 5 | 2763.705 | 18.707 | 24.584 | 3440.756 | 61757772 |
| Sort::Merge | c-wasm / wasmtime | test | 1 | 24.460 | 0.000 | 24.966 | 150.387 | 2548773 |
| Sort::Merge | direct / v8 | run | 5 | 1893.133 | 22.389 | 0.264 | 2305.471 | 61757772 |
| Sort::Merge | direct / v8 | test | 1 | 17.639 | 0.000 | 0.271 | 57.350 | 2548773 |
| Sort::Merge | direct / wasmtime | run | 5 | 2092.606 | 41.736 | 4.177 | 2559.915 | 61757772 |
| Sort::Merge | direct / wasmtime | test | 1 | 17.863 | 0.000 | 4.417 | 113.765 | 2548773 |
| Sort::Merge | native / native | run | 5 | 1409.092 | 4.272 | — | 1694.595 | 61757772 |
| Sort::Merge | native / native | test | 1 | 13.473 | 0.000 | — | 23.339 | 2548773 |
| Sort::Quick | c-wasm / v8 | run | 5 | 1428.790 | 7.517 | 0.589 | 1750.486 | 61757772 |
| Sort::Quick | c-wasm / v8 | test | 1 | 14.261 | 0.000 | 0.653 | 53.924 | 2548773 |
| Sort::Quick | c-wasm / wasmtime | run | 5 | 1649.707 | 6.889 | 23.819 | 2092.400 | 61757772 |
| Sort::Quick | c-wasm / wasmtime | test | 1 | 15.738 | 0.000 | 25.319 | 133.933 | 2548773 |
| Sort::Quick | direct / v8 | run | 5 | 1350.708 | 1.472 | 0.270 | 1657.927 | 61757772 |
| Sort::Quick | direct / v8 | test | 1 | 13.894 | 0.000 | 0.260 | 55.657 | 2548773 |
| Sort::Quick | direct / wasmtime | run | 5 | 1778.258 | 40.294 | 3.814 | 2190.381 | 61757772 |
| Sort::Quick | direct / wasmtime | test | 1 | 15.240 | 0.000 | 3.970 | 109.079 | 2548773 |
| Sort::Quick | native / native | run | 5 | 1207.179 | 11.348 | — | 1452.657 | 61757772 |
| Sort::Quick | native / native | test | 1 | 12.254 | 0.000 | — | 20.712 | 2548773 |

## Qualification and limits

- Seven adapted entrypoints (six change storage, one changes only the harness) are a subset of the 50-task catalog; they do not establish unmodified whole-suite Wasm support.
- No local result is a LangArena leaderboard rank: source/compiler versions, target layout, host, flags, and coverage differ.
- Cold builds retain OS and compiler system-library caches; they are complete uncached driver builds, not disk-cold experiments.

The full 50-task coverage matrix, raw commands/output, source and artifact hashes, tool versions, input values, environment overrides (including `EM_NODE_JS`), and phase timings are in `report.json` and adjacent logs. `Hash::SHA256` retains LangArena's custom hash workload; it is not standard cryptographic SHA-256.
