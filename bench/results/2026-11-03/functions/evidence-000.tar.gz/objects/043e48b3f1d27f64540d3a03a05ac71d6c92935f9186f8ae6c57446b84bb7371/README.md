# Functions qualification preparation

Prepared only. No build, test, engine, benchmark or binary-hash execution has run.
The provisional `2aa81824…` snapshot contains 32 headers, two patches, source and
toolchain metadata, and the writer regression. Final selection remains open.

After the coordinator closes measurements and declares the final compiler:

```sh
source build/performance-env.sh
python build/functions-hill/qualification/run.py seal \
  --compiler-sha FINAL_SHA \
  --resource-reference /absolute/current-source-resource-block-disabled/goose
python build/functions-hill/qualification/run.py gates --jobs 4
python build/functions-hill/qualification/run.py host --jobs 4
```

`seal` checks actual compiler bytes, the 32-header source identity and the
same-source resource control; it records bounded input hashes before execution.
The control must preserve the current writer and all unrelated headers. Its
resource-free-block predicate is disabled, so historical negative byte-equality
checks remain meaningful after universal writer canonicalization. Old 9bf/hash
compiler modules are not a valid exact-byte control for this new compiler.

The gates run 66 focused commands (prior 65 plus the writer regression) and six
backend/O0,O2 differential shards: 978 cases, 9,573 observations, 7,656 native
stdout comparisons. Only direct/O0 reruns the three compile refusals. At most
four child jobs run concurrently; internal qualification pools are capped at
one. Host replay follows in a separate phase: 11,484 observations across raw,
raw/no-parallel, and freshly prepared AOT/no-parallel. Unique module count is
derived from current bytes; the prior 1,574 is context, not an imposed result.

All outputs stay under `attempt-1`; use a different `--output-dir` beneath this
directory for a new attempt. Existing results and sealed inputs are never
replaced. Source inventory and bytes are checked before and after qualification.
No README/chart/prose or old evidence tree is a mutable qualification input.

After replay, `artifact-catalog.json` identifies genuinely new byte objects and
references already published objects by archive/member SHA. It scans only this
run. Old reports, repository snapshots, Rust/SDK caches and historical trees are
not copied or recursively resolved. Artifact deduplication does not replace fresh
current-host preparation or replay. Final delivery must verify referenced
archive/member bytes independently. The prior report links are in
`prior-evidence.json`; all prior raw reports remain untouched.

Builds/tests/hashing and any later measurements must have separate CPU windows.
These qualification pool caps must not carry into runtime measurements.
