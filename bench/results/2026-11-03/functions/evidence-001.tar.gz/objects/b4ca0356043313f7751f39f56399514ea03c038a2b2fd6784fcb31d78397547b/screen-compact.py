"""Interleaved Functions diagnostics; no claims about other workload cohorts."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import random
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'build/functions-hill/screen-compact'
BASE = ROOT / 'build/functions-hill/baseline'
HOST = ROOT / 'build/bin/goose-wasmtime'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def run(argv, name):
    folder = OUT / 'logs' / name
    folder.mkdir(parents=True, exist_ok=True)
    start = time.perf_counter_ns()
    result = subprocess.run(list(map(str, argv)), input=b'', capture_output=True, cwd=ROOT, timeout=120)
    elapsed = (time.perf_counter_ns() - start) / 1e9
    (folder / 'command.json').write_text(json.dumps(list(map(str, argv)), indent=2) + '\n')
    (folder / 'stdout').write_bytes(result.stdout)
    (folder / 'stderr').write_bytes(result.stderr)
    assert result.returncode == 0, (argv, result.stderr[-1500:])
    return result, elapsed


def main():
    sys.path.insert(0, str(ROOT / 'bench'))
    import benchmark as common
    OUT.mkdir(parents=True, exist_ok=True)
    old = json.loads((ROOT / 'bench/results/2026-11-02/full-hills/examples.json').read_bytes())
    native = next(Path(r['artifact']) for r in old['observations'] if r['kind'] == 'build'
                  and r['name'] == 'functions' and r['backend'] == 'native')
    golden = (ROOT / 'examples/expected/functions.out').read_bytes()
    node = Path(os.environ['FUNCTIONS_NODE']).resolve()
    variants = {'baseline-O2': BASE / 'O2.wasm', 'compact-O2': ROOT / 'build/functions-hill/compact/O2.wasm'}
    paths = [Path(__file__), HOST, HOST.with_suffix('.json'), native, node,
             ROOT / 'scripts/run_wasm.mjs', ROOT / 'examples/functions.goose',
             ROOT / 'examples/expected/functions.out', *variants.values()]
    pins = {str(p): sha(p) for p in paths}
    report = {'status': 'running', 'started_utc': datetime.now(timezone.utc).isoformat(),
              'method': 'Fresh process launch-to-exit. Randomized variant/mode blocks; normal CPU affinity and pool defaults. Native C built previously, executed freshly. Engine phase probes are separately instrumented diagnostics.',
              'cpu_affinity': sorted(os.sched_getaffinity(0)),
              'environment': {k: os.environ.get(k) for k in ['RAYON_NUM_THREADS', 'OMP_NUM_THREADS', 'BINARYEN_CORES']},
              'input_sha256': pins, 'variants': {k: {'wasm': str(v), 'sha256': sha(v)} for k, v in variants.items()},
              'host': json.loads(HOST.with_suffix('.json').read_bytes()), 'observations': [], 'phase_probes': []}
    commands = {'native-C': [native]}
    for name, wasm in variants.items():
        aot = OUT / (name + '.cwasm')
        result, elapsed = run([HOST, '--compile', wasm, aot], 'prepare/' + name)
        assert result.stdout == result.stderr == b''
        report['variants'][name].update(aot=str(aot), aot_sha256=sha(aot), preparation_seconds=elapsed)
        commands[name + '/ordinary'] = [HOST, wasm]
        commands[name + '/aot'] = [HOST, '--precompiled', aot]
        commands[name + '/v8'] = [node, ROOT / 'scripts/run_wasm.mjs', wasm]
    rng = random.Random(832347)
    for phase, count in [('warmup', 2), ('measure', 61)]:
        for sample in range(count):
            cells = list(commands)
            rng.shuffle(cells)
            for cell in cells:
                result, elapsed = run(commands[cell], f'{phase}/{sample}/{cell}')
                assert result.stdout == golden and result.stderr == b'', cell
                report['observations'].append({'phase': phase, 'sample': sample, 'cell': cell, 'seconds': elapsed})
    for sample in range(31):
        cells = [(name, engine) for name in variants for engine in ['native-host', 'v8']]
        rng.shuffle(cells)
        for name, engine in cells:
            timing = OUT / f'timing-{sample}-{name}-{engine}.json'
            command = [HOST, variants[name]]
            if engine == 'v8':
                command = [node, ROOT / 'scripts/run_wasm.mjs', variants[name]]
            result, elapsed = run([*command, '--timing-json', timing], f'phases/{sample}/{name}/{engine}')
            assert result.stdout == golden and result.stderr == b''
            report['phase_probes'].append({'sample': sample, 'variant': name, 'engine': engine,
                                          'wall_seconds': elapsed, 'timing': json.loads(timing.read_bytes())})
    report['summary'] = {cell: common.summary([r['seconds'] for r in report['observations']
                                             if r['phase'] == 'measure' and r['cell'] == cell]) for cell in commands}
    report['paired_speedups'] = {}
    indexed = {(r['sample'], r['cell']): r['seconds'] for r in report['observations'] if r['phase'] == 'measure'}
    for mode in ['ordinary', 'aot', 'v8']:
        report['paired_speedups'][mode] = common.summary([indexed[i, 'baseline-O2/' + mode] / indexed[i, 'compact-O2/' + mode]
                                                        for i in range(61)])
    assert pins == {str(p): sha(p) for p in paths}
    report['status'] = 'passed'
    report['finished_utc'] = datetime.now(timezone.utc).isoformat()
    (OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'status': report['status'], 'paired_speedups': report['paired_speedups'],
                      'medians_ms': {k: v['median'] * 1000 for k, v in report['summary'].items()}}, indent=2))


if __name__ == '__main__':
    main()
