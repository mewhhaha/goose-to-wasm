from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,random,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'build/functions-hill/screen-pools';OUT.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(ROOT/'bench'));import benchmark as common
old=json.loads((ROOT/'bench/results/2026-11-02/full-hills/examples.json').read_bytes())
cwasm=next(Path(r['artifact'])for r in old['observations']if r['kind']=='build'and r['name']=='functions'and r['backend']=='c-wasm')
modules={'baseline':ROOT/'build/functions-hill/baseline/O2.wasm','compact':ROOT/'build/functions-hill/compact/O2.wasm','c-wasm':cwasm}
host=ROOT/'build/bin/goose-wasmtime';golden=(ROOT/'examples/expected/functions.out').read_bytes();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=[Path(__file__),host,*modules.values(),ROOT/'examples/expected/functions.out'];pins={str(p):sha(p)for p in paths}
report={'status':'running','started_utc':datetime.now(timezone.utc).isoformat(),'input_sha256':pins,'observations':[],'method':'Fresh full-process launch, normal affinity; randomized pool/module cells within each sample. Explicit RAYON_NUM_THREADS or unset for default. Exploratory selection only.'}
cells=[(name,pool)for name in modules for pool in ['default','2','4','8','16']];rng=random.Random(823729)
for phase,count in [('warmup',2),('measure',31)]:
 for sample in range(count):
  jobs=cells[:];rng.shuffle(jobs)
  for name,pool in jobs:
   env=os.environ.copy();env.pop('RAYON_NUM_THREADS',None)
   if pool!='default':env['RAYON_NUM_THREADS']=pool
   d=OUT/'logs'/phase/str(sample)/name/pool;d.mkdir(parents=True,exist_ok=True);argv=[str(host),str(modules[name])]
   start=time.perf_counter_ns();r=subprocess.run(argv,input=b'',capture_output=True,env=env,timeout=120);elapsed=(time.perf_counter_ns()-start)/1e9
   (d/'stdout').write_bytes(r.stdout);(d/'stderr').write_bytes(r.stderr);(d/'command.json').write_text(json.dumps({'argv':argv,'RAYON_NUM_THREADS':env.get('RAYON_NUM_THREADS')}))
   assert r.returncode==0 and r.stdout==golden and r.stderr==b'',(name,pool,r.stderr)
   report['observations'].append({'phase':phase,'sample':sample,'module':name,'pool':pool,'seconds':elapsed})
report['summary']=[];report['paired_speedup']=[]
idx={(r['sample'],r['module'],r['pool']):r['seconds']for r in report['observations']if r['phase']=='measure'}
for name,pool in cells:
 report['summary'].append({'module':name,'pool':pool,'seconds':common.summary([idx[i,name,pool]for i in range(31)])})
 report['paired_speedup'].append({'module':name,'pool':pool,'baseline_over_pool':common.summary([idx[i,name,'default']/idx[i,name,pool]for i in range(31)])})
assert pins=={str(p):sha(p)for p in paths};report['status']='passed';report['finished_utc']=datetime.now(timezone.utc).isoformat();(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
for row in report['paired_speedup']:
 s=row['baseline_over_pool'];print(row['module'],row['pool'],round(s['median'],3),round(s['mad'],3))
