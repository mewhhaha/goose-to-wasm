#!/usr/bin/env python3
"""Inventory only this qualification's persisted guests; reuse prior byte objects."""
from pathlib import Path
import argparse
import gzip
import hashlib
import json

HERE=Path(__file__).resolve().parent


def sha(path):
    with Path(path).open('rb') as stream: return hashlib.file_digest(stream,'sha256').hexdigest()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run',type=Path,default=HERE/'attempt-1')
    args=parser.parse_args();run=args.run.resolve()
    assert run.is_relative_to(HERE.resolve())
    assert json.loads((run/'execution.json').read_text())['status']=='passed'
    assert json.loads((run/'host/report.json').read_text())['coverage_exact']
    output=run/'artifact-catalog-all.json';assert not output.exists()
    prior=json.loads((HERE/'prior-evidence.json').read_text())
    index_path=next(Path(name) for name in prior['reports'] if name.endswith('/archives.json.gz'))
    assert sha(index_path)==prior['reports'][str(index_path)]
    with gzip.open(index_path,'rt') as stream: index=json.load(stream)
    known={}
    for location in index['aliases'].values(): known.setdefault(location['sha256'],location)
    objects={};archives={};paths=[]
    for path in sorted(run.rglob('*')):
        if not path.is_file() or path.suffix not in {'.wasm','.bin','.cwasm'}: continue
        paths.append(path);value=sha(path)
        if value in objects:
            objects[value]['fresh_paths'].append(str(path));continue
        row={'sha256':value,'bytes':path.stat().st_size,'fresh_paths':[str(path)]}
        if value in known:
            location=known[value];record=index['archives'][location['archive']]
            archive=(index_path.parent/location['archive']).resolve()
            assert record['members'][location['member']]=={'sha256':value,'bytes':path.stat().st_size}
            if str(archive) not in archives:
                actual=sha(archive);assert actual==record['sha256'];archives[str(archive)]=actual
            row.update(retention='reuse-published-byte-object',location=location,archive=str(archive),archive_sha256=record['sha256'])
        else: row['retention']='new-byte-object'
        objects[value]=row
    result={'status':'passed','scope':'All persisted qualification guests, including focused examples, differential shards and fresh host AOT. No other tree scanned or copied.',
        'script_sha256':sha(Path(__file__)),'prior_index':str(index_path),'prior_index_sha256':sha(index_path),'verified_existing_archive_sha256':archives,
        'fresh_paths':len(paths),'unique_objects':len(objects),'new_objects':sum(row['retention']=='new-byte-object' for row in objects.values()),'objects':objects}
    output.write_text(json.dumps(result,indent=2)+'\n')
    print(result['fresh_paths'],'fresh paths;',result['unique_objects'],'unique objects;',result['new_objects'],'new byte objects')


if __name__=='__main__': main()
