#!/usr/bin/env python3
"""Derive and render the final public campaign charts without sampling."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'bench/results/2026-11-03/runtime-stencil'
RESULTS = ROOT / 'bench/results'
PYTHON = Path('/tmp/goose-readme-charts-venv/bin/python')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def pointer(name, schema, report):
    save(RESULTS / name, {'schema': schema, 'report': str(report.relative_to(RESULTS)),
                         'sha256': digest(report)})


def run(*command):
    subprocess.run([str(PYTHON), *map(str, command)], cwd=ROOT, check=True)


def main():
    cohort = json.loads((OUT / 'cohort.json').read_bytes())
    assert cohort['status'] == 'passed' and not cohort['failures']
    assert len(cohort['observations']) == 315
    readme = {
        'schema': 'goose-readme-benchmarks-v1', 'status': 'passed',
        'chart': {'date': '2026-11-03', 'host': 'AMD Ryzen 7 3800X', 'samples': 5,
                  'compilation_note': 'All backends measured in the same cohort.',
                  'runtime_note': 'Preparation, warmups and startup excluded. Native reference repeated in both panels.'},
        'method': 'One fresh same-host cohort measures all three backends with the same current compiler and adapted sources. Backends are not interleaved pairs. Direct Wasm is memory32; C-to-Wasm is memory64. Native reference is repeated in both engine panels.',
        'sources': {name: digest(OUT / name) for name in ['cohort.json', 'compiler-identity.json']},
        'compile_summary': cohort['compile_summary'], 'runtime_summary': cohort['runtime_summary'],
    }
    save(OUT / 'readme.json', readme)
    pointer('latest.json', 'goose-readme-latest-v1', OUT / 'readme.json')
    pointer('examples-latest.json', 'goose-example-benchmarks-latest-v1', OUT / 'examples.json')
    pointer('wasmtime-host-latest.json', 'goose-wasmtime-host-latest-v1', OUT / 'host.json')
    run('bench/charts.py')
    run('bench/example_charts.py', OUT / 'examples.json')
    os.replace(ROOT / 'bench/charts/examples-runtime.svg', ROOT / 'bench/charts/examples-python-runtime.svg')
    run('bench/wasmtime_host_charts.py', OUT / 'host.json', '--output-dir', ROOT / 'bench/charts')
    run('bench/example_runtime_charts.py', OUT / 'host.json')
    run('bench/runtime_reference_charts.py', OUT / 'references.json', '--climb-report', OUT / 'final-warmed.json',
        '--compiler', 'final', '--verification', OUT / 'target-chart-verification.json')
    save(RESULTS / 'runtime-targets-latest.json', {
        'schema': 'goose-runtime-reference-latest-v1',
        'report': str((OUT / 'references.json').relative_to(RESULTS)), 'sha256': digest(OUT / 'references.json'),
        'comparison': {'report': str((OUT / 'final-warmed.json').relative_to(RESULTS)),
                       'sha256': digest(OUT / 'final-warmed.json'), 'compiler': 'final'},
        'chart_verification': {'report': str((OUT / 'target-chart-verification.json').relative_to(RESULTS)),
                               'sha256': digest(OUT / 'target-chart-verification.json')},
    })
    run('bench/runtime_lifecycle_charts.py', OUT / 'lifecycle.json')
    pointer('runtime-lifecycle-latest.json', 'goose-runtime-lifecycle-latest-v1', OUT / 'lifecycle.json')
    run('build/next-levers/check_charts.py')


if __name__ == '__main__':
    main()
