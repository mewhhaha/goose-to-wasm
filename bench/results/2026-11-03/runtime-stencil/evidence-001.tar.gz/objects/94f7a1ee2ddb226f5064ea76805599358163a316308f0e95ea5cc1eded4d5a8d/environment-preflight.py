#!/usr/bin/env python3
"""Audit the already-sourced qualification environment; run only after approval."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parent


def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=HERE/'environment-preflight.json');args=parser.parse_args()
    if args.output.exists():raise RuntimeError('preserve existing preflight and choose a new output')
    record={'status':'preparing','python':sys.version,'python_path':sys.executable,
            'environment_script':str(ROOT/'build/performance-env.sh'),
            'environment_script_sha256':sha(ROOT/'build/performance-env.sh'),
            'environment':{key:os.environ.get(key) for key in ('PATH','EM_NODE_JS','EM_CACHE','TMPDIR','EMCC_CORES')},'tools':{}}
    for name in ('node','emcc','gcc','clang','c++'):
        path=shutil.which(name)
        if path is None:raise RuntimeError('source build/performance-env.sh; missing '+name)
        path=Path(path).resolve();result=subprocess.run([str(path),'--version'],capture_output=True,text=True,timeout=30)
        if result.returncode:raise RuntimeError(result.stdout+result.stderr)
        record['tools'][name]={'path':str(path),'sha256':sha(path),'version':result.stdout.strip()}
    expected=json.loads((ROOT/'toolchain.json').read_bytes())
    if record['tools']['node']['version'].removeprefix('v')!=expected['node']:raise RuntimeError('Node version differs')
    if record['tools']['emcc']['path']!=str((ROOT/'build/emsdk/upstream/emscripten/emcc').resolve()):
        raise RuntimeError('Emscripten is not the pinned local SDK')
    if os.environ.get('EM_CACHE')!=str(ROOT/'build/em-cache'):raise RuntimeError('EM_CACHE differs')
    if Path(sys.executable).parent!=ROOT/'.venv/bin':raise RuntimeError('use the repository virtualenv Python')
    record['status']='passed';args.output.write_text(json.dumps(record,indent=2)+'\n')
    print('ENVIRONMENT PASS; versions and exact tool/script identities retained')


if __name__=='__main__':main()
