"""Derive publication numbers from completed immutable cohorts."""
from pathlib import Path
import hashlib
import json
import math
import statistics

ROOT=Path(__file__).resolve().parents[2]
BUILD=ROOT/'build/next-levers'


def read(relative):
    return json.loads((BUILD/relative).read_bytes())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def summary(values):
    center=statistics.median(values)
    return {'n':len(values),'median':center,'mad':statistics.median(abs(v-center) for v in values),'samples':values}


def micro(relative):
    report=read(relative); assert report['status']=='passed'
    result={}
    for engine,entry in report['engine_runs'].items():
        rows=entry['result']['observations']
        by_key={(r['round'],r['compiler']):r['ns_per_call'] for r in rows}
        rounds=sorted({r['round'] for r in rows})
        values={}
        for compiler in ['baseline','final']:
            values[compiler]=summary([by_key[i,compiler]/1e6 for i in rounds])
        result[engine]={'milliseconds_per_start':values,
            'paired_speedup':summary([by_key[i,'baseline']/by_key[i,'final'] for i in rounds]),
            'modules':entry['result']['modules']}
    return result


def main():
    reports={name:read(path) for name,path in {
        'warmed':'delivered-warmed/report.json','v8':'delivered-v8/report.json',
        'examples':'current/examples/report.json','host':'current/host/report.json',
        'langarena':'current/langarena/report.json',
        'differential':'qualification/attempt-2/differential/report.json',
        'focused':'qualification/attempt-2/focused/report.json',
        'replay':'qualification/attempt-2/host/report.json','worker':'qualification/attempt-2/worker-replay/report.json','lifecycle':'current/lifecycle/report.json'}.items()}
    assert all(not r.get('failures') for r in reports.values())
    assert all(r['status']==('pass'if name=='replay'else'passed')for name,r in reports.items()if name!='differential')
    delivery=read('delivery-execution/report.json')
    assert reports['differential']['cases']==978 and reports['differential']['observations']==9573 and reports['differential']['qualification_execution']['native_stdout_comparisons']==7656
    for rel in ['focused','differential','host','worker-replay']:
        path=(BUILD/'qualification/attempt-2'/rel/'report.json').resolve()
        assert delivery['input_sha256'][str(path)]==sha(path)
    assert delivery['status']=='passed' and delivery['input_sha256']==delivery['input_sha256_after']
    assert len(delivery['phases'])==6 and all(p['status']=='passed'and p['exit_status']==0 and sha(Path(p['report']))==p['report_sha256']for p in delivery['phases'])
    assert {Path(p['report']).resolve()for p in delivery['phases']}=={(BUILD/p).resolve()for p in ['delivered-warmed/report.json','delivered-v8/report.json','current/examples/report.json','current/host/report.json','current/langarena/report.json','current/lifecycle/report.json']}
    ex=reports['examples']; host=reports['host']; arena=reports['langarena']
    final=read('final/toolchain.json')
    out={'schema':'goose-runtime-stencil-numbers-v1','compiler_sha256':final['compiler_sha256'],
        'baseline_compiler_sha256':'a8c5ba4b4838eea0ae747d495394e6fe77dbdc34e476e8d0cadcb7f225c78352',
        'module_analysis':read('module-analysis.json'),
        'qualification':{'focused_commands':len(reports['focused']['commands']),
            'cases':reports['differential']['cases'],'differential_executions':reports['differential']['observations'],
            'native_stdout_comparisons':reports['differential']['qualification_execution']['native_stdout_comparisons'],
            'host_observations':reports['replay']['observations'],'unique_host_modules':reports['replay']['unique_wasm'],'worker_observations':reports['worker']['observations'],'worker_aliases':reports['worker']['underlying_aliases']},
        'warmed':{},'examples':{},'langarena':{'compile_ranges_ms':{}},
        'lifecycle':reports['lifecycle']['examples']}
    for engine in ['warmed','v8']:
        report=reports[engine]
        out['warmed'][engine]={'geometric_ratios':report['geometric_ratios'],
            'tasks':[{'task':row['task'],'times':row['times'],'paired_ratios':row['paired_ratios']} for row in report['summary']]}
    for case in ex['examples']:
        name=case
        if isinstance(case,dict): name=case['name']
        out['examples'][name]={
            'compile':[r for r in ex['compile_summary'] if r['name']==name],
            'python_v8_native':[r for r in ex['runtime_summary'] if r['name']==name],
            'native_host':[r for r in host['runtime_summary'] if r['name']==name],
            'preparation':[r for r in host['preparation_summary'] if r['name']==name]}
    for backend in ['direct','c-wasm','native']:
        values=[r['wall_seconds']['median']*1000 for r in arena['compile_summary'] if r['backend']==backend and r['phase']=='cold']
        out['langarena']['compile_ranges_ms'][backend]={'min':min(values),'max':max(values)}
    out['langarena']['compile_summary']=arena['compile_summary'];out['langarena']['runtime_summary']=arena['runtime_summary']
    (BUILD/'final-numbers.json').write_text(json.dumps(out,indent=2)+'\n')
    campaign={'schema':'goose-runtime-stencil-campaign-v1','status':'passed',
        'compiler_sha256':final['compiler_sha256'],'baseline_compiler_sha256':out['baseline_compiler_sha256'],
        'scope':'Automatic Wasmtime compilation cache and bounded resident module reuse with fresh guest instances; guarded generic byte-stencil SIMD; transfer caller-private aggregate snapshots into selected callees.',
        'qualification':out['qualification'],
        'accepted_boundaries':'Fresh warmed paired compiler and frozen selected reference runs, all full-process current backends, and separate lifecycle boundaries. Worker IPC roundtrip excludes process startup; cold controls force --no-cache. Reference choices are frozen, not optimized anew.',
        'development_contexts':[
            {'stage':'stencil-initial','reason':'Pre-engine static review required stronger overflow/dead-expression/type proof; this draft is not a qualified or measured Life claim.'},
            {'stage':'stencil-reviewed','reason':'Safe but overly strict contextual load types blocked vectorization of unchanged Life; widened only the checked u8 zero-extension context.'},
            {'stage':'host-explicit-cache','reason':'Initial opt-in prototype; final host enables SDK cache by default. Prototype lifecycle screens remain separate.'},
            {'stage':'qualification/attempt-1','reason':'Coordinator stopped before acceptance after source-level review fixes.'},
            {'stage':'qualification/attempt-2/worker-preflight-expected-2871','reason':'Stale expected-count preflight; actual exact corpus requires3001 distinct module/input executions, all replayed.'}],
        'fallbacks':'Stencil debug/unsupported effects/types/aliasing/bounds preserve scalar execution. Private-snapshot ineligible params retain entry copies. Cache failures fall back uncached unless an explicit invalid config was requested.',
        'numbers_sha256':sha(BUILD/'final-numbers.json'),
        'evidence':{str(path.relative_to(BUILD)):sha(path) for path in [
            BUILD/'module-analysis.json',BUILD/'static-review.json',BUILD/'test-static-review.json',
            BUILD/'delivery-execution/report.json',BUILD/'abi-private-snapshots.md',
            BUILD/'life-wasmtime-screen/report.json',BUILD/'life-v8-screen/report.json',
            BUILD/'runtime-screen/report.json',BUILD/'runtime-host-control/report.json']}}
    (BUILD/'campaign.json').write_text(json.dumps(campaign,indent=2)+'\n')
    print(json.dumps({'qualification':out['qualification'],'compile_ranges_ms':out['langarena']['compile_ranges_ms'],
        'warmed':out['warmed']},indent=2))


if __name__=='__main__':main()
