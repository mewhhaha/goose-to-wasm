# Example program benchmarks

Status: **passed-smoke**.

2026-11-03 · AMD Ryzen 7 3800X 8-Core Processor.

Goose O2. Direct Wasm uses memory32; C-Wasm uses memory64. The selected programs, their constant inputs and all printing are unchanged from the [example catalog](../../../../examples/README.md). Compiler constant folding is allowed.

Builds are complete uncached Python-driver invocations, including any C compilation/linking. OS page caches and Emscripten's installed system-library cache remain warm.

Runtime is **whole-process launch-to-exit time**, including host startup, Wasm compilation/instantiation, program initialization, computation, output delivery and teardown. Each observation starts a fresh process/instance and calls the entrypoint once. This measures CLI cost, not warmed kernel throughput.

Each cell has 1 build samples or 1 runtime samples. Untimed fresh-process warmups per runtime cell: 0. Orders are shuffled with the recorded seed; builds and runtime never overlap. Every used artifact must pass its golden output. Values are median milliseconds ± median absolute deviation (MAD).

Headline runtime samples use the ordinary runners without timing-file instrumentation. The Wasm supplements use a separate shuffled set of fresh processes, with the same sample count; timing files are written after their engine intervals end.

## Compilation

| Example | Direct | C-Wasm | Native C |
| --- | ---: | ---: | ---: |
| squares | 65.762 ±0.000 | 593.347 ±0.000 | 259.983 ±0.000 |
| functions | 103.020 ±0.000 | 1038.367 ±0.000 | 568.440 ±0.000 |

## Whole-process runtime

| Example | Direct / V8 | C-Wasm / V8 | Direct / Wasmtime | C-Wasm / Wasmtime | Native C |
| --- | ---: | ---: | ---: | ---: | ---: |
| squares | 28.456 ±0.000 | 27.177 ±0.000 | 94.357 ±0.000 | 107.529 ±0.000 | 0.785 ±0.000 |
| functions | 36.476 ±0.000 | 34.328 ±0.000 | 99.363 ±0.000 | 140.140 ±0.000 | 1.314 ±0.000 |

## Supplement: Wasm entrypoint

| Example | Direct / V8 | C-Wasm / V8 | Direct / Wasmtime | C-Wasm / Wasmtime |
| --- | ---: | ---: | ---: | ---: |
| squares | 0.311 ±0.000 | 1.315 ±0.000 | 0.131 ±0.000 | 0.928 ±0.000 |
| functions | 6.245 ±0.000 | 2.808 ±0.000 | 1.685 ±0.000 | 1.963 ±0.000 |

## Supplement: Wasm engine compilation and instantiation

| Example | Direct / V8 | C-Wasm / V8 | Direct / Wasmtime | C-Wasm / Wasmtime |
| --- | ---: | ---: | ---: | ---: |
| squares | 0.348 ±0.000 | 0.627 ±0.000 | 3.609 ±0.000 | 12.590 ±0.000 |
| functions | 0.447 ±0.000 | 0.640 ±0.000 | 30.147 ±0.000 | 27.999 ±0.000 |

The entrypoint interval includes Goose initialization, host output callbacks and any lazy JIT work. It excludes final Wasm-host output concatenation/delivery. Native Goose prints unbuffered, so no native entrypoint column or cross-boundary speedup is presented. Process time minus engine time also includes loading, bookkeeping and teardown; it is not a pure startup measurement.

These fresh-process examples have different timing rules from LangArena's warmed computational regions. Raw samples, commands, artifact/source/compiler identities and engine versions are in [report.json](report.json). [Method and reproduction](../../../examples.md).
