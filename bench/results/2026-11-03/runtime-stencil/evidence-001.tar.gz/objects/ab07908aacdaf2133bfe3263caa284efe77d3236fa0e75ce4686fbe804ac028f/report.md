# LangArena qualification and measurements

Status: **passed**.

Upstream pin: `aab9b14998231ba905523b5ba3990ee03c46f64d`. Catalog: **50 tasks**. Adapted entrypoints: **7 tasks**, including six storage adaptations.

Mode: `measure`. Machine: AMD Ryzen 7 3800X, shared desktop host.
Compiler SHA-256: `1b1ec504894d387ae0bbed287d2d3214e250e6dc9bbff2ffd2893a69c06a8874`.

## Measurement contract

Whole-suite results use all original Goose kernel sources. The only staging patch changes the marker destination from `/tmp/recompile_marker` to a relative file inside the isolated run directory. The original checkout is hash-verified and never edited. Whole-suite compile times include all 50 tasks.

The adapted track uses the same seven port sources across native C, direct Wasm, and C-Wasm. Six ports replace growable storage; Fannkuch keeps its original fixed-array kernel. Official test/run inputs and checksums are unchanged. Preparation stays outside the clock; warmups mutate the same state used for measurement; the deterministic RNG is reset before measured iterations. Existing checksum work retains its original placement.

Cold builds and marker-edit builds launch fresh driver/compiler processes with `--no-cache`. OS caches and installed compiler/system-library caches are retained. A port marker edit changes its exit status from 0 to 1 after its two output lines, and the edited executable must retain the official checksum. Whole-suite edits change the actual marker file contents. Source bytes are restored in all cases. Optional unchanged cache hits are a separate phase. Edited sources still rerun the complete frontend.

The official whole-suite timer prints milliseconds; adapted ports print integer nanoseconds. Timed regions exclude process startup and preparation. Process wall time is retained separately. Sample counts below five are preliminary estimates; raw values and MAD are provided. These are local comparisons, not LangArena leaderboard scores or claims of complete direct-backend language support.

## Whole-suite compilation

| Backend | Phase | Samples | Median ms | MAD ms | Artifact bytes |
| --- | --- | ---: | ---: | ---: | ---: |

## Original-source correctness and runtime

| Task | Backend / engine | Profile | Samples | Region median ms | MAD ms | Process median ms |
| --- | --- | --- | ---: | ---: | ---: | ---: |

## Adapted workload compilation

| Task | Backend | Phase | Samples | Median ms | MAD ms | Artifact bytes |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| CLBG::Fannkuchredux | c-wasm | cold | 5 | 648.766 | 8.155 | 51975 |
| CLBG::Fannkuchredux | direct | cold | 5 | 72.040 | 0.781 | 3917 |
| CLBG::Fannkuchredux | native | cold | 5 | 322.575 | 22.955 | 22984 |
| CLBG::Mandelbrot | c-wasm | cold | 5 | 635.386 | 8.913 | 52056 |
| CLBG::Mandelbrot | direct | cold | 5 | 91.372 | 13.545 | 4467 |
| CLBG::Mandelbrot | native | cold | 5 | 290.709 | 7.540 | 23160 |
| Etc::Sieve | c-wasm | cold | 5 | 642.255 | 9.614 | 51597 |
| Etc::Sieve | direct | cold | 5 | 67.326 | 0.803 | 3098 |
| Etc::Sieve | native | cold | 5 | 287.079 | 23.800 | 23128 |
| Hash::CRC32 | c-wasm | cold | 5 | 644.573 | 6.751 | 51814 |
| Hash::CRC32 | direct | cold | 5 | 69.351 | 1.000 | 3132 |
| Hash::CRC32 | native | cold | 5 | 273.570 | 5.745 | 23008 |
| Hash::SHA256 | c-wasm | cold | 5 | 648.692 | 22.972 | 51823 |
| Hash::SHA256 | direct | cold | 5 | 68.422 | 2.232 | 6611 |
| Hash::SHA256 | native | cold | 5 | 301.924 | 11.127 | 23008 |
| Sort::Merge | c-wasm | cold | 5 | 688.284 | 2.081 | 52481 |
| Sort::Merge | direct | cold | 5 | 66.860 | 1.571 | 5214 |
| Sort::Merge | native | cold | 5 | 319.768 | 12.206 | 27416 |
| Sort::Quick | c-wasm | cold | 5 | 625.115 | 12.708 | 52040 |
| Sort::Quick | direct | cold | 5 | 91.284 | 5.161 | 4356 |
| Sort::Quick | native | cold | 5 | 275.986 | 11.122 | 23168 |

## Adapted workload runtime

| Task | Backend / engine | Profile | Samples | Region median ms | MAD ms | Engine compile + instantiate ms | Process median ms | Checksum |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| CLBG::Fannkuchredux | c-wasm / v8 | run | 5 | 2099.301 | 8.208 | 0.601 | 2550.119 | 135762480 |
| CLBG::Fannkuchredux | c-wasm / v8 | test | 1 | 0.038 | 0.000 | 0.541 | 29.615 | 4428 |
| CLBG::Fannkuchredux | c-wasm / wasmtime | run | 5 | 1465.831 | 10.564 | 25.316 | 1875.418 | 135762480 |
| CLBG::Fannkuchredux | c-wasm / wasmtime | test | 1 | 0.061 | 0.000 | 23.547 | 130.236 | 4428 |
| CLBG::Fannkuchredux | direct / v8 | run | 5 | 1268.475 | 6.756 | 0.254 | 1547.609 | 135762480 |
| CLBG::Fannkuchredux | direct / v8 | test | 1 | 0.042 | 0.000 | 0.290 | 35.800 | 4428 |
| CLBG::Fannkuchredux | direct / wasmtime | run | 5 | 1374.696 | 3.992 | 4.297 | 1735.340 | 135762480 |
| CLBG::Fannkuchredux | direct / wasmtime | test | 1 | 0.028 | 0.000 | 3.888 | 80.986 | 4428 |
| CLBG::Fannkuchredux | native / native | run | 5 | 1310.647 | 7.695 | — | 1571.424 | 135762480 |
| CLBG::Fannkuchredux | native / native | test | 1 | 0.021 | 0.000 | — | 1.190 | 4428 |
| CLBG::Mandelbrot | c-wasm / v8 | run | 5 | 953.239 | 3.199 | 0.560 | 1188.637 | 3455988829 |
| CLBG::Mandelbrot | c-wasm / v8 | test | 1 | 0.333 | 0.000 | 0.569 | 44.574 | 2236342953 |
| CLBG::Mandelbrot | c-wasm / wasmtime | run | 5 | 1058.130 | 7.672 | 23.603 | 1377.762 | 3455988829 |
| CLBG::Mandelbrot | c-wasm / wasmtime | test | 1 | 0.218 | 0.000 | 39.184 | 138.803 | 2236342953 |
| CLBG::Mandelbrot | direct / v8 | run | 5 | 965.255 | 5.019 | 0.233 | 1200.396 | 3455988829 |
| CLBG::Mandelbrot | direct / v8 | test | 1 | 0.360 | 0.000 | 0.192 | 28.590 | 2236342953 |
| CLBG::Mandelbrot | direct / wasmtime | run | 5 | 1001.122 | 3.645 | 4.046 | 1286.593 | 3455988829 |
| CLBG::Mandelbrot | direct / wasmtime | test | 1 | 0.190 | 0.000 | 4.142 | 84.899 | 2236342953 |
| CLBG::Mandelbrot | native / native | run | 5 | 930.363 | 0.726 | — | 1124.378 | 3455988829 |
| CLBG::Mandelbrot | native / native | test | 1 | 0.161 | 0.000 | — | 2.662 | 2236342953 |
| Etc::Sieve | c-wasm / v8 | run | 5 | 5931.197 | 219.030 | 0.596 | 7084.994 | 1042248060 |
| Etc::Sieve | c-wasm / v8 | test | 1 | 0.028 | 0.000 | 0.741 | 34.888 | 4660 |
| Etc::Sieve | c-wasm / wasmtime | run | 5 | 5328.035 | 27.489 | 24.558 | 6499.728 | 1042248060 |
| Etc::Sieve | c-wasm / wasmtime | test | 1 | 0.048 | 0.000 | 23.537 | 109.308 | 4660 |
| Etc::Sieve | direct / v8 | run | 5 | 1340.798 | 5.741 | 0.217 | 1663.010 | 1042248060 |
| Etc::Sieve | direct / v8 | test | 1 | 0.015 | 0.000 | 0.235 | 24.120 | 4660 |
| Etc::Sieve | direct / wasmtime | run | 5 | 1355.711 | 9.997 | 3.781 | 1736.657 | 1042248060 |
| Etc::Sieve | direct / wasmtime | test | 1 | 0.021 | 0.000 | 3.221 | 81.904 | 4660 |
| Etc::Sieve | native / native | run | 5 | 859.106 | 7.084 | — | 1049.092 | 1042248060 |
| Etc::Sieve | native / native | test | 1 | 0.003 | 0.000 | — | 2.927 | 4660 |
| Hash::CRC32 | c-wasm / v8 | run | 5 | 451.609 | 0.239 | 0.586 | 578.905 | 2318723244 |
| Hash::CRC32 | c-wasm / v8 | test | 1 | 0.014 | 0.000 | 0.466 | 25.829 | 3031698216 |
| Hash::CRC32 | c-wasm / wasmtime | run | 5 | 412.309 | 4.481 | 25.205 | 609.599 | 2318723244 |
| Hash::CRC32 | c-wasm / wasmtime | test | 1 | 0.050 | 0.000 | 22.997 | 133.971 | 3031698216 |
| Hash::CRC32 | direct / v8 | run | 5 | 501.655 | 1.316 | 0.228 | 646.043 | 2318723244 |
| Hash::CRC32 | direct / v8 | test | 1 | 0.017 | 0.000 | 0.211 | 25.922 | 3031698216 |
| Hash::CRC32 | direct / wasmtime | run | 5 | 431.868 | 2.989 | 3.775 | 609.335 | 2318723244 |
| Hash::CRC32 | direct / wasmtime | test | 1 | 0.025 | 0.000 | 4.581 | 84.561 | 3031698216 |
| Hash::CRC32 | native / native | run | 5 | 1354.687 | 0.873 | — | 1632.015 | 2318723244 |
| Hash::CRC32 | native / native | test | 1 | 0.027 | 0.000 | — | 2.024 | 3031698216 |
| Hash::SHA256 | c-wasm / v8 | run | 5 | 1035.860 | 9.415 | 0.534 | 1291.095 | 2844672256 |
| Hash::SHA256 | c-wasm / v8 | test | 1 | 0.007 | 0.000 | 0.543 | 28.180 | 1036619072 |
| Hash::SHA256 | c-wasm / wasmtime | run | 5 | 947.877 | 0.903 | 24.899 | 1271.962 | 2844672256 |
| Hash::SHA256 | c-wasm / wasmtime | test | 1 | 0.046 | 0.000 | 24.452 | 109.267 | 1036619072 |
| Hash::SHA256 | direct / v8 | run | 5 | 259.267 | 1.968 | 0.258 | 352.068 | 2844672256 |
| Hash::SHA256 | direct / v8 | test | 1 | 0.003 | 0.000 | 0.249 | 25.383 | 1036619072 |
| Hash::SHA256 | direct / wasmtime | run | 5 | 325.342 | 1.624 | 5.101 | 481.952 | 2844672256 |
| Hash::SHA256 | direct / wasmtime | test | 1 | 0.017 | 0.000 | 5.477 | 107.835 | 1036619072 |
| Hash::SHA256 | native / native | run | 5 | 580.752 | 2.707 | — | 702.064 | 2844672256 |
| Hash::SHA256 | native / native | test | 1 | 0.003 | 0.000 | — | 2.570 | 1036619072 |
| Sort::Merge | c-wasm / v8 | run | 5 | 1314.624 | 8.109 | 0.564 | 1612.108 | 61757772 |
| Sort::Merge | c-wasm / v8 | test | 1 | 12.025 | 0.000 | 0.545 | 46.991 | 2548773 |
| Sort::Merge | c-wasm / wasmtime | run | 5 | 2683.572 | 35.113 | 29.971 | 3338.639 | 61757772 |
| Sort::Merge | c-wasm / wasmtime | test | 1 | 24.284 | 0.000 | 25.690 | 145.754 | 2548773 |
| Sort::Merge | direct / v8 | run | 5 | 1870.866 | 10.160 | 0.267 | 2273.557 | 61757772 |
| Sort::Merge | direct / v8 | test | 1 | 17.164 | 0.000 | 0.260 | 55.635 | 2548773 |
| Sort::Merge | direct / wasmtime | run | 5 | 1944.191 | 50.979 | 4.298 | 2399.704 | 61757772 |
| Sort::Merge | direct / wasmtime | test | 1 | 17.518 | 0.000 | 4.135 | 137.928 | 2548773 |
| Sort::Merge | native / native | run | 5 | 1394.829 | 5.544 | — | 1681.773 | 61757772 |
| Sort::Merge | native / native | test | 1 | 17.932 | 0.000 | — | 28.015 | 2548773 |
| Sort::Quick | c-wasm / v8 | run | 5 | 1405.943 | 8.886 | 0.559 | 1724.988 | 61757772 |
| Sort::Quick | c-wasm / v8 | test | 1 | 20.250 | 0.000 | 0.772 | 80.131 | 2548773 |
| Sort::Quick | c-wasm / wasmtime | run | 5 | 1631.748 | 3.479 | 24.731 | 2080.668 | 61757772 |
| Sort::Quick | c-wasm / wasmtime | test | 1 | 15.744 | 0.000 | 34.966 | 159.010 | 2548773 |
| Sort::Quick | direct / v8 | run | 5 | 1340.783 | 7.829 | 0.239 | 1641.905 | 61757772 |
| Sort::Quick | direct / v8 | test | 1 | 13.209 | 0.000 | 0.239 | 47.816 | 2548773 |
| Sort::Quick | direct / wasmtime | run | 5 | 1721.603 | 41.951 | 3.616 | 2120.489 | 61757772 |
| Sort::Quick | direct / wasmtime | test | 1 | 15.131 | 0.000 | 4.676 | 107.912 | 2548773 |
| Sort::Quick | native / native | run | 5 | 1197.556 | 4.789 | — | 1443.207 | 61757772 |
| Sort::Quick | native / native | test | 1 | 12.153 | 0.000 | — | 20.987 | 2548773 |

## Qualification and limits

- Seven adapted entrypoints (six change storage, one changes only the harness) are a subset of the 50-task catalog; they do not establish unmodified whole-suite Wasm support.
- No local result is a LangArena leaderboard rank: source/compiler versions, target layout, host, flags, and coverage differ.
- Cold builds retain OS and compiler system-library caches; they are complete uncached driver builds, not disk-cold experiments.

The full 50-task coverage matrix, raw commands/output, source and artifact hashes, tool versions, input values, environment overrides (including `EM_NODE_JS`), and phase timings are in `report.json` and adjacent logs. `Hash::SHA256` retains LangArena's custom hash workload; it is not standard cryptographic SHA-256.
