from pathlib import Path
import hashlib,json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[3];out=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts.wasmtime_session import RuntimeSession
os.environ['XDG_CACHE_HOME']=str(out/'default-cache')
expected=(ROOT/'examples/expected/squares.out').read_bytes()
rows=[]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(command,output=expected):
 start=time.monotonic();result=subprocess.run(list(map(str,command)),cwd=ROOT,capture_output=True)
 row={'command':list(map(str,command)),'returncode':result.returncode,'stdout':result.stdout.decode(),'stderr':result.stderr.decode(),'wall_seconds':time.monotonic()-start}
 rows.append(row);assert result.returncode==0 and result.stdout==output and not result.stderr,row
host=ROOT/'build/bin/goose-wasmtime';wasm=ROOT/'build/squares.wasm';aot=ROOT/'build/squares.cwasm'
run([ROOT/'build/bin/goose',ROOT/'examples/squares.goose','--target','wasm-direct','-O2','-o',wasm,'--wasm-stats',ROOT/'build/squares.stats.json'],b'')
run(['node',ROOT/'scripts/run_wasm.mjs',wasm])
run([sys.executable,ROOT/'scripts/run_wasmtime.py',wasm])
run([host,wasm]);run([host,wasm]);run([host,'--no-cache',wasm])
run([host,'--compile',wasm,aot],b'');run([host,'--precompiled',aot])
config=out/'cache.toml';config.write_text('[cache]\ndirectory = "'+str(out/'explicit-cache')+'"\n')
run([host,'--cache-config',config,wasm])
for options in [{},{'cache':True},{'cache_config':str(config)}]:
 with RuntimeSession(**options)as session:
  for i in range(2):
   result=session.run('build/squares.wasm',stdin=b'')
   assert result.returncode==0 and result.stdout==expected and not result.stderr and result.module_cache_hit==(i==1)
   rows.append({'session_options':options,'request':i,'stdout':result.stdout.decode(),'returncode':result.returncode,'module_cache_hit':result.module_cache_hit})
report={'status':'passed','method':'Post-timing smoke validation of changed GUIDE CLI/cache/session instructions using installed qualified compiler/host. Existing setup/install instructions were not rerun.','checks':rows,'guide_sha256':sha(ROOT/'docs/GUIDE.md'),'compiler_sha256':sha(ROOT/'build/bin/goose'),'host_sha256':sha(host),'module_sha256':sha(wasm),'artifact_sha256':sha(aot)}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print('PASS',len(rows),'GUIDE command/request checks')
