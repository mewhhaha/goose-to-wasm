"""Analyze already measured modules; execute after all timing windows close."""
from pathlib import Path
import hashlib,json,subprocess,sys
ROOT=Path(__file__).resolve().parents[2];BUILD=ROOT/'build/next-levers'
sys.path.insert(0,str(ROOT/'tests'))
from test_function_value_forwarding import function_bodies,memory_copy_count
from test_private_snapshot_parameters import frame_bytes

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_bytes())
def main():
 old=load(ROOT/'build/functions-init/shapes/report.json')
 examples=load(BUILD/'current/examples/report.json')
 directory=BUILD/'module-analysis';directory.mkdir(exist_ok=True)
 out={'schema':'goose-runtime-stencil-module-analysis-v1','status':'passed','compilers':{'baseline':old['compilers']['candidate'],'final':load(BUILD/'final/toolchain.json')['compiler_sha256']},'method':'Existing unchanged-source O2 example modules. Baseline is prior delivered a8c compiler; final artifacts are this campaign actual measured direct modules. Static instructions are not dynamic operation counts. No additional compilations.','source_reports':{str(p):sha(p)for p in [ROOT/'build/functions-init/shapes/report.json',BUILD/'current/examples/report.json']},'source_sha256':{str(p):sha(p)for p in sorted((ROOT/'examples').glob('*.goose'))},'examples':[]}
 for case in examples['examples']:
  name=case['name'];before=Path(old['modules'][name]['candidate']['wasm'])
  measured=next(r for r in examples['observations']if r['kind']=='build'and r['name']==name and r['backend']=='direct'and r['sample']==0)
  assert measured['status']=='passed'
  after=Path(measured['artifact'])
  assert sha(after)==measured['artifact_sha256']==measured['driver_stats']['module_sha256']
  assert sha(before)==old['modules'][name]['candidate']['sha256']
  row={'task':name}
  for label,module in [('baseline',before),('final',after)]:
   data=module.read_bytes();dis=subprocess.check_output(['llvm-objdump','-d',str(module)],text=True)
   text=directory/(name+'-'+label+'.disassembly');text.write_text(dis)
   result={'wasm':str(module),'sha256':sha(module),'bytes':len(data),'static_memory_copy':dis.count('memory.copy'),'static_widened_loads':dis.count('i16x8.load8x8_u'),'disassembly':str(text),'disassembly_sha256':sha(text)}
   if name=='functions':
    info=load(ROOT/old['modules'][name]['candidate']['stats'])
    if label=='final':info=measured['driver_stats']['backend_stats']
    number=next(r['index']for r in info['function_info']if r['name']=='by_name#41')
    body=dict(function_bodies(module,info))['by_name#41']
    result['by_name']={'index':number,'body_bytes':len(body),'static_memory_copy':memory_copy_count(body),'frame_bytes':frame_bytes(body)}
   row[label]=result
  row['bytes_delta']=row['final']['bytes']-row['baseline']['bytes'];out['examples'].append(row)
 (BUILD/'module-analysis.json').write_text(json.dumps(out,indent=2)+'\n')
if __name__=='__main__':main()
