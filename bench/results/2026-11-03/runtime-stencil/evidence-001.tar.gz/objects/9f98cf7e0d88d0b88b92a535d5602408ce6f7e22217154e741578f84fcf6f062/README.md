# Next-levers qualification preparation

Prepared source only. Every execution needs the coordinator's CPU window.
Source `build/performance-env.sh` before every execution shell. Benchmark timing
and this runner never overlap.

The plan has73 focused commands: the previous70 plus private parameter
snapshots, byte stencils and runtime-session isolation. It retains978 cases,
9573 differential observations and7656 native comparisons. The existing
stateless native-host replay retains11484 observations. The separate worker
phase runs2871 effective module/input cases over3828 original aliases in one
Engine, with fresh Store/Instance state and exact raw protocol/payload logs.
Runtime cache/worker benchmark formats use their own root-owned protocols.

Header and patch inventories come from the selected manifests. The accepted
baselines retain their own32headers; the current combined source declares33.
Each component control keeps the selected inventory and changes one predicate
in exactly one header. The private-snapshot regression uses the matched private
control, while older memory/fresh-initialization controls retain their frozen
19d/353 baselines. No previous result tree, archive namespace or SDK is copied.

After final source selection and explicit approval:

```
source build/performance-env.sh
python -B build/next-levers/qualification/environment-preflight.py
python -B build/next-levers/qualification/controls.py prepare --control resource
python -B build/next-levers/qualification/controls.py build --control resource
```

Repeat prepare/build for `named`, `private` and `stencil`. Builds already verify
and record their complete source/toolchain match; do not duplicate `match`.
Then seal with the explicit final compiler hash:

```
python -B build/next-levers/qualification/run.py seal --compiler-sha SELECTED_SHA --resource-reference build/next-levers/qualification/resource-control/build/bin/goose --named-reference build/next-levers/qualification/named-control/build/bin/goose --private-reference build/next-levers/qualification/private-control/build/bin/goose --stencil-reference build/next-levers/qualification/stencil-control/build/bin/goose
python -B build/next-levers/qualification/run.py gates --jobs 4
python -B build/next-levers/qualification/run.py host --jobs 4
python -B build/next-levers/qualification/run.py worker --jobs 4
```

Preserve every failed run and use a new `--output-dir` before retrying.
Do not seal until all selected sources, tests, controls and runtime-host metadata
are stable. The new runtime benchmark adapters remain root-owned.
