#!/usr/bin/env python3
"""Replay the current verified corpus once per effective input in one worker.

Correctness only. Module reuse keeps one Engine; every request constructs a fresh
Store/Instance. Original native/Python observations remain independent references.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import signal
import struct
import sys
import time

ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'bench'))
import qualify_wasmtime_host as qualification
sys.path.insert(0,str(ROOT/'tests'))
from run_differential import cases
sys.path.insert(0,str(ROOT/'scripts'))
from wasmtime_session import RuntimeSession


def load(path):return json.loads(path.read_bytes())


def sha(path):return qualification.digest(path)


def digest(data):return hashlib.sha256(data).hexdigest()


def require(value,message):
    if not value:raise RuntimeError(str(message))


class RecordingSession(RuntimeSession):
    def __init__(self,host):
        self.received=bytearray();super().__init__(host,cache=False)
        self.handshake=bytes(self.received);self.received.clear()

    def _read(self,size):
        data=super()._read(size);self.received.extend(data);return data


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline-dir',type=Path,required=True)
    parser.add_argument('--host-report',type=Path,required=True)
    parser.add_argument('--host',type=Path,default=ROOT/'build/bin/goose-wasmtime')
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--expected',type=int,default=2871)
    parser.add_argument('--timeout',type=int,default=30)
    args=parser.parse_args();out=args.output.resolve();baseline=args.baseline_dir.resolve();host=args.host.resolve()
    require(not out.exists(),'preserve prior worker replay and choose a new output directory')
    out.mkdir(parents=True)
    report={'schema':'goose-fresh-store-worker-replay-v1','status':'running','results':[],
            'configuration':{'processes':1,'disk_compilation_cache':False,'fresh_store_and_instance_per_request':True,
                             'effective_key':['wasm_sha256','stdin_sha256'],'request_timeout_seconds':args.timeout},
            'expected_observations':args.expected,'observations':0,'failures':0,'coverage_exact':False}
    def save():
        report['observations']=len(report['results'])
        report['failures']=sum(row['status']!='pass' for row in report['results'])
        if report.get('error'):report['failures']+=1
        temporary=out/'report.tmp';temporary.write_text(json.dumps(report,indent=2)+'\n');temporary.replace(out/'report.json')
    started=time.monotonic();save()
    try:
        corpus=load(baseline/'report.json');host_report=load(args.host_report.resolve());matrix=cases()
        rows=qualification.verify_baseline(baseline,corpus,matrix)
        require(host_report['status']=='pass' and host_report['failures']==0 and host_report['coverage_exact'] and
                host_report['observations']==11484,'standard host replay must pass unchanged')
        require(host_report['compiler_sha256']==corpus['compiler_sha256'],'worker corpus/compiler differs')
        manifest_path=host.with_suffix('.json');manifest=load(manifest_path)
        require(manifest==host_report['host_build'] and sha(host)==manifest['host_sha256'],'worker host differs')
        pins=dict(corpus['qualification_execution']['input_sha256'])
        for path,expected in host_report['input_sha256'].items():
            require(path not in pins or pins[path]==expected,'conflicting input identity');pins[path]=expected
        for path in (Path(__file__).resolve(),ROOT/'scripts/wasmtime_session.py',baseline/'report.json',
                     args.host_report.resolve(),host,manifest_path):pins[str(path)]=sha(path)
        groups={};modules={};aliases=[]
        for case in matrix:
            for level in qualification.LEVELS:
                if level not in case.levels:continue
                native=rows[(case.name,level,case.debug,'native','native')]
                for backend in qualification.BACKENDS:
                    python=rows[(case.name,level,case.debug,backend,'wasmtime')]
                    module=qualification.artifact_path(baseline,case,level,backend)
                    module_sha=python['sha256'];require(sha(module)==module_sha,'worker guest differs')
                    require(rows[(case.name,level,case.debug,backend,'v8')]['sha256']==module_sha,'reference engines used different guests')
                    pins[str(module)]=module_sha;modules[str(module)]={'module':str(module),'sha256':module_sha,'bytes':module.stat().st_size}
                    data=case.stdin.encode();key=(module_sha,digest(data))
                    group=groups.setdefault(key,{'module':module,'stdin':data,'aliases':[],'native':native,'python':python})
                    require(group['native']['stdout']==native['stdout'] and group['native']['exit_code']==native['exit_code'],
                            'equivalent module/input aliases disagree')
                    alias={'case':case.name,'fixture':case.fixture,'optimization':level,'debug':case.debug,'backend':backend,
                           'module':str(module),'diagnostic':case.diagnostic,'golden':case.stdout}
                    group['aliases'].append(alias);aliases.append((case.name,level,case.debug,backend))
        report.update(derived_effective_cases=len(groups),derived_underlying_aliases=len(aliases))
        require(len(aliases)==len(set(aliases))==11484//3,'underlying worker alias coverage differs')
        require(len(groups)==args.expected,('effective worker coverage differs',len(groups),args.expected))
        qualification.verify_pins(pins)
        report.update(compiler_sha256=corpus['compiler_sha256'],host_build=manifest,
                      underlying_aliases=len(aliases),unique_wasm=len({key[0] for key in groups}),
                      modules=list(modules.values()),input_sha256=pins,
                      reference_method='Current passing native/Python corpus rows; byte-identical module/input aliases execute once.',
                      engine_configuration=host_report['engine_configuration'])
        save()
        def timed_out(signum,frame):raise TimeoutError('worker request exceeded '+str(args.timeout)+' seconds')
        previous=signal.signal(signal.SIGALRM,timed_out)
        seen=set()
        try:
            with RecordingSession(host) as session:
                require(session.handshake==b'GWRT\1\0\0\0','worker handshake differs')
                (out/'handshake.log').write_bytes(session.handshake)
                report['handshake_sha256']=digest(session.handshake)
                report['worker_command']=session._process.args
                for index,(key,group) in enumerate(sorted(groups.items())):
                    module_sha,stdin_sha=key;log=out/'runs'/str(index).zfill(5);log.mkdir(parents=True)
                    path=os.fsencode(group['module'].resolve());data=group['stdin']
                    request=struct.pack('<II',len(path),len(data))+path+data
                    (log/'request.log').write_bytes(request);(log/'stdin').write_bytes(data)
                    session.received.clear();signal.setitimer(signal.ITIMER_REAL,args.timeout)
                    try:result=session.run(group['module'],data)
                    finally:
                        signal.setitimer(signal.ITIMER_REAL,0)
                        (log/'response.log').write_bytes(session.received)
                    (log/'stdout').write_bytes(result.stdout);(log/'stderr').write_bytes(result.stderr)
                    checks={'native_exit':result.returncode==group['native']['exit_code'],
                            'native_stdout':result.stdout==group['native']['stdout'].encode(),
                            'python_exit':result.returncode==group['python']['exit_code'],
                            'python_stdout':result.stdout==group['python']['stdout'].encode(),
                            'cache_hit':result.module_cache_hit==(module_sha in seen)}
                    if not group['python']['stderr']:checks['empty_stderr']=not result.stderr
                    for alias in group['aliases']:
                        if alias['diagnostic']:checks['diagnostic:'+alias['case']]=alias['diagnostic'].lower() in result.stderr.decode(errors='replace').lower()
                        if alias['golden'] is not None:checks['golden:'+alias['case']]=result.stdout==alias['golden'].encode()
                    row={'wasm_sha256':module_sha,'stdin_sha256':stdin_sha,'module':str(group['module']),
                         'aliases':group['aliases'],'logs':str(log),'exit_code':result.returncode,
                         'stdout_sha256':digest(result.stdout),'stderr_sha256':digest(result.stderr),
                         'request_sha256':digest(request),'response_sha256':digest(session.received),
                         'module_cache_hit':result.module_cache_hit,'prepare_ns':result.prepare_ns,'start_ns':result.start_ns,
                         'comparisons':checks,'status':'pass'}
                    if not all(checks.values()):row['status']='fail'
                    (log/'result.json').write_text(json.dumps(row,indent=2)+'\n');report['results'].append(row);seen.add(module_sha)
                    if len(report['results'])%100==0:
                        save();print(len(report['results']),'/',args.expected,'worker observations',flush=True)
                    require(row['status']=='pass',('worker observation differs',index))
        finally:signal.signal(signal.SIGALRM,previous)
        after={path:sha(path) for path in pins};require(after==pins,'worker replay inputs changed')
        report['input_sha256_after']=after
        require(len(report['results'])==args.expected and
                {(row['wasm_sha256'],row['stdin_sha256']) for row in report['results']}==set(groups),'worker exact coverage differs')
        report.update(status='passed',coverage_exact=True)
    except BaseException as error:
        report.update(status='failed',error=type(error).__name__+': '+str(error));raise
    finally:
        report['wall_seconds']=time.monotonic()-started;save()
    print('PASS',report['observations'],'effective worker observations;',report['underlying_aliases'],'aliases',flush=True)


if __name__=='__main__':main()
