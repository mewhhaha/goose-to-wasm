# Example program benchmarks

Status: **passed**.

2026-11-03 · AMD Ryzen 7 3800X, shared desktop host.

Goose O2. Direct Wasm uses memory32; C-Wasm uses memory64. The selected programs, their constant inputs and all printing are unchanged from the [example catalog](../../../../examples/README.md). Compiler constant folding is allowed.

Builds are complete uncached Python-driver invocations, including any C compilation/linking. OS page caches and Emscripten's installed system-library cache remain warm.

Runtime is **whole-process launch-to-exit time**, including host startup, Wasm compilation/instantiation, program initialization, computation, output delivery and teardown. Each observation starts a fresh process/instance and calls the entrypoint once. This measures CLI cost, not warmed kernel throughput.

Each cell has 5 build samples or 15 runtime samples. Untimed fresh-process warmups per runtime cell: 1. Orders are shuffled with the recorded seed; builds and runtime never overlap. Every used artifact must pass its golden output. Values are median milliseconds ± median absolute deviation (MAD).

Headline runtime samples use the ordinary runners without timing-file instrumentation. The Wasm supplements use a separate shuffled set of fresh processes, with the same sample count; timing files are written after their engine intervals end.

## Compilation

| Example | Direct | C-Wasm | Native C |
| --- | ---: | ---: | ---: |
| squares | 60.889 ±1.208 | 525.694 ±18.596 | 197.619 ±12.349 |
| tour | 63.707 ±0.772 | 929.426 ±10.485 | 412.996 ±15.824 |
| functions | 80.876 ±0.696 | 930.538 ±14.043 | 499.105 ±27.726 |
| errors | 67.930 ±0.118 | 691.988 ±18.145 | 347.504 ±25.772 |
| sieve | 65.578 ±0.722 | 585.606 ±6.392 | 293.321 ±2.137 |
| sorting | 106.148 ±19.354 | 841.261 ±32.192 | 525.025 ±8.747 |
| sudoku | 78.456 ±12.695 | 523.501 ±22.166 | 261.393 ±5.060 |
| maze | 78.254 ±9.522 | 656.433 ±16.231 | 354.394 ±16.858 |
| vm | 67.339 ±2.054 | 655.369 ±19.706 | 303.892 ±11.081 |
| life | 73.134 ±6.705 | 614.360 ±34.799 | 301.364 ±8.411 |

## Whole-process runtime

| Example | Direct / V8 | C-Wasm / V8 | Direct / Wasmtime | C-Wasm / Wasmtime | Native C |
| --- | ---: | ---: | ---: | ---: | ---: |
| squares | 27.725 ±4.608 | 26.757 ±2.891 | 69.143 ±1.318 | 85.867 ±6.165 | 0.812 ±0.159 |
| tour | 52.326 ±11.569 | 36.352 ±7.646 | 105.480 ±6.292 | 115.145 ±12.356 | 1.009 ±0.211 |
| functions | 32.582 ±4.132 | 33.979 ±6.078 | 103.906 ±6.653 | 124.610 ±9.936 | 0.941 ±0.189 |
| errors | 27.380 ±2.171 | 30.571 ±4.263 | 80.971 ±5.193 | 89.744 ±4.284 | 1.058 ±0.198 |
| sieve | 31.636 ±3.926 | 29.597 ±0.891 | 93.727 ±9.483 | 87.185 ±8.746 | 1.658 ±0.121 |
| sorting | 64.725 ±9.657 | 232.996 ±13.161 | 107.821 ±9.080 | 240.545 ±12.747 | 49.122 ±3.960 |
| sudoku | 42.298 ±10.761 | 38.458 ±6.293 | 85.552 ±12.391 | 97.198 ±8.078 | 4.108 ±0.244 |
| maze | 32.168 ±6.230 | 31.750 ±3.363 | 83.346 ±6.946 | 100.572 ±10.936 | 1.037 ±0.179 |
| vm | 30.117 ±1.955 | 38.231 ±9.887 | 95.336 ±13.286 | 95.300 ±7.990 | 1.250 ±0.195 |
| life | 38.054 ±6.327 | 38.404 ±2.783 | 92.774 ±12.858 | 98.252 ±6.843 | 18.250 ±0.494 |

## Supplement: Wasm entrypoint

| Example | Direct / V8 | C-Wasm / V8 | Direct / Wasmtime | C-Wasm / Wasmtime |
| --- | ---: | ---: | ---: | ---: |
| squares | 0.216 ±0.057 | 0.968 ±0.052 | 0.131 ±0.003 | 0.632 ±0.008 |
| tour | 22.987 ±1.342 | 2.706 ±0.111 | 1.755 ±0.020 | 1.721 ±0.019 |
| functions | 5.563 ±0.346 | 2.574 ±0.080 | 1.348 ±0.011 | 1.926 ±0.019 |
| errors | 1.550 ±0.013 | 1.755 ±0.069 | 0.840 ±0.005 | 1.688 ±0.010 |
| sieve | 2.281 ±0.045 | 2.498 ±0.726 | 1.215 ±0.019 | 1.343 ±0.014 |
| sorting | 23.097 ±2.374 | 194.363 ±3.349 | 15.069 ±0.113 | 122.768 ±0.966 |
| sudoku | 5.251 ±0.103 | 6.232 ±0.117 | 3.790 ±0.016 | 8.367 ±0.025 |
| maze | 2.307 ±0.093 | 3.267 ±0.132 | 0.770 ±0.009 | 2.233 ±0.012 |
| vm | 2.918 ±0.324 | 2.942 ±0.800 | 0.910 ±0.007 | 2.989 ±0.026 |
| life | 4.160 ±0.167 | 9.667 ±0.170 | 2.782 ±0.025 | 9.518 ±0.054 |

## Supplement: Wasm engine compilation and instantiation

| Example | Direct / V8 | C-Wasm / V8 | Direct / Wasmtime | C-Wasm / Wasmtime |
| --- | ---: | ---: | ---: | ---: |
| squares | 0.289 ±0.048 | 0.512 ±0.080 | 2.964 ±0.164 | 10.552 ±0.892 |
| tour | 0.429 ±0.083 | 0.536 ±0.047 | 31.699 ±1.697 | 31.854 ±1.203 |
| functions | 0.317 ±0.053 | 0.545 ±0.042 | 23.796 ±5.656 | 28.607 ±2.072 |
| errors | 0.311 ±0.057 | 0.536 ±0.036 | 9.724 ±1.285 | 16.965 ±1.874 |
| sieve | 0.260 ±0.040 | 0.577 ±0.069 | 7.111 ±1.350 | 14.538 ±1.720 |
| sorting | 0.399 ±0.060 | 0.580 ±0.046 | 20.878 ±4.917 | 31.384 ±1.293 |
| sudoku | 0.258 ±0.023 | 0.513 ±0.033 | 6.192 ±1.033 | 13.578 ±2.315 |
| maze | 0.325 ±0.063 | 0.658 ±0.081 | 11.418 ±2.144 | 18.306 ±4.065 |
| vm | 0.314 ±0.035 | 0.522 ±0.035 | 19.332 ±4.497 | 15.952 ±1.070 |
| life | 0.266 ±0.031 | 0.569 ±0.078 | 19.956 ±2.169 | 14.835 ±2.032 |

The entrypoint interval includes Goose initialization, host output callbacks and any lazy JIT work. It excludes final Wasm-host output concatenation/delivery. Native Goose prints unbuffered, so no native entrypoint column or cross-boundary speedup is presented. Process time minus engine time also includes loading, bookkeeping and teardown; it is not a pure startup measurement.

These fresh-process examples have different timing rules from LangArena's warmed computational regions. Raw samples, commands, artifact/source/compiler identities and engine versions are in [report.json](report.json). [Method and reproduction](../../../examples.md).
