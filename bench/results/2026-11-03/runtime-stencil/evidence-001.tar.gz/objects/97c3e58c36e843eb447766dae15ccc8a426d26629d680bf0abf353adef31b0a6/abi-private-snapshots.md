# Private aggregate parameter snapshots

Pilot source: `Compiler::AnalyzePrivateSnapshots` and `Function::Finish` in
`compiler/direct_wasm_emit.h`. The caller emitter and Wasm signatures do not change.

`EmitCall` converts and copies each fixed aggregate into a distinct fresh caller
activation slot before evaluating the next argument. The slot lives throughout
the call. This pilot lets selected callees use that address directly, removing
the second entry copy and its frame reservation. Scalar spills remain unchanged.

The incoming-edge census covers global initializers, all reachable specialized
bodies and inline function-value bodies, arguments and default initializers.
Named FV tail forwarding still calls `EmitCall` with its argument override;
remapping changes bindings, not the target or its snapshot construction.
Recursive edges follow the same route. Dispatch is the only other emitter that
calls specialization indices; every dispatch arm is excluded even if ordinary
calls also target it. Startup/main, exports, externs and intrinsics are excluded.
Constant-divisor clones require existing scalar leaf eligibility, and element
runs return owned arrays; neither enters the selected aggregate/scalar slice.

All parameter types must be closed fixed values. Owners, refs, slices, FN
parameters, captures, reusable/captured bindings and nonlocal needs are rejected.
All results must be scalar or void. Explicit references, reference-formal calls,
byref declarations/loops and addressed parameters retain the old entry copy.
Local slice reads use the checker's nonescape lifetime contract; the regression
test also requires rejection of a parameter slice stored in a global.

No owners or borrowed results can outlive the call. Caller snapshots remain
distinct when source arguments alias, and source-order conversion/traps remain
in the untouched caller. Fewer callee frame bytes intentionally reduce resource
use; this is not a promise that resource-exhaustion thresholds stay identical.

First compiled evidence, combined compiler
`21f9841ea9fa41f757c2ab0fd50483b0db52736513c47d6d5b10a49ba4481f16`:
Functions `by_name#41` changes from 2 copies/776 body bytes/64 frame bytes to
0 copies/735 body bytes/16 frame bytes. Both actual modules and stats are in
`abi-tests/attempt-1`; no runtime speed claim has been measured.

Seven focused tests passed in attempt-2 against baseline a8c on native, V8 and
Wasmtime at O0/O2 with debug off/on. The baseline checks prove caller-body byte
identity, callee copy/frame reduction and fallback-body identity. A missing
stdlib `min` fixture failure is preserved in attempt-1. Additional duplicate
mutable-argument and owner fallback fixtures are source-prepared for the next
combined build/test window.
