#!/usr/bin/env python3
"""Named compiler pairs on unchanged workloads with default Node/V8 settings."""
from pathlib import Path
import argparse,sys,json,math
from measure_kernels import Measurement, ROOT, REFERENCE, require
import langarena as arena
class V8(Measurement):
 def prepare_inputs(self):
  super().prepare_inputs()
  self.pin(Path(__file__),snapshot=True)
  self.node=self.pin(self.args.node.resolve());self.runner=self.pin(ROOT/'scripts/run_wasm.mjs',snapshot=True)
  self.report['v8']=self.run([self.node,'-p','JSON.stringify(process.versions)'],'metadata/node-version')['stdout']
  self.report['runtime_engine']='v8-default';self.report['configuration']['runtime_flags']=[]
 def execute(self,case,variant,phase,round_):
  artifact=self.report['artifacts'][case['name']][variant]
  require(artifact['family']=='direct','V8 comparator supports direct compilers only')
  profile='run'
  if phase=='qualify':profile='test'
  config=case[profile];directory=f'runtime/{phase}/{round_:02}/{case["id"]}/{variant}'
  result=self.run([self.taskset,'-c',str(2),self.node,self.runner,artifact['path']],directory,config['stdin'])
  require(not result['stderr'],'unexpected V8 stderr')
  data=arena.parse_port_result(result['stdout'],result['returncode'],config['checksum'])
  require(math.isfinite(data['timed_region_seconds']) and 0<data['timed_region_seconds']<=result['wall_seconds'],'invalid interval')
  self.report['observations'].append({'task':case['name'],'variant':variant,'engine':'v8','phase':phase,'round':round_,
    'profile':profile,'runtime_affinity':[2],'artifact_sha256':artifact['sha256'],'log_directory':str(self.out/directory),
    'process_wall_seconds':result['wall_seconds'],**data});self.save()
def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--compiler',action='append',required=True);p.add_argument('--node',type=Path,required=True)
 p.add_argument('--filter',action='append',default=[]);p.add_argument('--samples',type=int,default=9)
 p.add_argument('--reference',type=Path,default=REFERENCE);p.add_argument('--output',type=Path,required=True)
 a=p.parse_args();a.references=False;a.timeout=600;a.seed=181771
 V8(a).main()
if __name__=='__main__':main()
