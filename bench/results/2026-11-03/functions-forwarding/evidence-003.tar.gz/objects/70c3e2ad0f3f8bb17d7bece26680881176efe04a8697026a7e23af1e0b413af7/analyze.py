"""Static byte estimate only; never compile or execute a Wasm module."""
from pathlib import Path
import hashlib
import json

ROOT=Path.cwd();OUT=ROOT/'build/functions-next/ensure-memory'
PATH=ROOT/'build/functions-hill/current/examples/compile/functions/direct/3/program.wasm'

def leb(data,offset,signed=False):
    value=0;shift=0
    while True:
        byte=data[offset];offset+=1;value|=(byte&127)<<shift;shift+=7
        if byte<128:break
    if signed and byte&64:value-=1<<shift
    return value,offset

def width(value):
    size=1
    while value>=128:value>>=7;size+=1
    return size

def name(data,offset):
    size,offset=leb(data,offset)
    return data[offset:offset+size].decode(),offset+size

def instructions(body):
    groups,offset=leb(body,0)
    for _ in range(groups):_,offset=leb(body,offset);offset+=1
    result=[]
    while offset<len(body):
        start=offset;op=body[offset];offset+=1;args=[]
        if op in (0x02,0x03,0x04,0x0c,0x0d,0x10,0x20,0x21,0x22,0x23,0x24,0x3f,0x40,0x41,0x42):
            value,offset=leb(body,offset,op in (0x41,0x42));args.append(value)
        elif op==0x0e:
            count,offset=leb(body,offset)
            for _ in range(count+1):_,offset=leb(body,offset)
        elif op==0x11 or 0x28<=op<=0x3e:
            _,offset=leb(body,offset);_,offset=leb(body,offset)
        elif op==0x43:offset+=4
        elif op==0x44:offset+=8
        elif op==0xfc:
            sub,offset=leb(body,offset)
            if sub in (10,14):_,offset=leb(body,offset);_,offset=leb(body,offset)
            elif sub in (11,15,16,17):_,offset=leb(body,offset)
            else:raise AssertionError(('unrecognized bulk-memory instruction',sub))
        elif op==0xfd:
            sub,offset=leb(body,offset)
            if sub<=11 or sub in (92,93):_,offset=leb(body,offset);_,offset=leb(body,offset)
            elif sub in (12,13):offset+=16
            elif 21<=sub<=34:offset+=1
            elif 84<=sub<=91:_,offset=leb(body,offset);_,offset=leb(body,offset);offset+=1
        else:assert op in (0x00,0x01,0x05,0x0b,0x0f,0x1a,0x1b) or 0x45<=op<=0xc4,hex(op)
        result.append({'op':op,'start':start,'end':offset,'args':args})
    assert offset==len(body)
    return result

raw=PATH.read_bytes();assert raw[:8]==b'\0asm\1\0\0\0';offset=8;sections={};names={}
while offset<len(raw):
    kind=raw[offset];size,start=leb(raw,offset+1);data=raw[start:start+size];offset=start+size
    if kind:sections[kind]=data
    else:
        custom,pos=name(data,0)
        if custom!='name':continue
        while pos<len(data):
            sub=data[pos];size,start=leb(data,pos+1);end=start+size;pos=end
            if sub!=1:continue
            count,at=leb(data,start)
            for _ in range(count):index,at=leb(data,at);names[index],at=name(data,at)
imports,offset=leb(sections[2],0)
for _ in range(imports):
    _,offset=name(sections[2],offset);_,offset=name(sections[2],offset);assert sections[2][offset]==0
    _,offset=leb(sections[2],offset+1)
count,offset=leb(sections[10],0);start_index=next(index for index,label in names.items() if label=='_start')
helper_index=start_index+1;rows=[];grow_count=0
pattern=[0x20,0x41,0x76,0x20,0x41,0x71,0x45,0x45,0x6a,0x3f,0x6b,0x40,0x41,0x46]
for ordinal in range(count):
    size,start=leb(sections[10],offset);body=sections[10][start:start+size];offset=start+size;ops=instructions(body)
    for i,op in enumerate(ops):
        if op['op']!=0x40:continue
        grow_count+=1;span=ops[i-11:i+3];assert [x['op'] for x in span]==pattern
        assert span[0]['args']==span[3]['args'] and span[1]['args']==[16] and span[4]['args']==[65535]
        assert span[-2]['args']==[-1] and span[9]['args']==span[11]['args']==[0]
        before=span[-1]['end']-span[0]['start'];after=span[0]['end']-span[0]['start']+1+width(helper_index)
        rows.append({'function':names[imports+ordinal],'function_index':imports+ordinal,'local':span[0]['args'][0],
                     'grow_offset':op['start'],'inline_slow_bytes':before,'call_slow_bytes':after,'saved_bytes':before-after})
result={'kind':'static-source-and-existing-module-estimate','status':'estimated-only','source_head':'66e08646d0acf230b34bfc24c3b1d907d086e62b',
        'module':str(PATH),'module_sha256':hashlib.sha256(raw).hexdigest(),'module_bytes':len(raw),
        'imports':imports,'defined_functions':count,'start_index':start_index,'proposed_helper_index':helper_index,
        'grow_instructions':grow_count,'matched_ensure_memory_slow_paths':len(rows),'sites':rows,
        'removed_inline_instruction_bytes':sum(row['saved_bytes'] for row in rows),'helper_body_bytes':25,
        'estimated_code_payload_saving':sum(row['saved_bytes'] for row in rows)-25,
        'limits':'No candidate compiler/module was built or executed. Type, function, code-length and debug-name section overhead and engine behavior are not included in the code-payload estimate.'}
assert grow_count==len(rows)
result['sites_per_function']={name:sum(row['function']==name for row in rows) for name in dict.fromkeys(row['function'] for row in rows)}
(OUT/'static-estimate.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({key:value for key,value in result.items() if key not in {'sites','limits'}},indent=2))
