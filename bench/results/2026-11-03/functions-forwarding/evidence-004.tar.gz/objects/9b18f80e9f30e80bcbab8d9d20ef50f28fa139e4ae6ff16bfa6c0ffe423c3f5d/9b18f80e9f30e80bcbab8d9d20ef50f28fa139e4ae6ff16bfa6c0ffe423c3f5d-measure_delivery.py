#!/usr/bin/env python3
"""Run qualified delivery cohorts sequentially, with immutable phase evidence.

Invoke after the exclusive qualification/replay window closes. This starts real
measurements; never run it alongside a build, test, renderer, hash or packager.
Failed/existing output reports are preserved and must be moved explicitly before
a fresh attempt. The historical final-* campaign reports are never overwritten.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import math
import os
import shutil
import signal
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[2]
BUILD=ROOT/'build/functions-next'
QUAL=BUILD/'qualification/attempt-1'
REFERENCE=ROOT/'build/runtime-reference/production/report.json'
REFERENCE_SHA='06c1f5b883af43d5f5563416fec01d5a1ff5ec309a5005e3abb5293654e59350'
BASELINE_SHA='5e3b87720d24f3285a5f9df57989c200bf7152a28f296cfd3af0220db1cc2edf'
CAPS=('RAYON_NUM_THREADS','OMP_NUM_THREADS','BINARYEN_CORES')
CONTROLS=(*CAPS,'LD_PRELOAD','LD_LIBRARY_PATH','NODE_OPTIONS','GOOSE_STDLIB')


def utc(): return datetime.now(timezone.utc).isoformat()


def digest(path):
    with Path(path).open('rb') as data: return hashlib.file_digest(data,'sha256').hexdigest()


def load(path): return json.loads(Path(path).read_bytes())


def require(condition,message):
    if not condition: raise RuntimeError(str(message))


class Delivery:
    def __init__(self,args):
        self.args=args
        self.out=args.execution_dir.absolute()
        require(not (self.out/'report.json').exists(),'preserve the previous delivery attempt before rerunning')
        self.out.mkdir(parents=True,exist_ok=True)
        self.pins={}
        self.report={'schema':'goose-delivery-execution-v1','status':'preparing','started_utc':utc(),
            'configuration':vars(args),'phases':[],'input_sha256':self.pins,
            'method':'One child phase at a time after complete correctness qualification. Each child builds/prepares and qualifies before its runtime tier. No qualification thread caps are inherited. Warmed references were selected previously; no selection uses these delivery rounds.'}

    def save(self):
        temporary=self.out/'report.tmp'
        temporary.write_text(json.dumps(self.report,indent=2,default=str)+'\n')
        temporary.replace(self.out/'report.json')

    def pin(self,path,expected=None,snapshot=False):
        path=Path(path).absolute(); sha=digest(path)
        require(expected is None or expected==sha,('input differs',str(path)))
        require(str(path) not in self.pins or self.pins[str(path)]==sha,('input changed',str(path)))
        self.pins[str(path)]=sha
        if snapshot:
            destination=self.out/'frozen-inputs'/(sha+'-'+path.name)
            destination.parent.mkdir(exist_ok=True)
            if not destination.exists(): shutil.copyfile(path,destination)
            require(digest(destination)==sha,'source snapshot differs')
            self.pins[str(destination)]=sha
        return path

    def verify(self):
        for path,sha in self.pins.items(): require(digest(path)==sha,('pinned delivery input changed',path))
        for key,value in self.report['environment']['controls'].items():
            require(os.environ.get(key)==value,('runtime environment changed',key))
        require(sorted(os.sched_getaffinity(0))==self.report['environment']['affinity'],'parent CPU affinity changed')

    def prepare(self):
        args=self.args
        for key in CONTROLS: require(os.environ.get(key) is None,('unset runtime control before delivery',key))
        self.report['environment']={'controls':{key:os.environ.get(key) for key in CONTROLS},
            'affinity':sorted(os.sched_getaffinity(0)),'PATH':os.environ.get('PATH'),'python':sys.version,
            'EMCC_CORES':os.environ.get('EMCC_CORES'),'load_average':list(os.getloadavg())}
        require(2 in os.sched_getaffinity(0),'CPU2 unavailable for warmed pairs')
        folder=args.compiler_root
        if folder is None: folder=BUILD/'compiler-experiments'/args.compiler
        folder=folder.absolute(); self.compiler=self.pin(folder/'bin/goose')
        toolchain=load(self.pin(folder/'toolchain.json',snapshot=True))
        source=load(self.pin(folder/'source.json',snapshot=True))
        self.sha=digest(self.compiler)
        require(toolchain['compiler_sha256']==self.sha,'frozen compiler/toolchain mismatch')
        require(toolchain['headers']==source['headers'] and toolchain['patches']==source['patches'],'frozen compiler/source metadata mismatch')
        self.pin(ROOT/'build/bin/goose',self.sha)
        for name,expected in source['headers'].items(): self.pin(folder/'compiler'/name,expected,snapshot=True)
        for name,expected in source['patches'].items():
            candidates=[folder/name,folder/'source'/name,ROOT/name]
            matches=[path for path in candidates if path.is_file() and digest(path)==expected]
            require(matches,('compiler patch unavailable',name)); self.pin(matches[0],expected,snapshot=True)
        for directory,pattern in [(self.compiler.parent/'stdlib','*.goose'),(self.compiler.parent/'include','*.h')]:
            require(directory.is_dir(),('installed compiler dependency missing',directory))
            for path in directory.rglob(pattern): self.pin(path,snapshot=True)
        self.pin(Path(__file__),snapshot=True)
        for name in ['bench/examples.py','bench/wasmtime_host.py','bench/langarena.py','bench/benchmark.py',
                     'bench/host_input.c','scripts/goose_wasm.py','oracle/goose_wasm.py','scripts/run_wasm.mjs',
                     'scripts/run_wasmtime.py','toolchain.json','build/full-hills/measure_kernels.py',
                     'build/full-hills/measure_v8_kernels.py','examples/manifest.json']:
            self.pin(ROOT/name,snapshot=True)
        for path in (ROOT/'examples').glob('*.goose'): self.pin(path,snapshot=True)
        for path in (ROOT/'examples/expected').glob('*.out'): self.pin(path,snapshot=True)
        for path in (ROOT/'bench/langarena').glob('*.json'): self.pin(path,snapshot=True)
        for path in (ROOT/'bench/langarena/ports').glob('*.goose'): self.pin(path,snapshot=True)
        self.pin(REFERENCE,REFERENCE_SHA,snapshot=True); reference=load(REFERENCE)
        self.node=Path(args.node).absolute()
        node_sha=reference['inputs'][reference['tools']['node']]
        self.pin(self.node,node_sha)
        path_node=shutil.which('node'); require(path_node,'node unavailable in PATH')
        self.pin(Path(path_node).resolve(),node_sha)
        baseline=ROOT/'build/functions-hill/final/bin/goose'; self.pin(baseline,BASELINE_SHA)
        self.pin(baseline.parent.parent/'source.json',snapshot=True)
        self.pin(baseline.parent.parent/'toolchain.json',snapshot=True)
        for case in reference['workloads']:
            self.pin(case['source'],reference['inputs'][case['source']],snapshot=True)
            for path in Path(case['source']).parent.glob('*.goose'):
                self.pin(path,reference['inputs'][str(path)],snapshot=True)
        focused=load(self.pin(QUAL/'focused/report.json',snapshot=True))
        differential=load(self.pin(QUAL/'differential/report.json',snapshot=True))
        replay=load(self.pin(QUAL/'host/report.json',snapshot=True))
        require(focused['status']=='passed' and focused['compiler_sha256']==self.sha and len(focused['commands'])==67,
                'all67 focused gates must pass for the final compiler')
        require(all(row['exit_status']==0 for row in focused['commands']),'focused gate failed')
        require(differential['compiler_sha256']==self.sha and differential['failures']==0 and differential['observations']==9573 and differential['cases']==978,
                'complete differential qualification is required')
        require(differential['qualification_execution']['native_stdout_comparisons']==7656,'native stdout comparisons incomplete')
        require(replay['status']=='pass' and replay['compiler_sha256']==self.sha and replay['coverage_exact'] and replay['observations']==11484 and replay['failures']==0,
                'complete native-host replay is required')
        # Check the gate's declared inputs once before collection. The immutable
        # gate reports and the measurement's actual sources are pinned thereafter.
        qualified=differential['qualification_execution']['input_sha256']
        for path,expected in qualified.items(): self.pin(path,expected)
        self.host=self.pin(args.host,replay['host_build']['host_sha256'])
        host=load(self.pin(self.host.with_suffix('.json'),snapshot=True))
        require(host==replay['host_build'] and host['linkage']=='sdk-static','production host differs from qualification')
        self.pin(host['library'],host['library_sha256'])
        python_engine=replay['python_engine']
        self.pin(python_engine['library'],python_engine['library_sha256'])
        require(python_engine['version']==host['version']==reference['host_build']['version'],'engine versions differ')
        self.report.update(compiler_sha256=self.sha,compiler_root=str(folder),host_build=host,python_engine=python_engine)
        self.reference=reference
        machine=args.machine_label
        current=args.current_dir.absolute()
        compiler_args=['--compiler','baseline='+str(baseline),'--compiler','final='+str(self.compiler),'--samples',str(args.samples)]
        self.commands=[
            ('delivered-warmed',[sys.executable,BUILD/'measure_kernels.py',*compiler_args,'--references','--output',args.warmed_dir],args.warmed_dir/'report.json'),
            ('delivered-v8',[sys.executable,BUILD/'measure_v8_kernels.py',*compiler_args,'--node',self.node,'--output',args.v8_dir],args.v8_dir/'report.json'),
            ('examples',[sys.executable,ROOT/'bench/examples.py','--goose',self.compiler,'--node',self.node,
                         '--compile-samples','5','--samples','15','--warmups','1','--machine-label',machine,'--output-dir',current/'examples'],current/'examples/report.json'),
            ('host',[sys.executable,ROOT/'bench/wasmtime_host.py','--host',self.host,'--example-report',current/'examples/report.json',
                     '--samples','15','--prepare-samples','5','--warmups','1','--machine-label',machine,'--output-dir',current/'host'],current/'host/report.json'),
            ('langarena',[sys.executable,ROOT/'bench/langarena.py','measure','--goose',self.compiler,'--node',self.node,
                          '--upstream',ROOT/'build/langarena-upstream','--tracks','adapted','--backends','native','c-wasm','direct',
                          '--engines','v8','wasmtime','--profiles','test','run','--compile-samples','5','--runtime-samples','5',
                          '--skip-edits','--machine-label',machine,'--output-dir',current/'langarena'],current/'langarena/report.json')]
        for name,command,path in self.commands:
            require(not path.exists(),('existing cohort preserved; choose fresh output paths',name,str(path)))
        self.report['planned_commands']=[{'name':name,'command':list(map(str,command)),'report':str(path.absolute())} for name,command,path in self.commands]
        self.verify(); self.save()

    def validate(self,name,report):
        require(report['status']=='passed' and not report.get('failures'),('cohort failed',name))
        if name.startswith('delivered-'):
            require(report['coverage_exact'] and report['workloads']==self.reference['workloads'],'incomplete/mismatched warmed workload matrix')
            require(report['configuration']['samples']==self.args.samples and set(report['compilers'])=={'baseline','final'},'named compiler/sample scope differs')
            require(report['compilers']['final']['sha256']==self.sha and report['compilers']['baseline']['sha256']==BASELINE_SHA,'named compiler identity differs')
            require(report['input_sha256']==report['input_sha256_after'],'warmed input pins changed')
            expected={(case['name'],variant,phase,i) for case in report['workloads'] for variant in report['artifacts'][case['name']]
                      for phase,n in [('qualify',1),('measure',self.args.samples)] for i in range(n)}
            actual=[(row['task'],row['variant'],row['phase'],row['round']) for row in report['observations']]
            require(len(actual)==len(set(actual)) and set(actual)==expected,'warmed coverage differs')
            for row in report['observations']:
                require(math.isfinite(row['timed_region_seconds']) and 0<row['timed_region_seconds']<=row['process_wall_seconds'],'invalid warmed timer')
                require(row['checksum']==row['expected_checksum'] and row['runtime_affinity']==[2],'warmed checksum/affinity differs')
            return
        require(report['environment']['compiler_sha256']==self.sha,'current cohort compiler differs')
        expected={'examples':1600,'host':1440,'langarena':315}[name]
        require(len(report['observations'])==expected,('current cohort observations differ',name))
        if name=='host': require(len(report['preparation'])==200 and report['host_build']==self.report['host_build'],'host preparation/identity differs')
        if name=='langarena': require(report['environment']['python_engine'] is not None,'LangArena engine pin absent')

    def retain_artifacts(self,value):
        if isinstance(value,dict):
            for path,sha in [('artifact','artifact_sha256'),('artifact','sha256'),('path','sha256'),('aot_path','aot_sha256')]:
                if isinstance(value.get(path),str) and isinstance(value.get(sha),str) and Path(value[path]).suffix in {'.wasm','.cwasm','.bin'}:
                    self.pin(value[path],value[sha])
            for item in value.values(): self.retain_artifacts(item)
        elif isinstance(value,list):
            for item in value: self.retain_artifacts(item)

    def main(self):
        try:
            self.prepare(); self.report['status']='running'; self.save()
            for name,command,path in self.commands:
                self.verify()
                row={'name':name,'command':list(map(str,command)),'report':str(path.absolute()),'started_utc':utc(),
                     'load_average_before':list(os.getloadavg()),'status':'running'}
                self.report['phases'].append(row); self.save(); print('START',name,flush=True)
                started=time.monotonic()
                with (self.out/(name+'.stdout')).open('w') as stdout,(self.out/(name+'.stderr')).open('w') as stderr:
                    process=subprocess.Popen(row['command'],cwd=ROOT,stdout=stdout,stderr=stderr,start_new_session=True)
                    row['pid']=process.pid; self.save()
                    try: status=process.wait()
                    except BaseException:
                        os.killpg(process.pid,signal.SIGTERM)
                        try: process.wait(timeout=10)
                        except subprocess.TimeoutExpired:
                            os.killpg(process.pid,signal.SIGKILL); process.wait()
                        raise
                row.update(exit_status=status,wall_seconds=time.monotonic()-started,finished_utc=utc(),
                           load_average_after=list(os.getloadavg()),stdout_sha256=digest(self.out/(name+'.stdout')),
                           stderr_sha256=digest(self.out/(name+'.stderr')))
                require(status==0,('delivery child failed; preserve this attempt',name,status))
                cohort=load(path); self.validate(name,cohort)
                self.pin(path); self.retain_artifacts(cohort); self.verify()
                row.update(status='passed',report_sha256=digest(path)); self.save(); print('DONE',name,flush=True)
            self.report.update(status='passed',input_sha256_after={path:digest(path) for path in self.pins})
        except BaseException as error:
            self.report.update(status='failed',error=type(error).__name__+': '+str(error)); raise
        finally:
            self.report['finished_utc']=utc(); self.save()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--compiler',required=True,help='final frozen compiler-experiments name')
    parser.add_argument('--compiler-root',type=Path)
    parser.add_argument('--host',type=Path,default=ROOT/'build/bin/goose-wasmtime')
    parser.add_argument('--node',type=Path,default=Path('/home/jacobt/.local/share/fnm/node-versions/v24.22.1/installation/bin/node'))
    parser.add_argument('--samples',type=int,default=9)
    parser.add_argument('--current-dir',type=Path,default=BUILD/'current')
    parser.add_argument('--warmed-dir',type=Path,default=BUILD/'delivered-warmed')
    parser.add_argument('--v8-dir',type=Path,default=BUILD/'delivered-v8')
    parser.add_argument('--execution-dir',type=Path,default=BUILD/'delivery-execution')
    parser.add_argument('--machine-label',default='AMD Ryzen 7 3800X, shared desktop host')
    args=parser.parse_args()
    if args.samples<9: parser.error('delivery requires at least9 fresh paired rounds')
    Delivery(args).main()


if __name__=='__main__': main()
