# Copy draft — pending qualification and final measurements

Replace every bracketed placeholder with verified final evidence before publication. Keep the prior local-pass cohort separate; do not combine its numbers with the new cohort.

## README.md

Replace the benchmark results link with:

The latest compiler also forwards eligible terminal callbacks without copying their parameters. [Full results and raw samples](bench/results/2026-11-03/functions-forwarding/README.md) · [Benchmark method](bench/langarena/README.md)

Update all chart-adjacent numerical text from the fresh cohorts when the ten charts are regenerated.

## docs/FUNCTIONS_PERFORMANCE.md

# Functions performance

The direct backend forwards eligible terminal callbacks through their original arguments. It applies only to identity forwarding with no remapping, non-owning fixed closed immutable parameters, scalar or void results, and a terminal body independent of the bypassed bindings. Arguments still run left to right, and the first record snapshots are constructed in the terminal bindings. It does not shortcut borrowing.

Functions shrank from 45,923 to 42,296 bytes (7.9%); copies fell from 427 to 317. All non-code payload is identical. The baseline already includes the [earlier local pass](../bench/results/2026-11-03/functions/README.md), which combined adjacent local operations and removed unused locals; its measurements belong to a separate cohort.

[Final paired CPU 2 holdout: boundary, sample count, baseline → current medians, paired speedup and MAD.] [Final normal-pool process cohort: boundary, sample count and results, including any uncertainty.] CPU 2 phase measurements and normal-pool process timings are separate experiments; startup, compilation, first entry and warmed body timings measure different work.

[Final fresh process results, including ordinary and precompiled native-host timings and native C, with preparation excluded from precompiled timing.] [Final warmed results with workload and engine coverage, and any regressions.] [Qualification counts and results.] [Measurements, identities and retained experiments](../bench/results/2026-11-03/functions-forwarding/README.md).

## bench/results/2026-11-03/functions-forwarding/README.md

# Functions callback forwarding · November 3, 2026

Compiler SHA-256 `[verified candidate hash]` is compared with delivered compiler `[verified baseline hash]` on [machine and CPU]. Goose upstream is `[revision]`; Wasmtime is `[version and build identities]` and Node is `[version]` / V8 `[version]`. [Identify compiler, host and reference artifact builds and disclose any separately collected reference runs.]

Eligible terminal callback forwarding reduced the Functions module from 45,923 to 42,296 bytes and copies from 427 to 317; all non-code payload is identical. The [Functions investigation](../../../../docs/FUNCTIONS_PERFORMANCE.md) describes the optimization and its boundaries. The [earlier local-pass cohort](../functions/README.md) used a different compiler comparison and measurements.

[Describe the five final fresh cohorts, sample counts, workloads, checked outputs, and links to their retained raw reports. State whether reference artifacts were built or collected separately.]

[Final CPU 2 paired holdout: link, sample count, exact phase boundaries, baseline and candidate medians, paired speedups and MAD.] [Final normal-pool process results and uncertainty.] CPU 2 phase measurements and normal-pool process measurements are separate; ordinary process launches include startup and compilation, precompiled launches exclude preparation, and first entry and warmed body timings use different boundaries.

[Qualification: final focused gate, differential and host replay counts and outcomes, configurations, and links to evidence.] [Retained experiments and measured tradeoffs, with links; report any failures or regressions.]
