"""Derive the delivery note from completed raw cohorts; never sample."""
from pathlib import Path
import hashlib,json,math,statistics,sys
ROOT=Path(__file__).resolve().parents[2]
BUILD=ROOT/'build/functions-next'
sys.path.insert(0,str(ROOT/'bench'))
from benchmark import summary

def read(path):return json.loads(path.read_bytes())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n')

def holdout(folder):
 r=read(BUILD/folder/'report.json');assert r['status']=='passed'
 p={(x['sample'],x['variant'],x['engine']):x['timing'] for x in r['phase_probes']}
 phases={}
 for engine in ['v8','native-host']:
  phases[engine]={}
  for field in ['compile_instantiate_ns','start_function_ns','engine_total_ns']:
   baseline=[p[i,'baseline-O2',engine][field] for i in range(31)]
   current=[p[i,'forward-O2',engine][field] for i in range(31)]
   phases[engine][field]={'baseline_ms':statistics.median(baseline)/1e6,'current_ms':statistics.median(current)/1e6,
                         'paired_speedup':summary([a/b for a,b in zip(baseline,current)])}
 return {'method':r['method'],'process':r['summary'],'process_paired_speedups':r['paired_speedups'],'phases':phases}

def warmed(path):
 r=read(path);assert r['status']=='passed' and r['coverage_exact']
 indexed={(o['task'],o['variant'],o['round']):o['timed_region_seconds'] for o in r['observations'] if o['phase']=='measure'}
 tasks={case['name']:summary([indexed[case['name'],'baseline',i]/indexed[case['name'],'final',i] for i in range(9)]) for case in r['workloads']}
 means=[math.exp(sum(math.log(indexed[case['name'],'baseline',i]/indexed[case['name'],'final',i]) for case in r['workloads'])/len(r['workloads'])) for i in range(9)]
 return {'tasks':tasks,'geomean':summary(means),
         'same_wasm_bytes':{case['name']:r['artifacts'][case['name']]['baseline']['sha256']==r['artifacts'][case['name']]['final']['sha256'] for case in r['workloads']}}

def main():
 host=read(BUILD/'current/host/report.json');examples=read(BUILD/'current/examples/report.json');cohort=read(BUILD/'current/langarena/report.json')
 host_rows=[r for r in host['runtime_summary'] if r['name'] in {'functions','sorting','sudoku','life'}]
 ranges={}
 for name,rows in [('langarena',[r for r in cohort['compile_summary'] if r['track']=='adapted' and r['phase']=='cold']),('examples',examples['compile_summary'])]:
  ranges[name]={}
  for backend in ['direct','c-wasm','native']:
   values=[r['wall_seconds']['median']*1000 for r in rows if r['backend']==backend]
   ranges[name][backend]={'min_ms':min(values),'max_ms':max(values)}
 values={'host':host_rows,'compile_ranges':ranges,'cpu2':holdout('holdout-cpu2'),'default':holdout('holdout-default'),
         'warmed_wasmtime':warmed(BUILD/'delivered-warmed/report.json'),'warmed_v8':warmed(BUILD/'delivered-v8/report.json')}
 raw_warmed=read(BUILD/'delivered-warmed/report.json')
 values['target_table']=[{'task':row['task'],'direct_ms':row['times']['final']['median']*1000,
                         'selected_wasm_ms':row['times'][row['reference_roles']['selected_wasm']]['median']*1000,
                         'selected_native_ms':row['times'][row['reference_roles']['selected_native']]['median']*1000} for row in raw_warmed['summary']]
 save(BUILD/'final-numbers.json',values)
 files={'focused':'qualification/attempt-1/focused/report.json','differential':'qualification/attempt-1/differential/report.json',
        'host_qualification':'qualification/attempt-1/host/report.json','warmed_wasmtime':'delivered-warmed/report.json','warmed_v8':'delivered-v8/report.json',
        'examples':'current/examples/report.json','host':'current/host/report.json','langarena':'current/langarena/report.json',
        'cpu2':'holdout-cpu2/report.json','default':'holdout-default/report.json','module_analysis':'module-analysis.json',
        'static_review':'forwarding-static-review.json','test_review':'forwarding-test-static-review.json'}
 campaign={'schema':'goose-functions-forwarding-campaign-v1','status':'passed','compiler_sha256':read(BUILD/'forward-v3/toolchain.json')['compiler_sha256'],
           'baseline_compiler_sha256':read(ROOT/'build/functions-hill/final/toolchain.json')['compiler_sha256'],
           'reports':{key:{'path':str(BUILD/value),'sha256':sha(BUILD/value)} for key,value in files.items()},
           'qualification':{'focused_commands':67,'differential_executions':9573,'native_comparisons':7656,'cases':978,'host_executions':11484},
           'module_analysis':read(BUILD/'module-analysis.json'),
           'method':'Fresh final cohorts after full qualification, followed by independent CPU2 and default-affinity61-pair process/31-pair engine-phase holdouts. First entry includes initialization, callbacks and lazy JIT; preparation and process startup are separate boundaries.',
           'tradeoffs':['Identity-only, no remaps; fixed closed immutable parameters; scalar/void exact results; no captures, address uses, owned parameters or parent-binding dependencies. First source-order snapshots retained.',
                        'Shared EnsureMemory slow path is retained as an unmeasured proposal, not a delivered optimization or rejected timing result.',
                        'Exploratory v1 screening preceded final qualification; only final holdouts support delivered paired timing claims.'],
           'summary':values}
 save(BUILD/'campaign.json',campaign)
 print(json.dumps({'ranges':ranges,'functions_host_ms':[{k:r[k] for k in ['backend','mode']}|{'ms':r['wall_seconds']['median']*1000} for r in host_rows if r['name']=='functions'],
                   'cpu2_phase_speedups':{e:{k:v['paired_speedup']['median'] for k,v in fields.items()} for e,fields in values['cpu2']['phases'].items()},
                   'default_process_speedups':{k:v['median'] for k,v in values['default']['process_paired_speedups'].items()},
                   'warmed':{k:values[k]['geomean']['median'] for k in ['warmed_wasmtime','warmed_v8']}},indent=2))
if __name__=='__main__':main()
