# Example program benchmarks

Status: **passed**.

2026-11-03 · AMD Ryzen 7 3800X, shared desktop host.

Goose O2. Direct Wasm uses memory32; C-Wasm uses memory64. The selected programs, their constant inputs and all printing are unchanged from the [example catalog](../../../../examples/README.md). Compiler constant folding is allowed.

Builds are complete uncached Python-driver invocations, including any C compilation/linking. OS page caches and Emscripten's installed system-library cache remain warm.

Runtime is **whole-process launch-to-exit time**, including host startup, Wasm compilation/instantiation, program initialization, computation, output delivery and teardown. Each observation starts a fresh process/instance and calls the entrypoint once. This measures CLI cost, not warmed kernel throughput.

Each cell has 5 build samples or 15 runtime samples. Untimed fresh-process warmups per runtime cell: 1. Orders are shuffled with the recorded seed; builds and runtime never overlap. Every used artifact must pass its golden output. Values are median milliseconds ± median absolute deviation (MAD).

Headline runtime samples use the ordinary runners without timing-file instrumentation. The Wasm supplements use a separate shuffled set of fresh processes, with the same sample count; timing files are written after their engine intervals end.

## Compilation

| Example | Direct | C-Wasm | Native C |
| --- | ---: | ---: | ---: |
| squares | 60.228 ±0.174 | 483.768 ±12.539 | 195.999 ±5.496 |
| tour | 63.405 ±0.437 | 919.482 ±19.427 | 405.878 ±9.105 |
| functions | 95.485 ±15.188 | 954.825 ±38.509 | 480.329 ±7.070 |
| errors | 68.360 ±1.582 | 700.745 ±13.697 | 352.947 ±30.194 |
| sieve | 65.806 ±2.324 | 600.124 ±33.683 | 278.939 ±16.419 |
| sorting | 85.491 ±0.493 | 871.410 ±8.723 | 523.498 ±12.186 |
| sudoku | 67.956 ±3.001 | 520.411 ±29.978 | 256.131 ±1.702 |
| maze | 69.701 ±1.191 | 707.561 ±14.760 | 350.165 ±13.850 |
| vm | 66.214 ±0.552 | 653.124 ±18.101 | 273.619 ±2.451 |
| life | 67.212 ±0.659 | 618.323 ±20.752 | 293.246 ±4.053 |

## Whole-process runtime

| Example | Direct / V8 | C-Wasm / V8 | Direct / Wasmtime | C-Wasm / Wasmtime | Native C |
| --- | ---: | ---: | ---: | ---: | ---: |
| squares | 28.348 ±4.185 | 40.715 ±7.741 | 71.979 ±5.402 | 84.073 ±6.756 | 1.025 ±0.179 |
| tour | 44.539 ±1.400 | 33.886 ±3.981 | 125.252 ±17.171 | 116.493 ±13.639 | 1.198 ±0.152 |
| functions | 39.562 ±8.495 | 33.051 ±4.539 | 102.619 ±3.256 | 102.769 ±6.752 | 0.854 ±0.110 |
| errors | 29.328 ±3.204 | 48.055 ±5.260 | 87.849 ±9.059 | 89.468 ±5.226 | 0.902 ±0.137 |
| sieve | 37.215 ±8.483 | 40.414 ±8.421 | 76.860 ±3.029 | 84.673 ±3.582 | 1.234 ±0.230 |
| sorting | 68.708 ±9.688 | 230.798 ±7.466 | 111.691 ±4.913 | 223.436 ±3.573 | 47.067 ±2.219 |
| sudoku | 55.315 ±6.980 | 37.016 ±5.398 | 76.246 ±1.905 | 94.068 ±6.982 | 4.475 ±0.560 |
| maze | 29.454 ±1.754 | 31.115 ±2.364 | 82.993 ±5.258 | 100.437 ±11.055 | 0.894 ±0.175 |
| vm | 30.356 ±2.493 | 48.174 ±9.621 | 85.908 ±3.244 | 97.769 ±8.887 | 0.943 ±0.157 |
| life | 37.912 ±3.527 | 45.279 ±6.748 | 89.999 ±7.959 | 97.701 ±6.132 | 18.500 ±0.708 |

## Supplement: Wasm entrypoint

| Example | Direct / V8 | C-Wasm / V8 | Direct / Wasmtime | C-Wasm / Wasmtime |
| --- | ---: | ---: | ---: | ---: |
| squares | 0.183 ±0.010 | 0.941 ±0.014 | 0.127 ±0.004 | 0.628 ±0.004 |
| tour | 19.259 ±5.148 | 2.689 ±0.089 | 1.736 ±0.027 | 1.703 ±0.017 |
| functions | 5.696 ±0.494 | 2.685 ±0.083 | 1.332 ±0.009 | 1.910 ±0.015 |
| errors | 1.376 ±0.065 | 1.814 ±0.121 | 0.835 ±0.009 | 1.694 ±0.017 |
| sieve | 2.315 ±0.077 | 1.810 ±0.044 | 1.238 ±0.016 | 1.352 ±0.016 |
| sorting | 22.205 ±1.108 | 194.365 ±5.190 | 15.169 ±0.061 | 121.737 ±0.957 |
| sudoku | 5.314 ±0.169 | 6.599 ±0.105 | 3.610 ±0.025 | 8.348 ±0.054 |
| maze | 2.312 ±0.033 | 1.909 ±0.045 | 0.755 ±0.005 | 2.232 ±0.011 |
| vm | 3.032 ±0.336 | 2.199 ±0.061 | 0.903 ±0.015 | 2.955 ±0.024 |
| life | 7.836 ±0.459 | 9.731 ±0.197 | 6.337 ±0.073 | 9.614 ±0.143 |

## Supplement: Wasm engine compilation and instantiation

| Example | Direct / V8 | C-Wasm / V8 | Direct / Wasmtime | C-Wasm / Wasmtime |
| --- | ---: | ---: | ---: | ---: |
| squares | 0.246 ±0.029 | 0.490 ±0.014 | 2.858 ±0.154 | 10.754 ±0.862 |
| tour | 0.578 ±0.067 | 0.601 ±0.039 | 32.659 ±1.149 | 32.446 ±0.933 |
| functions | 0.343 ±0.055 | 0.539 ±0.046 | 29.238 ±2.782 | 27.030 ±0.436 |
| errors | 0.301 ±0.023 | 0.570 ±0.055 | 9.209 ±0.937 | 18.137 ±1.179 |
| sieve | 0.294 ±0.032 | 0.538 ±0.021 | 6.375 ±0.461 | 12.927 ±1.536 |
| sorting | 0.390 ±0.044 | 0.652 ±0.121 | 22.727 ±6.020 | 30.307 ±1.206 |
| sudoku | 0.279 ±0.020 | 0.580 ±0.045 | 5.890 ±0.850 | 10.999 ±1.268 |
| maze | 0.309 ±0.036 | 0.595 ±0.031 | 12.842 ±1.777 | 14.008 ±0.329 |
| vm | 0.353 ±0.082 | 0.607 ±0.079 | 17.483 ±2.342 | 17.652 ±2.023 |
| life | 0.330 ±0.039 | 0.527 ±0.034 | 12.042 ±2.480 | 16.582 ±2.942 |

The entrypoint interval includes Goose initialization, host output callbacks and any lazy JIT work. It excludes final Wasm-host output concatenation/delivery. Native Goose prints unbuffered, so no native entrypoint column or cross-boundary speedup is presented. Process time minus engine time also includes loading, bookkeeping and teardown; it is not a pure startup measurement.

These fresh-process examples have different timing rules from LangArena's warmed computational regions. Raw samples, commands, artifact/source/compiler identities and engine versions are in [report.json](report.json). [Method and reproduction](../../../examples.md).
