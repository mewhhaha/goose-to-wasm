from pathlib import Path
import shutil,json,hashlib,subprocess,sys
root=Path(sys.argv[1]); metadata=json.loads(Path('build/toolchain.json').read_bytes())
for rel in ['bin/goose','source.json','toolchain.json']:
 d=root/rel;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(Path('build')/rel,d)
for rel in ['bin/stdlib','bin/include','bin/tcclib']:
 shutil.copytree(Path('build')/rel,root/rel,copy_function=shutil.copy2,dirs_exist_ok=True)
for name,expected in metadata['headers'].items():
 p=Path('compiler')/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==expected
 shutil.copy2(p,root/'compiler'/name)
for name in metadata['patches']:
 d=root/name;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(name,d)
subprocess.run([str(root/'bin/goose'),'examples/functions.goose','--target','wasm-direct','--offline','-O2','--wasm-initial-pages','16','--wasm-max-pages','256','--wasm-stats',str(root/'O2.json'),'-o',str(root/'O2.wasm')],check=True)
print('module bytes',(root/'O2.wasm').stat().st_size,'sha256',hashlib.sha256((root/'O2.wasm').read_bytes()).hexdigest())
