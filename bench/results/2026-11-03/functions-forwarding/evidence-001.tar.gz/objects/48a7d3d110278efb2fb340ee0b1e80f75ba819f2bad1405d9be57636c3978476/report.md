# LangArena qualification and measurements

Status: **passed**.

Upstream pin: `aab9b14998231ba905523b5ba3990ee03c46f64d`. Catalog: **50 tasks**. Adapted entrypoints: **7 tasks**, including six storage adaptations.

Mode: `measure`. Machine: AMD Ryzen 7 3800X, shared desktop host.
Compiler SHA-256: `19d377d68530e0cf5b59f6d28f7b1a2ca207b9ed981dfad29dedf7fa5723473b`.

## Measurement contract

Whole-suite results use all original Goose kernel sources. The only staging patch changes the marker destination from `/tmp/recompile_marker` to a relative file inside the isolated run directory. The original checkout is hash-verified and never edited. Whole-suite compile times include all 50 tasks.

The adapted track uses the same seven port sources across native C, direct Wasm, and C-Wasm. Six ports replace growable storage; Fannkuch keeps its original fixed-array kernel. Official test/run inputs and checksums are unchanged. Preparation stays outside the clock; warmups mutate the same state used for measurement; the deterministic RNG is reset before measured iterations. Existing checksum work retains its original placement.

Cold builds and marker-edit builds launch fresh driver/compiler processes with `--no-cache`. OS caches and installed compiler/system-library caches are retained. A port marker edit changes its exit status from 0 to 1 after its two output lines, and the edited executable must retain the official checksum. Whole-suite edits change the actual marker file contents. Source bytes are restored in all cases. Optional unchanged cache hits are a separate phase. Edited sources still rerun the complete frontend.

The official whole-suite timer prints milliseconds; adapted ports print integer nanoseconds. Timed regions exclude process startup and preparation. Process wall time is retained separately. Sample counts below five are preliminary estimates; raw values and MAD are provided. These are local comparisons, not LangArena leaderboard scores or claims of complete direct-backend language support.

## Whole-suite compilation

| Backend | Phase | Samples | Median ms | MAD ms | Artifact bytes |
| --- | --- | ---: | ---: | ---: | ---: |

## Original-source correctness and runtime

| Task | Backend / engine | Profile | Samples | Region median ms | MAD ms | Process median ms |
| --- | --- | --- | ---: | ---: | ---: | ---: |

## Adapted workload compilation

| Task | Backend | Phase | Samples | Median ms | MAD ms | Artifact bytes |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| CLBG::Fannkuchredux | c-wasm | cold | 5 | 680.579 | 27.270 | 51983 |
| CLBG::Fannkuchredux | direct | cold | 5 | 70.250 | 3.278 | 4067 |
| CLBG::Fannkuchredux | native | cold | 5 | 301.279 | 15.005 | 22984 |
| CLBG::Mandelbrot | c-wasm | cold | 5 | 664.115 | 14.462 | 52059 |
| CLBG::Mandelbrot | direct | cold | 5 | 67.307 | 1.561 | 4650 |
| CLBG::Mandelbrot | native | cold | 5 | 290.027 | 14.474 | 23160 |
| Etc::Sieve | c-wasm | cold | 5 | 657.156 | 5.113 | 51597 |
| Etc::Sieve | direct | cold | 5 | 66.613 | 0.185 | 3281 |
| Etc::Sieve | native | cold | 5 | 302.646 | 20.039 | 23128 |
| Hash::CRC32 | c-wasm | cold | 5 | 633.512 | 27.830 | 51817 |
| Hash::CRC32 | direct | cold | 5 | 65.784 | 0.955 | 3309 |
| Hash::CRC32 | native | cold | 5 | 250.299 | 2.016 | 23008 |
| Hash::SHA256 | c-wasm | cold | 5 | 657.446 | 9.140 | 51826 |
| Hash::SHA256 | direct | cold | 5 | 67.695 | 0.675 | 6788 |
| Hash::SHA256 | native | cold | 5 | 275.841 | 4.376 | 23008 |
| Sort::Merge | c-wasm | cold | 5 | 659.115 | 27.289 | 52484 |
| Sort::Merge | direct | cold | 5 | 66.246 | 0.082 | 5453 |
| Sort::Merge | native | cold | 5 | 309.008 | 10.813 | 27416 |
| Sort::Quick | c-wasm | cold | 5 | 631.314 | 17.068 | 52043 |
| Sort::Quick | direct | cold | 5 | 66.589 | 0.532 | 4566 |
| Sort::Quick | native | cold | 5 | 278.990 | 12.193 | 23168 |

## Adapted workload runtime

| Task | Backend / engine | Profile | Samples | Region median ms | MAD ms | Engine compile + instantiate ms | Process median ms | Checksum |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| CLBG::Fannkuchredux | c-wasm / v8 | run | 5 | 2117.364 | 11.089 | 0.615 | 2568.028 | 135762480 |
| CLBG::Fannkuchredux | c-wasm / v8 | test | 1 | 0.039 | 0.000 | 0.756 | 57.277 | 4428 |
| CLBG::Fannkuchredux | c-wasm / wasmtime | run | 5 | 1461.964 | 9.615 | 23.440 | 1869.049 | 135762480 |
| CLBG::Fannkuchredux | c-wasm / wasmtime | test | 1 | 0.052 | 0.000 | 39.492 | 119.381 | 4428 |
| CLBG::Fannkuchredux | direct / v8 | run | 5 | 1238.373 | 8.273 | 0.321 | 1518.521 | 135762480 |
| CLBG::Fannkuchredux | direct / v8 | test | 1 | 0.055 | 0.000 | 0.360 | 46.350 | 4428 |
| CLBG::Fannkuchredux | direct / wasmtime | run | 5 | 1354.396 | 11.577 | 4.392 | 1706.175 | 135762480 |
| CLBG::Fannkuchredux | direct / wasmtime | test | 1 | 0.023 | 0.000 | 3.966 | 82.258 | 4428 |
| CLBG::Fannkuchredux | native / native | run | 5 | 1311.180 | 9.052 | — | 1555.901 | 135762480 |
| CLBG::Fannkuchredux | native / native | test | 1 | 0.021 | 0.000 | — | 1.200 | 4428 |
| CLBG::Mandelbrot | c-wasm / v8 | run | 5 | 962.654 | 0.739 | 0.585 | 1198.461 | 3455988829 |
| CLBG::Mandelbrot | c-wasm / v8 | test | 1 | 0.333 | 0.000 | 0.515 | 29.681 | 2236342953 |
| CLBG::Mandelbrot | c-wasm / wasmtime | run | 5 | 1062.609 | 7.888 | 23.629 | 1388.106 | 3455988829 |
| CLBG::Mandelbrot | c-wasm / wasmtime | test | 1 | 0.219 | 0.000 | 36.184 | 119.901 | 2236342953 |
| CLBG::Mandelbrot | direct / v8 | run | 5 | 954.508 | 4.138 | 0.261 | 1192.038 | 3455988829 |
| CLBG::Mandelbrot | direct / v8 | test | 1 | 0.360 | 0.000 | 0.264 | 30.605 | 2236342953 |
| CLBG::Mandelbrot | direct / wasmtime | run | 5 | 1003.260 | 1.611 | 3.750 | 1294.311 | 3455988829 |
| CLBG::Mandelbrot | direct / wasmtime | test | 1 | 0.185 | 0.000 | 4.314 | 84.297 | 2236342953 |
| CLBG::Mandelbrot | native / native | run | 5 | 930.533 | 4.700 | — | 1127.143 | 3455988829 |
| CLBG::Mandelbrot | native / native | test | 1 | 0.152 | 0.000 | — | 4.281 | 2236342953 |
| Etc::Sieve | c-wasm / v8 | run | 5 | 6825.516 | 168.010 | 0.622 | 8119.307 | 1042248060 |
| Etc::Sieve | c-wasm / v8 | test | 1 | 0.019 | 0.000 | 0.634 | 29.863 | 4660 |
| Etc::Sieve | c-wasm / wasmtime | run | 5 | 5317.874 | 24.415 | 27.070 | 6489.305 | 1042248060 |
| Etc::Sieve | c-wasm / wasmtime | test | 1 | 0.047 | 0.000 | 24.583 | 106.542 | 4660 |
| Etc::Sieve | direct / v8 | run | 5 | 1330.499 | 9.251 | 0.235 | 1648.448 | 1042248060 |
| Etc::Sieve | direct / v8 | test | 1 | 0.015 | 0.000 | 0.269 | 27.023 | 4660 |
| Etc::Sieve | direct / wasmtime | run | 5 | 1365.225 | 4.659 | 3.376 | 1725.312 | 1042248060 |
| Etc::Sieve | direct / wasmtime | test | 1 | 0.022 | 0.000 | 3.332 | 83.858 | 4660 |
| Etc::Sieve | native / native | run | 5 | 856.169 | 3.543 | — | 1029.081 | 1042248060 |
| Etc::Sieve | native / native | test | 1 | 0.003 | 0.000 | — | 2.789 | 4660 |
| Hash::CRC32 | c-wasm / v8 | run | 5 | 449.579 | 0.711 | 0.580 | 578.494 | 2318723244 |
| Hash::CRC32 | c-wasm / v8 | test | 1 | 0.014 | 0.000 | 0.591 | 30.129 | 3031698216 |
| Hash::CRC32 | c-wasm / wasmtime | run | 5 | 410.809 | 2.389 | 24.241 | 616.777 | 2318723244 |
| Hash::CRC32 | c-wasm / wasmtime | test | 1 | 0.051 | 0.000 | 24.492 | 105.321 | 3031698216 |
| Hash::CRC32 | direct / v8 | run | 5 | 496.365 | 1.725 | 0.260 | 639.540 | 2318723244 |
| Hash::CRC32 | direct / v8 | test | 1 | 0.017 | 0.000 | 0.271 | 28.927 | 3031698216 |
| Hash::CRC32 | direct / wasmtime | run | 5 | 432.961 | 1.788 | 3.726 | 612.263 | 2318723244 |
| Hash::CRC32 | direct / wasmtime | test | 1 | 0.025 | 0.000 | 3.446 | 83.091 | 3031698216 |
| Hash::CRC32 | native / native | run | 5 | 1359.247 | 1.190 | — | 1635.390 | 2318723244 |
| Hash::CRC32 | native / native | test | 1 | 0.028 | 0.000 | — | 1.515 | 3031698216 |
| Hash::SHA256 | c-wasm / v8 | run | 5 | 1043.077 | 7.974 | 0.601 | 1297.825 | 2844672256 |
| Hash::SHA256 | c-wasm / v8 | test | 1 | 0.014 | 0.000 | 0.840 | 33.544 | 1036619072 |
| Hash::SHA256 | c-wasm / wasmtime | run | 5 | 953.946 | 16.050 | 37.843 | 1273.058 | 2844672256 |
| Hash::SHA256 | c-wasm / wasmtime | test | 1 | 0.044 | 0.000 | 40.927 | 121.730 | 1036619072 |
| Hash::SHA256 | direct / v8 | run | 5 | 256.632 | 1.727 | 0.271 | 351.484 | 2844672256 |
| Hash::SHA256 | direct / v8 | test | 1 | 0.005 | 0.000 | 0.419 | 31.639 | 1036619072 |
| Hash::SHA256 | direct / wasmtime | run | 5 | 326.688 | 2.517 | 5.244 | 484.195 | 2844672256 |
| Hash::SHA256 | direct / wasmtime | test | 1 | 0.017 | 0.000 | 5.233 | 112.771 | 1036619072 |
| Hash::SHA256 | native / native | run | 5 | 583.540 | 2.958 | — | 707.814 | 2844672256 |
| Hash::SHA256 | native / native | test | 1 | 0.002 | 0.000 | — | 1.478 | 1036619072 |
| Sort::Merge | c-wasm / v8 | run | 5 | 1297.928 | 7.313 | 0.590 | 1594.253 | 61757772 |
| Sort::Merge | c-wasm / v8 | test | 1 | 11.848 | 0.000 | 0.568 | 52.026 | 2548773 |
| Sort::Merge | c-wasm / wasmtime | run | 5 | 2675.951 | 22.366 | 28.617 | 3328.227 | 61757772 |
| Sort::Merge | c-wasm / wasmtime | test | 1 | 24.040 | 0.000 | 24.216 | 142.911 | 2548773 |
| Sort::Merge | direct / v8 | run | 5 | 1867.042 | 2.039 | 0.271 | 2281.784 | 61757772 |
| Sort::Merge | direct / v8 | test | 1 | 17.255 | 0.000 | 0.258 | 57.873 | 2548773 |
| Sort::Merge | direct / wasmtime | run | 5 | 2016.418 | 93.834 | 4.172 | 2474.703 | 61757772 |
| Sort::Merge | direct / wasmtime | test | 1 | 17.446 | 0.000 | 3.782 | 113.032 | 2548773 |
| Sort::Merge | native / native | run | 5 | 1377.608 | 4.731 | — | 1661.418 | 61757772 |
| Sort::Merge | native / native | test | 1 | 13.110 | 0.000 | — | 24.275 | 2548773 |
| Sort::Quick | c-wasm / v8 | run | 5 | 1391.555 | 2.153 | 0.592 | 1712.301 | 61757772 |
| Sort::Quick | c-wasm / v8 | test | 1 | 13.320 | 0.000 | 0.632 | 51.514 | 2548773 |
| Sort::Quick | c-wasm / wasmtime | run | 5 | 1620.117 | 6.489 | 23.102 | 2051.945 | 61757772 |
| Sort::Quick | c-wasm / wasmtime | test | 1 | 15.485 | 0.000 | 34.843 | 141.291 | 2548773 |
| Sort::Quick | direct / v8 | run | 5 | 1339.606 | 9.765 | 0.270 | 1643.811 | 61757772 |
| Sort::Quick | direct / v8 | test | 1 | 22.231 | 0.000 | 0.355 | 85.606 | 2548773 |
| Sort::Quick | direct / wasmtime | run | 5 | 1726.804 | 10.934 | 3.690 | 2131.913 | 61757772 |
| Sort::Quick | direct / wasmtime | test | 1 | 14.889 | 0.000 | 4.301 | 105.727 | 2548773 |
| Sort::Quick | native / native | run | 5 | 1180.251 | 1.749 | — | 1425.743 | 61757772 |
| Sort::Quick | native / native | test | 1 | 12.096 | 0.000 | — | 20.573 | 2548773 |

## Qualification and limits

- Seven adapted entrypoints (six change storage, one changes only the harness) are a subset of the 50-task catalog; they do not establish unmodified whole-suite Wasm support.
- No local result is a LangArena leaderboard rank: source/compiler versions, target layout, host, flags, and coverage differ.
- Cold builds retain OS and compiler system-library caches; they are complete uncached driver builds, not disk-cold experiments.

The full 50-task coverage matrix, raw commands/output, source and artifact hashes, tool versions, input values, environment overrides (including `EM_NODE_JS`), and phase timings are in `report.json` and adjacent logs. `Hash::SHA256` retains LangArena's custom hash workload; it is not standard cryptographic SHA-256.
