#!/usr/bin/env python3
"""Pair named frozen compilers on the ten unchanged warmed kernel workloads.

All guest emission, AOT preparation and test checks precede measured rounds.
References are the immutable production pilot choices; this run never selects.
"""
from pathlib import Path
import argparse
import hashlib
import itertools
import json
import math
import os
import platform
import random
import re
import sys

ROOT = Path(__file__).resolve().parents[2]
CAMPAIGN = ROOT / "build/full-hills"
BASELINE = CAMPAIGN / "baseline"
REFERENCE = ROOT / "build/runtime-reference/production/report.json"
REFERENCE_SHA = "06c1f5b883af43d5f5563416fec01d5a1ff5ec309a5005e3abb5293654e59350"
HOST = BASELINE / "bin/goose-wasmtime"
HOST_SHA = "e0468623661130c89eec4902c287c1ec971928b75469a47303c3392733c51cd3"
LIBRARY_SHA = "3127ca42fe7cdd3f0a43a358e79177dcfedd46c1746329826403b9d854de6178"
CPU = 2
sys.path.insert(0, str(ROOT / "bench"))
import langarena as arena


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def load(path):
    return json.loads(Path(path).read_text())


class Measurement:
    def __init__(self, args):
        self.args = args
        self.out = args.output.resolve()
        require(not (self.out / "report.json").exists(), "refusing to replace an existing report")
        self.out.mkdir(parents=True, exist_ok=True)
        self.pins = {}
        self.resolved = {}
        self.snapshots = {}
        self.compilers = {}
        for value in args.compiler:
            name, separator, path = value.partition("=")
            require(separator and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]*", name), "use --compiler NAME=PATH")
            require(name not in self.compilers and not name.startswith("ref--"), "duplicate/reserved compiler name: " + name)
            self.compilers[name] = Path(path).absolute()
        self.roots = [path.parent.parent for path in self.compilers.values()] + [BASELINE]
        self.base = load(args.reference)
        require(digest(args.reference) == REFERENCE_SHA, "reference report differs from the frozen production report")
        require(self.base["status"] == "passed" and not self.base["failures"], "reference failed")
        require(len(self.base["workloads"]) == 10 and len(self.base["variants"]) == 14, "reference matrix changed")
        require(self.base["configuration"]["engines"] == ["wasmtime"] and
                self.base["configuration"]["wasmtime_mode"] == "precompiled", "reference engine mode changed")
        self.workloads = [case for case in self.base["workloads"] if not args.filter or
                          any(text.lower() in case["name"].lower() for text in args.filter)]
        require(self.workloads, "no workloads match --filter")
        self.report = {"schema": "goose-frozen-kernel-pairs-v1", "status": "running",
            "started_utc": arena.utc_now(), "configuration": {
                "samples": args.samples, "seed": args.seed, "cpu": CPU,
                "compilers": {name: str(path) for name, path in self.compilers.items()},
                "filter": args.filter, "references": args.references, "reference": str(args.reference.absolute()),
                "host": str(HOST), "timeout": args.timeout},
            "method": "Fixed source and runtime inputs. All builds/AOT and test checks precede shuffled paired rounds. "
                      "Internal warmed intervals are authoritative; process/build/preparation times are separate. "
                      "References were selected in the frozen prior pilot, never in these measured rounds. "
                      "Median/MAD and paired ratios are empirical observations, not bounds or universal ceilings.",
            "workloads": self.workloads, "selection": self.base["selection"], "compilers": {},
            "artifacts": {}, "reference_roles": {}, "artifact_comparisons": [], "commands": [],
            "observations": [], "phases": [], "input_sha256": self.pins,
            "historical_input_resolution": self.resolved, "source_snapshots": self.snapshots}

    def save(self):
        temporary = self.out / "report.tmp"
        temporary.write_text(json.dumps(self.report, indent=2) + "\n")
        temporary.replace(self.out / "report.json")

    def snapshot(self, path):
        path = Path(path).absolute()
        value = digest(path)
        destination = self.out / "frozen-inputs" / (value + "-" + path.name)
        destination.parent.mkdir(exist_ok=True)
        if not destination.exists():
            destination.write_bytes(path.read_bytes())
        require(digest(destination) == value, "snapshot differs: " + str(path))
        self.pins[str(destination)] = value
        self.snapshots[str(path) + "@" + value] = str(destination)

    def pin(self, path, expected=None, snapshot=False):
        path = Path(path).absolute()
        value = digest(path)
        require(expected is None or value == expected, "SHA256 mismatch: " + str(path))
        require(str(path) not in self.pins or self.pins[str(path)] == value, "input changed: " + str(path))
        self.pins[str(path)] = value
        if snapshot:
            self.snapshot(path)
        return path

    def historical(self, original, expected):
        original = Path(original).absolute()
        candidates = []
        if original.is_relative_to(ROOT):
            relative = original.relative_to(ROOT)
            candidates.append(BASELINE / "source" / relative)
            if relative.parts[:2] == ("build", "bin"):
                candidates.append(BASELINE / "bin" / Path(*relative.parts[2:]))
        candidates.append(original)
        # Frozen compiler installations may retain a historical file at a new root.
        for root in self.roots:
            for marker in ("compiler", "bin"):
                if marker in original.parts:
                    index = len(original.parts) - 1 - list(reversed(original.parts)).index(marker)
                    candidates.append(root / Path(*original.parts[index:]))
        for path in dict.fromkeys(candidates):
            if path.is_file() and digest(path) == expected:
                self.resolved[str(original) + "@" + expected] = str(path)
                return self.pin(path, expected)
        raise RuntimeError("historical bytes unavailable: " + str(original) + "@" + expected)

    def verify(self):
        for path, expected in self.pins.items():
            require(digest(path) == expected, "pinned input changed: " + path)
        for key, expected in self.report["environment"]["host_controls"].items():
            require(os.environ.get(key) == expected, "host control changed: " + key)
        require(CPU in os.sched_getaffinity(0), "CPU2 no longer allowed")

    def phase(self, name, boundary):
        self.report["phases"].append({"name": name, "boundary": boundary, "utc": arena.utc_now(),
            "load_average": list(os.getloadavg()), "parent_affinity": sorted(os.sched_getaffinity(0)),
            "runtime_affinity": [CPU]})
        self.save()

    def prepare_inputs(self):
        # Snapshots and provenance are saved before even the first external command.
        for path in [Path(__file__), self.args.reference, ROOT / "bench/langarena.py"]:
            self.pin(path, snapshot=True)
        for path, expected in self.base["inputs"].items():
            self.historical(path, expected)
        self.pin(HOST, HOST_SHA)
        host_metadata = self.pin(HOST.with_suffix(".json"), snapshot=True)
        host = load(host_metadata)
        require(host["host_sha256"] == HOST_SHA and host["library_sha256"] == LIBRARY_SHA, "host/engine identity changed")
        self.pin(host["library"], LIBRARY_SHA)
        for path, expected in host["input_sha256"].items():
            self.historical(path, expected)
        self.report["host_build"] = host
        self.taskset = self.pin(self.base["tools"]["taskset"])
        self.pin(Path(sys.executable).resolve())
        control_keys = ["LD_PRELOAD", "LD_LIBRARY_PATH", "RAYON_NUM_THREADS", "OMP_NUM_THREADS",
                        "WASMTIME_BACKTRACE_DETAILS", "GOOSE_STDLIB"]
        controls = {key: os.environ.get(key) for key in control_keys}
        reference_controls = self.base["environment"]["host_controls"]
        require(all(value == reference_controls.get(key) for key, value in controls.items()),
                "runtime host controls differ from frozen reference")
        require(CPU in os.sched_getaffinity(0), "CPU2 is outside allowed affinity")
        self.report["environment"] = {"python": sys.version, "platform": platform.platform(),
            "parent_affinity": sorted(os.sched_getaffinity(0)), "runtime_affinity": [CPU],
            "host_controls": controls, "process_path": os.environ.get("PATH"),
            "reference_environment": self.base["environment"]}
        for name, compiler in self.compilers.items():
            self.pin(compiler)
            root = compiler.parent.parent
            metadata = self.pin(root / "source.json", snapshot=True)
            source = load(metadata)
            toolchain_path = self.pin(root / "toolchain.json", snapshot=True)
            toolchain = load(toolchain_path)
            require(toolchain["compiler_sha256"] == digest(compiler), "compiler differs from frozen toolchain: " + name)
            for category in ["headers", "patches"]:
                require(toolchain[category] == source[category], "source/toolchain metadata differs: " + name)
            resolved = {}
            for category, directory in [("headers", "compiler"), ("patches", "")]:
                for relative, expected in source.get(category, {}).items():
                    candidates = [root / directory / relative, root / "source" / directory / relative,
                                  ROOT / directory / relative]
                    matches = [path for path in candidates if path.is_file() and digest(path) == expected]
                    require(matches, "frozen compiler " + name + " missing " + category + ": " + relative)
                    resolved[category + "/" + relative] = str(self.pin(matches[0], expected, snapshot=True))
            for directory, pattern in [(compiler.parent / "stdlib", "*.goose"), (compiler.parent / "include", "*.h")]:
                require(directory.is_dir(), "missing installed compiler dependency: " + str(directory))
                for path in directory.rglob(pattern):
                    self.pin(path, snapshot=True)
            self.report["compilers"][name] = {"binary": str(compiler), "sha256": digest(compiler),
                "source": source, "source_metadata": str(metadata), "resolved_source_inputs": resolved}
        for case in self.workloads:
            source = Path(case["source"])
            require(str(source) in self.base["inputs"], "workload source lacks frozen pin")
            # Compile the original unchanged path so relative imports retain their meaning.
            self.pin(source, self.base["inputs"][str(source)], snapshot=True)
            for path in source.parent.glob("*.goose"):
                require(str(path) in self.base["inputs"], "unrecorded adjacent Goose source: " + str(path))
                self.pin(path, self.base["inputs"][str(path)], snapshot=True)
            for path in case["source_files"]:
                checked = self.historical(path, self.base["inputs"][path])
                self.snapshot(checked)
        self.verify()
        self.save()

    def run(self, command, directory, stdin=""):
        result = arena.execute(command, self.out / directory, cwd=ROOT, stdin=stdin, timeout=self.args.timeout)
        self.report["commands"].append({key: result[key] for key in
            ["command", "cwd", "returncode", "wall_seconds", "error"]} | {"log_directory": str(self.out / directory)})
        self.save()
        require(result["returncode"] == 0 and not result["error"], "command failed: " + str(command) + " " + result["stderr"])
        return result

    def reference_artifact(self, case, variant):
        original = self.base["artifacts"][case["id"] + "/" + variant]
        artifact = dict(original)
        artifact["path"] = str(self.historical(original["path"], original["sha256"]))
        if artifact["family"] != "native":
            artifact["aot_path"] = str(self.historical(original["aot_path"], original["aot_sha256"]))
        return artifact

    def build(self):
        self.phase("build", "start")
        version = self.run([HOST, "--version"], "metadata/host-version")
        require(version["stdout"] == "Wasmtime " + self.report["host_build"]["version"] + "\n",
                "host version differs from its frozen metadata")
        for case in self.workloads:
            artifacts = {}
            self.report["artifacts"][case["name"]] = artifacts
            for name, compiler in self.compilers.items():
                directory = self.out / "build" / case["id"] / name
                directory.mkdir(parents=True, exist_ok=True)
                wasm = directory / "program.wasm"
                aot = directory / "program.cwasm"
                stats = directory / "stats.json"
                result = self.run([compiler, case["source"], "--target", "wasm-direct", "--offline", "-O2",
                    "--wasm-initial-pages", str(self.base["configuration"]["initial_pages"]),
                    "--wasm-max-pages", str(self.base["configuration"]["maximum_pages"]),
                    "--wasm-stats", stats, "-o", wasm], "build-logs/" + case["id"] + "/" + name + "/emit")
                self.pin(wasm)
                self.pin(stats)
                prepared = self.run([HOST, "--compile", wasm, aot], "build-logs/" + case["id"] + "/" + name + "/prepare")
                self.pin(aot)
                artifacts[name] = {"variant": name, "family": "direct", "path": str(wasm),
                    "sha256": digest(wasm), "bytes": wasm.stat().st_size, "aot_path": str(aot),
                    "aot_sha256": digest(aot), "compiler_sha256": digest(compiler),
                    "stats_path": str(stats), "stats_sha256": digest(stats),
                    "artifact_build_wall_seconds": result["wall_seconds"], "preparation_wall_seconds": prepared["wall_seconds"]}
            roles = {}
            if self.args.references:
                selection = self.base["selection"][case["name"]]
                choices = {"original_direct": "direct-O2", "gcc_O2_anchor": "native-gcc-O2-generic",
                    "selected_native": selection["native"]["variant"],
                    "selected_wasm": selection["wasm"]["wasmtime"]["variant"]}
                for role, variant in choices.items():
                    label = "ref--" + variant
                    roles[role] = label
                    if label not in artifacts:
                        artifacts[label] = self.reference_artifact(case, variant)
            self.report["reference_roles"][case["name"]] = roles
            control = self.reference_artifact(case, "direct-O2")
            compared = {name: artifact for name, artifact in artifacts.items() if artifact["family"] != "native"}
            compared["production-direct-control"] = control
            for left, right in itertools.combinations(compared, 2):
                self.report["artifact_comparisons"].append({"task": case["name"], "left": left, "right": right,
                    "left_sha256": compared[left]["sha256"], "right_sha256": compared[right]["sha256"],
                    "byte_identical": compared[left]["sha256"] == compared[right]["sha256"]})
            self.save()
        self.verify()
        self.phase("build", "end")

    def execute(self, case, variant, phase, round_):
        artifact = self.report["artifacts"][case["name"]][variant]
        command = [artifact["path"]]
        engine = "native"
        if artifact["family"] != "native":
            command = [HOST, "--precompiled", artifact["aot_path"]]
            engine = "wasmtime"
        command = [self.taskset, "-c", str(CPU), *command]
        profile = "run"
        if phase == "qualify":
            profile = "test"
        config = case[profile]
        directory = f"runtime/{phase}/{round_:02}/{case['id']}/{variant}"
        result = self.run(command, directory, config["stdin"])
        require(not result["stderr"], "runtime stderr: " + result["stderr"])
        data = arena.parse_port_result(result["stdout"], result["returncode"], config["checksum"])
        require(math.isfinite(data["timed_region_seconds"]) and
                0 < data["timed_region_seconds"] <= result["wall_seconds"], "invalid internal interval")
        self.report["observations"].append({"task": case["name"], "variant": variant, "engine": engine,
            "phase": phase, "round": round_, "profile": profile, "runtime_affinity": [CPU],
            "artifact_sha256": artifact["sha256"], "aot_sha256": artifact.get("aot_sha256"),
            "log_directory": str(self.out / directory), "process_wall_seconds": result["wall_seconds"], **data})
        self.save()

    def collect(self):
        rng = random.Random(self.args.seed)
        for phase, rounds in [("qualify", 1), ("measure", self.args.samples)]:
            self.verify()
            self.phase(phase, "start")
            for round_ in range(rounds):
                cases = list(self.workloads)
                rng.shuffle(cases)
                for case in cases:
                    variants = list(self.report["artifacts"][case["name"]])
                    rng.shuffle(variants)
                    for variant in variants:
                        self.execute(case, variant, phase, round_)
                print(phase, "round", round_ + 1, "complete", flush=True)
            self.verify()
            self.phase(phase, "end")

    def summarize(self):
        actual = [(row["phase"], row["round"], row["task"], row["variant"]) for row in self.report["observations"]]
        expected = {(phase, round_, case["name"], variant)
            for phase, rounds in [("qualify", 1), ("measure", self.args.samples)] for round_ in range(rounds)
            for case in self.workloads for variant in self.report["artifacts"][case["name"]]}
        require(len(actual) == len(set(actual)) and set(actual) == expected, "sample coverage differs")
        indexed = {(row["task"], row["variant"], row["round"]): row["timed_region_seconds"]
            for row in self.report["observations"] if row["phase"] == "measure"}
        summaries = []
        for case in self.workloads:
            task = case["name"]
            variants = list(self.report["artifacts"][task])
            times = {variant: arena.summarize([indexed[task, variant, i] for i in range(self.args.samples)]) for variant in variants}
            pairs = []
            for numerator, denominator in itertools.combinations(variants, 2):
                values = [indexed[task, numerator, i] / indexed[task, denominator, i] for i in range(self.args.samples)]
                pairs.append({"numerator": numerator, "denominator": denominator,
                    "per_round": [{"round": i, "ratio": value} for i, value in enumerate(values)], "ratio": arena.summarize(values)})
            summaries.append({"task": task, "times": times, "paired_ratios": pairs,
                "reference_roles": self.report["reference_roles"][task]})
        geometric = []
        comparisons = [(left, right, "compiler") for left, right in itertools.combinations(self.compilers, 2)]
        if self.args.references:
            comparisons += [(name, role, "reference_role") for name in self.compilers
                for role in ["original_direct", "gcc_O2_anchor", "selected_native", "selected_wasm"]]
        for numerator, denominator, kind in comparisons:
            values = []
            for round_ in range(self.args.samples):
                ratios = []
                for case in self.workloads:
                    task = case["name"]
                    target = denominator
                    if kind == "reference_role":
                        target = self.report["reference_roles"][task][denominator]
                    ratios.append(indexed[task, numerator, round_] / indexed[task, target, round_])
                values.append(math.exp(sum(math.log(value) for value in ratios) / len(ratios)))
            geometric.append({"numerator": numerator, "denominator": denominator, "kind": kind,
                "tasks": [case["name"] for case in self.workloads],
                "per_round": [{"round": i, "ratio": value} for i, value in enumerate(values)],
                "ratio": arena.summarize(values)})
        self.report.update(summary=summaries, geometric_ratios=geometric,
                           coverage_exact=True, observations_expected=len(expected))

    def main(self):
        try:
            self.prepare_inputs()
            self.build()
            self.collect()
            self.summarize()
            self.verify()
            self.report["input_sha256_after"] = {path: digest(path) for path in self.pins}
            self.report["status"] = "passed"
            self.report["failures"] = 0
        except BaseException as error:
            self.report.update(status="failed", failures=1, error=type(error).__name__ + ": " + str(error))
            raise
        finally:
            self.report["finished_utc"] = arena.utc_now()
            self.save()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--compiler", action="append", required=True, help="NAME=PATH; repeat for each frozen compiler")
    parser.add_argument("--filter", action="append", default=[], help="case-name substring; repeated filters are ORed")
    parser.add_argument("--samples", type=int, default=9)
    parser.add_argument("--references", action="store_true", help="also measure frozen native/Wasm choices, GCC-O2 and original direct")
    parser.add_argument("--reference", type=Path, default=REFERENCE)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--seed", type=int, default=774159)
    parser.add_argument("--timeout", type=int, default=600)
    args = parser.parse_args()
    if args.samples < 1 or args.timeout < 1:
        parser.error("--samples and --timeout must be positive")
    Measurement(args).main()


if __name__ == "__main__":
    main()
