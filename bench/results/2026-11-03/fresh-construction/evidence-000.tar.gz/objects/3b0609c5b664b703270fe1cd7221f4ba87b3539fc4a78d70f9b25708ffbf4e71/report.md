# LangArena qualification and measurements

Status: **passed**.

Upstream pin: `aab9b14998231ba905523b5ba3990ee03c46f64d`. Catalog: **50 tasks**. Adapted entrypoints: **7 tasks**, including six storage adaptations.

Mode: `measure`. Machine: AMD Ryzen 7 3800X, shared desktop host.
Compiler SHA-256: `a8c5ba4b4838eea0ae747d495394e6fe77dbdc34e476e8d0cadcb7f225c78352`.

## Measurement contract

Whole-suite results use all original Goose kernel sources. The only staging patch changes the marker destination from `/tmp/recompile_marker` to a relative file inside the isolated run directory. The original checkout is hash-verified and never edited. Whole-suite compile times include all 50 tasks.

The adapted track uses the same seven port sources across native C, direct Wasm, and C-Wasm. Six ports replace growable storage; Fannkuch keeps its original fixed-array kernel. Official test/run inputs and checksums are unchanged. Preparation stays outside the clock; warmups mutate the same state used for measurement; the deterministic RNG is reset before measured iterations. Existing checksum work retains its original placement.

Cold builds and marker-edit builds launch fresh driver/compiler processes with `--no-cache`. OS caches and installed compiler/system-library caches are retained. A port marker edit changes its exit status from 0 to 1 after its two output lines, and the edited executable must retain the official checksum. Whole-suite edits change the actual marker file contents. Source bytes are restored in all cases. Optional unchanged cache hits are a separate phase. Edited sources still rerun the complete frontend.

The official whole-suite timer prints milliseconds; adapted ports print integer nanoseconds. Timed regions exclude process startup and preparation. Process wall time is retained separately. Sample counts below five are preliminary estimates; raw values and MAD are provided. These are local comparisons, not LangArena leaderboard scores or claims of complete direct-backend language support.

## Whole-suite compilation

| Backend | Phase | Samples | Median ms | MAD ms | Artifact bytes |
| --- | --- | ---: | ---: | ---: | ---: |

## Original-source correctness and runtime

| Task | Backend / engine | Profile | Samples | Region median ms | MAD ms | Process median ms |
| --- | --- | --- | ---: | ---: | ---: | ---: |

## Adapted workload compilation

| Task | Backend | Phase | Samples | Median ms | MAD ms | Artifact bytes |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| CLBG::Fannkuchredux | c-wasm | cold | 5 | 676.056 | 13.633 | 51983 |
| CLBG::Fannkuchredux | direct | cold | 5 | 68.963 | 0.310 | 3917 |
| CLBG::Fannkuchredux | native | cold | 5 | 291.634 | 0.574 | 22984 |
| CLBG::Mandelbrot | c-wasm | cold | 5 | 616.400 | 10.513 | 52059 |
| CLBG::Mandelbrot | direct | cold | 5 | 71.379 | 2.952 | 4467 |
| CLBG::Mandelbrot | native | cold | 5 | 295.596 | 10.505 | 23160 |
| Etc::Sieve | c-wasm | cold | 5 | 648.347 | 21.825 | 51597 |
| Etc::Sieve | direct | cold | 5 | 69.713 | 0.438 | 3098 |
| Etc::Sieve | native | cold | 5 | 294.074 | 7.621 | 23128 |
| Hash::CRC32 | c-wasm | cold | 5 | 626.162 | 28.872 | 51817 |
| Hash::CRC32 | direct | cold | 5 | 68.629 | 0.717 | 3132 |
| Hash::CRC32 | native | cold | 5 | 258.480 | 4.327 | 23008 |
| Hash::SHA256 | c-wasm | cold | 5 | 658.685 | 8.913 | 51826 |
| Hash::SHA256 | direct | cold | 5 | 74.523 | 4.898 | 6611 |
| Hash::SHA256 | native | cold | 5 | 297.593 | 16.340 | 23008 |
| Sort::Merge | c-wasm | cold | 5 | 670.459 | 13.884 | 52484 |
| Sort::Merge | direct | cold | 5 | 69.272 | 0.479 | 5214 |
| Sort::Merge | native | cold | 5 | 295.679 | 4.030 | 27416 |
| Sort::Quick | c-wasm | cold | 5 | 638.636 | 23.696 | 52043 |
| Sort::Quick | direct | cold | 5 | 68.677 | 0.770 | 4356 |
| Sort::Quick | native | cold | 5 | 314.874 | 12.998 | 23168 |

## Adapted workload runtime

| Task | Backend / engine | Profile | Samples | Region median ms | MAD ms | Engine compile + instantiate ms | Process median ms | Checksum |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| CLBG::Fannkuchredux | c-wasm / v8 | run | 5 | 2192.273 | 2.620 | 0.580 | 2654.498 | 135762480 |
| CLBG::Fannkuchredux | c-wasm / v8 | test | 1 | 0.020 | 0.000 | 0.605 | 30.521 | 4428 |
| CLBG::Fannkuchredux | c-wasm / wasmtime | run | 5 | 1528.520 | 25.249 | 23.963 | 1947.816 | 135762480 |
| CLBG::Fannkuchredux | c-wasm / wasmtime | test | 1 | 0.058 | 0.000 | 26.930 | 109.359 | 4428 |
| CLBG::Fannkuchredux | direct / v8 | run | 5 | 1278.014 | 19.705 | 0.245 | 1565.659 | 135762480 |
| CLBG::Fannkuchredux | direct / v8 | test | 1 | 0.054 | 0.000 | 0.392 | 45.231 | 4428 |
| CLBG::Fannkuchredux | direct / wasmtime | run | 5 | 1374.466 | 5.075 | 4.268 | 1731.236 | 135762480 |
| CLBG::Fannkuchredux | direct / wasmtime | test | 1 | 0.025 | 0.000 | 4.276 | 85.210 | 4428 |
| CLBG::Fannkuchredux | native / native | run | 5 | 1353.695 | 1.079 | — | 1607.512 | 135762480 |
| CLBG::Fannkuchredux | native / native | test | 1 | 0.022 | 0.000 | — | 1.219 | 4428 |
| CLBG::Mandelbrot | c-wasm / v8 | run | 5 | 964.501 | 6.678 | 0.557 | 1201.306 | 3455988829 |
| CLBG::Mandelbrot | c-wasm / v8 | test | 1 | 0.341 | 0.000 | 0.733 | 36.604 | 2236342953 |
| CLBG::Mandelbrot | c-wasm / wasmtime | run | 5 | 1078.145 | 1.207 | 27.053 | 1414.050 | 3455988829 |
| CLBG::Mandelbrot | c-wasm / wasmtime | test | 1 | 0.227 | 0.000 | 23.963 | 133.140 | 2236342953 |
| CLBG::Mandelbrot | direct / v8 | run | 5 | 977.451 | 3.452 | 0.212 | 1216.971 | 3455988829 |
| CLBG::Mandelbrot | direct / v8 | test | 1 | 0.387 | 0.000 | 0.342 | 30.765 | 2236342953 |
| CLBG::Mandelbrot | direct / wasmtime | run | 5 | 1033.074 | 5.033 | 3.767 | 1328.357 | 3455988829 |
| CLBG::Mandelbrot | direct / wasmtime | test | 1 | 0.192 | 0.000 | 4.224 | 86.713 | 2236342953 |
| CLBG::Mandelbrot | native / native | run | 5 | 943.414 | 3.283 | — | 1135.662 | 3455988829 |
| CLBG::Mandelbrot | native / native | test | 1 | 0.157 | 0.000 | — | 2.266 | 2236342953 |
| Etc::Sieve | c-wasm / v8 | run | 5 | 7143.851 | 684.284 | 0.587 | 8355.091 | 1042248060 |
| Etc::Sieve | c-wasm / v8 | test | 1 | 0.030 | 0.000 | 0.692 | 41.693 | 4660 |
| Etc::Sieve | c-wasm / wasmtime | run | 5 | 5492.619 | 2.860 | 24.045 | 6694.325 | 1042248060 |
| Etc::Sieve | c-wasm / wasmtime | test | 1 | 0.049 | 0.000 | 22.883 | 108.292 | 4660 |
| Etc::Sieve | direct / v8 | run | 5 | 1363.960 | 22.142 | 0.217 | 1693.315 | 1042248060 |
| Etc::Sieve | direct / v8 | test | 1 | 0.022 | 0.000 | 0.221 | 24.825 | 4660 |
| Etc::Sieve | direct / wasmtime | run | 5 | 1397.266 | 13.182 | 3.533 | 1761.115 | 1042248060 |
| Etc::Sieve | direct / wasmtime | test | 1 | 0.022 | 0.000 | 3.219 | 87.031 | 4660 |
| Etc::Sieve | native / native | run | 5 | 883.861 | 19.647 | — | 1063.928 | 1042248060 |
| Etc::Sieve | native / native | test | 1 | 0.004 | 0.000 | — | 2.947 | 4660 |
| Hash::CRC32 | c-wasm / v8 | run | 5 | 463.214 | 1.327 | 0.553 | 593.121 | 2318723244 |
| Hash::CRC32 | c-wasm / v8 | test | 1 | 0.014 | 0.000 | 0.807 | 34.580 | 3031698216 |
| Hash::CRC32 | c-wasm / wasmtime | run | 5 | 417.899 | 1.731 | 24.867 | 616.485 | 2318723244 |
| Hash::CRC32 | c-wasm / wasmtime | test | 1 | 0.051 | 0.000 | 39.641 | 126.300 | 3031698216 |
| Hash::CRC32 | direct / v8 | run | 5 | 512.565 | 5.035 | 0.230 | 658.203 | 2318723244 |
| Hash::CRC32 | direct / v8 | test | 1 | 0.035 | 0.000 | 0.343 | 47.005 | 3031698216 |
| Hash::CRC32 | direct / wasmtime | run | 5 | 446.669 | 2.402 | 3.790 | 628.996 | 2318723244 |
| Hash::CRC32 | direct / wasmtime | test | 1 | 0.025 | 0.000 | 3.786 | 85.759 | 3031698216 |
| Hash::CRC32 | native / native | run | 5 | 1378.281 | 8.206 | — | 1658.786 | 2318723244 |
| Hash::CRC32 | native / native | test | 1 | 0.028 | 0.000 | — | 1.514 | 3031698216 |
| Hash::SHA256 | c-wasm / v8 | run | 5 | 1086.183 | 7.100 | 0.593 | 1349.006 | 2844672256 |
| Hash::SHA256 | c-wasm / v8 | test | 1 | 0.007 | 0.000 | 0.590 | 26.323 | 1036619072 |
| Hash::SHA256 | c-wasm / wasmtime | run | 5 | 966.750 | 1.490 | 24.503 | 1282.718 | 2844672256 |
| Hash::SHA256 | c-wasm / wasmtime | test | 1 | 0.046 | 0.000 | 23.792 | 107.042 | 1036619072 |
| Hash::SHA256 | direct / v8 | run | 5 | 267.032 | 2.407 | 0.263 | 363.744 | 2844672256 |
| Hash::SHA256 | direct / v8 | test | 1 | 0.003 | 0.000 | 0.257 | 25.484 | 1036619072 |
| Hash::SHA256 | direct / wasmtime | run | 5 | 340.311 | 5.017 | 5.248 | 505.141 | 2844672256 |
| Hash::SHA256 | direct / wasmtime | test | 1 | 0.018 | 0.000 | 5.194 | 87.551 | 1036619072 |
| Hash::SHA256 | native / native | run | 5 | 598.964 | 6.652 | — | 723.283 | 2844672256 |
| Hash::SHA256 | native / native | test | 1 | 0.002 | 0.000 | — | 1.842 | 1036619072 |
| Sort::Merge | c-wasm / v8 | run | 5 | 1334.550 | 11.692 | 0.583 | 1654.195 | 61757772 |
| Sort::Merge | c-wasm / v8 | test | 1 | 12.222 | 0.000 | 3.688 | 52.596 | 2548773 |
| Sort::Merge | c-wasm / wasmtime | run | 5 | 2762.254 | 25.694 | 25.094 | 3431.487 | 61757772 |
| Sort::Merge | c-wasm / wasmtime | test | 1 | 25.388 | 0.000 | 24.155 | 147.133 | 2548773 |
| Sort::Merge | direct / v8 | run | 5 | 1912.315 | 27.078 | 0.256 | 2339.016 | 61757772 |
| Sort::Merge | direct / v8 | test | 1 | 17.722 | 0.000 | 0.255 | 59.312 | 2548773 |
| Sort::Merge | direct / wasmtime | run | 5 | 2065.554 | 48.732 | 4.061 | 2535.316 | 61757772 |
| Sort::Merge | direct / wasmtime | test | 1 | 18.079 | 0.000 | 4.222 | 113.663 | 2548773 |
| Sort::Merge | native / native | run | 5 | 1418.328 | 2.922 | — | 1706.564 | 61757772 |
| Sort::Merge | native / native | test | 1 | 13.807 | 0.000 | — | 23.878 | 2548773 |
| Sort::Quick | c-wasm / v8 | run | 5 | 1439.138 | 7.827 | 0.575 | 1762.756 | 61757772 |
| Sort::Quick | c-wasm / v8 | test | 1 | 14.144 | 0.000 | 0.630 | 54.220 | 2548773 |
| Sort::Quick | c-wasm / wasmtime | run | 5 | 1659.308 | 16.261 | 27.077 | 2102.586 | 61757772 |
| Sort::Quick | c-wasm / wasmtime | test | 1 | 16.587 | 0.000 | 23.782 | 132.604 | 2548773 |
| Sort::Quick | direct / v8 | run | 5 | 1375.540 | 3.914 | 0.263 | 1684.671 | 61757772 |
| Sort::Quick | direct / v8 | test | 1 | 15.409 | 0.000 | 3.466 | 62.549 | 2548773 |
| Sort::Quick | direct / wasmtime | run | 5 | 1787.930 | 7.762 | 3.720 | 2198.437 | 61757772 |
| Sort::Quick | direct / wasmtime | test | 1 | 15.294 | 0.000 | 3.741 | 127.046 | 2548773 |
| Sort::Quick | native / native | run | 5 | 1239.940 | 13.392 | — | 1500.399 | 61757772 |
| Sort::Quick | native / native | test | 1 | 12.319 | 0.000 | — | 20.855 | 2548773 |

## Qualification and limits

- Seven adapted entrypoints (six change storage, one changes only the harness) are a subset of the 50-task catalog; they do not establish unmodified whole-suite Wasm support.
- No local result is a LangArena leaderboard rank: source/compiler versions, target layout, host, flags, and coverage differ.
- Cold builds retain OS and compiler system-library caches; they are complete uncached driver builds, not disk-cold experiments.

The full 50-task coverage matrix, raw commands/output, source and artifact hashes, tool versions, input values, environment overrides (including `EM_NODE_JS`), and phase timings are in `report.json` and adjacent logs. `Hash::SHA256` retains LangArena's custom hash workload; it is not standard cryptographic SHA-256.
