#!/usr/bin/env node
import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';

function digest(path) {
  return createHash('sha256').update(readFileSync(path)).digest('hex');
}

function parseArgs(argv) {
  const values = { modules: [], warmups: 50, rounds: 9, calls: 100, seed: 0 };
  for (let index = 0; index < argv.length; index++) {
    const flag = argv[index];
    const value = argv[++index];
    if (flag === '--module') values.modules.push(value);
    else if (flag === '--warmups') values.warmups = Number(value);
    else if (flag === '--rounds') values.rounds = Number(value);
    else if (flag === '--calls') values.calls = Number(value);
    else if (flag === '--seed') values.seed = Number(value);
    else throw new Error(`unknown option ${flag}`);
  }
  if (values.modules.length !== 2 || values.modules.some((item) => !/^(baseline|final)=.+$/.test(item)) ||
      !values.modules.some((item) => item.startsWith('baseline=')) ||
      !values.modules.some((item) => item.startsWith('final=')) ||
      ![values.warmups, values.rounds, values.calls].every((item) => Number.isInteger(item) && item > 0)) {
    throw new Error('requires baseline/final module paths and positive warmup, round, and call counts');
  }
  return values;
}

function rng(seed) {
  let state = seed >>> 0;
  return () => {
    state = (state + 0x6D2B79F5) >>> 0;
    let value = state;
    value = Math.imul(value ^ (value >>> 15), value | 1);
    value ^= value + Math.imul(value ^ (value >>> 7), value | 61);
    return ((value ^ (value >>> 14)) >>> 0) / 4294967296;
  };
}

function shuffle(items, random) {
  for (let index = items.length - 1; index > 0; index--) {
    const other = Math.floor(random() * (index + 1));
    [items[index], items[other]] = [items[other], items[index]];
  }
}

function instantiate(path) {
  const bytes = readFileSync(path);
  const compileStarted = process.hrtime.bigint();
  const module = new WebAssembly.Module(bytes);
  const compileNs = Number(process.hrtime.bigint() - compileStarted);
  const imports = {};
  for (const item of WebAssembly.Module.imports(module)) {
    if (item.kind !== 'function') throw new Error(`unsupported fixture import ${item.module}.${item.name}`);
    imports[item.module] ??= {};
    imports[item.module][item.name] ??= () => 0;
  }
  const instantiateStarted = process.hrtime.bigint();
  const instance = new WebAssembly.Instance(module, imports);
  const instantiateNs = Number(process.hrtime.bigint() - instantiateStarted);
  if (!(instance.exports.memory instanceof WebAssembly.Memory) ||
      typeof instance.exports._start !== 'function' || typeof instance.exports.checksum !== 'function') {
    throw new Error('fixture must export memory, _start, and checksum');
  }
  return { instance, prepare: { module_sha256: digest(path), module_bytes: bytes.length,
                                module_compile_ns: compileNs, instantiate_ns: instantiateNs,
                                memory_bytes: instance.exports.memory.buffer.byteLength } };
}

function main() {
  const args = parseArgs(process.argv.slice(2));
  const modules = Object.fromEntries(args.modules.map((item) => {
    const [name, ...rest] = item.split('=');
    return [name, rest.join('=')];
  }));
  const instances = Object.fromEntries(Object.entries(modules).map(([name, path]) => [name, instantiate(path)]));
  const random = rng(args.seed);
  const order = Object.keys(instances);
  const warmupOrder = [];
  for (let count = 0; count < args.warmups; count++) {
    shuffle(order, random);
    warmupOrder.push([...order]);
    for (const name of order) instances[name].instance.exports._start();
    for (const name of order) {
      if (instances[name].instance.exports.checksum() !== 0n) throw new Error(`${name}: checksum changed during warmup`);
    }
  }
  for (const row of Object.values(instances)) {
    row.prepare.memory_bytes_after_warmup = row.instance.exports.memory.buffer.byteLength;
  }
  const observations = [];
  const roundOrder = [];
  for (let round = 0; round < args.rounds; round++) {
    shuffle(order, random);
    roundOrder.push([...order]);
    for (const name of order) {
      const start = instances[name].instance.exports._start;
      const started = process.hrtime.bigint();
      for (let count = 0; count < args.calls; count++) start();
      const elapsed = Number(process.hrtime.bigint() - started);
      const checksum = instances[name].instance.exports.checksum();
      if (checksum !== 0n) throw new Error(`${name}: checksum was ${checksum} after round ${round}`);
      observations.push({ compiler: name, round, calls: args.calls, elapsed_ns: elapsed,
                         ns_per_call: elapsed / args.calls, checksum: checksum.toString() });
    }
  }
  for (const row of Object.values(instances)) {
    row.prepare.memory_bytes_after_measurement = row.instance.exports.memory.buffer.byteLength;
  }
  const nodeBinary = process.execPath;
  process.stdout.write(JSON.stringify({
    engine: { name: 'V8', node: process.version, v8: process.versions.v8,
             binary: nodeBinary, binary_sha256: digest(nodeBinary) },
    modules: Object.fromEntries(Object.entries(instances).map(([name, row]) => [name, row.prepare])),
    warmups: args.warmups, warmup_order: warmupOrder, rounds: args.rounds,
    calls_per_round: args.calls, seed: args.seed, round_order: roundOrder, observations,
  }));
}

try {
  main();
} catch (error) {
  process.stderr.write(`initialization V8 host: ${error.message}\n`);
  process.exitCode = 1;
}
