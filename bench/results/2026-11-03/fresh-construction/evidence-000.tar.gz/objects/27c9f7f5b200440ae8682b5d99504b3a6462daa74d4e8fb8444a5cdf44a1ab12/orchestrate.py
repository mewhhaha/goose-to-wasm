#!/usr/bin/env python3
"""Run the approved fresh-initialization qualification, never performance samples."""
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parent


def load(path):return json.loads(path.read_bytes())


def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


def require(value,message):
    if not value:raise RuntimeError(message)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--selected-root',type=Path,default=ROOT/'build/functions-init/final')
    parser.add_argument('--attempt',type=Path,default=ROOT/'build/functions-init/test-development/attempt-3')
    parser.add_argument('--jobs',type=int,default=4)
    args=parser.parse_args();selected=args.selected_root.resolve();attempt=args.attempt.resolve()
    require(shutil.which('emcc') is not None,'source build/performance-env.sh before qualification')
    metadata=load(selected/'toolchain.json');compiler_sha=metadata['compiler_sha256']
    require(sha(selected/'bin/goose')==sha(ROOT/'build/bin/goose')==compiler_sha,'selected/root compiler mismatch')
    require(load(ROOT/'build/toolchain.json')==metadata,'selected/root toolchain mismatch')
    require(all(sha(ROOT/'compiler'/name)==expected for name,expected in metadata['headers'].items()),'selected/root headers differ')
    attempt.mkdir(parents=True,exist_ok=False)
    test=ROOT/'tests/test_fresh_initialization.py'
    shutil.copyfile(test,attempt/test.name)
    record={'status':'running','compiler_sha256':compiler_sha,'focused_test_sha256':sha(test),'steps':[]}
    def step(name,command):
        print('START',name,flush=True);started=time.monotonic();log=attempt/(name+'.log')
        with log.open('w') as stream:result=subprocess.run(command,cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT)
        record['steps'].append({'name':name,'command':command,'exit_status':result.returncode,
                                'wall_seconds':time.monotonic()-started,'log':str(log)})
        if result.returncode:record['status']='failed'
        (attempt/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
        print('DONE',name,result.returncode,flush=True)
        require(result.returncode==0,'failed '+name+'; source/log retained in '+str(attempt))
    python=[sys.executable,'-B']
    step('fresh-tests',python+[str(test),'--goose',str(selected/'bin/goose'),'--reference-goose',
                               str(ROOT/'build/functions-grow/body-growth/bin/goose'),'-v'])
    require(sha(test)==record['focused_test_sha256'],'test source changed during execution')
    for control in ('resource-control','named-control'):
        script=str(HERE/(control+'.py'))
        step('prepare-'+control,python+[script,'prepare','--selected-root',str(selected)])
        step('build-'+control,python+[script,'build','--selected-root',str(selected)])
    runner=python+[str(HERE/'run.py')]
    step('seal',runner+['seal','--compiler-sha',compiler_sha,
                       '--resource-reference',str(HERE/'resource-control/build/bin/goose'),
                       '--named-reference',str(HERE/'named-control/build/bin/goose')])
    step('gates',runner+['gates','--jobs',str(args.jobs)])
    step('host',runner+['host','--jobs',str(args.jobs)])
    record['status']='passed'
    (attempt/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
    print('PASS70 focused;9573 differential;7656 native;11484 host',flush=True)


if __name__=='__main__':main()
