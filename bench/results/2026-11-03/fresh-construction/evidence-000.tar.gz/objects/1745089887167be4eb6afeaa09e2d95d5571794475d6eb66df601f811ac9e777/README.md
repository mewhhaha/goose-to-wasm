# Fresh initialization qualification preparation

Prepared only. Do not execute while a measurement window is active.

Reuse the previous runner with 70 focused commands, 978 cases, 9573 differential
observations, 7656 native stdout comparisons and 11484 host observations.
The new regression runs against the accepted353 compiler for copy/frame evidence
and observable fallback controls. Resource-free and named-tail controls must be
rebuilt from the selected32headers with exactly one predicate disabled each.

After coordinator approval: prepare/build both controls, seal the selected compiler
and all inputs, run gates, then run the host replay. Commands are recorded in
commands.json; replace SELECTED_COMPILER_SHA only after the final source freeze.
Preserve failures in separate attempt folders. No historical reports, guest trees,
archives or alias namespaces are copied by this preparation.
