export PATH="/home/jacobt/src/goose-to-wasm/.venv/bin:/home/jacobt/.local/share/fnm/node-versions/v24.22.1/installation/bin:/home/jacobt/src/goose-to-wasm/build/emsdk/upstream/emscripten:$PATH"
export EM_NODE_JS="/home/jacobt/.local/share/fnm/node-versions/v24.22.1/installation/bin/node"
export EM_CACHE="/home/jacobt/src/goose-to-wasm/build/em-cache"
export TMPDIR="/home/jacobt/src/goose-to-wasm/build/tmp"
export EMCC_CORES=2
