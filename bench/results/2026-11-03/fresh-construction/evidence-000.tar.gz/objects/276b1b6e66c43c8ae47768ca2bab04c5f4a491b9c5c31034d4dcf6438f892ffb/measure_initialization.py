#!/usr/bin/env python3
"""Prepare the private repeated-_start initialization timing screen.

This script compiles the fixture once with each frozen compiler, then starts
one Wasmtime and one V8 worker. Each worker instantiates both modules, warms
them, and measures nine randomized paired blocks of 100 _start calls. It does
not measure process startup or native execution.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import platform
import subprocess
import sys
import time


ROOT = Path(__file__).resolve().parents[2]
BUILD = ROOT / 'build/functions-init'
TOOLCHAIN = ROOT / 'toolchain.json'
FIXTURE = BUILD / 'fixtures/global-copy-screen.goose'
WASMTIME_WORKER = BUILD / 'initialization_wasmtime.py'
V8_WORKER = BUILD / 'initialization_v8.mjs'
BASELINE = ROOT / 'build/functions-grow/body-growth'
FINAL = BUILD / 'final'
BASELINE_SHA = '353a3f1bd547330c8ecd32e9084ae92d616340f81f83a5cc30f2e657d577652e'
FINAL_SHA = 'a8c5ba4b4838eea0ae747d495394e6fe77dbdc34e476e8d0cadcb7f225c78352'
OUT = BUILD / 'initialization-screen'
CPU = 2
WARMUPS = 50
ROUNDS = 9
CALLS = 100


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
    temporary.replace(path)


def tree_hashes(root, pattern):
    result = {}
    for path in sorted(root.rglob(pattern)):
        if path.is_file():
            result[str(path)] = digest(path)
    return result


def compiler_identity(name, root, expected):
    binary = root / 'bin/goose'
    actual = digest(binary)
    if actual != expected:
        raise RuntimeError(f'{name} compiler hash changed: {actual}')
    toolchain = root / 'toolchain.json'
    source = root / 'source.json'
    metadata = json.loads(source.read_bytes())
    toolchain_metadata = json.loads(toolchain.read_bytes())
    if toolchain_metadata.get('compiler_sha256') != expected:
        raise RuntimeError(f'{name} toolchain compiler hash differs')
    if toolchain_metadata.get('headers') != metadata.get('headers'):
        raise RuntimeError(f'{name} toolchain/header source pins differ')
    if toolchain_metadata.get('patches') != metadata.get('patches'):
        raise RuntimeError(f'{name} toolchain/patch source pins differ')
    pins = {str(binary): actual, str(toolchain): digest(toolchain), str(source): digest(source)}
    for filename, sha in metadata.get('headers', {}).items():
        path = root / 'compiler' / filename
        if digest(path) != sha:
            raise RuntimeError(f'{name} frozen header changed: {path}')
        pins[str(path)] = sha
    for filename, sha in metadata.get('patches', {}).items():
        candidates = [root / filename, root / 'source' / filename, ROOT / filename]
        matches = [path for path in candidates if path.is_file() and digest(path) == sha]
        if not matches:
            raise RuntimeError(f'{name} frozen patch missing: {filename}')
        pins[str(matches[0])] = sha
    pins.update(tree_hashes(binary.parent / 'stdlib', '*.goose'))
    pins.update(tree_hashes(binary.parent / 'include', '*.h'))
    return {'name': name, 'root': str(root), 'binary': str(binary), 'sha256': actual,
            'toolchain_sha256': digest(toolchain), 'source_sha256': digest(source), 'input_sha256': pins}


def run_child(name, command, out, report):
    affinity = sorted(os.sched_getaffinity(0))
    if CPU not in affinity:
        raise RuntimeError(f'CPU {CPU} is unavailable')
    stdout_path = out / 'logs' / f'{name}.stdout'
    stderr_path = out / 'logs' / f'{name}.stderr'
    stdout_path.parent.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter_ns()
    with stdout_path.open('wb') as stdout, stderr_path.open('wb') as stderr:
        result = subprocess.run(command, cwd=ROOT, stdout=stdout, stderr=stderr,
                                check=False, preexec_fn=lambda: os.sched_setaffinity(0, {CPU}))
    elapsed = time.perf_counter_ns() - started
    row = {'name': name, 'command': list(map(str, command)), 'cpu_affinity': [CPU],
           'elapsed_ns': elapsed, 'returncode': result.returncode,
           'stdout_path': str(stdout_path), 'stdout_sha256': digest(stdout_path),
           'stderr_path': str(stderr_path), 'stderr_sha256': digest(stderr_path)}
    report['commands'].append(row)
    save(out / 'report.json', report)
    if result.returncode:
        raise RuntimeError(f'{name} exited {result.returncode}; logs preserved at {out / "logs"}')
    return json.loads(stdout_path.read_text()) if name.startswith('engine-') else row


def add_engine_pins(report, result):
    engine = result['engine']
    files = [(engine['package_path'], engine['package_sha256'])] if 'package_path' in engine else []
    files.extend((row['path'], row['sha256']) for row in engine.get('engine_binaries', []))
    if 'binary' in engine:
        files.append((engine['binary'], engine['binary_sha256']))
    if not files:
        raise RuntimeError('engine worker did not report a binary hash')
    for filename, expected in files:
        path = Path(filename).resolve()
        actual = digest(path)
        if actual != expected:
            raise RuntimeError(f'engine file changed during measurement: {path}')
        previous = report['input_sha256'].get(str(path))
        if previous is not None and previous != expected:
            raise RuntimeError(f'engine identity conflicts with an existing pin: {path}')
        report['input_sha256'][str(path)] = expected


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=OUT)
    parser.add_argument('--node', type=Path, default=Path('/home/jacobt/.local/share/fnm/node-versions/v24.22.1/installation/bin/node'))
    parser.add_argument('--python', type=Path, default=Path(sys.executable))
    parser.add_argument('--seed', type=int, default=20261103)
    args = parser.parse_args()
    out = args.output.absolute()
    if out.exists() and any(out.iterdir()):
        parser.error(f'preserve existing attempt before rerunning: {out}')
    node = args.node.absolute()
    python = args.python.absolute()
    if not node.is_file() or not python.is_file():
        parser.error('Node and Python executables must exist')
    affinity = sorted(os.sched_getaffinity(0))
    if CPU not in affinity:
        parser.error(f'CPU {CPU} is unavailable')
    out.mkdir(parents=True, exist_ok=True)
    report = {'schema': 'goose-initialization-screen-v1', 'status': 'preparing',
              'started_unix_ns': time.time_ns(),
              'configuration': {'optimization': 'O2', 'offline': True, 'initial_pages': 1,
                  'maximum_pages': 1024, 'cpu': CPU, 'warmups_per_module_per_engine': WARMUPS,
                  'paired_rounds': ROUNDS, 'calls_per_block': CALLS, 'seed': args.seed,
                  'scope': 'Repeated _start calls inside one warm engine instance; excludes process startup and native comparison.'},
              'environment': {'python': sys.version, 'platform': platform.platform(),
                  'cpu_affinity_before': affinity,
                  'controls': {key: os.environ.get(key) for key in ('RAYON_NUM_THREADS', 'OMP_NUM_THREADS',
                                                                       'BINARYEN_CORES', 'LD_PRELOAD',
                                                                       'LD_LIBRARY_PATH', 'GOOSE_STDLIB')}},
              'source': {'path': str(FIXTURE), 'sha256': digest(FIXTURE)},
              'measurement_script': {'path': str(Path(__file__).resolve()),
                                     'sha256': digest(Path(__file__).resolve())},
              'engine_versions_expected': json.loads(TOOLCHAIN.read_bytes()),
              'workers': {str(WASMTIME_WORKER): digest(WASMTIME_WORKER),
                          str(V8_WORKER): digest(V8_WORKER)},
              'compiler_identities': {}, 'input_sha256': {}, 'compile_phases': [],
              'commands': [], 'engine_runs': {}}
    save(out / 'report.json', report)
    try:
        compilers = [('baseline', BASELINE, BASELINE_SHA), ('final', FINAL, FINAL_SHA)]
        for name, root, expected in compilers:
            identity = compiler_identity(name, root, expected)
            report['compiler_identities'][name] = {key: value for key, value in identity.items() if key != 'input_sha256'}
            report['input_sha256'].update(identity['input_sha256'])
        report['input_sha256'][str(FIXTURE)] = digest(FIXTURE)
        report['input_sha256'][str(TOOLCHAIN)] = digest(TOOLCHAIN)
        report['input_sha256'][str(Path(__file__).resolve())] = digest(Path(__file__).resolve())
        report['input_sha256'][str(WASMTIME_WORKER)] = digest(WASMTIME_WORKER)
        report['input_sha256'][str(V8_WORKER)] = digest(V8_WORKER)
        report['input_sha256'][str(node)] = digest(node)
        report['input_sha256'][str(python)] = digest(python)
        save(out / 'report.json', report)

        wasm_paths = {}
        for name, root, expected in compilers:
            wasm = out / f'{name}.wasm'
            command = [str(root / 'bin/goose'), str(FIXTURE), '--offline', '--target', 'wasm-direct',
                       '-O2', '--wasm-initial-pages', '1', '--wasm-max-pages', '1024', '-o', str(wasm)]
            phase = {'compiler': name, 'compiler_sha256': expected, 'command': command,
                     'started_unix_ns': time.time_ns(), 'status': 'running', 'output': str(wasm)}
            report['compile_phases'].append(phase)
            save(out / 'report.json', report)
            record = run_child(f'compile-{name}', command, out, report)
            phase.update(status='passed', elapsed_ns=record['elapsed_ns'], returncode=record['returncode'],
                         stdout_path=record['stdout_path'], stdout_sha256=record['stdout_sha256'],
                         stderr_path=record['stderr_path'], stderr_sha256=record['stderr_sha256'],
                         module_sha256=digest(wasm), module_bytes=wasm.stat().st_size)
            report['input_sha256'][str(wasm)] = phase['module_sha256']
            wasm_paths[name] = wasm
            save(out / 'report.json', report)

        engine_jobs = [
            ('engine-wasmtime', [str(python), str(WASMTIME_WORKER),
                '--module', f'baseline={wasm_paths["baseline"]}', '--module', f'final={wasm_paths["final"]}',
                '--warmups', str(WARMUPS), '--rounds', str(ROUNDS), '--calls', str(CALLS), '--seed', str(args.seed)]),
            ('engine-v8', [str(node), str(V8_WORKER),
                '--module', f'baseline={wasm_paths["baseline"]}', '--module', f'final={wasm_paths["final"]}',
                '--warmups', str(WARMUPS), '--rounds', str(ROUNDS), '--calls', str(CALLS), '--seed', str(args.seed + 1)]),
        ]
        for name, command in engine_jobs:
            result = run_child(name, command, out, report)
            add_engine_pins(report, result)
            pins = report['engine_versions_expected']
            if name == 'engine-wasmtime' and result['engine']['version'] != pins['wasmtime_python']:
                raise RuntimeError('Wasmtime version differs from the repository toolchain pin')
            if name == 'engine-v8' and (result['engine']['node'].removeprefix('v') != pins['node'] or
                                        result['engine']['v8'] != pins['v8']):
                raise RuntimeError('Node/V8 version differs from the repository toolchain pin')
            for compiler, wasm in wasm_paths.items():
                if result['modules'][compiler]['module_sha256'] != digest(wasm):
                    raise RuntimeError(f'{name} module hash differs for {compiler}')
            observations = result['observations']
            expected = {(compiler, round_index) for compiler in ('baseline', 'final') for round_index in range(ROUNDS)}
            actual = {(row['compiler'], row['round']) for row in observations}
            if len(observations) != len(expected) or actual != expected or any(row['checksum'] not in (0, '0') for row in observations):
                raise RuntimeError(f'{name} returned incomplete observations or a nonzero checksum')
            if result['warmups'] != WARMUPS or result['calls_per_round'] != CALLS:
                raise RuntimeError(f'{name} warmup or call count differs')
            report['engine_runs'][name] = {'command': command, 'stdout_path': str(out / 'logs' / f'{name}.stdout'),
                'stdout_sha256': digest(out / 'logs' / f'{name}.stdout'),
                'stderr_path': str(out / 'logs' / f'{name}.stderr'),
                'stderr_sha256': digest(out / 'logs' / f'{name}.stderr'), 'result': result}
            save(out / 'report.json', report)
        input_sha256_after = {}
        for filename, expected in sorted(report['input_sha256'].items()):
            actual = digest(filename)
            if actual != expected:
                raise RuntimeError(f'input changed during measurement: {filename}')
            input_sha256_after[filename] = actual
        if input_sha256_after != report['input_sha256']:
            raise RuntimeError('input hashes changed during final audit')
        report['input_sha256_after'] = input_sha256_after
        report['status'] = 'passed'
    except BaseException as error:
        report['status'] = 'failed'
        report['error'] = f'{type(error).__name__}: {error}'
        raise
    finally:
        report['finished_unix_ns'] = time.time_ns()
        save(out / 'report.json', report)


if __name__ == '__main__':
    main()
