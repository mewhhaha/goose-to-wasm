# Example program benchmarks

Status: **passed**.

2026-11-03 · AMD Ryzen 7 3800X, shared desktop host.

Goose O2. Direct Wasm uses memory32; C-Wasm uses memory64. The selected programs, their constant inputs and all printing are unchanged from the [example catalog](../../../../examples/README.md). Compiler constant folding is allowed.

Builds are complete uncached Python-driver invocations, including any C compilation/linking. OS page caches and Emscripten's installed system-library cache remain warm.

Runtime is **whole-process launch-to-exit time**, including host startup, Wasm compilation/instantiation, program initialization, computation, output delivery and teardown. Each observation starts a fresh process/instance and calls the entrypoint once. This measures CLI cost, not warmed kernel throughput.

Each cell has 5 build samples or 15 runtime samples. Untimed fresh-process warmups per runtime cell: 1. Orders are shuffled with the recorded seed; builds and runtime never overlap. Every used artifact must pass its golden output. Values are median milliseconds ± median absolute deviation (MAD).

Headline runtime samples use the ordinary runners without timing-file instrumentation. The Wasm supplements use a separate shuffled set of fresh processes, with the same sample count; timing files are written after their engine intervals end.

## Compilation

| Example | Direct | C-Wasm | Native C |
| --- | ---: | ---: | ---: |
| squares | 61.909 ±0.535 | 499.917 ±18.684 | 233.375 ±26.643 |
| tour | 76.302 ±11.944 | 946.222 ±26.918 | 405.178 ±4.052 |
| functions | 107.832 ±2.608 | 940.684 ±10.828 | 516.962 ±34.138 |
| errors | 69.520 ±0.963 | 745.666 ±17.981 | 349.609 ±8.704 |
| sieve | 67.144 ±0.803 | 577.657 ±35.241 | 277.533 ±0.551 |
| sorting | 108.486 ±8.845 | 909.066 ±23.970 | 528.001 ±2.955 |
| sudoku | 74.489 ±5.930 | 541.761 ±19.516 | 298.396 ±16.941 |
| maze | 87.695 ±14.801 | 695.286 ±19.345 | 354.759 ±20.527 |
| vm | 72.250 ±2.851 | 685.866 ±18.976 | 287.366 ±9.157 |
| life | 69.684 ±0.742 | 652.259 ±10.736 | 338.464 ±9.924 |

## Whole-process runtime

| Example | Direct / V8 | C-Wasm / V8 | Direct / Wasmtime | C-Wasm / Wasmtime | Native C |
| --- | ---: | ---: | ---: | ---: | ---: |
| squares | 28.734 ±5.021 | 27.914 ±2.824 | 70.933 ±2.192 | 92.298 ±12.616 | 0.960 ±0.161 |
| tour | 44.445 ±2.756 | 36.253 ±5.956 | 123.776 ±10.088 | 112.302 ±10.160 | 0.992 ±0.162 |
| functions | 32.760 ±2.700 | 32.321 ±1.852 | 89.270 ±2.616 | 123.087 ±13.982 | 0.978 ±0.111 |
| errors | 34.122 ±5.768 | 28.875 ±2.612 | 84.610 ±7.233 | 90.253 ±4.996 | 0.936 ±0.112 |
| sieve | 38.658 ±8.162 | 36.468 ±7.539 | 78.009 ±4.224 | 91.635 ±9.612 | 1.540 ±0.300 |
| sorting | 73.591 ±9.498 | 240.985 ±10.634 | 114.992 ±12.948 | 249.113 ±11.754 | 46.906 ±0.794 |
| sudoku | 36.228 ±4.144 | 53.809 ±4.061 | 80.648 ±4.963 | 105.255 ±8.280 | 4.472 ±0.387 |
| maze | 31.388 ±4.822 | 38.925 ±10.179 | 86.188 ±6.962 | 101.479 ±11.991 | 1.127 ±0.180 |
| vm | 37.640 ±8.509 | 30.426 ±2.113 | 97.209 ±12.756 | 92.717 ±5.049 | 1.052 ±0.214 |
| life | 40.983 ±6.525 | 50.886 ±9.942 | 108.993 ±7.658 | 101.220 ±7.416 | 19.134 ±0.804 |

## Supplement: Wasm entrypoint

| Example | Direct / V8 | C-Wasm / V8 | Direct / Wasmtime | C-Wasm / Wasmtime |
| --- | ---: | ---: | ---: | ---: |
| squares | 0.169 ±0.009 | 0.954 ±0.030 | 0.129 ±0.004 | 0.653 ±0.019 |
| tour | 19.912 ±4.691 | 2.965 ±0.377 | 1.781 ±0.022 | 1.780 ±0.019 |
| functions | 5.662 ±0.847 | 2.698 ±0.080 | 1.383 ±0.026 | 1.965 ±0.020 |
| errors | 1.675 ±0.143 | 1.818 ±0.091 | 0.861 ±0.020 | 1.753 ±0.023 |
| sieve | 2.370 ±0.072 | 3.371 ±1.537 | 1.233 ±0.019 | 1.401 ±0.020 |
| sorting | 23.258 ±1.959 | 209.790 ±5.442 | 15.760 ±0.209 | 128.972 ±1.665 |
| sudoku | 5.381 ±0.216 | 6.526 ±0.160 | 3.843 ±0.031 | 8.579 ±0.142 |
| maze | 2.341 ±0.079 | 2.670 ±0.724 | 0.776 ±0.011 | 2.335 ±0.047 |
| vm | 3.074 ±0.215 | 2.308 ±0.094 | 0.933 ±0.020 | 3.094 ±0.080 |
| life | 10.748 ±2.981 | 10.177 ±0.482 | 6.417 ±0.070 | 9.855 ±0.172 |

## Supplement: Wasm engine compilation and instantiation

| Example | Direct / V8 | C-Wasm / V8 | Direct / Wasmtime | C-Wasm / Wasmtime |
| --- | ---: | ---: | ---: | ---: |
| squares | 0.225 ±0.017 | 0.550 ±0.094 | 3.004 ±0.187 | 10.413 ±0.629 |
| tour | 0.509 ±0.062 | 0.596 ±0.073 | 31.868 ±0.601 | 34.122 ±2.638 |
| functions | 0.366 ±0.052 | 0.561 ±0.052 | 19.944 ±3.173 | 38.646 ±6.350 |
| errors | 0.327 ±0.055 | 0.551 ±0.081 | 10.623 ±1.298 | 15.390 ±2.079 |
| sieve | 0.265 ±0.044 | 0.528 ±0.024 | 6.346 ±0.409 | 13.248 ±1.895 |
| sorting | 0.408 ±0.056 | 0.620 ±0.072 | 17.440 ±2.103 | 32.471 ±1.828 |
| sudoku | 0.280 ±0.026 | 0.570 ±0.074 | 5.832 ±0.732 | 12.548 ±0.847 |
| maze | 0.314 ±0.018 | 0.650 ±0.096 | 10.005 ±0.943 | 14.808 ±0.574 |
| vm | 0.343 ±0.061 | 0.590 ±0.061 | 17.318 ±2.255 | 17.270 ±0.793 |
| life | 0.320 ±0.062 | 0.573 ±0.040 | 11.613 ±2.531 | 14.721 ±1.111 |

The entrypoint interval includes Goose initialization, host output callbacks and any lazy JIT work. It excludes final Wasm-host output concatenation/delivery. Native Goose prints unbuffered, so no native entrypoint column or cross-boundary speedup is presented. Process time minus engine time also includes loading, bookkeeping and teardown; it is not a pure startup measurement.

These fresh-process examples have different timing rules from LangArena's warmed computational regions. Raw samples, commands, artifact/source/compiler identities and engine versions are in [report.json](report.json). [Method and reproduction](../../../examples.md).
