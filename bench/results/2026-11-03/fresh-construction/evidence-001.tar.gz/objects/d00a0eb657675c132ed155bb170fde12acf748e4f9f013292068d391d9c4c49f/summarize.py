"""Derive publication numbers from completed immutable cohorts."""
from pathlib import Path
import hashlib
import json
import math
import statistics

ROOT=Path(__file__).resolve().parents[2]
BUILD=ROOT/'build/functions-init'


def read(relative):
    return json.loads((BUILD/relative).read_bytes())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def summary(values):
    center=statistics.median(values)
    return {'n':len(values),'median':center,'mad':statistics.median(abs(v-center) for v in values),'samples':values}


def micro(relative):
    report=read(relative); assert report['status']=='passed'
    result={}
    for engine,entry in report['engine_runs'].items():
        rows=entry['result']['observations']
        by_key={(r['round'],r['compiler']):r['ns_per_call'] for r in rows}
        rounds=sorted({r['round'] for r in rows})
        values={}
        for compiler in ['baseline','final']:
            values[compiler]=summary([by_key[i,compiler]/1e6 for i in rounds])
        result[engine]={'milliseconds_per_start':values,
            'paired_speedup':summary([by_key[i,'baseline']/by_key[i,'final'] for i in rounds]),
            'modules':entry['result']['modules']}
    return result


def main():
    reports={name:read(path) for name,path in {
        'warmed':'delivered-warmed/report.json','v8':'delivered-v8/report.json',
        'examples':'current/examples/report.json','host':'current/host/report.json',
        'langarena':'current/langarena/report.json',
        'differential':'qualification/attempt-2/differential/report.json',
        'focused':'qualification/attempt-2/focused/report.json',
        'replay':'qualification/attempt-2/host/report.json'}.items()}
    assert all(not r.get('failures') for r in reports.values())
    ex=reports['examples']; host=reports['host']; arena=reports['langarena']
    final=read('final/toolchain.json')
    out={'schema':'goose-fresh-construction-numbers-v1','compiler_sha256':final['compiler_sha256'],
        'baseline_compiler_sha256':'353a3f1bd547330c8ecd32e9084ae92d616340f81f83a5cc30f2e657d577652e',
        'module_analysis':read('module-analysis.json'),
        'qualification':{'focused_commands':len(reports['focused']['commands']),
            'cases':reports['differential']['cases'],'differential_executions':reports['differential']['observations'],
            'native_stdout_comparisons':reports['differential']['qualification_execution']['native_stdout_comparisons'],
            'host_observations':reports['replay']['observations'],'unique_host_modules':reports['replay']['unique_wasm']},
        'warmed':{},'examples':{},'langarena':{'compile_ranges_ms':{}},
        'initialization_screen':micro('initialization-screen/report.json'),
        'initialization_confirmation':micro('initialization-confirmation/report.json')}
    for engine in ['warmed','v8']:
        report=reports[engine]
        out['warmed'][engine]={'geometric_ratios':report['geometric_ratios'],
            'tasks':[{'task':row['task'],'times':row['times'],'paired_ratios':row['paired_ratios']} for row in report['summary']]}
    for case in ex['examples']:
        name=case
        if isinstance(case,dict): name=case['name']
        out['examples'][name]={
            'compile':[r for r in ex['compile_summary'] if r['name']==name],
            'python_v8_native':[r for r in ex['runtime_summary'] if r['name']==name],
            'native_host':[r for r in host['runtime_summary'] if r['name']==name],
            'preparation':[r for r in host['preparation_summary'] if r['name']==name]}
    for backend in ['direct','c-wasm','native']:
        values=[r['wall_seconds']['median']*1000 for r in arena['compile_summary'] if r['backend']==backend and r['phase']=='cold']
        out['langarena']['compile_ranges_ms'][backend]={'min':min(values),'max':max(values)}
    out['langarena']['compile_summary']=arena['compile_summary'];out['langarena']['runtime_summary']=arena['runtime_summary']
    (BUILD/'final-numbers.json').write_text(json.dumps(out,indent=2)+'\n')
    campaign={'schema':'goose-fresh-construction-campaign-v1','status':'passed',
        'compiler_sha256':final['compiler_sha256'],'baseline_compiler_sha256':out['baseline_compiler_sha256'],
        'scope':'Pure fixed global literal trees and local limited-array/string literal trees write into fresh destinations. Plain local fixed arrays/records retain staging.',
        'qualification':out['qualification'],
        'accepted_boundaries':'Static module/copy reductions and focused repeated large-global initialization; warmed and ordinary whole-process results are separately collected and disclosed.',
        'rejected':[{'stage':'all-fixed','report':'screen-warmed/report.json','reason':'Stable Wasmtime Fannkuch and Sudoku regressions. Static diagnosis records register allocation and placement changes; full causation is not established.'}],
        'numbers_sha256':sha(BUILD/'final-numbers.json'),
        'evidence':{str(path.relative_to(BUILD)):sha(path) for path in [
            BUILD/'module-analysis.json',BUILD/'static-review.json',BUILD/'test-static-review.json',
            BUILD/'static-diagnosis.json',BUILD/'delivery-execution/report.json',
            BUILD/'initialization-screen/report.json',BUILD/'initialization-confirmation/report.json']}}
    (BUILD/'campaign.json').write_text(json.dumps(campaign,indent=2)+'\n')
    print(json.dumps({'qualification':out['qualification'],'compile_ranges_ms':out['langarena']['compile_ranges_ms'],
        'initialization_confirmation':out['initialization_confirmation']},indent=2))


if __name__=='__main__':main()
