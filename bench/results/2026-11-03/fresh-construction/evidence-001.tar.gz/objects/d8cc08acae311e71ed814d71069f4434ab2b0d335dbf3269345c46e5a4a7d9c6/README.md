# Fresh construction evidence preparation

Source preparation only. Run collection only after all timing windows close.
The coordinator supplies the final reports, review, charts and documentation.

The spec uses the eight conventional plain primary reports, two plain repeated
initialization reports,
compiler identity and the unchanged official references. It retains only this
campaign's qualification, delivery, screens, source stages, diagnostics, tests
and previews. The all-fixed screen is rejected evidence; literal-v1 is unmeasured.

Storage reuse reads one published functions-calls index. It imports no aliases
or documents. Its explicit member map can name only four calls archives and
eight forwarding archives. Every reused member and complete physical archive
is verified by SHA; no older index or report is opened. New objects are deduped
into deterministic archives with at most64MiB raw payload and metadata.

After explicit approval, use the repository virtualenv Python with `-B`:

```
python -B build/functions-init/delivery-package/bundle.py copy-reports
python -B build/functions-init/delivery-package/bundle.py inventory
python -B build/functions-init/delivery-package/bundle.py package
python -B build/functions-init/delivery-package/verify.py --package bench/results/2026-11-03/fresh-construction --report build/functions-init/package-verification.json
```

Copy reports before rendering charts. Wait for the final public review before
packaging. Publish verification JSON/log and update the manifest, then freeze
public writes for the independent final audit and its single manifest entry.
Preserve failed preparation scripts and logs; never rewrite raw reports.
