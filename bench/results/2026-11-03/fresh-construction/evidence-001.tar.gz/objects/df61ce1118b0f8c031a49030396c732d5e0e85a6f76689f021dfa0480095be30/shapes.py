from pathlib import Path
import json,sys,subprocess,hashlib
sys.path.insert(0,'tests')
from test_function_value_forwarding import function_bodies,memory_copy_count
out=Path('build/functions-init/shapes');out.mkdir(exist_ok=True)
compilers={'baseline':Path('build/functions-grow/body-growth/bin/goose'),'candidate':Path('build/functions-init/final/bin/goose')}
report={'compilers':{k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in compilers.items()},'modules':{}}
for source in sorted(Path('examples').glob('*.goose')):
 row={}
 for name,compiler in compilers.items():
  stem=out/(source.stem+'-'+name);wasm=stem.with_suffix('.wasm');stats=stem.with_suffix('.json')
  subprocess.run([str(compiler),str(source),'--target','wasm-direct','--offline','-O2','--wasm-stats',str(stats),'-o',str(wasm)],check=True,capture_output=True)
  data=wasm.read_bytes();info=json.loads(stats.read_bytes())
  disassembly=subprocess.check_output(['llvm-objdump','-d',str(wasm)],text=True)
  copies=disassembly.count('memory.copy')
  stem.with_suffix('.wat-disassembly').write_text(disassembly)
  row[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'copies':copies,'activation_bytes':info['activation_bytes'],'stats':str(stats),'wasm':str(wasm)}
 report['modules'][source.stem]=row
 print(source.stem,[(k,r['bytes'],r['copies'],r['activation_bytes']) for k,r in row.items()],flush=True)
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
