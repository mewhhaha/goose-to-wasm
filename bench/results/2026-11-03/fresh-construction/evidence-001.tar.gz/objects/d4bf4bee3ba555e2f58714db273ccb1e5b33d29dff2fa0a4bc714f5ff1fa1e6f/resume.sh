#!/usr/bin/env zsh
set -eu
cd /home/jacobt/src/goose-to-wasm
source build/performance-env.sh
QUAL=build/functions-init/qualification
ATTEMPT=$QUAL/attempt-2
mkdir "$ATTEMPT"
python -B "$QUAL/run.py" seal --output-dir "$ATTEMPT" \
  --compiler-sha a8c5ba4b4838eea0ae747d495394e6fe77dbdc34e476e8d0cadcb7f225c78352 \
  --resource-reference "$QUAL/resource-control/build/bin/goose" \
  --named-reference "$QUAL/named-control/build/bin/goose" > "$ATTEMPT/seal.log" 2>&1
python -B "$QUAL/run.py" gates --output-dir "$ATTEMPT" --jobs 4 > "$ATTEMPT/gates.log" 2>&1
python -B "$QUAL/run.py" host --output-dir "$ATTEMPT" --jobs 4 > "$ATTEMPT/host.log" 2>&1
