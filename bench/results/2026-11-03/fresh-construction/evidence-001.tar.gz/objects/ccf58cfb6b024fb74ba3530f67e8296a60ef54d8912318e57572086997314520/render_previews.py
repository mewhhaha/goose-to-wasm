"""Render all delivered SVGs for inspection after measurements have ended."""
from pathlib import Path
import hashlib,json,subprocess
from PIL import Image,ImageDraw
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'build/functions-init/chart-previews';OUT.mkdir(exist_ok=True)
charts=['compilation','runtime','runtime-targets','examples-compilation','examples-runtime','examples-python-runtime','examples-entry','wasmtime-host-preparation','wasmtime-host-runtime','wasmtime-host-c-wasm']
records=[]
for name in charts:
 source=ROOT/'bench/charts'/(name+'.svg');target=OUT/(name+'.png')
 subprocess.run(['rsvg-convert','-w','1600','-o',str(target),str(source)],check=True)
 records.append({'source':str(source),'sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'preview':str(target),'preview_sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
contacts=[]
for index,start in enumerate(range(0,len(charts),4),1):
 sheet=Image.new('RGB',(1600,1060),'white');draw=ImageDraw.Draw(sheet)
 for slot,name in enumerate(charts[start:start+4]):
  image=Image.open(OUT/(name+'.png')).convert('RGB');image.thumbnail((800,500))
  left=(slot%2)*800;top=(slot//2)*530
  sheet.paste(image,(left,top+25));draw.text((left+10,top+5),name,fill='black')
 path=OUT/f'contact-{index}.png';sheet.save(path);contacts.append(str(path))
proof={'status':'pending-visual-inspection','method':'All10SVGs rendered with rsvg-convert at1600px; three contact sheets and full-size plots inspected separately. Numeric labels checked against raw reports by check_charts.py.',
       'charts':records,'contact_sheets':contacts}
(OUT/'review.json').write_text(json.dumps(proof,indent=2)+'\n')
print('\n'.join(contacts))
