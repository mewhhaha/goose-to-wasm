# LangArena qualification and measurements

Status: **passed**.

Upstream pin: `aab9b14998231ba905523b5ba3990ee03c46f64d`. Catalog: **50 tasks**. Adapted entrypoints: **7 tasks**, including six storage adaptations.

Mode: `measure`. Machine: AMD Ryzen 7 3800X, shared desktop host.
Compiler SHA-256: `353a3f1bd547330c8ecd32e9084ae92d616340f81f83a5cc30f2e657d577652e`.

## Measurement contract

Whole-suite results use all original Goose kernel sources. The only staging patch changes the marker destination from `/tmp/recompile_marker` to a relative file inside the isolated run directory. The original checkout is hash-verified and never edited. Whole-suite compile times include all 50 tasks.

The adapted track uses the same seven port sources across native C, direct Wasm, and C-Wasm. Six ports replace growable storage; Fannkuch keeps its original fixed-array kernel. Official test/run inputs and checksums are unchanged. Preparation stays outside the clock; warmups mutate the same state used for measurement; the deterministic RNG is reset before measured iterations. Existing checksum work retains its original placement.

Cold builds and marker-edit builds launch fresh driver/compiler processes with `--no-cache`. OS caches and installed compiler/system-library caches are retained. A port marker edit changes its exit status from 0 to 1 after its two output lines, and the edited executable must retain the official checksum. Whole-suite edits change the actual marker file contents. Source bytes are restored in all cases. Optional unchanged cache hits are a separate phase. Edited sources still rerun the complete frontend.

The official whole-suite timer prints milliseconds; adapted ports print integer nanoseconds. Timed regions exclude process startup and preparation. Process wall time is retained separately. Sample counts below five are preliminary estimates; raw values and MAD are provided. These are local comparisons, not LangArena leaderboard scores or claims of complete direct-backend language support.

## Whole-suite compilation

| Backend | Phase | Samples | Median ms | MAD ms | Artifact bytes |
| --- | --- | ---: | ---: | ---: | ---: |

## Original-source correctness and runtime

| Task | Backend / engine | Profile | Samples | Region median ms | MAD ms | Process median ms |
| --- | --- | --- | ---: | ---: | ---: | ---: |

## Adapted workload compilation

| Task | Backend | Phase | Samples | Median ms | MAD ms | Artifact bytes |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| CLBG::Fannkuchredux | c-wasm | cold | 5 | 703.842 | 23.328 | 51988 |
| CLBG::Fannkuchredux | direct | cold | 5 | 67.124 | 1.673 | 4067 |
| CLBG::Fannkuchredux | native | cold | 5 | 322.133 | 24.708 | 22984 |
| CLBG::Mandelbrot | c-wasm | cold | 5 | 654.193 | 11.360 | 52065 |
| CLBG::Mandelbrot | direct | cold | 5 | 71.651 | 0.596 | 4650 |
| CLBG::Mandelbrot | native | cold | 5 | 290.509 | 13.681 | 23160 |
| Etc::Sieve | c-wasm | cold | 5 | 652.815 | 3.538 | 51607 |
| Etc::Sieve | direct | cold | 5 | 66.169 | 0.664 | 3281 |
| Etc::Sieve | native | cold | 5 | 275.006 | 5.387 | 23128 |
| Hash::CRC32 | c-wasm | cold | 5 | 668.545 | 17.415 | 51823 |
| Hash::CRC32 | direct | cold | 5 | 67.025 | 1.556 | 3309 |
| Hash::CRC32 | native | cold | 5 | 260.422 | 8.871 | 23008 |
| Hash::SHA256 | c-wasm | cold | 5 | 654.298 | 7.732 | 51831 |
| Hash::SHA256 | direct | cold | 5 | 71.644 | 5.005 | 6788 |
| Hash::SHA256 | native | cold | 5 | 298.866 | 25.176 | 23008 |
| Sort::Merge | c-wasm | cold | 5 | 712.412 | 22.184 | 52490 |
| Sort::Merge | direct | cold | 5 | 67.914 | 1.136 | 5453 |
| Sort::Merge | native | cold | 5 | 318.144 | 6.960 | 27416 |
| Sort::Quick | c-wasm | cold | 5 | 634.640 | 44.293 | 52049 |
| Sort::Quick | direct | cold | 5 | 67.094 | 0.749 | 4566 |
| Sort::Quick | native | cold | 5 | 295.182 | 10.946 | 23168 |

## Adapted workload runtime

| Task | Backend / engine | Profile | Samples | Region median ms | MAD ms | Engine compile + instantiate ms | Process median ms | Checksum |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| CLBG::Fannkuchredux | c-wasm / v8 | run | 5 | 2120.221 | 19.030 | 0.504 | 2572.356 | 135762480 |
| CLBG::Fannkuchredux | c-wasm / v8 | test | 1 | 0.020 | 0.000 | 0.531 | 26.510 | 4428 |
| CLBG::Fannkuchredux | c-wasm / wasmtime | run | 5 | 1470.115 | 6.431 | 24.604 | 1866.180 | 135762480 |
| CLBG::Fannkuchredux | c-wasm / wasmtime | test | 1 | 0.054 | 0.000 | 24.867 | 125.874 | 4428 |
| CLBG::Fannkuchredux | direct / v8 | run | 5 | 1249.077 | 3.901 | 0.235 | 1528.353 | 135762480 |
| CLBG::Fannkuchredux | direct / v8 | test | 1 | 0.041 | 0.000 | 0.293 | 35.864 | 4428 |
| CLBG::Fannkuchredux | direct / wasmtime | run | 5 | 1368.456 | 6.928 | 4.428 | 1729.341 | 135762480 |
| CLBG::Fannkuchredux | direct / wasmtime | test | 1 | 0.030 | 0.000 | 5.251 | 110.608 | 4428 |
| CLBG::Fannkuchredux | native / native | run | 5 | 1318.930 | 3.546 | — | 1568.366 | 135762480 |
| CLBG::Fannkuchredux | native / native | test | 1 | 0.011 | 0.000 | — | 0.714 | 4428 |
| CLBG::Mandelbrot | c-wasm / v8 | run | 5 | 950.062 | 4.057 | 0.556 | 1183.431 | 3455988829 |
| CLBG::Mandelbrot | c-wasm / v8 | test | 1 | 0.486 | 0.000 | 0.664 | 44.282 | 2236342953 |
| CLBG::Mandelbrot | c-wasm / wasmtime | run | 5 | 1063.152 | 7.358 | 23.888 | 1384.376 | 3455988829 |
| CLBG::Mandelbrot | c-wasm / wasmtime | test | 1 | 0.220 | 0.000 | 22.840 | 110.058 | 2236342953 |
| CLBG::Mandelbrot | direct / v8 | run | 5 | 960.415 | 2.466 | 0.227 | 1197.881 | 3455988829 |
| CLBG::Mandelbrot | direct / v8 | test | 1 | 0.351 | 0.000 | 0.238 | 29.984 | 2236342953 |
| CLBG::Mandelbrot | direct / wasmtime | run | 5 | 1002.704 | 1.893 | 4.087 | 1290.180 | 3455988829 |
| CLBG::Mandelbrot | direct / wasmtime | test | 1 | 0.186 | 0.000 | 4.312 | 110.601 | 2236342953 |
| CLBG::Mandelbrot | native / native | run | 5 | 920.373 | 3.378 | — | 1113.749 | 3455988829 |
| CLBG::Mandelbrot | native / native | test | 1 | 0.153 | 0.000 | — | 3.853 | 2236342953 |
| Etc::Sieve | c-wasm / v8 | run | 5 | 6155.424 | 133.230 | 0.610 | 7361.956 | 1042248060 |
| Etc::Sieve | c-wasm / v8 | test | 1 | 0.019 | 0.000 | 0.671 | 27.853 | 4660 |
| Etc::Sieve | c-wasm / wasmtime | run | 5 | 5327.812 | 7.899 | 23.962 | 6495.268 | 1042248060 |
| Etc::Sieve | c-wasm / wasmtime | test | 1 | 0.047 | 0.000 | 38.525 | 120.540 | 4660 |
| Etc::Sieve | direct / v8 | run | 5 | 1323.669 | 5.628 | 0.237 | 1646.737 | 1042248060 |
| Etc::Sieve | direct / v8 | test | 1 | 0.021 | 0.000 | 0.228 | 25.620 | 4660 |
| Etc::Sieve | direct / wasmtime | run | 5 | 1360.114 | 4.945 | 3.365 | 1728.574 | 1042248060 |
| Etc::Sieve | direct / wasmtime | test | 1 | 0.022 | 0.000 | 3.778 | 87.166 | 4660 |
| Etc::Sieve | native / native | run | 5 | 852.348 | 1.522 | — | 1026.345 | 1042248060 |
| Etc::Sieve | native / native | test | 1 | 0.002 | 0.000 | — | 2.725 | 4660 |
| Hash::CRC32 | c-wasm / v8 | run | 5 | 455.741 | 3.354 | 0.545 | 586.305 | 2318723244 |
| Hash::CRC32 | c-wasm / v8 | test | 1 | 0.014 | 0.000 | 0.624 | 29.323 | 3031698216 |
| Hash::CRC32 | c-wasm / wasmtime | run | 5 | 410.320 | 2.770 | 29.557 | 610.709 | 2318723244 |
| Hash::CRC32 | c-wasm / wasmtime | test | 1 | 0.051 | 0.000 | 24.641 | 106.419 | 3031698216 |
| Hash::CRC32 | direct / v8 | run | 5 | 497.199 | 2.313 | 0.242 | 639.620 | 2318723244 |
| Hash::CRC32 | direct / v8 | test | 1 | 0.017 | 0.000 | 0.259 | 26.678 | 3031698216 |
| Hash::CRC32 | direct / wasmtime | run | 5 | 433.250 | 1.592 | 3.409 | 611.673 | 2318723244 |
| Hash::CRC32 | direct / wasmtime | test | 1 | 0.025 | 0.000 | 3.543 | 86.980 | 3031698216 |
| Hash::CRC32 | native / native | run | 5 | 1356.500 | 4.295 | — | 1640.023 | 2318723244 |
| Hash::CRC32 | native / native | test | 1 | 0.027 | 0.000 | — | 1.547 | 3031698216 |
| Hash::SHA256 | c-wasm / v8 | run | 5 | 1028.437 | 2.431 | 0.618 | 1283.194 | 2844672256 |
| Hash::SHA256 | c-wasm / v8 | test | 1 | 0.014 | 0.000 | 0.770 | 51.406 | 1036619072 |
| Hash::SHA256 | c-wasm / wasmtime | run | 5 | 941.707 | 3.465 | 24.139 | 1251.622 | 2844672256 |
| Hash::SHA256 | c-wasm / wasmtime | test | 1 | 0.049 | 0.000 | 23.260 | 132.525 | 1036619072 |
| Hash::SHA256 | direct / v8 | run | 5 | 257.849 | 2.878 | 0.241 | 349.920 | 2844672256 |
| Hash::SHA256 | direct / v8 | test | 1 | 0.003 | 0.000 | 0.278 | 31.687 | 1036619072 |
| Hash::SHA256 | direct / wasmtime | run | 5 | 321.969 | 1.014 | 5.165 | 479.324 | 2844672256 |
| Hash::SHA256 | direct / wasmtime | test | 1 | 0.017 | 0.000 | 5.076 | 109.280 | 1036619072 |
| Hash::SHA256 | native / native | run | 5 | 587.412 | 5.998 | — | 709.086 | 2844672256 |
| Hash::SHA256 | native / native | test | 1 | 0.002 | 0.000 | — | 2.114 | 1036619072 |
| Sort::Merge | c-wasm / v8 | run | 5 | 1305.285 | 5.973 | 0.527 | 1599.759 | 61757772 |
| Sort::Merge | c-wasm / v8 | test | 1 | 11.977 | 0.000 | 0.614 | 49.751 | 2548773 |
| Sort::Merge | c-wasm / wasmtime | run | 5 | 2660.540 | 20.650 | 24.538 | 3317.487 | 61757772 |
| Sort::Merge | c-wasm / wasmtime | test | 1 | 24.251 | 0.000 | 38.821 | 160.273 | 2548773 |
| Sort::Merge | direct / v8 | run | 5 | 1876.383 | 13.919 | 0.248 | 2287.277 | 61757772 |
| Sort::Merge | direct / v8 | test | 1 | 17.259 | 0.000 | 0.249 | 56.883 | 2548773 |
| Sort::Merge | direct / wasmtime | run | 5 | 2104.084 | 46.996 | 3.870 | 2562.891 | 61757772 |
| Sort::Merge | direct / wasmtime | test | 1 | 17.551 | 0.000 | 4.389 | 117.625 | 2548773 |
| Sort::Merge | native / native | run | 5 | 1392.813 | 9.581 | — | 1676.445 | 61757772 |
| Sort::Merge | native / native | test | 1 | 13.436 | 0.000 | — | 23.149 | 2548773 |
| Sort::Quick | c-wasm / v8 | run | 5 | 1401.803 | 9.143 | 0.511 | 1718.301 | 61757772 |
| Sort::Quick | c-wasm / v8 | test | 1 | 13.728 | 0.000 | 0.668 | 53.156 | 2548773 |
| Sort::Quick | c-wasm / wasmtime | run | 5 | 1624.306 | 10.753 | 24.111 | 2060.309 | 61757772 |
| Sort::Quick | c-wasm / wasmtime | test | 1 | 15.611 | 0.000 | 39.663 | 149.678 | 2548773 |
| Sort::Quick | direct / v8 | run | 5 | 1337.377 | 6.044 | 0.217 | 1643.261 | 61757772 |
| Sort::Quick | direct / v8 | test | 1 | 13.632 | 0.000 | 0.272 | 63.458 | 2548773 |
| Sort::Quick | direct / wasmtime | run | 5 | 1714.497 | 40.146 | 3.526 | 2136.604 | 61757772 |
| Sort::Quick | direct / wasmtime | test | 1 | 14.853 | 0.000 | 3.945 | 108.916 | 2548773 |
| Sort::Quick | native / native | run | 5 | 1205.823 | 12.255 | — | 1450.102 | 61757772 |
| Sort::Quick | native / native | test | 1 | 11.794 | 0.000 | — | 20.064 | 2548773 |

## Qualification and limits

- Seven adapted entrypoints (six change storage, one changes only the harness) are a subset of the 50-task catalog; they do not establish unmodified whole-suite Wasm support.
- No local result is a LangArena leaderboard rank: source/compiler versions, target layout, host, flags, and coverage differ.
- Cold builds retain OS and compiler system-library caches; they are complete uncached driver builds, not disk-cold experiments.

The full 50-task coverage matrix, raw commands/output, source and artifact hashes, tool versions, input values, environment overrides (including `EM_NODE_JS`), and phase timings are in `report.json` and adjacent logs. `Hash::SHA256` retains LangArena's custom hash workload; it is not standard cryptographic SHA-256.
