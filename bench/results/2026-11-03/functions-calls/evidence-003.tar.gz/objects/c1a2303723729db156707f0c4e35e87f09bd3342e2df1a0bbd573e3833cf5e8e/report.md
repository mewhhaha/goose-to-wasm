# LangArena qualification and measurements

Status: **passed**.

Upstream pin: `aab9b14998231ba905523b5ba3990ee03c46f64d`. Catalog: **50 tasks**. Adapted entrypoints: **7 tasks**, including six storage adaptations.

Mode: `measure`. Machine: AMD Ryzen 7 3800X, shared desktop host.
Compiler SHA-256: `864262133e821068738b24952324a3145ba74a926ad7135c6cb15f7baba1f04a`.

## Measurement contract

Whole-suite results use all original Goose kernel sources. The only staging patch changes the marker destination from `/tmp/recompile_marker` to a relative file inside the isolated run directory. The original checkout is hash-verified and never edited. Whole-suite compile times include all 50 tasks.

The adapted track uses the same seven port sources across native C, direct Wasm, and C-Wasm. Six ports replace growable storage; Fannkuch keeps its original fixed-array kernel. Official test/run inputs and checksums are unchanged. Preparation stays outside the clock; warmups mutate the same state used for measurement; the deterministic RNG is reset before measured iterations. Existing checksum work retains its original placement.

Cold builds and marker-edit builds launch fresh driver/compiler processes with `--no-cache`. OS caches and installed compiler/system-library caches are retained. A port marker edit changes its exit status from 0 to 1 after its two output lines, and the edited executable must retain the official checksum. Whole-suite edits change the actual marker file contents. Source bytes are restored in all cases. Optional unchanged cache hits are a separate phase. Edited sources still rerun the complete frontend.

The official whole-suite timer prints milliseconds; adapted ports print integer nanoseconds. Timed regions exclude process startup and preparation. Process wall time is retained separately. Sample counts below five are preliminary estimates; raw values and MAD are provided. These are local comparisons, not LangArena leaderboard scores or claims of complete direct-backend language support.

## Whole-suite compilation

| Backend | Phase | Samples | Median ms | MAD ms | Artifact bytes |
| --- | --- | ---: | ---: | ---: | ---: |

## Original-source correctness and runtime

| Task | Backend / engine | Profile | Samples | Region median ms | MAD ms | Process median ms |
| --- | --- | --- | ---: | ---: | ---: | ---: |

## Adapted workload compilation

| Task | Backend | Phase | Samples | Median ms | MAD ms | Artifact bytes |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| CLBG::Fannkuchredux | c-wasm | cold | 5 | 654.927 | 11.734 | 51983 |
| CLBG::Fannkuchredux | direct | cold | 5 | 66.027 | 0.661 | 4055 |
| CLBG::Fannkuchredux | native | cold | 5 | 295.063 | 6.558 | 22984 |
| CLBG::Mandelbrot | c-wasm | cold | 5 | 677.340 | 29.394 | 52059 |
| CLBG::Mandelbrot | direct | cold | 5 | 72.034 | 3.861 | 4638 |
| CLBG::Mandelbrot | native | cold | 5 | 279.695 | 20.803 | 23160 |
| Etc::Sieve | c-wasm | cold | 5 | 633.812 | 10.374 | 51597 |
| Etc::Sieve | direct | cold | 5 | 67.077 | 1.242 | 3288 |
| Etc::Sieve | native | cold | 5 | 289.783 | 12.124 | 23128 |
| Hash::CRC32 | c-wasm | cold | 5 | 658.191 | 14.711 | 51817 |
| Hash::CRC32 | direct | cold | 5 | 70.396 | 2.245 | 3316 |
| Hash::CRC32 | native | cold | 5 | 300.387 | 9.364 | 23008 |
| Hash::SHA256 | c-wasm | cold | 5 | 668.952 | 21.378 | 51826 |
| Hash::SHA256 | direct | cold | 5 | 68.187 | 0.623 | 6776 |
| Hash::SHA256 | native | cold | 5 | 286.195 | 5.472 | 23008 |
| Sort::Merge | c-wasm | cold | 5 | 666.890 | 28.306 | 52484 |
| Sort::Merge | direct | cold | 5 | 66.565 | 0.555 | 5460 |
| Sort::Merge | native | cold | 5 | 328.704 | 8.545 | 27416 |
| Sort::Quick | c-wasm | cold | 5 | 665.912 | 17.388 | 52043 |
| Sort::Quick | direct | cold | 5 | 67.210 | 1.805 | 4573 |
| Sort::Quick | native | cold | 5 | 283.866 | 10.262 | 23168 |

## Adapted workload runtime

| Task | Backend / engine | Profile | Samples | Region median ms | MAD ms | Engine compile + instantiate ms | Process median ms | Checksum |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| CLBG::Fannkuchredux | c-wasm / v8 | run | 5 | 2121.984 | 11.871 | 0.514 | 2570.426 | 135762480 |
| CLBG::Fannkuchredux | c-wasm / v8 | test | 1 | 0.020 | 0.000 | 0.503 | 27.501 | 4428 |
| CLBG::Fannkuchredux | c-wasm / wasmtime | run | 5 | 1482.628 | 0.444 | 22.891 | 1878.459 | 135762480 |
| CLBG::Fannkuchredux | c-wasm / wasmtime | test | 1 | 0.054 | 0.000 | 25.772 | 105.686 | 4428 |
| CLBG::Fannkuchredux | direct / v8 | run | 5 | 1244.110 | 4.473 | 0.223 | 1523.661 | 135762480 |
| CLBG::Fannkuchredux | direct / v8 | test | 1 | 0.028 | 0.000 | 0.296 | 27.487 | 4428 |
| CLBG::Fannkuchredux | direct / wasmtime | run | 5 | 1348.711 | 6.451 | 4.496 | 1704.537 | 135762480 |
| CLBG::Fannkuchredux | direct / wasmtime | test | 1 | 0.024 | 0.000 | 4.623 | 113.659 | 4428 |
| CLBG::Fannkuchredux | native / native | run | 5 | 1320.629 | 5.850 | — | 1569.202 | 135762480 |
| CLBG::Fannkuchredux | native / native | test | 1 | 0.021 | 0.000 | — | 1.227 | 4428 |
| CLBG::Mandelbrot | c-wasm / v8 | run | 5 | 952.702 | 4.516 | 0.601 | 1186.288 | 3455988829 |
| CLBG::Mandelbrot | c-wasm / v8 | test | 1 | 0.334 | 0.000 | 0.644 | 31.714 | 2236342953 |
| CLBG::Mandelbrot | c-wasm / wasmtime | run | 5 | 1075.657 | 8.360 | 23.350 | 1399.505 | 3455988829 |
| CLBG::Mandelbrot | c-wasm / wasmtime | test | 1 | 0.219 | 0.000 | 21.690 | 129.791 | 2236342953 |
| CLBG::Mandelbrot | direct / v8 | run | 5 | 962.559 | 5.101 | 0.234 | 1202.659 | 3455988829 |
| CLBG::Mandelbrot | direct / v8 | test | 1 | 0.375 | 0.000 | 0.196 | 28.040 | 2236342953 |
| CLBG::Mandelbrot | direct / wasmtime | run | 5 | 1003.734 | 3.529 | 3.653 | 1291.459 | 3455988829 |
| CLBG::Mandelbrot | direct / wasmtime | test | 1 | 0.188 | 0.000 | 4.294 | 110.417 | 2236342953 |
| CLBG::Mandelbrot | native / native | run | 5 | 921.341 | 3.048 | — | 1110.818 | 3455988829 |
| CLBG::Mandelbrot | native / native | test | 1 | 0.307 | 0.000 | — | 3.627 | 2236342953 |
| Etc::Sieve | c-wasm / v8 | run | 5 | 6099.737 | 395.337 | 0.617 | 7589.162 | 1042248060 |
| Etc::Sieve | c-wasm / v8 | test | 1 | 0.019 | 0.000 | 0.632 | 29.750 | 4660 |
| Etc::Sieve | c-wasm / wasmtime | run | 5 | 5344.591 | 49.847 | 24.426 | 6532.882 | 1042248060 |
| Etc::Sieve | c-wasm / wasmtime | test | 1 | 0.049 | 0.000 | 26.538 | 110.805 | 4660 |
| Etc::Sieve | direct / v8 | run | 5 | 1331.880 | 12.135 | 0.222 | 1645.982 | 1042248060 |
| Etc::Sieve | direct / v8 | test | 1 | 0.028 | 0.000 | 0.357 | 46.971 | 4660 |
| Etc::Sieve | direct / wasmtime | run | 5 | 1646.351 | 10.380 | 3.487 | 2060.480 | 1042248060 |
| Etc::Sieve | direct / wasmtime | test | 1 | 0.021 | 0.000 | 3.449 | 81.542 | 4660 |
| Etc::Sieve | native / native | run | 5 | 860.199 | 5.991 | — | 1036.230 | 1042248060 |
| Etc::Sieve | native / native | test | 1 | 0.005 | 0.000 | — | 3.932 | 4660 |
| Hash::CRC32 | c-wasm / v8 | run | 5 | 452.356 | 1.132 | 0.561 | 579.746 | 2318723244 |
| Hash::CRC32 | c-wasm / v8 | test | 1 | 0.014 | 0.000 | 0.642 | 30.333 | 3031698216 |
| Hash::CRC32 | c-wasm / wasmtime | run | 5 | 411.802 | 4.964 | 24.522 | 606.069 | 2318723244 |
| Hash::CRC32 | c-wasm / wasmtime | test | 1 | 0.051 | 0.000 | 25.169 | 106.214 | 3031698216 |
| Hash::CRC32 | direct / v8 | run | 5 | 504.247 | 2.475 | 0.229 | 646.913 | 2318723244 |
| Hash::CRC32 | direct / v8 | test | 1 | 0.017 | 0.000 | 0.254 | 24.123 | 3031698216 |
| Hash::CRC32 | direct / wasmtime | run | 5 | 426.587 | 1.130 | 3.649 | 607.250 | 2318723244 |
| Hash::CRC32 | direct / wasmtime | test | 1 | 0.024 | 0.000 | 3.683 | 106.168 | 3031698216 |
| Hash::CRC32 | native / native | run | 5 | 1363.007 | 6.690 | — | 1645.666 | 2318723244 |
| Hash::CRC32 | native / native | test | 1 | 0.028 | 0.000 | — | 2.033 | 3031698216 |
| Hash::SHA256 | c-wasm / v8 | run | 5 | 1039.279 | 8.003 | 0.558 | 1298.476 | 2844672256 |
| Hash::SHA256 | c-wasm / v8 | test | 1 | 0.007 | 0.000 | 0.569 | 25.882 | 1036619072 |
| Hash::SHA256 | c-wasm / wasmtime | run | 5 | 945.799 | 5.088 | 23.837 | 1264.504 | 2844672256 |
| Hash::SHA256 | c-wasm / wasmtime | test | 1 | 0.045 | 0.000 | 21.901 | 103.443 | 1036619072 |
| Hash::SHA256 | direct / v8 | run | 5 | 259.946 | 0.404 | 0.273 | 355.557 | 2844672256 |
| Hash::SHA256 | direct / v8 | test | 1 | 0.003 | 0.000 | 0.256 | 27.905 | 1036619072 |
| Hash::SHA256 | direct / wasmtime | run | 5 | 326.555 | 1.819 | 5.094 | 484.332 | 2844672256 |
| Hash::SHA256 | direct / wasmtime | test | 1 | 0.017 | 0.000 | 4.894 | 111.303 | 1036619072 |
| Hash::SHA256 | native / native | run | 5 | 583.572 | 4.694 | — | 705.480 | 2844672256 |
| Hash::SHA256 | native / native | test | 1 | 0.003 | 0.000 | — | 3.535 | 1036619072 |
| Sort::Merge | c-wasm / v8 | run | 5 | 1317.884 | 2.958 | 0.577 | 1618.905 | 61757772 |
| Sort::Merge | c-wasm / v8 | test | 1 | 15.469 | 0.000 | 0.667 | 62.846 | 2548773 |
| Sort::Merge | c-wasm / wasmtime | run | 5 | 2699.813 | 3.670 | 25.186 | 3350.739 | 61757772 |
| Sort::Merge | c-wasm / wasmtime | test | 1 | 23.731 | 0.000 | 40.264 | 185.388 | 2548773 |
| Sort::Merge | direct / v8 | run | 5 | 1856.918 | 6.959 | 0.267 | 2268.704 | 61757772 |
| Sort::Merge | direct / v8 | test | 1 | 17.346 | 0.000 | 0.232 | 55.694 | 2548773 |
| Sort::Merge | direct / wasmtime | run | 5 | 2027.940 | 29.163 | 3.947 | 2510.038 | 61757772 |
| Sort::Merge | direct / wasmtime | test | 1 | 17.449 | 0.000 | 4.380 | 140.026 | 2548773 |
| Sort::Merge | native / native | run | 5 | 1396.474 | 6.466 | — | 1677.924 | 61757772 |
| Sort::Merge | native / native | test | 1 | 13.406 | 0.000 | — | 23.100 | 2548773 |
| Sort::Quick | c-wasm / v8 | run | 5 | 1410.588 | 5.510 | 0.517 | 1726.283 | 61757772 |
| Sort::Quick | c-wasm / v8 | test | 1 | 19.922 | 0.000 | 0.803 | 78.304 | 2548773 |
| Sort::Quick | c-wasm / wasmtime | run | 5 | 1638.358 | 9.278 | 23.162 | 2072.797 | 61757772 |
| Sort::Quick | c-wasm / wasmtime | test | 1 | 15.758 | 0.000 | 23.562 | 130.028 | 2548773 |
| Sort::Quick | direct / v8 | run | 5 | 1331.818 | 2.559 | 0.230 | 1632.270 | 61757772 |
| Sort::Quick | direct / v8 | test | 1 | 13.006 | 0.000 | 0.207 | 48.021 | 2548773 |
| Sort::Quick | direct / wasmtime | run | 5 | 1737.443 | 64.627 | 4.076 | 2164.017 | 61757772 |
| Sort::Quick | direct / wasmtime | test | 1 | 15.576 | 0.000 | 3.717 | 110.553 | 2548773 |
| Sort::Quick | native / native | run | 5 | 1218.322 | 3.187 | — | 1463.264 | 61757772 |
| Sort::Quick | native / native | test | 1 | 11.924 | 0.000 | — | 21.067 | 2548773 |

## Qualification and limits

- Seven adapted entrypoints (six change storage, one changes only the harness) are a subset of the 50-task catalog; they do not establish unmodified whole-suite Wasm support.
- No local result is a LangArena leaderboard rank: source/compiler versions, target layout, host, flags, and coverage differ.
- Cold builds retain OS and compiler system-library caches; they are complete uncached driver builds, not disk-cold experiments.

The full 50-task coverage matrix, raw commands/output, source and artifact hashes, tool versions, input values, environment overrides (including `EM_NODE_JS`), and phase timings are in `report.json` and adjacent logs. `Hash::SHA256` retains LangArena's custom hash workload; it is not standard cryptographic SHA-256.
