"""Prove the new Ninja regression rejects the prior timestamp behavior."""
from pathlib import Path
import json,sys,unittest
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'oracle/tests'))
import test_bootstrap as tests
original=tests.BOOTSTRAP.shutil.copyfile

def preserving_copy(source,destination,*args,**kwargs):
 result=original(source,destination,*args,**kwargs)
 tests.BOOTSTRAP.shutil.copystat(source,destination)
 return result

tests.BOOTSTRAP.shutil.copyfile=preserving_copy
try:
 suite=unittest.TestSuite([tests.ManagedSource('test_restoring_an_older_header_rebuilds_the_artifact')])
 result=unittest.TextTestRunner(verbosity=2).run(suite)
 assert len(result.failures)==1 and not result.errors and not result.skipped,'old behavior must fail the artifact assertion'
 Path(__file__).with_name('regression-control.json').write_text(json.dumps({'status':'expected-failure-confirmed','tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'scope':'Only copyfile timestamp preservation is replaced with previous copy2 behavior; regression runs real Ninja and detects stale artifact content.'},indent=2)+'\n')
finally:
 tests.BOOTSTRAP.shutil.copyfile=original
