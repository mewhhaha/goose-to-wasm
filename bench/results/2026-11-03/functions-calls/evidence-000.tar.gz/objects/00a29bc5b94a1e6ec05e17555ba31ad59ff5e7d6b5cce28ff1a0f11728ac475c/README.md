# Example program benchmarks

Status: **passed**.

2026-11-03 · AMD Ryzen 7 3800X, shared desktop host.

Goose O2. Direct Wasm uses memory32; C-Wasm uses memory64. The selected programs, their constant inputs and all printing are unchanged from the [example catalog](../../../../examples/README.md). Compiler constant folding is allowed.

Builds are complete uncached Python-driver invocations, including any C compilation/linking. OS page caches and Emscripten's installed system-library cache remain warm.

Runtime is **whole-process launch-to-exit time**, including host startup, Wasm compilation/instantiation, program initialization, computation, output delivery and teardown. Each observation starts a fresh process/instance and calls the entrypoint once. This measures CLI cost, not warmed kernel throughput.

Each cell has 5 build samples or 15 runtime samples. Untimed fresh-process warmups per runtime cell: 1. Orders are shuffled with the recorded seed; builds and runtime never overlap. Every used artifact must pass its golden output. Values are median milliseconds ± median absolute deviation (MAD).

Headline runtime samples use the ordinary runners without timing-file instrumentation. The Wasm supplements use a separate shuffled set of fresh processes, with the same sample count; timing files are written after their engine intervals end.

## Compilation

| Example | Direct | C-Wasm | Native C |
| --- | ---: | ---: | ---: |
| squares | 61.793 ±3.157 | 500.790 ±15.674 | 200.964 ±11.941 |
| tour | 62.852 ±1.054 | 921.642 ±6.431 | 403.225 ±7.609 |
| functions | 79.638 ±1.916 | 875.814 ±1.890 | 507.805 ±17.794 |
| errors | 68.780 ±0.882 | 665.384 ±5.345 | 357.003 ±1.580 |
| sieve | 67.122 ±1.461 | 584.289 ±18.611 | 267.166 ±29.052 |
| sorting | 85.682 ±1.741 | 855.508 ±29.382 | 535.814 ±18.404 |
| sudoku | 71.114 ±4.050 | 524.370 ±12.622 | 256.899 ±3.135 |
| maze | 70.711 ±0.978 | 652.878 ±11.146 | 355.727 ±22.486 |
| vm | 67.419 ±1.671 | 662.127 ±15.502 | 275.886 ±4.032 |
| life | 66.833 ±1.226 | 621.652 ±26.651 | 312.156 ±24.264 |

## Whole-process runtime

| Example | Direct / V8 | C-Wasm / V8 | Direct / Wasmtime | C-Wasm / Wasmtime | Native C |
| --- | ---: | ---: | ---: | ---: | ---: |
| squares | 38.035 ±6.748 | 29.779 ±5.697 | 69.966 ±3.589 | 83.173 ±5.825 | 1.012 ±0.245 |
| tour | 43.153 ±2.763 | 43.472 ±8.703 | 122.166 ±6.272 | 123.505 ±8.335 | 0.854 ±0.076 |
| functions | 31.804 ±1.998 | 33.672 ±5.587 | 103.286 ±14.804 | 120.933 ±10.185 | 1.294 ±0.043 |
| errors | 28.301 ±2.308 | 31.350 ±5.834 | 79.029 ±3.856 | 89.408 ±4.273 | 0.884 ±0.156 |
| sieve | 29.345 ±3.643 | 32.946 ±4.849 | 88.427 ±12.215 | 105.646 ±6.589 | 1.467 ±0.409 |
| sorting | 61.012 ±7.983 | 227.630 ±6.963 | 125.494 ±11.073 | 250.273 ±19.691 | 45.765 ±0.815 |
| sudoku | 32.056 ±3.352 | 33.300 ±2.829 | 77.265 ±2.957 | 91.407 ±5.121 | 4.111 ±0.189 |
| maze | 28.807 ±3.011 | 31.975 ±4.417 | 82.502 ±6.143 | 92.730 ±9.279 | 1.068 ±0.166 |
| vm | 31.552 ±4.892 | 29.816 ±2.581 | 102.900 ±8.605 | 95.329 ±10.775 | 1.237 ±0.193 |
| life | 38.752 ±4.771 | 45.814 ±9.656 | 90.066 ±7.589 | 94.541 ±6.058 | 23.199 ±5.195 |

## Supplement: Wasm entrypoint

| Example | Direct / V8 | C-Wasm / V8 | Direct / Wasmtime | C-Wasm / Wasmtime |
| --- | ---: | ---: | ---: | ---: |
| squares | 0.211 ±0.054 | 0.929 ±0.016 | 0.128 ±0.005 | 0.622 ±0.011 |
| tour | 15.062 ±1.999 | 2.610 ±0.068 | 1.723 ±0.009 | 1.694 ±0.015 |
| functions | 5.536 ±0.621 | 2.628 ±0.101 | 1.342 ±0.008 | 1.899 ±0.014 |
| errors | 2.847 ±0.172 | 1.719 ±0.042 | 0.848 ±0.011 | 1.680 ±0.020 |
| sieve | 2.636 ±0.411 | 1.800 ±0.035 | 1.206 ±0.011 | 1.321 ±0.012 |
| sorting | 22.467 ±0.301 | 194.725 ±3.394 | 15.934 ±0.058 | 123.126 ±1.668 |
| sudoku | 5.309 ±0.236 | 9.108 ±2.567 | 3.781 ±0.026 | 8.315 ±0.043 |
| maze | 2.314 ±0.065 | 2.575 ±0.734 | 0.765 ±0.010 | 2.228 ±0.022 |
| vm | 3.018 ±0.450 | 2.264 ±0.166 | 0.899 ±0.008 | 2.963 ±0.028 |
| life | 10.980 ±3.167 | 10.044 ±0.438 | 6.280 ±0.041 | 9.495 ±0.076 |

## Supplement: Wasm engine compilation and instantiation

| Example | Direct / V8 | C-Wasm / V8 | Direct / Wasmtime | C-Wasm / Wasmtime |
| --- | ---: | ---: | ---: | ---: |
| squares | 0.241 ±0.036 | 0.456 ±0.030 | 2.806 ±0.230 | 11.309 ±1.481 |
| tour | 0.410 ±0.077 | 0.555 ±0.075 | 30.876 ±0.794 | 44.360 ±8.536 |
| functions | 0.345 ±0.073 | 0.497 ±0.019 | 18.042 ±1.154 | 28.400 ±1.314 |
| errors | 0.385 ±0.048 | 0.580 ±0.077 | 12.184 ±1.009 | 18.101 ±2.272 |
| sieve | 0.260 ±0.041 | 0.477 ±0.031 | 8.149 ±0.933 | 13.457 ±2.213 |
| sorting | 0.339 ±0.042 | 0.548 ±0.052 | 20.327 ±2.260 | 30.933 ±1.490 |
| sudoku | 0.246 ±0.030 | 0.629 ±0.101 | 5.710 ±0.883 | 11.117 ±1.196 |
| maze | 0.294 ±0.025 | 0.555 ±0.103 | 11.641 ±1.911 | 15.153 ±1.520 |
| vm | 0.326 ±0.068 | 0.559 ±0.068 | 18.765 ±3.896 | 16.084 ±1.721 |
| life | 0.331 ±0.050 | 0.538 ±0.065 | 11.935 ±2.526 | 13.936 ±1.167 |

The entrypoint interval includes Goose initialization, host output callbacks and any lazy JIT work. It excludes final Wasm-host output concatenation/delivery. Native Goose prints unbuffered, so no native entrypoint column or cross-boundary speedup is presented. Process time minus engine time also includes loading, bookkeeping and teardown; it is not a pure startup measurement.

These fresh-process examples have different timing rules from LangArena's warmed computational regions. Raw samples, commands, artifact/source/compiler identities and engine versions are in [report.json](report.json). [Method and reproduction](../../../examples.md).
