# Copy draft — pending final qualification and fresh cohorts

Use only closed, verified final reports for all bracketed values. Exploratory screening does not establish delivered timing results. Keep the prior forwarding cohort separate.

## README.md

Update the seven-port direct and C-to-Wasm compile ranges from the final cohort and point the existing results link at `bench/results/2026-11-03/functions-calls/README.md`. Preserve the current benchmark-focused layout; add no implementation discussion.

## docs/FUNCTIONS_PERFORMANCE.md

# Functions performance

The direct backend forwards eligible tail-only identity wrappers into an ordinary internal named call. It feeds original argument expressions into the ordinary caller's snapshot path, preserving full first snapshots in source order and the callee's finish copies. It excludes captures, remaps, arguments requiring materialization, multiple returns, and non-fixed, reference, slice or mutable parameters.

Memory growth sites share a helper for actual growth. The caller retains its fast guard, abort behavior, source attribution and reentry behavior; the helper is called only when growth is needed. In Functions, 51 sites share a 25-byte helper.

Functions shrank from 42,296 to 39,564 bytes (6.46%); static `memory.copy` instructions fell from 317 to 267, and declared locals from 2,019 to 1,919. Public imports, memory, globals, exports and data are unchanged; internal type and function sections changed. The baseline includes the [earlier forwarding step](../bench/results/2026-11-03/functions-forwarding/README.md), measured in a separate cohort.

[Final paired CPU 2 phase results, including medians, paired ratio and MAD; identify startup, first entry and body boundaries.] [Independent normal-pool holdout, paired ratios and MAD; characterize uncertainty.] [Fresh process and warmed cohort results, including preparation exclusions, noise controls and any regressions.] Do not infer a process or execution gain from a compilation measurement.

[Final qualification counts and links.] [Ablation and rejected experiments: name each measured variant, outcome and tradeoff using verified results; distinguish unmeasured ideas.] During development a restored source header retained an old timestamp, allowing Ninja to reuse a named-only binary. Bootstrap now gives changed header bytes a new timestamp and preserves the timestamp when bytes are unchanged; the Ninja regression test fails with the old copy behavior and passes with the fix. Frozen exploratory compilers used for screening had the intended bytes; the stale attempt was not timed.

[Measurements, compiler identities and raw samples](../bench/results/2026-11-03/functions-calls/README.md).

## bench/results/2026-11-03/functions-calls/README.md

# Functions calls and memory growth · November 3, 2026

Compiler SHA-256 `864262133e821068738b24952324a3145ba74a926ad7135c6cb15f7baba1f04a` is compared with compiler `19d377d68530e0cf5b59f6d28f7b1a2ca207b9ed981dfad29dedf7fa5723473b` on [machine identity]. Goose upstream is [revision]; Wasmtime is [version and host build identities] and Node is [version] / V8 [version]. [Disclose any separately built or collected reference artifacts.]

Eligible named-call forwarding and a shared growth helper reduced the Functions module from 42,296 to 39,564 bytes, static `memory.copy` instructions from 317 to 267, and declared locals from 2,019 to 1,919. Public imports, memory, globals, exports and data are unchanged; internal type and function sections changed. The [Functions investigation](../../../../docs/FUNCTIONS_PERFORMANCE.md) describes the constraints and retained experiments. The [prior forwarding cohort](../functions-forwarding/README.md) is a separate compiler comparison.

[Links to five final fresh cohort reports, with sample counts, workloads and checked-output method.] [Record whether warmed modules changed; identify identical modules as noise controls.] [Link final CPU 2 and default-affinity holdouts, counts, medians, paired ratios and MAD; report uncertainty and any regressions.] CPU 2 constrains inherited engine workers; normal-pool process measurements are independent. Process launches include startup, ordinary launches include compilation, and precompiled runs exclude preparation. First entry includes initialization and callbacks; V8 includes lazy JIT. Warmed body measurements use a separate boundary.

[Final focused, differential and host qualification counts; links to raw reports and compiler identity.] [Brief verified ablation and rejected-experiment outcomes; link evidence.] [Bootstrap timestamp fix and regression evidence, if published; explain that the stale attempt was never timed.]

## Other current benchmark pages

- `bench/examples.md`: replace current process medians and MADs, example cold-build ranges, compiler identity and current evidence link from final reports. Preserve separately identified historical boundary probes.
- `bench/wasmtime-host.md`: replace current compiler identity, four-row host table, qualification counts and current evidence link from final reports. Keep separately dated reference cohort distinct; precompiled results exclude preparation.
- `docs/RUNTIME_TARGETS.md`: replace the ten current rows from the final warmed report and update its evidence link. Preserve the frozen reference selection and method; identify separately built references.
- `docs/PERFORMANCE_PLAN.md`: update the Functions pointer only if needed to reflect the delivered step and confirmed results.
