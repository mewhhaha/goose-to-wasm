#!/usr/bin/env python3
"""Explicitly seal, qualify, then replay one Functions candidate; never measure it.

Source preparation is safe during measurement. Every phase below needs the
coordinator's separate CPU window. Existing results are never overwritten.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import concurrent.futures
import hashlib
import json
import os
import shutil
import signal
import subprocess
import sys
import threading
import time

ROOT=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parent
CAPS={name:'1' for name in ('EMCC_CORES','BINARYEN_CORES','RAYON_NUM_THREADS','OMP_NUM_THREADS')}
EXPECTED={'focused_commands':69,'differential_observations':9573,'native_stdout_comparisons':7656,'cases':978,'host_observations':11484}
FORWARDING_REFERENCE=ROOT/'build/functions-grow/slow-helper/bin/goose'
FORWARDING_REFERENCE_SHA='33a9fb04cb2d0847443232bf75d266a0be080b3195f78a9773d12b04cdd58698'
MEMORY_REFERENCE=ROOT/'build/functions-next/forward-v3/bin/goose'
MEMORY_REFERENCE_SHA='19d377d68530e0cf5b59f6d28f7b1a2ca207b9ed981dfad29dedf7fa5723473b'


def require(value,message):
    if not value: raise RuntimeError(message)


def load(path): return json.loads(Path(path).read_bytes())


def sha(path):
    with Path(path).open('rb') as source: return hashlib.file_digest(source,'sha256').hexdigest()


def save(path,value): Path(path).write_text(json.dumps(value,indent=2)+'\n')


def small_snapshot(compiler_sha,source_root,provisional=False):
    """Copy only 32 headers, two patches, build metadata and both regression tests."""
    metadata=load(source_root/'toolchain.json'); source=load(source_root/'source.json')
    require(metadata['compiler_sha256']==compiler_sha,'snapshot compiler identity differs')
    require(source['headers']==metadata['headers'] and source['patches']==metadata['patches'],'snapshot source metadata differs')
    require(len(source['headers'])==32 and len(source['patches'])==2,'unexpected source inventory')
    folder=HERE/'sources'/compiler_sha
    inputs={}
    for name,expected in source['headers'].items():
        paths=[source_root/'compiler'/name,ROOT/'compiler'/name,ROOT/'build/source/src'/name]
        original=next((path for path in paths if path.is_file() and sha(path)==expected),None)
        require(original is not None,'matching header unavailable: '+name)
        inputs['compiler/'+name]=(original,expected)
    for name,expected in source['patches'].items():
        original=ROOT/name
        require(sha(original)==expected,'patch differs: '+name)
        inputs[name]=(original,expected)
    for name,original in [('source.json',source_root/'source.json'),('toolchain.json',source_root/'toolchain.json'),
                          ('toolchain-pin.json',ROOT/'toolchain.json'),('test_local_tee.py',ROOT/'tests/test_local_tee.py'),
                          ('test_function_value_forwarding.py',ROOT/'tests/test_function_value_forwarding.py'),
                          ('test_named_callback_forwarding.py',ROOT/'tests/test_named_callback_forwarding.py'),
                          ('test_memory_growth_helper.py',ROOT/'tests/test_memory_growth_helper.py')]:
        inputs[name]=(original,sha(original))
    folder.mkdir(parents=True,exist_ok=True)
    for name,(original,expected) in inputs.items():
        destination=folder/name;destination.parent.mkdir(parents=True,exist_ok=True)
        if destination.exists(): require(sha(destination)==expected,'refusing to replace source snapshot: '+name)
        else: shutil.copyfile(original,destination)
    manifest={'status':'provisional-source-only','compiler_sha256':compiler_sha,'compiler_bytes_verified':False,
              'provisional':provisional,'source_root':str(source_root),'input_sha256':{name:value[1] for name,value in inputs.items()},
              'resolved_sources':{name:str(value[0]) for name,value in inputs.items()},
              'scope':'32 headers, two patches, metadata and both regression tests only; no repository or old results tree copy.'}
    path=folder/'snapshot.json'
    if not path.exists(): save(path,manifest)
    return folder


def inputs(run,selected):
    paths={Path(__file__).resolve(),HERE/'control.py',HERE/'plan.json',HERE/'prior-evidence.json',run/'plan.json',
           ROOT/'build/bin/goose',ROOT/'build/bin/goose-wasmtime',ROOT/'build/bin/goose-wasmtime.json',
           ROOT/'build/source.json',ROOT/'build/toolchain.json',ROOT/'toolchain.json',ROOT/'requirements.txt',
           ROOT/'docs/capabilities.json',ROOT/'.github/workflows/ci.yml',ROOT/'build/native/CMakeCache.txt'}
    for folder,patterns in [('compiler',('*.h',)),('scripts',('*.py','*.mjs')),('oracle',('*.py',)),
                            ('oracle/tests',('*.py',)),
                            ('tests',('*.py',)),('tests/fixtures',('*.goose','*.json')),
                            ('bench',('*.py','*.c')),('bench/langarena',('*.json',)),
                            ('bench/langarena/ports',('*.goose',)),('examples',('*.goose','*.py','*.json')),
                            ('examples/expected',('*.out',)),('capabilities',('*.json',)),('host',('*.cpp','*.json')),
                            ('build/bin/stdlib',('*.goose',)),('build/bin/include',('**/*.h',))]:
        for pattern in patterns: paths.update((ROOT/folder).glob(pattern))
    source=load(ROOT/'build/source.json')
    paths.update(ROOT/name for name in source['patches'])
    paths.update(ROOT/'build/source/src'/name for name in ('ast.h','builtins.h','clone.h'))
    snapshot=Path(selected['source_snapshot'])
    paths.update(snapshot/name for name in load(snapshot/'snapshot.json')['input_sha256'])
    paths.add(snapshot/'snapshot.json')
    reference=Path(selected['resource_reference'])
    paths.add(reference)
    for key in ('forwarding_reference','memory_reference'):
        baseline=Path(selected[key])
        base_root=baseline.parent.parent
        paths.update((baseline,base_root/'source.json',base_root/'toolchain.json'))
    control=reference.parent.parent.parent
    paths.update(control/name for name in ('preparation.json','direct_wasm_temps.before.h',
                 'disable-resource-free-block.patch','build-execution.json','build.log'))
    paths.add(reference.parent.parent/'control-toolchain-match.json')
    paths.update((control/'shadow').rglob('*.h'))
    paths.update((control/'shadow').rglob('*.patch'))
    paths.update((control/'shadow').rglob('*.py'))
    paths.add(control/'shadow/toolchain.json')
    for root in (reference.parent,reference.parent.parent):
        for name in ('source.json','toolchain.json'):
            if (root/name).is_file(): paths.add(root/name)
        if (root/'native/CMakeCache.txt').is_file(): paths.add(root/'native/CMakeCache.txt')
        if (root/'control-toolchain-match.json').is_file(): paths.add(root/'control-toolchain-match.json')
        paths.update((root/'compiler').glob('*.h'))
        paths.update((root/'stdlib').glob('*.goose'))
        paths.update((root/'include').glob('**/*.h'))
    for name in ('node','emcc','gcc','c++','clang'):
        location=shutil.which(name)
        if location: paths.add(Path(location).resolve())
    paths.add(Path(sys.executable).resolve())
    import wasmtime._ffi as ffi
    paths.add(Path(ffi.dll._name).resolve())
    host=load(ROOT/'build/bin/goose-wasmtime.json')
    paths.add(Path(host['library']))
    paths.update(Path(name) for name in host['input_sha256'])
    require(all(path.is_file() for path in paths),'one or more bounded qualification inputs are unavailable')
    return sorted(paths)


def verify(run,selected,pins):
    require(sha(ROOT/'build/bin/goose')==selected['compiler_sha256'],'selected compiler changed')
    require({str(path) for path in inputs(run,selected)}==set(pins),'qualification input inventory changed')
    require(all(sha(path)==value for path,value in pins.items()),'qualification input bytes changed')


def seal(args,run):
    require(args.compiler_sha and args.resource_reference,'seal requires --compiler-sha and --resource-reference')
    require(not (run/'selected.json').exists(),'refusing to replace a sealed run; use a new --output-dir')
    require(sha(ROOT/'build/bin/goose')==args.compiler_sha,'compiler differs from explicit selected SHA')
    require(os.access(FORWARDING_REFERENCE,os.X_OK),'forwarding baseline is not executable')
    require(sha(FORWARDING_REFERENCE)==FORWARDING_REFERENCE_SHA,'forwarding baseline compiler differs')
    baseline_source=load(FORWARDING_REFERENCE.parent.parent/'source.json')
    baseline_toolchain=load(FORWARDING_REFERENCE.parent.parent/'toolchain.json')
    require(baseline_toolchain['compiler_sha256']==FORWARDING_REFERENCE_SHA and
            baseline_toolchain['headers']==baseline_source['headers'] and
            baseline_toolchain['patches']==baseline_source['patches'],'forwarding baseline source metadata differs')
    require(os.access(MEMORY_REFERENCE,os.X_OK),'memory-helper baseline is not executable')
    require(sha(MEMORY_REFERENCE)==MEMORY_REFERENCE_SHA,'memory-helper baseline compiler differs')
    memory_source=load(MEMORY_REFERENCE.parent.parent/'source.json')
    memory_toolchain=load(MEMORY_REFERENCE.parent.parent/'toolchain.json')
    require(memory_toolchain['compiler_sha256']==MEMORY_REFERENCE_SHA and
            memory_toolchain['headers']==memory_source['headers'] and
            memory_toolchain['patches']==memory_source['patches'],'memory-helper baseline source metadata differs')
    snapshot=small_snapshot(args.compiler_sha,ROOT/'build')
    reference=args.resource_reference.resolve()
    control_root=reference.parent
    if not (control_root/'toolchain.json').is_file(): control_root=control_root.parent
    control=load(control_root/'toolchain.json'); current=load(ROOT/'build/toolchain.json')
    require(set(control['headers'])==set(current['headers']),'resource control header inventory differs')
    for name,expected in control['headers'].items():
        path=control_root/'compiler'/name
        require(path.is_file() and sha(path)==expected,'resource control frozen header differs: '+name)
    changed={name for name,value in current['headers'].items() if control['headers'].get(name)!=value}
    require(control['revision']==current['revision'] and control['patches']==current['patches'],'resource control upstream/patches differ')
    require(changed=={'direct_wasm_temps.h'},'resource control may change only ResourceFreeBlock in direct_wasm_temps.h')
    before=(control_root.parent/'direct_wasm_temps.before.h').read_text()
    marker='inline bool Function::ResourceFreeBlock(Block *block) {\n'
    require(before.count(marker)==1,'resource control predicate marker differs')
    require((ROOT/'compiler/direct_wasm_temps.h').read_text()==before,'resource control before header differs from selected source')
    require((control_root/'compiler/direct_wasm_temps.h').read_text()==before.replace(marker,marker+'    return false;\n',1),'resource control differs beyond disabling ResourceFreeBlock')
    match=load(control_root/'control-toolchain-match.json')
    require(match['status']=='matched' and match['selected_compiler_sha256']==args.compiler_sha and
            match['control_compiler_sha256']==control['compiler_sha256'],'resource control toolchain proof differs')
    require(sha(reference)==control['compiler_sha256'],'resource control binary differs from its metadata')
    selected={'compiler_sha256':args.compiler_sha,'compiler_bytes_verified':True,'resource_reference':str(reference),
              'forwarding_reference':str(FORWARDING_REFERENCE),'forwarding_reference_sha256':FORWARDING_REFERENCE_SHA,
              'memory_reference':str(MEMORY_REFERENCE),'memory_reference_sha256':MEMORY_REFERENCE_SHA,
              'resource_control_header_differences':sorted(changed),'resource_control_sha256':control['compiler_sha256'],
              'source_snapshot':str(snapshot),'expected':EXPECTED,'created_utc':datetime.now(timezone.utc).isoformat(),
              'coverage':'Previous67 gates plus named-callback and memory-growth-helper regressions; exact six differential shards, then separate host replay.',
              'historical_unique_host_modules':1574,'unique_host_module_policy':'Derived from current module hashes; historical count is not an acceptance target.'}
    run.mkdir(parents=True,exist_ok=True);shutil.copyfile(HERE/'plan.json',run/'plan.json')
    pins={str(path):sha(path) for path in inputs(run,selected)}
    save(run/'input-pins.json',pins);save(run/'selected.json',selected)
    print('SEALED',args.compiler_sha,len(pins),'bounded inputs; no tests/builds/guests executed',flush=True)


def focused(run,selected,pins,environment):
    output=run/'focused';output.mkdir(parents=True,exist_ok=True)
    report={'status':'running','compiler_sha256':selected['compiler_sha256'],'commands':[]}
    commands=load(run/'plan.json')['commands'];require(len(commands)==69,'focused inventory differs')
    require(not (output/'report.json').exists(),'refusing to replace focused results')
    for index,parts in enumerate(commands):
        require(sha(ROOT/'build/bin/goose')==selected['compiler_sha256'],'compiler changed during focused gates')
        require(not (run/'stop').exists(),'qualification stop marker exists')
        command=[sys.executable,*[part.format(run=str(run),resource_reference=selected['resource_reference'],
                                            forwarding_reference=selected['forwarding_reference'],
                                            memory_reference=selected['memory_reference']) for part in parts]]
        log=output/(str(index).zfill(2)+'-'+Path(parts[0]).stem+'.log')
        print('START',index,parts[0],flush=True);started=time.monotonic()
        with log.open('w') as stream: result=subprocess.run(command,cwd=ROOT,env=environment,stdout=stream,stderr=subprocess.STDOUT)
        row={'command':command,'exit_status':result.returncode,'wall_seconds':time.monotonic()-started,'log':str(log),'script_sha256':pins[str(ROOT/parts[0])]}
        report['commands'].append(row);save(output/'report.json',report)
        print('DONE',index,result.returncode,flush=True)
        if result.returncode:
            report['status']='failed';save(output/'report.json',report);return result.returncode
    report['status']='passed';save(output/'report.json',report);return 0


def gates(args,run,selected,pins,environment):
    require(not (run/'execution.json').exists(),'refusing to replace prior gate results')
    verify(run,selected,pins)
    sys.path.insert(0,str(ROOT/'bench'));import qualify_compiler as merger
    sys.path.insert(0,str(ROOT/'tests'));from run_differential import cases
    matrix=cases();require(len(matrix)==EXPECTED['cases'],'differential case inventory changed')
    diff=run/'differential';diff.mkdir(parents=True,exist_ok=True)
    jobs=[('focused',[sys.executable,str(Path(__file__).resolve()),'focused','--output-dir',str(run)],run/'focused-runner.log')]
    configurations={};commands={}
    for backend in merger.BACKENDS:
        for level in merger.LEVELS:
            key=(backend,level);name=f'{backend}-O{level}';configuration=merger.expected_configuration(backend,level,'')
            configurations[key]=configuration
            command=[sys.executable,str(ROOT/'tests/run_differential.py'),'--goose',str(ROOT/'build/bin/goose'),
                     '--backends',backend,'--levels',str(level),'--engines','v8','wasmtime','--output-dir',str(diff/'shards'/name)]
            if configuration['skip_refusals']: command.append('--skip-refusals')
            commands[key]=command;jobs.append((name,command,diff/(name+'.log')))
    order={'c-wasm-O2':0,'c-wasm-O0':1,'focused':2,'native-O0':3,'direct-O2':4,'direct-O0':5,'native-O2':6}
    jobs.sort(key=lambda job:order[job[0]])
    lock=threading.Lock();abort=threading.Event();active={};rows=[]
    def stop():
        abort.set();(run/'stop').write_text('Stopped after a qualification failure; preserve this run.\n')
        with lock: processes=list(active.values())
        for process in processes:
            if process.poll() is None:
                try: os.killpg(process.pid,signal.SIGTERM)
                except ProcessLookupError: pass
    def execute(job):
        name,command,log=job
        if abort.is_set(): return {'name':name,'status':'not-started'}
        print('START',name,flush=True);started=time.monotonic()
        with log.open('w') as stream:
            process=subprocess.Popen(command,cwd=ROOT,env=environment,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,start_new_session=True)
            with lock: active[name]=process
            for line in process.stdout:
                stream.write(line);stream.flush()
                if name=='focused': print(line.rstrip(),flush=True)
                if line.startswith(('FAIL ','FAIL:','ERROR:','FAILED (')): stop()
            code=process.wait()
        with lock: active.pop(name,None)
        if code: stop()
        print('DONE',name,code,flush=True)
        return {'name':name,'command':command,'exit_status':code,'wall_seconds':time.monotonic()-started,'log':str(log)}
    started=time.monotonic()
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.jobs) as pool:
        for future in concurrent.futures.as_completed([pool.submit(execute,job) for job in jobs]):
            rows.append(future.result());save(run/'execution.json',{'status':'running','jobs':args.jobs,'observations':rows})
    if abort.is_set():
        save(run/'execution.json',{'status':'failed','jobs':args.jobs,'observations':rows});raise RuntimeError('qualification failed; inspect retained logs')
    reports={}
    for key in configurations:
        path=diff/'shards'/f'{key[0]}-O{key[1]}'/'report.json';report=load(path)
        report['_report_sha256']=sha(path);report['_command']=commands[key];reports[key]=report
    combined,shards=merger.combine(reports,matrix,configurations,selected['compiler_sha256'],False)
    comparisons=sum(row['backend']!='native' and row.get('kind')!='compile-refusal' for row in combined['results'])
    require(combined['observations']==9573 and combined['failures']==0 and comparisons==7656,'differential exact counts differ')
    require(load(run/'focused/report.json')['status']=='passed' and len(load(run/'focused/report.json')['commands'])==69,'focused gate coverage differs')
    verify(run,selected,pins)
    combined['qualification_execution']={'method':'At most four total jobs: one sequential focused pipeline and six backend/O0,O2 shards; all qualification internal pools capped1.',
        'wall_seconds':time.monotonic()-started,'jobs':args.jobs,'shards':shards,'native_stdout_comparisons':comparisons,'input_sha256':pins,'internal_thread_limits':CAPS}
    save(diff/'report.json',combined)
    save(run/'execution.json',{'status':'passed','compiler_sha256':selected['compiler_sha256'],'expected':EXPECTED,
         'jobs':args.jobs,'observations':rows,'wall_seconds':time.monotonic()-started,'input_sha256':pins})
    print('PASS69 focused;9573 differential;7656 native comparisons',flush=True)


def host(args,run,selected,pins,environment):
    require(load(run/'execution.json')['status']=='passed','host replay requires passing gates')
    require(not (run/'host/report.json').exists(),'refusing to replace prior host replay')
    verify(run,selected,pins)
    command=[sys.executable,str(ROOT/'bench/qualify_wasmtime_host.py'),'--baseline-dir',str(run/'differential'),
             '--host',str(ROOT/'build/bin/goose-wasmtime'),'--output-dir',str(run/'host'),'--jobs',str(args.jobs)]
    started=time.monotonic()
    with (run/'host-runner.log').open('w') as stream: result=subprocess.run(command,cwd=ROOT,env=environment,stdout=stream,stderr=subprocess.STDOUT)
    execution={'command':command,'exit_status':result.returncode,'wall_seconds':time.monotonic()-started,'log':str(run/'host-runner.log')}
    save(run/'host-execution.json',execution);require(result.returncode==0,'host replay failed; inspect retained logs')
    report=load(run/'host/report.json')
    require(report['coverage_exact'] and report['failures']==0 and report['observations']==11484,'host replay exact coverage differs')
    verify(run,selected,pins)
    catalog(run)
    print('PASS11484 host observations;',report['unique_wasm'],'current unique modules',flush=True)


def catalog(run):
    # Record only guests produced in this bounded run. Historical archive
    # indexes use a different format and are left for the packager to assess.
    require(not (run/'artifact-catalog.json').exists(),'refusing to replace artifact catalog')
    objects={}
    paths=[path for path in run.rglob('*') if path.is_file() and path.suffix in {'.wasm','.bin','.cwasm'}]
    for path in sorted(paths):
        value=sha(path)
        if value in objects:
            objects[value]['fresh_paths'].append(str(path));continue
        row={'sha256':value,'bytes':path.stat().st_size,'fresh_paths':[str(path)]}
        row['retention']='fresh-run-byte-object'
        objects[value]=row
    save(run/'artifact-catalog.json',{'status':'catalogued','policy':'Only guests in this run were scanned; no historical aliases or archives are reused.',
        'fresh_paths':len(paths),'unique_objects':len(objects),'objects':objects})


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('phase',choices=['seal','gates','focused','host'])
    parser.add_argument('--output-dir',type=Path,default=HERE/'attempt-1')
    parser.add_argument('--compiler-sha')
    parser.add_argument('--resource-reference',type=Path)
    parser.add_argument('--jobs',type=int,default=4)
    args=parser.parse_args();require(1<=args.jobs<=4,'jobs must be1..4')
    require(__debug__,'assertions must remain enabled');run=args.output_dir.resolve()
    require(run.is_relative_to(HERE.resolve()),'qualification output must remain beneath bounded campaign directory')
    if args.phase=='seal': seal(args,run);return
    selected=load(run/'selected.json');pins=load(run/'input-pins.json');environment=os.environ.copy();environment.update(CAPS)
    if args.phase=='focused': raise SystemExit(focused(run,selected,pins,environment))
    if args.phase=='gates': gates(args,run,selected,pins,environment)
    if args.phase=='host': host(args,run,selected,pins,environment)


if __name__=='__main__': main()
