#!/usr/bin/env python3
"""Build a matched control that disables only named-tail callback forwarding."""
from pathlib import Path
import argparse
import difflib
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parent
KEYS=('CMAKE_C_COMPILER','CMAKE_CXX_COMPILER','CMAKE_C_FLAGS','CMAKE_CXX_FLAGS',
      'CMAKE_C_FLAGS_RELEASE','CMAKE_CXX_FLAGS_RELEASE','CMAKE_EXE_LINKER_FLAGS','CMAKE_BUILD_TYPE','CMAKE_GENERATOR')


def load(path):return json.loads(path.read_bytes())


def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


def require(value,message):
    if not value:raise RuntimeError(message)


def save(path,value):
    require(not path.exists(),'refusing to replace '+str(path))
    path.write_text(json.dumps(value,indent=2)+'\n')


def cache(path):
    rows={}
    for line in path.read_text().splitlines():
        if line.startswith(('#','//')) or '=' not in line or ':' not in line:continue
        name,value=line.split('=',1);rows[name.split(':',1)[0]]=value
    require(all(name in rows for name in KEYS),'incomplete CMake compiler configuration')
    return {name:rows[name] for name in KEYS}


def prepare(args):
    selected=args.selected_root.resolve();folder=args.output.resolve();shadow=folder/'shadow'
    require(not folder.exists(),'control output already exists; preserve it and select a new output')
    source=load(selected/'source.json');toolchain=load(selected/'toolchain.json')
    require(source['headers']==toolchain['headers'] and source['patches']==toolchain['patches'],'selected source metadata differs')
    require(len(source['headers'])==32 and len(source['patches'])==2,'unexpected selected source inventory')
    settings=cache(args.selected_cache)
    require(settings['CMAKE_GENERATOR']=='Ninja' and settings['CMAKE_BUILD_TYPE']=='Release','selected build must be Ninja Release')
    require(settings['CMAKE_C_FLAGS_RELEASE']==settings['CMAKE_CXX_FLAGS_RELEASE']=='-O3 -DNDEBUG','nondefault Release flags need explicit bootstrap support')
    require('clang' in Path(settings['CMAKE_C_COMPILER']).name and 'clang' in Path(settings['CMAKE_CXX_COMPILER']).name,'selected control must use Clang')
    shadow.mkdir(parents=True)
    inputs={}
    def copy(original,relative,expected=None):
        actual=sha(original)
        require(expected is None or actual==expected,'source differs: '+str(original))
        target=shadow/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(original,target)
        inputs[str(target)]=actual
    for name,expected in source['headers'].items():copy(selected/'compiler'/name,'compiler/'+name,expected)
    for name,expected in source['patches'].items():copy(selected/name,name,expected)
    copy(ROOT/'scripts/bootstrap.py','scripts/bootstrap.py');copy(ROOT/'toolchain.json','toolchain.json')
    header=shadow/'compiler/direct_wasm_funvals.h';before=header.read_text()
    marker='    if (!tail->fvbody) {\n'
    require(before.count(marker)==1,'named-tail forwarding predicate marker differs')
    after=before.replace(marker,marker+'        return nullptr;\n',1);header.write_text(after)
    (folder/'direct_wasm_funvals.before.h').write_text(before)
    (folder/'disable-named-tail-forwarding.patch').write_text(''.join(difflib.unified_diff(
        before.splitlines(keepends=True),after.splitlines(keepends=True),
        fromfile='a/compiler/direct_wasm_funvals.h',tofile='b/compiler/direct_wasm_funvals.h')))
    inputs[str(header)]=sha(header)
    source_repo=args.source_repo.resolve()
    command=[sys.executable,str(shadow/'scripts/bootstrap.py'),'--build-dir',str(folder/'build'),
             '--source-repo',str(source_repo),'--generator','Ninja','--jobs','2']
    environment={'CC':settings['CMAKE_C_COMPILER'],'CXX':settings['CMAKE_CXX_COMPILER'],
                 'CFLAGS':settings['CMAKE_C_FLAGS'],'CXXFLAGS':settings['CMAKE_CXX_FLAGS'],
                 'LDFLAGS':settings['CMAKE_EXE_LINKER_FLAGS']}
    record={'status':'prepared','selected_root':str(selected),'selected_compiler_sha256':toolchain['compiler_sha256'],
            'selected_cache':str(args.selected_cache.resolve()),'selected_cmake':settings,
            'changed_headers':['direct_wasm_funvals.h'],'before_sha256':hashlib.sha256(before.encode()).hexdigest(),
            'after_sha256':sha(header),'input_sha256':inputs,'source_repo':str(source_repo),
            'command':command,'environment':environment,'method':'Only named-tail FunctionValueForwarder paths return nullptr; all other31headers, both patches, and memory-growth behavior match selected source.'}
    save(folder/'preparation.json',record)
    print('PREPARED',toolchain['compiler_sha256'],len(inputs),'small source inputs; no build executed',flush=True)


def build(args):
    folder=args.output.resolve();record=load(folder/'preparation.json')
    require(not (folder/'build-execution.json').exists(),'preserve prior control build before retrying')
    require(all(sha(path)==expected for path,expected in record['input_sha256'].items()),'control source inputs changed')
    environment=os.environ.copy();environment.update(record['environment']);started=time.monotonic()
    with (folder/'build.log').open('w') as stream:
        result=subprocess.run(record['command'],cwd=ROOT,env=environment,stdout=stream,stderr=subprocess.STDOUT)
    save(folder/'build-execution.json',{'command':record['command'],'environment':record['environment'],
        'exit_status':result.returncode,'wall_seconds':time.monotonic()-started,'log':str(folder/'build.log'),'measurement':False})
    require(result.returncode==0,'control build failed; inspect preserved build.log')
    match(args)


def match(args):
    folder=args.output.resolve();record=load(folder/'preparation.json');selected=Path(record['selected_root'])
    current=load(selected/'toolchain.json');control=load(folder/'build/toolchain.json')
    require(current['compiler_sha256']==record['selected_compiler_sha256'],'selected compiler metadata changed')
    require(control['revision']==current['revision'] and control['patches']==current['patches'],'control upstream or patches differ')
    changed={name for name,expected in current['headers'].items() if control['headers'].get(name)!=expected}
    require(changed=={'direct_wasm_funvals.h'},'control changes more than the named-tail predicate header')
    require(control['headers']['direct_wasm_funvals.h']==record['after_sha256'],'control predicate differs')
    settings=cache(folder/'build/native/CMakeCache.txt');require(settings==record['selected_cmake'],'control compiler flags or generator differ')
    # Freeze only matching headers beside build metadata for the qualification runner.
    target=folder/'build/compiler';target.mkdir(exist_ok=True)
    for name,expected in control['headers'].items():
        source=folder/'shadow/compiler'/name;require(sha(source)==expected,'compiled control header differs')
        shutil.copyfile(source,target/name)
    require(sha(folder/'build/bin/goose')==control['compiler_sha256'],'control binary differs from metadata')
    proof={'status':'matched','selected_compiler_sha256':current['compiler_sha256'],
           'control_compiler_sha256':control['compiler_sha256'],'changed_headers':sorted(changed),
           'selected_cmake':record['selected_cmake'],'control_cmake':settings,
           'compiler_tool_sha256':{settings[name]:sha(settings[name]) for name in ('CMAKE_C_COMPILER','CMAKE_CXX_COMPILER')},
           'scope':record['method']}
    save(folder/'build/control-toolchain-match.json',proof)
    print('CONTROL READY',control['compiler_sha256'],'matched',current['compiler_sha256'],flush=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('phase',choices=['prepare','build','match'])
    parser.add_argument('--selected-root',type=Path,default=ROOT/'build/functions-grow/body-growth')
    parser.add_argument('--selected-cache',type=Path,default=ROOT/'build/native/CMakeCache.txt')
    parser.add_argument('--source-repo',type=Path,default=ROOT/'build/source')
    parser.add_argument('--output',type=Path,default=HERE/'named-control')
    args=parser.parse_args();globals()[args.phase](args)


if __name__=='__main__':main()
