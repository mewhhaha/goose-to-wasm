from trials import *
root=B/'release/source'
src=(root/F).read_text()
rehashed=src.replace('let old = l.frames[frame].read_table; let cap =','let cap =').replace('''        for item in 0..cap {
            let index = l.read_slots[old + item];
            if index < 0 { continue; }''','''        var index = l.frames[frame].first_read;
        while index >= 0 {''').replace('''            l.read_slots[table + slot] = index;
        }
        l.frames[frame].read_table''','''            l.read_slots[table + slot] = index as i32;
            index = l.summary_reads[index].next;
        }
        l.frames[frame].read_table''')
fill=src.replace('2 * (l.frames[frame].read_count + 1) > l.frames[frame].read_cap','3 * (l.frames[frame].read_count + 1) > 2 * l.frames[frame].read_cap')
quad=src.replace('if cap > 0 { size = 2 * cap; }','if cap > 0 { size = 4 * cap; }')
assert len({rehashed,quad,fill,src})==4
os.sched_setaffinity(0,{2})
args=['current='+str(B/'release/fixed.wasm')]
for name,body in [('linked',rehashed),('two-thirds',fill),('quad',quad)]:
 d=B/('table-'+name);shutil.copytree(root,d/'source');(d/'source'/F).write_text(body)
 (d/'change.patch').write_text(''.join(unified_diff(src.splitlines(True),body.splitlines(True),fromfile='a/'+str(F),tofile='b/'+str(F))))
 out=d/'compiler.wasm'
 subprocess.run([N,'selfhost/main.goose','--stdlib','stdlib','--target','wasm-direct','-O2','--wasm-bundled-host','--wasm-initial-pages','65535','--wasm-max-pages','65535','--wasm-region-profile',B/'release/training.profile','-o',out],cwd=d/'source',check=True)
 args.append(name+'='+str(out))
subprocess.run([R/'.venv/bin/python',R/'bench/results/2026-11-18/compiler-frame-cost/measure.py',O/'own',B/'table-screen',*args,'--rounds','6','--cpu','2'],check=True)
