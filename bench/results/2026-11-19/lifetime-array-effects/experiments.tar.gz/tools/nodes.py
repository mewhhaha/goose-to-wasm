from trials import *
import trials
parent=trials.variant
def variant(tags):
 s=parent(tags)
 def rep(a,b):
  nonlocal s
  assert s.count(a)==1,(a,s.count(a));s=s.replace(a,b)
 if 'siteprobe' in tags:
  rep('fn life_construct_read(p:', 'var site_counts: i64[6];\nfn life_construct_read(p:')
  rep('    if l.reading_place > 0 { return; }\n    var effect_places', '''    site_counts[0]++;
    if node < 0 || value.type_id != p.nodes[node].type_id { site_counts[1]++; }
    if l.reading_place > 0 { return; }
    var effect_places''')
  rep('        let entry = read; let item: const LifeReadEntry& = l.summary_reads[entry];', '''        let entry = read; let item: const LifeReadEntry& = l.summary_reads[entry];
            site_counts[2]++; let original: const LifeLeaf& = l.leaves[item.leaf];
            if original.value.type_id != p.nodes[original.node].type_id { site_counts[3]++; }''')
  rep('    if p.diagnostics.len == 0 { life_export_provenance', '    print(site_counts);\n    if p.diagnostics.len == 0 { life_export_provenance')
 else:
  a=s.index('inline fn life_read_key');b=s.index('// A frame\'s construct read',a)
  s=s[:a]+s[b:]
  s=s.replace('life_read_key(offer.node, offer.value.type_id)','offer.node')
  rep('struct LifeReadEntry { changed: i64, key: i64,', 'struct LifeReadEntry { changed: i64, node: i32,')
  rep('changed: l.frames[frame].reads_version, key: key,', 'changed: l.frames[frame].reads_version, node: key as i32,')
  rep('l.summary_reads[index].key == key', 'l.summary_reads[index].node as i64 == key')
  rep('life_read_hash(l.summary_reads[index as i64].key)', 'life_read_hash(l.summary_reads[index as i64].node as i64)')
  rep('life_read_hash(entry.key)', 'life_read_hash(entry.node as i64)')
  rep('l.summary_reads[entry].key, prior_reach','l.summary_reads[entry].node as i64, prior_reach')
  rep('// A frame\'s construct read', '''inline fn life_read_hash(node: i64) -> i64 {
    return node ^ (node >> 8);
}
// A frame's construct read''')
  if 'identity' in tags:rep('return node ^ (node >> 8);','return node;')
  if 'mix' in tags:rep('return node ^ (node >> 8);','let h = (node as! u64) * 11400714819323198485; return (h ^ (h >> 32)) as! i64;')
 return s
trials.variant=variant
for name in sys.argv[1:]:
 build(name)
 if 'probe' in name:
  d=B/name
  with (d/'counts.txt').open('w') as f:
   subprocess.run([H,d/'compiler.wasm','--cache',d/'compiler.cwasm','--','selfhost/main.goose','--stdlib','stdlib','--target','wasm-direct','-O2','--wasm-memory64','--wasm-max-pages','262144','--check'],cwd=S,check=True,stdout=f)
