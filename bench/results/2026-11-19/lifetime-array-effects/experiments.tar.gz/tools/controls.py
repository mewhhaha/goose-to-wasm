from trials import *
import json,hashlib
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
out=B/'controls';out.mkdir(exist_ok=True);home=out/'upstream-home';home.mkdir(exist_ok=True)
ref=R/'build/langbench-native/goose';up=R/'build/life-parity/fp-corpus/upstream';suite=json.loads((R/'tests/conformance/cases.json').read_bytes());counts={c['name']:c for c in json.loads((B/'corpus/results.json').read_bytes())['cases']}
new=B/'own/build-1/compiler-native';env={**os.environ,'GOOSE_HOME':str(home)}
report=dict(reference_sha256=sha(ref),revision=suite['upstream']['revision'],compiler_sha256=sha(new),host_sha256=sha(H),cases=[])
names=['test/lifetimes/shrink_in_expressions.goose','test/lifetimes/emptied_holder_shrink.goose','test/codegen/render_walks_around_overloads.goose','test/errors_tc/balanced_shrink_recursive_settled.goose','test/errors_tc/emptied_callee_view_kept.goose','test/errors_tc/construct_use_recursive.goose','test/errors_tc/format_shrinks_rendered_adt_forwarded.goose']
for name in names:
 f=up/name;k='upstream:'+name;case=next(c for c in suite['cases'] if c['source']==k); obs=counts[k];positive=case['phase']=='run';assert positive==(obs['status']==0)
 rr=subprocess.run([ref,'run' if positive else 'check',f,'--stdlib',R/'build/langbench-goose-source/stdlib'],cwd=out,env=env,capture_output=True,timeout=150)
 module=out/(f.stem+'.wasm');p=subprocess.run([new,f,'--stdlib',up/'stdlib','--target','wasm-direct','-O2','-o',module],capture_output=True)
 item=dict(name=name,source_sha256=sha(f),group_skips=obs['whole'],individual_skips=obs['single'],upstream_exit=rr.returncode,compiler_exit=p.returncode)
 if positive:
  assert rr.returncode==p.returncode==0,(name,rr.stderr,p.stderr)
  x=subprocess.run([H,module,'--no-cache'],capture_output=True,check=True)
  assert x.stdout==rr.stdout and x.stdout.decode().rstrip('\n')==case['expect']['stdout'].rstrip('\n')
  item.update(stdout_sha256=hashlib.sha256(x.stdout).hexdigest(),stdout_bytes=len(x.stdout),module_sha256=sha(module))
 else:
  assert rr.returncode and p.returncode and not module.exists()
  item.update(upstream_error=next(l for l in rr.stderr.decode().splitlines() if 'error:' in l.lower()),compiler_error=p.stderr.decode().strip())
 report['cases'].append(item);print(name,'passed',flush=True)
(out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
