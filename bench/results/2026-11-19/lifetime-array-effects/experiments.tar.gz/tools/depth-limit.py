from trials import *
import json,hashlib
d=B/'scaling';f=d/'depth1024.goose';out=d/'limit.wasm';report={}
for case,cmd in [('native-before',[N]),('wasm-before',[H,O/'release/fixed.wasm','--cache',O/'release/fixed.cwasm','--']),('wasm-after',[H,B/'release/fixed.wasm','--cache',B/'release/fixed.cwasm','--']),('native-after',[B/'own/build-1/compiler-native'])]:
 out.unlink(missing_ok=True)
 p=subprocess.run([*cmd,f,'--stdlib',S/'stdlib','--target','wasm-direct','-O2','-o',out],cwd=d,capture_output=True)
 report[case]=dict(exit=p.returncode,stderr=p.stderr.decode(),module=hashlib.sha256(out.read_bytes()).hexdigest() if out.exists() else None)
assert report['native-before']['module'] and report['native-before']['module']==report['native-after']['module']
for k in ['wasm-before','wasm-after']:assert report[k]['exit'] and 'activation stack exhausted' in report[k]['stderr']
(d/'limit.json').write_text(json.dumps(report,indent=2)+'\n')
