from pathlib import Path
import json,subprocess,resource,os,hashlib,tarfile
from concurrent.futures import ThreadPoolExecutor
from collections import Counter
root=Path.cwd();B=root/'build/lifetime-safe-19';P=root/'build/nov19-main';d=B/'corpus';d.mkdir(exist_ok=True)
resource.setrlimit(resource.RLIMIT_STACK,(256<<20,resource.getrlimit(resource.RLIMIT_STACK)[1]));os.sched_setaffinity(0,{0,4})
s=B/'operations/source';tool=B/'operations/native'
manifest=root/'tests/conformance/cases.json';suite=json.loads(manifest.read_bytes());names=sorted({c['source'] for c in suite['cases']});upstream=root/'build/life-parity/fp-corpus/upstream'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def case(name):
 path=root/name;cwd=root
 if name.startswith('upstream:'):cwd=upstream;path=upstream/name.removeprefix('upstream:')
 r=subprocess.run([tool,path,'--target','native','--check','--stdlib',cwd/'stdlib'],cwd=cwd,capture_output=True,timeout=60)
 assert r.returncode in (0,1),(name,r.returncode)
 lines=[s for s in r.stdout.splitlines() if s.startswith(b'[')]
 if not lines:return name,r.returncode,None
 assert len(lines)==1
 counts=json.loads(lines[0]);return name,r.returncode,counts
total=Counter();hits=[];observed=0
with ThreadPoolExecutor(2) as pool:
 for name,status,counts in pool.map(case,names):
  if counts is None:continue
  observed+=1
  for i,k in enumerate(['whole_replays','whole_shrink','whole_grow','whole_replace','single_shrink','single_grow','single_replace','sent_shrink','sent_grow','sent_replace']):total[k]+=counts[i]
  if sum(counts[1:7]):hits.append(dict(name=name,status=status,whole=counts[1:4],single=counts[4:7]))
report=dict(source_count=len(names),complete_checks=observed,with_skipped_operations=len(hits),totals=dict(total),cases=hits,manifest_sha256=sha(manifest),probe_sha256=sha(tool),probe_lifetimes_sha256=sha(s/'selfhost/checker_lifetimes.goose'),upstream_archive_sha256=suite['upstream']['sha256'])
(d/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(len(names),observed,len(hits),total)
