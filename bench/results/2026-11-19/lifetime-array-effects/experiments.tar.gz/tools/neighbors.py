from trials import *
import trials
def variant(tags):
 s=(B/'release/source'/F).read_text()
 for patch in tags:
  if patch=='current':continue
  if patch=='far32':patch='far'
  if patch=='site':patch='node-identity'
  temp=B/'neighbor-input.goose';temp.write_text(s)
  change=B/'neighbor-input.patch';change.write_text((B/patch/'change.patch').read_text().replace('reads_version','replay_version'))
  proc=subprocess.run(['patch','--batch','--silent','--reject-file',B/'neighbor.rej','-o','-',temp,change],capture_output=True)
  if proc.returncode: raise ValueError((patch,proc.stderr[-400:]))
  s=proc.stdout.decode()
 return s
trials.variant=variant
for n in sys.argv[1:]:build(n)
