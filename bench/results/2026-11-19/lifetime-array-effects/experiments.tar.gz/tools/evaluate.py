from trials import *
root=B/'release/source';src=(root/F).read_text()
a=src.index('recursive fn life_eval(');b=src.index('recursive fn life_eval_body(',a);body=src[a:b]
stmt='out.refs = life_fold(l, out.refs); out.contents = life_fold(l, out.contents);'
start='let n: const Node& = p.nodes[node]; var out = LifeValue { type_id: n.type_id };'
init='var out = LifeValue { type_id: n.type_id };'
lazy=body.replace(start,'let n: const Node& = p.nodes[node];').replace('        let cell = life_cell(p, l, n.symbol);','        '+init+'\n        let cell = life_cell(p, l, n.symbol);').replace('if n.kind == N_STRING { out.place = life_root_set(l, 0); out.refs = out.place; return out; }','if n.kind == N_STRING { let place = life_root_set(l, 0); return LifeValue { type_id: n.type_id, place: place, refs: place }; }').replace('N_IMPORT { return out; }','N_IMPORT { return LifeValue { type_id: n.type_id }; }')
assert lazy!=body and stmt in lazy
def guard(s):return s.replace(stmt,'if l.class_frames > 0 { '+stmt+' }')
os.sched_setaffinity(0,{3})
args=['current='+str(B/'release/fixed.wasm')]
for name,chunk in [('fold',guard(body)),('lazy',lazy),('both',guard(lazy))]:
 d=B/('eval-'+name);shutil.copytree(root,d/'source');s=src[:a]+chunk+src[b:];(d/'source'/F).write_text(s)
 (d/'change.patch').write_text(''.join(unified_diff(src.splitlines(True),s.splitlines(True),fromfile='a/'+str(F),tofile='b/'+str(F))))
 out=d/'compiler.wasm';subprocess.run([N,'selfhost/main.goose','--stdlib','stdlib','--target','wasm-direct','-O2','--wasm-bundled-host','--wasm-initial-pages','65535','--wasm-max-pages','65535','--wasm-region-profile',B/'release/training.profile','-o',out],cwd=d/'source',check=True)
 args.append(name+'='+str(out))
subprocess.run([R/'.venv/bin/python',R/'bench/results/2026-11-18/compiler-frame-cost/measure.py',O/'own',B/'eval-screen',*args,'--rounds','6','--cpu','3'],check=True)
