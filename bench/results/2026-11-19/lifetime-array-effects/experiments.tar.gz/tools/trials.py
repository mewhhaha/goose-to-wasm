from pathlib import Path
from difflib import unified_diff
import os,sys,resource,subprocess,shutil
B=Path(__file__).resolve().parent; R=B.parents[1]; O=R/'build/replay-nov19'; S=O/'own/source'; N=O/'own/build-1/compiler-native'; F=Path('selfhost/checker_lifetimes.goose'); H=R/'host/rust/target/release/goose-wasmtime'
resource.setrlimit(resource.RLIMIT_STACK,(256<<20,resource.getrlimit(resource.RLIMIT_STACK)[1]))
orig=(S/F).read_text()
def variant(tags):
 s=orig
 def rep(a,b):
  nonlocal s
  assert s.count(a)==1,(a,s.count(a));s=s.replace(a,b)
 if 'cycle' in tags:
  rep('    var entry = -1; var at = l.frame; let target_head', '''    if !l.frames[target].active && !l.frames[target].recursive_call { return; }
    var entry = -1; var at = l.frame; let target_head''')
 if 'cursor' in tags:
  rep('    var formal = p.nodes[function_node].first; var index = 0;\n    while formal >= 0 {','    var formal = p.nodes[function_node].first; var input = arguments;\n    while formal >= 0 {')
  rep('            let value = life_coerce(p, l, life_item(l, arguments, index), p.nodes[formal].type_id);','''            var argument = LifeValue {};
            if input >= 0 { argument = l.items[input].value; }
            let value = life_coerce(p, l, argument, p.nodes[formal].type_id);''')
  rep('        index += 1; formal = p.nodes[formal].next;\n    }\n    // (Evaluated again', '        if input >= 0 { input = l.items[input].next; }\n        formal = p.nodes[formal].next;\n    }\n    // (Evaluated again')
  rep('var arguments = -1; var argument = n.first;', 'var arguments = -1; var last_argument = -1; var argument = n.first;')
  rep('        arguments = life_append(l, arguments, value);\n        if index == 0', '''        let item = l.items.len;
        l.items.push(LifeItem { value: value });
        if last_argument >= 0 { l.items[last_argument].next = item; } else { arguments = item; }
        last_argument = item;
        if index == 0''')
 if 'grow' in tags:
  rep('        let hold = l.holds[index];\n        if (hold.kind == 1 || hold.kind == 2)', '        let hold: const LifeHold& = l.holds[index];\n        if (hold.kind == 1 || hold.kind == 2)')
 if 'far' in tags or 'far256' in tags:
  n=256 if 'far256' in tags else 32
  rep('    var l = Lifetimes { parents:', f'    var reaches: LifeReach[>..] = []; reaches.resize({n}, LifeReach {{}});\n    var l = Lifetimes {{ parents:')
  rep(' parents: scope_parent,',' reaches: reaches, parents: scope_parent,')
  rep('struct Lifetimes {', 'struct Lifetimes {\n    reaches: LifeReach[>..]&,')
  rep('fn life_effect_far(l: Lifetimes&, places: i64) -> LifeFar {',f'''struct LifeReach {{ activation: i64 = -1, epoch: i64 = 0, places: i64 = -1, first: i64 = -1, reach: LifeFar = LifeFar {{ far: 0, home: 0 }} }}
fn life_effect_far(l: Lifetimes&, places: i64) -> LifeFar {{
    let slot = places & {n-1}; let a = l.frames[l.frame].activation; let first = l.sets[places].first;
    let old: const LifeReach& = l.reaches[slot];
    if old.places == places && old.first == first && old.activation == a && old.epoch == l.recursion_epoch {{ return old.reach; }}
    let reach = life_compute_far(l, places);
    l.reaches[slot] = LifeReach {{ activation: a, epoch: l.recursion_epoch, places: places, first: first, reach: reach }};
    return reach;
}}
fn life_compute_far(l: Lifetimes&, places: i64) -> LifeFar {{''')
 if 'probe' in tags:
  rep('fn life_cycle_call(p:', 'var cost_probe: i64[12];\nfn life_cycle_call(p:')
  rep('    var entry = -1; var at = l.frame; let target_head', '    cost_probe[0]++; let empty = !l.frames[target].active && !l.frames[target].recursive_call; if empty { cost_probe[1]++; }\n    var entry = -1; var at = l.frame; let target_head')
  rep('        if at == target || l.frames[target].recursive_call', '        cost_probe[2]++; if empty { cost_probe[3]++; }\n        if at == target || l.frames[target].recursive_call')
  rep('    if entry >= 0 {\n        var member = l.frame;', '    if entry >= 0 {\n        if empty { cost_probe[4]++; }\n        var member = l.frame;')
  rep('    let item = l.items.len; l.items.push', '    cost_probe[5]++; let item = l.items.len; l.items.push')
  rep('var last = first; while l.items[last].next >= 0 { last =', 'var last = first; while l.items[last].next >= 0 { cost_probe[6]++; last =')
  rep('    while at >= 0 { if i == index { return l.items[at].value; }', '    while at >= 0 { cost_probe[7]++; if i == index { return l.items[at].value; }')
  rep('    if p.diagnostics.len == 0 { life_export_provenance', '    print(cost_probe);\n    if p.diagnostics.len == 0 { life_export_provenance')
 return s
def build(name):
 s=variant(name.split('-')); d=B/name; src=d/'source';shutil.copytree(S,src,dirs_exist_ok=True);(src/F).write_text(s)
 (d/'change.patch').write_text(''.join(unified_diff(orig.splitlines(True),s.splitlines(True),fromfile='a/'+str(F),tofile='b/'+str(F))))
 subprocess.run([N,'selfhost/main.goose','--stdlib','stdlib','--target','wasm-direct','-O2','--wasm-bundled-host','--wasm-initial-pages','65535','--wasm-max-pages','65535','--wasm-region-profile',O/'release/training.profile','-o',d/'compiler.wasm'],cwd=src,check=True)
 if name=='probe':
  with (d/'counts.txt').open('w') as f:subprocess.run([H,d/'compiler.wasm','--cache',d/'compiler.cwasm','--','selfhost/main.goose','--stdlib','stdlib','--target','wasm-direct','-O2','--wasm-memory64','--wasm-max-pages','262144','--check'],cwd=S,check=True,stdout=f)
if __name__=='__main__':
 os.sched_setaffinity(0,{2,4,6})
 for n in sys.argv[1:]:build(n)
