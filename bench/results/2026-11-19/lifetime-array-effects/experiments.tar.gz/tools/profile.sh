set -eu
base=$(pwd)
b=$base/build/lifetime-safe-19
s=$base/build/lifetime-safe-19/own
r=$base/build/lifetime-safe-19/release
ulimit -s 262144
cp -r "$s/source" "$b/namer"
python3 - "$b/namer/selfhost/codegen.goose" <<'PY'
import sys,pathlib
p=pathlib.Path(sys.argv[1]);s=p.read_text();assert s.count("else if p.debug {\n        var name_count")==1;p.write_text(s.replace("else if p.debug {\n        var name_count","else {\n        var name_count"))
PY
(cd "$b/namer" && "$s/build-1/compiler-native" selfhost/main.goose --stdlib stdlib --target wasm-direct -O2 --wasm-memory64 --wasm-max-pages 262144 -o "$b/namer.wasm")
(cd "$s/source" && "$base/host/rust/target/release/goose-wasmtime" "$b/namer.wasm" --cache "$b/namer.cwasm" -- selfhost/main.goose --stdlib stdlib --target wasm-direct -O2 --wasm-bundled-host --wasm-initial-pages 65535 --wasm-max-pages 65535 --wasm-region-profile "$r/training.profile" -o "$b/named.wasm")
taskset -c 6 "$base/.venv/bin/python" "$b/profile.py" "$s" "$base/build/replay-nov19/own" "$b/named.wasm" "$b/profile.json" --cpu 6 --rounds 3
