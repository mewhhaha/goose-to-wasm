from pathlib import Path
from statistics import median
import hashlib, json, os, resource, subprocess, sys, time
R=Path.cwd();B=R/'build/lifetime-safe-19';old=R/'build/replay-nov19'
D=B/'scaling';D.mkdir(exist_ok=True)
cpu=6;os.sched_setaffinity(0,{cpu})
resource.setrlimit(resource.RLIMIT_STACK,(256<<20,resource.getrlimit(resource.RLIMIT_STACK)[1]))
up=R/'build/langbench-native/goose';upstd=R/'build/langbench-goose-source/stdlib'
std=old/'own/source/stdlib';H=R/'host/rust/target/release/goose-wasmtime'
native=old/'own/build-1/compiler-native';new=B/'own/build-1/compiler-native'
cases={'native-before':[native], 'wasm-before':[H,old/'release/fixed.wasm','--cache',old/'release/fixed.cwasm','--'],'wasm-after':[H,B/'release/fixed.wasm','--cache',B/'release/fixed.cwasm','--'],'native-after':[new]}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
home=D/'upstream-home';home.mkdir(exist_ok=True); env={**os.environ,'GOOSE_HOME':str(home)}
report=dict(cpu=cpu,host_sha256=sha(H),upstream_sha256=sha(up),compiler_sha256={k:sha(v[1] if len(v)>1 else v[0]) for k,v in cases.items()},inputs={},samples=[])
if (D/'results.json').is_file(): report=json.loads((D/'results.json').read_text())
for label,n in [('arrays',16),('arrays',64),('arrays',256),('depth',128),('depth',512)]:
 name=label+str(n);f=D/(name+'.goose')
 if len([r for r in report['samples'] if r['input']==name])==20:continue
 if label=='arrays':
  text=['fn edit(a: i64[>..]&) {',*['    a.push(1);' for _ in range(n)],'}']
  last='edit'
  for i in range(6):
   text.append(f'fn group{i}(a: i64[>..]&) {{ {last}(a); {last}(a); }}');last='group'+str(i)
  text.append(f'fn main() {{ var a: i64[>..] = []; {last}(a); print(a.len); }}');expected=str(64*n)
 else:
  text=['fn step0(x: i64) -> i64 { return x + 1; }']
  for i in range(1,n):text.append(f'fn step{i}(x: i64) -> i64 {{ return step{i-1}(x); }}')
  text.append(f'fn main() {{ print(step{n-1}(1)); }}');expected='2'
 f.write_text('\n'.join(text)+'\n'); output=expected.encode()+b'\n'
 # Plain upstream runs one representative of each shape; all six execute below.
 ref=dict(source=sha(f),stdout=expected)
 if n in (16,128):
  p=subprocess.run([up,'run',f,'--stdlib',upstd],cwd=D,capture_output=True,env=env,timeout=150);assert p.returncode==0 and p.stdout==output,(name,p.returncode,p.stderr[-512:],p.stdout);ref['upstream_match']=True
 args=[f,'--stdlib',std,'--target','wasm-direct','-O2']
 target=D/(name+'.wasm');subprocess.run([native,*args,'-o',target],cwd=D,check=True)
 ref['module_sha256']=sha(target);p=subprocess.run([H,target,'--no-cache'],capture_output=True,check=True);assert p.stdout==output
 report['inputs'][name]=ref
 for i in range(5):
  labels=list(cases)
  if i%2:labels.reverse()
  for case in labels:
   stats=D/'stats.json';stats.unlink(missing_ok=True);target.unlink(missing_ok=True)
   args2=[*args,'-o',target,'--wasm-stats',stats];start=time.monotonic_ns()
   p=subprocess.run([*cases[case],*args2],cwd=D,capture_output=True)
   elapsed=time.monotonic_ns()-start;assert (p.returncode,p.stderr)==(0,b''),(name,case,p.stderr)
   assert sha(target)==ref['module_sha256'];raw=json.loads(stats.read_bytes())
   report['samples'].append(dict(input=name,round=i+1,case=case,wall_ns=elapsed,lifetime_ns=raw['lifetime_ns'],module_sha256=sha(target)))
 (D/'results.json').write_text(json.dumps(report,indent=2)+'\n')
 print(name,{k:round(median(r['lifetime_ns']/1e6 for r in report['samples'] if r['input']==name and r['case']==k),2) for k in cases},flush=True)
