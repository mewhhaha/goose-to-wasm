from trials import *
import hashlib
root=R;file=F;native=R/'build/nov19-main/release/compiler-native';base=R/'build/nov19-main/own/source'

import hashlib,json
R=root;T=R/'bench/results';F=B/'fingerprints';F.mkdir(exist_ok=True); H=R/'host/rust/target/release/goose-wasmtime'
resource.setrlimit(resource.RLIMIT_STACK,(256<<20,resource.getrlimit(resource.RLIMIT_STACK)[1]));os.sched_setaffinity(0,{0,2,4,6})
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def build(tag,path):
 d=F/tag; src=d/'source';shutil.copytree(path,src,dirs_exist_ok=True)
 for script,extra in [(T/'2026-11-17/lifetime-compact-reads/tools/logicalfp.py',['fingerprint']),(T/'2026-11-18/lifetime-exit-index/tools/exitfp.py',[])]:
  subprocess.run([sys.executable,script,src/'selfhost',*extra],check=True)
 f=src/file;orig=f.read_text()
 for mode in ['self','class']:
  if mode=='class':assert orig.count('LIFE_CONCRETE_FRAMES: i64 = 4096')==1;f.write_text(orig.replace('LIFE_CONCRETE_FRAMES: i64 = 4096','LIFE_CONCRETE_FRAMES: i64 = 64'))
  mod=d/(mode+'.wasm');subprocess.run([native,'selfhost/main.goose','--stdlib','stdlib','--target','wasm-direct','-O2','--wasm-memory64','--wasm-max-pages','262144','-o',mod],cwd=src,check=True)
  sources=['selfhost/main.goose'] if mode=='self' else [T/'2026-11-18/compiler-array-views/lifetime/class-exits.goose',T/'2026-11-18/compiler-replay-and-captures/replay/class-read.goose']
  for index,source in enumerate(sources):
   r=subprocess.run([H,mod,'--cache',d/(mode+'.cwasm'),'--',source,'--stdlib','stdlib','--target','native','--check'],cwd=base,capture_output=True)
   assert r.returncode==0 and b'LIFEFP' in r.stderr and not r.stdout
   (d/f'{mode}{index}.err').write_bytes(r.stderr)
 f.write_text(orig)
 subprocess.run([native,'selfhost/main.goose','--stdlib','stdlib','--target','native','-O2','-o',d/'probe.c'],cwd=src,check=True)
 subprocess.run(['clang-23','-w','-O0','-std=gnu11',d/'probe.c','-lm','-ldl','-pthread','-o',d/'probe'],check=True)
 print(tag,'finished',flush=True)
def compare(tag):
 d=F/tag; b=F/'baseline';out=F/('corpus-'+tag);out.mkdir(exist_ok=True)
 for f in b.glob('*.err'): assert (d/f.name).read_bytes()==f.read_bytes(),f
 if not (out/'upstream').exists():(out/'upstream').symlink_to(R/'build/life-parity/fp-corpus/upstream')
 subprocess.run([sys.executable,T/'2026-11-17/lifetime-compact-reads/tools/fpcompare.py',b/'probe',d/'probe',out,'--jobs','4'],check=True)
 result=json.loads((out/'report.json').read_bytes())['summary'];assert result['differing']==0 and result['compared']==4357
 result['controls']={f.name:dict(fp=sum(x.startswith(b'LIFEFP') for x in f.read_bytes().splitlines()),stderr_sha256=sha(f)) for f in d.glob('*.err')}
 result['probes']={k:{n:sha((F/k)/n) for n in ['probe','self.wasm','class.wasm']} for k in ['baseline',tag]}
 (out/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(result,flush=True)
if sys.argv[1]=='compare':compare(sys.argv[2])
else:build(sys.argv[1],Path(sys.argv[2]))
