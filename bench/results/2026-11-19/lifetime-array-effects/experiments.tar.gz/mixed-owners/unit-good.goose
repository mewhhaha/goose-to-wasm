fn replace(xs: i64[>..<]&) { xs = [1]; }
fn choose(xs: i64[>..<]&) {
    var local: i64[>..<] = [];
    let target: i64[>..<]& = if xs.len > 0 { &xs } else { &local }; print(target.len); target = [1];
}
fn repeat(xs: i64[>..<]&) { choose(xs); choose(xs); }
recursive fn outer(again: bool) -> i64 {
    var xs: i64[>..<] = [];
    repeat(xs);
    if again { xs = [outer(false)]; }
    return 0;
}
fn main() { outer(true); }
