fn reset(xs: i64[>..<]&) {
    var local: i64[>..<] = [];
    let target: i64[>..<]& = if xs.len > 0 { &xs } else { &local };
    let length = target.len;
    target = [length];
}
fn twice(xs: i64[>..<]&) { reset(xs); reset(xs); }
recursive fn outer(again: bool) -> i64 {
    var xs: i64[>..<] = [];
    twice(xs);
    if again { xs = [outer(false)]; }
    return 0;
}
fn main() { outer(true); }
