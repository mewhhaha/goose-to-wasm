fn leaf(a: i64[>..<]&) { a.push(4); }
fn deep(g: i64[>..<]&, flag: bool) {
    var d: i64[>..<] = [1];
    let both: i64[>..<]& = if true { &g } else { &d };
    leaf(both);
    leaf(both);
}
fn middle(g: i64[>..<]&, flag: bool) {
    deep(g, flag);
    deep(g, flag);
}
recursive fn outer(flag: bool) -> i64 { var g: i64[>..<] = [1]; middle(g, flag); if flag { g = [outer(false)]; } return 0; }
fn main() {outer(true);}