fn leaf(a: i64[>..<]&) { print(a[0]); }
fn deep(g: i64[>..<]&, flag: bool) {
    var d: i64[>..<] = [1];
    let both: i64[>..<]& = if flag { &g } else { &d };
    leaf(both);
    leaf(both);
}
fn middle(g: i64[>..<]&, flag: bool) {
    deep(g, flag);
    deep(g, flag);
}
recursive fn outer(flag: bool) -> i64 { var g: i64[>..<] = [1]; if flag { let val=g[outer(false)]; print(val); } middle(g, flag); return 0; }
fn main() {outer(true);}