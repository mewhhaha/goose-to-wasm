fn trim(xs: i64[>..<]&) { xs.clear(); }
fn choose(xs: i64[>..<]&, outer: bool) {
    var local: i64[>..<] = [1];
    let target: i64[>..<]& = if outer { &xs } else { &local };
    trim(target);
    trim(target);
}
fn repeat(xs: i64[>..<]&) {
    choose(xs, true);
    choose(xs, false);
}
fn main() {
    var xs: i64[>..<] = [1];
    repeat(xs);
}
