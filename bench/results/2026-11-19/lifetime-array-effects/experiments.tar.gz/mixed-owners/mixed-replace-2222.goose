fn leaf(a: i64[>..<]&) { a = [1]; }
fn deep(g: i64[>..<]&, flag: bool) {
    var d: i64[>..<] = [1];
    let both: i64[>..<]& = if flag { &g } else { &d };
    leaf(both);
    leaf(both);
}
fn middle(g: i64[>..<]&, flag: bool) {
    deep(g, flag);
    deep(g, flag);
}
fn outer(flag: bool) {
    var g: i64[>..<] = [1];
    middle(g, flag);
    middle(g, flag);
}
fn main() { outer(false); outer(true); }
