fn edit(a: i64[>..]&) {
    a.push(1);
    a.push(1);
    a.push(1);
    a.push(1);
    a.push(1);
    a.push(1);
    a.push(1);
    a.push(1);
    a.push(1);
    a.push(1);
    a.push(1);
    a.push(1);
    a.push(1);
    a.push(1);
    a.push(1);
    a.push(1);
}
fn group0(a: i64[>..]&) { edit(a); edit(a); }
fn group1(a: i64[>..]&) { group0(a); group0(a); }
fn group2(a: i64[>..]&) { group1(a); group1(a); }
fn group3(a: i64[>..]&) { group2(a); group2(a); }
fn group4(a: i64[>..]&) { group3(a); group3(a); }
fn group5(a: i64[>..]&) { group4(a); group4(a); }
fn main() { var a: i64[>..] = []; group5(a); print(a.len); }
