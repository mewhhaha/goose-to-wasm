from trials import *
import hashlib
os.sched_setaffinity(0,{4});d=B/'capacity-pairs';d.mkdir(exist_ok=True);bd=B/'block-trials';ref=O/'own';out=d/'training.wasm';expected=(ref/'build-1/compiler.wasm').read_bytes();cases={}
args=['selfhost/main.goose','--stdlib','stdlib','--target','wasm-direct','-O2'];wide=['--wasm-memory64','--wasm-max-pages','262144']
record=dict(source=json.loads((ref/'builds.json').read_bytes())['source_commit'],source_archive_sha256=json.loads((ref/'builds.json').read_bytes())['source_archive_sha256'],expected=hashlib.sha256(expected).hexdigest(),cases={})
for name,src,train in [('current',B/'own/source',B/'release/train'),('frame16',bd/'frame16/source',bd/'frame16/train')]:
 p=d/(name+'.profile');subprocess.run([H,train/'stats.wasm','--cache',train/'stats.cwasm','--',*args,*wide,'-o',out],cwd=ref/'source',check=True,env={**os.environ,'GOOSE_REGION_PROFILE':str(p)});assert out.read_bytes()==expected
 mod=d/(name+'.wasm');subprocess.run([B/'own/build-1/compiler-native',*args,'--wasm-bundled-host','--wasm-initial-pages','65535','--wasm-max-pages','65535','--wasm-region-profile',p,'-o',mod],cwd=src,check=True);cases[name]=mod
 record['cases'][name]=dict(profile=hashlib.sha256(p.read_bytes()).hexdigest(),module=hashlib.sha256(mod.read_bytes()).hexdigest(),stats_module=hashlib.sha256((train/'stats.wasm').read_bytes()).hexdigest())
(d/'training.json').write_text(json.dumps(record,indent=2)+'\n')
for n,order in [('first',list(cases)),('reverse',list(reversed(cases)))]:
 subprocess.run([R/'.venv/bin/python',R/'bench/results/2026-11-18/compiler-frame-cost/measure.py',W/'own',d/n,*[k+'='+str(cases[k]) for k in order],'--rounds','4','--cpu','4'],check=True)
