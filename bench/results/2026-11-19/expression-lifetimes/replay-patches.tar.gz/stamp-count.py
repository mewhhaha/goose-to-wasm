from trials import *
import hashlib
os.sched_setaffinity(0,{0});d=B/'stamp-count';src=d/'source';shutil.copytree(B/'replay-trials/stamp/source',src,dirs_exist_ok=True);f=src/F;s=f.read_text().replace('fn life_replay(', 'var hits: i64[3];\nfn life_replay(')
a='if (memo || quick) && ((stamp_valid && l.leaf_stamps[leaf] == exact_stamp) || life_leaf_offered_in(l, leaf, activation, replay_epoch, stamp_chain)) { continue; }'
assert s.count(a)==1
s=s.replace(a,'''if memo || quick {
                hits[0]++;
                if stamp_valid && l.leaf_stamps[leaf] == exact_stamp { hits[1]++; continue; }
                if life_leaf_offered_in(l, leaf, activation, replay_epoch, stamp_chain) { hits[2]++; continue; }
            }''').replace('    if p.diagnostics.len == 0 { life_export_provenance','    print(hits);\n    if p.diagnostics.len == 0 { life_export_provenance')
f.write_text(s);args=['selfhost/main.goose','--stdlib','stdlib'];mod=d/'compiler.wasm'
subprocess.run([B/'own/build-1/compiler-native',*args,'--target','wasm-direct','-O2','--wasm-memory64','--wasm-max-pages','262144','-o',mod],cwd=src,check=True);p=subprocess.run([H,mod,'--cache',d/'stats.cwasm','--',*args,'--check'],cwd=S,capture_output=True,check=True);assert not p.stderr
v=json.loads(p.stdout);(d/'counts.json').write_text(json.dumps(dict(tested=v[0],exact=v[1],other=v[2],compiler=hashlib.sha256(mod.read_bytes()).hexdigest()),indent=2)+'\n');print(v)
