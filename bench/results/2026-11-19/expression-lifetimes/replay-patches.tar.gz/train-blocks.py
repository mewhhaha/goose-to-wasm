from trials import *
import hashlib
from math import isqrt
os.sched_setaffinity(0,{2});d=B/'block-trials';native=B/'own/build-1/compiler-native';old=B/'release/train';flags=['--target','wasm-direct','-O2'];wide=['--wasm-memory64','--wasm-max-pages','262144'];inp=['selfhost/main.goose','--stdlib','stdlib']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
cases={'current':B/'release/fixed.wasm'}
for tag in ['linear16','frame16','frame64']:
 dst=d/tag;src=dst/'source';train=dst/'train';train.mkdir(exist_ok=True);mod=train/'stats.wasm'
 subprocess.run([native,*inp,*flags,*wide,'--wasm-region-stats','-o',mod],cwd=src,check=True)
 vals={};record={}
 for n in ['squares','sorting','tour']:
  rel=Path('examples',n+'.goose');f=train/rel;f.parent.mkdir(exist_ok=True);shutil.copyfile(old/rel,f)
  out=train/(n+'.wasm');prof=train/(n+'.profile')
  subprocess.run([H,mod,'--cache',train/'stats.cwasm','--',rel,'--stdlib',src/'stdlib',*flags,*wide,'-o',out],cwd=train,env={**os.environ,'GOOSE_REGION_PROFILE':str(prof)},check=True);assert sha(out)==sha(old/(n+'.ref'))
  record[n]=dict(source=sha(f),output=sha(out),usage=sha(prof))
  for row in prof.read_text().splitlines():
   i,v=map(int,row.split());vals[i]=max(v,vals.get(i,0))
 profile=dst/'training.profile';profile.write_text(''.join(f'{i} {isqrt(v<<16)}\n' for i,v in sorted(vals.items())))
 result=dst/'trained.wasm';subprocess.run([native,*inp,*flags,'--wasm-bundled-host','--wasm-initial-pages','65535','--wasm-max-pages','65535','--wasm-region-profile',profile,'-o',result],cwd=src,check=True);cases[tag]=result
 (dst/'training.json').write_text(json.dumps(dict(controls=record,profile=sha(profile),compiler=sha(result)),indent=2)+'\n')
for n,order in [('first',list(cases)),('reverse',list(reversed(cases)))]:
 subprocess.run([R/'.venv/bin/python',R/'bench/results/2026-11-18/compiler-frame-cost/measure.py',W/'own',d/n,*[k+'='+str(cases[k]) for k in order],'--rounds','4','--cpu','4'],check=True)
