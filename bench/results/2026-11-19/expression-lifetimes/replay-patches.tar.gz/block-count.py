from trials import *
import hashlib
os.sched_setaffinity(0,{0});d=B/'block-trials';base=json.loads((B/'replay-count/counts.json').read_bytes());out={}
for name in ['linear16','frame16','frame64']:
 t=d/name;copy=t/'count-source';shutil.copytree(t/'source',copy,dirs_exist_ok=True);f=copy/F;s=f.read_text();a=s.index('fn life_replay(');b=s.index('\n}',a)
 p=s[a:b].replace('            let entry = read;','            visits[0]++; let entry = read;').replace('{ read = l.summary_reads[b.last].next as i64;', '{ visits[1]++; read = l.summary_reads[b.last].next as i64;');s=s[:a]+'var visits: i64[2];\n'+p+s[b:];s=s.replace('    if p.diagnostics.len == 0 { life_export_provenance','    print(visits);\n    if p.diagnostics.len == 0 { life_export_provenance')
 f.write_text(s);mod=t/'counter.wasm';args=['selfhost/main.goose','--stdlib','stdlib'];subprocess.run([B/'own/build-1/compiler-native',*args,'--target','wasm-direct','-O2','--wasm-memory64','--wasm-max-pages','262144','-o',mod],cwd=copy,check=True)
 p=subprocess.run([H,mod,'--cache',t/'counter.cwasm','--',*args,'--check'],cwd=S,capture_output=True,check=True);assert not p.stderr
 v,j=json.loads(p.stdout);out[name]=dict(read_visits=v,removed_visits=base['counts']['read_entries']-v,jumps=j,instrumented=hashlib.sha256(mod.read_bytes()).hexdigest());(d/'counts.json').write_text(json.dumps(out,indent=2)+'\n');print(name,out[name],flush=True)
