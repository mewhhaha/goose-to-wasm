from trial import *
a=S/'selfhost/checker_lifetimes.goose';orig=a.read_text()
for label in sys.argv[1:]:
 d=B/label;shutil.copytree(S,d/'source',dirs_exist_ok=True)
 s=orig;start=s.index('recursive fn life_eval(');stop=s.index('// m: for a class-keyed frame',start)
 if 'into' in label:s=(B/'body-into/source/selfhost/checker_lifetimes.goose').read_text()
 if 'seed' in label:
  s=s.replace('struct LifeItem {','let LIFE_EMPTY_VALUE = LifeValue {};\nstruct LifeItem {')
  start=s.index('recursive fn life_eval(');stop=s.index('// m: for a class-keyed frame',start)
  s=s[:start]+s[start:stop].replace('var out = LifeValue { type_id: n.type_id };','var out = LIFE_EMPTY_VALUE; out.type_id = n.type_id;')+s[stop:]
 if 'visit' in label:
  # Standalone expression statements discard the result. Both two-argument and
  # extended calls are retained through the regular evaluator for every other kind.
  pat=r'(^[ \t]*|; |\{ )(life_eval\(p, l, [^;]+?\);)'
  s=re.sub(pat,lambda m:m[1]+m[2].replace('life_eval(','life_visit(',1),s,flags=re.M)
  a=s.index('recursive fn life_eval(')
  fn='''recursive fn life_visit(p: Program&, l: Lifetimes&, node: i64, destination: i64 = 0, selected_result: i64 = -1) {
    if node < 0 { return; }
    let kind = p.nodes[node].kind;
    if kind == N_INTEGER || kind == N_FLOAT || kind == N_NULL || kind == N_BOOL || kind == N_EMPTY || kind == N_FUNCTION || kind == N_FUNCTION_VALUE || kind == N_IMPORT { return; }
    life_eval(p, l, node, destination, selected_result);
}
'''
  if 'direct' in label:
   fn=fn.replace('    life_eval(p, l, node, destination, selected_result);','''    if kind == N_NAME || kind == N_STRING { life_eval(p, l, node, destination, selected_result); return; }
    var out = LifeValue { type_id: p.nodes[node].type_id };
    life_eval_body(p, l, node, p.nodes[node], destination, selected_result, out);''')
  s=s[:a]+fn+'\n'+s[a:]
 assert s!=orig;(d/'source/selfhost/checker_lifetimes.goose').write_text(s)
 (d/'change.patch').write_text(''.join(difflib.unified_diff(orig.splitlines(True),s.splitlines(True),'a/selfhost/checker_lifetimes.goose','b/selfhost/checker_lifetimes.goose')))
 p=subprocess.run([N,*flags,*fixed,'-o',d/'compiler.wasm'],cwd=d/'source')
 print(label,p.returncode,flush=True)
