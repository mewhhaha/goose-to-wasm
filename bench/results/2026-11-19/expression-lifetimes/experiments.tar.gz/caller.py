from trial import *
from difflib import unified_diff
def build_source(n,s):
 d=B/n;shutil.copytree(S,d/'source',dirs_exist_ok=True);(d/'source'/f).write_text(s)
 (d/'change.patch').write_text(''.join(unified_diff(orig.splitlines(True),s.splitlines(True),'a/'+str(f),'b/'+str(f))))
 subprocess.run([N,*flags,*fixed,'-o',d/'compiler.wasm'],cwd=d/'source',check=True)
f=Path('selfhost/checker_lifetimes.goose');orig=(S/f).read_text()
for label in sys.argv[1:]:
 model='void'
 if 'flat' in label:model='void-flat'
 s=(B/model/'source'/f).read_text();s=s.replace('struct LifeItem {','let LIFE_EMPTY_VALUE = LifeValue {};\nstruct LifeItem {')
 s=s.replace('destination: i64, selected_result: i64, out: LifeValue&) {\n    if node < 0','out: LifeValue&, destination: i64 = 0, selected_result: i64 = -1) {\n    if node < 0')
 s=s.replace('var out = LifeValue {};\n    life_eval_into(p, l, node, destination, selected_result, out);','var out = LIFE_EMPTY_VALUE;\n    life_eval_into(p, l, node, out, destination, selected_result);')
 pat=r'(let|var) (\w+) = life_eval\(p, l, ([^(),;]+)([^();]*)\);'
 def sub(m):
  return f'var {m[2]} = LIFE_EMPTY_VALUE; life_eval_into(p, l, {m[3]}, {m[2]}{m[4]});'
 s,n=re.subn(pat,sub,s);assert n==14,n
 if 'fast' in label:
  s=s.replace('    var out = value;\n    if expected < 0 || expected == TYPE_VOID { return out; }','    if value.type_id == expected && value.contents == 0 { return value; }\n    var out = value;\n    if expected < 0 || expected == TYPE_VOID { return out; }')
 build_source(label,s)
