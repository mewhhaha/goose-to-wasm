from pathlib import Path
from collections import Counter
import sys,subprocess,json
B=Path(__file__).resolve().parent;R=B.parents[1];O=R/'build/lifetime-safe-19'
from instrument import read,leb,chunk
def ops(n,vector):
 arr=[]
 for w in ([16] if vector else [])+[8,4,2,1]:
  while sum(arr)+w<=n:arr.append(w)
 return arr
def move(n,a,vector):
 dst=leb(a);src=leb(a+1);code=bytearray(b'\x1a\x21'+src+b'\x21'+dst)
 parts=ops(n,vector);offset=0;stores=[]
 for w in parts:
  code+=b'\x20'+dst+b'\x20'+src
  ld,st={16:(b'\xfd\x00',b'\xfd\x0b'),8:(b'\x29',b'\x37'),4:(b'\x28',b'\x36'),2:(b'\x2f',b'\x3b'),1:(b'\x2d',b'\x3a')}[w]
  code+=ld+b'\x00'+leb(offset);stores.append(st+b'\0'+leb(offset));offset+=w
 return code+b''.join(stores[::-1])
def build(data,sites,selected,vec=False):
 p=8;sects=[]
 while p<len(data):
  tag=data[p];n,st=read(data,p+1);sects.append((tag,data[st:st+n]));p=st+n
 sec=dict(sects);ar=[];n,p=read(sec[1],0)
 for _ in range(n):
  assert sec[1][p]==96;nargs,p=read(sec[1],p+1);p+=nargs;nr,p=read(sec[1],p);p+=nr;ar.append(nargs)
 assert p==len(sec[1])
 n,p=read(sec[3],0);types=[]
 for _ in range(n):idx,p=read(sec[3],p);types.append(idx)
 code=sec[10];nf,p=read(code,0);assert nf==len(types)
 new=bytearray(leb(nf));counts=Counter()
 for i in range(nf):
  n,p=read(code,p);body=code[p:p+n];p+=n;keep=[(pos,w) for pos,w in sites.get(i,[]) if selected(w)]
  if not keep:new+=chunk(body);continue
  ng,at=read(body,0);lo=at;locals_=ar[types[i]]
  for _ in range(ng):m,at=read(body,at);at+=1;locals_+=m
  result=bytearray(leb(ng+1)+body[lo:at]+b'\x02\x7f')
  for pos,w in keep:
   assert body[pos:pos+4]==b'\xfc\x0a\0\0';result+=body[at:pos];result+=move(w,locals_,vec);at=pos+4;counts[w]+=1
  result+=body[at:];new+=chunk(result)
 return data[:8]+b''.join(bytes([k])+chunk(new if k==10 else v) for k,v in sects),counts
def findsites(p):
 sites={}
 dec=B/'target/release/wasm-copy-sites'
 for r in subprocess.check_output([dec,p],text=True).splitlines():
  i,at,kind,w=r.split()
  if kind=='copy' and int(w)>0:sites.setdefault(int(i),[]).append((int(at),int(w)))
 return sites
if __name__=='__main__':
 p=O/'release/fixed.wasm';s=findsites(p)
 for tag,ok,v in [('only72',lambda w:w==72,False),('small32',lambda w:0<w<=32,False),('small96',lambda w:0<w<=96,False),('simd96',lambda w:0<w<=96,True)]:
  out,counts=build(p.read_bytes(),s,ok,v);d=B/tag;d.mkdir(exist_ok=True);(d/'compiler.wasm').write_bytes(out);print(tag,sum(counts.values()),len(out),flush=True)
