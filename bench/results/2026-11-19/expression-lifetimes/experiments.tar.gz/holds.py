from trial import *
file=Path('selfhost/checker_lifetimes.goose');orig=(S/file).read_text()
for label in sys.argv[1:]:
 s=orig;tags=label.split('-')
 if 'baseplus' in tags:s=(B/'seed-same-construct-block-args/source'/file).read_text()
 if 'scalar' in tags:s=(B/'same/source'/file).read_text()
 def replace(a,b):
  global s
  assert s.count(a)==1,(a,s.count(a));s=s.replace(a,b)
 if 'held' in tags:
  replace('hold_floor: i64 = 0,','hold_floor: i64 = 0, replacement_hold: i64 = -1,')
  replace('        life_hold(l, receiver, n.left, kind);','''        let replacement = l.replacement_hold;
        if kind == 2 { l.replacement_hold = held; }
        life_hold(l, receiver, n.left, kind);''')
  replace('let value = life_coerce(p, l, natural, ty); l.hold_count = held;', 'let value = life_coerce(p, l, natural, ty); l.replacement_hold = replacement; l.hold_count = held;')
  replace('if quick { for index in l.hold_floor..l.hold_count { if l.holds[index].kind == 2 { quick = false; } } }','if quick { quick = l.replacement_hold < l.hold_floor; }')
  replace('    if l.discovery { return; }\n    var places = value.place;', '    if l.discovery || l.replacement_hold < l.hold_floor { return; }\n    var places = value.place;')
 if 'name' in tags:
  a=s.index('recursive fn life_eval(');z=s.index('recursive fn life_eval_body(',a)
  seg=s[a:z].replace('let cell = life_cell(p, l, n.symbol);','let cell = life_cell(p, l, n.symbol); let root = l.cells[cell].root;\n        let holds = life_holds(p, n.type_id);').replace('l.cells[cell].root);','root);').replace('l.roots[l.cells[cell].root]', 'l.roots[root]').replace('== TY_REF && life_holds(p, n.type_id)', '== TY_REF && holds').replace('if !life_holds(p, n.type_id)', 'if !holds')
  s=s[:a]+seg+s[z:]
 if 'read' in tags:
  a=s.index('fn life_construct_read(');z=s.index('fn life_coerce(',a);seg=s[a:z]
  seg=seg.replace('    var effect_places = value.place; if life_is_ref(p, value.type_id) { effect_places = value.refs; }\n','')
  seg=seg.replace('{ life_offer_once(l, LifeEffect { kind: 3, node: node, value: value, places: effect_places }, known); }','''{
        var effect_places = value.place; if life_is_ref(p, value.type_id) { effect_places = value.refs; }
        life_offer_once(l, LifeEffect { kind: 3, node: node, value: value, places: effect_places }, known);
    }''')
  seg=seg.replace('    var type_id = value.type_id;\n    if type_id >= 0 && p.types[type_id].kind == TY_REF { type_id = p.types[type_id].element; }\n','').replace('effect_type','type_id')
  s=s[:a]+seg+s[z:]
 assert s!=orig
 d=B/label;shutil.copytree(S,d/'source',dirs_exist_ok=True);(d/'source'/file).write_text(s);(d/'change.patch').write_text(''.join(difflib.unified_diff(orig.splitlines(True),s.splitlines(True),'a/'+str(file),'b/'+str(file))))
 p=subprocess.run([N,*flags,*fixed,'-o',d/'compiler.wasm'],cwd=d/'source');print(label,p.returncode,flush=True)
