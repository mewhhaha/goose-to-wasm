from trial import *
import time
tag,cpu,n,*ls=sys.argv[1:]
args=[]
for name in ls:
 if name=='native':p=N
 elif name=='base':p=O/'release/fixed.wasm'
 else:p=B/name/'compiler.wasm'
 args.append(name+'='+str(p))
subprocess.run([R/'.venv/bin/python',R/'bench/results/2026-11-18/compiler-frame-cost/measure.py',R/'build/replay-nov19/own',B/tag,*args,'--rounds',n,'--cpu',cpu],check=True)
