from trial import *
import json
f=Path('selfhost/checker_lifetimes.goose');d=B/'discovery-count';shutil.copytree(S,d/'source',dirs_exist_ok=True);s=(S/f).read_text()
s=s.replace('fn life_hold(l:', 'var activity: i64[9];\nfn life_hold(l:').replace('    let entry = LifeHold { value: value,','    if l.discovery { activity[0]++; } else { activity[1]++; }\n    let entry = LifeHold { value: value,').replace('    let entry = LifeFuture {','    if l.discovery { activity[2]++; } else { activity[3]++; }\n    let entry = LifeFuture {').replace('    var out = value;\n    if expected < 0 || expected == TYPE_VOID { return out; }', '    activity[4]++; if value.type_id == expected && value.contents == 0 { activity[5]++; }\n    var out = value;\n    if expected < 0 || expected == TYPE_VOID { return out; }').replace('    if p.diagnostics.len == 0 { life_export_provenance', '    print(activity);\n    if p.diagnostics.len == 0 { life_export_provenance')
(d/'source'/f).write_text(s);(d/'change.patch').write_text(''.join(difflib.unified_diff((S/f).read_text().splitlines(True),s.splitlines(True),'a/'+str(f),'b/'+str(f))))
subprocess.run([N,*flags,*fixed,'-o',d/'compiler.wasm'],cwd=d/'source',check=True)
r=subprocess.run([H,d/'compiler.wasm','--cache',d/'compiler.cwasm','--',*flags,*wide,'--check'],cwd=R/'build/replay-nov19/own/source',capture_output=True,check=True)
assert not r.stderr;print(r.stdout.decode(),flush=True);(d/'counts.json').write_bytes(r.stdout)
