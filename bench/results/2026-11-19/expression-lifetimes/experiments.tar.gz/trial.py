from pathlib import Path
import os,sys,subprocess,resource,shutil,re,difflib
R=Path(__file__).resolve().parents[2];B=R/'build/result-copies-19';O=R/'build/lifetime-safe-19';S=O/'own/source';N=O/'own/build-1/compiler-native';H=R/'host/rust/target/release/goose-wasmtime'
resource.setrlimit(resource.RLIMIT_STACK,(256<<20,resource.getrlimit(resource.RLIMIT_STACK)[1]))
flags=['selfhost/main.goose','--stdlib','stdlib','--target','wasm-direct','-O2']
fixed=['--wasm-bundled-host','--wasm-initial-pages','65535','--wasm-max-pages','65535','--wasm-region-profile',O/'release/training.profile']
wide=['--wasm-memory64','--wasm-max-pages','262144']
def build(label):
 d=B/label;d.mkdir(exist_ok=True);shutil.copytree(S,d/'source',dirs_exist_ok=True)
 codegen=label.startswith('cg-'); f=Path('selfhost')/('codegen.goose' if codegen else 'checker_lifetimes.goose');s=(S/f).read_text();orig=s
 if not codegen:
  a=s.index('recursive fn life_eval(');b=s.index('recursive fn life_eval_body(',a);z=s.index('// m: for a class-keyed frame',b)
  start=s[a:b];body=s[b:z];split='    return life_eval_body(p, l, node, n, destination, selected_result);'
  sig,rest=body.split('    var out = LifeValue { type_id: n.type_id };\n',1);init='var out = LifeValue { type_id: n.type_id };'
  if label=='flat':
   s=s[:a]+start[:start.index(split)]+rest+s[z:]
  elif label=='body-into':
   start=start.replace(split,'    life_eval_body(p, l, node, n, destination, selected_result, out); return out;')
   sig=sig.replace('selected_result: i64) -> LifeValue','selected_result: i64, out: LifeValue&)')
   rest=rest.replace('return out;', 'return;')
   rest=re.sub(r'return (life_[^;]+);',r'out = \1; return;',rest)
   # A void function can complete naturally.
   rest=rest[:rest.rindex('    return;')]+rest[rest.rindex('    return;')+len('    return;\n'):]
   s=s[:a]+start+sig+rest+s[z:]
  elif label.startswith('void'):
   # Either every call or only standalone statements receive an explicit destination.
   oldsig=start[:start.index(' {')];wrapper=oldsig+' {\n    var out = LifeValue {};\n    life_eval_into(p, l, node, destination, selected_result, out);\n    return out;\n}\n\n'
   newstart=start.replace(oldsig,oldsig.replace('life_eval(', 'life_eval_into(').replace('destination: i64 = 0, selected_result: i64 = -1) -> LifeValue','destination: i64, selected_result: i64, out: LifeValue&)'))
   newstart=newstart.replace('if node < 0 { return LifeValue {}; }','if node < 0 { return; }').replace(init,'out.type_id = n.type_id;').replace('return out;','return;')
   sig=sig.replace('selected_result: i64) -> LifeValue','selected_result: i64, out: LifeValue&)')
   rest=rest.replace('return out;', 'return;');rest=re.sub(r'return (life_[^;]+);',r'out = \1; return;',rest)
   newstart=newstart.replace(split,'    life_eval_body(p, l, node, n, destination, selected_result, out);')
   if label=='void-flat':newstart=newstart[:newstart.index('    life_eval_body(p, l, node, n,')];sig=''
   s=s[:a]+wrapper+newstart+sig+rest+s[z:]
  else:raise ValueError(label)
 else:
  old='        cg_set_values(p, m, f, n.first, cg_result_type(p, f.function), first_slot, node);'
  assert s.count(old)==1
  pred='p.nodes[n.first].kind == N_NAME'
  if label=='cg-call':pred='p.nodes[n.first].kind == N_CALL && p.nodes[n.first].symbol >= 0 && (p.symbols[p.nodes[n.first].symbol].flags & (S_FUNCTION | S_BUILTIN)) == S_FUNCTION && p.symbols[p.nodes[n.first].symbol].node >= 0'
  if label=='cg-both':pred='p.nodes[n.first].kind == N_NAME || p.nodes[n.first].kind == N_CALL && p.nodes[n.first].symbol >= 0 && (p.symbols[p.nodes[n.first].symbol].flags & (S_FUNCTION | S_BUILTIN)) == S_FUNCTION && p.symbols[p.nodes[n.first].symbol].node >= 0'
  s=s.replace(old,'''        let result_type = cg_result_type(p, f.function);
        if f.results.len == 1 && n.first >= 0 && p.nodes[n.first].next < 0 && f.defers.len == 0 && cg_receiving(f, first_slot, 0) < 0 &&
           (PRED) && p.nodes[n.first].type_id == result_type && cg_type_kind(p, result_type) == TY_STRUCT && cg_snapshot_field(p, result_type) {
            cg_to(p, m, f, n.first, result_type);
            if !cg_diverges(p, n.first) { cg_set(f, first_slot); }
        } else { cg_set_values(p, m, f, n.first, result_type, first_slot, node); }'''.replace('PRED',pred))
 (d/'source'/f).write_text(s);(d/'change.patch').write_text(''.join(difflib.unified_diff(orig.splitlines(True),s.splitlines(True),'a/'+str(f),'b/'+str(f))))
 if codegen:
  subprocess.run([N,*flags,*wide,'-o',d/'emitter.wasm'],cwd=d/'source',check=True)
  subprocess.run([H,d/'emitter.wasm','--cache',d/'emitter.cwasm','--',*flags,*fixed,'-o',d/'compiler.wasm'],cwd=S,check=True)
 else:subprocess.run([N,*flags,*fixed,'-o',d/'compiler.wasm'],cwd=d/'source',check=True)
 print(label,'built',flush=True)
if __name__=='__main__':
 for name in sys.argv[1:]:
  try:build(name)
  except subprocess.CalledProcessError as e:print(name,'failed',e.returncode,flush=True)
