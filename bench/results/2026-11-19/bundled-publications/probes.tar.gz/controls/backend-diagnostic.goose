recursive fn pair() -> i64, i64 { return 2, 3; }
recursive fn print_tuple() { let a, b = pair(); print(a + b); }
fn main() {
    var result: i64[>..] = if 1 < 2 { [1, 2] } else { [3, 4] };
    let image, ok = from_bytes<i64[>..]>("");
    print_tuple();
    print(result, image, ok);
}
