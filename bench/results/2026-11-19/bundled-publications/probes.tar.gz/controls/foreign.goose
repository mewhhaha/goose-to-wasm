extern fn write(text: const u8[:]) = "gs_os_write_stdout";
var result: i64[>..] = if 1 < 2 { [1, 2] } else { [3, 4] };
fn main() { write("foreign "); print(result); }
