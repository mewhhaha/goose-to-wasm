struct R { tag: i64, data: i64[>..] }
recursive fn take(out: R = if 1 < 2 { R{8, [1, 2]} } else { R{9, [3, 4]} }) { print(out.tag, " ", out.data); }
fn main() { take(); }
