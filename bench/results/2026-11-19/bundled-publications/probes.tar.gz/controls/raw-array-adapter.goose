inline fn make(n: i64) -> u8[u16] { "xy" }
fn main() { var out: u8[varint] = make(1); print(out); }
