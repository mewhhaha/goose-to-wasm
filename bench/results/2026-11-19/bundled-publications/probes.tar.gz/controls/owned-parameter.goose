recursive fn take(out: i64[>..]) { print(out); }
fn main() { take(if 1 < 2 { [1, 2] } else { [3, 4] }); }
