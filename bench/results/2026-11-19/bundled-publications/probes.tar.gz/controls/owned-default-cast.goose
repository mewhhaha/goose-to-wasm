recursive fn take(out: i64[>..] = if 1 < 2 { [1, 2] as i64[2] } else { [3, 4] as i64[2] }) { print(out); }
fn main() { take(); }
