fn main() { var out: i64[>..] = if 1 < 2 { [1, 2] } else { [3, 4] }; print(out); }
