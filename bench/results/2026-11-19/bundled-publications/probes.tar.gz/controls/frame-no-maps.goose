struct Record { tag: i64, values: i64[>..] }
fn main() {
    var record = Record { 8, [1, 2] };
    record.tag += 4;
    record.values.push(3);
    print(record.tag, " ", record.values);
}
