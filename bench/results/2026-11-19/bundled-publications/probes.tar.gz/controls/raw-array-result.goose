recursive fn make(n: i64) -> i64[] { [n, n + 1] }
fn main() { var out: i64[>..] = [9]; out.append(make(1)); print(out); }
