fn main() {
    var result: i64[>..] = [];
    var completed = 0;
    for i in 0..8 {
        if i == 2 { continue; }
        let done = block {
            defer completed++;
            for j in 0..2 {
                if i == 4 || j == 1 { continue; }
                result.push(i);
            }
            if i == 5 { break true; }
            false
        };
        if done { break; }
    }
    assert(completed == 5);
    print(result);
}
