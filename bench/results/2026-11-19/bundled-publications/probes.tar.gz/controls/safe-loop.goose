var result: i64[>..] = [];
fn main() {
    for i in 0..8 {
        if i == 4 { continue; }
        result.push(i);
        if i == 6 { break; }
    }
    print(result);
}
