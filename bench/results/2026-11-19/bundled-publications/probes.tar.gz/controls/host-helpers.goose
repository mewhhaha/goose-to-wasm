import os;
fn main() {
    var out: u8[>..] = [];
    out.format("before:");
    out.format(12);
    assert(read_file("host-control.txt", out));
    print(out);
}
