recursive fn pair() -> i64, i64 { return 2, 3; }
recursive fn print_tuple() { let a, b = pair(); print(a + b); }
var result: i64[>..] = [1, 2];
fn main() { print_tuple(); print(result); }
