fn main() { var left: i64[>..] = [1,2]; var right: i64[>..] = [3,4]; var out: i64[>..] = if left.len == 2 { copy(left) } else { copy(right) }; print(out); }
