var result: i64[>..] = if 1 < 2 { [1, 2] } else { [3, 4] };
export fn view() -> i64 { result.len }
