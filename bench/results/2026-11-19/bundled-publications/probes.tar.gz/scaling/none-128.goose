recursive fn task_0(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 1];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_1(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 2];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_2(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 3];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_3(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 4];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_4(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 5];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_5(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 6];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_6(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 7];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_7(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 8];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_8(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 9];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_9(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 10];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_10(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 11];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_11(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 12];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_12(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 13];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_13(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 14];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_14(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 15];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_15(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 16];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_16(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 17];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_17(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 18];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_18(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 19];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_19(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 20];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_20(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 21];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_21(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 22];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_22(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 23];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_23(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 24];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_24(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 25];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_25(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 26];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_26(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 27];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_27(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 28];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_28(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 29];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_29(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 30];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_30(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 31];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_31(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 32];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_32(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 33];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_33(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 34];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_34(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 35];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_35(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 36];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_36(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 37];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_37(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 38];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_38(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 39];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_39(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 40];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_40(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 41];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_41(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 42];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_42(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 43];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_43(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 44];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_44(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 45];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_45(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 46];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_46(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 47];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_47(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 48];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_48(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 49];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_49(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 50];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_50(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 51];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_51(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 52];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_52(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 53];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_53(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 54];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_54(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 55];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_55(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 56];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_56(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 57];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_57(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 58];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_58(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 59];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_59(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 60];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_60(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 61];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_61(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 62];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_62(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 63];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_63(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 64];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_64(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 65];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_65(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 66];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_66(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 67];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_67(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 68];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_68(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 69];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_69(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 70];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_70(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 71];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_71(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 72];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_72(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 73];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_73(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 74];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_74(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 75];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_75(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 76];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_76(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 77];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_77(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 78];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_78(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 79];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_79(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 80];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_80(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 81];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_81(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 82];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_82(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 83];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_83(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 84];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_84(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 85];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_85(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 86];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_86(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 87];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_87(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 88];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_88(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 89];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_89(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 90];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_90(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 91];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_91(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 92];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_92(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 93];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_93(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 94];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_94(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 95];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_95(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 96];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_96(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 97];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_97(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 98];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_98(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 99];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_99(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 100];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_100(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 101];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_101(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 102];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_102(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 103];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_103(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 104];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_104(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 105];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_105(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 106];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_106(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 107];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_107(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 108];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_108(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 109];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_109(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 110];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_110(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 111];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_111(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 112];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_112(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 113];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_113(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 114];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_114(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 115];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_115(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 116];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_116(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 117];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_117(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 118];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_118(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 119];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_119(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 120];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_120(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 121];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_121(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 122];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_122(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 123];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_123(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 124];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_124(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 125];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_125(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 126];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_126(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 127];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_127(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 128];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
var result: i64[>..] = [1, 2];
fn main() {
    var sum: i64 = 0;
    sum += task_0(0);
    sum += task_1(1);
    sum += task_2(2);
    sum += task_3(3);
    sum += task_4(4);
    sum += task_5(5);
    sum += task_6(6);
    sum += task_7(7);
    sum += task_8(8);
    sum += task_9(9);
    sum += task_10(10);
    sum += task_11(11);
    sum += task_12(12);
    sum += task_13(13);
    sum += task_14(14);
    sum += task_15(15);
    sum += task_16(16);
    sum += task_17(17);
    sum += task_18(18);
    sum += task_19(19);
    sum += task_20(20);
    sum += task_21(21);
    sum += task_22(22);
    sum += task_23(23);
    sum += task_24(24);
    sum += task_25(25);
    sum += task_26(26);
    sum += task_27(27);
    sum += task_28(28);
    sum += task_29(29);
    sum += task_30(30);
    sum += task_31(31);
    sum += task_32(32);
    sum += task_33(33);
    sum += task_34(34);
    sum += task_35(35);
    sum += task_36(36);
    sum += task_37(37);
    sum += task_38(38);
    sum += task_39(39);
    sum += task_40(40);
    sum += task_41(41);
    sum += task_42(42);
    sum += task_43(43);
    sum += task_44(44);
    sum += task_45(45);
    sum += task_46(46);
    sum += task_47(47);
    sum += task_48(48);
    sum += task_49(49);
    sum += task_50(50);
    sum += task_51(51);
    sum += task_52(52);
    sum += task_53(53);
    sum += task_54(54);
    sum += task_55(55);
    sum += task_56(56);
    sum += task_57(57);
    sum += task_58(58);
    sum += task_59(59);
    sum += task_60(60);
    sum += task_61(61);
    sum += task_62(62);
    sum += task_63(63);
    sum += task_64(64);
    sum += task_65(65);
    sum += task_66(66);
    sum += task_67(67);
    sum += task_68(68);
    sum += task_69(69);
    sum += task_70(70);
    sum += task_71(71);
    sum += task_72(72);
    sum += task_73(73);
    sum += task_74(74);
    sum += task_75(75);
    sum += task_76(76);
    sum += task_77(77);
    sum += task_78(78);
    sum += task_79(79);
    sum += task_80(80);
    sum += task_81(81);
    sum += task_82(82);
    sum += task_83(83);
    sum += task_84(84);
    sum += task_85(85);
    sum += task_86(86);
    sum += task_87(87);
    sum += task_88(88);
    sum += task_89(89);
    sum += task_90(90);
    sum += task_91(91);
    sum += task_92(92);
    sum += task_93(93);
    sum += task_94(94);
    sum += task_95(95);
    sum += task_96(96);
    sum += task_97(97);
    sum += task_98(98);
    sum += task_99(99);
    sum += task_100(100);
    sum += task_101(101);
    sum += task_102(102);
    sum += task_103(103);
    sum += task_104(104);
    sum += task_105(105);
    sum += task_106(106);
    sum += task_107(107);
    sum += task_108(108);
    sum += task_109(109);
    sum += task_110(110);
    sum += task_111(111);
    sum += task_112(112);
    sum += task_113(113);
    sum += task_114(114);
    sum += task_115(115);
    sum += task_116(116);
    sum += task_117(117);
    sum += task_118(118);
    sum += task_119(119);
    sum += task_120(120);
    sum += task_121(121);
    sum += task_122(122);
    sum += task_123(123);
    sum += task_124(124);
    sum += task_125(125);
    sum += task_126(126);
    sum += task_127(127);
    print(sum, " ", result.len);
}
