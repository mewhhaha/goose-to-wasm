recursive fn task_0(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 1];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_1(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 2];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_2(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 3];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_3(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 4];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_4(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 5];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_5(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 6];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_6(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 7];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_7(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 8];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_8(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 9];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_9(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 10];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_10(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 11];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_11(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 12];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_12(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 13];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_13(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 14];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_14(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 15];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_15(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 16];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_16(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 17];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_17(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 18];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_18(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 19];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_19(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 20];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_20(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 21];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_21(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 22];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_22(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 23];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_23(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 24];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_24(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 25];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_25(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 26];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_26(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 27];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_27(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 28];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_28(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 29];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_29(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 30];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_30(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 31];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_31(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 32];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
var result: i64[>..] = if 1 < 2 { [1, 2] } else { [3, 4] };
fn main() {
    var sum: i64 = 0;
    sum += task_0(0);
    sum += task_1(1);
    sum += task_2(2);
    sum += task_3(3);
    sum += task_4(4);
    sum += task_5(5);
    sum += task_6(6);
    sum += task_7(7);
    sum += task_8(8);
    sum += task_9(9);
    sum += task_10(10);
    sum += task_11(11);
    sum += task_12(12);
    sum += task_13(13);
    sum += task_14(14);
    sum += task_15(15);
    sum += task_16(16);
    sum += task_17(17);
    sum += task_18(18);
    sum += task_19(19);
    sum += task_20(20);
    sum += task_21(21);
    sum += task_22(22);
    sum += task_23(23);
    sum += task_24(24);
    sum += task_25(25);
    sum += task_26(26);
    sum += task_27(27);
    sum += task_28(28);
    sum += task_29(29);
    sum += task_30(30);
    sum += task_31(31);
    print(sum, " ", result.len);
}
