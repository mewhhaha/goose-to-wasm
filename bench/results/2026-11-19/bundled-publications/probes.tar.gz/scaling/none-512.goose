recursive fn task_0(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 1];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_1(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 2];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_2(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 3];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_3(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 4];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_4(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 5];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_5(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 6];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_6(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 7];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_7(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 8];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_8(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 9];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_9(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 10];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_10(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 11];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_11(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 12];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_12(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 13];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_13(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 14];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_14(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 15];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_15(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 16];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_16(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 17];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_17(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 18];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_18(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 19];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_19(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 20];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_20(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 21];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_21(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 22];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_22(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 23];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_23(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 24];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_24(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 25];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_25(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 26];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_26(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 27];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_27(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 28];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_28(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 29];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_29(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 30];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_30(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 31];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_31(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 32];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_32(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 33];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_33(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 34];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_34(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 35];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_35(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 36];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_36(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 37];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_37(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 38];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_38(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 39];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_39(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 40];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_40(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 41];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_41(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 42];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_42(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 43];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_43(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 44];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_44(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 45];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_45(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 46];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_46(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 47];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_47(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 48];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_48(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 49];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_49(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 50];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_50(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 51];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_51(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 52];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_52(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 53];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_53(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 54];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_54(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 55];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_55(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 56];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_56(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 57];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_57(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 58];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_58(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 59];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_59(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 60];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_60(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 61];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_61(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 62];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_62(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 63];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_63(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 64];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_64(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 65];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_65(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 66];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_66(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 67];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_67(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 68];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_68(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 69];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_69(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 70];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_70(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 71];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_71(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 72];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_72(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 73];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_73(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 74];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_74(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 75];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_75(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 76];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_76(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 77];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_77(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 78];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_78(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 79];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_79(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 80];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_80(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 81];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_81(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 82];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_82(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 83];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_83(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 84];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_84(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 85];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_85(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 86];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_86(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 87];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_87(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 88];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_88(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 89];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_89(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 90];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_90(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 91];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_91(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 92];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_92(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 93];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_93(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 94];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_94(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 95];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_95(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 96];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_96(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 97];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_97(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 98];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_98(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 99];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_99(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 100];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_100(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 101];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_101(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 102];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_102(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 103];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_103(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 104];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_104(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 105];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_105(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 106];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_106(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 107];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_107(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 108];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_108(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 109];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_109(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 110];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_110(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 111];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_111(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 112];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_112(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 113];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_113(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 114];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_114(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 115];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_115(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 116];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_116(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 117];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_117(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 118];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_118(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 119];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_119(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 120];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_120(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 121];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_121(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 122];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_122(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 123];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_123(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 124];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_124(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 125];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_125(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 126];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_126(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 127];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_127(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 128];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_128(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 129];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_129(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 130];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_130(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 131];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_131(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 132];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_132(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 133];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_133(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 134];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_134(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 135];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_135(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 136];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_136(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 137];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_137(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 138];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_138(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 139];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_139(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 140];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_140(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 141];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_141(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 142];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_142(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 143];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_143(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 144];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_144(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 145];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_145(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 146];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_146(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 147];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_147(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 148];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_148(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 149];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_149(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 150];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_150(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 151];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_151(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 152];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_152(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 153];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_153(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 154];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_154(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 155];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_155(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 156];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_156(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 157];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_157(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 158];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_158(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 159];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_159(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 160];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_160(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 161];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_161(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 162];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_162(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 163];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_163(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 164];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_164(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 165];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_165(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 166];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_166(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 167];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_167(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 168];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_168(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 169];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_169(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 170];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_170(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 171];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_171(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 172];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_172(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 173];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_173(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 174];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_174(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 175];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_175(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 176];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_176(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 177];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_177(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 178];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_178(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 179];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_179(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 180];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_180(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 181];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_181(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 182];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_182(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 183];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_183(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 184];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_184(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 185];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_185(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 186];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_186(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 187];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_187(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 188];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_188(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 189];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_189(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 190];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_190(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 191];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_191(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 192];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_192(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 193];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_193(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 194];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_194(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 195];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_195(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 196];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_196(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 197];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_197(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 198];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_198(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 199];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_199(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 200];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_200(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 201];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_201(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 202];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_202(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 203];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_203(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 204];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_204(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 205];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_205(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 206];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_206(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 207];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_207(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 208];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_208(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 209];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_209(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 210];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_210(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 211];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_211(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 212];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_212(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 213];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_213(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 214];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_214(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 215];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_215(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 216];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_216(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 217];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_217(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 218];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_218(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 219];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_219(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 220];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_220(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 221];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_221(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 222];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_222(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 223];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_223(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 224];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_224(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 225];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_225(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 226];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_226(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 227];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_227(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 228];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_228(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 229];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_229(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 230];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_230(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 231];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_231(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 232];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_232(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 233];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_233(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 234];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_234(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 235];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_235(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 236];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_236(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 237];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_237(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 238];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_238(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 239];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_239(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 240];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_240(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 241];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_241(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 242];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_242(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 243];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_243(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 244];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_244(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 245];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_245(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 246];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_246(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 247];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_247(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 248];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_248(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 249];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_249(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 250];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_250(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 251];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_251(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 252];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_252(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 253];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_253(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 254];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_254(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 255];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_255(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 256];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_256(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 257];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_257(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 258];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_258(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 259];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_259(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 260];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_260(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 261];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_261(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 262];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_262(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 263];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_263(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 264];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_264(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 265];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_265(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 266];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_266(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 267];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_267(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 268];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_268(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 269];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_269(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 270];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_270(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 271];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_271(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 272];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_272(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 273];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_273(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 274];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_274(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 275];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_275(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 276];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_276(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 277];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_277(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 278];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_278(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 279];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_279(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 280];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_280(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 281];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_281(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 282];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_282(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 283];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_283(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 284];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_284(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 285];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_285(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 286];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_286(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 287];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_287(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 288];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_288(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 289];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_289(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 290];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_290(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 291];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_291(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 292];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_292(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 293];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_293(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 294];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_294(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 295];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_295(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 296];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_296(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 297];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_297(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 298];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_298(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 299];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_299(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 300];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_300(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 301];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_301(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 302];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_302(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 303];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_303(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 304];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_304(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 305];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_305(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 306];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_306(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 307];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_307(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 308];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_308(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 309];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_309(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 310];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_310(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 311];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_311(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 312];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_312(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 313];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_313(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 314];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_314(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 315];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_315(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 316];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_316(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 317];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_317(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 318];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_318(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 319];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_319(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 320];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_320(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 321];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_321(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 322];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_322(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 323];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_323(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 324];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_324(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 325];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_325(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 326];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_326(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 327];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_327(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 328];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_328(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 329];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_329(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 330];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_330(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 331];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_331(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 332];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_332(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 333];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_333(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 334];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_334(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 335];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_335(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 336];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_336(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 337];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_337(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 338];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_338(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 339];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_339(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 340];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_340(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 341];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_341(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 342];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_342(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 343];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_343(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 344];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_344(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 345];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_345(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 346];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_346(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 347];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_347(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 348];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_348(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 349];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_349(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 350];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_350(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 351];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_351(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 352];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_352(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 353];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_353(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 354];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_354(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 355];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_355(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 356];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_356(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 357];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_357(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 358];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_358(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 359];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_359(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 360];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_360(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 361];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_361(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 362];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_362(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 363];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_363(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 364];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_364(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 365];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_365(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 366];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_366(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 367];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_367(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 368];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_368(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 369];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_369(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 370];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_370(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 371];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_371(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 372];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_372(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 373];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_373(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 374];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_374(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 375];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_375(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 376];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_376(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 377];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_377(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 378];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_378(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 379];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_379(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 380];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_380(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 381];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_381(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 382];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_382(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 383];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_383(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 384];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_384(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 385];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_385(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 386];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_386(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 387];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_387(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 388];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_388(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 389];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_389(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 390];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_390(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 391];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_391(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 392];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_392(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 393];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_393(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 394];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_394(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 395];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_395(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 396];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_396(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 397];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_397(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 398];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_398(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 399];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_399(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 400];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_400(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 401];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_401(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 402];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_402(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 403];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_403(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 404];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_404(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 405];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_405(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 406];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_406(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 407];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_407(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 408];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_408(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 409];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_409(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 410];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_410(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 411];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_411(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 412];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_412(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 413];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_413(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 414];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_414(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 415];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_415(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 416];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_416(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 417];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_417(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 418];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_418(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 419];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_419(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 420];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_420(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 421];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_421(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 422];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_422(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 423];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_423(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 424];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_424(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 425];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_425(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 426];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_426(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 427];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_427(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 428];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_428(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 429];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_429(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 430];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_430(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 431];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_431(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 432];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_432(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 433];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_433(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 434];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_434(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 435];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_435(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 436];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_436(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 437];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_437(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 438];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_438(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 439];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_439(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 440];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_440(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 441];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_441(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 442];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_442(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 443];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_443(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 444];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_444(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 445];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_445(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 446];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_446(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 447];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_447(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 448];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_448(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 449];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_449(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 450];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_450(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 451];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_451(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 452];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_452(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 453];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_453(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 454];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_454(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 455];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_455(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 456];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_456(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 457];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_457(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 458];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_458(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 459];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_459(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 460];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_460(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 461];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_461(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 462];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_462(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 463];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_463(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 464];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_464(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 465];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_465(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 466];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_466(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 467];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_467(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 468];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_468(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 469];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_469(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 470];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_470(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 471];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_471(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 472];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_472(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 473];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_473(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 474];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_474(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 475];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_475(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 476];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_476(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 477];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_477(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 478];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_478(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 479];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_479(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 480];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_480(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 481];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_481(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 482];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_482(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 483];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_483(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 484];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_484(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 485];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_485(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 486];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_486(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 487];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_487(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 488];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_488(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 489];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_489(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 490];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_490(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 491];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_491(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 492];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_492(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 493];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_493(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 494];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_494(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 495];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_495(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 496];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_496(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 497];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_497(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 498];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_498(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 499];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_499(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 500];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_500(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 501];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_501(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 502];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_502(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 503];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_503(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 504];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_504(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 505];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_505(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 506];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_506(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 507];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_507(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 508];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_508(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 509];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_509(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 510];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_510(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 511];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
recursive fn task_511(n: i64) -> i64 {
    var values: i64[>..] = [n, n + 512];
    for j in 0..8 {
        if j == 4 { continue; }
        values.push(j);
        if j == 6 { break; }
    }
    return values[0] + values[values.len - 1];
}
var result: i64[>..] = [1, 2];
fn main() {
    var sum: i64 = 0;
    sum += task_0(0);
    sum += task_1(1);
    sum += task_2(2);
    sum += task_3(3);
    sum += task_4(4);
    sum += task_5(5);
    sum += task_6(6);
    sum += task_7(7);
    sum += task_8(8);
    sum += task_9(9);
    sum += task_10(10);
    sum += task_11(11);
    sum += task_12(12);
    sum += task_13(13);
    sum += task_14(14);
    sum += task_15(15);
    sum += task_16(16);
    sum += task_17(17);
    sum += task_18(18);
    sum += task_19(19);
    sum += task_20(20);
    sum += task_21(21);
    sum += task_22(22);
    sum += task_23(23);
    sum += task_24(24);
    sum += task_25(25);
    sum += task_26(26);
    sum += task_27(27);
    sum += task_28(28);
    sum += task_29(29);
    sum += task_30(30);
    sum += task_31(31);
    sum += task_32(32);
    sum += task_33(33);
    sum += task_34(34);
    sum += task_35(35);
    sum += task_36(36);
    sum += task_37(37);
    sum += task_38(38);
    sum += task_39(39);
    sum += task_40(40);
    sum += task_41(41);
    sum += task_42(42);
    sum += task_43(43);
    sum += task_44(44);
    sum += task_45(45);
    sum += task_46(46);
    sum += task_47(47);
    sum += task_48(48);
    sum += task_49(49);
    sum += task_50(50);
    sum += task_51(51);
    sum += task_52(52);
    sum += task_53(53);
    sum += task_54(54);
    sum += task_55(55);
    sum += task_56(56);
    sum += task_57(57);
    sum += task_58(58);
    sum += task_59(59);
    sum += task_60(60);
    sum += task_61(61);
    sum += task_62(62);
    sum += task_63(63);
    sum += task_64(64);
    sum += task_65(65);
    sum += task_66(66);
    sum += task_67(67);
    sum += task_68(68);
    sum += task_69(69);
    sum += task_70(70);
    sum += task_71(71);
    sum += task_72(72);
    sum += task_73(73);
    sum += task_74(74);
    sum += task_75(75);
    sum += task_76(76);
    sum += task_77(77);
    sum += task_78(78);
    sum += task_79(79);
    sum += task_80(80);
    sum += task_81(81);
    sum += task_82(82);
    sum += task_83(83);
    sum += task_84(84);
    sum += task_85(85);
    sum += task_86(86);
    sum += task_87(87);
    sum += task_88(88);
    sum += task_89(89);
    sum += task_90(90);
    sum += task_91(91);
    sum += task_92(92);
    sum += task_93(93);
    sum += task_94(94);
    sum += task_95(95);
    sum += task_96(96);
    sum += task_97(97);
    sum += task_98(98);
    sum += task_99(99);
    sum += task_100(100);
    sum += task_101(101);
    sum += task_102(102);
    sum += task_103(103);
    sum += task_104(104);
    sum += task_105(105);
    sum += task_106(106);
    sum += task_107(107);
    sum += task_108(108);
    sum += task_109(109);
    sum += task_110(110);
    sum += task_111(111);
    sum += task_112(112);
    sum += task_113(113);
    sum += task_114(114);
    sum += task_115(115);
    sum += task_116(116);
    sum += task_117(117);
    sum += task_118(118);
    sum += task_119(119);
    sum += task_120(120);
    sum += task_121(121);
    sum += task_122(122);
    sum += task_123(123);
    sum += task_124(124);
    sum += task_125(125);
    sum += task_126(126);
    sum += task_127(127);
    sum += task_128(128);
    sum += task_129(129);
    sum += task_130(130);
    sum += task_131(131);
    sum += task_132(132);
    sum += task_133(133);
    sum += task_134(134);
    sum += task_135(135);
    sum += task_136(136);
    sum += task_137(137);
    sum += task_138(138);
    sum += task_139(139);
    sum += task_140(140);
    sum += task_141(141);
    sum += task_142(142);
    sum += task_143(143);
    sum += task_144(144);
    sum += task_145(145);
    sum += task_146(146);
    sum += task_147(147);
    sum += task_148(148);
    sum += task_149(149);
    sum += task_150(150);
    sum += task_151(151);
    sum += task_152(152);
    sum += task_153(153);
    sum += task_154(154);
    sum += task_155(155);
    sum += task_156(156);
    sum += task_157(157);
    sum += task_158(158);
    sum += task_159(159);
    sum += task_160(160);
    sum += task_161(161);
    sum += task_162(162);
    sum += task_163(163);
    sum += task_164(164);
    sum += task_165(165);
    sum += task_166(166);
    sum += task_167(167);
    sum += task_168(168);
    sum += task_169(169);
    sum += task_170(170);
    sum += task_171(171);
    sum += task_172(172);
    sum += task_173(173);
    sum += task_174(174);
    sum += task_175(175);
    sum += task_176(176);
    sum += task_177(177);
    sum += task_178(178);
    sum += task_179(179);
    sum += task_180(180);
    sum += task_181(181);
    sum += task_182(182);
    sum += task_183(183);
    sum += task_184(184);
    sum += task_185(185);
    sum += task_186(186);
    sum += task_187(187);
    sum += task_188(188);
    sum += task_189(189);
    sum += task_190(190);
    sum += task_191(191);
    sum += task_192(192);
    sum += task_193(193);
    sum += task_194(194);
    sum += task_195(195);
    sum += task_196(196);
    sum += task_197(197);
    sum += task_198(198);
    sum += task_199(199);
    sum += task_200(200);
    sum += task_201(201);
    sum += task_202(202);
    sum += task_203(203);
    sum += task_204(204);
    sum += task_205(205);
    sum += task_206(206);
    sum += task_207(207);
    sum += task_208(208);
    sum += task_209(209);
    sum += task_210(210);
    sum += task_211(211);
    sum += task_212(212);
    sum += task_213(213);
    sum += task_214(214);
    sum += task_215(215);
    sum += task_216(216);
    sum += task_217(217);
    sum += task_218(218);
    sum += task_219(219);
    sum += task_220(220);
    sum += task_221(221);
    sum += task_222(222);
    sum += task_223(223);
    sum += task_224(224);
    sum += task_225(225);
    sum += task_226(226);
    sum += task_227(227);
    sum += task_228(228);
    sum += task_229(229);
    sum += task_230(230);
    sum += task_231(231);
    sum += task_232(232);
    sum += task_233(233);
    sum += task_234(234);
    sum += task_235(235);
    sum += task_236(236);
    sum += task_237(237);
    sum += task_238(238);
    sum += task_239(239);
    sum += task_240(240);
    sum += task_241(241);
    sum += task_242(242);
    sum += task_243(243);
    sum += task_244(244);
    sum += task_245(245);
    sum += task_246(246);
    sum += task_247(247);
    sum += task_248(248);
    sum += task_249(249);
    sum += task_250(250);
    sum += task_251(251);
    sum += task_252(252);
    sum += task_253(253);
    sum += task_254(254);
    sum += task_255(255);
    sum += task_256(256);
    sum += task_257(257);
    sum += task_258(258);
    sum += task_259(259);
    sum += task_260(260);
    sum += task_261(261);
    sum += task_262(262);
    sum += task_263(263);
    sum += task_264(264);
    sum += task_265(265);
    sum += task_266(266);
    sum += task_267(267);
    sum += task_268(268);
    sum += task_269(269);
    sum += task_270(270);
    sum += task_271(271);
    sum += task_272(272);
    sum += task_273(273);
    sum += task_274(274);
    sum += task_275(275);
    sum += task_276(276);
    sum += task_277(277);
    sum += task_278(278);
    sum += task_279(279);
    sum += task_280(280);
    sum += task_281(281);
    sum += task_282(282);
    sum += task_283(283);
    sum += task_284(284);
    sum += task_285(285);
    sum += task_286(286);
    sum += task_287(287);
    sum += task_288(288);
    sum += task_289(289);
    sum += task_290(290);
    sum += task_291(291);
    sum += task_292(292);
    sum += task_293(293);
    sum += task_294(294);
    sum += task_295(295);
    sum += task_296(296);
    sum += task_297(297);
    sum += task_298(298);
    sum += task_299(299);
    sum += task_300(300);
    sum += task_301(301);
    sum += task_302(302);
    sum += task_303(303);
    sum += task_304(304);
    sum += task_305(305);
    sum += task_306(306);
    sum += task_307(307);
    sum += task_308(308);
    sum += task_309(309);
    sum += task_310(310);
    sum += task_311(311);
    sum += task_312(312);
    sum += task_313(313);
    sum += task_314(314);
    sum += task_315(315);
    sum += task_316(316);
    sum += task_317(317);
    sum += task_318(318);
    sum += task_319(319);
    sum += task_320(320);
    sum += task_321(321);
    sum += task_322(322);
    sum += task_323(323);
    sum += task_324(324);
    sum += task_325(325);
    sum += task_326(326);
    sum += task_327(327);
    sum += task_328(328);
    sum += task_329(329);
    sum += task_330(330);
    sum += task_331(331);
    sum += task_332(332);
    sum += task_333(333);
    sum += task_334(334);
    sum += task_335(335);
    sum += task_336(336);
    sum += task_337(337);
    sum += task_338(338);
    sum += task_339(339);
    sum += task_340(340);
    sum += task_341(341);
    sum += task_342(342);
    sum += task_343(343);
    sum += task_344(344);
    sum += task_345(345);
    sum += task_346(346);
    sum += task_347(347);
    sum += task_348(348);
    sum += task_349(349);
    sum += task_350(350);
    sum += task_351(351);
    sum += task_352(352);
    sum += task_353(353);
    sum += task_354(354);
    sum += task_355(355);
    sum += task_356(356);
    sum += task_357(357);
    sum += task_358(358);
    sum += task_359(359);
    sum += task_360(360);
    sum += task_361(361);
    sum += task_362(362);
    sum += task_363(363);
    sum += task_364(364);
    sum += task_365(365);
    sum += task_366(366);
    sum += task_367(367);
    sum += task_368(368);
    sum += task_369(369);
    sum += task_370(370);
    sum += task_371(371);
    sum += task_372(372);
    sum += task_373(373);
    sum += task_374(374);
    sum += task_375(375);
    sum += task_376(376);
    sum += task_377(377);
    sum += task_378(378);
    sum += task_379(379);
    sum += task_380(380);
    sum += task_381(381);
    sum += task_382(382);
    sum += task_383(383);
    sum += task_384(384);
    sum += task_385(385);
    sum += task_386(386);
    sum += task_387(387);
    sum += task_388(388);
    sum += task_389(389);
    sum += task_390(390);
    sum += task_391(391);
    sum += task_392(392);
    sum += task_393(393);
    sum += task_394(394);
    sum += task_395(395);
    sum += task_396(396);
    sum += task_397(397);
    sum += task_398(398);
    sum += task_399(399);
    sum += task_400(400);
    sum += task_401(401);
    sum += task_402(402);
    sum += task_403(403);
    sum += task_404(404);
    sum += task_405(405);
    sum += task_406(406);
    sum += task_407(407);
    sum += task_408(408);
    sum += task_409(409);
    sum += task_410(410);
    sum += task_411(411);
    sum += task_412(412);
    sum += task_413(413);
    sum += task_414(414);
    sum += task_415(415);
    sum += task_416(416);
    sum += task_417(417);
    sum += task_418(418);
    sum += task_419(419);
    sum += task_420(420);
    sum += task_421(421);
    sum += task_422(422);
    sum += task_423(423);
    sum += task_424(424);
    sum += task_425(425);
    sum += task_426(426);
    sum += task_427(427);
    sum += task_428(428);
    sum += task_429(429);
    sum += task_430(430);
    sum += task_431(431);
    sum += task_432(432);
    sum += task_433(433);
    sum += task_434(434);
    sum += task_435(435);
    sum += task_436(436);
    sum += task_437(437);
    sum += task_438(438);
    sum += task_439(439);
    sum += task_440(440);
    sum += task_441(441);
    sum += task_442(442);
    sum += task_443(443);
    sum += task_444(444);
    sum += task_445(445);
    sum += task_446(446);
    sum += task_447(447);
    sum += task_448(448);
    sum += task_449(449);
    sum += task_450(450);
    sum += task_451(451);
    sum += task_452(452);
    sum += task_453(453);
    sum += task_454(454);
    sum += task_455(455);
    sum += task_456(456);
    sum += task_457(457);
    sum += task_458(458);
    sum += task_459(459);
    sum += task_460(460);
    sum += task_461(461);
    sum += task_462(462);
    sum += task_463(463);
    sum += task_464(464);
    sum += task_465(465);
    sum += task_466(466);
    sum += task_467(467);
    sum += task_468(468);
    sum += task_469(469);
    sum += task_470(470);
    sum += task_471(471);
    sum += task_472(472);
    sum += task_473(473);
    sum += task_474(474);
    sum += task_475(475);
    sum += task_476(476);
    sum += task_477(477);
    sum += task_478(478);
    sum += task_479(479);
    sum += task_480(480);
    sum += task_481(481);
    sum += task_482(482);
    sum += task_483(483);
    sum += task_484(484);
    sum += task_485(485);
    sum += task_486(486);
    sum += task_487(487);
    sum += task_488(488);
    sum += task_489(489);
    sum += task_490(490);
    sum += task_491(491);
    sum += task_492(492);
    sum += task_493(493);
    sum += task_494(494);
    sum += task_495(495);
    sum += task_496(496);
    sum += task_497(497);
    sum += task_498(498);
    sum += task_499(499);
    sum += task_500(500);
    sum += task_501(501);
    sum += task_502(502);
    sum += task_503(503);
    sum += task_504(504);
    sum += task_505(505);
    sum += task_506(506);
    sum += task_507(507);
    sum += task_508(508);
    sum += task_509(509);
    sum += task_510(510);
    sum += task_511(511);
    print(sum, " ", result.len);
}
