struct Cell { v: i64, next: Cell&? }
var p0: Cell[>..] = [Cell { v: 0, next: null }];
var p1: Cell[>..] = [Cell { v: 1, next: null }];
var p2: Cell[>..] = [Cell { v: 2, next: null }];
fn keep(a: Cell&, x: Cell&) { a.next .= x; }
recursive fn f0(n:i64, a:Cell&, b:Cell&) -> Cell& {
    if n <= 0 { return a; }
    let x0:Cell& = f1(n - 1, p0[0], p0[0]);
    keep(p2[0], x0);
    return x0;
}
recursive fn f1(n:i64, a:Cell&, b:Cell&) -> Cell& {
    if n <= 0 { return p2[0]; }
    let x0:Cell& = f0(n - 1, p1[0], p1[0]);
    keep(p0[0], x0);
    let x1:Cell& = f0(n - 1, p0[0], p2[0]);
    keep(p1[0], x1);
    return p0[0];
}
fn main() {
    print(f0(1, p0[0], p0[0]).v);
    print(f1(1, p0[0], p0[0]).v);
    print(f1(1, p0[0], p0[0]).v);
}
