struct Cell { v: i64, next: Cell&? }
var p0: Cell[>..] = [Cell { v: 0, next: null }];
var p1: Cell[>..] = [Cell { v: 1, next: null }];
var p2: Cell[>..] = [Cell { v: 2, next: null }];
fn keep(a: Cell&, x: Cell&) { a.next .= x; }
recursive fn f0(n:i64, a:Cell&, b:Cell&) -> Cell& {
    if n <= 0 { return p1[0]; }
    let x0:Cell& = f1(n - 1, b, a);
    keep(a, x0);
    return p2[0];
}
recursive fn f1(n:i64, a:Cell&, b:Cell&) -> Cell& {
    if n <= 0 { return b; }
    let x0:Cell& = f0(n - 1, a, b);
    keep(p2[0], x0);
    return x0;
}
fn main() {
    print(f0(1, p0[0], p0[0]).v);
    print(f1(1, p1[0], p0[0]).v);
}
