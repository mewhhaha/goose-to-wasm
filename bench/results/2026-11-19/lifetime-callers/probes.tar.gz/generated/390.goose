struct Cell { v: i64, next: Cell&? }
var p0: Cell[>..] = [Cell { v: 0, next: null }];
var p1: Cell[>..] = [Cell { v: 1, next: null }];
var p2: Cell[>..] = [Cell { v: 2, next: null }];
fn keep(a: Cell&, x: Cell&) { a.next .= x; }
recursive fn f0(n:i64, a:Cell&, b:Cell&) -> Cell& {
    if n <= 0 { return p2[0]; }
    let x0:Cell& = f4(n - 1, p2[0], p2[0]);
    keep(a, x0);
    return x0;
}
recursive fn f1(n:i64, a:Cell&, b:Cell&) -> Cell& {
    if n <= 0 { return p0[0]; }
    let x0:Cell& = f5(n - 1, p2[0], b);
    keep(a, x0);
    let x1:Cell& = f2(n - 1, a, p0[0]);
    let x2:Cell& = f5(n - 1, p1[0], p0[0]);
    keep(b, x2);
    return p1[0];
}
recursive fn f2(n:i64, a:Cell&, b:Cell&) -> Cell& {
    if n <= 0 { return a; }
    let x0:Cell& = f0(n - 1, p1[0], b);
    keep(p0[0], x0);
    let x1:Cell& = f5(n - 1, b, p2[0]);
    keep(b, x1);
    let x2:Cell& = f1(n - 1, p2[0], p0[0]);
    return p2[0];
}
recursive fn f3(n:i64, a:Cell&, b:Cell&) -> Cell& {
    if n <= 0 { return b; }
    let x0:Cell& = f3(n - 1, p0[0], p2[0]);
    let x1:Cell& = f1(n - 1, b, a);
    keep(a, x1);
    return x1;
}
recursive fn f4(n:i64, a:Cell&, b:Cell&) -> Cell& {
    if n <= 0 { return p1[0]; }
    let x0:Cell& = f4(n - 1, a, p0[0]);
    keep(b, x0);
    let x1:Cell& = f1(n - 1, a, p1[0]);
    keep(p1[0], x1);
    return x1;
}
recursive fn f5(n:i64, a:Cell&, b:Cell&) -> Cell& {
    if n <= 0 { return a; }
    let x0:Cell& = f0(n - 1, b, p1[0]);
    keep(p1[0], x0);
    let x1:Cell& = f5(n - 1, p0[0], p1[0]);
    keep(p1[0], x1);
    return x1;
}
fn main() {
    print(f2(1, p2[0], p0[0]).v);
    print(f2(1, p0[0], p2[0]).v);
    print(f2(1, p0[0], p1[0]).v);
}
