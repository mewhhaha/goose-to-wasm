struct Cell { v: i64, next: Cell&? }
var p0: Cell[>..] = [Cell { v: 0, next: null }];
var p1: Cell[>..] = [Cell { v: 1, next: null }];
var p2: Cell[>..] = [Cell { v: 2, next: null }];
fn keep(a: Cell&, x: Cell&) { a.next .= x; }
recursive fn f0(n:i64, a:Cell&, b:Cell&) -> Cell& {
    if n <= 0 { return p2[0]; }
    let x0:Cell& = f1(n - 1, p0[0], p1[0]);
    keep(p0[0], x0);
    let x1:Cell& = f1(n - 1, p1[0], p1[0]);
    keep(a, x1);
    return a;
}
recursive fn f1(n:i64, a:Cell&, b:Cell&) -> Cell& {
    if n <= 0 { return p0[0]; }
    let x0:Cell& = f1(n - 1, p1[0], a);
    keep(p0[0], x0);
    let x1:Cell& = f1(n - 1, p2[0], p1[0]);
    keep(b, x1);
    return p2[0];
}
fn main() {
    print(f1(1, p2[0], p1[0]).v);
    print(f1(1, p1[0], p2[0]).v);
    print(f1(1, p1[0], p2[0]).v);
    print(f1(1, p0[0], p1[0]).v);
}
