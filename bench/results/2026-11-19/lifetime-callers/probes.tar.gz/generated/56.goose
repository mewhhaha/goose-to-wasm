struct Cell { v: i64, next: Cell&? }
var p0: Cell[>..] = [Cell { v: 0, next: null }];
var p1: Cell[>..] = [Cell { v: 1, next: null }];
var p2: Cell[>..] = [Cell { v: 2, next: null }];
fn keep(a: Cell&, x: Cell&) { a.next .= x; }
recursive fn f0(n:i64, a:Cell&, b:Cell&) -> Cell& {
    if n <= 0 { return a; }
    let x0:Cell& = f5(n - 1, p2[0], p0[0]);
    keep(b, x0);
    let x1:Cell& = f0(n - 1, p0[0], p2[0]);
    return x1;
}
recursive fn f1(n:i64, a:Cell&, b:Cell&) -> Cell& {
    if n <= 0 { return p2[0]; }
    let x0:Cell& = f0(n - 1, p2[0], b);
    return p2[0];
}
recursive fn f2(n:i64, a:Cell&, b:Cell&) -> Cell& {
    if n <= 0 { return p1[0]; }
    let x0:Cell& = f0(n - 1, b, p1[0]);
    keep(b, x0);
    let x1:Cell& = f0(n - 1, p2[0], b);
    keep(p1[0], x1);
    let x2:Cell& = f1(n - 1, p1[0], b);
    return b;
}
recursive fn f3(n:i64, a:Cell&, b:Cell&) -> Cell& {
    if n <= 0 { return b; }
    let x0:Cell& = f1(n - 1, p2[0], p1[0]);
    keep(a, x0);
    return x0;
}
recursive fn f4(n:i64, a:Cell&, b:Cell&) -> Cell& {
    if n <= 0 { return a; }
    let x0:Cell& = f5(n - 1, a, p2[0]);
    let x1:Cell& = f4(n - 1, p1[0], p1[0]);
    keep(p1[0], x1);
    let x2:Cell& = f2(n - 1, b, p2[0]);
    keep(p2[0], x2);
    return p1[0];
}
recursive fn f5(n:i64, a:Cell&, b:Cell&) -> Cell& {
    if n <= 0 { return b; }
    let x0:Cell& = f2(n - 1, p1[0], b);
    return x0;
}
fn main() {
    print(f4(1, p1[0], p1[0]).v);
    print(f0(1, p0[0], p0[0]).v);
}
