struct Cell { v: i64, next: Cell&? }
var p0: Cell[>..] = [Cell { v: 0, next: null }];
var p1: Cell[>..] = [Cell { v: 1, next: null }];
var p2: Cell[>..] = [Cell { v: 2, next: null }];
fn keep(a: Cell&, x: Cell&) { a.next .= x; }
recursive fn f0(n:i64, a:Cell&, b:Cell&) -> Cell& {
    if n <= 0 { return b; }
    let x0:Cell& = f3(n - 1, p1[0], p1[0]);
    keep(b, x0);
    let x1:Cell& = f2(n - 1, p2[0], b);
    keep(p0[0], x1);
    return a;
}
recursive fn f1(n:i64, a:Cell&, b:Cell&) -> Cell& {
    if n <= 0 { return p2[0]; }
    let x0:Cell& = f0(n - 1, p0[0], a);
    keep(p2[0], x0);
    let x1:Cell& = f1(n - 1, b, p0[0]);
    let x2:Cell& = f3(n - 1, b, b);
    return x2;
}
recursive fn f2(n:i64, a:Cell&, b:Cell&) -> Cell& {
    if n <= 0 { return p1[0]; }
    let x0:Cell& = f1(n - 1, p2[0], p1[0]);
    keep(p1[0], x0);
    let x1:Cell& = f2(n - 1, a, b);
    let x2:Cell& = f2(n - 1, b, a);
    keep(p0[0], x2);
    return x2;
}
recursive fn f3(n:i64, a:Cell&, b:Cell&) -> Cell& {
    if n <= 0 { return b; }
    let x0:Cell& = f2(n - 1, p0[0], p1[0]);
    let x1:Cell& = f1(n - 1, a, p0[0]);
    keep(p2[0], x1);
    let x2:Cell& = f3(n - 1, p2[0], b);
    keep(p2[0], x2);
    return p2[0];
}
fn main() {
    print(f1(1, p0[0], p1[0]).v);
    print(f2(1, p1[0], p2[0]).v);
    print(f0(1, p1[0], p1[0]).v);
}
