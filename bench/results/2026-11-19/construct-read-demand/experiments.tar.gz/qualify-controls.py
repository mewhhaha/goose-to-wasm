from common import *
from statistics import median
import itertools
os.sched_setaffinity(0,{2})
d=B/'release-controls';d.mkdir(exist_ok=True)
G=[H,B/'release/fixed.wasm','--cache',B/'release/fixed.cwasm','--'];GB=[H,O/'release/fixed.wasm','--cache',O/'release/fixed.cwasm','--'];NN=B/'own/build-1/compiler-native'
cmds={'old-native':[N],'new-native':[NN],'old-guest':GB,'new-guest':G}
obs=[];meta={};env={**os.environ,'GOOSE_HOME':str(d/'home')}
for name,src in [('binding',B/'scaling/binding-witness.goose'),('replacement',B/'storage-review/replacement-heavy.goose'),('overlap',B/'storage-review/replacement-error.goose'),('class',B/'fixtures/production-ok.goose'),('class-error',B/'fixtures/production-error.goose')]:
 meta[name]=sha(src)
 for level in ([0,2] if name=='binding' else [2]):
  ref=None
  for tag,cmd in cmds.items():
   out=d/'out.wasm';out.unlink(missing_ok=True)
   p=subprocess.run([*cmd,src,'--stdlib',R/'stdlib','--target','wasm-direct',f'-O{level}','-o',out],capture_output=True,env=env)
   err=p.stderr.rstrip(b'\n');assert p.returncode==int(name in ['overlap','class-error']) and (not p.returncode or err), (name,tag,p.stderr[-500:])
   result=dict(exit=p.returncode,stderr=err.decode(),stdout=p.stdout.decode(),module=sha(out) if out.exists() else None)
   if out.exists():result['execution']=subprocess.check_output([H,out,'--no-cache']).decode()
   if ref is not None:assert ref==result,(name,tag)
   ref=result;obs.append(dict(source=name,level=level,compiler=tag,**result))
rows=[]
for i in range(6):
 for name,src in [('class', B/'fixtures/production-ok.goose'),('replacement',B/'storage-review/replacement-heavy.goose')]:
  order=['old-guest','new-guest']
  if i%2:order.reverse()
  for tag in order:
   p=subprocess.Popen([*cmds[tag],src,'--stdlib',R/'stdlib','--check'],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
   start=time.monotonic_ns();_,status,ru=os.wait4(p.pid,0);elapsed=time.monotonic_ns()-start;p.returncode=os.waitstatus_to_exitcode(status);assert p.returncode==0 and not p.stderr.read().strip()
   rows.append(dict(round=i+1,name=name,case=tag,cpu_s=ru.ru_utime+ru.ru_stime,wall_ns=elapsed,rss_kib=ru.ru_maxrss))
out=dict(workloads=meta,compiler_identity={k:sha(v[1] if len(v)>1 else v[0]) for k,v in cmds.items()},host=sha(H),cpu=2,observations=obs,checks=rows)
put(d/'results.json',out)
print('release controls verified',flush=True)
