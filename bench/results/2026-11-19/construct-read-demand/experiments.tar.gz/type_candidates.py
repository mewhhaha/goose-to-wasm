from common import *
os.sched_setaffinity(0,{5});s=(S/F).read_text()
s=once(s,'fn life_construct_read(','''var hit: i64[8];
var replaced_types: i64[>..] = [];
var possible_types: i64[>..] = [];
var actual_types: i64[>..] = [];
var assigned_kinds: i64[>..] = [];
var read_types: i64[>..] = [];
fn life_construct_read(''')
s=once(s,'    l.types_frozen = true;\n    for t, id', '''    l.types_frozen = true;
    read_types.resize(p.types.len, 0); actual_types.resize(p.types.len, 0); assigned_kinds.resize(256, 0);
    possible_types.resize(p.types.len, 0);
    for n in p.nodes {
        if n.kind != N_ASSIGN || n.left < 0 || n.right < 0 { continue; }
        var ty = p.nodes[n.left].type_id;
        if ty >= 0 && p.types[ty].kind == TY_REF && n.integer != T_DOTASSIGN { ty = p.types[ty].element; }
        if life_cached_size_class(p, l, ty) == 2 {
            possible_types[ty]++; assigned_kinds[p.nodes[n.right].kind]++;
        }
    }
    for t, id''')
s=once(s,'life_shrink(p, l, node, receiver); kind = 2;', 'life_shrink(p, l, node, receiver); kind = 2; if !l.discovery { actual_types[ty]++; }')
s=once(s,'    if p.diagnostics.len == 0 { life_export_provenance', '''    for entry in l.summary_reads { read_types[l.leaves[entry.leaf].value.type_id]++; }
    print(possible_types); print(actual_types); print(assigned_kinds); print(read_types);
    var types: i64[>..] = []; for n, i in possible_types { if n > 0 { types.push(i); } }
    var compat: i64[>..] = []; compat.resize(p.types.len, -1);
    for entry in l.summary_reads {
        let v = l.leaves[entry.leaf].value; var ty = v.type_id;
        if ty >= 0 && p.types[ty].kind == TY_REF { ty = p.types[ty].element; }
        if ty < 0 { hit[4]++; continue; }
        if v.element_array != -1 { hit[1]++; if v.element_array == -2 { hit[3]++; } continue; }
        if compat[ty] < 0 {
            compat[ty] = 0; for other in types {
                if life_contains(p, l, ty, other) || life_cached_size_class(p, l, ty) > 0 && life_contains(p, l, other, ty) { compat[ty] = 1; break; }
            }
        }
        if compat[ty] == 0 { hit[0]++; } else { hit[2]++; }
    }
    print(hit);
    if p.diagnostics.len == 0 { life_export_provenance''')
d,m=prep('types',s,wide);p=subprocess.run([H,m,'--cache',d/'compiler.cwasm','--','selfhost/main.goose','--stdlib','stdlib','--check'],cwd=W/'source',capture_output=True);print(p.returncode,p.stderr.decode(),flush=True);assert p.returncode==0
v=[json.loads(x) for x in p.stdout.splitlines()];put(d/'result.json',dict(compiler=sha(m),source=j(W/'builds.json')['source_commit'],counts=v));print([(len(x),sum(x),sum(a>0 for a in x)) for x in v],v[-1],flush=True)
