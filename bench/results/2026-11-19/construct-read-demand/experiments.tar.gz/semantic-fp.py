from common import *
os.sched_setaffinity(0,{0,2,4,6})
which=sys.argv[1];src=Path(sys.argv[2]).resolve();forced=int(sys.argv[3]) if len(sys.argv)>3 else 4096
d=B/'semantic'/(which+'-'+str(forced));dest=d/'source';shutil.copytree(src,dest,dirs_exist_ok=True);f=dest/F;s=f.read_text();new='fn life_check_attempt(' in s
ref=(O/'fingerprints/release/source'/F).read_text()
h=ref[ref.index('fn dbg_num('):ref.index('fn dbg_progress(')];x=h[h.index('fn dbg_fingerprint('):].replace('fn dbg_fingerprint(','fn dbg_project(').replace('out.append("LIFEFP ");','out.append("PROJECT ");')
x=once(x,'h = dbg_mix(h, l.revision);','');x=once(x,'dbg_kv(out, "rev", l.revision);','')
x=once(x,'if l.compact { read = frame.first_read; }','')
x=once(x,'he = dbg_entry(l, he, l.effects[at]); count += 1;', 'if l.effects[at].kind != 3 { he = dbg_entry(l, he, l.effects[at]); count += 1; }')
x=once(x,'he = dbg_entry(l, he, l.effects[at]); checked += 1;', 'if l.effects[at].kind != 3 { he = dbg_entry(l, he, l.effects[at]); checked += 1; }')
sv=h[h.index('fn dbg_value('):h.index('fn dbg_fingerprint(')].replace('fn dbg_value(', 'recursive fn dbg_sem_value(').replace('= dbg_value(', '= dbg_sem_value(').replace('fn dbg_entry(', 'fn dbg_sem_entry(')
sv=once(sv,'x = dbg_mix(x, v.tuple);','''var at = v.tuple;
    while at >= 0 {
        x = dbg_mix(x, 91); x = dbg_sem_value(l, x, l.items[at].value); at = l.items[at].next;
    }
    x = dbg_mix(x, 92); x = dbg_mix(x, v.reached);''')
sv+='''
fn dbg_sem_items(l: Lifetimes&, h: u64, first: i64) -> u64 {
    var x = h; var at = first;
    while at >= 0 { x = dbg_mix(x, 91); x = dbg_sem_value(l, x, l.items[at].value); at = l.items[at].next; }
    return dbg_mix(x, 92);
}
'''
for e in ['h = dbg_mix(h, l.pass);','h = dbg_mix(h, l.items.len);','h = dbg_mix(h, l.activations);','dbg_kv(out, "pass", l.pass);']:x=once(x,e,'')
x=x.replace('dbg_value(','dbg_sem_value(').replace('dbg_entry(','dbg_sem_entry(')
x=once(x,'hf = dbg_mix(hf, frame.inputs);','hf = dbg_sem_items(l, hf, frame.inputs);')
x=once(x,'hf = dbg_mix(hf, frame.capture_inputs);','hf = dbg_sem_items(l, hf, frame.capture_inputs);')
x=once(x,'hf = dbg_mix(hf, frame.checked_revision);','hf = dbg_mix(hf, frame.function_node); hf = dbg_mix(hf, frame.selected_result);')
x=once(x,'hf = dbg_mix(hf, frame.activation);','if frame.validated { hf = dbg_mix(hf, 1); } if frame.recursive_call { hf = dbg_mix(hf, 2); }')
a=x.index('    var hi:');b=x.index('    var hx:',a);x=x[:a]+x[b:]
x=once(x,'dbg_kv(out, "items", (hi >> 1) as! i64);','')
s0=x.index('var read: i64 = -1;');s1=x.index('            if at < 0 { break; }',s0)
x=x[:s0]+'loop {\n'+x[s1:]
h+=sv

s=once(s,'import model;','import model;\nimport os;')
s=once(s,'fn check_lifetimes(',h+'\n'+x+'\nfn check_lifetimes(')
def raw(tag):
 e=f'dbg_fingerprint(p, l, "{tag}");'
 if new:e='if !omit_reads { '+e+' }'
 return e
s=once(s,'        let before = l.revision;','        '+raw('pass_begin')+'\n        let before = l.revision;')
s=once(s,'            for failure in l.failures { life_error(p, l, failure.node, failure.message); }','            for failure in l.failures { life_error(p, l, failure.node, failure.message); }\n            '+raw('failed')+' dbg_project(p, l, "failed");')
s=once(s,'    l.discovery = false;\n    for root, index in l.roots','    '+raw('discovered')+'\n    l.discovery = false;\n    for root, index in l.roots')
s=once(s,'    if p.diagnostics.len == 0 { life_export_provenance','    '+raw('validated')+' dbg_project(p, l, "validated");\n    if p.diagnostics.len == 0 { life_export_provenance')
s=once(s,'LIFE_CONCRETE_FRAMES: i64 = 4096','LIFE_CONCRETE_FRAMES: i64 = '+str(forced));f.write_text(s)
subprocess.run([N,'selfhost/main.goose','--stdlib','stdlib','--target','native','-O2','-o',d/'probe.c'],cwd=dest,check=True)
subprocess.run(['clang-23','-w','-O0','-std=gnu11',d/'probe.c','-lm','-ldl','-pthread','-o',d/'probe'],check=True)
print(which,forced,sha(d/'probe'),flush=True)
