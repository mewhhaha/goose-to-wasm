from common import *
os.sched_setaffinity(0,{2});s=(S/F).read_text()
s=once(s,'    // Offer', '    // Offer') if False else s
s=once(s,'compact: bool = true','check_construct_reads: bool = true, compact: bool = true')
s=once(s,'    if l.reading_place > 0 { return; }\n    var effect_places', '    if !l.check_construct_reads || l.reading_place > 0 { return; }\n    var effect_places')
s=once(s,'    l.types_frozen = true;\n    for t, id', '''    l.types_frozen = true;
    l.check_construct_reads = false;
    for n in p.nodes {
        if n.kind != N_ASSIGN || n.left < 0 { continue; }
        let target: const Node& = p.nodes[n.left];
        if target.kind != N_NAME && target.kind != N_INDEX && target.kind != N_MEMBER && !(target.kind == N_UNARY && target.integer == T_MUL) { l.check_construct_reads = true; break; }
        var ty = target.type_id;
        if ty >= 0 && p.types[ty].kind == TY_REF && n.integer != T_DOTASSIGN { ty = p.types[ty].element; }
        if life_cached_size_class(p, l, ty) == 2 { l.check_construct_reads = true; break; }
    }
    for t, id''')
d,m=prep('elide',s,fixed);screen('elision-screen',{'base':O/'release/fixed.wasm','elide':m},4,5)
