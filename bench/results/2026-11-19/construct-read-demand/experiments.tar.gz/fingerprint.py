from common import *
os.sched_setaffinity(0,{0,2,4,6})
which=sys.argv[1];src=Path(sys.argv[2]).resolve();forced=int(sys.argv[3]) if len(sys.argv)>3 else 4096
d=B/'fp'/(which+'-'+str(forced));dest=d/'source';shutil.copytree(src,dest,dirs_exist_ok=True);f=dest/F;s=f.read_text();new='fn life_check_attempt(' in s
ref=(O/'fingerprints/release/source'/F).read_text()
h=ref[ref.index('fn dbg_num('):ref.index('fn dbg_progress(')];x=h[h.index('fn dbg_fingerprint('):].replace('fn dbg_fingerprint(','fn dbg_project(').replace('out.append("LIFEFP ");','out.append("PROJECT ");')
x=once(x,'h = dbg_mix(h, l.revision);','');x=once(x,'dbg_kv(out, "rev", l.revision);','')
x=once(x,'if l.compact { read = frame.first_read; }','')
x=once(x,'he = dbg_entry(l, he, l.effects[at]); count += 1;', 'if l.effects[at].kind != 3 { he = dbg_entry(l, he, l.effects[at]); count += 1; }')
x=once(x,'he = dbg_entry(l, he, l.effects[at]); checked += 1;', 'if l.effects[at].kind != 3 { he = dbg_entry(l, he, l.effects[at]); checked += 1; }')
s=once(s,'import model;','import model;\nimport os;')
s=once(s,'fn check_lifetimes(',h+'\n'+x+'\nfn check_lifetimes(')
def raw(tag):
 e=f'dbg_fingerprint(p, l, "{tag}");'
 if new:e='if !omit_reads { '+e+' }'
 return e
s=once(s,'        let before = l.revision;\n        for symbol in p.symbols','        '+raw('pass_begin')+'\n        let before = l.revision;\n        for symbol in p.symbols')
s=once(s,'            for failure in l.failures { life_error(p, l, failure.node, failure.message); }','            for failure in l.failures { life_error(p, l, failure.node, failure.message); }\n            '+raw('failed')+' dbg_project(p, l, "failed");')
s=once(s,'    l.discovery = false;\n    for root, index in l.roots','    '+raw('discovered')+'\n    l.discovery = false;\n    for root, index in l.roots')
s=once(s,'    if p.diagnostics.len == 0 { life_export_provenance','    '+raw('validated')+' dbg_project(p, l, "validated");\n    if p.diagnostics.len == 0 { life_export_provenance')
s=once(s,'LIFE_CONCRETE_FRAMES: i64 = 4096','LIFE_CONCRETE_FRAMES: i64 = '+str(forced));f.write_text(s)
subprocess.run([N,'selfhost/main.goose','--stdlib','stdlib','--target','native','-O2','-o',d/'probe.c'],cwd=dest,check=True)
subprocess.run(['clang-23','-w','-O0','-std=gnu11',d/'probe.c','-lm','-ldl','-pthread','-o',d/'probe'],check=True)
print(which,forced,sha(d/'probe'),flush=True)
