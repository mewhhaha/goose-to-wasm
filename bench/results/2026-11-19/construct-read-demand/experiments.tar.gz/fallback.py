from common import *
os.sched_setaffinity(0,{4});s=(B/'elide/source'/F).read_text()
sig='fn check_lifetimes(p: Program&, scope_parent: const i64[:], scope_depth: const i64[:], scope_functions: const i64[:], pool_references: const i64[:]) {'
s=once(s,sig,'''fn check_lifetimes(p: Program&, scope_parent: const i64[:], scope_depth: const i64[:], scope_functions: const i64[:], pool_references: const i64[:]) {
    let nodes = p.nodes.len; let types = p.types.len; let diagnostics = p.diagnostics.len;
    if life_check_attempt(p, scope_parent, scope_depth, scope_functions, pool_references, false) { return; }
    p.nodes.resize(nodes); p.types.resize(types); p.diagnostics.resize(diagnostics);
    if p.type_holds.len > types { p.type_holds.resize(types); }
    if p.type_indexed > types { p.type_buckets.clear(); p.type_links.clear(); p.type_indexed = 0; }
    life_check_attempt(p, scope_parent, scope_depth, scope_functions, pool_references, true);
}
fn life_check_attempt(p: Program&, scope_parent: const i64[:], scope_depth: const i64[:], scope_functions: const i64[:], pool_references: const i64[:], force_construct_reads: bool) -> bool {''')
a=s.index('fn life_check_attempt(');part=s[a:];part=part.replace('return;','return true;').replace('l.check_construct_reads = false;','l.check_construct_reads = force_construct_reads;');end=part.rindex('}');s=s[:a]+part[:end]+'    return true;\n'+part[end:]
s=once(s,'    if l.compact { life_reads_materialize(p, l); }','''    if !l.check_construct_reads { return false from life_check_attempt; }
    if l.compact { life_reads_materialize(p, l); }''')
d,m=prep('fallback',s,fixed);screen('fallback-screen',{'base':O/'release/fixed.wasm','fallback':m},4,6)
