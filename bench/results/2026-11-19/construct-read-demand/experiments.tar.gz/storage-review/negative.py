from hashlib import sha256
import json
from pathlib import Path
import os
import subprocess

scratch = Path(__file__).resolve().parent
project = scratch.parents[2]
candidates = scratch.parent
shipping = project / "build/result-copies-19/shipping"
host = project / "host/rust/target/release/goose-wasmtime"
baseline = shipping / "own/build-1/compiler-native"
host_short = sha256(host.read_bytes()).hexdigest()[:16]
modules = {
    "base": (shipping / "release/fixed.wasm", candidates / f"review-screen/base-{host_short}.cwasm"),
    "dynamic": (candidates / "recycle/compiler.wasm", candidates / f"review-screen/recycle-{host_short}.cwasm"),
    "fixed": (scratch / "recycle-fixed.wasm", scratch / "recycle-fixed.cwasm"),
    "miss-slot": (candidates / "miss-slot/compiler.wasm", candidates / f"review-screen/miss-slot-{host_short}.cwasm"),
}
commands = {"native": [baseline]}
commands.update({
    name: [host, module, "--cache", cache, "--"] for name, (module, cache) in modules.items()
})
fixture = scratch / "replacement-error.goose"
checks = {}
os.sched_setaffinity(0, {4})
for name, command in commands.items():
    check = subprocess.run(
        [*command, fixture.name, "--stdlib", project / "build/replay-nov19/own/source/stdlib", "--check"],
        cwd=scratch, capture_output=True,
    )
    stderr = check.stderr.decode().strip()
    checks[name] = dict(code=check.returncode, stderr=stderr, stdout=check.stdout.decode())
    assert check.returncode == 1 and "whole assignment reads storage" in stderr, (name, checks[name])
    assert checks[name] == checks["native"]
output = dict(source_sha256=sha256(fixture.read_bytes()).hexdigest(), results=checks)
(scratch / "negative.json").write_text(json.dumps(output, indent=2) + "\n")
print(checks["native"]["stderr"])
