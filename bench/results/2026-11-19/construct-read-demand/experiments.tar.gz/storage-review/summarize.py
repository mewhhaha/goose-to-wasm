from hashlib import sha256
import json
from pathlib import Path
import re
from statistics import median

scratch = Path(__file__).resolve().parent
project = scratch.parents[2]
candidates = scratch.parent
shipping = project / "build/result-copies-19/shipping"
lockfile = (project / "host/rust/Cargo.lock").read_text()
version = re.search(r'\nname = "wasmtime"\nversion = "([^"]+)"', lockfile).group(1)
source = json.loads((shipping / "own/builds.json").read_text())

def hash_file(path):
    return sha256(path.read_bytes()).hexdigest()

def stats(document):
    rows = {}
    for row in document["samples"]:
        rows.setdefault(row["case"], {})[row["round"]] = row
    return {
        case: {
            "wall_s": median(r["wall_s"] for r in trial.values()),
            "cpu_s": median(r["cpu_s"] for r in trial.values()),
            "peak_rss_mib": median(r["rss_KiB"] for r in trial.values()) / 1024,
            "instructions": median(r["counters"]["instructions"]["value"] for r in trial.values()),
            "paired_wall_change_pct": median(
                (row["wall_s"] / rows["base"][key]["wall_s"] - 1) * 100
                for key, row in trial.items()
            ),
            "paired_cpu_change_pct": median(
                (row["cpu_s"] / rows["base"][key]["cpu_s"] - 1) * 100
                for key, row in trial.items()
            ),
        }
        for case, trial in rows.items()
    }

summary = {
    "baseline_revision": source["source_commit"],
    "baseline_archive_sha256": source["source_archive_sha256"],
    "training_profile_sha256": hash_file(shipping / "release/training.profile"),
    "build_emitter_sha256": hash_file(shipping / "own/build-1/compiler-native"),
    "candidate_patch_sha256": {
        name: hash_file(candidates / name / "change.patch")
        for name in ("recycle", "recycle-fixed", "miss-slot")
    },
    "rust_wasmtime": version,
    "CPU": "AMD Ryzen 7 3800X, logical CPU 4, shared host",
    "workloads": {},
}
for name in ("frozen", "replacement"):
    path = scratch / f"{name}.json"
    if not path.exists():
        continue
    doc = json.loads(path.read_text())
    doc.pop("wasmtime_python_version", None)
    doc["rust_wasmtime"] = version
    assert len(doc["samples"]) == 16
    assert all(row["output"] == doc["reference"] for row in doc["samples"])
    path.write_text(json.dumps(doc, indent=2) + "\n")
    summary["workloads"][name] = {
        "reference": doc["reference"],
        "summary": stats(doc),
        "observations": path.name,
    }
(scratch / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
