from pathlib import Path
import os
import resource
import shutil
import subprocess

scratch = Path(__file__).resolve().parent
project = scratch.parents[2]
candidates = scratch.parent
shipping = project / "build/result-copies-19/shipping"
emitter = shipping / "own/build-1/compiler-native"
source = scratch / "fixed-source"
os.sched_setaffinity(0, {4})
resource.setrlimit(resource.RLIMIT_STACK, (256 << 20, resource.getrlimit(resource.RLIMIT_STACK)[1]))
shutil.copytree(shipping / "own/source", source, dirs_exist_ok=True)
subprocess.run(["patch", "-p1", "-i", candidates / "recycle-fixed/change.patch"], cwd=source, check=True)
subprocess.run(
    [emitter, "selfhost/main.goose", "--stdlib", "stdlib", "--target", "wasm-direct", "-O2",
     "--wasm-bundled-host", "--wasm-initial-pages", "65535", "--wasm-max-pages", "65535",
     "--wasm-region-profile", shipping / "release/training.profile", "-o", scratch / "recycle-fixed.wasm"],
    cwd=source, check=True,
)
host = project / "host/rust/target/release/goose-wasmtime"
subprocess.run([host, scratch / "recycle-fixed.wasm", "--cache", scratch / "recycle-fixed.cwasm", "--", "--version"],
               cwd=source, check=True)
