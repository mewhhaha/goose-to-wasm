from importlib.metadata import version
import json
import os
from pathlib import Path
import resource
from statistics import median
import subprocess
import sys
import tempfile

scratch = Path(__file__).resolve().parent
project = scratch.parents[2]
candidates = scratch.parent
shipping = project / "build/result-copies-19/shipping"
stage = project / "build/replay-nov19/own"
sys.path[:0] = [
    str(project / "bench"),
    str(project / "scripts"),
    str(project / "bench/results/2026-11-18/selfhost-wasm-runtime/tools"),
]
from selfhost_comparison import SOURCE, WASM_FLAGS, identity, verify_frozen_source
from measure import measured

host = project / "host/rust/target/release/goose-wasmtime"
native = shipping / "own/build-1/compiler-native"
host_short = identity(host)["sha256"][:16]
modules = {
    "base": (shipping / "release/fixed.wasm", candidates / f"review-screen/base-{host_short}.cwasm"),
    "dynamic": (candidates / "recycle/compiler.wasm", candidates / f"review-screen/recycle-{host_short}.cwasm"),
    "fixed": (scratch / "recycle-fixed.wasm", scratch / "recycle-fixed.cwasm"),
    "miss-slot": (candidates / "miss-slot/compiler.wasm", candidates / f"review-screen/miss-slot-{host_short}.cwasm"),
}
commands = {}
identities = {}
for label, (module, cache) in modules.items():
    module_id = identity(module)
    assert cache.with_suffix(".cwasm.sha256").read_text().strip() == module_id["sha256"]
    commands[label] = [host, module, "--cache", cache, "--"]
    identities[label] = {"module": module_id, "cache": identity(cache)}

def run(command, cwd):
    with tempfile.TemporaryFile(dir=scratch) as out, tempfile.TemporaryFile(dir=scratch) as err:
        child = subprocess.Popen(command, cwd=cwd, stdout=out, stderr=err)
        _, status, usage = os.wait4(child.pid, 0)
        child.returncode = os.waitstatus_to_exitcode(status)
        out.seek(0)
        err.seek(0)
        return child.returncode, out.read(), err.read(), usage

def save(report, report_path):
    report_path.write_text(json.dumps(report, indent=2) + "\n")

manifest = json.loads((stage / "builds.json").read_bytes())
frozen = stage / "source"
verify_frozen_source(frozen, manifest["source_commit"], manifest["source_archive_sha256"])
os.sched_setaffinity(0, {4})
resource.setrlimit(resource.RLIMIT_STACK, (256 << 20, resource.getrlimit(resource.RLIMIT_STACK)[1]))

name = sys.argv[1]
output = scratch / f"{name}-output.wasm"
report_path = scratch / f"{name}.json"
if name == "frozen":
    arguments = [*SOURCE, *WASM_FLAGS]
    input_id = dict(source_commit=manifest["source_commit"], source_archive_sha256=manifest["source_archive_sha256"])
    reference = identity(stage / "build-1/compiler.wasm")
    cwd = frozen
else:
    fixture = scratch / "replacement-heavy.goose"
    arguments = [fixture.name, "--stdlib", str(frozen / "stdlib"), *WASM_FLAGS]
    input_id = dict(source=identity(fixture), stdlib_source_commit=manifest["source_commit"],
                    source_archive_sha256=manifest["source_archive_sha256"])
    cwd = scratch
    subprocess.run([native, *arguments, "-o", output], cwd=cwd, check=True)
    reference = identity(output)
    runtime = subprocess.check_output([host, output, "--no-cache"], cwd=cwd).decode()
    assert runtime == "32768\n", runtime
    input_id["runtime_stdout"] = runtime

report = dict(input=input_id, arguments=arguments, CPU=4, host=identity(host),
              wasmtime_python_version=version("wasmtime"), reference=reference,
              artifacts=identities, samples=[])
orders = (
    ("base", "dynamic", "fixed", "miss-slot"),
    ("miss-slot", "fixed", "dynamic", "base"),
    ("dynamic", "base", "miss-slot", "fixed"),
    ("fixed", "miss-slot", "base", "dynamic"),
)
for round_number, order in enumerate(orders, 1):
    for label in order:
        output.unlink(missing_ok=True)
        argv = [*commands[label], *arguments, "-o", output]
        result, wall, counters = measured(lambda: run(argv, cwd), child=True)
        status, stdout, stderr, usage = result
        if status or stdout or stderr:
            raise RuntimeError((label, status, stdout, stderr))
        actual = identity(output)
        if actual != reference:
            raise RuntimeError((label, actual, reference))
        row = dict(round=round_number, case=label, wall_s=wall / 1e9,
                   cpu_s=usage.ru_utime + usage.ru_stime,
                   rss_KiB=usage.ru_maxrss, counters=counters, output=actual)
        report["samples"].append(row)
        save(report, report_path)
        print(round_number, label, f"{row['wall_s']:.3f} s", f"{row['rss_KiB'] / 1024:.1f} MiB", flush=True)
