from pathlib import Path

fixture = Path(__file__).with_name("replacement-heavy.goose")
wrappers = 128
read_sites = 256
lines = ["fn read_many(xs: const i64[>..]&) -> i64 {", "    var sum = 0;"]
for i in range(read_sites):
    lines.append("    sum += xs[0];")
lines.extend(["    return sum;", "}"])
for i in range(wrappers):
    lines.append(f"fn wrapper_{i}(xs: const i64[>..]&) -> i64 {{ return read_many(xs); }}")
lines.extend(["fn main() {", "    var xs: i64[>..] = [1];", "    var sum = 0;"])
for i in range(wrappers):
    lines.append(f"    xs = [1, {i}];")
    lines.append(f"    sum += wrapper_{i}(xs);")
lines.extend(["    print(sum);", "}"])
fixture.write_text("\n".join(lines) + "\n")
