fn read_one(xs: const i64[>..]&) -> i64 { return xs[0]; }
fn main() {
    var xs: i64[>..] = [1];
    xs = [read_one(xs)];
    print(xs[0]);
}
