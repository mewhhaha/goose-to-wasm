from common import *
d=B/'fixtures';d.mkdir(exist_ok=True)
for size,tag in [(48,'small'),(4100,'production')]:
 for label in ['ok','error']:
  helpers=[f'fn call_{i}() -> i64 {{ {i} }}' for i in range(size)]
  calls='\n'.join(f'    call_{i}();' for i in range(size))
  src='''fn standalone(xs: const i64[:], tag: i64&) -> i64 { xs.len + tag }
fn last(xs: i64[>..<]&) -> i64 {
    let view = xs[0..1];
    CHANGE
    return view[0];
}
'''.replace('CHANGE','xs.pop();' if label=='error' else '')
  f=d/(tag+'-'+label+'.goose');f.write_text(src+'\n'.join(helpers)+'\nfn main() {\n'+calls+'\n    var xs: i64[>..<] = [42, 7];\n    print(last(xs));\n}\n')
