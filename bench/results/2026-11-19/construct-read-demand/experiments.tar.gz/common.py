import hashlib,json,os,sys,subprocess,shutil,time,resource,difflib
from pathlib import Path
B=Path(__file__).resolve().parent; R=B.parents[1]; O=R/'build/result-copies-19/shipping'; W=R/'build/replay-nov19/own'; S=O/'own/source'; N=O/'own/build-1/compiler-native'; H=R/'host/rust/target/release/goose-wasmtime'; F=Path('selfhost/checker_lifetimes.goose')
resource.setrlimit(resource.RLIMIT_STACK,(256<<20,resource.getrlimit(resource.RLIMIT_STACK)[1]))
A=['selfhost/main.goose','--stdlib','stdlib','--target','wasm-direct','-O2']; wide=['--wasm-memory64','--wasm-max-pages','262144']; fixed=['--wasm-bundled-host','--wasm-initial-pages','65535','--wasm-max-pages','65535','--wasm-region-profile',O/'release/training.profile']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def j(p):return json.loads(p.read_bytes())
def put(p,data):p.write_text(json.dumps(data,indent=2)+'\n')
def prep(tag,s,flags):
 d=B/tag;src=d/'source';shutil.copytree(S,src,dirs_exist_ok=True);f=src/F;orig=(S/F).read_text();f.write_text(s);(d/'change.patch').write_text(''.join(difflib.unified_diff(orig.splitlines(True),s.splitlines(True),'a/'+str(F),'b/'+str(F))))
 mod=d/'compiler.wasm';subprocess.run([N,*A,*flags,'-o',mod],cwd=src,check=True);return d,mod
def once(s,a,b):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,b)
def screen(dest,cases,n=4,cpu=7):
 subprocess.run([R/'.venv/bin/python',R/'bench/results/2026-11-18/compiler-frame-cost/measure.py',W,B/dest,*[k+'='+str(v) for k,v in cases.items()],'--rounds',str(n),'--cpu',str(cpu)],check=True)
