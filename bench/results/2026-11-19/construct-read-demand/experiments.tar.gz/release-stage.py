from trials import *
root=R; native=N; prior=O
import hashlib,json,time
from math import isqrt
resource.setrlimit(resource.RLIMIT_STACK,(256<<20,resource.getrlimit(resource.RLIMIT_STACK)[1]));os.sched_setaffinity(0,{4,6})
d=B/'release';src=d/'source';host=root/'host/rust/target/release/goose-wasmtime';train=d/'train';train.mkdir(exist_ok=True)
inp=['selfhost/main.goose','--stdlib','stdlib'];flags=['--target','wasm-direct','-O2'];wide=['--wasm-memory64','--wasm-max-pages','262144']
def run(c,folder,**kw): subprocess.run(c,cwd=folder,check=True,**kw)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
mod=train/'stats.wasm';run([native,*inp,*flags,*wide,'--wasm-region-stats','-o',mod],src)
maximum={};controls={}
for name in ['squares','sorting','tour']:
 rel=Path('examples',name+'.goose');source=train/rel;source.parent.mkdir(exist_ok=True)
 source.write_bytes(subprocess.check_output(['git','show','fc34386:'+str(rel)],cwd=root))
 prof=train/(name+'.profile');out=train/(name+'.wasm');ref=train/(name+'.ref');args=[rel,'--stdlib',src/'stdlib',*flags,*wide]
 run([host,mod,'--cache',train/'stats.cwasm','--',*args,'-o',out],train,env=dict(os.environ,GOOSE_REGION_PROFILE=str(prof)))
 run([native,*args,'-o',ref],train);assert sha(out)==sha(ref)
 controls[name]=dict(source=sha(source),output=sha(out),region_stats=sha(prof))
 for line in prof.read_text().splitlines():
  i,n=map(int,line.split());maximum[i]=max(n,maximum.get(i,0))
profile=d/'training.profile';profile.write_text(''.join(f'{i} {isqrt(v<<16)}\n' for i,v in sorted(maximum.items())))
fixed=['--wasm-bundled-host','--wasm-initial-pages','65535','--wasm-max-pages','65535','--wasm-region-profile',profile]
while not (B/'own/build-1/compiler.wasm').exists():time.sleep(2)
new=B/'own/build-1/compiler-native'
module=d/'fixed.wasm';run([new,*inp,*flags,*fixed,'-o',module],src)
repro=d/'fixed-point.wasm';run([host,module,'--cache',d/'fixed.cwasm','--',*inp,*flags,*fixed,'-o',repro],src);assert sha(repro)==sha(module)
port=d/'portable.wasm';run([host,module,'--cache',d/'fixed.cwasm','--',*inp,*flags,*wide,'-o',port],src);assert sha(port)==sha(B/'own/build-1/compiler.wasm')
(d/'identity.json').write_text(json.dumps(dict(training=controls,old_profile=sha(prior/'release/training.profile'),new_profile=sha(profile),fixed_point=sha(repro),native_fixed_emission=sha(module),native=sha(new),portable_native=sha(B/'own/build-1/compiler.wasm'),portable_guest=sha(port),host=sha(host)),indent=2)+'\n');print('Wasm fixed point and portable outputs verified',flush=True)
