fn bytes_hash(bytes: u8[:]) -> i64 {
    var hash: u32 = 2166136261;
    for byte in bytes { hash = (hash ^ (byte as u32)) * 16777619; }
    return hash as i64;
}

enum Choice { One, Two }
fn rejdsjmb(n: i64) -> i64 { return n + 11; }
fn wyrqlnhb(n: i64) -> i64 { return n + 23; }
fn rejdsjmb::marker() -> i64 { return 53; }
fn rejdsjmb(c: Choice.One) -> i64 { return 31; }
fn rejdsjmb(c: Choice.Two) -> i64 { return 37; }
fn route(c: Choice) -> i64 { return rejdsjmb(c); }

fn main() {
    print(bytes_hash("rejdsjmb"), " ", bytes_hash("wyrqlnhb"));
    print(rejdsjmb(1), " ", wyrqlnhb(1), " ", rejdsjmb::marker());
    {
        let rejdsjmb: i64 = 41;
        print(rejdsjmb, " ", wyrqlnhb(2), " ", rejdsjmb::marker());
    }
    {
        fn wyrqlnhb(n: i64) -> i64 { return n + 71; }
        print(rejdsjmb(2), " ", wyrqlnhb(2));
    }
    print(route(Choice.One {}), " ", route(Choice.Two {}));
}
