"""Generate and verify two compiler scaling workloads and a name-binding witness."""

import argparse
import hashlib
import itertools
import json
from pathlib import Path
import os
import re
import resource
import statistics
import subprocess
import sys

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2]
STAGES = HERE.parent
SHIPPING = REPO / 'build/result-copies-19/shipping'
UPSTREAM = REPO / 'build/langbench-native/goose'
UPSTREAM_STDLIB = REPO / 'build/langbench-goose-source/stdlib'
UPSTREAM_RECEIPT = REPO / 'bench/results/2026-11-19/expression-lifetimes/upstream-controls.json'
HOST = REPO / 'host/rust/target/release/goose-wasmtime'
MODEL = SHIPPING / 'own/source/selfhost/model.goose'
STDLIB = SHIPPING / 'own/source/stdlib'
SIZE = (256, 1024, 4096)
COMPILERS = {
    'base': (SHIPPING / 'release/fixed.wasm', SHIPPING / 'release/fixed.cwasm'),
    'optimizer-state': (STAGES / 'optimizer-state/compiler.wasm', STAGES / 'review-screen/optimizer-state-b247393d8fbe3115.cwasm'),
    'scope-hash': (STAGES / 'scope-hash/compiler.wasm', STAGES / 'review-screen/scope-hash-b247393d8fbe3115.cwasm'),
    'checked-both': (STAGES / 'checked-both/compiler.wasm', STAGES / 'checked-both/witness.cwasm'),
}
sys.path[:0] = [str(REPO / 'scripts'), str(REPO / 'bench/results/2026-11-18/selfhost-wasm-runtime/tools')]
from measure import measured


def identity(path):
    data = path.read_bytes()
    return {'path': str(path), 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}


def checksum(path):
    return identity(path)['sha256']


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def graph(size):
    pieces = [f'fn leaf_{index:04}(n: i64) -> i64 {{ return n + {index % 17 + 1}; }}' for index in range(size)]
    pieces += ['fn main() {', '    var total = 1;']
    pieces += [f'    total = leaf_{index:04}(total);' for index in range(size)]
    pieces += ['    print(total);', '}']
    return '\n'.join(pieces) + '\n', f'{1 + sum(index % 17 + 1 for index in range(size))}\n'


def nested(size):
    depth = 12
    name = 'outer_' + 'long_lexical_identifier_' * 6 + 'value'
    pieces = [f'let {name}: i64 = 19;', 'fn main() {', '    var total = 0;']
    for index in range(depth):
        pieces.append('    ' * (index + 1) + '{')
    pieces += [f'{"    " * (depth + 1)}total += {name};'] * size
    for index in reversed(range(depth)):
        pieces.append('    ' * (index + 1) + '}')
    pieces += ['    print(total);', '}']
    return '\n'.join(pieces) + '\n', f'{19 * size}\n'


def witness(hash_source):
    return hash_source + '''

enum Choice { One, Two }
fn rejdsjmb(n: i64) -> i64 { return n + 11; }
fn wyrqlnhb(n: i64) -> i64 { return n + 23; }
fn rejdsjmb::marker() -> i64 { return 53; }
fn rejdsjmb(c: Choice.One) -> i64 { return 31; }
fn rejdsjmb(c: Choice.Two) -> i64 { return 37; }
fn route(c: Choice) -> i64 { return rejdsjmb(c); }

fn main() {
    print(bytes_hash("rejdsjmb"), " ", bytes_hash("wyrqlnhb"));
    print(rejdsjmb(1), " ", wyrqlnhb(1), " ", rejdsjmb::marker());
    {
        let rejdsjmb: i64 = 41;
        print(rejdsjmb, " ", wyrqlnhb(2), " ", rejdsjmb::marker());
    }
    {
        fn wyrqlnhb(n: i64) -> i64 { return n + 71; }
        print(rejdsjmb(2), " ", wyrqlnhb(2));
    }
    print(route(Choice.One {}), " ", route(Choice.Two {}));
}
'''


def check_result(completed, command, expected=None, allow_stderr=False):
    stdout = completed.stdout.decode()
    stderr = completed.stderr.decode(errors='replace')
    result = {'command': list(map(str, command)), 'status': completed.returncode, 'stdout': stdout, 'stderr': stderr}
    if completed.returncode or (stderr and not allow_stderr) or (expected is not None and stdout != expected):
        raise RuntimeError(result)
    return result


def primary_command(label):
    compiler, cache = COMPILERS[label]
    return [HOST, compiler, '--cache', cache]


def compilation_command(label, source, module, level, timer=None):
    command = primary_command(label)
    if timer is not None:
        command += ['--timing-json', timer]
    return [*command, '--', source, '--stdlib', STDLIB, '--target', 'wasm-direct', f'-O{level}', '-o', module]


def populate(work):
    source = MODEL.read_text()
    fn_hash = re.search(r'^fn bytes_hash\(.*?^}', source, re.MULTILINE | re.DOTALL).group(0)
    hash_path = work / 'bytes_hash.goose'
    hash_path.write_text(fn_hash + '\n')
    witness_path = work / 'binding-witness.goose'
    witness_path.write_text(witness(fn_hash))
    workloads = {}
    for (category, generator), size in itertools.product((('graph', graph), ('scope', nested)), SIZE):
        text, expected = generator(size)
        path = work / f'{category}-{size}.goose'
        path.write_text(text)
        workloads[path.stem] = {'source': identity(path), 'size': size, 'expected_stdout': expected}
    return workloads, hash_path, witness_path


def cache_and_pins(invoke):
    meta = {}
    for label, (compiler, cache) in COMPILERS.items():
        command = [*primary_command(label), '--', '--version']
        warmup = check_result(invoke(command), command)
        assert cache.with_suffix('.cwasm.sha256').read_text().strip() == checksum(compiler)
        meta[label] = {'compiler': identity(compiler), 'cache': identity(cache), 'warmup': warmup}
    for label in ('optimizer-state', 'scope-hash'):
        meta[label]['patch'] = identity(STAGES / label / 'change.patch')
    for label in ('optimizer-state', 'scope-hash', 'checked-both'):
        assert checksum(STAGES / label / 'source/selfhost/model.goose') == checksum(MODEL)
    return meta


def witness_controls(work, witness_path, invoke):
    receipt = json.loads(UPSTREAM_RECEIPT.read_bytes())
    assert checksum(UPSTREAM) == receipt['upstream_binary']
    collision = int('59488034', 16)
    expected = f'{collision} {collision}\n12 24 53\n41 25 53\n13 73\n31 37\n'
    upstream = [UPSTREAM, 'run', witness_path, '--stdlib', UPSTREAM_STDLIB]
    report = {
        'source': identity(witness_path), 'expected': expected, 'expected_fnv1a_hex': f'0x{collision:08x}',
        'upstream': {'revision': receipt['upstream'], 'binary': identity(UPSTREAM), 'result': check_result(invoke(upstream), upstream, expected, allow_stderr=True)},
        'cases': {},
    }
    for level in (0, 2):
        baseline = None
        for label in COMPILERS:
            module = work / f'witness-{label}-O{level}.wasm'
            compile_command = compilation_command(label, witness_path, module, level)
            compiled = check_result(invoke(compile_command), compile_command, '')
            module_identity = identity(module)
            module_hash = module_identity['sha256']
            if baseline is None:
                baseline = module_hash
            assert module_hash == baseline, (label, level, baseline, module_hash)
            run_command = [HOST, module, '--no-cache']
            executed = check_result(invoke(run_command), run_command, expected)
            report['cases'][f'{label}-O{level}'] = {'compiler_run': compiled, 'module': module_identity, 'execution': executed}
    return report


def finish(work, report):
    for name, workload in report['workloads'].items():
        grouped = {label: [row for row in report['runs'] if row['case'] == label and row['workload'] == name]
                   for label in ('base', 'optimizer-state', 'scope-hash')}
        observed = {}
        for label, rows in grouped.items():
            if not rows:
                continue
            baseline = grouped['base']
            observed[label] = {
                'samples': len(rows),
                'wall_ms': statistics.median(row['wall_ns'] for row in rows) / 1e6,
                'cpu_ms': statistics.median(row['cpu_s'] for row in rows) * 1000,
                'instructions': statistics.median(row['counters']['instructions']['value'] for row in rows),
                'paired_wall_change_percent': statistics.median(row['wall_ns'] / base['wall_ns'] - 1 for base, row in zip(baseline, rows)) * 100,
                'paired_instr_change_percent': statistics.median(row['counters']['instructions']['value'] / base['counters']['instructions']['value'] - 1 for base, row in zip(baseline, rows)) * 100,
            }
        workload['summary'] = observed
    write_json(work / 'observations.json', report)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cpu', type=int, default=6)
    parser.add_argument('--rounds', type=int, default=6)
    parser.add_argument('--only-witness', action='store_true')
    args = parser.parse_args()
    work = HERE.resolve()
    os.sched_setaffinity(0, {args.cpu})
    resource.setrlimit(resource.RLIMIT_STACK, (256 << 20, resource.getrlimit(resource.RLIMIT_STACK)[1]))
    home = work / 'home'
    home.mkdir(exist_ok=True)
    env = {**os.environ, 'GOOSE_HOME': str(home)}

    def invoke(command):
        return subprocess.run(command, cwd=work, env=env, capture_output=True, timeout=180)

    workloads, hash_path, witness_path = populate(work)
    stage = json.loads((SHIPPING / 'own/builds.json').read_bytes())
    report = {'cpu': args.cpu, 'rounds': args.rounds, 'compiler_baseline': stage['source_commit'],
              'compiler_baseline_archive_sha256': stage['source_archive_sha256'], 'compiler_model': identity(MODEL),
              'bytes_hash_fragment': identity(hash_path), 'host': identity(HOST),
              'training_layout': identity(SHIPPING / 'release/training.profile'),
              'compilers': cache_and_pins(invoke), 'workloads': workloads, 'runs': []}
    report['witness'] = witness_controls(work, witness_path, invoke)
    finish(work, report)
    print('binding witness passed upstream and all four compilers at O0/O2', flush=True)
    if args.only_witness:
        return
    cases = ('base', 'optimizer-state', 'scope-hash')
    orders = tuple(itertools.permutations(cases))
    timer = work / 'engine.json'
    for round_id in range(args.rounds):
        names = list(workloads)
        if round_id % 2 == 1:
            names.reverse()
        for name in names:
            data = workloads[name]
            source = Path(data['source']['path'])
            for label in orders[round_id % len(orders)]:
                module = work / f'{name}-{label}.wasm'
                timer.unlink(missing_ok=True)
                command = compilation_command(label, source, module, 2, timer)
                before = resource.getrusage(resource.RUSAGE_CHILDREN)
                completed, wall, counters = measured(lambda: invoke(command), child=True)
                after = resource.getrusage(resource.RUSAGE_CHILDREN)
                observation = check_result(completed, command, '')
                artifact = identity(module)
                if 'reference' not in data:
                    assert label == 'base'
                    execute = [HOST, module, '--no-cache']
                    data['reference'] = artifact
                    data['reference_run'] = check_result(invoke(execute), execute, data['expected_stdout'])
                assert artifact['sha256'] == data['reference']['sha256'], (name, label, artifact, data['reference'])
                report['runs'].append({'round': round_id + 1, 'case': label, 'workload': name,
                                       'invocation': observation, 'artifact': artifact, 'wall_ns': wall,
                                       'cpu_s': after.ru_utime + after.ru_stime - before.ru_utime - before.ru_stime,
                                       'counters': counters, 'engine': json.loads(timer.read_bytes())})
            finish(work, report)
            print(round_id + 1, name, {label: round(data['summary'][label]['wall_ms'], 2) for label in cases}, flush=True)


if __name__ == '__main__':
    main()
