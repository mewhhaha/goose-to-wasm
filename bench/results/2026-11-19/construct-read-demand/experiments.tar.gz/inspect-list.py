from common import *
os.sched_setaffinity(0,{5})
d=B/'list-probe';src=d/'source';shutil.copytree(B/'release/source',src,dirs_exist_ok=True);f=src/F;s=f.read_text()
orig=s;s=once(s,'fn life_list_set(l: Lifetimes&, start: i64) -> i64 {','var list_counts: i64[8];\nvar list_lengths: i64[10];\nfn life_list_set(l: Lifetimes&, start: i64) -> i64 {')
sig='let count = l.scratch.len - start;\n    var h: u64'
s=once(s,sig,'''let count = l.scratch.len - start;
    list_counts[0]++; list_counts[1] += count;
    var bucket = 0; var size = count;
    while size > 1 && bucket < 9 { size = size >> 1; bucket++; }
    list_lengths[bucket]++;
    if count > list_counts[7] { list_counts[7] = count; }
    var h: u64''')
s=once(s,'let entry = l.list_slots[slot];\n        if entry < 0 { break; }','list_counts[2]++; let entry = l.list_slots[slot];\n        if entry < 0 { break; }')
s=once(s,'if l.list_keys[entry] == key && l.sets[set].count == count && life_list_same(l, set, start) { return set; }','''if l.list_keys[entry] == key && l.sets[set].count == count {
            list_counts[3]++;
            if life_list_same(l, set, start) { list_counts[4]++; list_counts[5] += count; return set; }
            list_counts[6]++;
        }''')
s=once(s,'    if p.diagnostics.len == 0 { life_export_provenance','    print(list_counts); print(list_lengths);\n    if p.diagnostics.len == 0 { life_export_provenance')
f.write_text(s);(d/'change.patch').write_text(''.join(difflib.unified_diff(orig.splitlines(True),s.splitlines(True),'a/'+str(F),'b/'+str(F))))
mod=d/'probe.wasm';args=[*fixed[:-1],B/'release/training.profile']
subprocess.run([N,*A,*args,'-o',mod],cwd=src,check=True)
p=subprocess.run([H,mod,'--cache',d/'probe.cwasm','--',*A,'--check'],cwd=W/'source',capture_output=True,check=True)
assert not p.stderr
counts,lengths=map(json.loads,p.stdout.splitlines())
put(d/'result.json',dict(module=sha(mod),source=j(W/'builds.json')['source_commit'],counts=dict(zip(['calls','alternatives_hashed','table_probes','equal_hash_count','hits','alternatives_compared_on_hits','hash_collisions','longest_list'],counts)),calls_by_floor_log2_length=lengths))
print(counts,lengths,flush=True)
