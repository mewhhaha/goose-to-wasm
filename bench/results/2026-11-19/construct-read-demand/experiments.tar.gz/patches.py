from common import *
os.sched_setaffinity(0,{2});tags=sys.argv[1:];cases={'base':O/'release/fixed.wasm'}
for tag in tags:
 d=B/tag;src=d/'source';shutil.copytree(S,src,dirs_exist_ok=True)
 subprocess.run(['patch','--batch','-p1','-i',d/'change.patch'],cwd=src,check=True,stdout=subprocess.DEVNULL)
 m=d/'compiler.wasm';subprocess.run([N,*A,*fixed,'-o',m],cwd=src,check=True);cases[tag]=m
screen('review-screen',cases,4,7);screen('review-reverse',dict(reversed(list(cases.items()))),4,7)
