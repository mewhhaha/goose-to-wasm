from common import *
while not (B/'release/identity.json').is_file():time.sleep(2)
os.sched_setaffinity(0,{5})
namer=R/'build/lifetime-safe-19/namer.wasm';d=B/'release'
f=['--wasm-bundled-host','--wasm-initial-pages','65535','--wasm-max-pages','65535','--wasm-region-profile',d/'training.profile']
subprocess.run([H,namer,'--cache',B/'namer.cwasm','--',*A,*f,'-o',B/'named.wasm'],cwd=d/'source',check=True)
assert (B/'named.wasm').read_bytes().startswith((d/'fixed.wasm').read_bytes())
subprocess.run([R/'.venv/bin/python',B/'profile.py',B/'own',W,B/'named.wasm',B/'profile.json','--rounds','3','--cpu','5'],check=True)
