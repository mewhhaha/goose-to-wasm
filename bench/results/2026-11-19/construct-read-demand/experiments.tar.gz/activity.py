from common import *
os.sched_setaffinity(0,{4})
s=(S/F).read_text()
s=once(s,'struct LifeFrame {','struct LifeFrame { prof_calls: i64 = 0, prof_back: i64 = 0,')
s=once(s,'struct LifeReadEntry {','struct LifeReadEntry { prof: i32 = 0,')
s=once(s,'fn life_read_add(','''var lookup_counts: i64[10];
var distribution: i64[32];
fn life_read_add(''')
s=once(s,'let old = l.frames[frame].read_table; let cap = l.frames[frame].read_cap;', 'let old = l.frames[frame].read_table; let cap = l.frames[frame].read_cap; lookup_counts[0] += cap;')
s=once(s,'let index = l.summary_reads.len; l.summary_reads.push(entry);','''let index = l.summary_reads.len; l.summary_reads.push(entry); lookup_counts[1]++;
    if frame == l.frame { lookup_counts[2]++; }
    if entry.before < 0 { lookup_counts[3]++; }
    if l.frames[frame].recursive_call { lookup_counts[4]++; }
    if entry.walked & 1 == 1 { lookup_counts[5]++; }
    if l.leaves[entry.leaf].value.element_array != -1 { lookup_counts[6]++; }''')
s=once(s,'    var at = l.frames[frame].first_effect; if summary', '''    if summary { l.frames[frame].prof_calls++; if l.frames[frame].active { l.frames[frame].prof_back++; } }
    var at = l.frames[frame].first_effect; if summary''')
s=once(s,'            let entry = read; let item: const LifeReadEntry&', '''            l.summary_reads[read].prof |= 1;
            let entry = read; let item: const LifeReadEntry&''')
s=once(s,'            if memo { l.offer_count = 0;', '''            l.summary_reads[entry].prof |= 2; if !l.discovery { l.summary_reads[entry].prof |= 4; }
            if memo { l.offer_count = 0;''')
s=once(s,'    l.discovery = false;\n    for root, index in l.roots', '''    for f in l.frames {
        distribution[0] += f.read_count;
        if f.prof_calls == 0 { distribution[1] += f.read_count; }
        if f.prof_back == 0 { distribution[2] += f.read_count; }
        if f.prof_calls > 0 && f.prof_back > 0 { distribution[3] += f.read_count; }
        distribution[4] += f.read_cap;
    }
    distribution[5] = l.read_slots.len;
    distribution[6] = l.leaves.len;
    l.discovery = false;
    for root, index in l.roots''')
s=once(s,'    if p.diagnostics.len == 0 { life_export_provenance', '''    for entry in l.summary_reads { distribution[8 + (entry.prof as i64)]++; }
    for f in l.frames { if f.read_count > 0 { distribution[16]++; } if f.prof_calls == 0 { distribution[17] += f.read_count; } }
    print(lookup_counts); print(distribution);
    if p.diagnostics.len == 0 { life_export_provenance''')
d,m=prep('activity',s,wide)
p=subprocess.run([H,m,'--cache',d/'compiler.cwasm','--','selfhost/main.goose','--stdlib','stdlib','--check'],cwd=W/'source',capture_output=True);print(p.returncode,p.stderr.decode(),p.stdout.decode(),flush=True);assert p.returncode==0
put(d/'result.json',dict(compiler=sha(m),source=j(W/'builds.json')['source_commit'],counts=[json.loads(x) for x in p.stdout.splitlines()]))
