from trials import *
import argparse
p=argparse.ArgumentParser();p.add_argument('mode');args=p.parse_args()
def read(f):
 try:return json.loads(f.read_bytes())
 except (FileNotFoundError,json.JSONDecodeError):return {}
def gates():
 while not ((B/'release/identity.json').is_file() and
  read(B/'reader/reader/hot/report.json').get('status')=='passed' and len(read(B/'own/measurements.json').get('execution',{}).get('samples',[]))==3):time.sleep(3)
def pair(stage,d,cases,n):
 subprocess.run([R/'.venv/bin/python',R/'bench/results/2026-11-18/compiler-frame-cost/measure.py',stage,B/d,*[k+'='+str(f) for k,f in cases],'--rounds',str(n),'--cpu','7'],check=True)
gates()
if args.mode=='phases':
 subprocess.run([sys.executable,B/'phases.py'],check=True)
else:
 native=B/'own/build-1/compiler-native';wasm=B/'release/fixed.wasm'
 comp=[('native-before',N),('wasm-before',O/'release/fixed.wasm'),('wasm-after',wasm),('native-after',native)]
 pair(W/'own','frozen',comp,8);pair(W/'own','reverse',list(reversed(comp)),8)
 pair(B/'own','current',[('native',native),('wasm',wasm)],7)
 subprocess.run([R/'.venv/bin/python',R/'bench/results/2026-11-18/compiler-request-latency/launch.py',R,B/'own',B/'launch','--layout-profile',B/'release/training.profile','--fixed-bundled32','--cpu','7'],check=True)
 pair(B/'own','current-reverse',[('wasm',wasm),('native',native)],7)
