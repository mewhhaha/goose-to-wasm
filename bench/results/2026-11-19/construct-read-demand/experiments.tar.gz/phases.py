from trials import *
import json,hashlib
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
dst=B/'phases';dst.mkdir(exist_ok=True)
mod=B/'release/fixed.wasm';new=B/'own/build-1/compiler-native'
cases={'native-before':[N], 'wasm-before':[H,O/'release/fixed.wasm','--cache',O/'release/fixed.cwasm','--'], 'wasm-after':[H,mod,'--cache',B/'release/fixed.cwasm','--'], 'native-after':[new]}
os.sched_setaffinity(0,{5})
report=dict(source=json.loads((W/'own/builds.json').read_bytes())['source_commit'],source_archive_sha256=json.loads((W/'own/builds.json').read_bytes())['source_archive_sha256'],cpu=5,expected=sha(W/'own/build-1/compiler.wasm'),compiler_sha256={k:sha(c[1] if len(c)>1 else c[0]) for k,c in cases.items()},host_sha256=sha(H),samples=[])
for i in range(5):
 labels=list(cases)
 if i%2:labels.reverse()
 for case in labels:
  f=dst/'out.wasm';stats=dst/'phase.json';f.unlink(missing_ok=True);stats.unlink(missing_ok=True)
  args=['selfhost/main.goose','--stdlib','stdlib','--target','wasm-direct','-O2','--wasm-memory64','--wasm-max-pages','262144','--wasm-stats',stats,'-o',f]
  p=subprocess.Popen([*cases[case],*args],cwd=S,stdout=subprocess.DEVNULL)
  _,status,usage=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(status)
  assert p.returncode==0 and sha(f)==report['expected']
  raw=json.loads(stats.read_bytes())
  row=dict(round=i+1,case=case,peak_rss_kib=usage.ru_maxrss,output_sha256=report['expected'],phase={k:raw[k] for k in ('parse_ns','typecheck_ns','lifetime_ns','optimize_ns','backend_ns','nodes','functions')});report['samples'].append(row)
  (dst/'results.json').write_text(json.dumps(report,indent=2)+'\n')
  print(i+1,case,round(raw['lifetime_ns']/1e9,3),flush=True)
