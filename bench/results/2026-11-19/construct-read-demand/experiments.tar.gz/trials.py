from common import *
W=R/'build/replay-nov19'
S=W/'own/source'
