from common import *
os.sched_setaffinity(0,{2})
s=(S/F).read_text();sig='fn check_lifetimes(p: Program&, scope_parent: const i64[:], scope_depth: const i64[:], scope_functions: const i64[:], pool_references: const i64[:])'
params='p, scope_parent, scope_depth, scope_functions, pool_references'
# Only the attempt owns analysis arenas. A retry starts after they have been released.
a=s.index(sig);b=s.index('    var roots:',a);end=s.rindex('}')
body=s[b:end].replace('return;', 'return true;')
body=once(body,'    l.types_frozen = true;','''    l.types_frozen = true;
    let omit_reads = !full && !life_has_replacement(p, l);
    l.omit_construct_reads = omit_reads;''')
body=once(body, '        for root in standalone { life_function(p, l, root.function_node, -1, root.arguments, 0); }', '''        for root in standalone {
            if omit_reads && !l.omit_construct_reads { return false; }
            life_function(p, l, root.function_node, -1, root.arguments, 0);
        }
        if omit_reads && !l.omit_construct_reads { return false; }''')
body=once(body, '    for root in standalone { life_function(p, l, root.function_node, -1, root.arguments, 0); }', '''    for root in standalone {
        if omit_reads && !l.omit_construct_reads { return false; }
        life_function(p, l, root.function_node, -1, root.arguments, 0);
    }
    if omit_reads && !l.omit_construct_reads { return false; }''')
# Include a check after each global initializer so class-heavy libraries with no main also stop promptly.
body=body.replace('                life_eval(p, l, symbol.node);','                life_eval(p, l, symbol.node);\n                if omit_reads && !l.omit_construct_reads { return false; }')
body=body.replace('{ life_eval(p, l, symbol.node); }','{\n            life_eval(p, l, symbol.node);\n            if omit_reads && !l.omit_construct_reads { return false; }\n        }')
s=s[:a]+'''// Only assignment to size-class-2 storage can create a replacement hold.
fn life_has_replacement(p: Program&, l: Lifetimes&) -> bool {
    for index in 0..p.nodes.len {
        let n: const Node& = p.nodes[index];
        if n.kind != N_ASSIGN || n.left < 0 { continue; }
        let target: const Node& = p.nodes[n.left];
        if target.kind != N_NAME && target.kind != N_INDEX && target.kind != N_MEMBER && !(target.kind == N_UNARY && target.integer == T_MUL) { return true; }
        var ty = target.type_id;
        if ty >= 0 && p.types[ty].kind == TY_REF && n.integer != T_DOTASSIGN { ty = p.types[ty].element; }
        if life_cached_size_class(p, l, ty) == 2 { return true; }
    }
    return false;
}
'''+sig+''' {
    if p.diagnostics.len > 0 { return; }
    let nodes = p.nodes.len; let types = p.types.len; let holds = p.type_holds.len;
    let messages = p.messages.len;
    if life_check_attempt('''+params+''', false) { return; }
    // Standalone parameters append synthetic nodes and types. Discard them and
    // any diagnostics from this attempt before rebuilding full class summaries.
    p.nodes.resize(nodes); p.types.resize(types); p.type_holds.resize(holds);
    p.diagnostics.clear(); p.messages.resize(messages);
    life_check_attempt('''+params+''', true);
}
'''+sig.replace('fn check_lifetimes(', 'fn life_check_attempt(')[:-1]+', full: bool) -> bool {\n'+body+'    return true;\n}\n'
s=once(s,'compact: bool = true','omit_construct_reads: bool = false, compact: bool = true')
s=once(s,'    if l.reading_place > 0 { return; }\n    var effect_places','    if l.omit_construct_reads || l.reading_place > 0 { return; }\n    var effect_places')
s=once(s,'    if l.compact { life_reads_materialize(p, l); }','''    // Class mapping needs the full history, including earlier concrete reads.
    l.omit_construct_reads = false;
    if l.compact { life_reads_materialize(p, l); }''')
s=once(s,'            life_shrink(p, l, node, receiver); kind = 2;','''            l.omit_construct_reads = false;
            life_shrink(p, l, node, receiver); kind = 2;''')
d,m=prep('checked',s,fixed)
# Optional independently reviewed candidates compiled on top of the same checker.
cases={'base':O/'release/fixed.wasm','checked':m}
for tag,extra in [('opt',['optimizer-state']),('hash',['scope-hash']),('both',['optimizer-state','scope-hash'])]:
 t=B/('checked-'+tag);src=t/'source';shutil.copytree(d/'source',src,dirs_exist_ok=True)
 for x in extra:subprocess.run(['patch','--batch','-p1','-i',B/x/'change.patch'],cwd=src,check=True,stdout=subprocess.DEVNULL)
 mod=t/'compiler.wasm';subprocess.run([N,*A,*fixed,'-o',mod],cwd=src,check=True);cases[tag]=mod
screen('integrated',cases,4,7);screen('integrated-reverse',dict(reversed(list(cases.items()))),4,7)
