from common import *
os.sched_setaffinity(0,{6});d=B/'fixtures';up=R/'build/langbench-native/goose';report={}
for f in sorted(d.glob('*.goose')):
 group={}
 for k,cmd in [('baseline',[N]),('guest-new',[H,B/'release/fixed.wasm','--cache',B/'release/fixed.cwasm','--']),('forced-base',[B/'semantic/old-16/probe']),('forced-new',[B/'semantic/new-16/probe']),('upstream',[up,'run' if 'ok' in f.name else 'check'])]:
  if k.startswith('forced') and f.name.startswith('production'):continue
  out=d/(k+'-fixture.wasm');out.unlink(missing_ok=True)
  flags=['--stdlib',R/'stdlib','--target','wasm-direct','-O2','-o',out];
  if k.startswith('forced'):flags=['--stdlib',R/'stdlib','--check']
  if k=='upstream':flags=['--stdlib',R/'build/langbench-goose-source/stdlib']
  before=time.monotonic();p=subprocess.run([*cmd,f,*flags],cwd=d,capture_output=True,env={**os.environ,'GOOSE_HOME':str(d/'home')},timeout=240)
  raw=[v.decode() for v in p.stderr.splitlines() if v.startswith(b'LIFEFP ')];se=b'\n'.join(v for v in p.stderr.splitlines() if v.strip() and not v.startswith((b'LIFEFP ',b'PROJECT ')))
  group[k]=dict(status=p.returncode,stderr=se.decode(),stdout=p.stdout.decode(),raw=raw,seconds=time.monotonic()-before)
  if out.exists():
   obs=subprocess.run([H,out,'--no-cache'],check=True,capture_output=True);group[k]['execution']=obs.stdout.decode();group[k]['wasm']=sha(out)
  print(f.name,k,p.returncode,group[k].get('execution',''),se[:100],flush=True)
 report[f.name]=dict(source=sha(f),cases=group);put(d/'final.json',report)
