from common import *
from concurrent.futures import ThreadPoolExecutor
from collections import Counter
import gzip
src_root=R/'build/life-parity/fp-corpus/upstream';manifest=j(R/'tests/conformance/cases.json')
names={x['source'] for x in manifest['cases']};inputs={}
for name in names:
 if name.startswith('upstream:'):inputs[name]=(src_root/name[9:],src_root,src_root/'stdlib')
 else:inputs[name]=(R/name,R,R/'stdlib')
controls=[('self',W/'source/selfhost/main.goose',W/'source',W/'source/stdlib'),('class-exits',R/'bench/results/2026-11-18/compiler-array-views/lifetime/class-exits.goose',R,R/'stdlib'),('class-read',R/'bench/results/2026-11-18/compiler-replay-and-captures/replay/class-read.goose',R,R/'stdlib')]
for f in sorted((R/'build/review-mixed-leaf').glob('*.goose')):controls.append(('mixed-'+f.name,f,R,R/'stdlib'))
def take(bin,src,cwd,lib):
 p=subprocess.run([bin,src,'--stdlib',lib,'--target','native','--check'],cwd=cwd,capture_output=True,timeout=600)
 lines=p.stderr.splitlines(keepends=True)
 return dict(code=p.returncode,stdout=hashlib.sha256(p.stdout).hexdigest(),stderr=hashlib.sha256(b''.join(x for x in lines if not x.startswith((b'PROJECT ',b'LIFEFP ')))).hexdigest(),project=[x.decode().strip() for x in lines if x.startswith(b'PROJECT ')],full=[x.decode().strip() for x in lines if x.startswith(b'LIFEFP ')])
def cmp(row):
 name,src,cwd,lib=row;v=[take(x,src,cwd,lib) for x in bins];a,c=v;obs=all(a[k]==c[k] for k in ['code','stdout','stderr']);pr=a['project']==c['project'];raw=not c['full'] or a['full']==c['full']
 return dict(name=name,source=sha(src),observation=obs,projection=pr,raw=raw,baseline_lines=len(a['full']),full_lines=len(c['full']),projected_lines=len(c['project']),detail=v if not (obs and pr and raw) or name in ['self','class-exits','class-read'] else None)
mode=sys.argv[1];forced=16 if mode=='forced' else 4096;bins=[B/'semantic'/(tag+'-'+str(forced))/'probe' for tag in ['old','new']]
while not all(p.exists() for p in bins):time.sleep(2)
os.sched_setaffinity(0,{0,2,4,6});cases=controls if mode!='corpus' else [(n,*inputs[n]) for n in sorted(inputs)]
if mode in ['forced','native-controls']:cases=[r for r in cases if r[0]!='self']
with ThreadPoolExecutor(4) as ex: rows=list(ex.map(cmp,cases))
summary=dict(total=len(rows),observation_diffs=sum(not r['observation'] for r in rows),projection_diffs=sum(not r['projection'] for r in rows),full_diffs=sum(not r['raw'] for r in rows),baseline_lines=sum(r['baseline_lines'] for r in rows),full_lines=sum(r['full_lines'] for r in rows),projected_lines=sum(r['projected_lines'] for r in rows),omitted_cases=sum(r['baseline_lines']>0 and r['full_lines']==0 for r in rows))
put(B/('semantic-'+mode+'.json'),dict(summary=summary,probes=[sha(x) for x in bins],cases=rows));print(mode,summary,flush=True)
