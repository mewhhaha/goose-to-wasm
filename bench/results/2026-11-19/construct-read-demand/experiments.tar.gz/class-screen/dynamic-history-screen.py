import hashlib
import json
import os
from pathlib import Path
import resource
import statistics
import subprocess
import sys

work = Path(__file__).resolve().parent
stage = work.parent
root = stage.parents[1]
frozen = root / 'build/replay-nov19/own'
frozen_manifest = json.loads((frozen / 'builds.json').read_bytes())
release = stage / 'release'
host = root / 'host/rust/target/release/goose-wasmtime'
sys.path[:0] = [str(root / 'scripts'), str(root / 'bench/results/2026-11-18/selfhost-wasm-runtime/tools')]
from measure import measured

os.sched_setaffinity(0, {4})
resource.setrlimit(resource.RLIMIT_STACK, (256 << 20, resource.getrlimit(resource.RLIMIT_STACK)[1]))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

baseline = release / 'fixed.wasm'
candidate = work / 'dynamic-history.wasm'
compilers = {'release': (baseline, release / 'fixed.cwasm'),
             'history': (candidate, work / 'dynamic-history.cwasm')}
commands = {}
for label, (module, cache) in compilers.items():
    assert cache.with_suffix('.cwasm.sha256').read_text().strip() == sha(module)
    commands[label] = [host, module, '--cache', cache, '--']

def check(command, directory):
    return subprocess.run(command, cwd=directory, capture_output=True, timeout=60)

fixture = stage / 'fixtures/production-ok.goose'
with_read = work / 'production-reads-before-class.goose'
source_text = fixture.read_text()
assert source_text.count('fn main() {\n') == 1
with_read.write_text(source_text.replace('fn main() {\n','fn main() {\n    var history: i64[>..<] = [7];\n    print(history[0]);\n'))
stdlib = release / 'source/stdlib'
fixtures = {
    'called-4100': (fixture, work, stdlib, 'check', 0),
    'captured-callback-4100': (work / 'captured-callback-reads.goose', work, stdlib, 'check', 0),
    'frozen-rebuild': (Path('selfhost/main.goose'), frozen / 'source', Path('stdlib'), 'emit', 0),
    'called-4100-error': (stage / 'fixtures/production-error.goose', work, stdlib, 'check', 1),
    'class-with-early-read': (with_read, work, stdlib, 'check', 0),
    'replacement-error': (stage / 'storage-review/replacement-error.goose', work, stdlib, 'check', 1),
}
emit = ['--target', 'wasm-direct', '-O2', '--wasm-memory64', '--wasm-max-pages', '262144']
report = {'programs': {}, 'samples': [], 'cpu': 4, 'frozen_commit': frozen_manifest['source_commit'],
          'frozen_archive_sha256': frozen_manifest['source_archive_sha256'], 'candidate_source': 'fc34386',
          'host': sha(host), 'training_profile': sha(release / 'training.profile'),
          'compilers': {label: sha(row[0]) for label, row in compilers.items()}}

def save():
    (work / 'dynamic-history-report.json').write_text(json.dumps(report, indent=2) + '\n')

for tag, (source, directory, library, mode, status) in fixtures.items():
    report['programs'][tag] = {'source': sha(directory / source), 'timed_mode': mode, 'emission': {}}
    for label, command in commands.items():
        output = work / f'dynamic-history-{tag}-{label}.wasm'
        output.unlink(missing_ok=True)
        proc = check([*command, source, '--stdlib', library, *emit, '-o', output], directory)
        assert proc.returncode == status, (tag, label, proc.returncode, proc.stderr)
        report['programs'][tag]['emission'][label] = {'status': proc.returncode, 'stderr': proc.stderr.decode(),
                                                     'stdout': proc.stdout.decode(),
                                                     'sha256': sha(output) if output.exists() else None}
    values = report['programs'][tag]['emission']
    assert values['release'] == values['history'], values
    if tag == 'frozen-rebuild':
        assert values['release']['sha256'] == sha(frozen / 'build-1/compiler.wasm')
    print(f'verified {tag}', flush=True)
    save()

for round_ in range(6):
    for tag, (source, directory, library, mode, status) in list(fixtures.items())[:3]:
        order = list(commands) if round_ % 2 == 0 else list(reversed(commands))
        output = work / 'timed-output.wasm'
        args = [*emit, '-o', output] if mode == 'emit' else ['--check']
        for label in order:
            output.unlink(missing_ok=True)
            before = resource.getrusage(resource.RUSAGE_CHILDREN)
            proc, wall, counts = measured(lambda: check([*commands[label], source, '--stdlib', library, *args], directory), child=True)
            after = resource.getrusage(resource.RUSAGE_CHILDREN)
            assert (proc.returncode, proc.stdout, proc.stderr) == (status, b'', b'')
            digest = sha(output) if mode == 'emit' else None
            if mode == 'emit':
                assert digest == report['programs'][tag]['emission'][label]['sha256']
            cpu = after.ru_utime + after.ru_stime - before.ru_utime - before.ru_stime
            report['samples'].append({'round': round_ + 1, 'label': label, 'fixture': tag,
                                      'wall_ns': wall, 'cpu_s': cpu, 'retired': counts['instructions'], 'output': digest})
            print(round_+1, tag, label, round(wall/1e9,4), round(cpu, 4), counts['instructions']['value'], flush=True)
            save()

report['summary'] = {}
for tag in list(fixtures)[:3]:
    rows = [row for row in report['samples'] if row['fixture'] == tag]
    summary = report['summary'][tag] = {}
    for metric, value in [('retired', lambda x: x['retired']['value']), ('wall_ns', lambda x: x['wall_ns']), ('cpu_s', lambda x: x['cpu_s'])]:
        pairs = []
        for round_ in range(1, 7):
            pair = {row['label']: value(row) for row in rows if row['round'] == round_}
            pairs.append(100 * (pair['history'] / pair['release'] - 1))
        summary[metric] = {'paired_percent': statistics.median(pairs), 'odd_percent': statistics.median(pairs[::2]),
                           'even_percent': statistics.median(pairs[1::2]),
                           'median_release': statistics.median(value(row) for row in rows if row['label'] == 'release'),
                           'median_history': statistics.median(value(row) for row in rows if row['label'] == 'history')}
save()
print(json.dumps(report['summary'], indent=2), flush=True)
