import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import statistics
import subprocess
import sys

work = Path(__file__).resolve().parent
stage = work.parent
root = stage.parents[1]
frozen = root / 'build/replay-nov19/own'
frozen_manifest = json.loads((frozen / 'builds.json').read_bytes())
release = stage / 'release'
host = root / 'host/rust/target/release/goose-wasmtime'
sys.path.insert(0, str(root / 'bench/results/2026-11-18/selfhost-wasm-runtime/tools'))
sys.path.insert(0, str(root / 'scripts'))
from measure import measured

os.sched_setaffinity(0, {4})
resource.setrlimit(resource.RLIMIT_STACK, (256 << 20, resource.getrlimit(resource.RLIMIT_STACK)[1]))

def identity(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

modules = {'release': release / 'fixed.wasm', 'reachable': work / 'reachable.wasm'}
commands = {}
for label, module in modules.items():
    cache = work / f'{label}.cwasm'
    if label == 'release':
        shutil.copy2(release / 'fixed.cwasm', cache)
        shutil.copy2(release / 'fixed.cwasm.sha256', cache.with_suffix('.cwasm.sha256'))
    command = [host, module, '--cache', cache, '--']
    subprocess.run([*command, '--version'], cwd=work, check=True, capture_output=True)
    assert cache.with_suffix('.cwasm.sha256').read_text().strip() == identity(module)
    commands[label] = command

fixtures = {
    'called-4100': (stage / 'fixtures/production-ok.goose', work, release / 'source/stdlib'),
    'standalone-4100': (work / 'standalone-reads.goose', work, release / 'source/stdlib'),
    'frozen': (Path('selfhost/main.goose'), frozen / 'source', Path('stdlib')),
    'library-4100': (work / 'standalone-reads.goose', work, release / 'source/stdlib'),
    'called-4100-error': (stage / 'fixtures/production-error.goose', work, release / 'source/stdlib'),
}
report = {'programs': {}, 'samples': [], 'cpu': 4, 'frozen_commit': frozen_manifest['source_commit'],
          'frozen_archive_sha256': frozen_manifest['source_archive_sha256'], 'prediction_source': 'fc34386',
          'host': identity(host), 'training_profile': identity(release / 'training.profile'),
          'compilers': {label: identity(module) for label, module in modules.items()}}

def save():
    (work / 'reachable-report.json').write_text(json.dumps(report, indent=2) + '\n')

for fixture, (source, directory, stdlib) in fixtures.items():
    extra = ['--library'] if fixture.startswith('library-') else []
    expected = 1 if fixture.endswith('-error') else 0
    report['programs'][fixture] = {'source': identity(directory / source), 'extra': extra, 'encoding': 'memory64 O2', 'emission': {}}
    for label, command in commands.items():
        output = work / f'{fixture}-{label}.wasm'
        output.unlink(missing_ok=True)
        proc = subprocess.run([*command, source, '--stdlib', stdlib, *extra, '--target', 'wasm-direct', '-O2',
                               '--wasm-memory64', '--wasm-max-pages', '262144', '-o', output],
                              cwd=directory, capture_output=True, timeout=60)
        assert proc.returncode == expected, (fixture, label, proc.returncode, proc.stderr)
        report['programs'][fixture]['emission'][label] = {
            'status': proc.returncode, 'stderr': proc.stderr.decode(), 'stdout': proc.stdout.decode(),
            'sha256': identity(output) if output.exists() else None,
        }
    values = report['programs'][fixture]['emission']
    assert values['release'] == values['reachable'], values
    if fixture == 'frozen':
        assert values['release']['sha256'] == identity(frozen / 'build-1/compiler.wasm')
    print(f'verified {fixture}', flush=True)
    save()

for round_ in range(6):
    for fixture, (source, directory, stdlib) in list(fixtures.items())[:-1]:
        extra = ['--library'] if fixture.startswith('library-') else []
        order = list(commands) if round_ % 2 == 0 else list(reversed(commands))
        for label in order:
            before = resource.getrusage(resource.RUSAGE_CHILDREN)
            proc, wall, counts = measured(lambda: subprocess.run([*commands[label], source, '--stdlib', stdlib, *extra, '--check'],
                                         cwd=directory, capture_output=True, timeout=60), child=True)
            after = resource.getrusage(resource.RUSAGE_CHILDREN)
            assert (proc.returncode, proc.stdout, proc.stderr) == (0, b'', b'')
            cpu = after.ru_utime + after.ru_stime - before.ru_utime - before.ru_stime
            report['samples'].append({'round': round_ + 1, 'label': label, 'fixture': fixture,
                                      'wall_ns': wall, 'cpu_s': cpu, 'retired': counts['instructions']})
            print(round_+1, fixture, label, round(cpu, 4), counts['instructions']['value'], flush=True)
            save()

report['summary'] = {}
for fixture in list(fixtures)[:-1]:
    rows = [row for row in report['samples'] if row['fixture'] == fixture]
    summary = report['summary'][fixture] = {}
    for metric, value in [('retired', lambda x: x['retired']['value']), ('cpu_s', lambda x: x['cpu_s'])]:
        pairs = []
        for round_ in range(1, 7):
            pair = {row['label']: value(row) for row in rows if row['round'] == round_}
            pairs.append(100 * (pair['reachable'] / pair['release'] - 1))
        summary[metric] = {'paired_percent': statistics.median(pairs), 'odd_percent': statistics.median(pairs[::2]),
                           'even_percent': statistics.median(pairs[1::2]),
                           'median_release': statistics.median(value(row) for row in rows if row['label'] == 'release'),
                           'median_prediction': statistics.median(value(row) for row in rows if row['label'] == 'reachable')}
save()
print(json.dumps(report['summary'], indent=2), flush=True)
