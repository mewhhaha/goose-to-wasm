from common import *
os.sched_setaffinity(0,{6})
root=B/'wasm-fp';root.mkdir(exist_ok=True);rows=[]
for tag in ['old','new']:
 src=B/'semantic'/(tag+'-4096')/'source';module=root/(tag+'.wasm')
 subprocess.run([N,*A,*wide,'-o',module],cwd=src,check=True)
 r=subprocess.run([H,module,'--cache',root/(tag+'.cwasm'),'--',W/'source/selfhost/main.goose','--stdlib',W/'source/stdlib','--target','native','--check'],cwd=W/'source',capture_output=True,timeout=900)
 lines=r.stderr.decode().splitlines();row=dict(module=sha(module),host=sha(H),exit=r.returncode,stdout=r.stdout.decode(),diagnostics=[x for x in lines if x and not x.startswith(('PROJECT ','LIFEFP '))],full=[x for x in lines if x.startswith('LIFEFP ')],project=[x for x in lines if x.startswith('PROJECT ')])
 print(tag,r.returncode,len(row['full']),len(row['project']),row['diagnostics'][:1],flush=True)
 assert r.returncode==0 and row['project'] and not row['diagnostics'] and not row['stdout']
 rows.append(row)
assert rows[0]['project']==rows[1]['project'];put(root/'result.json',rows)
