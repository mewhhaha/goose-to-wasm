from common import *
n=j(B/'semantic-native-controls.json');a,c=j(B/'wasm-fp/result.json');assert a['project']==c['project'] and len(a['project'])==1 and not c['full']
for r in [a,c]:assert r['exit']==0 and not r['diagnostics'] and not r['stdout']
n['cases'].insert(0,dict(name='self',source=sha(W/'source/selfhost/main.goose'),observation=True,projection=True,raw=True,baseline_lines=len(a['full']),full_lines=0,projected_lines=1,detail=[a,c]))
s=n['summary'];s['total']+=1;s['baseline_lines']+=len(a['full']);s['omitted_cases']+=1;s['projected_lines']+=1
n['selfhost_probes']=[r['module'] for r in [a,c]];n['selfhost_runner']=c['host'];n['measurement_note']='The unoptimized native baseline instrumented self-check reached a 600 s wall limit. The same probe sources were compiled to memory64 and the frozen self-check completed in Wasmtime. Other controls used native probes.'
put(B/'semantic-controls.json',n);print(s)
