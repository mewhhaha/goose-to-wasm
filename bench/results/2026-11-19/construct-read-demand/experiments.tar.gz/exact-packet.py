from common import *
os.sched_setaffinity(0,{2});out={}
for name,source in [('old',S),('new',B/'release/source')]:
 d=B/('exact-packet-'+name);src=d/'source';shutil.copytree(source,src,dirs_exist_ok=True);f=src/F;s=f.read_text();s=once(s,'fn life_read_add(', 'var read_add_count = 0;\nfn life_read_add(')
 s=once(s,'    let index = l.summary_reads.len; l.summary_reads.push(entry);','    read_add_count++; let index = l.summary_reads.len; l.summary_reads.push(entry);')
 s=once(s,'    if p.diagnostics.len == 0 { life_export_provenance','    print([read_add_count, l.read_slots.len, l.frames.len, l.class_frames, l.leaves.len, l.pass]);\n    if p.diagnostics.len == 0 { life_export_provenance')
 f.write_text(s);(d/'change.patch').write_text(''.join(difflib.unified_diff((source/F).read_text().splitlines(True),s.splitlines(True),'a/'+str(F),'b/'+str(F))))
 mod=d/'probe.wasm';subprocess.run([N,*A,*fixed,'-o',mod],cwd=src,check=True)
 p=subprocess.run([H,mod,'--cache',d/'probe.cwasm','--',*A,'--check'],cwd=W/'source',capture_output=True,check=True);assert not p.stderr;out[name]=dict(probe=sha(mod),observed=json.loads(p.stdout));print(name,out[name],flush=True)
put(B/'exact-insertions.json',out)
