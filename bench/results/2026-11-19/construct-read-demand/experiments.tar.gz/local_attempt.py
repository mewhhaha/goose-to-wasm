from common import *
os.sched_setaffinity(0,{4})
s=(B/'fallback/source'/F).read_text()
s=once(s,'    if !l.check_construct_reads { return false from life_check_attempt; }\n','')
s=once(s,'let diagnostics = p.diagnostics.len;', 'let diagnostics = p.diagnostics.len; let messages = p.messages.len;')
s=once(s,'p.diagnostics.resize(diagnostics);','p.diagnostics.resize(diagnostics); p.messages.resize(messages);')
s=once(s,'    if p.type_indexed > types { p.type_buckets.clear(); p.type_links.clear(); p.type_indexed = 0; }\n','')
s=once(s,'        if l.failures.len > 0 {\n            l.discovery = false;', '''        if !l.check_construct_reads && (l.class_frames > 0 || l.failures.len > 0) { return false; }
        if l.failures.len > 0 {
            l.discovery = false;''')
s=once(s,'    if p.diagnostics.len == 0 { life_export_provenance', '''    if !l.check_construct_reads && (l.class_frames > 0 || p.diagnostics.len > 0) { return false; }
    if p.diagnostics.len == 0 { life_export_provenance''')
# Stop at root boundaries before starting another potentially large standalone tree.
s=once(s,'        for root in standalone { life_function(p, l, root.function_node, -1, root.arguments, 0); }','''        for root in standalone {
            if !l.check_construct_reads && l.class_frames > 0 { return false; }
            life_function(p, l, root.function_node, -1, root.arguments, 0);
        }''')
s=once(s,'    for root in standalone { life_function(p, l, root.function_node, -1, root.arguments, 0); }','''    for root in standalone {
        if !l.check_construct_reads && l.class_frames > 0 { return false; }
        life_function(p, l, root.function_node, -1, root.arguments, 0);
    }''')
d,m=prep('local-attempt',s,fixed);screen('local-screen',{'base':O/'release/fixed.wasm','local-attempt':m},4,5)
