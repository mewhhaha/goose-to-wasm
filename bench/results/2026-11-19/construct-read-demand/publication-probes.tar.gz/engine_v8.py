from contextlib import ExitStack
from hashlib import sha256
import json
import os
from pathlib import Path
import resource
import select
import shutil
from statistics import median
import subprocess

scratch = Path(__file__).resolve().parent
project = scratch.parents[2]
stage = project / "build/replay-nov19/own"
source = stage / "source"
node = Path(shutil.which("node")).resolve()
runner = project / "bench/selfhost_v8.mjs"
host = project / "scripts/run_wasm.mjs"
parts = {"base": scratch.parent / "release/fixed.wasm", "guard": scratch / "guarded.wasm"}
frozen = json.loads((stage / "builds.json").read_text())
cpu = 1
flags = ["--stack-size=65536", "--no-liftoff", "--no-wasm-lazy-compilation"]
os.sched_setaffinity(0, {cpu})
resource.setrlimit(resource.RLIMIT_STACK, (256 << 20, resource.getrlimit(resource.RLIMIT_STACK)[1]))
environment = {**os.environ}
for name in ("NODE_OPTIONS", "GOOSE_REGION_STATS", "GOOSE_REGION_PROFILE"):
    environment.pop(name, None)
def identity(path):
    return dict(sha256=sha256(path.read_bytes()).hexdigest(), bytes=path.stat().st_size)
check = ["selfhost/main.goose", "--stdlib", "stdlib", "--check"]
output = scratch / "engines-v8-emitted.wasm"
emit = ["selfhost/main.goose", "--stdlib", "stdlib", "--target", "wasm-direct", "-O2",
        "--wasm-memory64", "--wasm-max-pages", "262144", "-o", str(output)]
report = {
    "node_binary": identity(node), "runner": identity(runner), "host": identity(host),
    "cpu": cpu, "CPU_affinity": list(os.sched_getaffinity(0)), "flags": flags,
    "worker_stack_mib": 256, "frozen_source": frozen["source_commit"],
    "frozen_archive_sha256": frozen["source_archive_sha256"], "arguments": {"check": check, "emit": emit},
    "reference": identity(stage / "build-1/compiler.wasm"), "cases": {}, "runs": [],
}
receipt = scratch / "engines-v8.json"
def save():
    receipt.write_text(json.dumps(report, indent=2) + "\n")

def receive(worker, label):
    if not select.select([worker.stdout], [], [], 180)[0]:
        raise RuntimeError(f"{label} V8 worker response timeout")
    raw = worker.stdout.readline()
    if not raw:
        raise RuntimeError(f"{label} V8 worker exited with {worker.poll()}")
    return json.loads(raw)

def request(worker, label, args):
    worker.stdin.write(json.dumps(args) + "\n")
    worker.stdin.flush()
    return receive(worker, label)

try:
    with ExitStack() as cleanup:
        workers = {}
        def stop(worker):
            if worker.poll() is None:
                worker.stdin.close()
                try:
                    worker.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    worker.kill()
                    worker.wait()
        for label, module in parts.items():
            trace = cleanup.enter_context((scratch / f"engines-v8-{label}.log").open("wb"))
            worker = subprocess.Popen(
                [node, *flags, runner, module], cwd=source, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                stderr=trace, text=True, env=environment,
            )
            cleanup.callback(stop, worker)
            workers[label] = worker
            ready = receive(worker, label)
            fingerprint = identity(module)
            assert ready["source_sha256"] == fingerprint["sha256"]
            report["cases"][label] = {"module": fingerprint, "ready": ready}
            probe = request(worker, label, ["--version"])
            report["cases"][label]["version_probe"] = probe
            save()
            if probe["exitCode"] or probe["stderr"]:
                raise RuntimeError(f"{label} bundled-host module: {probe['stderr']}")
            print("v8 ready", label, ready, flush=True)

        def run(label, mode, round_id):
            output.unlink(missing_ok=True)
            result = request(workers[label], label, check if mode == "check" else emit)
            item = {"case": label, "mode": mode, "round": round_id, **result}
            if not result["exitCode"] and mode == "emit":
                item["output"] = identity(output)
                assert item["output"] == report["reference"], item
            report["runs"].append(item)
            save()
            assert not (result["exitCode"] or result["stderr"] or result["stdout"]), result
            print(mode, round_id, label, f"{result['timing']['start_function_ns'] / 1e9:.3f}s", flush=True)

        for mode, rounds in (("check", 4), ("emit", 2)):
            for round_id in range(1, rounds + 1):
                order = ("base", "guard") if round_id % 2 else ("guard", "base")
                for label in order:
                    run(label, mode, round_id)
        report["median_guest_s"] = {
            mode: {label: median(row["timing"]["start_function_ns"] for row in report["runs"]
                                 if row["mode"] == mode and row["case"] == label) / 1e9
                   for label in parts}
            for mode in ("check", "emit")
        }
        save()
except Exception as failure:
    report["error"] = str(failure)
    save()
    raise
