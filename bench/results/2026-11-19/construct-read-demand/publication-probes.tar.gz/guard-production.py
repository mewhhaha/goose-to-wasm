from common import *
import importlib.util
d=B/'publication/full';d.mkdir(exist_ok=True);src=B/'publication/emitter-source'
os.sched_setaffinity(0,{4})
fixed_args=[*fixed[:-1],B/'release/training.profile']
mod=d/'compiler.wasm'
subprocess.run([H,B/'publication/emitter.wasm','--cache',B/'publication/emitter.cwasm','--',*A,*fixed_args,'-o',mod],cwd=src,check=True)
cc=d/'compiler-native'
subprocess.run([R/'.venv/bin/python',R/'scripts/goose_wasm.py','build','selfhost/main.goose','--stdlib','stdlib','--goose',B/'own/build-1/compiler-native','--backend','native','--cc','clang-23','--jobs','8','--no-cache','-O2','-o',cc],cwd=src,check=True,preexec_fn=lambda:os.sched_setaffinity(0,{0,2,4,6}))
reference=d/'reference.wasm'
subprocess.run([cc,*A,*wide,'-o',reference],cwd=W/'source',check=True)
out=d/'out.wasm';rpt=d/'fixed-point.wasm'
guest=[H,mod,'--cache',d/'compiler.cwasm','--'];subprocess.run([*guest,*A,*fixed_args,'-o',rpt],cwd=src,check=True)
assert sha(mod)==sha(rpt)
subprocess.run([*guest,*A,*wide,'-o',out],cwd=W/'source',check=True);assert sha(out)==sha(reference)
# The reference compiler output has changed. Populate a stage with the same
# frozen workload and the reference native emission for the patched backend.
stage=d/'expected';stage.mkdir(exist_ok=True)
o=stage/'build-1';o.mkdir(exist_ok=True)
(stage/'source').symlink_to(W/'source',target_is_directory=True)
shutil.copyfile(W/'builds.json',stage/'builds.json');(o/'compiler.wasm').symlink_to(reference)
put(d/'identity.json',dict(native=sha(cc),wasm=sha(mod),fixed_point=sha(rpt),reference=sha(reference),size=reference.stat().st_size,base_reference=sha(W/'build-1/compiler.wasm'),candidate_source_patch=sha(B/'publication/call-guard.patch')))
