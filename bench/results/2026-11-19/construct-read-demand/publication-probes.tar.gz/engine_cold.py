from hashlib import sha256
import json
import os
from pathlib import Path
import resource
from statistics import median
import subprocess
import sys
import time

scratch = Path(__file__).resolve().parent
project = scratch.parents[2]
demand = scratch.parent
stage = project / "build/replay-nov19/own"
source = stage / "source"
host = project / "host/rust/target/release/goose-wasmtime"
manifest = json.loads((stage / "builds.json").read_text())
cpu = 6
os.sched_setaffinity(0, {cpu})
resource.setrlimit(resource.RLIMIT_STACK, (256 << 20, resource.getrlimit(resource.RLIMIT_STACK)[1]))
environment = {**os.environ, "RAYON_NUM_THREADS": "1"}
environment.pop("GOOSE_REGION_PROFILE", None)
environment.pop("GOOSE_REGION_STATS", None)
parts = {
    "base": (demand / "release/fixed.wasm", scratch / "trial/base-b247393d8fbe3115.cwasm"),
    "guard": (scratch / "guarded.wasm", scratch / "trial/guard-b247393d8fbe3115.cwasm"),
}
source_fixture = manifest["source_commit"]
def identity(path):
    return dict(sha256=sha256(path.read_bytes()).hexdigest(), bytes=path.stat().st_size)
cases = {}
for label, (module, cache) in parts.items():
    cases[label] = {"module": identity(module), "compiled_cache": identity(cache)}
    assert cache.with_suffix(".cwasm.sha256").read_text().strip() == cases[label]["module"]["sha256"]
reference = identity(stage / "build-1/compiler.wasm")
version_args = ["--version"]
frozen_args = ["selfhost/main.goose", "--stdlib", "stdlib", "--target", "wasm-direct", "-O2",
               "--wasm-memory64", "--wasm-max-pages", "262144"]
timing_file = scratch / "engines-timing.json"
result_file = scratch / "engines-emitted.wasm"
cold_file = scratch / "engines-wasmtime.json"
report = {"host": identity(host), "cpu": cpu, "cpu_affinity": list(os.sched_getaffinity(0)),
          "rayon_num_threads": 1, "mode": "exact fixed memory32 bundled compilers, Cranelift speed",
          "frozen_source": source_fixture, "frozen_archive_sha256": manifest["source_archive_sha256"],
          "reference": reference, "arguments": {"cold": version_args, "cached": frozen_args},
          "cases": cases, "measurements": {"cold": [], "cached": []}}

def record(group, sample):
    report["measurements"][group].append(sample)
    cold_file.write_text(json.dumps(report, indent=2) + "\n")

def run(group, round_id, label):
    timing_file.unlink(missing_ok=True)
    result_file.unlink(missing_ok=True)
    module, cache = parts[label]
    args = [host, module, "--timing-json", timing_file]
    if group == "cold":
        args.extend(["--no-cache", "--", *version_args])
    else:
        args.extend(["--cache", cache, "--", *frozen_args, "-o", result_file])
    begin = time.perf_counter_ns()
    before = resource.getrusage(resource.RUSAGE_CHILDREN)
    proc = subprocess.run(args, cwd=source, capture_output=True, env=environment, timeout=90)
    elapsed = time.perf_counter_ns() - begin
    after = resource.getrusage(resource.RUSAGE_CHILDREN)
    assert proc.returncode == 0 and not proc.stderr, (label, proc.returncode, proc.stderr)
    timing = json.loads(timing_file.read_text())
    cpu_s = after.ru_utime + after.ru_stime - before.ru_utime - before.ru_stime
    sample = {"round": round_id, "case": label, "wall_ns": elapsed, "cpu_s": cpu_s, **timing}
    if group == "cold":
        assert proc.stdout == b"Goose to Wasm (Goose implementation)\n", proc.stdout
        sample["stdout_sha256"] = sha256(proc.stdout).hexdigest()
    else:
        assert not proc.stdout, proc.stdout
        sample["output"] = identity(result_file)
        assert sample["output"] == reference, (label, sample["output"], reference)
    record(group, sample)
    print(group, round_id, label, f"prepare={timing['compile_instantiate_ns'] / 1e9:.3f}s",
          f"guest={timing['start_function_ns'] / 1e9:.3f}s", f"cpu={cpu_s:.3f}s",
          f"wall={elapsed / 1e9:.3f}s", flush=True)

groups = ("cold", "cached")
rounds = range(1, 5)
if "--extend-cold" in sys.argv:
    previous = json.loads(cold_file.read_text())
    assert all(previous[k] == report[k] for k in ("host", "cpu", "cases", "arguments", "reference"))
    assert len(previous["measurements"]["cold"]) == 8
    report = previous
    groups = ("cold",)
    rounds = range(5, 7)
for group in groups:
    for round_id in rounds:
        order = ("base", "guard") if round_id % 2 else ("guard", "base")
        for label in order:
            run(group, round_id, label)
    report.setdefault("median", {})[group] = {
        label: {key: median(s[key] for s in report["measurements"][group] if s["case"] == label)
                for key in ("compile_instantiate_ns", "start_function_ns", "wall_ns", "cpu_s")}
        for label in parts
    }
    cold_file.write_text(json.dumps(report, indent=2) + "\n")
