from common import *
from statistics import median
d=B/'publication/full';out=d/'cold-output.wasm';clock=d/'cold-clock.json'
mods={ 'base':B/'release/fixed.wasm','guard':d/'compiler.wasm'}
refs={'base':sha(W/'build-1/compiler.wasm'),'guard':j(d/'identity.json')['reference']}
os.sched_setaffinity(0,{6});env={**os.environ,'RAYON_NUM_THREADS':'1'}
report=dict(cpu=6,threads=1,source=j(W/'builds.json')['source_commit'],archive=j(W/'builds.json')['source_archive_sha256'],host=sha(H),modules={k:sha(v) for k,v in mods.items()},expected=refs,samples=[])
for i in range(6):
 order=list(mods)
 if i%2:order.reverse()
 for k in order:
  out.unlink(missing_ok=True);clock.unlink(missing_ok=True)
  start=time.monotonic_ns();before=resource.getrusage(resource.RUSAGE_CHILDREN)
  p=subprocess.run([H,mods[k],'--no-cache','--timing-json',clock,'--',*A,*wide,'-o',out],env=env,cwd=W/'source',capture_output=True,check=True)
  elapsed=time.monotonic_ns()-start;after=resource.getrusage(resource.RUSAGE_CHILDREN);assert not p.stdout and not p.stderr and sha(out)==refs[k]
  report['samples'].append(dict(round=i+1,case=k,wall_ns=elapsed,cpu_s=after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime,output_sha256=refs[k],output_bytes=out.stat().st_size,engine=j(clock)))
  put(d/'cold.json',report);print(i+1,k,round(elapsed/1e9,2),flush=True)
