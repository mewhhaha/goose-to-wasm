from common import *
os.sched_setaffinity(0,{1});d=B/'publication/helper-entry';src=d/'source';shutil.copytree(B/'release/source',src,dirs_exist_ok=True)
f=src/'selfhost/codegen.goose';s=f.read_text();a=s.index('fn cg_header_publish_body(');p=s.index('    wb_byte(out, 0x02);',a)
s2=s[:p]+'''    wb_op(out, 0x23, 11); wa_op(out, 0x45); wb_byte(out, 0x04); wb_byte(out, 0x40);
    wb_byte(out, 0x0f); wb_byte(out, 0x0b);
'''+s[p:];f.write_text(s2)
(d/'change.patch').write_text(''.join(difflib.unified_diff(s.splitlines(True),s2.splitlines(True),'a/selfhost/codegen.goose','b/selfhost/codegen.goose')))
flags=[*A,*fixed[:-1],B/'release/training.profile'];em=d/'emitter.wasm';m=d/'compiler.wasm'
subprocess.run([B/'own/build-1/compiler-native',*flags,'-o',em],cwd=src,check=True)
subprocess.run([H,em,'--cache',d/'emitter.cwasm','--',*flags,'-o',m],cwd=B/'release/source',check=True)
subprocess.run([R/'.venv/bin/python',R/'bench/results/2026-11-18/compiler-frame-cost/measure.py',W,d/'pairs','base='+str(B/'release/fixed.wasm'),'early='+str(m),'--rounds','4','--cpu','1'],check=True)
