"""Count completed forwarding stores in both emitters' positive witness."""

import json
import os

from count_publications import HERE, NAMES, STORES, create_hosted_config, identity, instrument, run_module


def main():
    os.sched_setaffinity(0, {5})
    work = HERE / 'live'
    report = {}
    for width in (32, 64):
        for label in ('base', 'guard'):
            case = f'{width}-{label}'
            original = work / f'grow_tail-{case}.wasm'
            original_bytes = original.read_bytes()
            data = instrument(original_bytes, target=None, wide=width == 64, count_stores=True)
            module = original.with_name(original.stem + '-stores.wasm')
            module.write_bytes(data)
            counters = {}

            def invoke(store, exports):
                try:
                    exports['_start'](store)
                finally:
                    names = zip(('empty', 'live', 'stores'), NAMES + (STORES,))
                    counters.update({key: exports[name].value(store) for key, name in names})

            result = run_module(data, b'', arguments=[str(module)], config=create_hosted_config(), invoke_start=invoke)
            assert result['exit_code'] == 0 and result['stdout'] == b'129 129 8127\n' and not result['stderr'], result
            assert counters['stores'] > 0, counters
            report[case] = {'original': identity(original_bytes), 'probe': identity(data), 'counters': counters,
                            'stdout': result['stdout'].decode(), 'stderr': result['stderr'], 'exit': result['exit_code']}
            print(case, counters, flush=True)
        assert report[f'{width}-base']['counters']['stores'] == report[f'{width}-guard']['counters']['stores']
    (work / 'stores.json').write_text(json.dumps(report, indent=2) + '\n')


if __name__ == '__main__':
    main()
