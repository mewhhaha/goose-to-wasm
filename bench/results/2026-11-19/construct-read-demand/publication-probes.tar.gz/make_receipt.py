"""Combine the publication counters, paired performance and live fixtures."""

import json
from pathlib import Path
from statistics import median

HERE = Path(__file__).resolve().parent


def read(path):
    return json.loads((HERE / path).read_bytes())


def performance(path, expected):
    raw = read(path)
    assert raw['expected'] == expected
    samples = raw['samples']
    assert len(samples) == 8 and all(sample['output'] == expected for sample in samples)
    pairs = [{row['case']: row for row in samples if row['round'] == index} for index in range(1, 5)]
    metrics = {'wall_seconds': lambda row: row['wall_ns'] / 1e9,
               'cpu_seconds': lambda row: row['cpu_s'],
               'instructions': lambda row: row['counters']['instructions']['value']}
    summary = {}
    for name, extract in metrics.items():
        base = [extract(pair['base']) for pair in pairs]
        guard = [extract(pair['guard']) for pair in pairs]
        summary[name] = {'base': median(base), 'guard': median(guard),
                         'paired_change_percent': median((b / a - 1) * 100 for a, b in zip(base, guard)),
                         'guard_wins': sum(b < a for a, b in zip(base, guard))}
    return {'summary': summary, 'raw': raw}


def main():
    counts = read('counts.json')
    build = read('guard-build.json')
    initial = performance('trial/paired.json', counts['observations']['emit']['output'])
    reversed_ = performance('trial-reverse/paired.json', counts['observations']['emit']['output'])
    assert initial['raw']['cases'] == reversed_['raw']['cases']
    cases = initial['raw']['cases']
    assert build['stage2']['output'] == cases['guard']['compiler']
    live = read('live/observations.json')
    for width in (32, 64):
        commands = live['cases']['grow_tail']['runs']
        assert commands[f'{width}-base']['probe']['counts'] == {'empty': 4, 'live': 3}
        assert commands[f'{width}-guard']['probe']['counts'] == {'empty': 0, 'live': 3}
    live['cpu_affinity_note'] = 'Correctness process started on CPU 6 and moved to CPU 5 during the early fixtures. All measured compiler pairs ran on CPU 5.'
    live['completed_forwarding_stores'] = read('live/stores.json')
    assert all(sample['counters']['stores'] == 2 for sample in live['completed_forwarding_stores'].values())
    size = {kind: {case: cases[case][kind]['bytes'] for case in ('base', 'guard')} for kind in ('compiler', 'cache')}
    for sizes in size.values():
        sizes['increase_bytes'] = sizes['guard'] - sizes['base']
        sizes['increase_percent'] = (sizes['guard'] / sizes['base'] - 1) * 100
    result = {'compiler_sizes': size, 'diagnostic_counts': counts, 'guard_build': build,
              'performance': {'base_first': initial, 'guard_first': reversed_}, 'live_path_coverage': live}
    (HERE / 'receipt.json').write_text(json.dumps(result, indent=2) + '\n')
    print(len(live['cases']), 'fixture groups', sum(len(case['runs']) for case in live['cases'].values()), 'emitted controls')


if __name__ == '__main__':
    main()
