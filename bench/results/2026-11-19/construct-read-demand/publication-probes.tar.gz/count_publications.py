"""Count heads at entry to the final compiler's array publication helper."""

import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
from importlib.metadata import version
import json
import os
from pathlib import Path
import sys
import threading

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2]
STAGE = HERE.parent
WORKLOAD = REPO / 'build/replay-nov19/own'
NAMES = ('probe.publications.empty', 'probe.publications.live')
STORES = 'probe.publications.stores'
sys.path.insert(0, str(REPO / 'scripts'))
from run_wasmtime import HOSTED_STACK_BYTES, create_hosted_config, run_module


def read_leb(data, offset):
    value = 0
    shift = 0
    while True:
        byte = data[offset]
        offset += 1
        value |= (byte & 127) << shift
        if byte < 128:
            return value, offset
        shift += 7


def leb(value):
    result = bytearray()
    while value >= 128:
        result.append((value & 127) | 128)
        value >>= 7
    result.append(value)
    return bytes(result)


def chunk(data):
    return leb(len(data)) + data


def sections(data):
    assert data[:8] == b'\0asm\1\0\0\0'
    at = 8
    while at < len(data):
        kind = data[at]
        size, start = read_leb(data, at + 1)
        at = start + size
        yield kind, data[start:at]
    assert at == len(data)


def imports(data):
    count, at = read_leb(data, 0)
    for _ in range(count):
        for _ in range(2):
            size, at = read_leb(data, at)
            at += size
        assert data[at] == 0  # All imports are functions.
        _, at = read_leb(data, at + 1)
    assert at == len(data)
    return count


def increment(index):
    return b'\x23' + leb(index) + b'\x42\x01\x7c\x24' + leb(index)


def changed_code(data, target, first_global, wide=False, count_stores=False):
    count, at = read_leb(data, 0)
    output = bytearray(leb(count))
    if target is not None:
        assert 0 <= target < count
    value_type, eqz = (b'\x7e', b'\x50') if wide else (b'\x7f', b'\x45')
    prefix = b'\x01\x02' + value_type + bytes.fromhex('02 40 03 40 23 0b 21 02 03 40 20 02') + eqz + b'\x0d\x02'
    matches = []
    for function in range(count):
        size, at = read_leb(data, at)
        body = data[at:at + size]
        at += size
        if body.startswith(prefix):
            # Two address locals, then the outer block/loop and global 11.
            matches.append(function)
            counters = b'\x23\x0b' + eqz + b'\x04\x40' + increment(first_global) + b'\x05' + increment(first_global + 1) + b'\x0b'
            body = body[:3] + counters + body[3:]
            if count_stores:
                transfer = bytes.fromhex('29 03 00 37 03 00' if wide else '28 02 00 36 02 00')
                assert body.count(transfer) == 1
                body = body.replace(transfer, transfer + increment(first_global + 2))
        output += chunk(body)
    assert at == len(data)
    assert len(matches) == 1 and (target is None or target == matches[0]), (matches, target)
    return bytes(output)


def instrument(data, target=1585, wide=False, count_stores=False):
    before = list(sections(data))
    contents = dict(before)
    first_global, start = read_leb(contents[6], 0)
    assert first_global == 12
    names = NAMES + (STORES,) if count_stores else NAMES
    globals_ = leb(first_global + len(names)) + contents[6][start:] + b'\x7e\x01\x42\x00\x0b' * len(names)
    exported, start = read_leb(contents[7], 0)
    exports = leb(exported + len(names)) + contents[7][start:]
    for index, name in enumerate(names, first_global):
        exports += chunk(name.encode()) + b'\x03' + leb(index)
    imported = imports(contents[2])
    if target is not None:
        target -= imported
    updated = {6: globals_, 7: exports, 10: changed_code(contents[10], target, first_global, wide, count_stores)}
    return data[:8] + b''.join(bytes([kind]) + chunk(updated.get(kind, section)) for kind, section in before)


def identity(data):
    return {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cpu', type=int, default=5)
    args = parser.parse_args()
    os.sched_setaffinity(0, {args.cpu})
    profile = json.loads((STAGE / 'profile.json').read_bytes())
    frozen = json.loads((WORKLOAD / 'builds.json').read_bytes())
    assert profile['workload'] == frozen['source_commit']
    assert profile['workload_archive_sha256'] == frozen['source_archive_sha256']
    base = (STAGE / 'release/fixed.wasm').read_bytes()
    assert identity(base) == profile['wasm']
    new = instrument(base)
    module = HERE / 'probe.wasm'
    module.write_bytes(new)
    os.chdir(WORKLOAD / 'source')
    common = [str(module), 'selfhost/main.goose', '--stdlib', 'stdlib']
    output = HERE / 'frozen-output.wasm'
    expected = profile['expected_emission']
    modes = {'check': [*common, '--check'],
             'emit': [*common, '--target', 'wasm-direct', '-O2', '--wasm-memory64', '--wasm-max-pages', '262144', '-o', str(output)]}
    result = {'compiler': profile['compiler'], 'workload': profile['workload'], 'workload_archive_sha256': profile['workload_archive_sha256'],
              'base': identity(base), 'probe': identity(new), 'cpu': args.cpu, 'wasmtime': version('wasmtime'),
              'instrumented_function': 1585, 'observations': {}}
    threading.stack_size(HOSTED_STACK_BYTES + (64 << 20))
    with ThreadPoolExecutor(1) as worker:
        for mode, command in modes.items():
            counts = {}

            def invoke_start(store, exports):
                try:
                    exports['_start'](store)
                finally:
                    counts.update({kind: exports[name].value(store) for kind, name in zip(('empty', 'live'), NAMES)})

            observed = worker.submit(run_module, new, b'', arguments=command, config=create_hosted_config(),
                                     cache=HERE / 'probe.cwasm', invoke_start=invoke_start).result()
            assert not observed['exit_code'] and not observed['stdout'] and not observed['stderr'], observed
            observation = {'command': command, 'counts': counts, 'status': observed['exit_code']}
            if mode == 'emit':
                observation['output'] = identity(output.read_bytes())
                assert observation['output'] == expected, (observation['output'], expected)
            result['observations'][mode] = observation
            print(mode, counts, flush=True)
            (HERE / 'counts.json').write_text(json.dumps(result, indent=2) + '\n')


if __name__ == '__main__':
    main()
