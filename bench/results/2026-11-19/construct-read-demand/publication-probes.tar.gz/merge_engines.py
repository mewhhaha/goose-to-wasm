from hashlib import sha256
import json
from pathlib import Path
from statistics import median
import subprocess
import sys

scratch = Path(__file__).resolve().parent
project = scratch.parents[2]
stage = project / "build/replay-nov19/own"
sys.path[:0] = [str(project / "bench"), str(project / "scripts")]
from selfhost_comparison import verify_frozen_source

manifest = json.loads((stage / "builds.json").read_text())
verify_frozen_source(stage / "source", manifest["source_commit"], manifest["source_archive_sha256"])

def read(name):
    path = scratch / name
    return json.loads(path.read_text()) if path.exists() else None

def compare(samples, metric):
    paired = {}
    for row in samples:
        paired.setdefault(row["round"], {})[row["case"]] = metric(row)
    complete = [values for values in paired.values() if len(values) == 2]
    changes = [100 * (values["guard"] / values["base"] - 1) for values in complete]
    return {
        "pairs": len(complete),
        "base_median": median(values["base"] for values in complete),
        "guard_median": median(values["guard"] for values in complete),
        "median_paired_change_pct": median(changes),
        "guard_faster": sum(change < 0 for change in changes),
        "paired_changes_pct": changes,
    }

parts = {"base": scratch.parent / "release/fixed.wasm", "guard": scratch / "guarded.wasm"}
wasmtime = read("engines-wasmtime.json")
for label, module in parts.items():
    assert sha256(module.read_bytes()).hexdigest() == wasmtime["cases"][label]["module"]["sha256"]
cold = wasmtime["measurements"]["cold"]
cached = wasmtime["measurements"]["cached"]
summary = {
    "wasmtime_cold": {
        "prepare_wall_s": compare(cold, lambda row: row["compile_instantiate_ns"] / 1e9),
        "process_cpu_s": compare(cold, lambda row: row["cpu_s"]),
    },
}
if len(cached) >= 2:
    assert all(row["output"] == wasmtime["reference"] for row in cached)
    summary["wasmtime_cached"] = {
        "guest_wall_s": compare(cached, lambda row: row["start_function_ns"] / 1e9),
        "process_cpu_s": compare(cached, lambda row: row["cpu_s"]),
        "process_wall_s": compare(cached, lambda row: row["wall_ns"] / 1e9),
    }
v8 = read("engines-v8.json")
if v8 is not None:
    for mode in ("check", "emit"):
        rows = [row for row in v8["runs"] if row["mode"] == mode and not row["exitCode"]]
        if len(rows) >= 2:
            if mode == "emit":
                assert all(row["output"] == v8["reference"] for row in rows)
            summary[f"v8_resident_{mode}"] = compare(rows, lambda row: row["timing"]["start_function_ns"] / 1e9)
summary["module_size"] = {label: values["module"]["bytes"] for label, values in wasmtime["cases"].items()}
summary["compiled_cache_size"] = {label: values["compiled_cache"]["bytes"] for label, values in wasmtime["cases"].items()}
report = {
    "summary": summary,
    "notes": [
        "Wasmtime uses one allowed logical CPU and RAYON_NUM_THREADS=1. The first cold sample overlapped an existing project process pinned to the same logical CPU. Subsequent runs kept project-managed work off this logical CPU. External host activity continued.",
        "Cold engine timer includes instantiation. A --version invocation contributes less than 1 ms of guest time. Cached measurements are separate fresh processes using the already serialized modules.",
        "Resident V8 uses two long-lived workers and fresh instances for individual compiler invocations. It ran on a separate logical CPU, so engine comparisons are within-engine.",
        "Both runtime compiler modules use the same code generator semantics. The guard affects the runtime module produced by the patched emitter. Timed full outputs are checked against the common frozen native output.",
    ],
    "cpu_model": next(row.split(":", 1)[1].strip() for row in Path("/proc/cpuinfo").read_text().splitlines()
                      if row.startswith("model name")),
    "wasmtime": wasmtime,
    "v8": v8,
}
(scratch / "engines.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(summary, indent=2))
