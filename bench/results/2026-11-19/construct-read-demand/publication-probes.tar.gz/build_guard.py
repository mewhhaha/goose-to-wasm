"""Emit the unmodified final sources with a scratch publication call guard."""

from difflib import unified_diff
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import subprocess

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2]
STAGE = HERE.parent
RELEASE = STAGE / 'release'
HOST = REPO / 'host/rust/target/release/goose-wasmtime'
NATIVE = STAGE / 'own/build-1/compiler-native'
FLAGS = ['selfhost/main.goose', '--stdlib', 'stdlib', '--target', 'wasm-direct', '-O2',
         '--wasm-bundled-host', '--wasm-initial-pages', '65535', '--wasm-max-pages', '65535',
         '--wasm-region-profile', RELEASE / 'training.profile']


def identity(path):
    data = path.read_bytes()
    return {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}


def compile_(command, cwd):
    subprocess.run(command, cwd=cwd, check=True, timeout=300)
    return {'command': list(map(str, command)), 'cwd': str(cwd)}


def main():
    os.sched_setaffinity(0, {5})
    resource.setrlimit(resource.RLIMIT_STACK, (256 << 20, resource.getrlimit(resource.RLIMIT_STACK)[1]))
    source = HERE / 'emitter-source'
    shutil.copytree(RELEASE / 'source', source, dirs_exist_ok=True)
    edited = source / 'selfhost/codegen.goose'
    old = edited.read_text()
    needle = '    if m.header_helper >= 0 { cg_get(f, header); wa_const(f.code, wB_control_offset(word)); wb_op(f.code, 0x10, m.header_helper); }'
    assert old.count(needle) == 1
    new = old.replace(needle, '''    if m.header_helper < 0 { return; }
    wb_op(f.code, 0x23, 11); wa_truth(f.code); cg_begin(f, 0x04, 0x40);
    cg_get(f, header); wa_const(f.code, wB_control_offset(word)); wb_op(f.code, 0x10, m.header_helper);
    cg_end(f);''')
    edited.write_text(new)
    patch = HERE / 'call-guard.patch'
    patch.write_text(''.join(unified_diff(old.splitlines(keepends=True), new.splitlines(keepends=True), 'a/selfhost/codegen.goose', 'b/selfhost/codegen.goose')))
    emitter = HERE / 'emitter.wasm'
    guarded = HERE / 'guarded.wasm'
    stage1 = compile_([NATIVE, *FLAGS, '-o', emitter], source)
    stage2 = compile_([HOST, emitter, '--cache', HERE / 'emitter.cwasm', '--', *FLAGS, '-o', guarded], RELEASE / 'source')
    payload = {'patch': identity(patch), 'native': identity(NATIVE), 'host': identity(HOST),
               'stage1': {**stage1, 'output': identity(emitter)}, 'stage2': {**stage2, 'output': identity(guarded)}}
    (HERE / 'guard-build.json').write_text(json.dumps(payload, indent=2) + '\n')
    print('guarded runtime compiler', payload['stage2']['output'], flush=True)


if __name__ == '__main__':
    main()
