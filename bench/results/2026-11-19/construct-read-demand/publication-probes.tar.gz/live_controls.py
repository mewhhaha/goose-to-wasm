"""Compare existing and guarded emitters on return/construction contracts."""

import argparse
import json
import os
from pathlib import Path
import resource
import subprocess

from count_publications import HERE, REPO, STAGE, NAMES, identity, instrument, create_hosted_config, run_module

HOST = REPO / 'host/rust/target/release/goose-wasmtime'
UPSTREAM = REPO / 'build/langbench-native/goose'
UPSTREAM_STDLIB = REPO / 'build/langbench-goose-source/stdlib'
UPSTREAM_RECEIPT = REPO / 'bench/results/2026-11-19/expression-lifetimes/upstream-controls.json'
STDLIB = STAGE / 'release/source/stdlib'
FIXTURES = REPO / 'tests/fixtures'
ORACLE = FIXTURES / 'encoded_record_tail_oracles.json'
CONTROLS = ('grow_tail', 'channels', 'nested', 'values', 'aliases')
BASE = [STAGE / 'own/build-1/compiler-native']
GUARD = [HOST, HERE / 'emitter.wasm', '--cache', HERE / 'emitter.cwasm', '--']


def run(command, work):
    result = subprocess.run(command, cwd=work, env={**os.environ, 'GOOSE_HOME': str(work / 'home')},
                            text=True, capture_output=True, timeout=180)
    return {'command': list(map(str, command)), 'stdout': result.stdout, 'stderr': result.stderr, 'status': result.returncode}


def probe(module, width):
    counts = {}
    data = instrument(module.read_bytes(), target=None, wide=width == 64)
    module.with_name(module.stem + '-probe.wasm').write_bytes(data)

    def entry(store, exports):
        try:
            exports['_start'](store)
        finally:
            counts.update({kind: exports[name].value(store) for kind, name in zip(('empty', 'live'), NAMES)})

    result = run_module(data, b'', arguments=[str(module)], config=create_hosted_config(), invoke_start=entry)
    return {'counts': counts, 'module': identity(data), 'stdout': result['stdout'].decode(),
            'stderr': result['stderr'], 'status': result['exit_code']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cpu', type=int, default=5)
    args = parser.parse_args()
    os.sched_setaffinity(0, {args.cpu})
    resource.setrlimit(resource.RLIMIT_STACK, (256 << 20, resource.getrlimit(resource.RLIMIT_STACK)[1]))
    work = HERE / 'live'
    work.mkdir(exist_ok=True)
    (work / 'home').mkdir(exist_ok=True)
    receipt = json.loads(UPSTREAM_RECEIPT.read_bytes())
    upstream_binary = identity(UPSTREAM.read_bytes())
    assert upstream_binary['sha256'] == receipt['upstream_binary']
    expected = json.loads(ORACLE.read_bytes())
    report = {'cpu': args.cpu, 'native': identity(BASE[0].read_bytes()), 'guard_emitter': identity(GUARD[1].read_bytes()),
              'upstream_revision': receipt['upstream'], 'upstream': upstream_binary, 'oracle': identity(ORACLE.read_bytes()),
              'cases': {}}
    for name in CONTROLS:
        case = FIXTURES / f'encoded_record_tail_{name}.goose'
        upstream = run([UPSTREAM, 'run', case, '--stdlib', UPSTREAM_STDLIB], work)
        assert upstream['status'] == expected[name]['exit_code'] and upstream['stdout'] == expected[name]['stdout'], upstream
        report['cases'][name] = {'source': identity(case.read_bytes()), 'expected': expected[name], 'upstream': upstream, 'runs': {}}
        for width in (32, 64):
            flags = [] if width == 32 else ['--wasm-memory64', '--wasm-max-pages', '262144']
            counts = {}
            for label, compiler in (('base', BASE), ('guard', GUARD)):
                module = work / f'{name}-{width}-{label}.wasm'
                compile_ = run([*compiler, case, '--stdlib', STDLIB, '--target', 'wasm-direct', '-O2', *flags, '-o', module], work)
                assert not compile_['status'] and not compile_['stdout'] and not compile_['stderr'], compile_
                execution = run([HOST, module, '--no-cache'], work)
                observed = probe(module, width)
                for result in (execution, observed):
                    assert result['status'] == expected[name]['exit_code'] and result['stdout'] == expected[name]['stdout'] and result['stderr'] == expected[name]['diagnostic'], result
                counts[label] = observed['counts']
                report['cases'][name]['runs'][f'{width}-{label}'] = {'compile': compile_, 'artifact': identity(module.read_bytes()), 'execute': execution, 'probe': observed}
            assert counts['base']['live'] == counts['guard']['live'] and counts['guard']['empty'] == 0, counts
            print(name, width, counts, flush=True)
        (work / 'observations.json').write_text(json.dumps(report, indent=2) + '\n')
    assert any(all(item['runs'][f'{width}-base']['probe']['counts']['live'] > 0 for width in (32, 64)) for item in report['cases'].values())


if __name__ == '__main__':
    main()
