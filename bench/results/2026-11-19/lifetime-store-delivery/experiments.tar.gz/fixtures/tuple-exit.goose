fn views(a: i64[:], b: i64[:]) -> i64[:], i64[:] { return a, b; }
fn choose(a: i64[:], b: i64[:], swap: bool) -> i64[:], i64[:] {
    block { break views(a, b); };
    if swap { return b, a; }
    return a, b;
}
fn main() {
    var left: i64[2] = [2, 3];
    var right: i64[2] = [5, 7];
    let a, b = choose(left[..], right[..], true);
    print(a[0], " ", b[0]);
}
