fn ping_0() {}
fn ping_1() {}
fn ping_2() {}
fn ping_3() {}
fn ping_4() {}
fn ping_5() {}
fn ping_6() {}
fn ping_7() {}
fn ping_8() {}
fn ping_9() {}
fn ping_10() {}
fn ping_11() {}
fn ping_12() {}
fn ping_13() {}
fn ping_14() {}
fn ping_15() {}
fn ping_16() {}
fn ping_17() {}
fn ping_18() {}
fn ping_19() {}
fn ping_20() {}
fn ping_21() {}
fn ping_22() {}
fn ping_23() {}
fn ping_24() {}
fn ping_25() {}
fn ping_26() {}
fn ping_27() {}
fn ping_28() {}
fn ping_29() {}
fn ping_30() {}
fn ping_31() {}
fn ping_32() {}
fn ping_33() {}
fn ping_34() {}
fn ping_35() {}
fn ping_36() {}
fn ping_37() {}
fn ping_38() {}
fn ping_39() {}
fn ping_40() {}
fn ping_41() {}
fn ping_42() {}
fn ping_43() {}
fn ping_44() {}
fn ping_45() {}
fn ping_46() {}
fn ping_47() {}
fn ping_48() {}
fn ping_49() {}
fn ping_50() {}
fn ping_51() {}
fn ping_52() {}
fn ping_53() {}
fn ping_54() {}
fn ping_55() {}
fn ping_56() {}
fn ping_57() {}
fn ping_58() {}
fn ping_59() {}
fn ping_60() {}
fn ping_61() {}
fn ping_62() {}
fn ping_63() {}
fn ping_64() {}
fn ping_65() {}
fn ping_66() {}
fn ping_67() {}
fn ping_68() {}
fn ping_69() {}
fn ping_70() {}
fn ping_71() {}
fn ping_72() {}
fn ping_73() {}
fn ping_74() {}
fn ping_75() {}
fn ping_76() {}
fn ping_77() {}
fn ping_78() {}
fn ping_79() {}
struct Cell { v: i64, next: Cell&? }
var p0: Cell[>..] = [Cell { v: 0, next: null }];
var p1: Cell[>..] = [Cell { v: 1, next: null }];
var p2: Cell[>..] = [Cell { v: 2, next: null }];
fn keep(a: Cell&, x: Cell&) { a.next .= x; }
recursive fn f0(n:i64, a:Cell&, b:Cell&) -> Cell& {
    if n <= 0 { return p2[0]; }
    let x0:Cell& = f1(n - 1, a, a);
    let x1:Cell& = f1(n - 1, p0[0], p2[0]);
    let x2:Cell& = f1(n - 1, p0[0], p0[0]);
    return x2;
}
recursive fn f1(n:i64, a:Cell&, b:Cell&) -> Cell& {
    if n <= 0 { return b; }
    let x0:Cell& = f0(n - 1, p2[0], p0[0]);
    let x1:Cell& = f0(n - 1, p0[0], a);
    keep(a, x1);
    return p1[0];
}
fn main() {
    ping_0(); ping_1(); ping_2(); ping_3(); ping_4(); ping_5(); ping_6(); ping_7(); ping_8(); ping_9(); ping_10(); ping_11(); ping_12(); ping_13(); ping_14(); ping_15(); ping_16(); ping_17(); ping_18(); ping_19(); ping_20(); ping_21(); ping_22(); ping_23(); ping_24(); ping_25(); ping_26(); ping_27(); ping_28(); ping_29(); ping_30(); ping_31(); ping_32(); ping_33(); ping_34(); ping_35(); ping_36(); ping_37(); ping_38(); ping_39(); ping_40(); ping_41(); ping_42(); ping_43(); ping_44(); ping_45(); ping_46(); ping_47(); ping_48(); ping_49(); ping_50(); ping_51(); ping_52(); ping_53(); ping_54(); ping_55(); ping_56(); ping_57(); ping_58(); ping_59(); ping_60(); ping_61(); ping_62(); ping_63(); ping_64(); ping_65(); ping_66(); ping_67(); ping_68(); ping_69(); ping_70(); ping_71(); ping_72(); ping_73(); ping_74(); ping_75(); ping_76(); ping_77(); ping_78(); ping_79(); 
}
