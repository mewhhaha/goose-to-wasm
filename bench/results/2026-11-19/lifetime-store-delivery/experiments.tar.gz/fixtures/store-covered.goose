fn ping_0() {}
fn ping_1() {}
fn ping_2() {}
fn ping_3() {}
fn ping_4() {}
fn ping_5() {}
fn ping_6() {}
fn ping_7() {}
fn ping_8() {}
fn ping_9() {}
fn ping_10() {}
fn ping_11() {}
fn ping_12() {}
fn ping_13() {}
fn ping_14() {}
fn ping_15() {}
fn ping_16() {}
fn ping_17() {}
fn ping_18() {}
fn ping_19() {}
fn ping_20() {}
fn ping_21() {}
fn ping_22() {}
fn ping_23() {}
fn ping_24() {}
fn ping_25() {}
fn ping_26() {}
fn ping_27() {}
fn ping_28() {}
fn ping_29() {}
fn ping_30() {}
fn ping_31() {}
fn ping_32() {}
fn ping_33() {}
fn ping_34() {}
fn ping_35() {}
fn ping_36() {}
fn ping_37() {}
fn ping_38() {}
fn ping_39() {}
fn ping_40() {}
fn ping_41() {}
fn ping_42() {}
fn ping_43() {}
fn ping_44() {}
fn ping_45() {}
struct Cell { v: i64, next: Cell&? }
var p0: Cell[>..] = [Cell { v: 0, next: null }];
var p1: Cell[>..] = [Cell { v: 1, next: null }];
var p2: Cell[>..] = [Cell { v: 2, next: null }];
fn keep(a: Cell&, x: Cell&) { a.next .= x; }
recursive fn f0(n:i64, a:Cell&, b:Cell&) -> Cell& {
    if n <= 0 { return p0[0]; }
    let x0:Cell& = f1(n - 1, b, a);
    return x0;
}
recursive fn f1(n:i64, a:Cell&, b:Cell&) -> Cell& {
    if n <= 0 { return p0[0]; }
    let x0:Cell& = f0(n - 1, a, p2[0]);
    keep(p0[0], x0);
    let x1:Cell& = f0(n - 1, p2[0], p1[0]);
    keep(p2[0], x1);
    let x2:Cell& = f0(n - 1, p1[0], p2[0]);
    keep(b, x2);
    return p1[0];
}
fn main() {
    ping_0(); ping_1(); ping_2(); ping_3(); ping_4(); ping_5(); ping_6(); ping_7(); ping_8(); ping_9(); ping_10(); ping_11(); ping_12(); ping_13(); ping_14(); ping_15(); ping_16(); ping_17(); ping_18(); ping_19(); ping_20(); ping_21(); ping_22(); ping_23(); ping_24(); ping_25(); ping_26(); ping_27(); ping_28(); ping_29(); ping_30(); ping_31(); ping_32(); ping_33(); ping_34(); ping_35(); ping_36(); ping_37(); ping_38(); ping_39(); ping_40(); ping_41(); ping_42(); ping_43(); ping_44(); ping_45(); 
    print(f1(1, p2[0], p1[0]).v);
}
