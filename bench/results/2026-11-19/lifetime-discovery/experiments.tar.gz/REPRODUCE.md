# Reproduce the lifetime experiments

Start in the repository with its Rust host built. Set `EMITTER` to an absolute path to the native compiler at 7ff11b7. Its expected hash is in measurements.json.gz. Set `EXP` to the absolute directory where this archive was extracted. These examples use Bash and the repository's pinned Python environment.

```sh
repo=$(pwd)
trial=$(mktemp -d)
mkdir "$trial/compiler" "$trial/input"
git archive 7ff11b74a7c78c00f0213c7c01af86c1bb989454 selfhost stdlib native | tar -x -C "$trial/compiler"
git archive 34ddff8db385b1e357e3b5048d7a301ead975fc5 selfhost stdlib native | tar -x -C "$trial/input"
ulimit -s 262144
profile="$repo/bench/results/2026-11-19/bundled-publications/training.profile"
host="$repo/host/rust/target/release/goose-wasmtime"
build_guest() {
  (cd "$trial/compiler" && "$EMITTER" selfhost/main.goose --stdlib stdlib --target wasm-direct -O2 --wasm-bundled-host --wasm-initial-pages 65535 --wasm-max-pages 65535 --wasm-region-profile "$profile" -o "$1")
}
build_guest "$trial/control.wasm"
(cd "$trial/compiler" && patch -p1 < "$EXP/patches/edges.patch")
build_guest "$trial/edges.wasm"
(cd "$trial/input" && taskset -c 7 "$host" "$trial/edges.wasm" --cache "$trial/edges.cwasm" -- selfhost/main.goose --stdlib stdlib --target wasm-direct -O2 --wasm-memory64 --wasm-max-pages 262144 --check > "$trial/edges.txt")
```

For another candidate, start with a fresh compiler source directory. To reproduce an emission, prime the cache with `--version`, then replace `--check` in the final invocation with `-o "$trial/output.wasm" --wasm-stats "$trial/stats.json"`. The output SHA-256 is fe23695e4c38f1d83345c722949b51535da6a5d5b08c4c7131c26169223e9d25. A native candidate can be built with `scripts/goose_wasm.py build`, the same emitter and `--backend native --cc clang-23 --jobs 4 --no-cache -O2`. The measurements store the actual case order, round and per-child measurements. Use the existing compiler-frame-cost runner for additional timing series.

## Decode the counters

The edges probe prints one JSON list per line. Records of length six give phase (1 onward for discovery, -1 for validation), elapsed milliseconds, allocated frames, items, roots, and class frames. The next two records give operation and revision-site counts. In the operations record, columns 1 and 2 (zero-indexed) give evaluated bodies and syntax visits. Add the revision counts for changes per pass. Use the included sites.json to map counters to the unmodified checker. Timing comparisons in the report come from separate builds without operation probes.

Tag 98 gives pass, reachable items, total items and live hold count. Tag 99 records an existing effect growing, and tag 96 records a new summary. Their remaining columns are pass, owner frame, owner function, executing frame, executing function, effect kind, site and summary index. Tag 97 gives caller and callee in the fifth discovery pass, including repeat edges. To reproduce the 169-frame result, seed a set with the two pass-four summary owners and repeatedly add callers whose callees are in the set until it stops growing. This trace measures ordinary frame calls. The frozen project had zero class frames.

The map-frequency probe reports requests and hits for interior and named-component mappings respectively. The reuse-timer probe's fourth column gives the item arena length. In cap.patch the two-pass limit is deliberately incorrect. To check the two counterexamples, extract tests/conformance/upstream.tar.gz into a temporary directory, copy the repo stdlib into that directory as stdlib, and run the same source and --stdlib path through the control and capped compiler.

Regenerate the chart with `python chart.py DIRECTORY`, where DIRECTORY holds discovery.json. The archive also contains the fixtures used to exercise the ordinary 4,096-frame transition.
