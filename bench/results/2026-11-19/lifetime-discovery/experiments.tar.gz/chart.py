import sys,json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter,MaxNLocator
e=Path(sys.argv[1]); data=json.loads((e/'discovery.json').read_text())
rows=[p for p in data['passes'] if p['phase']!='validation']
plt.rcParams.update({'font.family':'DejaVu Sans','axes.spines.right':False,'axes.spines.top':False,'axes.spines.left':False,'axes.spines.bottom':False})
fig,axes=plt.subplots(1,2,figsize=(9,3.25),layout='constrained')
fig.suptitle('Lifetime discovery on a frozen compiler rebuild',fontsize=15,weight='bold')
for ax,(label,field,color) in zip(axes,[('Syntax nodes visited','node_visits','#287e87'),('Changes recorded','revisions','#935125')]):
    vals=[x[field] for x in rows]; inds=list(range(5)); cap=max(vals)
    ax.barh(inds,vals,color=color,height=.6); ax.set_yticks(inds,[f'Pass {i+1}' for i in inds]); ax.tick_params(axis='both',length=0,labelsize=9); ax.invert_yaxis()
    ax.xaxis.set_major_locator(MaxNLocator(4,integer=True));ax.xaxis.set_major_formatter(FuncFormatter(lambda v,_: f'{v/1000:g}k' if v>=1000 else str(int(v))))
    ax.grid(axis='x',alpha=.2);ax.set_axisbelow(True);ax.set_xlim(0,cap*1.37);ax.set_title(label,fontsize=12,loc='left',weight='bold')
    for i,v in enumerate(vals): ax.text(v+cap*.025,i,f'{v:,}',fontsize=9,va='center')
fig.savefig(e/'passes.png',dpi=160,bbox_inches='tight');plt.close(fig)
