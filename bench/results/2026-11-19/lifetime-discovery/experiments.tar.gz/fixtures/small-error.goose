fn standalone(xs: const i64[:], tag: i64&) -> i64 { xs.len + tag }
fn last(xs: i64[>..<]&) -> i64 {
    let view = xs[0..1];
    xs.pop();
    return view[0];
}
fn call_0() -> i64 { 0 }
fn call_1() -> i64 { 1 }
fn call_2() -> i64 { 2 }
fn call_3() -> i64 { 3 }
fn call_4() -> i64 { 4 }
fn call_5() -> i64 { 5 }
fn call_6() -> i64 { 6 }
fn call_7() -> i64 { 7 }
fn call_8() -> i64 { 8 }
fn call_9() -> i64 { 9 }
fn call_10() -> i64 { 10 }
fn call_11() -> i64 { 11 }
fn call_12() -> i64 { 12 }
fn call_13() -> i64 { 13 }
fn call_14() -> i64 { 14 }
fn call_15() -> i64 { 15 }
fn call_16() -> i64 { 16 }
fn call_17() -> i64 { 17 }
fn call_18() -> i64 { 18 }
fn call_19() -> i64 { 19 }
fn call_20() -> i64 { 20 }
fn call_21() -> i64 { 21 }
fn call_22() -> i64 { 22 }
fn call_23() -> i64 { 23 }
fn call_24() -> i64 { 24 }
fn call_25() -> i64 { 25 }
fn call_26() -> i64 { 26 }
fn call_27() -> i64 { 27 }
fn call_28() -> i64 { 28 }
fn call_29() -> i64 { 29 }
fn call_30() -> i64 { 30 }
fn call_31() -> i64 { 31 }
fn call_32() -> i64 { 32 }
fn call_33() -> i64 { 33 }
fn call_34() -> i64 { 34 }
fn call_35() -> i64 { 35 }
fn call_36() -> i64 { 36 }
fn call_37() -> i64 { 37 }
fn call_38() -> i64 { 38 }
fn call_39() -> i64 { 39 }
fn call_40() -> i64 { 40 }
fn call_41() -> i64 { 41 }
fn call_42() -> i64 { 42 }
fn call_43() -> i64 { 43 }
fn call_44() -> i64 { 44 }
fn call_45() -> i64 { 45 }
fn call_46() -> i64 { 46 }
fn call_47() -> i64 { 47 }
fn main() {
    call_0();
    call_1();
    call_2();
    call_3();
    call_4();
    call_5();
    call_6();
    call_7();
    call_8();
    call_9();
    call_10();
    call_11();
    call_12();
    call_13();
    call_14();
    call_15();
    call_16();
    call_17();
    call_18();
    call_19();
    call_20();
    call_21();
    call_22();
    call_23();
    call_24();
    call_25();
    call_26();
    call_27();
    call_28();
    call_29();
    call_30();
    call_31();
    call_32();
    call_33();
    call_34();
    call_35();
    call_36();
    call_37();
    call_38();
    call_39();
    call_40();
    call_41();
    call_42();
    call_43();
    call_44();
    call_45();
    call_46();
    call_47();
    var xs: i64[>..<] = [42, 7];
    print(last(xs));
}
