"""Restore hash-verified benchmark inputs and artifacts into a NEW directory."""
from pathlib import Path
import argparse,hashlib,json,tarfile
p=argparse.ArgumentParser(description=__doc__);p.add_argument('archive',type=Path);p.add_argument('destination',type=Path);a=p.parse_args();a.destination.mkdir(parents=True,exist_ok=False)
with tarfile.open(a.archive) as t:
 manifest=json.load(t.extractfile('capsule-manifest.json'));cache={}
 for name,item in manifest['files'].items():
  path=Path(name)
  if path.is_absolute() or '..' in path.parts:raise ValueError(name)
  digest=item['sha256']
  if digest not in cache:
   data=t.extractfile('objects/'+digest).read()
   if hashlib.sha256(data).hexdigest()!=digest:raise ValueError(digest)
   cache[digest]=data
  target=a.destination/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(cache[digest]);target.chmod(item['mode'])
print('Restored',len(manifest['files']),'files from',len(cache),'verified objects')
