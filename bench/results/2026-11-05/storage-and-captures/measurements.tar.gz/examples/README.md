# Example program benchmarks

Status: **passed**.

2026-11-05 · AMD Ryzen 7 3800X 8-Core Processor.

Goose O2. Direct Wasm uses memory32; Native C is emitted by the Goose compiler. The selected programs, their constant inputs and all printing are unchanged from the [example catalog](../../../../examples/README.md). Compiler constant folding is allowed.

Builds are complete uncached Python-driver invocations, including any C compilation/linking. OS page caches remain warm.

Runtime is **whole-process launch-to-exit time**, including host startup, Wasm compilation/instantiation, program initialization, computation, output delivery and teardown. Each observation starts a fresh process/instance and calls the entrypoint once. This measures CLI cost, not warmed kernel throughput.

Each cell has 5 build samples or 5 runtime samples. Untimed fresh-process warmups per runtime cell: 1. Orders are shuffled with the recorded seed; builds and runtime never overlap. Every used artifact must pass its golden output. Values are median milliseconds ± median absolute deviation (MAD).

Headline runtime samples use the ordinary runners without timing-file instrumentation. The Wasm supplements use a separate shuffled set of fresh processes, with the same sample count; timing files are written after their engine intervals end.

## Compilation

| Example | Direct Wasm | Goose Native C |
| --- | ---: | ---: |
| squares | 54.197 ±2.141 | 263.805 ±5.012 |
| tour | 70.840 ±1.501 | 998.440 ±24.868 |
| functions | 150.013 ±7.443 | 1756.736 ±62.969 |
| errors | 88.516 ±1.625 | 843.288 ±6.453 |
| sieve | 84.762 ±7.555 | 420.020 ±6.315 |
| sorting | 144.301 ±7.031 | 2011.935 ±32.865 |
| sudoku | 78.710 ±3.400 | 527.489 ±38.430 |
| maze | 107.492 ±17.826 | 808.265 ±55.295 |
| vm | 86.345 ±2.113 | 744.170 ±49.261 |
| life | 81.101 ±2.656 | 576.075 ±23.235 |

## Whole-process runtime

| Example | Direct / V8 | Direct / Wasmtime | Goose Native C |
| --- | ---: | ---: | ---: |
| squares | 28.099 ±0.085 | 73.467 ±1.742 | 0.847 ±0.018 |
| tour | 58.621 ±1.022 | 134.872 ±3.770 | 0.976 ±0.118 |
| functions | 64.921 ±3.928 | 275.405 ±4.502 | 0.969 ±0.021 |
| errors | 34.498 ±0.835 | 131.614 ±3.013 | 0.808 ±0.045 |
| sieve | 65.110 ±0.900 | 98.344 ±2.055 | 2.100 ±0.055 |
| sorting | 430.718 ±3.902 | 421.613 ±14.517 | 125.699 ±1.373 |
| sudoku | 51.792 ±2.028 | 103.965 ±0.483 | 9.324 ±0.401 |
| maze | 51.956 ±0.373 | 166.137 ±0.799 | 0.923 ±0.097 |
| vm | 64.517 ±1.603 | 156.221 ±4.418 | 0.961 ±0.012 |
| life | 72.720 ±4.989 | 135.524 ±2.867 | 22.182 ±0.697 |

## Supplement: Wasm entrypoint

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.214 ±0.011 | 0.135 ±0.007 |
| tour | 26.147 ±0.115 | 1.149 ±0.013 |
| functions | 32.742 ±1.318 | 1.077 ±0.005 |
| errors | 5.985 ±0.440 | 0.903 ±0.012 |
| sieve | 16.206 ±1.181 | 2.237 ±0.027 |
| sorting | 396.977 ±8.708 | 195.695 ±1.502 |
| sudoku | 20.753 ±0.422 | 12.807 ±0.239 |
| maze | 23.775 ±1.317 | 0.839 ±0.024 |
| vm | 32.129 ±2.369 | 0.975 ±0.013 |
| life | 40.661 ±0.912 | 29.791 ±0.624 |

## Supplement: Wasm engine compilation and instantiation

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.356 ±0.031 | 4.343 ±0.012 |
| tour | 0.581 ±0.030 | 65.773 ±0.740 |
| functions | 1.236 ±0.038 | 195.001 ±1.699 |
| errors | 0.615 ±0.019 | 59.133 ±0.193 |
| sieve | 0.404 ±0.017 | 25.070 ±0.431 |
| sorting | 1.165 ±0.017 | 166.960 ±2.428 |
| sudoku | 0.433 ±0.008 | 21.246 ±0.447 |
| maze | 0.797 ±0.016 | 96.156 ±3.913 |
| vm | 0.688 ±0.050 | 81.871 ±1.717 |
| life | 0.515 ±0.048 | 36.455 ±0.843 |

The entrypoint interval includes Goose initialization, host output callbacks and any lazy JIT work. It excludes final Wasm-host output concatenation/delivery. Native Goose prints unbuffered, so no native entrypoint column or cross-boundary speedup is presented. Process time minus engine time also includes loading, bookkeeping and teardown; it is not a pure startup measurement.

These fresh-process examples have different timing rules from LangArena's warmed computational regions. Raw samples, commands, artifact/source/compiler identities and engine versions are in [report.json](report.json). [Method and reproduction](../../../examples.md).
