# Example program benchmarks

Status: **passed**.

2026-11-05 · AMD Ryzen 7 3800X; pinned CPU 7.

Goose O2. Direct Wasm uses memory32; Native C is emitted by the Goose compiler. The selected programs, their constant inputs and all printing are unchanged from the [example catalog](../../../../examples/README.md). Compiler constant folding is allowed.

Builds are complete uncached Python-driver invocations, including any C compilation/linking. OS page caches remain warm.

Runtime is **whole-process launch-to-exit time**, including host startup, Wasm compilation/instantiation, program initialization, computation, output delivery and teardown. Each observation starts a fresh process/instance and calls the entrypoint once. This measures CLI cost, not warmed kernel throughput.

Each cell has 5 build samples or 5 runtime samples. Untimed fresh-process warmups per runtime cell: 1. Orders are shuffled with the recorded seed; builds and runtime never overlap. Every used artifact must pass its golden output. Values are median milliseconds ± median absolute deviation (MAD).

Headline runtime samples use the ordinary runners without timing-file instrumentation. The Wasm supplements use a separate shuffled set of fresh processes, with the same sample count; timing files are written after their engine intervals end.

## Compilation

| Example | Direct Wasm | Goose Native C |
| --- | ---: | ---: |
| squares | 48.863 ±0.065 | 242.746 ±0.557 |
| tour | 56.637 ±0.129 | 886.558 ±0.879 |
| functions | 117.608 ±0.212 | 1507.176 ±1.148 |
| errors | 74.696 ±0.372 | 703.872 ±0.525 |
| sieve | 67.054 ±0.217 | 379.464 ±0.536 |
| sorting | 119.928 ±0.056 | 1670.877 ±5.623 |
| sudoku | 69.126 ±0.140 | 453.150 ±1.324 |
| maze | 82.137 ±0.105 | 688.419 ±0.746 |
| vm | 76.633 ±0.078 | 576.284 ±1.521 |
| life | 70.786 ±0.341 | 530.689 ±0.893 |

## Whole-process runtime

| Example | Direct / V8 | Direct / Wasmtime | Goose Native C |
| --- | ---: | ---: | ---: |
| squares | 27.262 ±1.589 | 69.733 ±0.705 | 0.804 ±0.017 |
| tour | 56.143 ±0.539 | 116.963 ±1.134 | 0.872 ±0.021 |
| functions | 63.059 ±0.640 | 244.608 ±1.423 | 0.941 ±0.024 |
| errors | 32.584 ±0.544 | 103.389 ±0.425 | 0.752 ±0.007 |
| sieve | 54.414 ±0.477 | 85.290 ±1.101 | 1.324 ±0.002 |
| sorting | 399.461 ±1.944 | 383.257 ±5.457 | 113.568 ±0.248 |
| sudoku | 48.349 ±2.141 | 96.259 ±0.363 | 8.758 ±0.084 |
| maze | 50.877 ±0.714 | 151.696 ±0.501 | 0.779 ±0.014 |
| vm | 60.846 ±1.050 | 141.080 ±1.569 | 0.913 ±0.011 |
| life | 65.546 ±0.375 | 125.795 ±0.369 | 20.828 ±0.080 |

## Supplement: Wasm entrypoint

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.201 ±0.005 | 0.129 ±0.005 |
| tour | 25.348 ±0.140 | 1.790 ±0.004 |
| functions | 29.222 ±0.336 | 1.343 ±0.001 |
| errors | 4.214 ±0.026 | 0.838 ±0.004 |
| sieve | 15.775 ±0.430 | 2.458 ±0.007 |
| sorting | 369.585 ±3.362 | 166.226 ±1.083 |
| sudoku | 19.602 ±0.490 | 11.703 ±0.025 |
| maze | 21.288 ±0.328 | 0.784 ±0.004 |
| vm | 28.611 ±0.111 | 0.922 ±0.002 |
| life | 37.522 ±0.291 | 27.674 ±0.064 |

## Supplement: Wasm engine compilation and instantiation

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.268 ±0.008 | 4.251 ±0.060 |
| tour | 0.488 ±0.010 | 49.248 ±0.152 |
| functions | 1.138 ±0.025 | 179.239 ±1.373 |
| errors | 0.522 ±0.020 | 37.627 ±0.054 |
| sieve | 0.333 ±0.007 | 16.801 ±0.028 |
| sorting | 1.141 ±0.024 | 151.689 ±0.992 |
| sudoku | 0.368 ±0.020 | 20.146 ±0.039 |
| maze | 0.719 ±0.024 | 86.668 ±0.662 |
| vm | 0.595 ±0.014 | 73.860 ±0.290 |
| life | 0.424 ±0.009 | 33.458 ±0.177 |

The entrypoint interval includes Goose initialization, host output callbacks and any lazy JIT work. It excludes final Wasm-host output concatenation/delivery. Native Goose prints unbuffered, so no native entrypoint column or cross-boundary speedup is presented. Process time minus engine time also includes loading, bookkeeping and teardown; it is not a pure startup measurement.

These fresh-process examples have different timing rules from LangArena's warmed computational regions. Raw samples, commands, artifact/source/compiler identities and engine versions are in [report.json](report.json). [Method and reproduction](../../../examples.md).
