# Example program benchmarks

Status: **passed**.

2026-11-05 · AMD Ryzen 7 3800X 8-Core Processor.

Goose O2. Direct Wasm uses memory32; Native C is emitted by the Goose compiler. The selected programs, their constant inputs and all printing are unchanged from the [example catalog](../../../../examples/README.md). Compiler constant folding is allowed.

Builds are complete uncached Python-driver invocations, including any C compilation/linking. OS page caches remain warm.

Runtime is **whole-process launch-to-exit time**, including host startup, Wasm compilation/instantiation, program initialization, computation, output delivery and teardown. Each observation starts a fresh process/instance and calls the entrypoint once. This measures CLI cost, not warmed kernel throughput.

Each cell has 5 build samples or 5 runtime samples. Untimed fresh-process warmups per runtime cell: 1. Orders are shuffled with the recorded seed; builds and runtime never overlap. Every used artifact must pass its golden output. Values are median milliseconds ± median absolute deviation (MAD).

Headline runtime samples use the ordinary runners without timing-file instrumentation. The Wasm supplements use a separate shuffled set of fresh processes, with the same sample count; timing files are written after their engine intervals end.

## Compilation

| Example | Direct Wasm | Goose Native C |
| --- | ---: | ---: |
| squares | 51.990 ±0.687 | 262.086 ±5.246 |
| tour | 64.465 ±0.785 | 952.936 ±14.279 |
| functions | 137.020 ±0.679 | 1664.379 ±19.959 |
| errors | 92.559 ±0.278 | 851.462 ±5.612 |
| sieve | 75.177 ±0.611 | 411.747 ±0.883 |
| sorting | 141.760 ±2.696 | 1909.180 ±22.434 |
| sudoku | 76.877 ±0.240 | 481.139 ±5.961 |
| maze | 91.879 ±0.313 | 750.111 ±5.994 |
| vm | 85.596 ±2.290 | 606.334 ±5.935 |
| life | 77.679 ±0.239 | 539.641 ±9.257 |

## Whole-process runtime

| Example | Direct / V8 | Direct / Wasmtime | Goose Native C |
| --- | ---: | ---: | ---: |
| squares | 28.546 ±0.158 | 74.647 ±0.909 | 0.830 ±0.045 |
| tour | 59.232 ±2.364 | 134.791 ±2.124 | 0.954 ±0.032 |
| functions | 63.589 ±0.438 | 266.318 ±1.526 | 0.933 ±0.019 |
| errors | 35.669 ±0.649 | 128.159 ±2.847 | 0.790 ±0.019 |
| sieve | 64.849 ±1.266 | 95.868 ±1.055 | 2.037 ±0.011 |
| sorting | 439.682 ±5.848 | 428.525 ±13.000 | 124.718 ±0.744 |
| sudoku | 49.786 ±0.954 | 105.000 ±1.363 | 9.279 ±0.087 |
| maze | 52.302 ±0.504 | 161.328 ±1.703 | 0.825 ±0.016 |
| vm | 67.772 ±4.145 | 150.331 ±0.837 | 0.947 ±0.015 |
| life | 70.872 ±0.433 | 133.249 ±1.370 | 21.557 ±0.398 |

## Supplement: Wasm entrypoint

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.194 ±0.002 | 0.132 ±0.003 |
| tour | 27.198 ±0.865 | 1.107 ±0.011 |
| functions | 29.612 ±0.617 | 1.063 ±0.003 |
| errors | 5.734 ±0.104 | 0.874 ±0.008 |
| sieve | 16.969 ±1.846 | 2.141 ±0.005 |
| sorting | 388.530 ±2.748 | 175.219 ±0.609 |
| sudoku | 20.432 ±0.738 | 12.436 ±0.090 |
| maze | 24.657 ±0.341 | 0.796 ±0.002 |
| vm | 31.047 ±0.392 | 0.955 ±0.010 |
| life | 40.095 ±0.520 | 29.532 ±0.098 |

## Supplement: Wasm engine compilation and instantiation

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.296 ±0.039 | 4.432 ±0.032 |
| tour | 0.568 ±0.025 | 61.815 ±0.884 |
| functions | 1.180 ±0.020 | 191.266 ±4.147 |
| errors | 0.583 ±0.021 | 56.596 ±0.154 |
| sieve | 0.373 ±0.015 | 24.560 ±0.090 |
| sorting | 1.136 ±0.013 | 161.266 ±1.323 |
| sudoku | 0.382 ±0.016 | 21.051 ±0.153 |
| maze | 0.724 ±0.022 | 89.080 ±0.086 |
| vm | 0.608 ±0.034 | 77.678 ±0.423 |
| life | 0.428 ±0.007 | 35.282 ±0.444 |

The entrypoint interval includes Goose initialization, host output callbacks and any lazy JIT work. It excludes final Wasm-host output concatenation/delivery. Native Goose prints unbuffered, so no native entrypoint column or cross-boundary speedup is presented. Process time minus engine time also includes loading, bookkeeping and teardown; it is not a pure startup measurement.

These fresh-process examples have different timing rules from LangArena's warmed computational regions. Raw samples, commands, artifact/source/compiler identities and engine versions are in [report.json](report.json). [Method and reproduction](../../../examples.md).
