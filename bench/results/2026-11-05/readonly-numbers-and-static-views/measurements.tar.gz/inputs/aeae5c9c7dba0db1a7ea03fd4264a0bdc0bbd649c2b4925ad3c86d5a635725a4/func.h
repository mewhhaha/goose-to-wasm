/// \file wasmtime/component/func.h

#ifndef WASMTIME_COMPONENT_FUNC_H
#define WASMTIME_COMPONENT_FUNC_H

#include <wasmtime/async.h>
#include <wasmtime/component/types/func.h>
#include <wasmtime/component/val.h>
#include <wasmtime/conf.h>
#include <wasmtime/error.h>
#include <wasmtime/store.h>

#ifdef WASMTIME_FEATURE_COMPONENT_MODEL

#ifdef __cplusplus
extern "C" {
#endif

/// \brief Representation of a function in Wasmtime.
///
/// Functions in Wasmtime are represented as an index into a store and don't
/// have any data or destructor associated with the value. Functions cannot
/// interoperate between #wasmtime_store_t instances and if the wrong function
/// is passed to the wrong store then it may trigger an assertion to abort the
/// process.
typedef struct wasmtime_component_func {
  struct {
    /// Internal identifier of what store this belongs to, never zero.
    uint64_t store_id;
    /// Private internal wasmtime information.
    uint32_t __private1;
  };

  /// Private internal wasmtime information.
  uint32_t __private2;

  /// Private internal wasmtime information.
  void *__private3;
} wasmtime_component_func_t;

/// \brief Returns the type of this function.
///
/// The caller must deallocate the returned pointer with
/// `wasmtime_component_func_type_delete`.
WASM_API_EXTERN wasmtime_component_func_type_t *
wasmtime_component_func_type(const wasmtime_component_func_t *func,
                             wasmtime_context_t *context);

/**
 * \brief Invokes \p func with the \p args given and returns the result.
 *
 * The \p args provided must match the parameters that this function takes in
 * terms of their types and the number of parameters. Results will be written to
 * the \p results provided if the call completes successfully. It's required
 * that the \p results_size exactly matches the number of results that this
 * function produces. It's additionally required that \p results is all entirely
 * initialize (cannot be uninitialized memory). The types of values do not
 * matter, and #WASMTIME_COMPONENT_BOOL can be used to cheaply initialize.
 */
WASM_API_EXTERN wasmtime_error_t *wasmtime_component_func_call(
    const wasmtime_component_func_t *func, wasmtime_context_t *context,
    const wasmtime_component_val_t *args, size_t args_size,
    wasmtime_component_val_t *results, size_t results_size);

/**
 * \brief No longer needs to be called; this function has no effect.
 *
 * \deprecated Previously, this invoked the `post-return` canonical ABI option,
 * if specified, after a #wasmtime_component_func_call had finished.  Now that's
 * taken care of automatically as part of #wasmtime_component_func_call, so this
 * function is no longer needed, and any calls to it may be removed.
 */
WASM_API_EXTERN wasmtime_error_t *
wasmtime_component_func_post_return(const wasmtime_component_func_t *func,
                                    wasmtime_context_t *context);

#ifdef WASMTIME_FEATURE_COMPONENT_MODEL_ASYNC

/**
 * \brief Invokes \p func with the \p args given, returning the results
 * asynchronously.
 *
 * This is the same as #wasmtime_component_func_call except that it is
 * asynchronous. This is only compatible with stores associated with an
 * asynchronous config.
 *
 * The result is a future that is owned by the caller and must be deleted via
 * #wasmtime_call_future_delete.
 *
 * All parameters to this function must be kept alive and not modified until the
 * returned #wasmtime_call_future_t is deleted.
 */
WASM_API_EXTERN wasmtime_call_future_t *wasmtime_component_func_call_async(
    const wasmtime_component_func_t *func, wasmtime_context_t *context,
    const wasmtime_component_val_t *args, size_t args_size,
    wasmtime_component_val_t *results, size_t results_size,
    wasmtime_error_t **error_ret);

#endif // WASMTIME_FEATURE_COMPONENT_MODEL_ASYNC

#ifdef __cplusplus
} // extern "C"
#endif

#endif // WASMTIME_FEATURE_COMPONENT_MODEL

#endif // WASMTIME_COMPONENT_FUNC_H
