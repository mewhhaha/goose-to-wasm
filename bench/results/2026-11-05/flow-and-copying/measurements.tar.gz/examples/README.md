# Example program benchmarks

Status: **passed**.

2026-11-05 · AMD Ryzen 7 3800X 8-Core Processor.

Goose O2. Direct Wasm uses memory32; Native C is emitted by the Goose compiler. The selected programs, their constant inputs and all printing are unchanged from the [example catalog](../../../../examples/README.md). Compiler constant folding is allowed.

Builds are complete uncached Python-driver invocations, including any C compilation/linking. OS page caches remain warm.

Runtime is **whole-process launch-to-exit time**, including host startup, Wasm compilation/instantiation, program initialization, computation, output delivery and teardown. Each observation starts a fresh process/instance and calls the entrypoint once. This measures CLI cost, not warmed kernel throughput.

Each cell has 5 build samples or 5 runtime samples. Untimed fresh-process warmups per runtime cell: 1. Orders are shuffled with the recorded seed; builds and runtime never overlap. Every used artifact must pass its golden output. Values are median milliseconds ± median absolute deviation (MAD).

Headline runtime samples use the ordinary runners without timing-file instrumentation. The Wasm supplements use a separate shuffled set of fresh processes, with the same sample count; timing files are written after their engine intervals end.

## Compilation

| Example | Direct Wasm | Goose Native C |
| --- | ---: | ---: |
| squares | 49.868 ±0.063 | 246.424 ±3.281 |
| tour | 62.015 ±0.125 | 893.985 ±2.751 |
| functions | 127.857 ±0.229 | 1523.215 ±7.321 |
| errors | 77.476 ±0.217 | 712.534 ±2.596 |
| sieve | 72.255 ±0.273 | 382.594 ±1.405 |
| sorting | 129.158 ±0.048 | 1696.557 ±18.311 |
| sudoku | 72.101 ±0.234 | 459.664 ±2.066 |
| maze | 85.623 ±0.166 | 692.626 ±1.928 |
| vm | 79.683 ±0.136 | 584.061 ±0.220 |
| life | 73.875 ±0.193 | 544.492 ±4.946 |

## Whole-process runtime

| Example | Direct / V8 | Direct / Wasmtime | Goose Native C |
| --- | ---: | ---: | ---: |
| squares | 27.362 ±0.652 | 69.565 ±0.978 | 0.812 ±0.012 |
| tour | 56.514 ±0.190 | 128.575 ±1.505 | 0.780 ±0.036 |
| functions | 61.692 ±1.344 | 251.720 ±4.447 | 0.934 ±0.008 |
| errors | 31.681 ±1.707 | 105.185 ±0.988 | 0.764 ±0.032 |
| sieve | 61.505 ±0.640 | 90.732 ±0.248 | 1.384 ±0.042 |
| sorting | 404.145 ±4.308 | 390.292 ±5.594 | 114.186 ±0.712 |
| sudoku | 48.881 ±1.455 | 97.962 ±1.808 | 8.840 ±0.164 |
| maze | 53.339 ±1.425 | 154.156 ±0.575 | 0.902 ±0.033 |
| vm | 62.689 ±1.407 | 140.038 ±0.339 | 0.911 ±0.019 |
| life | 67.334 ±0.728 | 126.218 ±0.219 | 20.966 ±0.080 |

## Supplement: Wasm entrypoint

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.197 ±0.002 | 0.123 ±0.000 |
| tour | 25.476 ±0.114 | 1.058 ±0.010 |
| functions | 27.474 ±0.394 | 1.021 ±0.002 |
| errors | 4.087 ±0.061 | 0.844 ±0.005 |
| sieve | 16.318 ±1.857 | 2.033 ±0.018 |
| sorting | 364.049 ±0.663 | 162.656 ±0.262 |
| sudoku | 19.496 ±0.027 | 11.549 ±0.037 |
| maze | 22.631 ±0.387 | 0.786 ±0.003 |
| vm | 29.182 ±0.822 | 0.922 ±0.005 |
| life | 37.673 ±0.291 | 27.439 ±0.082 |

## Supplement: Wasm engine compilation and instantiation

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.316 ±0.051 | 4.145 ±0.008 |
| tour | 0.555 ±0.035 | 58.031 ±0.152 |
| functions | 1.119 ±0.011 | 179.216 ±0.237 |
| errors | 0.480 ±0.011 | 37.575 ±0.191 |
| sieve | 0.378 ±0.007 | 23.215 ±0.050 |
| sorting | 1.103 ±0.008 | 152.724 ±0.427 |
| sudoku | 0.360 ±0.004 | 19.922 ±0.011 |
| maze | 0.728 ±0.031 | 85.472 ±0.238 |
| vm | 0.581 ±0.011 | 73.337 ±0.468 |
| life | 0.453 ±0.037 | 33.239 ±0.083 |

The entrypoint interval includes Goose initialization, host output callbacks and any lazy JIT work. It excludes final Wasm-host output concatenation/delivery. Native Goose prints unbuffered, so no native entrypoint column or cross-boundary speedup is presented. Process time minus engine time also includes loading, bookkeeping and teardown; it is not a pure startup measurement.

These fresh-process examples have different timing rules from LangArena's warmed computational regions. Raw samples, commands, artifact/source/compiler identities and engine versions are in [report.json](report.json). [Method and reproduction](../../../examples.md).
