# Example program benchmarks

Status: **passed**.

2026-11-05 · AMD Ryzen 7 3800X 8-Core Processor.

Goose O2. Direct Wasm uses memory32; Native C is emitted by the Goose compiler. The selected programs, their constant inputs and all printing are unchanged from the [example catalog](../../../../examples/README.md). Compiler constant folding is allowed.

Builds are complete uncached Python-driver invocations, including any C compilation/linking. OS page caches remain warm.

Runtime is **whole-process launch-to-exit time**, including host startup, Wasm compilation/instantiation, program initialization, computation, output delivery and teardown. Each observation starts a fresh process/instance and calls the entrypoint once. This measures CLI cost, not warmed kernel throughput.

Each cell has 5 build samples or 5 runtime samples. Untimed fresh-process warmups per runtime cell: 1. Orders are shuffled with the recorded seed; builds and runtime never overlap. Every used artifact must pass its golden output. Values are median milliseconds ± median absolute deviation (MAD).

Headline runtime samples use the ordinary runners without timing-file instrumentation. The Wasm supplements use a separate shuffled set of fresh processes, with the same sample count; timing files are written after their engine intervals end.

## Compilation

| Example | Direct Wasm | Goose Native C |
| --- | ---: | ---: |
| squares | 49.770 ±0.008 | 249.841 ±0.479 |
| tour | 62.263 ±0.031 | 894.240 ±6.072 |
| functions | 130.416 ±0.766 | 1591.802 ±2.875 |
| errors | 82.763 ±0.017 | 816.443 ±11.667 |
| sieve | 72.349 ±0.341 | 390.353 ±0.673 |
| sorting | 131.702 ±0.170 | 1823.321 ±14.703 |
| sudoku | 73.391 ±0.181 | 463.711 ±0.842 |
| maze | 87.570 ±0.535 | 713.846 ±3.453 |
| vm | 80.505 ±0.037 | 584.500 ±1.680 |
| life | 74.422 ±0.188 | 518.219 ±1.304 |

## Whole-process runtime

| Example | Direct / V8 | Direct / Wasmtime | Goose Native C |
| --- | ---: | ---: | ---: |
| squares | 26.053 ±1.212 | 69.137 ±0.353 | 0.810 ±0.010 |
| tour | 55.708 ±0.667 | 124.988 ±0.102 | 0.811 ±0.043 |
| functions | 60.864 ±2.224 | 245.901 ±0.164 | 0.909 ±0.032 |
| errors | 34.720 ±1.486 | 120.458 ±0.065 | 0.753 ±0.005 |
| sieve | 60.667 ±0.666 | 90.516 ±0.101 | 1.966 ±0.007 |
| sorting | 398.417 ±2.231 | 381.357 ±0.184 | 114.040 ±0.053 |
| sudoku | 47.337 ±0.152 | 96.304 ±0.056 | 8.766 ±0.076 |
| maze | 50.685 ±0.345 | 151.378 ±0.284 | 0.778 ±0.019 |
| vm | 59.998 ±0.363 | 139.683 ±0.119 | 0.909 ±0.005 |
| life | 66.005 ±0.671 | 125.738 ±0.185 | 20.717 ±0.074 |

## Supplement: Wasm entrypoint

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.190 ±0.001 | 0.122 ±0.004 |
| tour | 24.985 ±0.298 | 1.048 ±0.008 |
| functions | 26.935 ±0.017 | 1.013 ±0.003 |
| errors | 5.575 ±0.009 | 0.834 ±0.004 |
| sieve | 14.914 ±0.399 | 2.033 ±0.003 |
| sorting | 365.048 ±3.732 | 162.672 ±0.137 |
| sudoku | 19.506 ±0.072 | 11.577 ±0.007 |
| maze | 22.189 ±1.113 | 0.776 ±0.003 |
| vm | 28.496 ±0.196 | 0.903 ±0.003 |
| life | 37.657 ±0.465 | 27.289 ±0.009 |

## Supplement: Wasm engine compilation and instantiation

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.265 ±0.002 | 4.057 ±0.005 |
| tour | 0.548 ±0.013 | 57.773 ±0.060 |
| functions | 1.118 ±0.014 | 178.792 ±0.198 |
| errors | 0.573 ±0.024 | 54.301 ±0.064 |
| sieve | 0.364 ±0.005 | 23.087 ±0.036 |
| sorting | 1.110 ±0.004 | 151.793 ±0.190 |
| sudoku | 0.350 ±0.001 | 19.840 ±0.010 |
| maze | 0.690 ±0.010 | 84.795 ±0.151 |
| vm | 0.574 ±0.017 | 72.894 ±0.215 |
| life | 0.416 ±0.005 | 33.098 ±0.067 |

The entrypoint interval includes Goose initialization, host output callbacks and any lazy JIT work. It excludes final Wasm-host output concatenation/delivery. Native Goose prints unbuffered, so no native entrypoint column or cross-boundary speedup is presented. Process time minus engine time also includes loading, bookkeeping and teardown; it is not a pure startup measurement.

These fresh-process examples have different timing rules from LangArena's warmed computational regions. Raw samples, commands, artifact/source/compiler identities and engine versions are in [report.json](report.json). [Method and reproduction](../../../examples.md).
