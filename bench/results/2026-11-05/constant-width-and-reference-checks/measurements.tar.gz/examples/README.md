# Example program benchmarks

Status: **passed**.

2026-11-05 · AMD Ryzen 7 3800X 8-Core Processor.

Goose O2. Direct Wasm uses memory32; Native C is emitted by the Goose compiler. The selected programs, their constant inputs and all printing are unchanged from the [example catalog](../../../../examples/README.md). Compiler constant folding is allowed.

Builds are complete uncached Python-driver invocations, including any C compilation/linking. OS page caches remain warm.

Runtime is **whole-process launch-to-exit time**, including host startup, Wasm compilation/instantiation, program initialization, computation, output delivery and teardown. Each observation starts a fresh process/instance and calls the entrypoint once. This measures CLI cost, not warmed kernel throughput.

Each cell has 5 build samples or 5 runtime samples. Untimed fresh-process warmups per runtime cell: 1. Orders are shuffled with the recorded seed; builds and runtime never overlap. Every used artifact must pass its golden output. Values are median milliseconds ± median absolute deviation (MAD).

Headline runtime samples use the ordinary runners without timing-file instrumentation. The Wasm supplements use a separate shuffled set of fresh processes, with the same sample count; timing files are written after their engine intervals end.

## Compilation

| Example | Direct Wasm | Goose Native C |
| --- | ---: | ---: |
| squares | 50.369 ±0.423 | 249.442 ±0.125 |
| tour | 62.835 ±0.153 | 897.452 ±2.889 |
| functions | 131.218 ±0.217 | 1594.543 ±0.600 |
| errors | 83.989 ±0.137 | 804.798 ±2.382 |
| sieve | 72.806 ±0.390 | 392.030 ±0.682 |
| sorting | 132.413 ±0.092 | 1823.015 ±4.686 |
| sudoku | 74.406 ±0.393 | 465.826 ±0.370 |
| maze | 87.283 ±0.013 | 715.683 ±0.249 |
| vm | 80.942 ±0.538 | 586.619 ±0.725 |
| life | 75.035 ±0.174 | 519.108 ±1.328 |

## Whole-process runtime

| Example | Direct / V8 | Direct / Wasmtime | Goose Native C |
| --- | ---: | ---: | ---: |
| squares | 27.709 ±0.754 | 69.238 ±0.350 | 0.815 ±0.010 |
| tour | 56.933 ±0.138 | 129.698 ±2.420 | 0.902 ±0.096 |
| functions | 60.819 ±0.985 | 246.731 ±0.664 | 0.935 ±0.013 |
| errors | 34.303 ±1.370 | 120.279 ±0.231 | 0.776 ±0.025 |
| sieve | 61.771 ±0.779 | 91.893 ±1.235 | 1.962 ±0.002 |
| sorting | 403.792 ±4.022 | 383.853 ±1.166 | 117.210 ±0.234 |
| sudoku | 47.911 ±1.309 | 98.518 ±1.104 | 8.851 ±0.022 |
| maze | 50.889 ±0.054 | 152.020 ±0.984 | 0.786 ±0.010 |
| vm | 62.186 ±0.806 | 140.597 ±0.868 | 0.921 ±0.017 |
| life | 66.464 ±0.933 | 126.403 ±0.313 | 20.956 ±0.115 |

## Supplement: Wasm entrypoint

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.194 ±0.002 | 0.126 ±0.007 |
| tour | 25.958 ±0.928 | 1.052 ±0.003 |
| functions | 26.928 ±0.044 | 1.015 ±0.001 |
| errors | 5.574 ±0.070 | 0.837 ±0.002 |
| sieve | 16.397 ±1.019 | 2.033 ±0.011 |
| sorting | 364.400 ±1.808 | 163.806 ±0.398 |
| sudoku | 19.427 ±0.096 | 11.666 ±0.023 |
| maze | 22.407 ±1.185 | 0.769 ±0.005 |
| vm | 28.345 ±0.044 | 0.911 ±0.005 |
| life | 37.592 ±0.304 | 27.401 ±0.029 |

## Supplement: Wasm engine compilation and instantiation

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.345 ±0.035 | 4.111 ±0.019 |
| tour | 0.554 ±0.017 | 58.021 ±0.010 |
| functions | 1.117 ±0.012 | 178.152 ±0.149 |
| errors | 0.586 ±0.004 | 54.144 ±0.329 |
| sieve | 0.376 ±0.020 | 23.030 ±0.017 |
| sorting | 1.106 ±0.009 | 151.505 ±0.249 |
| sudoku | 0.359 ±0.006 | 19.776 ±0.022 |
| maze | 0.714 ±0.018 | 84.820 ±0.082 |
| vm | 0.590 ±0.004 | 72.623 ±0.092 |
| life | 0.470 ±0.034 | 32.985 ±0.071 |

The entrypoint interval includes Goose initialization, host output callbacks and any lazy JIT work. It excludes final Wasm-host output concatenation/delivery. Native Goose prints unbuffered, so no native entrypoint column or cross-boundary speedup is presented. Process time minus engine time also includes loading, bookkeeping and teardown; it is not a pure startup measurement.

These fresh-process examples have different timing rules from LangArena's warmed computational regions. Raw samples, commands, artifact/source/compiler identities and engine versions are in [report.json](report.json). [Method and reproduction](../../../examples.md).
