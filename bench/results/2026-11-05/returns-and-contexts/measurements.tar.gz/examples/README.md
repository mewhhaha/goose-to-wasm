# Example program benchmarks

Status: **passed**.

2026-11-05 · AMD Ryzen 7 3800X 8-Core Processor.

Goose O2. Direct Wasm uses memory32; Native C is emitted by the Goose compiler. The selected programs, their constant inputs and all printing are unchanged from the [example catalog](../../../../examples/README.md). Compiler constant folding is allowed.

Builds are complete uncached Python-driver invocations, including any C compilation/linking. OS page caches remain warm.

Runtime is **whole-process launch-to-exit time**, including host startup, Wasm compilation/instantiation, program initialization, computation, output delivery and teardown. Each observation starts a fresh process/instance and calls the entrypoint once. This measures CLI cost, not warmed kernel throughput.

Each cell has 5 build samples or 5 runtime samples. Untimed fresh-process warmups per runtime cell: 1. Orders are shuffled with the recorded seed; builds and runtime never overlap. Every used artifact must pass its golden output. Values are median milliseconds ± median absolute deviation (MAD).

Headline runtime samples use the ordinary runners without timing-file instrumentation. The Wasm supplements use a separate shuffled set of fresh processes, with the same sample count; timing files are written after their engine intervals end.

## Compilation

| Example | Direct Wasm | Goose Native C |
| --- | ---: | ---: |
| squares | 50.864 ±0.567 | 255.378 ±3.425 |
| tour | 62.860 ±0.299 | 965.079 ±12.645 |
| functions | 136.230 ±5.292 | 1582.418 ±29.259 |
| errors | 84.543 ±0.907 | 819.541 ±6.450 |
| sieve | 72.871 ±0.213 | 390.158 ±1.439 |
| sorting | 132.069 ±0.475 | 1744.293 ±29.497 |
| sudoku | 77.367 ±2.243 | 492.444 ±13.386 |
| maze | 87.898 ±1.088 | 721.416 ±11.607 |
| vm | 82.896 ±0.570 | 598.021 ±3.320 |
| life | 78.149 ±2.029 | 545.571 ±1.058 |

## Whole-process runtime

| Example | Direct / V8 | Direct / Wasmtime | Goose Native C |
| --- | ---: | ---: | ---: |
| squares | 27.910 ±0.776 | 71.072 ±1.385 | 0.818 ±0.011 |
| tour | 58.215 ±0.264 | 129.060 ±1.352 | 0.907 ±0.031 |
| functions | 62.057 ±0.404 | 252.578 ±1.939 | 0.935 ±0.010 |
| errors | 34.016 ±0.449 | 123.186 ±0.338 | 0.750 ±0.012 |
| sieve | 61.533 ±0.375 | 91.999 ±0.170 | 1.356 ±0.015 |
| sorting | 409.376 ±1.272 | 401.585 ±7.921 | 118.560 ±1.103 |
| sudoku | 47.563 ±0.554 | 99.743 ±0.952 | 8.787 ±0.064 |
| maze | 52.119 ±0.955 | 155.157 ±0.103 | 0.778 ±0.005 |
| vm | 61.659 ±0.213 | 142.354 ±0.376 | 0.924 ±0.021 |
| life | 68.248 ±1.080 | 128.599 ±0.495 | 21.087 ±0.073 |

## Supplement: Wasm entrypoint

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.200 ±0.001 | 0.129 ±0.003 |
| tour | 26.235 ±0.272 | 1.073 ±0.001 |
| functions | 28.726 ±1.179 | 1.030 ±0.004 |
| errors | 5.717 ±0.056 | 0.838 ±0.004 |
| sieve | 14.524 ±0.931 | 2.064 ±0.009 |
| sorting | 377.491 ±0.812 | 169.398 ±0.458 |
| sudoku | 18.938 ±0.452 | 11.999 ±0.063 |
| maze | 22.577 ±1.136 | 0.793 ±0.010 |
| vm | 29.245 ±0.423 | 0.934 ±0.007 |
| life | 39.510 ±0.481 | 28.306 ±0.036 |

## Supplement: Wasm engine compilation and instantiation

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.287 ±0.016 | 4.250 ±0.046 |
| tour | 0.550 ±0.010 | 59.213 ±0.297 |
| functions | 1.160 ±0.010 | 182.794 ±0.413 |
| errors | 0.592 ±0.001 | 55.480 ±0.347 |
| sieve | 0.390 ±0.032 | 23.439 ±0.107 |
| sorting | 1.116 ±0.015 | 155.046 ±0.175 |
| sudoku | 0.386 ±0.022 | 20.098 ±0.022 |
| maze | 0.722 ±0.009 | 88.533 ±1.842 |
| vm | 0.611 ±0.036 | 74.615 ±0.516 |
| life | 0.434 ±0.017 | 33.893 ±0.409 |

The entrypoint interval includes Goose initialization, host output callbacks and any lazy JIT work. It excludes final Wasm-host output concatenation/delivery. Native Goose prints unbuffered, so no native entrypoint column or cross-boundary speedup is presented. Process time minus engine time also includes loading, bookkeeping and teardown; it is not a pure startup measurement.

These fresh-process examples have different timing rules from LangArena's warmed computational regions. Raw samples, commands, artifact/source/compiler identities and engine versions are in [report.json](report.json). [Method and reproduction](../../../examples.md).
