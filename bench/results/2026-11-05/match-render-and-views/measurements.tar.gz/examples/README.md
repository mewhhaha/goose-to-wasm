# Example program benchmarks

Status: **passed**.

2026-11-05 · AMD Ryzen 7 3800X 8-Core Processor.

Goose O2. Direct Wasm uses memory32; Native C is emitted by the Goose compiler. The selected programs, their constant inputs and all printing are unchanged from the [example catalog](../../../../examples/README.md). Compiler constant folding is allowed.

Builds are complete uncached Python-driver invocations, including any C compilation/linking. OS page caches remain warm.

Runtime is **whole-process launch-to-exit time**, including host startup, Wasm compilation/instantiation, program initialization, computation, output delivery and teardown. Each observation starts a fresh process/instance and calls the entrypoint once. This measures CLI cost, not warmed kernel throughput.

Each cell has 5 build samples or 5 runtime samples. Untimed fresh-process warmups per runtime cell: 1. Orders are shuffled with the recorded seed; builds and runtime never overlap. Every used artifact must pass its golden output. Values are median milliseconds ± median absolute deviation (MAD).

Headline runtime samples use the ordinary runners without timing-file instrumentation. The Wasm supplements use a separate shuffled set of fresh processes, with the same sample count; timing files are written after their engine intervals end.

## Compilation

| Example | Direct Wasm | Goose Native C |
| --- | ---: | ---: |
| squares | 50.398 ±0.199 | 252.935 ±1.284 |
| tour | 63.830 ±1.655 | 909.928 ±15.104 |
| functions | 132.708 ±0.741 | 1611.872 ±4.766 |
| errors | 84.073 ±0.198 | 811.420 ±2.259 |
| sieve | 75.977 ±1.122 | 398.854 ±5.503 |
| sorting | 132.909 ±0.377 | 1988.919 ±89.527 |
| sudoku | 74.032 ±0.557 | 476.987 ±8.624 |
| maze | 87.452 ±0.175 | 721.340 ±2.411 |
| vm | 86.299 ±2.885 | 600.701 ±10.420 |
| life | 75.249 ±0.618 | 539.218 ±16.024 |

## Whole-process runtime

| Example | Direct / V8 | Direct / Wasmtime | Goose Native C |
| --- | ---: | ---: | ---: |
| squares | 28.448 ±1.321 | 73.802 ±0.505 | 0.869 ±0.021 |
| tour | 65.663 ±3.186 | 132.391 ±0.240 | 0.959 ±0.025 |
| functions | 62.838 ±0.954 | 261.803 ±0.763 | 0.969 ±0.068 |
| errors | 35.426 ±1.293 | 127.728 ±0.824 | 0.774 ±0.012 |
| sieve | 64.748 ±0.397 | 95.776 ±0.269 | 2.013 ±0.007 |
| sorting | 426.520 ±9.326 | 413.344 ±10.634 | 121.071 ±0.188 |
| sudoku | 49.636 ±0.303 | 102.936 ±0.539 | 9.240 ±0.071 |
| maze | 57.644 ±5.681 | 162.619 ±1.800 | 0.950 ±0.092 |
| vm | 63.154 ±0.831 | 148.725 ±0.617 | 0.961 ±0.019 |
| life | 70.289 ±1.004 | 133.356 ±0.669 | 21.427 ±0.148 |

## Supplement: Wasm entrypoint

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.201 ±0.003 | 0.123 ±0.002 |
| tour | 26.922 ±0.783 | 1.085 ±0.007 |
| functions | 29.385 ±1.257 | 1.034 ±0.015 |
| errors | 5.716 ±0.118 | 0.853 ±0.017 |
| sieve | 15.567 ±1.400 | 2.121 ±0.031 |
| sorting | 391.229 ±4.816 | 171.964 ±1.010 |
| sudoku | 20.112 ±0.570 | 12.022 ±0.133 |
| maze | 22.691 ±0.090 | 0.795 ±0.008 |
| vm | 29.884 ±0.143 | 0.962 ±0.010 |
| life | 38.936 ±0.755 | 28.584 ±0.378 |

## Supplement: Wasm engine compilation and instantiation

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.302 ±0.012 | 4.189 ±0.020 |
| tour | 0.586 ±0.036 | 61.420 ±0.655 |
| functions | 1.186 ±0.048 | 184.253 ±0.389 |
| errors | 0.607 ±0.024 | 55.805 ±0.626 |
| sieve | 0.382 ±0.004 | 23.891 ±0.282 |
| sorting | 1.161 ±0.025 | 159.926 ±4.349 |
| sudoku | 0.378 ±0.006 | 20.164 ±0.064 |
| maze | 0.762 ±0.034 | 89.261 ±1.102 |
| vm | 0.646 ±0.010 | 77.653 ±1.496 |
| life | 0.479 ±0.049 | 34.346 ±0.218 |

The entrypoint interval includes Goose initialization, host output callbacks and any lazy JIT work. It excludes final Wasm-host output concatenation/delivery. Native Goose prints unbuffered, so no native entrypoint column or cross-boundary speedup is presented. Process time minus engine time also includes loading, bookkeeping and teardown; it is not a pure startup measurement.

These fresh-process examples have different timing rules from LangArena's warmed computational regions. Raw samples, commands, artifact/source/compiler identities and engine versions are in [report.json](report.json). [Method and reproduction](../../../examples.md).
