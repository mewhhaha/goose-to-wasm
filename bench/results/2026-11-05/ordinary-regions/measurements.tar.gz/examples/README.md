# Example program benchmarks

Status: **passed**.

2026-11-04 · AMD Ryzen 7 3800X; pinned CPU 7.

Goose O2. Direct Wasm uses memory32; Native C is emitted by the Goose compiler. The selected programs, their constant inputs and all printing are unchanged from the [example catalog](../../../../examples/README.md). Compiler constant folding is allowed.

Builds are complete uncached Python-driver invocations, including any C compilation/linking. OS page caches remain warm.

Runtime is **whole-process launch-to-exit time**, including host startup, Wasm compilation/instantiation, program initialization, computation, output delivery and teardown. Each observation starts a fresh process/instance and calls the entrypoint once. This measures CLI cost, not warmed kernel throughput.

Each cell has 5 build samples or 5 runtime samples. Untimed fresh-process warmups per runtime cell: 1. Orders are shuffled with the recorded seed; builds and runtime never overlap. Every used artifact must pass its golden output. Values are median milliseconds ± median absolute deviation (MAD).

Headline runtime samples use the ordinary runners without timing-file instrumentation. The Wasm supplements use a separate shuffled set of fresh processes, with the same sample count; timing files are written after their engine intervals end.

## Compilation

| Example | Direct Wasm | Goose Native C |
| --- | ---: | ---: |
| squares | 50.407 ±0.403 | 246.964 ±7.768 |
| tour | 59.615 ±0.407 | 862.206 ±1.373 |
| functions | 111.214 ±0.787 | 1266.201 ±4.303 |
| errors | 68.684 ±0.172 | 646.172 ±1.860 |
| sieve | 61.493 ±0.621 | 370.786 ±1.912 |
| sorting | 114.601 ±0.873 | 1337.321 ±9.257 |
| sudoku | 63.969 ±0.457 | 431.533 ±2.787 |
| maze | 75.263 ±0.454 | 588.751 ±5.409 |
| vm | 71.349 ±0.640 | 521.037 ±1.708 |
| life | 64.855 ±0.170 | 479.020 ±9.795 |

## Whole-process runtime

| Example | Direct / V8 | Direct / Wasmtime | Goose Native C |
| --- | ---: | ---: | ---: |
| squares | 25.374 ±0.269 | 70.713 ±1.122 | 0.826 ±0.016 |
| tour | 57.432 ±0.860 | 120.186 ±0.609 | 0.884 ±0.048 |
| functions | 64.522 ±0.700 | 252.034 ±2.486 | 0.932 ±0.039 |
| errors | 32.792 ±0.175 | 105.635 ±1.032 | 0.779 ±0.003 |
| sieve | 54.699 ±0.331 | 89.824 ±3.185 | 5.752 ±0.050 |
| sorting | 409.794 ±4.393 | 401.511 ±8.807 | 1150.738 ±1.980 |
| sudoku | 47.999 ±0.568 | 99.102 ±0.605 | 9.879 ±0.037 |
| maze | 52.679 ±0.864 | 159.261 ±2.552 | 0.936 ±0.072 |
| vm | 63.507 ±1.265 | 144.012 ±0.989 | 0.965 ±0.045 |
| life | 68.928 ±0.790 | 129.190 ±0.398 | 21.337 ±0.241 |

## Supplement: Wasm entrypoint

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.202 ±0.001 | 0.126 ±0.001 |
| tour | 25.395 ±0.068 | 1.821 ±0.018 |
| functions | 29.705 ±0.198 | 1.373 ±0.013 |
| errors | 4.278 ±0.103 | 0.843 ±0.025 |
| sieve | 15.276 ±0.563 | 2.554 ±0.069 |
| sorting | 379.535 ±6.450 | 169.886 ±0.033 |
| sudoku | 20.129 ±0.288 | 12.066 ±0.010 |
| maze | 23.689 ±0.508 | 0.780 ±0.006 |
| vm | 29.222 ±0.061 | 0.932 ±0.007 |
| life | 39.390 ±0.484 | 28.205 ±0.068 |

## Supplement: Wasm engine compilation and instantiation

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.265 ±0.005 | 4.257 ±0.048 |
| tour | 0.484 ±0.003 | 51.531 ±0.759 |
| functions | 1.109 ±0.043 | 186.550 ±4.888 |
| errors | 0.482 ±0.012 | 38.536 ±0.677 |
| sieve | 0.339 ±0.002 | 17.280 ±0.415 |
| sorting | 1.110 ±0.008 | 152.440 ±0.657 |
| sudoku | 0.419 ±0.022 | 20.431 ±0.221 |
| maze | 0.723 ±0.014 | 89.250 ±1.205 |
| vm | 0.609 ±0.002 | 75.295 ±0.700 |
| life | 0.489 ±0.024 | 34.037 ±0.182 |

The entrypoint interval includes Goose initialization, host output callbacks and any lazy JIT work. It excludes final Wasm-host output concatenation/delivery. Native Goose prints unbuffered, so no native entrypoint column or cross-boundary speedup is presented. Process time minus engine time also includes loading, bookkeeping and teardown; it is not a pure startup measurement.

These fresh-process examples have different timing rules from LangArena's warmed computational regions. Raw samples, commands, artifact/source/compiler identities and engine versions are in [report.json](report.json). [Method and reproduction](../../../examples.md).
