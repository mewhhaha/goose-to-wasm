# Example program benchmarks

Status: **passed**.

2026-11-05 · AMD Ryzen 7 3800X 8-Core Processor.

Goose O2. Direct Wasm uses memory32; Native C is emitted by the Goose compiler. The selected programs, their constant inputs and all printing are unchanged from the [example catalog](../../../../examples/README.md). Compiler constant folding is allowed.

Builds are complete uncached Python-driver invocations, including any C compilation/linking. OS page caches remain warm.

Runtime is **whole-process launch-to-exit time**, including host startup, Wasm compilation/instantiation, program initialization, computation, output delivery and teardown. Each observation starts a fresh process/instance and calls the entrypoint once. This measures CLI cost, not warmed kernel throughput.

Each cell has 5 build samples or 5 runtime samples. Untimed fresh-process warmups per runtime cell: 1. Orders are shuffled with the recorded seed; builds and runtime never overlap. Every used artifact must pass its golden output. Values are median milliseconds ± median absolute deviation (MAD).

Headline runtime samples use the ordinary runners without timing-file instrumentation. The Wasm supplements use a separate shuffled set of fresh processes, with the same sample count; timing files are written after their engine intervals end.

## Compilation

| Example | Direct Wasm | Goose Native C |
| --- | ---: | ---: |
| squares | 49.005 ±0.208 | 241.760 ±1.083 |
| tour | 61.026 ±0.167 | 884.007 ±1.641 |
| functions | 126.061 ±0.310 | 1502.150 ±1.282 |
| errors | 80.814 ±0.182 | 791.383 ±7.231 |
| sieve | 70.235 ±0.175 | 379.609 ±2.012 |
| sorting | 127.358 ±0.429 | 1663.377 ±6.578 |
| sudoku | 71.919 ±0.504 | 453.728 ±1.344 |
| maze | 84.414 ±0.171 | 684.104 ±1.065 |
| vm | 78.856 ±0.625 | 576.761 ±0.948 |
| life | 73.218 ±0.222 | 528.952 ±1.015 |

## Whole-process runtime

| Example | Direct / V8 | Direct / Wasmtime | Goose Native C |
| --- | ---: | ---: | ---: |
| squares | 27.779 ±0.477 | 68.393 ±0.118 | 0.802 ±0.001 |
| tour | 57.039 ±1.049 | 124.543 ±0.484 | 0.757 ±0.018 |
| functions | 59.095 ±0.451 | 243.840 ±0.319 | 0.910 ±0.013 |
| errors | 34.150 ±0.596 | 119.314 ±0.285 | 0.729 ±0.005 |
| sieve | 59.891 ±0.130 | 90.102 ±0.547 | 1.336 ±0.006 |
| sorting | 392.914 ±1.432 | 378.306 ±2.098 | 112.664 ±0.089 |
| sudoku | 47.655 ±0.286 | 95.764 ±0.292 | 8.645 ±0.033 |
| maze | 49.791 ±1.298 | 150.353 ±0.362 | 0.882 ±0.051 |
| vm | 60.073 ±0.875 | 138.686 ±0.263 | 0.894 ±0.009 |
| life | 65.811 ±1.209 | 125.019 ±0.183 | 20.465 ±0.088 |

## Supplement: Wasm entrypoint

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.190 ±0.001 | 0.120 ±0.001 |
| tour | 25.172 ±0.427 | 1.046 ±0.006 |
| functions | 26.812 ±0.195 | 1.009 ±0.005 |
| errors | 5.538 ±0.040 | 0.834 ±0.005 |
| sieve | 16.306 ±0.572 | 2.020 ±0.005 |
| sorting | 357.151 ±0.764 | 159.423 ±0.035 |
| sudoku | 19.255 ±0.119 | 11.508 ±0.042 |
| maze | 21.445 ±0.477 | 0.774 ±0.001 |
| vm | 28.101 ±0.079 | 0.906 ±0.007 |
| life | 37.246 ±0.494 | 27.150 ±0.026 |

## Supplement: Wasm engine compilation and instantiation

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.274 ±0.012 | 4.134 ±0.017 |
| tour | 0.562 ±0.035 | 57.344 ±0.074 |
| functions | 1.153 ±0.024 | 179.194 ±1.836 |
| errors | 0.640 ±0.009 | 53.984 ±0.171 |
| sieve | 0.369 ±0.016 | 22.978 ±0.011 |
| sorting | 1.106 ±0.016 | 150.869 ±0.307 |
| sudoku | 0.353 ±0.006 | 19.755 ±0.017 |
| maze | 0.721 ±0.028 | 84.392 ±0.077 |
| vm | 0.576 ±0.006 | 72.353 ±0.120 |
| life | 0.429 ±0.014 | 32.912 ±0.077 |

The entrypoint interval includes Goose initialization, host output callbacks and any lazy JIT work. It excludes final Wasm-host output concatenation/delivery. Native Goose prints unbuffered, so no native entrypoint column or cross-boundary speedup is presented. Process time minus engine time also includes loading, bookkeeping and teardown; it is not a pure startup measurement.

These fresh-process examples have different timing rules from LangArena's warmed computational regions. Raw samples, commands, artifact/source/compiler identities and engine versions are in [report.json](report.json). [Method and reproduction](../../../examples.md).
