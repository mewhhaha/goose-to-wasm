# Example program benchmarks

Status: **passed**.

2026-11-05 · AMD Ryzen 7 3800X 8-Core Processor.

Goose O2. Direct Wasm uses memory32; Native C is emitted by the Goose compiler. The selected programs, their constant inputs and all printing are unchanged from the [example catalog](../../../../examples/README.md). Compiler constant folding is allowed.

Builds are complete uncached Python-driver invocations, including any C compilation/linking. OS page caches remain warm.

Runtime is **whole-process launch-to-exit time**, including host startup, Wasm compilation/instantiation, program initialization, computation, output delivery and teardown. Each observation starts a fresh process/instance and calls the entrypoint once. This measures CLI cost, not warmed kernel throughput.

Each cell has 5 build samples or 5 runtime samples. Untimed fresh-process warmups per runtime cell: 1. Orders are shuffled with the recorded seed; builds and runtime never overlap. Every used artifact must pass its golden output. Values are median milliseconds ± median absolute deviation (MAD).

Headline runtime samples use the ordinary runners without timing-file instrumentation. The Wasm supplements use a separate shuffled set of fresh processes, with the same sample count; timing files are written after their engine intervals end.

## Compilation

| Example | Direct Wasm | Goose Native C |
| --- | ---: | ---: |
| squares | 53.165 ±1.745 | 263.248 ±2.805 |
| tour | 67.227 ±1.075 | 1004.177 ±30.498 |
| functions | 137.972 ±1.094 | 1675.702 ±11.249 |
| errors | 93.187 ±5.058 | 865.139 ±13.569 |
| sieve | 76.611 ±1.042 | 416.917 ±5.186 |
| sorting | 140.387 ±0.678 | 1933.798 ±18.773 |
| sudoku | 78.880 ±0.844 | 498.573 ±12.077 |
| maze | 92.146 ±0.173 | 760.569 ±17.336 |
| vm | 97.108 ±12.640 | 642.439 ±29.644 |
| life | 82.585 ±2.335 | 546.057 ±2.169 |

## Whole-process runtime

| Example | Direct / V8 | Direct / Wasmtime | Goose Native C |
| --- | ---: | ---: | ---: |
| squares | 26.575 ±0.526 | 71.108 ±0.144 | 0.836 ±0.007 |
| tour | 57.828 ±0.507 | 130.156 ±0.752 | 0.827 ±0.051 |
| functions | 62.949 ±1.321 | 256.573 ±0.774 | 0.928 ±0.024 |
| errors | 36.244 ±1.130 | 124.811 ±0.233 | 0.772 ±0.017 |
| sieve | 64.128 ±0.128 | 93.940 ±0.442 | 1.994 ±0.025 |
| sorting | 425.147 ±1.569 | 405.236 ±3.164 | 121.677 ±0.691 |
| sudoku | 48.920 ±0.252 | 100.154 ±0.447 | 9.155 ±0.042 |
| maze | 51.934 ±0.165 | 157.976 ±0.527 | 0.891 ±0.051 |
| vm | 62.786 ±1.214 | 145.931 ±0.991 | 0.930 ±0.005 |
| life | 68.831 ±0.649 | 131.175 ±0.120 | 21.168 ±0.149 |

## Supplement: Wasm entrypoint

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.202 ±0.003 | 0.124 ±0.002 |
| tour | 25.565 ±0.345 | 1.091 ±0.003 |
| functions | 27.623 ±0.253 | 1.044 ±0.009 |
| errors | 5.749 ±0.219 | 0.880 ±0.001 |
| sieve | 15.953 ±0.375 | 2.113 ±0.010 |
| sorting | 385.001 ±1.347 | 174.937 ±0.552 |
| sudoku | 20.384 ±0.343 | 12.277 ±0.046 |
| maze | 22.783 ±0.169 | 0.799 ±0.007 |
| vm | 28.991 ±0.075 | 0.941 ±0.005 |
| life | 39.819 ±0.208 | 28.886 ±0.057 |

## Supplement: Wasm engine compilation and instantiation

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.281 ±0.011 | 4.182 ±0.005 |
| tour | 0.576 ±0.028 | 60.553 ±0.099 |
| functions | 1.146 ±0.015 | 186.919 ±0.346 |
| errors | 0.596 ±0.003 | 56.685 ±0.153 |
| sieve | 0.387 ±0.019 | 23.929 ±0.067 |
| sorting | 1.198 ±0.041 | 158.852 ±0.508 |
| sudoku | 0.418 ±0.039 | 20.532 ±0.049 |
| maze | 0.774 ±0.019 | 90.076 ±1.685 |
| vm | 0.596 ±0.012 | 75.856 ±0.188 |
| life | 0.512 ±0.019 | 34.388 ±0.057 |

The entrypoint interval includes Goose initialization, host output callbacks and any lazy JIT work. It excludes final Wasm-host output concatenation/delivery. Native Goose prints unbuffered, so no native entrypoint column or cross-boundary speedup is presented. Process time minus engine time also includes loading, bookkeeping and teardown; it is not a pure startup measurement.

These fresh-process examples have different timing rules from LangArena's warmed computational regions. Raw samples, commands, artifact/source/compiler identities and engine versions are in [report.json](report.json). [Method and reproduction](../../../examples.md).
