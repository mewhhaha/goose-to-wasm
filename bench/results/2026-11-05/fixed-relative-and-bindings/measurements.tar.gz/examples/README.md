# Example program benchmarks

Status: **passed**.

2026-11-05 · AMD Ryzen 7 3800X; pinned CPU 7.

Goose O2. Direct Wasm uses memory32; Native C is emitted by the Goose compiler. The selected programs, their constant inputs and all printing are unchanged from the [example catalog](../../../../examples/README.md). Compiler constant folding is allowed.

Builds are complete uncached Python-driver invocations, including any C compilation/linking. OS page caches remain warm.

Runtime is **whole-process launch-to-exit time**, including host startup, Wasm compilation/instantiation, program initialization, computation, output delivery and teardown. Each observation starts a fresh process/instance and calls the entrypoint once. This measures CLI cost, not warmed kernel throughput.

Each cell has 5 build samples or 5 runtime samples. Untimed fresh-process warmups per runtime cell: 1. Orders are shuffled with the recorded seed; builds and runtime never overlap. Every used artifact must pass its golden output. Values are median milliseconds ± median absolute deviation (MAD).

Headline runtime samples use the ordinary runners without timing-file instrumentation. The Wasm supplements use a separate shuffled set of fresh processes, with the same sample count; timing files are written after their engine intervals end.

## Compilation

| Example | Direct Wasm | Goose Native C |
| --- | ---: | ---: |
| squares | 50.167 ±0.526 | 255.870 ±8.580 |
| tour | 57.877 ±0.709 | 929.981 ±17.536 |
| functions | 124.612 ±0.643 | 1559.155 ±12.373 |
| errors | 78.067 ±0.621 | 716.113 ±0.983 |
| sieve | 69.286 ±0.268 | 388.488 ±2.180 |
| sorting | 126.035 ±0.474 | 1702.367 ±10.967 |
| sudoku | 71.592 ±0.188 | 464.018 ±3.933 |
| maze | 85.048 ±0.063 | 706.429 ±8.885 |
| vm | 79.524 ±0.372 | 588.849 ±0.869 |
| life | 75.966 ±2.693 | 559.946 ±17.458 |

## Whole-process runtime

| Example | Direct / V8 | Direct / Wasmtime | Goose Native C |
| --- | ---: | ---: | ---: |
| squares | 28.240 ±0.166 | 69.179 ±0.138 | 0.815 ±0.021 |
| tour | 57.048 ±0.773 | 116.292 ±0.060 | 0.769 ±0.040 |
| functions | 62.983 ±0.946 | 243.608 ±0.433 | 0.906 ±0.012 |
| errors | 31.421 ±0.418 | 103.434 ±0.412 | 0.736 ±0.005 |
| sieve | 55.071 ±0.771 | 84.290 ±0.367 | 1.333 ±0.014 |
| sorting | 404.040 ±3.564 | 384.094 ±0.981 | 114.985 ±0.190 |
| sudoku | 47.157 ±1.573 | 96.592 ±0.390 | 8.675 ±0.072 |
| maze | 50.771 ±1.445 | 152.076 ±0.361 | 0.850 ±0.072 |
| vm | 61.227 ±2.262 | 139.673 ±0.119 | 0.886 ±0.008 |
| life | 67.355 ±0.865 | 125.794 ±0.054 | 20.768 ±0.106 |

## Supplement: Wasm entrypoint

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.203 ±0.001 | 0.123 ±0.003 |
| tour | 24.983 ±0.059 | 1.786 ±0.013 |
| functions | 28.940 ±0.022 | 1.342 ±0.024 |
| errors | 4.244 ±0.044 | 0.844 ±0.010 |
| sieve | 15.373 ±1.304 | 2.453 ±0.026 |
| sorting | 370.257 ±4.983 | 164.758 ±0.223 |
| sudoku | 19.550 ±1.008 | 11.733 ±0.018 |
| maze | 22.513 ±0.833 | 0.778 ±0.001 |
| vm | 28.568 ±0.113 | 0.908 ±0.003 |
| life | 38.179 ±0.614 | 27.535 ±0.034 |

## Supplement: Wasm engine compilation and instantiation

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.282 ±0.014 | 4.174 ±0.011 |
| tour | 0.488 ±0.025 | 48.581 ±0.106 |
| functions | 1.094 ±0.011 | 175.633 ±0.386 |
| errors | 0.485 ±0.026 | 37.785 ±0.115 |
| sieve | 0.390 ±0.024 | 16.681 ±0.058 |
| sorting | 1.130 ±0.036 | 149.464 ±0.357 |
| sudoku | 0.404 ±0.016 | 19.993 ±0.170 |
| maze | 0.741 ±0.022 | 87.177 ±0.599 |
| vm | 0.579 ±0.001 | 73.225 ±0.327 |
| life | 0.477 ±0.019 | 33.230 ±0.018 |

The entrypoint interval includes Goose initialization, host output callbacks and any lazy JIT work. It excludes final Wasm-host output concatenation/delivery. Native Goose prints unbuffered, so no native entrypoint column or cross-boundary speedup is presented. Process time minus engine time also includes loading, bookkeeping and teardown; it is not a pure startup measurement.

These fresh-process examples have different timing rules from LangArena's warmed computational regions. Raw samples, commands, artifact/source/compiler identities and engine versions are in [report.json](report.json). [Method and reproduction](../../../examples.md).
