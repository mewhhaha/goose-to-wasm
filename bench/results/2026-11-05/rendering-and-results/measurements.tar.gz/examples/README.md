# Example program benchmarks

Status: **passed**.

2026-11-05 · AMD Ryzen 7 3800X 8-Core Processor.

Goose O2. Direct Wasm uses memory32; Native C is emitted by the Goose compiler. The selected programs, their constant inputs and all printing are unchanged from the [example catalog](../../../../examples/README.md). Compiler constant folding is allowed.

Builds are complete uncached Python-driver invocations, including any C compilation/linking. OS page caches remain warm.

Runtime is **whole-process launch-to-exit time**, including host startup, Wasm compilation/instantiation, program initialization, computation, output delivery and teardown. Each observation starts a fresh process/instance and calls the entrypoint once. This measures CLI cost, not warmed kernel throughput.

Each cell has 5 build samples or 5 runtime samples. Untimed fresh-process warmups per runtime cell: 1. Orders are shuffled with the recorded seed; builds and runtime never overlap. Every used artifact must pass its golden output. Values are median milliseconds ± median absolute deviation (MAD).

Headline runtime samples use the ordinary runners without timing-file instrumentation. The Wasm supplements use a separate shuffled set of fresh processes, with the same sample count; timing files are written after their engine intervals end.

## Compilation

| Example | Direct Wasm | Goose Native C |
| --- | ---: | ---: |
| squares | 52.078 ±1.696 | 268.103 ±4.207 |
| tour | 70.187 ±2.013 | 1007.925 ±18.612 |
| functions | 137.062 ±2.839 | 1655.333 ±18.412 |
| errors | 81.526 ±0.600 | 843.723 ±55.844 |
| sieve | 74.896 ±0.336 | 422.254 ±3.171 |
| sorting | 131.440 ±0.321 | 1830.837 ±10.402 |
| sudoku | 76.910 ±3.247 | 497.884 ±4.672 |
| maze | 88.008 ±0.797 | 766.262 ±10.160 |
| vm | 84.359 ±1.389 | 658.958 ±10.686 |
| life | 77.036 ±1.841 | 603.379 ±13.510 |

## Whole-process runtime

| Example | Direct / V8 | Direct / Wasmtime | Goose Native C |
| --- | ---: | ---: | ---: |
| squares | 27.905 ±1.336 | 73.385 ±0.509 | 0.830 ±0.052 |
| tour | 65.483 ±2.717 | 178.088 ±2.026 | 0.936 ±0.012 |
| functions | 64.769 ±1.052 | 280.131 ±2.167 | 0.991 ±0.010 |
| errors | 32.918 ±0.283 | 109.661 ±2.021 | 0.764 ±0.006 |
| sieve | 65.857 ±2.402 | 105.613 ±1.294 | 1.391 ±0.011 |
| sorting | 430.754 ±6.087 | 415.767 ±10.526 | 125.287 ±3.472 |
| sudoku | 52.735 ±2.121 | 107.727 ±3.906 | 9.029 ±0.029 |
| maze | 53.806 ±0.918 | 160.768 ±1.327 | 0.848 ±0.037 |
| vm | 65.189 ±1.512 | 146.833 ±0.426 | 0.952 ±0.025 |
| life | 71.213 ±1.862 | 132.910 ±3.263 | 21.717 ±0.245 |

## Supplement: Wasm entrypoint

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.212 ±0.002 | 0.132 ±0.003 |
| tour | 35.513 ±2.700 | 1.090 ±0.013 |
| functions | 34.439 ±2.944 | 1.061 ±0.009 |
| errors | 4.183 ±0.031 | 0.860 ±0.002 |
| sieve | 18.637 ±0.509 | 2.149 ±0.033 |
| sorting | 391.172 ±5.346 | 176.456 ±2.044 |
| sudoku | 18.803 ±0.354 | 12.525 ±0.011 |
| maze | 22.990 ±0.406 | 0.812 ±0.002 |
| vm | 30.377 ±0.665 | 0.956 ±0.004 |
| life | 39.492 ±0.314 | 29.157 ±0.321 |

## Supplement: Wasm engine compilation and instantiation

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.276 ±0.006 | 4.824 ±0.095 |
| tour | 0.811 ±0.039 | 103.902 ±1.950 |
| functions | 1.209 ±0.015 | 199.361 ±0.995 |
| errors | 0.475 ±0.001 | 39.090 ±0.122 |
| sieve | 0.492 ±0.006 | 32.559 ±0.037 |
| sorting | 1.252 ±0.023 | 163.409 ±0.404 |
| sudoku | 0.367 ±0.008 | 20.935 ±0.340 |
| maze | 0.717 ±0.005 | 88.414 ±0.188 |
| vm | 0.614 ±0.014 | 76.686 ±0.447 |
| life | 0.440 ±0.009 | 34.847 ±0.713 |

The entrypoint interval includes Goose initialization, host output callbacks and any lazy JIT work. It excludes final Wasm-host output concatenation/delivery. Native Goose prints unbuffered, so no native entrypoint column or cross-boundary speedup is presented. Process time minus engine time also includes loading, bookkeeping and teardown; it is not a pure startup measurement.

These fresh-process examples have different timing rules from LangArena's warmed computational regions. Raw samples, commands, artifact/source/compiler identities and engine versions are in [report.json](report.json). [Method and reproduction](../../../examples.md).
