(module
 (type $0 (func (param i64)))
 (type $1 (func))
 (type $2 (func (param i32)))
 (type $3 (func (result i64)))
 (type $4 (func (param i32 i32)))
 (type $5 (func (param f64)))
 (type $6 (func (param f32)))
 (type $7 (func (param i32 i32 i32)))
 (type $8 (func (param i64) (result i64)))
 (type $9 (func (param i32 i64)))
 (import "goose" "write" (func $goose.write (param i32 i32)))
 (import "goose" "print_i64" (func $goose.print_i64 (param i64)))
 (import "goose" "print_u64" (func $goose.print_u64 (param i64)))
 (import "goose" "print_f64" (func $goose.print_f64 (param f64)))
 (import "goose" "print_f32" (func $goose.print_f32 (param f32)))
 (import "goose" "print_bool" (func $goose.print_bool (param i32)))
 (import "goose" "newline" (func $goose.newline))
 (import "goose" "abort" (func $goose.abort (param i32 i32 i32)))
 (import "goose" "exit" (func $goose.exit (param i32)))
 (import "env" "bench_input" (func $env.bench_input (result i64)))
 (import "env" "bench_barrier" (func $env.bench_barrier (param i64) (result i64)))
 (import "env" "bench_clock" (func $env.bench_clock (result i64)))
 (import "env" "bench_sink" (func $env.bench_sink (param i64)))
 (global $global$0 (mut i32) (i32.const 1001392))
 (memory $0 16 256)
 (data $0 (i32.const 1001256) "assertion failedslice bounds out of rangearray index out of boundsdivision by zeroactivation frame overflowlinear memory exhausted")
 (export "memory" (memory $0))
 (export "_start" (func $_start))
 (func $main#0
  (local $0 i32)
  (local $1 i64)
  (local $2 i64)
  (local $3 i64)
  (local $4 i64)
  (local $5 i64)
  (local $6 i64)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 i64)
  (local $12 i64)
  (local $13 i32)
  (local $14 i32)
  (local $15 i32)
  (local $16 i32)
  (local $17 i32)
  (local $18 i32)
  (local $19 i32)
  (local $20 i64)
  (local $21 i64)
  (local $22 i64)
  (local $23 i64)
  (local $24 i64)
  (local $25 i64)
  (local $26 i64)
  (local $27 i64)
  (local $28 i64)
  (local $29 i64)
  (local $30 i64)
  (local $31 i64)
  (local $32 i32)
  (local $33 i32)
  (local $34 i64)
  (local $35 i64)
  (local $36 i64)
  (local $37 i64)
  (local $38 i64)
  (local $39 i64)
  (local $40 i32)
  (local $41 i32)
  (local $42 i32)
  (local $43 i32)
  (local $44 i64)
  (local $45 i64)
  (local $46 i32)
  (local $47 i32)
  (local $48 f64)
  (local $49 i64)
  (local $50 i32)
  (local $51 i64)
  (local $52 i64)
  (local $53 i32)
  (local $54 i32)
  (local $55 i64)
  (local $56 i64)
  (local $57 i64)
  (local $58 i64)
  (local $59 i32)
  (local $60 i64)
  (local $61 i64)
  (local $62 i64)
  (local $63 i64)
  (local $64 i64)
  (local $65 i64)
  (local $66 i64)
  (local $67 i64)
  (local $68 i64)
  (local $69 i64)
  (local $70 i32)
  (local $71 i32)
  (local $72 i64)
  (local $73 i64)
  (local $74 i32)
  (local $75 i32)
  (local $76 i32)
  (local $77 i64)
  (local $78 i32)
  (local $scratch i32)
  (local.set $0
   (global.get $global$0)
  )
  (local.set $78
   (i32.add
    (local.get $0)
    (i32.const 24)
   )
  )
  (if
   (i32.lt_u
    (local.get $78)
    (local.get $0)
   )
   (then
    (call $goose.abort
     (i32.const 1001338)
     (i32.const 25)
     (i32.const 36)
    )
    (unreachable)
   )
  )
  (if
   (i32.gt_u
    (local.get $78)
    (i32.shl
     (memory.size)
     (i32.const 16)
    )
   )
   (then
    (if
     (i32.eq
      (memory.grow
       (i32.sub
        (i32.add
         (i32.shr_u
          (local.get $78)
          (i32.const 16)
         )
         (i32.eqz
          (i32.eqz
           (i32.and
            (local.get $78)
            (i32.const 65535)
           )
          )
         )
        )
        (memory.size)
       )
      )
      (i32.const -1)
     )
     (then
      (call $goose.abort
       (i32.const 1001363)
       (i32.const 23)
       (i32.const 36)
      )
      (unreachable)
     )
    )
   )
  )
  (global.set $global$0
   (local.get $78)
  )
  (block
   (local.set $2
    (call $env.bench_input)
   )
   (local.set $1
    (local.get $2)
   )
   (local.set $4
    (call $env.bench_input)
   )
   (local.set $3
    (local.get $4)
   )
   (local.set $6
    (call $env.bench_input)
   )
   (local.set $5
    (local.get $6)
   )
   (if
    (i32.eqz
     (i32.eqz
      (i32.eqz
       (if (result i32)
        (i32.eqz
         (i32.eqz
          (if (result i32)
           (i32.eqz
            (i32.eqz
             (if (result i32)
              (i32.eqz
               (i32.eqz
                (i64.ge_s
                 (local.get $1)
                 (i64.const 1)
                )
               )
              )
              (then
               (local.set $7
                (i32.eqz
                 (i32.eqz
                  (i64.le_s
                   (local.get $1)
                   (i64.const 1000000)
                  )
                 )
                )
               )
               (local.get $7)
              )
              (else
               (i32.const 0)
              )
             )
            )
           )
           (then
            (local.set $8
             (i32.eqz
              (i32.eqz
               (i64.gt_s
                (local.get $3)
                (i64.const 0)
               )
              )
             )
            )
            (local.get $8)
           )
           (else
            (i32.const 0)
           )
          )
         )
        )
        (then
         (local.set $9
          (i32.eqz
           (i32.eqz
            (i64.ge_s
             (local.get $5)
             (i64.const 0)
            )
           )
          )
         )
         (local.get $9)
        )
        (else
         (i32.const 0)
        )
       )
      )
     )
    )
    (then
     (call $goose.abort
      (i32.const 1001256)
      (i32.const 16)
      (i32.const 40)
     )
     (unreachable)
    )
   )
   (block
    (local.set $10
     (i32.const 42)
    )
    (i32.store align=1
     (i32.const 1240)
     (local.get $10)
    )
   )
   (memory.fill
    (i32.add
     (local.get $0)
     (i32.const 12)
    )
    (i32.const 0)
    (i32.const 12)
   )
   (local.set $11
    (local.get $1)
   )
   (local.set $12
    (local.get $11)
   )
   (i64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 12)
    )
    (local.get $12)
   )
   (local.set $13
    (i32.const 0)
   )
   (local.set $14
    (local.get $13)
   )
   (i32.store align=1
    (i32.add
     (local.get $0)
     (i32.const 20)
    )
    (local.get $14)
   )
   (local.set $15
    (i32.add
     (local.get $0)
     (i32.const 12)
    )
   )
   (local.set $16
    (local.get $15)
   )
   (memory.copy
    (local.get $0)
    (local.get $16)
    (i32.const 12)
   )
   (block
    (local.set $17
     (i32.const 42)
    )
    (i32.store align=1
     (i32.const 1240)
     (local.get $17)
    )
   )
   (block
    (local.set $19
     (local.get $0)
    )
    (local.set $18
     (local.get $19)
    )
    (block
     (local.set $21
      (i64.or
       (i64.extend_i32_u
        (i32.const 1256)
       )
       (i64.const 4294967296000000)
      )
     )
     (local.set $22
      (i64.shr_u
       (local.get $21)
       (i64.const 32)
      )
     )
     (local.set $23
      (i64.const 0)
     )
     (local.set $24
      (i64.load align=1
       (local.get $18)
      )
     )
     (if
      (i32.or
       (i64.gt_u
        (local.get $23)
        (local.get $24)
       )
       (i64.gt_u
        (local.get $24)
        (local.get $22)
       )
      )
      (then
       (call $goose.abort
        (i32.const 1001272)
        (i32.const 25)
        (i32.const 12)
       )
       (unreachable)
      )
     )
     (local.set $25
      (i64.or
       (i64.extend_i32_u
        (i32.add
         (i32.wrap_i64
          (local.get $21)
         )
         (i32.mul
          (i32.wrap_i64
           (local.get $23)
          )
          (i32.const 1)
         )
        )
       )
       (i64.shl
        (i64.sub
         (local.get $24)
         (local.get $23)
        )
        (i64.const 32)
       )
      )
     )
     (local.set $20
      (local.get $25)
     )
     (local.set $27
      (i64.const 0)
     )
     (local.set $28
      (i64.shr_u
       (local.get $20)
       (i64.const 32)
      )
     )
     (local.set $29
      (i64.const 0)
     )
     (block $block
      (loop $label
       (br_if $block
        (i64.ge_s
         (local.get $27)
         (local.get $28)
        )
       )
       (local.set $26
        (local.get $27)
       )
       (block
        (local.set $30
         (local.get $20)
        )
        (local.set $31
         (local.get $26)
        )
        (local.set $32
         (i32.add
          (i32.wrap_i64
           (local.get $30)
          )
          (i32.mul
           (i32.wrap_i64
            (local.get $31)
           )
           (i32.const 1)
          )
         )
        )
        (local.set $33
         (i32.and
          (i32.and
           (i32.const 0)
           (i32.const 255)
          )
          (i32.const 255)
         )
        )
        (i32.store8
         (local.get $32)
         (local.get $33)
        )
       )
       (local.set $27
        (i64.add
         (local.get $27)
         (i64.const 1)
        )
       )
       (local.set $29
        (i64.add
         (local.get $29)
         (i64.const 1)
        )
       )
       (br $label)
      )
     )
    )
    (local.set $35
     (i64.const 0)
    )
    (local.set $36
     (i64.load align=1
      (local.get $18)
     )
    )
    (local.set $37
     (i64.const 0)
    )
    (block $block1
     (loop $label1
      (br_if $block1
       (i64.ge_s
        (local.get $35)
        (local.get $36)
       )
      )
      (local.set $34
       (local.get $35)
      )
      (block
       (local.set $38
        (i64.or
         (i64.extend_i32_u
          (i32.const 1256)
         )
         (i64.const 4294967296000000)
        )
       )
       (local.set $39
        (local.get $34)
       )
       (if
        (i64.ge_u
         (local.get $39)
         (i64.shr_u
          (local.get $38)
          (i64.const 32)
         )
        )
        (then
         (call $goose.abort
          (i32.const 1001297)
          (i32.const 25)
          (i32.const 13)
         )
         (unreachable)
        )
       )
       (local.set $40
        (i32.add
         (i32.wrap_i64
          (local.get $38)
         )
         (i32.mul
          (i32.wrap_i64
           (local.get $39)
          )
          (i32.const 1)
         )
        )
       )
       (block $block2
        (local.set $43
         (block (result i32)
          (local.set $scratch
           (i32.add
            (i32.mul
             (i32.load align=1
              (i32.const 1240)
             )
             (i32.const 3877)
            )
            (i32.const 29573)
           )
          )
          (local.set $42
           (i32.const 139968)
          )
          (local.get $scratch)
         )
        )
        (if
         (i32.eqz
          (local.get $42)
         )
         (then
          (call $goose.abort
           (i32.const 1001322)
           (i32.const 16)
           (i32.const 18)
          )
          (unreachable)
         )
        )
        (local.set $44
         (i64.rem_s
          (i64.extend_i32_s
           (local.get $43)
          )
          (i64.extend_i32_s
           (local.get $42)
          )
         )
        )
        (if
         (i64.lt_s
          (local.get $44)
          (i64.const 0)
         )
         (then
          (local.set $44
           (i64.add
            (local.get $44)
            (block (result i64)
             (local.set $45
              (i64.extend_i32_s
               (local.get $42)
              )
             )
             (if (result i64)
              (i64.lt_s
               (local.get $45)
               (i64.const 0)
              )
              (then
               (i64.sub
                (i64.const 0)
                (local.get $45)
               )
              )
              (else
               (local.get $45)
              )
             )
            )
           )
          )
         )
        )
        (local.set $46
         (i32.wrap_i64
          (local.get $44)
         )
        )
        (i32.store align=1
         (i32.const 1240)
         (local.get $46)
        )
        (local.set $47
         (i32.load align=1
          (i32.const 1240)
         )
        )
        (local.set $48
         (f64.mul
          (f64.div
           (f64.convert_i32_s
            (local.get $47)
           )
           (f64.const 139968)
          )
          (f64.const 256)
         )
        )
        (local.set $49
         (i64.reinterpret_f64
          (local.get $48)
         )
        )
        (local.set $50
         (i32.sub
          (i32.wrap_i64
           (i64.and
            (i64.shr_u
             (local.get $49)
             (i64.const 52)
            )
            (i64.const 2047)
           )
          )
          (i32.const 1023)
         )
        )
        (local.set $41
         (i32.wrap_i64
          (if (result i64)
           (i32.or
            (i32.lt_s
             (local.get $50)
             (i32.const 0)
            )
            (i32.ge_s
             (local.get $50)
             (i32.const 116)
            )
           )
           (then
            (i64.const 0)
           )
           (else
            (local.set $51
             (i64.or
              (i64.and
               (local.get $49)
               (i64.const 4503599627370495)
              )
              (i64.const 4503599627370496)
             )
            )
            (local.set $52
             (if (result i64)
              (i32.lt_s
               (local.get $50)
               (i32.const 52)
              )
              (then
               (i64.shr_u
                (local.get $51)
                (i64.extend_i32_u
                 (i32.sub
                  (i32.const 52)
                  (local.get $50)
                 )
                )
               )
              )
              (else
               (i64.shl
                (local.get $51)
                (i64.extend_i32_u
                 (i32.sub
                  (local.get $50)
                  (i32.const 52)
                 )
                )
               )
              )
             )
            )
            (if (result i64)
             (i64.lt_s
              (local.get $49)
              (i64.const 0)
             )
             (then
              (i64.sub
               (i64.const 0)
               (local.get $52)
              )
             )
             (else
              (local.get $52)
             )
            )
           )
          )
         )
        )
        (br $block2)
       )
       (local.set $53
        (local.get $41)
       )
       (local.set $54
        (i32.and
         (i32.and
          (i32.and
           (local.get $53)
           (i32.const 255)
          )
          (i32.const 255)
         )
         (i32.const 255)
        )
       )
       (i32.store8
        (local.get $40)
        (local.get $54)
       )
      )
      (local.set $35
       (i64.add
        (local.get $35)
        (i64.const 1)
       )
      )
      (local.set $37
       (i64.add
        (local.get $37)
        (i64.const 1)
       )
      )
      (br $label1)
     )
    )
   )
   (local.set $56
    (i64.const 0)
   )
   (local.set $57
    (local.get $5)
   )
   (local.set $58
    (i64.const 0)
   )
   (block $block3
    (loop $label2
     (br_if $block3
      (i64.ge_s
       (local.get $56)
       (local.get $57)
      )
     )
     (local.set $55
      (local.get $56)
     )
     (block
      (call $run#6
       (local.get $0)
       (local.get $55)
      )
     )
     (local.set $56
      (i64.add
       (local.get $56)
       (i64.const 1)
      )
     )
     (local.set $58
      (i64.add
       (local.get $58)
       (i64.const 1)
      )
     )
     (br $label2)
    )
   )
   (block
    (local.set $59
     (i32.const 42)
    )
    (i32.store align=1
     (i32.const 1240)
     (local.get $59)
    )
   )
   (local.set $61
    (call $env.bench_barrier
     (local.get $3)
    )
   )
   (local.set $60
    (local.get $61)
   )
   (local.set $63
    (call $env.bench_clock)
   )
   (local.set $62
    (local.get $63)
   )
   (local.set $65
    (i64.const 0)
   )
   (local.set $66
    (local.get $60)
   )
   (local.set $67
    (i64.const 0)
   )
   (block $block4
    (loop $label3
     (br_if $block4
      (i64.ge_s
       (local.get $65)
       (local.get $66)
      )
     )
     (local.set $64
      (local.get $65)
     )
     (block
      (call $run#6
       (local.get $0)
       (local.get $64)
      )
     )
     (local.set $65
      (i64.add
       (local.get $65)
       (i64.const 1)
      )
     )
     (local.set $67
      (i64.add
       (local.get $67)
       (i64.const 1)
      )
     )
     (br $label3)
    )
   )
   (local.set $69
    (i64.sub
     (call $env.bench_clock)
     (local.get $62)
    )
   )
   (local.set $68
    (local.get $69)
   )
   (block
    (local.set $71
     (i32.load align=1
      (i32.add
       (local.get $0)
       (i32.const 8)
      )
     )
    )
    (local.set $70
     (local.get $71)
    )
    (local.set $73
     (local.get $68)
    )
    (local.set $72
     (local.get $73)
    )
    (call $env.bench_sink
     (i64.extend_i32_u
      (local.get $70)
     )
    )
    (local.set $74
     (global.get $global$0)
    )
    (local.set $75
     (local.get $70)
    )
    (call $goose.print_u64
     (i64.extend_i32_u
      (local.get $75)
     )
    )
    (call $goose.newline)
    (global.set $global$0
     (local.get $74)
    )
    (local.set $76
     (global.get $global$0)
    )
    (local.set $77
     (local.get $72)
    )
    (call $goose.print_i64
     (local.get $77)
    )
    (call $goose.newline)
    (global.set $global$0
     (local.get $76)
    )
   )
  )
  (global.set $global$0
   (local.get $0)
  )
 )
 (func $run#6 (param $0 i32) (param $1 i64)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i64)
  (local $6 i64)
  (local $7 i64)
  (local $8 i64)
  (local $9 i64)
  (local $10 i64)
  (local $11 i32)
  (local $12 i32)
  (local $13 i32)
  (local $14 i64)
  (local $15 i64)
  (local $16 i64)
  (local $17 i64)
  (local $18 i32)
  (local $19 i32)
  (local $20 i32)
  (local $21 i32)
  (local.set $2
   (global.get $global$0)
  )
  (block
   (block $block1
    (local.set $6
     (i64.or
      (i64.extend_i32_u
       (i32.const 1256)
      )
      (i64.const 4294967296000000)
     )
    )
    (local.set $7
     (i64.shr_u
      (local.get $6)
      (i64.const 32)
     )
    )
    (local.set $8
     (i64.const 0)
    )
    (local.set $9
     (i64.load align=1
      (local.get $0)
     )
    )
    (if
     (i32.or
      (i64.gt_u
       (local.get $8)
       (local.get $9)
      )
      (i64.gt_u
       (local.get $9)
       (local.get $7)
      )
     )
     (then
      (call $goose.abort
       (i32.const 1001272)
       (i32.const 25)
       (i32.const 32)
      )
      (unreachable)
     )
    )
    (local.set $10
     (i64.or
      (i64.extend_i32_u
       (i32.add
        (i32.wrap_i64
         (local.get $6)
        )
        (i32.mul
         (i32.wrap_i64
          (local.get $8)
         )
         (i32.const 1)
        )
       )
      )
      (i64.shl
       (i64.sub
        (local.get $9)
        (local.get $8)
       )
       (i64.const 32)
      )
     )
    )
    (local.set $5
     (local.get $10)
    )
    (local.set $12
     (i32.const -1)
    )
    (local.set $11
     (local.get $12)
    )
    (local.set $14
     (local.get $5)
    )
    (local.set $15
     (i64.const 0)
    )
    (local.set $16
     (i64.shr_u
      (local.get $14)
      (i64.const 32)
     )
    )
    (local.set $17
     (i64.const 0)
    )
    (block $block
     (loop $label
      (br_if $block
       (i64.ge_s
        (local.get $15)
        (local.get $16)
       )
      )
      (local.set $13
       (i32.and
        (i32.load8_u
         (i32.add
          (i32.wrap_i64
           (local.get $14)
          )
          (i32.mul
           (i32.wrap_i64
            (local.get $15)
           )
           (i32.const 1)
          )
         )
        )
        (i32.const 255)
       )
      )
      (block
       (local.set $11
        (i32.xor
         (local.get $11)
         (local.get $13)
        )
       )
       (local.set $18
        (local.get $11)
       )
       (local.set $11
        (i32.xor
         (i32.xor
          (i32.xor
           (i32.shr_u
            (local.get $18)
            (i32.const 8)
           )
           (i32.and
            (i32.sub
             (i32.const 0)
             (i32.and
              (local.get $18)
              (i32.const 1)
             )
            )
            (i32.const 1996959894)
           )
          )
          (i32.xor
           (i32.and
            (i32.sub
             (i32.const 0)
             (i32.and
              (i32.shr_u
               (local.get $18)
               (i32.const 1)
              )
              (i32.const 1)
             )
            )
            (i32.const -301047508)
           )
           (i32.and
            (i32.sub
             (i32.const 0)
             (i32.and
              (i32.shr_u
               (local.get $18)
               (i32.const 2)
              )
              (i32.const 1)
             )
            )
            (i32.const 124634137)
           )
          )
         )
         (i32.xor
          (i32.xor
           (i32.and
            (i32.sub
             (i32.const 0)
             (i32.and
              (i32.shr_u
               (local.get $18)
               (i32.const 3)
              )
              (i32.const 1)
             )
            )
            (i32.const 249268274)
           )
           (i32.and
            (i32.sub
             (i32.const 0)
             (i32.and
              (i32.shr_u
               (local.get $18)
               (i32.const 4)
              )
              (i32.const 1)
             )
            )
            (i32.const 498536548)
           )
          )
          (i32.xor
           (i32.and
            (i32.sub
             (i32.const 0)
             (i32.and
              (i32.shr_u
               (local.get $18)
               (i32.const 5)
              )
              (i32.const 1)
             )
            )
            (i32.const 997073096)
           )
           (i32.xor
            (i32.and
             (i32.sub
              (i32.const 0)
              (i32.and
               (i32.shr_u
                (local.get $18)
                (i32.const 6)
               )
               (i32.const 1)
              )
             )
             (i32.const 1994146192)
            )
            (i32.and
             (i32.sub
              (i32.const 0)
              (i32.and
               (i32.shr_u
                (local.get $18)
                (i32.const 7)
               )
               (i32.const 1)
              )
             )
             (i32.const -306674912)
            )
           )
          )
         )
        )
       )
      )
      (local.set $15
       (i64.add
        (local.get $15)
        (i64.const 1)
       )
      )
      (local.set $17
       (i64.add
        (local.get $17)
        (i64.const 1)
       )
      )
      (br $label)
     )
    )
    (local.set $4
     (i32.xor
      (local.get $11)
      (i32.const -1)
     )
    )
    (br $block1)
   )
   (local.set $19
    (local.get $4)
   )
   (local.set $3
    (local.get $19)
   )
   (local.set $20
    (i32.add
     (local.get $0)
     (i32.const 8)
    )
   )
   (local.set $21
    (i32.add
     (i32.load align=1
      (local.get $20)
     )
     (local.get $3)
    )
   )
   (i32.store align=1
    (local.get $20)
    (local.get $21)
   )
  )
  (global.set $global$0
   (local.get $2)
  )
 )
 (func $_start
  (local $0 i32)
  (local $1 f64)
  (local $2 f64)
  (local $3 f64)
  (local $4 f64)
  (local $5 f64)
  (local $6 f64)
  (local $7 f64)
  (local $8 f64)
  (local $9 f64)
  (local $10 f64)
  (local $11 f64)
  (local $12 f64)
  (local $13 f64)
  (local $14 f64)
  (local $15 f64)
  (local $16 f64)
  (local $17 f64)
  (local $18 f64)
  (local $19 f64)
  (local $20 f64)
  (local $21 f64)
  (local $22 f64)
  (local $23 f64)
  (local $24 f64)
  (local $25 f64)
  (local $26 f64)
  (local $27 f64)
  (local $28 f64)
  (local $29 f64)
  (local $30 f64)
  (local $31 f64)
  (local $32 f64)
  (local $33 f64)
  (local $34 f64)
  (local $35 f64)
  (local $36 f64)
  (local $37 f64)
  (local $38 f64)
  (local $39 f64)
  (local $40 f64)
  (local $41 f64)
  (local $42 f64)
  (local $43 f64)
  (local $44 f64)
  (local $45 f64)
  (local $46 f64)
  (local $47 i32)
  (local $48 i32)
  (local $49 i64)
  (local $50 i64)
  (local $51 i64)
  (local $52 i64)
  (local $53 i64)
  (local $54 i64)
  (local $55 i64)
  (local $56 i64)
  (local $57 i32)
  (local $58 i32)
  (local $59 i64)
  (local $60 i64)
  (local $61 i32)
  (local $62 i32)
  (local $63 i32)
  (local $64 i32)
  (local $65 i32)
  (local.set $0
   (global.get $global$0)
  )
  (local.set $65
   (i32.add
    (local.get $0)
    (i32.const 1000184)
   )
  )
  (if
   (i32.lt_u
    (local.get $65)
    (local.get $0)
   )
   (then
    (call $goose.abort
     (i32.const 1001338)
     (i32.const 25)
     (i32.const 0)
    )
    (unreachable)
   )
  )
  (if
   (i32.gt_u
    (local.get $65)
    (i32.shl
     (memory.size)
     (i32.const 16)
    )
   )
   (then
    (if
     (i32.eq
      (memory.grow
       (i32.sub
        (i32.add
         (i32.shr_u
          (local.get $65)
          (i32.const 16)
         )
         (i32.eqz
          (i32.eqz
           (i32.and
            (local.get $65)
            (i32.const 65535)
           )
          )
         )
        )
        (memory.size)
       )
      )
      (i32.const -1)
     )
     (then
      (call $goose.abort
       (i32.const 1001363)
       (i32.const 23)
       (i32.const 0)
      )
      (unreachable)
     )
    )
   )
  )
  (global.set $global$0
   (local.get $65)
  )
  (block
   (memory.fill
    (local.get $0)
    (i32.const 0)
    (i32.const 184)
   )
   (local.set $1
    (f64.const 1)
   )
   (local.set $2
    (local.get $1)
   )
   (f64.store align=1
    (local.get $0)
    (local.get $2)
   )
   (local.set $3
    (f64.const 10)
   )
   (local.set $4
    (local.get $3)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 8)
    )
    (local.get $4)
   )
   (local.set $5
    (f64.const 100)
   )
   (local.set $6
    (local.get $5)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 16)
    )
    (local.get $6)
   )
   (local.set $7
    (f64.const 1e3)
   )
   (local.set $8
    (local.get $7)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 24)
    )
    (local.get $8)
   )
   (local.set $9
    (f64.const 1e4)
   )
   (local.set $10
    (local.get $9)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 32)
    )
    (local.get $10)
   )
   (local.set $11
    (f64.const 1e5)
   )
   (local.set $12
    (local.get $11)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 40)
    )
    (local.get $12)
   )
   (local.set $13
    (f64.const 1e6)
   )
   (local.set $14
    (local.get $13)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 48)
    )
    (local.get $14)
   )
   (local.set $15
    (f64.const 1e7)
   )
   (local.set $16
    (local.get $15)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 56)
    )
    (local.get $16)
   )
   (local.set $17
    (f64.const 1e8)
   )
   (local.set $18
    (local.get $17)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 64)
    )
    (local.get $18)
   )
   (local.set $19
    (f64.const 1e9)
   )
   (local.set $20
    (local.get $19)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 72)
    )
    (local.get $20)
   )
   (local.set $21
    (f64.const 1e10)
   )
   (local.set $22
    (local.get $21)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 80)
    )
    (local.get $22)
   )
   (local.set $23
    (f64.const 1e11)
   )
   (local.set $24
    (local.get $23)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 88)
    )
    (local.get $24)
   )
   (local.set $25
    (f64.const 1e12)
   )
   (local.set $26
    (local.get $25)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 96)
    )
    (local.get $26)
   )
   (local.set $27
    (f64.const 1e13)
   )
   (local.set $28
    (local.get $27)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 104)
    )
    (local.get $28)
   )
   (local.set $29
    (f64.const 1e14)
   )
   (local.set $30
    (local.get $29)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 112)
    )
    (local.get $30)
   )
   (local.set $31
    (f64.const 1e15)
   )
   (local.set $32
    (local.get $31)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 120)
    )
    (local.get $32)
   )
   (local.set $33
    (f64.const 1e16)
   )
   (local.set $34
    (local.get $33)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 128)
    )
    (local.get $34)
   )
   (local.set $35
    (f64.const 1e17)
   )
   (local.set $36
    (local.get $35)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 136)
    )
    (local.get $36)
   )
   (local.set $37
    (f64.const 1e18)
   )
   (local.set $38
    (local.get $37)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 144)
    )
    (local.get $38)
   )
   (local.set $39
    (f64.const 1e19)
   )
   (local.set $40
    (local.get $39)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 152)
    )
    (local.get $40)
   )
   (local.set $41
    (f64.const 1e20)
   )
   (local.set $42
    (local.get $41)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 160)
    )
    (local.get $42)
   )
   (local.set $43
    (f64.const 1e21)
   )
   (local.set $44
    (local.get $43)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 168)
    )
    (local.get $44)
   )
   (local.set $45
    (f64.const 1e22)
   )
   (local.set $46
    (local.get $45)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 176)
    )
    (local.get $46)
   )
   (local.set $47
    (local.get $0)
   )
   (local.set $48
    (local.get $47)
   )
   (memory.copy
    (i32.const 1024)
    (local.get $48)
    (i32.const 184)
   )
   (local.set $49
    (i64.const 139968)
   )
   (local.set $50
    (local.get $49)
   )
   (i64.store align=1
    (i32.const 1208)
    (local.get $50)
   )
   (local.set $51
    (i64.const 3877)
   )
   (local.set $52
    (local.get $51)
   )
   (i64.store align=1
    (i32.const 1216)
    (local.get $52)
   )
   (local.set $53
    (i64.const 29573)
   )
   (local.set $54
    (local.get $53)
   )
   (i64.store align=1
    (i32.const 1224)
    (local.get $54)
   )
   (local.set $55
    (i64.const 42)
   )
   (local.set $56
    (local.get $55)
   )
   (i64.store align=1
    (i32.const 1232)
    (local.get $56)
   )
   (local.set $57
    (i32.const 42)
   )
   (local.set $58
    (local.get $57)
   )
   (i32.store align=1
    (i32.const 1240)
    (local.get $58)
   )
   (local.set $59
    (i64.const 0)
   )
   (local.set $60
    (local.get $59)
   )
   (i64.store align=1
    (i32.const 1248)
    (local.get $60)
   )
   (memory.fill
    (i32.add
     (local.get $0)
     (i32.const 184)
    )
    (i32.const 0)
    (i32.const 1000000)
   )
   (local.set $61
    (i32.and
     (i32.and
      (i32.const 0)
      (i32.const 255)
     )
     (i32.const 255)
    )
   )
   (local.set $62
    (i32.const 0)
   )
   (block $block
    (loop $label
     (br_if $block
      (i32.ge_u
       (local.get $62)
       (i32.const 1000000)
      )
     )
     (i32.store8
      (i32.add
       (i32.add
        (local.get $0)
        (i32.const 184)
       )
       (i32.mul
        (local.get $62)
        (i32.const 1)
       )
      )
      (local.get $61)
     )
     (local.set $62
      (i32.add
       (local.get $62)
       (i32.const 1)
      )
     )
     (br $label)
    )
   )
   (local.set $63
    (i32.add
     (local.get $0)
     (i32.const 184)
    )
   )
   (local.set $64
    (local.get $63)
   )
   (memory.copy
    (i32.const 1256)
    (local.get $64)
    (i32.const 1000000)
   )
   (call $main#0)
  )
  (global.set $global$0
   (local.get $0)
  )
 )
 ;; custom section "goose.direct", size 508
)

