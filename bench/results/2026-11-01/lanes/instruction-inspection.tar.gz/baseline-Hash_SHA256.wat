(module
 (type $0 (func (param i64)))
 (type $1 (func))
 (type $2 (func (param i32)))
 (type $3 (func (result i64)))
 (type $4 (func (param i32 i32)))
 (type $5 (func (param f64)))
 (type $6 (func (param f32)))
 (type $7 (func (param i32 i32 i32)))
 (type $8 (func (param i64) (result i64)))
 (type $9 (func (param i32 i64)))
 (type $10 (func (param i64 i64) (result i32 i32)))
 (type $11 (func (result i32 i32)))
 (import "goose" "write" (func $goose.write (param i32 i32)))
 (import "goose" "print_i64" (func $goose.print_i64 (param i64)))
 (import "goose" "print_u64" (func $goose.print_u64 (param i64)))
 (import "goose" "print_f64" (func $goose.print_f64 (param f64)))
 (import "goose" "print_f32" (func $goose.print_f32 (param f32)))
 (import "goose" "print_bool" (func $goose.print_bool (param i32)))
 (import "goose" "newline" (func $goose.newline))
 (import "goose" "abort" (func $goose.abort (param i32 i32 i32)))
 (import "goose" "exit" (func $goose.exit (param i32)))
 (import "env" "bench_input" (func $env.bench_input (result i64)))
 (import "env" "bench_barrier" (func $env.bench_barrier (param i64) (result i64)))
 (import "env" "bench_clock" (func $env.bench_clock (result i64)))
 (import "env" "bench_sink" (func $env.bench_sink (param i64)))
 (global $global$0 (mut i32) (i32.const 1001392))
 (memory $0 16 256)
 (data $0 (i32.const 1001256) "assertion failedslice bounds out of rangearray index out of boundsdivision by zeroactivation frame overflowlinear memory exhausted")
 (export "memory" (memory $0))
 (export "_start" (func $_start))
 (func $main#0
  (local $0 i32)
  (local $1 i64)
  (local $2 i64)
  (local $3 i64)
  (local $4 i64)
  (local $5 i64)
  (local $6 i64)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 i64)
  (local $12 i64)
  (local $13 i32)
  (local $14 i32)
  (local $15 i32)
  (local $16 i32)
  (local $17 i32)
  (local $18 i32)
  (local $19 i32)
  (local $20 i64)
  (local $21 i64)
  (local $22 i64)
  (local $23 i64)
  (local $24 i64)
  (local $25 i64)
  (local $26 i64)
  (local $27 i64)
  (local $28 i64)
  (local $29 i64)
  (local $30 i64)
  (local $31 i64)
  (local $32 i32)
  (local $33 i32)
  (local $34 i64)
  (local $35 i64)
  (local $36 i64)
  (local $37 i64)
  (local $38 i64)
  (local $39 i64)
  (local $40 i32)
  (local $41 i32)
  (local $42 i32)
  (local $43 i32)
  (local $44 i64)
  (local $45 i64)
  (local $46 i32)
  (local $47 i32)
  (local $48 f64)
  (local $49 i64)
  (local $50 i32)
  (local $51 i64)
  (local $52 i64)
  (local $53 i32)
  (local $54 i32)
  (local $55 i64)
  (local $56 i64)
  (local $57 i64)
  (local $58 i64)
  (local $59 i32)
  (local $60 i64)
  (local $61 i64)
  (local $62 i64)
  (local $63 i64)
  (local $64 i64)
  (local $65 i64)
  (local $66 i64)
  (local $67 i64)
  (local $68 i64)
  (local $69 i64)
  (local $70 i32)
  (local $71 i32)
  (local $72 i64)
  (local $73 i64)
  (local $74 i32)
  (local $75 i32)
  (local $76 i32)
  (local $77 i64)
  (local $78 i32)
  (local $scratch i32)
  (local.set $0
   (global.get $global$0)
  )
  (local.set $78
   (i32.add
    (local.get $0)
    (i32.const 24)
   )
  )
  (if
   (i32.lt_u
    (local.get $78)
    (local.get $0)
   )
   (then
    (call $goose.abort
     (i32.const 1001338)
     (i32.const 25)
     (i32.const 45)
    )
    (unreachable)
   )
  )
  (if
   (i32.gt_u
    (local.get $78)
    (i32.shl
     (memory.size)
     (i32.const 16)
    )
   )
   (then
    (if
     (i32.eq
      (memory.grow
       (i32.sub
        (i32.add
         (i32.shr_u
          (local.get $78)
          (i32.const 16)
         )
         (i32.eqz
          (i32.eqz
           (i32.and
            (local.get $78)
            (i32.const 65535)
           )
          )
         )
        )
        (memory.size)
       )
      )
      (i32.const -1)
     )
     (then
      (call $goose.abort
       (i32.const 1001363)
       (i32.const 23)
       (i32.const 45)
      )
      (unreachable)
     )
    )
   )
  )
  (global.set $global$0
   (local.get $78)
  )
  (block
   (local.set $2
    (call $env.bench_input)
   )
   (local.set $1
    (local.get $2)
   )
   (local.set $4
    (call $env.bench_input)
   )
   (local.set $3
    (local.get $4)
   )
   (local.set $6
    (call $env.bench_input)
   )
   (local.set $5
    (local.get $6)
   )
   (if
    (i32.eqz
     (i32.eqz
      (i32.eqz
       (if (result i32)
        (i32.eqz
         (i32.eqz
          (if (result i32)
           (i32.eqz
            (i32.eqz
             (if (result i32)
              (i32.eqz
               (i32.eqz
                (i64.ge_s
                 (local.get $1)
                 (i64.const 1)
                )
               )
              )
              (then
               (local.set $7
                (i32.eqz
                 (i32.eqz
                  (i64.le_s
                   (local.get $1)
                   (i64.const 1000000)
                  )
                 )
                )
               )
               (local.get $7)
              )
              (else
               (i32.const 0)
              )
             )
            )
           )
           (then
            (local.set $8
             (i32.eqz
              (i32.eqz
               (i64.gt_s
                (local.get $3)
                (i64.const 0)
               )
              )
             )
            )
            (local.get $8)
           )
           (else
            (i32.const 0)
           )
          )
         )
        )
        (then
         (local.set $9
          (i32.eqz
           (i32.eqz
            (i64.ge_s
             (local.get $5)
             (i64.const 0)
            )
           )
          )
         )
         (local.get $9)
        )
        (else
         (i32.const 0)
        )
       )
      )
     )
    )
    (then
     (call $goose.abort
      (i32.const 1001256)
      (i32.const 16)
      (i32.const 49)
     )
     (unreachable)
    )
   )
   (block
    (local.set $10
     (i32.const 42)
    )
    (i32.store align=1
     (i32.const 1240)
     (local.get $10)
    )
   )
   (memory.fill
    (i32.add
     (local.get $0)
     (i32.const 12)
    )
    (i32.const 0)
    (i32.const 12)
   )
   (local.set $11
    (local.get $1)
   )
   (local.set $12
    (local.get $11)
   )
   (i64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 12)
    )
    (local.get $12)
   )
   (local.set $13
    (i32.const 0)
   )
   (local.set $14
    (local.get $13)
   )
   (i32.store align=1
    (i32.add
     (local.get $0)
     (i32.const 20)
    )
    (local.get $14)
   )
   (local.set $15
    (i32.add
     (local.get $0)
     (i32.const 12)
    )
   )
   (local.set $16
    (local.get $15)
   )
   (memory.copy
    (local.get $0)
    (local.get $16)
    (i32.const 12)
   )
   (block
    (local.set $17
     (i32.const 42)
    )
    (i32.store align=1
     (i32.const 1240)
     (local.get $17)
    )
   )
   (block
    (local.set $19
     (local.get $0)
    )
    (local.set $18
     (local.get $19)
    )
    (block
     (local.set $21
      (i64.or
       (i64.extend_i32_u
        (i32.const 1256)
       )
       (i64.const 4294967296000000)
      )
     )
     (local.set $22
      (i64.shr_u
       (local.get $21)
       (i64.const 32)
      )
     )
     (local.set $23
      (i64.const 0)
     )
     (local.set $24
      (i64.load align=1
       (local.get $18)
      )
     )
     (if
      (i32.or
       (i64.gt_u
        (local.get $23)
        (local.get $24)
       )
       (i64.gt_u
        (local.get $24)
        (local.get $22)
       )
      )
      (then
       (call $goose.abort
        (i32.const 1001272)
        (i32.const 25)
        (i32.const 14)
       )
       (unreachable)
      )
     )
     (local.set $25
      (i64.or
       (i64.extend_i32_u
        (i32.add
         (i32.wrap_i64
          (local.get $21)
         )
         (i32.mul
          (i32.wrap_i64
           (local.get $23)
          )
          (i32.const 1)
         )
        )
       )
       (i64.shl
        (i64.sub
         (local.get $24)
         (local.get $23)
        )
        (i64.const 32)
       )
      )
     )
     (local.set $20
      (local.get $25)
     )
     (local.set $27
      (i64.const 0)
     )
     (local.set $28
      (i64.shr_u
       (local.get $20)
       (i64.const 32)
      )
     )
     (local.set $29
      (i64.const 0)
     )
     (block $block
      (loop $label
       (br_if $block
        (i64.ge_s
         (local.get $27)
         (local.get $28)
        )
       )
       (local.set $26
        (local.get $27)
       )
       (block
        (local.set $30
         (local.get $20)
        )
        (local.set $31
         (local.get $26)
        )
        (local.set $32
         (i32.add
          (i32.wrap_i64
           (local.get $30)
          )
          (i32.mul
           (i32.wrap_i64
            (local.get $31)
           )
           (i32.const 1)
          )
         )
        )
        (local.set $33
         (i32.and
          (i32.and
           (i32.const 0)
           (i32.const 255)
          )
          (i32.const 255)
         )
        )
        (i32.store8
         (local.get $32)
         (local.get $33)
        )
       )
       (local.set $27
        (i64.add
         (local.get $27)
         (i64.const 1)
        )
       )
       (local.set $29
        (i64.add
         (local.get $29)
         (i64.const 1)
        )
       )
       (br $label)
      )
     )
    )
    (local.set $35
     (i64.const 0)
    )
    (local.set $36
     (i64.load align=1
      (local.get $18)
     )
    )
    (local.set $37
     (i64.const 0)
    )
    (block $block1
     (loop $label1
      (br_if $block1
       (i64.ge_s
        (local.get $35)
        (local.get $36)
       )
      )
      (local.set $34
       (local.get $35)
      )
      (block
       (local.set $38
        (i64.or
         (i64.extend_i32_u
          (i32.const 1256)
         )
         (i64.const 4294967296000000)
        )
       )
       (local.set $39
        (local.get $34)
       )
       (if
        (i64.ge_u
         (local.get $39)
         (i64.shr_u
          (local.get $38)
          (i64.const 32)
         )
        )
        (then
         (call $goose.abort
          (i32.const 1001297)
          (i32.const 25)
          (i32.const 15)
         )
         (unreachable)
        )
       )
       (local.set $40
        (i32.add
         (i32.wrap_i64
          (local.get $38)
         )
         (i32.mul
          (i32.wrap_i64
           (local.get $39)
          )
          (i32.const 1)
         )
        )
       )
       (block $block2
        (local.set $43
         (block (result i32)
          (local.set $scratch
           (i32.add
            (i32.mul
             (i32.load align=1
              (i32.const 1240)
             )
             (i32.const 3877)
            )
            (i32.const 29573)
           )
          )
          (local.set $42
           (i32.const 139968)
          )
          (local.get $scratch)
         )
        )
        (if
         (i32.eqz
          (local.get $42)
         )
         (then
          (call $goose.abort
           (i32.const 1001322)
           (i32.const 16)
           (i32.const 18)
          )
          (unreachable)
         )
        )
        (local.set $44
         (i64.rem_s
          (i64.extend_i32_s
           (local.get $43)
          )
          (i64.extend_i32_s
           (local.get $42)
          )
         )
        )
        (if
         (i64.lt_s
          (local.get $44)
          (i64.const 0)
         )
         (then
          (local.set $44
           (i64.add
            (local.get $44)
            (block (result i64)
             (local.set $45
              (i64.extend_i32_s
               (local.get $42)
              )
             )
             (if (result i64)
              (i64.lt_s
               (local.get $45)
               (i64.const 0)
              )
              (then
               (i64.sub
                (i64.const 0)
                (local.get $45)
               )
              )
              (else
               (local.get $45)
              )
             )
            )
           )
          )
         )
        )
        (local.set $46
         (i32.wrap_i64
          (local.get $44)
         )
        )
        (i32.store align=1
         (i32.const 1240)
         (local.get $46)
        )
        (local.set $47
         (i32.load align=1
          (i32.const 1240)
         )
        )
        (local.set $48
         (f64.mul
          (f64.div
           (f64.convert_i32_s
            (local.get $47)
           )
           (f64.const 139968)
          )
          (f64.const 256)
         )
        )
        (local.set $49
         (i64.reinterpret_f64
          (local.get $48)
         )
        )
        (local.set $50
         (i32.sub
          (i32.wrap_i64
           (i64.and
            (i64.shr_u
             (local.get $49)
             (i64.const 52)
            )
            (i64.const 2047)
           )
          )
          (i32.const 1023)
         )
        )
        (local.set $41
         (i32.wrap_i64
          (if (result i64)
           (i32.or
            (i32.lt_s
             (local.get $50)
             (i32.const 0)
            )
            (i32.ge_s
             (local.get $50)
             (i32.const 116)
            )
           )
           (then
            (i64.const 0)
           )
           (else
            (local.set $51
             (i64.or
              (i64.and
               (local.get $49)
               (i64.const 4503599627370495)
              )
              (i64.const 4503599627370496)
             )
            )
            (local.set $52
             (if (result i64)
              (i32.lt_s
               (local.get $50)
               (i32.const 52)
              )
              (then
               (i64.shr_u
                (local.get $51)
                (i64.extend_i32_u
                 (i32.sub
                  (i32.const 52)
                  (local.get $50)
                 )
                )
               )
              )
              (else
               (i64.shl
                (local.get $51)
                (i64.extend_i32_u
                 (i32.sub
                  (local.get $50)
                  (i32.const 52)
                 )
                )
               )
              )
             )
            )
            (if (result i64)
             (i64.lt_s
              (local.get $49)
              (i64.const 0)
             )
             (then
              (i64.sub
               (i64.const 0)
               (local.get $52)
              )
             )
             (else
              (local.get $52)
             )
            )
           )
          )
         )
        )
        (br $block2)
       )
       (local.set $53
        (local.get $41)
       )
       (local.set $54
        (i32.and
         (i32.and
          (i32.and
           (local.get $53)
           (i32.const 255)
          )
          (i32.const 255)
         )
         (i32.const 255)
        )
       )
       (i32.store8
        (local.get $40)
        (local.get $54)
       )
      )
      (local.set $35
       (i64.add
        (local.get $35)
        (i64.const 1)
       )
      )
      (local.set $37
       (i64.add
        (local.get $37)
        (i64.const 1)
       )
      )
      (br $label1)
     )
    )
   )
   (local.set $56
    (i64.const 0)
   )
   (local.set $57
    (local.get $5)
   )
   (local.set $58
    (i64.const 0)
   )
   (block $block3
    (loop $label2
     (br_if $block3
      (i64.ge_s
       (local.get $56)
       (local.get $57)
      )
     )
     (local.set $55
      (local.get $56)
     )
     (block
      (call $run#6
       (local.get $0)
       (local.get $55)
      )
     )
     (local.set $56
      (i64.add
       (local.get $56)
       (i64.const 1)
      )
     )
     (local.set $58
      (i64.add
       (local.get $58)
       (i64.const 1)
      )
     )
     (br $label2)
    )
   )
   (block
    (local.set $59
     (i32.const 42)
    )
    (i32.store align=1
     (i32.const 1240)
     (local.get $59)
    )
   )
   (local.set $61
    (call $env.bench_barrier
     (local.get $3)
    )
   )
   (local.set $60
    (local.get $61)
   )
   (local.set $63
    (call $env.bench_clock)
   )
   (local.set $62
    (local.get $63)
   )
   (local.set $65
    (i64.const 0)
   )
   (local.set $66
    (local.get $60)
   )
   (local.set $67
    (i64.const 0)
   )
   (block $block4
    (loop $label3
     (br_if $block4
      (i64.ge_s
       (local.get $65)
       (local.get $66)
      )
     )
     (local.set $64
      (local.get $65)
     )
     (block
      (call $run#6
       (local.get $0)
       (local.get $64)
      )
     )
     (local.set $65
      (i64.add
       (local.get $65)
       (i64.const 1)
      )
     )
     (local.set $67
      (i64.add
       (local.get $67)
       (i64.const 1)
      )
     )
     (br $label3)
    )
   )
   (local.set $69
    (i64.sub
     (call $env.bench_clock)
     (local.get $62)
    )
   )
   (local.set $68
    (local.get $69)
   )
   (block
    (local.set $71
     (i32.load align=1
      (i32.add
       (local.get $0)
       (i32.const 8)
      )
     )
    )
    (local.set $70
     (local.get $71)
    )
    (local.set $73
     (local.get $68)
    )
    (local.set $72
     (local.get $73)
    )
    (call $env.bench_sink
     (i64.extend_i32_u
      (local.get $70)
     )
    )
    (local.set $74
     (global.get $global$0)
    )
    (local.set $75
     (local.get $70)
    )
    (call $goose.print_u64
     (i64.extend_i32_u
      (local.get $75)
     )
    )
    (call $goose.newline)
    (global.set $global$0
     (local.get $74)
    )
    (local.set $76
     (global.get $global$0)
    )
    (local.set $77
     (local.get $72)
    )
    (call $goose.print_i64
     (local.get $77)
    )
    (call $goose.newline)
    (global.set $global$0
     (local.get $76)
    )
   )
  )
  (global.set $global$0
   (local.get $0)
  )
 )
 (func $run#6 (param $0 i32) (param $1 i64)
  (local $2 i32)
  (local $3 i32)
  (local $4 i64)
  (local $5 i64)
  (local $6 i64)
  (local $7 i64)
  (local $8 i64)
  (local $9 i64)
  (local $10 i32)
  (local $11 i32)
  (local $12 i32)
  (local $13 i32)
  (local $14 i32)
  (local $15 i32)
  (local $16 i32)
  (local $17 i32)
  (local $18 i32)
  (local $19 i32)
  (local $20 i32)
  (local $21 i32)
  (local $22 i32)
  (local $23 i32)
  (local $24 i32)
  (local $25 i32)
  (local $26 i32)
  (local $27 i32)
  (local $28 i32)
  (local $29 i32)
  (local $30 i32)
  (local $31 i32)
  (local $32 i32)
  (local $33 i64)
  (local $34 i64)
  (local $35 i64)
  (local $36 i64)
  (local $37 i64)
  (local $38 i64)
  (local $39 i32)
  (local $40 i64)
  (local $41 i64)
  (local $42 i32)
  (local $43 i64)
  (local $44 i64)
  (local $45 i32)
  (local $46 i32)
  (local $47 i64)
  (local $48 i64)
  (local $49 i64)
  (local $50 i32)
  (local $51 i64)
  (local $52 i64)
  (local $53 i32)
  (local $54 i32)
  (local $55 i64)
  (local $56 i64)
  (local $57 i64)
  (local $58 i32)
  (local $59 i64)
  (local $60 i64)
  (local $61 i32)
  (local $62 i32)
  (local $63 i64)
  (local $64 i64)
  (local $65 i64)
  (local $66 i32)
  (local $67 i64)
  (local $68 i64)
  (local $69 i32)
  (local $70 i32)
  (local $71 i64)
  (local $72 i64)
  (local $73 i64)
  (local $74 i32)
  (local $75 i64)
  (local $76 i64)
  (local $77 i32)
  (local $78 i32)
  (local $79 i64)
  (local $80 i64)
  (local $81 i64)
  (local $82 i32)
  (local $83 i64)
  (local $84 i64)
  (local $85 i32)
  (local $86 i32)
  (local $87 i64)
  (local $88 i64)
  (local $89 i64)
  (local $90 i32)
  (local $91 i64)
  (local $92 i64)
  (local $93 i32)
  (local $94 i32)
  (local $95 i64)
  (local $96 i64)
  (local $97 i64)
  (local $98 i32)
  (local $99 i64)
  (local $100 i64)
  (local $101 i32)
  (local $102 i32)
  (local $103 i64)
  (local $104 i64)
  (local $105 i64)
  (local $106 i32)
  (local $107 i64)
  (local $108 i64)
  (local $109 i32)
  (local $110 i32)
  (local $111 i64)
  (local $112 i64)
  (local $113 i64)
  (local $114 i32)
  (local $115 i64)
  (local $116 i64)
  (local $117 i32)
  (local $118 i32)
  (local $119 i64)
  (local $120 i64)
  (local $121 i64)
  (local $122 i32)
  (local $123 i64)
  (local $124 i64)
  (local $125 i32)
  (local $126 i32)
  (local $127 i64)
  (local $128 i64)
  (local $129 i64)
  (local $130 i32)
  (local $131 i64)
  (local $132 i64)
  (local $133 i32)
  (local $134 i32)
  (local $135 i64)
  (local $136 i64)
  (local $137 i64)
  (local $138 i32)
  (local $139 i64)
  (local $140 i64)
  (local $141 i32)
  (local $142 i32)
  (local $143 i64)
  (local $144 i64)
  (local $145 i64)
  (local $146 i32)
  (local $147 i64)
  (local $148 i64)
  (local $149 i32)
  (local $150 i32)
  (local $151 i64)
  (local $152 i64)
  (local $153 i64)
  (local $154 i32)
  (local $155 i64)
  (local $156 i64)
  (local $157 i32)
  (local $158 i32)
  (local $159 i64)
  (local $160 i64)
  (local $161 i64)
  (local $162 i32)
  (local $163 i64)
  (local $164 i64)
  (local $165 i32)
  (local $166 i32)
  (local $167 i64)
  (local $168 i64)
  (local $169 i64)
  (local $170 i64)
  (local $171 i32)
  (local $172 i64)
  (local $173 i64)
  (local $174 i32)
  (local $175 i64)
  (local $176 i64)
  (local $177 i32)
  (local $178 i32)
  (local $179 i32)
  (local $180 i64)
  (local $181 i64)
  (local $182 i32)
  (local $183 i32)
  (local $184 i32)
  (local $185 i64)
  (local $186 i64)
  (local $187 i32)
  (local $188 i32)
  (local $189 i32)
  (local $190 i64)
  (local $191 i64)
  (local $192 i32)
  (local $193 i32)
  (local $194 i32)
  (local $195 i32)
  (local $196 i32)
  (local $197 i32)
  (local $198 i32)
  (local $199 i32)
  (local $200 i32)
  (local $201 i32)
  (local $202 i32)
  (local $203 i32)
  (local $204 i32)
  (local $205 i32)
  (local $206 i32)
  (local $207 i32)
  (local $208 i32)
  (local $scratch (tuple i32 i32))
  (local $scratch_210 i32)
  (local.set $2
   (global.get $global$0)
  )
  (local.set $208
   (i32.add
    (local.get $2)
    (i32.const 192)
   )
  )
  (if
   (i32.lt_u
    (local.get $208)
    (local.get $2)
   )
   (then
    (call $goose.abort
     (i32.const 1001338)
     (i32.const 25)
     (i32.const 39)
    )
    (unreachable)
   )
  )
  (if
   (i32.gt_u
    (local.get $208)
    (i32.shl
     (memory.size)
     (i32.const 16)
    )
   )
   (then
    (if
     (i32.eq
      (memory.grow
       (i32.sub
        (i32.add
         (i32.shr_u
          (local.get $208)
          (i32.const 16)
         )
         (i32.eqz
          (i32.eqz
           (i32.and
            (local.get $208)
            (i32.const 65535)
           )
          )
         )
        )
        (memory.size)
       )
      )
      (i32.const -1)
     )
     (then
      (call $goose.abort
       (i32.const 1001363)
       (i32.const 23)
       (i32.const 39)
      )
      (unreachable)
     )
    )
   )
  )
  (global.set $global$0
   (local.get $208)
  )
  (block
   (block $block4
    (local.set $5
     (i64.or
      (i64.extend_i32_u
       (i32.const 1256)
      )
      (i64.const 4294967296000000)
     )
    )
    (local.set $6
     (i64.shr_u
      (local.get $5)
      (i64.const 32)
     )
    )
    (local.set $7
     (i64.const 0)
    )
    (local.set $8
     (i64.load align=1
      (local.get $0)
     )
    )
    (if
     (i32.or
      (i64.gt_u
       (local.get $7)
       (local.get $8)
      )
      (i64.gt_u
       (local.get $8)
       (local.get $6)
      )
     )
     (then
      (call $goose.abort
       (i32.const 1001272)
       (i32.const 25)
       (i32.const 40)
      )
      (unreachable)
     )
    )
    (local.set $9
     (i64.or
      (i64.extend_i32_u
       (i32.add
        (i32.wrap_i64
         (local.get $5)
        )
        (i32.mul
         (i32.wrap_i64
          (local.get $7)
         )
         (i32.const 1)
        )
       )
      )
      (i64.shl
       (i64.sub
        (local.get $8)
        (local.get $7)
       )
       (i64.const 32)
      )
     )
    )
    (local.set $4
     (local.get $9)
    )
    (memory.fill
     (i32.add
      (local.get $2)
      (i32.const 64)
     )
     (i32.const 0)
     (i32.const 32)
    )
    (local.set $10
     (i32.and
      (i32.and
       (i32.const 0)
       (i32.const 255)
      )
      (i32.const 255)
     )
    )
    (local.set $11
     (i32.const 0)
    )
    (block $block
     (loop $label
      (br_if $block
       (i32.ge_u
        (local.get $11)
        (i32.const 32)
       )
      )
      (i32.store8
       (i32.add
        (i32.add
         (local.get $2)
         (i32.const 64)
        )
        (i32.mul
         (local.get $11)
         (i32.const 1)
        )
       )
       (local.get $10)
      )
      (local.set $11
       (i32.add
        (local.get $11)
        (i32.const 1)
       )
      )
      (br $label)
     )
    )
    (local.set $12
     (i32.add
      (local.get $2)
      (i32.const 64)
     )
    )
    (local.set $13
     (local.get $12)
    )
    (memory.copy
     (i32.add
      (local.get $2)
      (i32.const 32)
     )
     (local.get $13)
     (i32.const 32)
    )
    (memory.fill
     (i32.add
      (local.get $2)
      (i32.const 128)
     )
     (i32.const 0)
     (i32.const 32)
    )
    (local.set $14
     (i32.const 1779033703)
    )
    (local.set $15
     (local.get $14)
    )
    (i32.store align=1
     (i32.add
      (local.get $2)
      (i32.const 128)
     )
     (local.get $15)
    )
    (local.set $16
     (i32.const -1150833019)
    )
    (local.set $17
     (local.get $16)
    )
    (i32.store align=1
     (i32.add
      (local.get $2)
      (i32.const 132)
     )
     (local.get $17)
    )
    (local.set $18
     (i32.const 1013904242)
    )
    (local.set $19
     (local.get $18)
    )
    (i32.store align=1
     (i32.add
      (local.get $2)
      (i32.const 136)
     )
     (local.get $19)
    )
    (local.set $20
     (i32.const -1521486534)
    )
    (local.set $21
     (local.get $20)
    )
    (i32.store align=1
     (i32.add
      (local.get $2)
      (i32.const 140)
     )
     (local.get $21)
    )
    (local.set $22
     (i32.const 1359893119)
    )
    (local.set $23
     (local.get $22)
    )
    (i32.store align=1
     (i32.add
      (local.get $2)
      (i32.const 144)
     )
     (local.get $23)
    )
    (local.set $24
     (i32.const -1694144372)
    )
    (local.set $25
     (local.get $24)
    )
    (i32.store align=1
     (i32.add
      (local.get $2)
      (i32.const 148)
     )
     (local.get $25)
    )
    (local.set $26
     (i32.const 528734635)
    )
    (local.set $27
     (local.get $26)
    )
    (i32.store align=1
     (i32.add
      (local.get $2)
      (i32.const 152)
     )
     (local.get $27)
    )
    (local.set $28
     (i32.const 1541459225)
    )
    (local.set $29
     (local.get $28)
    )
    (i32.store align=1
     (i32.add
      (local.get $2)
      (i32.const 156)
     )
     (local.get $29)
    )
    (local.set $30
     (i32.add
      (local.get $2)
      (i32.const 128)
     )
    )
    (local.set $31
     (local.get $30)
    )
    (memory.copy
     (i32.add
      (local.get $2)
      (i32.const 96)
     )
     (local.get $31)
     (i32.const 32)
    )
    (local.set $34
     (local.get $4)
    )
    (local.set $35
     (i64.const 0)
    )
    (local.set $36
     (i64.shr_u
      (local.get $34)
      (i64.const 32)
     )
    )
    (block $block1
     (loop $label1
      (br_if $block1
       (i64.lt_u
        (i64.sub
         (local.get $36)
         (local.get $35)
        )
        (i64.const 8)
       )
      )
      (local.set $32
       (i32.and
        (i32.load8_u
         (i32.add
          (i32.wrap_i64
           (local.get $34)
          )
          (i32.mul
           (i32.wrap_i64
            (local.get $35)
           )
           (i32.const 1)
          )
         )
        )
        (i32.const 255)
       )
      )
      (local.set $33
       (local.get $35)
      )
      (local.set $38
       (i64.const 0)
      )
      (local.set $37
       (local.get $38)
      )
      (local.set $40
       (i64.or
        (i64.extend_i32_u
         (i32.add
          (local.get $2)
          (i32.const 96)
         )
        )
        (i64.const 34359738368)
       )
      )
      (local.set $41
       (local.get $37)
      )
      (local.set $42
       (i32.load align=1
        (i32.add
         (i32.wrap_i64
          (local.get $40)
         )
         (i32.mul
          (i32.wrap_i64
           (local.get $41)
          )
          (i32.const 4)
         )
        )
       )
      )
      (local.set $39
       (local.get $42)
      )
      (local.set $39
       (i32.add
        (i32.add
         (i32.shl
          (local.get $39)
          (i32.and
           (i32.wrap_i64
            (i64.const 5)
           )
           (i32.const 31)
          )
         )
         (local.get $39)
        )
        (local.get $32)
       )
      )
      (local.set $39
       (i32.xor
        (i32.add
         (local.get $39)
         (i32.shl
          (local.get $39)
          (i32.and
           (i32.wrap_i64
            (i64.const 10)
           )
           (i32.const 31)
          )
         )
        )
        (i32.shr_u
         (local.get $39)
         (i32.and
          (i32.wrap_i64
           (i64.const 6)
          )
          (i32.const 31)
         )
        )
       )
      )
      (local.set $43
       (i64.or
        (i64.extend_i32_u
         (i32.add
          (local.get $2)
          (i32.const 96)
         )
        )
        (i64.const 34359738368)
       )
      )
      (local.set $44
       (local.get $37)
      )
      (local.set $45
       (i32.add
        (i32.wrap_i64
         (local.get $43)
        )
        (i32.mul
         (i32.wrap_i64
          (local.get $44)
         )
         (i32.const 4)
        )
       )
      )
      (local.set $46
       (local.get $39)
      )
      (i32.store align=1
       (local.get $45)
       (local.get $46)
      )
      (local.set $35
       (i64.add
        (local.get $35)
        (i64.const 1)
       )
      )
      (local.set $32
       (i32.and
        (i32.load8_u
         (i32.add
          (i32.wrap_i64
           (local.get $34)
          )
          (i32.mul
           (i32.wrap_i64
            (local.get $35)
           )
           (i32.const 1)
          )
         )
        )
        (i32.const 255)
       )
      )
      (local.set $33
       (local.get $35)
      )
      (local.set $47
       (i64.const 1)
      )
      (local.set $37
       (local.get $47)
      )
      (local.set $48
       (i64.or
        (i64.extend_i32_u
         (i32.add
          (local.get $2)
          (i32.const 96)
         )
        )
        (i64.const 34359738368)
       )
      )
      (local.set $49
       (local.get $37)
      )
      (local.set $50
       (i32.load align=1
        (i32.add
         (i32.wrap_i64
          (local.get $48)
         )
         (i32.mul
          (i32.wrap_i64
           (local.get $49)
          )
          (i32.const 4)
         )
        )
       )
      )
      (local.set $39
       (local.get $50)
      )
      (local.set $39
       (i32.add
        (i32.add
         (i32.shl
          (local.get $39)
          (i32.and
           (i32.wrap_i64
            (i64.const 5)
           )
           (i32.const 31)
          )
         )
         (local.get $39)
        )
        (local.get $32)
       )
      )
      (local.set $39
       (i32.xor
        (i32.add
         (local.get $39)
         (i32.shl
          (local.get $39)
          (i32.and
           (i32.wrap_i64
            (i64.const 10)
           )
           (i32.const 31)
          )
         )
        )
        (i32.shr_u
         (local.get $39)
         (i32.and
          (i32.wrap_i64
           (i64.const 6)
          )
          (i32.const 31)
         )
        )
       )
      )
      (local.set $51
       (i64.or
        (i64.extend_i32_u
         (i32.add
          (local.get $2)
          (i32.const 96)
         )
        )
        (i64.const 34359738368)
       )
      )
      (local.set $52
       (local.get $37)
      )
      (local.set $53
       (i32.add
        (i32.wrap_i64
         (local.get $51)
        )
        (i32.mul
         (i32.wrap_i64
          (local.get $52)
         )
         (i32.const 4)
        )
       )
      )
      (local.set $54
       (local.get $39)
      )
      (i32.store align=1
       (local.get $53)
       (local.get $54)
      )
      (local.set $35
       (i64.add
        (local.get $35)
        (i64.const 1)
       )
      )
      (local.set $32
       (i32.and
        (i32.load8_u
         (i32.add
          (i32.wrap_i64
           (local.get $34)
          )
          (i32.mul
           (i32.wrap_i64
            (local.get $35)
           )
           (i32.const 1)
          )
         )
        )
        (i32.const 255)
       )
      )
      (local.set $33
       (local.get $35)
      )
      (local.set $55
       (i64.const 2)
      )
      (local.set $37
       (local.get $55)
      )
      (local.set $56
       (i64.or
        (i64.extend_i32_u
         (i32.add
          (local.get $2)
          (i32.const 96)
         )
        )
        (i64.const 34359738368)
       )
      )
      (local.set $57
       (local.get $37)
      )
      (local.set $58
       (i32.load align=1
        (i32.add
         (i32.wrap_i64
          (local.get $56)
         )
         (i32.mul
          (i32.wrap_i64
           (local.get $57)
          )
          (i32.const 4)
         )
        )
       )
      )
      (local.set $39
       (local.get $58)
      )
      (local.set $39
       (i32.add
        (i32.add
         (i32.shl
          (local.get $39)
          (i32.and
           (i32.wrap_i64
            (i64.const 5)
           )
           (i32.const 31)
          )
         )
         (local.get $39)
        )
        (local.get $32)
       )
      )
      (local.set $39
       (i32.xor
        (i32.add
         (local.get $39)
         (i32.shl
          (local.get $39)
          (i32.and
           (i32.wrap_i64
            (i64.const 10)
           )
           (i32.const 31)
          )
         )
        )
        (i32.shr_u
         (local.get $39)
         (i32.and
          (i32.wrap_i64
           (i64.const 6)
          )
          (i32.const 31)
         )
        )
       )
      )
      (local.set $59
       (i64.or
        (i64.extend_i32_u
         (i32.add
          (local.get $2)
          (i32.const 96)
         )
        )
        (i64.const 34359738368)
       )
      )
      (local.set $60
       (local.get $37)
      )
      (local.set $61
       (i32.add
        (i32.wrap_i64
         (local.get $59)
        )
        (i32.mul
         (i32.wrap_i64
          (local.get $60)
         )
         (i32.const 4)
        )
       )
      )
      (local.set $62
       (local.get $39)
      )
      (i32.store align=1
       (local.get $61)
       (local.get $62)
      )
      (local.set $35
       (i64.add
        (local.get $35)
        (i64.const 1)
       )
      )
      (local.set $32
       (i32.and
        (i32.load8_u
         (i32.add
          (i32.wrap_i64
           (local.get $34)
          )
          (i32.mul
           (i32.wrap_i64
            (local.get $35)
           )
           (i32.const 1)
          )
         )
        )
        (i32.const 255)
       )
      )
      (local.set $33
       (local.get $35)
      )
      (local.set $63
       (i64.const 3)
      )
      (local.set $37
       (local.get $63)
      )
      (local.set $64
       (i64.or
        (i64.extend_i32_u
         (i32.add
          (local.get $2)
          (i32.const 96)
         )
        )
        (i64.const 34359738368)
       )
      )
      (local.set $65
       (local.get $37)
      )
      (local.set $66
       (i32.load align=1
        (i32.add
         (i32.wrap_i64
          (local.get $64)
         )
         (i32.mul
          (i32.wrap_i64
           (local.get $65)
          )
          (i32.const 4)
         )
        )
       )
      )
      (local.set $39
       (local.get $66)
      )
      (local.set $39
       (i32.add
        (i32.add
         (i32.shl
          (local.get $39)
          (i32.and
           (i32.wrap_i64
            (i64.const 5)
           )
           (i32.const 31)
          )
         )
         (local.get $39)
        )
        (local.get $32)
       )
      )
      (local.set $39
       (i32.xor
        (i32.add
         (local.get $39)
         (i32.shl
          (local.get $39)
          (i32.and
           (i32.wrap_i64
            (i64.const 10)
           )
           (i32.const 31)
          )
         )
        )
        (i32.shr_u
         (local.get $39)
         (i32.and
          (i32.wrap_i64
           (i64.const 6)
          )
          (i32.const 31)
         )
        )
       )
      )
      (local.set $67
       (i64.or
        (i64.extend_i32_u
         (i32.add
          (local.get $2)
          (i32.const 96)
         )
        )
        (i64.const 34359738368)
       )
      )
      (local.set $68
       (local.get $37)
      )
      (local.set $69
       (i32.add
        (i32.wrap_i64
         (local.get $67)
        )
        (i32.mul
         (i32.wrap_i64
          (local.get $68)
         )
         (i32.const 4)
        )
       )
      )
      (local.set $70
       (local.get $39)
      )
      (i32.store align=1
       (local.get $69)
       (local.get $70)
      )
      (local.set $35
       (i64.add
        (local.get $35)
        (i64.const 1)
       )
      )
      (local.set $32
       (i32.and
        (i32.load8_u
         (i32.add
          (i32.wrap_i64
           (local.get $34)
          )
          (i32.mul
           (i32.wrap_i64
            (local.get $35)
           )
           (i32.const 1)
          )
         )
        )
        (i32.const 255)
       )
      )
      (local.set $33
       (local.get $35)
      )
      (local.set $71
       (i64.const 4)
      )
      (local.set $37
       (local.get $71)
      )
      (local.set $72
       (i64.or
        (i64.extend_i32_u
         (i32.add
          (local.get $2)
          (i32.const 96)
         )
        )
        (i64.const 34359738368)
       )
      )
      (local.set $73
       (local.get $37)
      )
      (local.set $74
       (i32.load align=1
        (i32.add
         (i32.wrap_i64
          (local.get $72)
         )
         (i32.mul
          (i32.wrap_i64
           (local.get $73)
          )
          (i32.const 4)
         )
        )
       )
      )
      (local.set $39
       (local.get $74)
      )
      (local.set $39
       (i32.add
        (i32.add
         (i32.shl
          (local.get $39)
          (i32.and
           (i32.wrap_i64
            (i64.const 5)
           )
           (i32.const 31)
          )
         )
         (local.get $39)
        )
        (local.get $32)
       )
      )
      (local.set $39
       (i32.xor
        (i32.add
         (local.get $39)
         (i32.shl
          (local.get $39)
          (i32.and
           (i32.wrap_i64
            (i64.const 10)
           )
           (i32.const 31)
          )
         )
        )
        (i32.shr_u
         (local.get $39)
         (i32.and
          (i32.wrap_i64
           (i64.const 6)
          )
          (i32.const 31)
         )
        )
       )
      )
      (local.set $75
       (i64.or
        (i64.extend_i32_u
         (i32.add
          (local.get $2)
          (i32.const 96)
         )
        )
        (i64.const 34359738368)
       )
      )
      (local.set $76
       (local.get $37)
      )
      (local.set $77
       (i32.add
        (i32.wrap_i64
         (local.get $75)
        )
        (i32.mul
         (i32.wrap_i64
          (local.get $76)
         )
         (i32.const 4)
        )
       )
      )
      (local.set $78
       (local.get $39)
      )
      (i32.store align=1
       (local.get $77)
       (local.get $78)
      )
      (local.set $35
       (i64.add
        (local.get $35)
        (i64.const 1)
       )
      )
      (local.set $32
       (i32.and
        (i32.load8_u
         (i32.add
          (i32.wrap_i64
           (local.get $34)
          )
          (i32.mul
           (i32.wrap_i64
            (local.get $35)
           )
           (i32.const 1)
          )
         )
        )
        (i32.const 255)
       )
      )
      (local.set $33
       (local.get $35)
      )
      (local.set $79
       (i64.const 5)
      )
      (local.set $37
       (local.get $79)
      )
      (local.set $80
       (i64.or
        (i64.extend_i32_u
         (i32.add
          (local.get $2)
          (i32.const 96)
         )
        )
        (i64.const 34359738368)
       )
      )
      (local.set $81
       (local.get $37)
      )
      (local.set $82
       (i32.load align=1
        (i32.add
         (i32.wrap_i64
          (local.get $80)
         )
         (i32.mul
          (i32.wrap_i64
           (local.get $81)
          )
          (i32.const 4)
         )
        )
       )
      )
      (local.set $39
       (local.get $82)
      )
      (local.set $39
       (i32.add
        (i32.add
         (i32.shl
          (local.get $39)
          (i32.and
           (i32.wrap_i64
            (i64.const 5)
           )
           (i32.const 31)
          )
         )
         (local.get $39)
        )
        (local.get $32)
       )
      )
      (local.set $39
       (i32.xor
        (i32.add
         (local.get $39)
         (i32.shl
          (local.get $39)
          (i32.and
           (i32.wrap_i64
            (i64.const 10)
           )
           (i32.const 31)
          )
         )
        )
        (i32.shr_u
         (local.get $39)
         (i32.and
          (i32.wrap_i64
           (i64.const 6)
          )
          (i32.const 31)
         )
        )
       )
      )
      (local.set $83
       (i64.or
        (i64.extend_i32_u
         (i32.add
          (local.get $2)
          (i32.const 96)
         )
        )
        (i64.const 34359738368)
       )
      )
      (local.set $84
       (local.get $37)
      )
      (local.set $85
       (i32.add
        (i32.wrap_i64
         (local.get $83)
        )
        (i32.mul
         (i32.wrap_i64
          (local.get $84)
         )
         (i32.const 4)
        )
       )
      )
      (local.set $86
       (local.get $39)
      )
      (i32.store align=1
       (local.get $85)
       (local.get $86)
      )
      (local.set $35
       (i64.add
        (local.get $35)
        (i64.const 1)
       )
      )
      (local.set $32
       (i32.and
        (i32.load8_u
         (i32.add
          (i32.wrap_i64
           (local.get $34)
          )
          (i32.mul
           (i32.wrap_i64
            (local.get $35)
           )
           (i32.const 1)
          )
         )
        )
        (i32.const 255)
       )
      )
      (local.set $33
       (local.get $35)
      )
      (local.set $87
       (i64.const 6)
      )
      (local.set $37
       (local.get $87)
      )
      (local.set $88
       (i64.or
        (i64.extend_i32_u
         (i32.add
          (local.get $2)
          (i32.const 96)
         )
        )
        (i64.const 34359738368)
       )
      )
      (local.set $89
       (local.get $37)
      )
      (local.set $90
       (i32.load align=1
        (i32.add
         (i32.wrap_i64
          (local.get $88)
         )
         (i32.mul
          (i32.wrap_i64
           (local.get $89)
          )
          (i32.const 4)
         )
        )
       )
      )
      (local.set $39
       (local.get $90)
      )
      (local.set $39
       (i32.add
        (i32.add
         (i32.shl
          (local.get $39)
          (i32.and
           (i32.wrap_i64
            (i64.const 5)
           )
           (i32.const 31)
          )
         )
         (local.get $39)
        )
        (local.get $32)
       )
      )
      (local.set $39
       (i32.xor
        (i32.add
         (local.get $39)
         (i32.shl
          (local.get $39)
          (i32.and
           (i32.wrap_i64
            (i64.const 10)
           )
           (i32.const 31)
          )
         )
        )
        (i32.shr_u
         (local.get $39)
         (i32.and
          (i32.wrap_i64
           (i64.const 6)
          )
          (i32.const 31)
         )
        )
       )
      )
      (local.set $91
       (i64.or
        (i64.extend_i32_u
         (i32.add
          (local.get $2)
          (i32.const 96)
         )
        )
        (i64.const 34359738368)
       )
      )
      (local.set $92
       (local.get $37)
      )
      (local.set $93
       (i32.add
        (i32.wrap_i64
         (local.get $91)
        )
        (i32.mul
         (i32.wrap_i64
          (local.get $92)
         )
         (i32.const 4)
        )
       )
      )
      (local.set $94
       (local.get $39)
      )
      (i32.store align=1
       (local.get $93)
       (local.get $94)
      )
      (local.set $35
       (i64.add
        (local.get $35)
        (i64.const 1)
       )
      )
      (local.set $32
       (i32.and
        (i32.load8_u
         (i32.add
          (i32.wrap_i64
           (local.get $34)
          )
          (i32.mul
           (i32.wrap_i64
            (local.get $35)
           )
           (i32.const 1)
          )
         )
        )
        (i32.const 255)
       )
      )
      (local.set $33
       (local.get $35)
      )
      (local.set $95
       (i64.const 7)
      )
      (local.set $37
       (local.get $95)
      )
      (local.set $96
       (i64.or
        (i64.extend_i32_u
         (i32.add
          (local.get $2)
          (i32.const 96)
         )
        )
        (i64.const 34359738368)
       )
      )
      (local.set $97
       (local.get $37)
      )
      (local.set $98
       (i32.load align=1
        (i32.add
         (i32.wrap_i64
          (local.get $96)
         )
         (i32.mul
          (i32.wrap_i64
           (local.get $97)
          )
          (i32.const 4)
         )
        )
       )
      )
      (local.set $39
       (local.get $98)
      )
      (local.set $39
       (i32.add
        (i32.add
         (i32.shl
          (local.get $39)
          (i32.and
           (i32.wrap_i64
            (i64.const 5)
           )
           (i32.const 31)
          )
         )
         (local.get $39)
        )
        (local.get $32)
       )
      )
      (local.set $39
       (i32.xor
        (i32.add
         (local.get $39)
         (i32.shl
          (local.get $39)
          (i32.and
           (i32.wrap_i64
            (i64.const 10)
           )
           (i32.const 31)
          )
         )
        )
        (i32.shr_u
         (local.get $39)
         (i32.and
          (i32.wrap_i64
           (i64.const 6)
          )
          (i32.const 31)
         )
        )
       )
      )
      (local.set $99
       (i64.or
        (i64.extend_i32_u
         (i32.add
          (local.get $2)
          (i32.const 96)
         )
        )
        (i64.const 34359738368)
       )
      )
      (local.set $100
       (local.get $37)
      )
      (local.set $101
       (i32.add
        (i32.wrap_i64
         (local.get $99)
        )
        (i32.mul
         (i32.wrap_i64
          (local.get $100)
         )
         (i32.const 4)
        )
       )
      )
      (local.set $102
       (local.get $39)
      )
      (i32.store align=1
       (local.get $101)
       (local.get $102)
      )
      (local.set $35
       (i64.add
        (local.get $35)
        (i64.const 1)
       )
      )
      (br $label1)
     )
    )
    (block $block2
     (br_if $block2
      (i64.ge_u
       (local.get $35)
       (local.get $36)
      )
     )
     (local.set $32
      (i32.and
       (i32.load8_u
        (i32.add
         (i32.wrap_i64
          (local.get $34)
         )
         (i32.mul
          (i32.wrap_i64
           (local.get $35)
          )
          (i32.const 1)
         )
        )
       )
       (i32.const 255)
      )
     )
     (local.set $33
      (local.get $35)
     )
     (local.set $103
      (i64.const 0)
     )
     (local.set $37
      (local.get $103)
     )
     (local.set $104
      (i64.or
       (i64.extend_i32_u
        (i32.add
         (local.get $2)
         (i32.const 96)
        )
       )
       (i64.const 34359738368)
      )
     )
     (local.set $105
      (local.get $37)
     )
     (local.set $106
      (i32.load align=1
       (i32.add
        (i32.wrap_i64
         (local.get $104)
        )
        (i32.mul
         (i32.wrap_i64
          (local.get $105)
         )
         (i32.const 4)
        )
       )
      )
     )
     (local.set $39
      (local.get $106)
     )
     (local.set $39
      (i32.add
       (i32.add
        (i32.shl
         (local.get $39)
         (i32.and
          (i32.wrap_i64
           (i64.const 5)
          )
          (i32.const 31)
         )
        )
        (local.get $39)
       )
       (local.get $32)
      )
     )
     (local.set $39
      (i32.xor
       (i32.add
        (local.get $39)
        (i32.shl
         (local.get $39)
         (i32.and
          (i32.wrap_i64
           (i64.const 10)
          )
          (i32.const 31)
         )
        )
       )
       (i32.shr_u
        (local.get $39)
        (i32.and
         (i32.wrap_i64
          (i64.const 6)
         )
         (i32.const 31)
        )
       )
      )
     )
     (local.set $107
      (i64.or
       (i64.extend_i32_u
        (i32.add
         (local.get $2)
         (i32.const 96)
        )
       )
       (i64.const 34359738368)
      )
     )
     (local.set $108
      (local.get $37)
     )
     (local.set $109
      (i32.add
       (i32.wrap_i64
        (local.get $107)
       )
       (i32.mul
        (i32.wrap_i64
         (local.get $108)
        )
        (i32.const 4)
       )
      )
     )
     (local.set $110
      (local.get $39)
     )
     (i32.store align=1
      (local.get $109)
      (local.get $110)
     )
     (local.set $35
      (i64.add
       (local.get $35)
       (i64.const 1)
      )
     )
     (br_if $block2
      (i64.ge_u
       (local.get $35)
       (local.get $36)
      )
     )
     (local.set $32
      (i32.and
       (i32.load8_u
        (i32.add
         (i32.wrap_i64
          (local.get $34)
         )
         (i32.mul
          (i32.wrap_i64
           (local.get $35)
          )
          (i32.const 1)
         )
        )
       )
       (i32.const 255)
      )
     )
     (local.set $33
      (local.get $35)
     )
     (local.set $111
      (i64.const 1)
     )
     (local.set $37
      (local.get $111)
     )
     (local.set $112
      (i64.or
       (i64.extend_i32_u
        (i32.add
         (local.get $2)
         (i32.const 96)
        )
       )
       (i64.const 34359738368)
      )
     )
     (local.set $113
      (local.get $37)
     )
     (local.set $114
      (i32.load align=1
       (i32.add
        (i32.wrap_i64
         (local.get $112)
        )
        (i32.mul
         (i32.wrap_i64
          (local.get $113)
         )
         (i32.const 4)
        )
       )
      )
     )
     (local.set $39
      (local.get $114)
     )
     (local.set $39
      (i32.add
       (i32.add
        (i32.shl
         (local.get $39)
         (i32.and
          (i32.wrap_i64
           (i64.const 5)
          )
          (i32.const 31)
         )
        )
        (local.get $39)
       )
       (local.get $32)
      )
     )
     (local.set $39
      (i32.xor
       (i32.add
        (local.get $39)
        (i32.shl
         (local.get $39)
         (i32.and
          (i32.wrap_i64
           (i64.const 10)
          )
          (i32.const 31)
         )
        )
       )
       (i32.shr_u
        (local.get $39)
        (i32.and
         (i32.wrap_i64
          (i64.const 6)
         )
         (i32.const 31)
        )
       )
      )
     )
     (local.set $115
      (i64.or
       (i64.extend_i32_u
        (i32.add
         (local.get $2)
         (i32.const 96)
        )
       )
       (i64.const 34359738368)
      )
     )
     (local.set $116
      (local.get $37)
     )
     (local.set $117
      (i32.add
       (i32.wrap_i64
        (local.get $115)
       )
       (i32.mul
        (i32.wrap_i64
         (local.get $116)
        )
        (i32.const 4)
       )
      )
     )
     (local.set $118
      (local.get $39)
     )
     (i32.store align=1
      (local.get $117)
      (local.get $118)
     )
     (local.set $35
      (i64.add
       (local.get $35)
       (i64.const 1)
      )
     )
     (br_if $block2
      (i64.ge_u
       (local.get $35)
       (local.get $36)
      )
     )
     (local.set $32
      (i32.and
       (i32.load8_u
        (i32.add
         (i32.wrap_i64
          (local.get $34)
         )
         (i32.mul
          (i32.wrap_i64
           (local.get $35)
          )
          (i32.const 1)
         )
        )
       )
       (i32.const 255)
      )
     )
     (local.set $33
      (local.get $35)
     )
     (local.set $119
      (i64.const 2)
     )
     (local.set $37
      (local.get $119)
     )
     (local.set $120
      (i64.or
       (i64.extend_i32_u
        (i32.add
         (local.get $2)
         (i32.const 96)
        )
       )
       (i64.const 34359738368)
      )
     )
     (local.set $121
      (local.get $37)
     )
     (local.set $122
      (i32.load align=1
       (i32.add
        (i32.wrap_i64
         (local.get $120)
        )
        (i32.mul
         (i32.wrap_i64
          (local.get $121)
         )
         (i32.const 4)
        )
       )
      )
     )
     (local.set $39
      (local.get $122)
     )
     (local.set $39
      (i32.add
       (i32.add
        (i32.shl
         (local.get $39)
         (i32.and
          (i32.wrap_i64
           (i64.const 5)
          )
          (i32.const 31)
         )
        )
        (local.get $39)
       )
       (local.get $32)
      )
     )
     (local.set $39
      (i32.xor
       (i32.add
        (local.get $39)
        (i32.shl
         (local.get $39)
         (i32.and
          (i32.wrap_i64
           (i64.const 10)
          )
          (i32.const 31)
         )
        )
       )
       (i32.shr_u
        (local.get $39)
        (i32.and
         (i32.wrap_i64
          (i64.const 6)
         )
         (i32.const 31)
        )
       )
      )
     )
     (local.set $123
      (i64.or
       (i64.extend_i32_u
        (i32.add
         (local.get $2)
         (i32.const 96)
        )
       )
       (i64.const 34359738368)
      )
     )
     (local.set $124
      (local.get $37)
     )
     (local.set $125
      (i32.add
       (i32.wrap_i64
        (local.get $123)
       )
       (i32.mul
        (i32.wrap_i64
         (local.get $124)
        )
        (i32.const 4)
       )
      )
     )
     (local.set $126
      (local.get $39)
     )
     (i32.store align=1
      (local.get $125)
      (local.get $126)
     )
     (local.set $35
      (i64.add
       (local.get $35)
       (i64.const 1)
      )
     )
     (br_if $block2
      (i64.ge_u
       (local.get $35)
       (local.get $36)
      )
     )
     (local.set $32
      (i32.and
       (i32.load8_u
        (i32.add
         (i32.wrap_i64
          (local.get $34)
         )
         (i32.mul
          (i32.wrap_i64
           (local.get $35)
          )
          (i32.const 1)
         )
        )
       )
       (i32.const 255)
      )
     )
     (local.set $33
      (local.get $35)
     )
     (local.set $127
      (i64.const 3)
     )
     (local.set $37
      (local.get $127)
     )
     (local.set $128
      (i64.or
       (i64.extend_i32_u
        (i32.add
         (local.get $2)
         (i32.const 96)
        )
       )
       (i64.const 34359738368)
      )
     )
     (local.set $129
      (local.get $37)
     )
     (local.set $130
      (i32.load align=1
       (i32.add
        (i32.wrap_i64
         (local.get $128)
        )
        (i32.mul
         (i32.wrap_i64
          (local.get $129)
         )
         (i32.const 4)
        )
       )
      )
     )
     (local.set $39
      (local.get $130)
     )
     (local.set $39
      (i32.add
       (i32.add
        (i32.shl
         (local.get $39)
         (i32.and
          (i32.wrap_i64
           (i64.const 5)
          )
          (i32.const 31)
         )
        )
        (local.get $39)
       )
       (local.get $32)
      )
     )
     (local.set $39
      (i32.xor
       (i32.add
        (local.get $39)
        (i32.shl
         (local.get $39)
         (i32.and
          (i32.wrap_i64
           (i64.const 10)
          )
          (i32.const 31)
         )
        )
       )
       (i32.shr_u
        (local.get $39)
        (i32.and
         (i32.wrap_i64
          (i64.const 6)
         )
         (i32.const 31)
        )
       )
      )
     )
     (local.set $131
      (i64.or
       (i64.extend_i32_u
        (i32.add
         (local.get $2)
         (i32.const 96)
        )
       )
       (i64.const 34359738368)
      )
     )
     (local.set $132
      (local.get $37)
     )
     (local.set $133
      (i32.add
       (i32.wrap_i64
        (local.get $131)
       )
       (i32.mul
        (i32.wrap_i64
         (local.get $132)
        )
        (i32.const 4)
       )
      )
     )
     (local.set $134
      (local.get $39)
     )
     (i32.store align=1
      (local.get $133)
      (local.get $134)
     )
     (local.set $35
      (i64.add
       (local.get $35)
       (i64.const 1)
      )
     )
     (br_if $block2
      (i64.ge_u
       (local.get $35)
       (local.get $36)
      )
     )
     (local.set $32
      (i32.and
       (i32.load8_u
        (i32.add
         (i32.wrap_i64
          (local.get $34)
         )
         (i32.mul
          (i32.wrap_i64
           (local.get $35)
          )
          (i32.const 1)
         )
        )
       )
       (i32.const 255)
      )
     )
     (local.set $33
      (local.get $35)
     )
     (local.set $135
      (i64.const 4)
     )
     (local.set $37
      (local.get $135)
     )
     (local.set $136
      (i64.or
       (i64.extend_i32_u
        (i32.add
         (local.get $2)
         (i32.const 96)
        )
       )
       (i64.const 34359738368)
      )
     )
     (local.set $137
      (local.get $37)
     )
     (local.set $138
      (i32.load align=1
       (i32.add
        (i32.wrap_i64
         (local.get $136)
        )
        (i32.mul
         (i32.wrap_i64
          (local.get $137)
         )
         (i32.const 4)
        )
       )
      )
     )
     (local.set $39
      (local.get $138)
     )
     (local.set $39
      (i32.add
       (i32.add
        (i32.shl
         (local.get $39)
         (i32.and
          (i32.wrap_i64
           (i64.const 5)
          )
          (i32.const 31)
         )
        )
        (local.get $39)
       )
       (local.get $32)
      )
     )
     (local.set $39
      (i32.xor
       (i32.add
        (local.get $39)
        (i32.shl
         (local.get $39)
         (i32.and
          (i32.wrap_i64
           (i64.const 10)
          )
          (i32.const 31)
         )
        )
       )
       (i32.shr_u
        (local.get $39)
        (i32.and
         (i32.wrap_i64
          (i64.const 6)
         )
         (i32.const 31)
        )
       )
      )
     )
     (local.set $139
      (i64.or
       (i64.extend_i32_u
        (i32.add
         (local.get $2)
         (i32.const 96)
        )
       )
       (i64.const 34359738368)
      )
     )
     (local.set $140
      (local.get $37)
     )
     (local.set $141
      (i32.add
       (i32.wrap_i64
        (local.get $139)
       )
       (i32.mul
        (i32.wrap_i64
         (local.get $140)
        )
        (i32.const 4)
       )
      )
     )
     (local.set $142
      (local.get $39)
     )
     (i32.store align=1
      (local.get $141)
      (local.get $142)
     )
     (local.set $35
      (i64.add
       (local.get $35)
       (i64.const 1)
      )
     )
     (br_if $block2
      (i64.ge_u
       (local.get $35)
       (local.get $36)
      )
     )
     (local.set $32
      (i32.and
       (i32.load8_u
        (i32.add
         (i32.wrap_i64
          (local.get $34)
         )
         (i32.mul
          (i32.wrap_i64
           (local.get $35)
          )
          (i32.const 1)
         )
        )
       )
       (i32.const 255)
      )
     )
     (local.set $33
      (local.get $35)
     )
     (local.set $143
      (i64.const 5)
     )
     (local.set $37
      (local.get $143)
     )
     (local.set $144
      (i64.or
       (i64.extend_i32_u
        (i32.add
         (local.get $2)
         (i32.const 96)
        )
       )
       (i64.const 34359738368)
      )
     )
     (local.set $145
      (local.get $37)
     )
     (local.set $146
      (i32.load align=1
       (i32.add
        (i32.wrap_i64
         (local.get $144)
        )
        (i32.mul
         (i32.wrap_i64
          (local.get $145)
         )
         (i32.const 4)
        )
       )
      )
     )
     (local.set $39
      (local.get $146)
     )
     (local.set $39
      (i32.add
       (i32.add
        (i32.shl
         (local.get $39)
         (i32.and
          (i32.wrap_i64
           (i64.const 5)
          )
          (i32.const 31)
         )
        )
        (local.get $39)
       )
       (local.get $32)
      )
     )
     (local.set $39
      (i32.xor
       (i32.add
        (local.get $39)
        (i32.shl
         (local.get $39)
         (i32.and
          (i32.wrap_i64
           (i64.const 10)
          )
          (i32.const 31)
         )
        )
       )
       (i32.shr_u
        (local.get $39)
        (i32.and
         (i32.wrap_i64
          (i64.const 6)
         )
         (i32.const 31)
        )
       )
      )
     )
     (local.set $147
      (i64.or
       (i64.extend_i32_u
        (i32.add
         (local.get $2)
         (i32.const 96)
        )
       )
       (i64.const 34359738368)
      )
     )
     (local.set $148
      (local.get $37)
     )
     (local.set $149
      (i32.add
       (i32.wrap_i64
        (local.get $147)
       )
       (i32.mul
        (i32.wrap_i64
         (local.get $148)
        )
        (i32.const 4)
       )
      )
     )
     (local.set $150
      (local.get $39)
     )
     (i32.store align=1
      (local.get $149)
      (local.get $150)
     )
     (local.set $35
      (i64.add
       (local.get $35)
       (i64.const 1)
      )
     )
     (br_if $block2
      (i64.ge_u
       (local.get $35)
       (local.get $36)
      )
     )
     (local.set $32
      (i32.and
       (i32.load8_u
        (i32.add
         (i32.wrap_i64
          (local.get $34)
         )
         (i32.mul
          (i32.wrap_i64
           (local.get $35)
          )
          (i32.const 1)
         )
        )
       )
       (i32.const 255)
      )
     )
     (local.set $33
      (local.get $35)
     )
     (local.set $151
      (i64.const 6)
     )
     (local.set $37
      (local.get $151)
     )
     (local.set $152
      (i64.or
       (i64.extend_i32_u
        (i32.add
         (local.get $2)
         (i32.const 96)
        )
       )
       (i64.const 34359738368)
      )
     )
     (local.set $153
      (local.get $37)
     )
     (local.set $154
      (i32.load align=1
       (i32.add
        (i32.wrap_i64
         (local.get $152)
        )
        (i32.mul
         (i32.wrap_i64
          (local.get $153)
         )
         (i32.const 4)
        )
       )
      )
     )
     (local.set $39
      (local.get $154)
     )
     (local.set $39
      (i32.add
       (i32.add
        (i32.shl
         (local.get $39)
         (i32.and
          (i32.wrap_i64
           (i64.const 5)
          )
          (i32.const 31)
         )
        )
        (local.get $39)
       )
       (local.get $32)
      )
     )
     (local.set $39
      (i32.xor
       (i32.add
        (local.get $39)
        (i32.shl
         (local.get $39)
         (i32.and
          (i32.wrap_i64
           (i64.const 10)
          )
          (i32.const 31)
         )
        )
       )
       (i32.shr_u
        (local.get $39)
        (i32.and
         (i32.wrap_i64
          (i64.const 6)
         )
         (i32.const 31)
        )
       )
      )
     )
     (local.set $155
      (i64.or
       (i64.extend_i32_u
        (i32.add
         (local.get $2)
         (i32.const 96)
        )
       )
       (i64.const 34359738368)
      )
     )
     (local.set $156
      (local.get $37)
     )
     (local.set $157
      (i32.add
       (i32.wrap_i64
        (local.get $155)
       )
       (i32.mul
        (i32.wrap_i64
         (local.get $156)
        )
        (i32.const 4)
       )
      )
     )
     (local.set $158
      (local.get $39)
     )
     (i32.store align=1
      (local.get $157)
      (local.get $158)
     )
     (local.set $35
      (i64.add
       (local.get $35)
       (i64.const 1)
      )
     )
     (br_if $block2
      (i64.ge_u
       (local.get $35)
       (local.get $36)
      )
     )
     (local.set $32
      (i32.and
       (i32.load8_u
        (i32.add
         (i32.wrap_i64
          (local.get $34)
         )
         (i32.mul
          (i32.wrap_i64
           (local.get $35)
          )
          (i32.const 1)
         )
        )
       )
       (i32.const 255)
      )
     )
     (local.set $33
      (local.get $35)
     )
     (local.set $159
      (i64.const 7)
     )
     (local.set $37
      (local.get $159)
     )
     (local.set $160
      (i64.or
       (i64.extend_i32_u
        (i32.add
         (local.get $2)
         (i32.const 96)
        )
       )
       (i64.const 34359738368)
      )
     )
     (local.set $161
      (local.get $37)
     )
     (local.set $162
      (i32.load align=1
       (i32.add
        (i32.wrap_i64
         (local.get $160)
        )
        (i32.mul
         (i32.wrap_i64
          (local.get $161)
         )
         (i32.const 4)
        )
       )
      )
     )
     (local.set $39
      (local.get $162)
     )
     (local.set $39
      (i32.add
       (i32.add
        (i32.shl
         (local.get $39)
         (i32.and
          (i32.wrap_i64
           (i64.const 5)
          )
          (i32.const 31)
         )
        )
        (local.get $39)
       )
       (local.get $32)
      )
     )
     (local.set $39
      (i32.xor
       (i32.add
        (local.get $39)
        (i32.shl
         (local.get $39)
         (i32.and
          (i32.wrap_i64
           (i64.const 10)
          )
          (i32.const 31)
         )
        )
       )
       (i32.shr_u
        (local.get $39)
        (i32.and
         (i32.wrap_i64
          (i64.const 6)
         )
         (i32.const 31)
        )
       )
      )
     )
     (local.set $163
      (i64.or
       (i64.extend_i32_u
        (i32.add
         (local.get $2)
         (i32.const 96)
        )
       )
       (i64.const 34359738368)
      )
     )
     (local.set $164
      (local.get $37)
     )
     (local.set $165
      (i32.add
       (i32.wrap_i64
        (local.get $163)
       )
       (i32.mul
        (i32.wrap_i64
         (local.get $164)
        )
        (i32.const 4)
       )
      )
     )
     (local.set $166
      (local.get $39)
     )
     (i32.store align=1
      (local.get $165)
      (local.get $166)
     )
     (local.set $35
      (i64.add
       (local.get $35)
       (i64.const 1)
      )
     )
    )
    (local.set $168
     (i64.const 0)
    )
    (local.set $169
     (i64.const 8)
    )
    (local.set $170
     (i64.const 0)
    )
    (block $block3
     (loop $label2
      (br_if $block3
       (i64.ge_s
        (local.get $168)
        (local.get $169)
       )
      )
      (local.set $167
       (local.get $168)
      )
      (block
       (local.set $172
        (i64.or
         (i64.extend_i32_u
          (i32.add
           (local.get $2)
           (i32.const 96)
          )
         )
         (i64.const 34359738368)
        )
       )
       (local.set $173
        (local.get $167)
       )
       (local.set $174
        (i32.load align=1
         (i32.add
          (i32.wrap_i64
           (local.get $172)
          )
          (i32.mul
           (i32.wrap_i64
            (local.get $173)
           )
           (i32.const 4)
          )
         )
        )
       )
       (local.set $171
        (local.get $174)
       )
       (local.set $175
        (i64.or
         (i64.extend_i32_u
          (i32.add
           (local.get $2)
           (i32.const 32)
          )
         )
         (i64.const 137438953472)
        )
       )
       (local.set $176
        (i64.mul
         (local.get $167)
         (i64.const 4)
        )
       )
       (local.set $177
        (i32.add
         (i32.wrap_i64
          (local.get $175)
         )
         (i32.mul
          (i32.wrap_i64
           (local.get $176)
          )
          (i32.const 1)
         )
        )
       )
       (local.set $178
        (i32.shr_u
         (local.get $171)
         (i32.and
          (i32.wrap_i64
           (i64.const 24)
          )
          (i32.const 31)
         )
        )
       )
       (local.set $179
        (i32.and
         (i32.and
          (i32.and
           (local.get $178)
           (i32.const 255)
          )
          (i32.const 255)
         )
         (i32.const 255)
        )
       )
       (i32.store8
        (local.get $177)
        (local.get $179)
       )
       (local.set $180
        (i64.or
         (i64.extend_i32_u
          (i32.add
           (local.get $2)
           (i32.const 32)
          )
         )
         (i64.const 137438953472)
        )
       )
       (local.set $181
        (i64.add
         (i64.mul
          (local.get $167)
          (i64.const 4)
         )
         (i64.const 1)
        )
       )
       (local.set $182
        (i32.add
         (i32.wrap_i64
          (local.get $180)
         )
         (i32.mul
          (i32.wrap_i64
           (local.get $181)
          )
          (i32.const 1)
         )
        )
       )
       (local.set $183
        (i32.shr_u
         (local.get $171)
         (i32.and
          (i32.wrap_i64
           (i64.const 16)
          )
          (i32.const 31)
         )
        )
       )
       (local.set $184
        (i32.and
         (i32.and
          (i32.and
           (local.get $183)
           (i32.const 255)
          )
          (i32.const 255)
         )
         (i32.const 255)
        )
       )
       (i32.store8
        (local.get $182)
        (local.get $184)
       )
       (local.set $185
        (i64.or
         (i64.extend_i32_u
          (i32.add
           (local.get $2)
           (i32.const 32)
          )
         )
         (i64.const 137438953472)
        )
       )
       (local.set $186
        (i64.add
         (i64.mul
          (local.get $167)
          (i64.const 4)
         )
         (i64.const 2)
        )
       )
       (local.set $187
        (i32.add
         (i32.wrap_i64
          (local.get $185)
         )
         (i32.mul
          (i32.wrap_i64
           (local.get $186)
          )
          (i32.const 1)
         )
        )
       )
       (local.set $188
        (i32.shr_u
         (local.get $171)
         (i32.and
          (i32.wrap_i64
           (i64.const 8)
          )
          (i32.const 31)
         )
        )
       )
       (local.set $189
        (i32.and
         (i32.and
          (i32.and
           (local.get $188)
           (i32.const 255)
          )
          (i32.const 255)
         )
         (i32.const 255)
        )
       )
       (i32.store8
        (local.get $187)
        (local.get $189)
       )
       (local.set $190
        (i64.or
         (i64.extend_i32_u
          (i32.add
           (local.get $2)
           (i32.const 32)
          )
         )
         (i64.const 137438953472)
        )
       )
       (local.set $191
        (i64.add
         (i64.mul
          (local.get $167)
          (i64.const 4)
         )
         (i64.const 3)
        )
       )
       (local.set $192
        (i32.add
         (i32.wrap_i64
          (local.get $190)
         )
         (i32.mul
          (i32.wrap_i64
           (local.get $191)
          )
          (i32.const 1)
         )
        )
       )
       (local.set $193
        (local.get $171)
       )
       (local.set $194
        (i32.and
         (i32.and
          (i32.and
           (local.get $193)
           (i32.const 255)
          )
          (i32.const 255)
         )
         (i32.const 255)
        )
       )
       (i32.store8
        (local.get $192)
        (local.get $194)
       )
      )
      (local.set $168
       (i64.add
        (local.get $168)
        (i64.const 1)
       )
      )
      (local.set $170
       (i64.add
        (local.get $170)
        (i64.const 1)
       )
      )
      (br $label2)
     )
    )
    (local.set $195
     (i32.add
      (local.get $2)
      (i32.const 32)
     )
    )
    (local.set $196
     (local.get $195)
    )
    (memory.copy
     (i32.add
      (local.get $2)
      (i32.const 160)
     )
     (local.get $196)
     (i32.const 32)
    )
    (local.set $197
     (i32.add
      (local.get $2)
      (i32.const 160)
     )
    )
    (local.set $3
     (local.get $197)
    )
    (br $block4)
   )
   (local.set $198
    (local.get $3)
   )
   (local.set $199
    (local.get $198)
   )
   (memory.copy
    (local.get $2)
    (local.get $199)
    (i32.const 32)
   )
   (local.set $203
    (block (result i32)
     (local.set $scratch_210
      (tuple.extract 2 0
       (local.tee $scratch
        (call $binary::read_u32le#8
         (i64.or
          (i64.extend_i32_u
           (local.get $2)
          )
          (i64.const 137438953472)
         )
         (i64.const 0)
        )
       )
      )
     )
     (local.set $202
      (tuple.extract 2 1
       (local.get $scratch)
      )
     )
     (local.get $scratch_210)
    )
   )
   (local.set $204
    (local.get $203)
   )
   (local.set $200
    (local.get $204)
   )
   (local.set $205
    (local.get $202)
   )
   (local.set $201
    (local.get $205)
   )
   (local.set $206
    (i32.add
     (local.get $0)
     (i32.const 8)
    )
   )
   (local.set $207
    (i32.add
     (i32.load align=1
      (local.get $206)
     )
     (local.get $200)
    )
   )
   (i32.store align=1
    (local.get $206)
    (local.get $207)
   )
  )
  (global.set $global$0
   (local.get $2)
  )
 )
 (func $binary::read_u32le#8 (param $0 i64) (param $1 i64) (result i32 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i64)
  (local $7 i64)
  (local $8 i64)
  (local $9 i64)
  (local $10 i64)
  (local $11 i64)
  (local $12 i64)
  (local $13 i64)
  (local $14 i64)
  (local $15 i32)
  (local $16 i64)
  (local $17 i64)
  (local $18 i64)
  (local $19 i64)
  (local $20 i32)
  (local $21 i64)
  (local $22 i64)
  (local $23 i32)
  (local $24 i64)
  (local $25 i64)
  (local $26 i32)
  (local.set $2
   (global.get $global$0)
  )
  (block $block
   (block
    (local.set $7
     (local.get $0)
    )
    (local.set $6
     (local.get $7)
    )
    (local.set $9
     (local.get $1)
    )
    (local.set $8
     (local.get $9)
    )
    (local.set $11
     (local.get $8)
    )
    (local.set $12
     (local.get $11)
    )
    (local.set $10
     (local.get $12)
    )
    (local.set $5
     (if (result i32)
      (i32.eqz
       (i32.eqz
        (i64.le_u
         (local.get $10)
         (block (result i64)
          (local.set $13
           (i64.shr_u
            (local.get $6)
            (i64.const 32)
           )
          )
          (local.get $13)
         )
        )
       )
      )
      (then
       (local.set $15
        (i32.eqz
         (i32.eqz
          (i64.le_u
           (i64.const 4)
           (block (result i64)
            (local.set $14
             (i64.shr_u
              (local.get $6)
              (i64.const 32)
             )
            )
            (i64.sub
             (local.get $14)
             (local.get $10)
            )
           )
          )
         )
        )
       )
       (local.get $15)
      )
      (else
       (i32.const 0)
      )
     )
    )
   )
   (if
    (i32.eqz
     (i32.eqz
      (i32.eqz
       (i32.eqz
        (i32.eqz
         (local.get $5)
        )
       )
      )
     )
    )
    (then
     (local.set $3
      (i32.const 0)
     )
     (local.set $4
      (i32.const 0)
     )
     (br $block)
    )
   )
   (local.set $16
    (local.get $0)
   )
   (local.set $17
    (local.get $1)
   )
   (if
    (i64.ge_u
     (local.get $17)
     (i64.shr_u
      (local.get $16)
      (i64.const 32)
     )
    )
    (then
     (call $goose.abort
      (i32.const 1001297)
      (i32.const 25)
      (i32.const 28)
     )
     (unreachable)
    )
   )
   (local.set $3
    (i32.or
     (i32.or
      (i32.or
       (i32.load8_u
        (i32.add
         (i32.wrap_i64
          (local.get $16)
         )
         (i32.mul
          (i32.wrap_i64
           (local.get $17)
          )
          (i32.const 1)
         )
        )
       )
       (block (result i32)
        (local.set $18
         (local.get $0)
        )
        (local.set $19
         (i64.add
          (local.get $1)
          (i64.const 1)
         )
        )
        (if
         (i64.ge_u
          (local.get $19)
          (i64.shr_u
           (local.get $18)
           (i64.const 32)
          )
         )
         (then
          (call $goose.abort
           (i32.const 1001297)
           (i32.const 25)
           (i32.const 28)
          )
          (unreachable)
         )
        )
        (local.set $20
         (i32.and
          (i32.load8_u
           (i32.add
            (i32.wrap_i64
             (local.get $18)
            )
            (i32.mul
             (i32.wrap_i64
              (local.get $19)
             )
             (i32.const 1)
            )
           )
          )
          (i32.const 255)
         )
        )
        (i32.shl
         (local.get $20)
         (i32.and
          (i32.wrap_i64
           (i64.const 8)
          )
          (i32.const 31)
         )
        )
       )
      )
      (block (result i32)
       (local.set $21
        (local.get $0)
       )
       (local.set $22
        (i64.add
         (local.get $1)
         (i64.const 2)
        )
       )
       (if
        (i64.ge_u
         (local.get $22)
         (i64.shr_u
          (local.get $21)
          (i64.const 32)
         )
        )
        (then
         (call $goose.abort
          (i32.const 1001297)
          (i32.const 25)
          (i32.const 29)
         )
         (unreachable)
        )
       )
       (local.set $23
        (i32.and
         (i32.load8_u
          (i32.add
           (i32.wrap_i64
            (local.get $21)
           )
           (i32.mul
            (i32.wrap_i64
             (local.get $22)
            )
            (i32.const 1)
           )
          )
         )
         (i32.const 255)
        )
       )
       (i32.shl
        (local.get $23)
        (i32.and
         (i32.wrap_i64
          (i64.const 16)
         )
         (i32.const 31)
        )
       )
      )
     )
     (block (result i32)
      (local.set $24
       (local.get $0)
      )
      (local.set $25
       (i64.add
        (local.get $1)
        (i64.const 3)
       )
      )
      (if
       (i64.ge_u
        (local.get $25)
        (i64.shr_u
         (local.get $24)
         (i64.const 32)
        )
       )
       (then
        (call $goose.abort
         (i32.const 1001297)
         (i32.const 25)
         (i32.const 29)
        )
        (unreachable)
       )
      )
      (local.set $26
       (i32.and
        (i32.load8_u
         (i32.add
          (i32.wrap_i64
           (local.get $24)
          )
          (i32.mul
           (i32.wrap_i64
            (local.get $25)
           )
           (i32.const 1)
          )
         )
        )
        (i32.const 255)
       )
      )
      (i32.shl
       (local.get $26)
       (i32.and
        (i32.wrap_i64
         (i64.const 24)
        )
        (i32.const 31)
       )
      )
     )
    )
   )
   (local.set $4
    (i32.const 1)
   )
   (br $block)
  )
  (global.set $global$0
   (local.get $2)
  )
  (tuple.make 2
   (local.get $3)
   (local.get $4)
  )
 )
 (func $_start
  (local $0 i32)
  (local $1 f64)
  (local $2 f64)
  (local $3 f64)
  (local $4 f64)
  (local $5 f64)
  (local $6 f64)
  (local $7 f64)
  (local $8 f64)
  (local $9 f64)
  (local $10 f64)
  (local $11 f64)
  (local $12 f64)
  (local $13 f64)
  (local $14 f64)
  (local $15 f64)
  (local $16 f64)
  (local $17 f64)
  (local $18 f64)
  (local $19 f64)
  (local $20 f64)
  (local $21 f64)
  (local $22 f64)
  (local $23 f64)
  (local $24 f64)
  (local $25 f64)
  (local $26 f64)
  (local $27 f64)
  (local $28 f64)
  (local $29 f64)
  (local $30 f64)
  (local $31 f64)
  (local $32 f64)
  (local $33 f64)
  (local $34 f64)
  (local $35 f64)
  (local $36 f64)
  (local $37 f64)
  (local $38 f64)
  (local $39 f64)
  (local $40 f64)
  (local $41 f64)
  (local $42 f64)
  (local $43 f64)
  (local $44 f64)
  (local $45 f64)
  (local $46 f64)
  (local $47 i32)
  (local $48 i32)
  (local $49 i64)
  (local $50 i64)
  (local $51 i64)
  (local $52 i64)
  (local $53 i64)
  (local $54 i64)
  (local $55 i64)
  (local $56 i64)
  (local $57 i32)
  (local $58 i32)
  (local $59 i64)
  (local $60 i64)
  (local $61 i32)
  (local $62 i32)
  (local $63 i32)
  (local $64 i32)
  (local $65 i32)
  (local.set $0
   (global.get $global$0)
  )
  (local.set $65
   (i32.add
    (local.get $0)
    (i32.const 1000184)
   )
  )
  (if
   (i32.lt_u
    (local.get $65)
    (local.get $0)
   )
   (then
    (call $goose.abort
     (i32.const 1001338)
     (i32.const 25)
     (i32.const 0)
    )
    (unreachable)
   )
  )
  (if
   (i32.gt_u
    (local.get $65)
    (i32.shl
     (memory.size)
     (i32.const 16)
    )
   )
   (then
    (if
     (i32.eq
      (memory.grow
       (i32.sub
        (i32.add
         (i32.shr_u
          (local.get $65)
          (i32.const 16)
         )
         (i32.eqz
          (i32.eqz
           (i32.and
            (local.get $65)
            (i32.const 65535)
           )
          )
         )
        )
        (memory.size)
       )
      )
      (i32.const -1)
     )
     (then
      (call $goose.abort
       (i32.const 1001363)
       (i32.const 23)
       (i32.const 0)
      )
      (unreachable)
     )
    )
   )
  )
  (global.set $global$0
   (local.get $65)
  )
  (block
   (memory.fill
    (local.get $0)
    (i32.const 0)
    (i32.const 184)
   )
   (local.set $1
    (f64.const 1)
   )
   (local.set $2
    (local.get $1)
   )
   (f64.store align=1
    (local.get $0)
    (local.get $2)
   )
   (local.set $3
    (f64.const 10)
   )
   (local.set $4
    (local.get $3)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 8)
    )
    (local.get $4)
   )
   (local.set $5
    (f64.const 100)
   )
   (local.set $6
    (local.get $5)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 16)
    )
    (local.get $6)
   )
   (local.set $7
    (f64.const 1e3)
   )
   (local.set $8
    (local.get $7)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 24)
    )
    (local.get $8)
   )
   (local.set $9
    (f64.const 1e4)
   )
   (local.set $10
    (local.get $9)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 32)
    )
    (local.get $10)
   )
   (local.set $11
    (f64.const 1e5)
   )
   (local.set $12
    (local.get $11)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 40)
    )
    (local.get $12)
   )
   (local.set $13
    (f64.const 1e6)
   )
   (local.set $14
    (local.get $13)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 48)
    )
    (local.get $14)
   )
   (local.set $15
    (f64.const 1e7)
   )
   (local.set $16
    (local.get $15)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 56)
    )
    (local.get $16)
   )
   (local.set $17
    (f64.const 1e8)
   )
   (local.set $18
    (local.get $17)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 64)
    )
    (local.get $18)
   )
   (local.set $19
    (f64.const 1e9)
   )
   (local.set $20
    (local.get $19)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 72)
    )
    (local.get $20)
   )
   (local.set $21
    (f64.const 1e10)
   )
   (local.set $22
    (local.get $21)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 80)
    )
    (local.get $22)
   )
   (local.set $23
    (f64.const 1e11)
   )
   (local.set $24
    (local.get $23)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 88)
    )
    (local.get $24)
   )
   (local.set $25
    (f64.const 1e12)
   )
   (local.set $26
    (local.get $25)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 96)
    )
    (local.get $26)
   )
   (local.set $27
    (f64.const 1e13)
   )
   (local.set $28
    (local.get $27)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 104)
    )
    (local.get $28)
   )
   (local.set $29
    (f64.const 1e14)
   )
   (local.set $30
    (local.get $29)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 112)
    )
    (local.get $30)
   )
   (local.set $31
    (f64.const 1e15)
   )
   (local.set $32
    (local.get $31)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 120)
    )
    (local.get $32)
   )
   (local.set $33
    (f64.const 1e16)
   )
   (local.set $34
    (local.get $33)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 128)
    )
    (local.get $34)
   )
   (local.set $35
    (f64.const 1e17)
   )
   (local.set $36
    (local.get $35)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 136)
    )
    (local.get $36)
   )
   (local.set $37
    (f64.const 1e18)
   )
   (local.set $38
    (local.get $37)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 144)
    )
    (local.get $38)
   )
   (local.set $39
    (f64.const 1e19)
   )
   (local.set $40
    (local.get $39)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 152)
    )
    (local.get $40)
   )
   (local.set $41
    (f64.const 1e20)
   )
   (local.set $42
    (local.get $41)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 160)
    )
    (local.get $42)
   )
   (local.set $43
    (f64.const 1e21)
   )
   (local.set $44
    (local.get $43)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 168)
    )
    (local.get $44)
   )
   (local.set $45
    (f64.const 1e22)
   )
   (local.set $46
    (local.get $45)
   )
   (f64.store align=1
    (i32.add
     (local.get $0)
     (i32.const 176)
    )
    (local.get $46)
   )
   (local.set $47
    (local.get $0)
   )
   (local.set $48
    (local.get $47)
   )
   (memory.copy
    (i32.const 1024)
    (local.get $48)
    (i32.const 184)
   )
   (local.set $49
    (i64.const 139968)
   )
   (local.set $50
    (local.get $49)
   )
   (i64.store align=1
    (i32.const 1208)
    (local.get $50)
   )
   (local.set $51
    (i64.const 3877)
   )
   (local.set $52
    (local.get $51)
   )
   (i64.store align=1
    (i32.const 1216)
    (local.get $52)
   )
   (local.set $53
    (i64.const 29573)
   )
   (local.set $54
    (local.get $53)
   )
   (i64.store align=1
    (i32.const 1224)
    (local.get $54)
   )
   (local.set $55
    (i64.const 42)
   )
   (local.set $56
    (local.get $55)
   )
   (i64.store align=1
    (i32.const 1232)
    (local.get $56)
   )
   (local.set $57
    (i32.const 42)
   )
   (local.set $58
    (local.get $57)
   )
   (i32.store align=1
    (i32.const 1240)
    (local.get $58)
   )
   (local.set $59
    (i64.const 0)
   )
   (local.set $60
    (local.get $59)
   )
   (i64.store align=1
    (i32.const 1248)
    (local.get $60)
   )
   (memory.fill
    (i32.add
     (local.get $0)
     (i32.const 184)
    )
    (i32.const 0)
    (i32.const 1000000)
   )
   (local.set $61
    (i32.and
     (i32.and
      (i32.const 0)
      (i32.const 255)
     )
     (i32.const 255)
    )
   )
   (local.set $62
    (i32.const 0)
   )
   (block $block
    (loop $label
     (br_if $block
      (i32.ge_u
       (local.get $62)
       (i32.const 1000000)
      )
     )
     (i32.store8
      (i32.add
       (i32.add
        (local.get $0)
        (i32.const 184)
       )
       (i32.mul
        (local.get $62)
        (i32.const 1)
       )
      )
      (local.get $61)
     )
     (local.set $62
      (i32.add
       (local.get $62)
       (i32.const 1)
      )
     )
     (br $label)
    )
   )
   (local.set $63
    (i32.add
     (local.get $0)
     (i32.const 184)
    )
   )
   (local.set $64
    (local.get $63)
   )
   (memory.copy
    (i32.const 1256)
    (local.get $64)
    (i32.const 1000000)
   )
   (call $main#0)
  )
  (global.set $global$0
   (local.get $0)
  )
 )
 ;; custom section "goose.direct", size 508
)

