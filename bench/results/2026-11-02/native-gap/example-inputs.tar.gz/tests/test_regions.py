#!/usr/bin/env python3
"""Check stable-region resource bounds, isolation and repeated-call cleanup."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import struct
import subprocess
import sys
import tempfile
import unittest

from test_static_data import sections, uleb

ROOT = Path(__file__).resolve().parents[1]
GOOSE = ROOT / "build/bin/goose"
NODE = "node"
CANARY = 987654321

NODE_HOST = r'''
const fs = require("node:fs");
const [file, input, repeats, canaryIndex, corruptTag] = process.argv.slice(1);
const module_ = new WebAssembly.Module(fs.readFileSync(file));
const metadata = JSON.parse(new TextDecoder().decode(WebAssembly.Module.customSections(module_, "goose.regions")[0]));
let instance;
const numbers=[];
const imports = {goose: {}, env: {bench_input: () => BigInt(input)}};
for (const item of WebAssembly.Module.imports(module_)) {
  if (item.module === "goose") imports.goose[item.name] = () => {};
}
imports.goose.abort = (p,n) => { throw new Error(new TextDecoder().decode(new Uint8Array(instance.exports.memory.buffer,p>>>0,n>>>0))); };
imports.goose.print_i64 = value => numbers.push(value.toString());
instance = new WebAssembly.Instance(module_,imports);
let error = "";
try {
  instance.exports._start();
  if(corruptTag === "true") {
    const bytes=Buffer.from(instance.exports.memory.buffer);
    const at=bytes.indexOf(Buffer.from("8877665544332211","hex"));
    if(at<1) throw new Error("missing dispatch tag sentinel");
    new DataView(instance.exports.memory.buffer).setUint8(at-1,99);
  }
  for(let i=0;i<Number(repeats);i++) {
    if(instance.exports.tick(BigInt(i)) !== BigInt(i+1)) throw new Error("wrong repeated result");
  }
} catch(e) { error = String(e.message); }
let canary = null;
if(Number(canaryIndex)>=0) {
  const p=metadata.activation_limit+Number(canaryIndex)*metadata.region_bytes;
  canary=new DataView(instance.exports.memory.buffer).getBigInt64(p,true).toString();
}
process.stdout.write(JSON.stringify({error,canary,numbers,pages:instance.exports.memory.buffer.byteLength/65536}));
'''


def metadata(data):
    for kind, body in sections(data):
        if kind == 0:
            length, offset = uleb(body, 0)
            if body[offset:offset + length] == b"goose.regions":
                return json.loads(body[offset + length:])
    raise AssertionError("missing runtime resource metadata")


def wasmtime_run(path, runtime, input_value, repeats, canary_index, corrupt_tag=False):
    import wasmtime
    engine = wasmtime.Engine()
    module = wasmtime.Module.from_file(engine, str(path))
    store = wasmtime.Store(engine)
    linker = wasmtime.Linker(engine)
    numbers = []

    def abort(caller, pointer, length, line):
        memory = caller.get("memory")
        message = bytes(memory.read(caller, pointer, pointer + length)).decode()
        raise wasmtime.Trap(message)

    for item in module.imports:
        if (item.module, item.name) == ("goose", "abort"):
            linker.define_func(item.module, item.name, item.type, abort, access_caller=True)
        elif (item.module, item.name) == ("env", "bench_input"):
            linker.define_func(item.module, item.name, item.type, lambda: input_value)
        elif (item.module, item.name) == ("goose", "print_i64"):
            linker.define_func(item.module, item.name, item.type, lambda value: numbers.append(str(value)))
        elif item.module == "goose":
            linker.define_func(item.module, item.name, item.type, lambda *args: None)
        else:
            raise AssertionError(f"unexpected import {item.module}.{item.name}")
    instance = linker.instantiate(store, module)
    exports = instance.exports(store)
    error = ""
    try:
        exports["_start"](store)
        if corrupt_tag:
            memory = exports["memory"]
            at = bytes(memory.read(store)).find(bytes.fromhex("8877665544332211"))
            assert at >= 1, "missing dispatch tag sentinel"
            memory.write(store, bytes([99]), at - 1)
        for value in range(repeats):
            assert exports["tick"](store, value) == value + 1
    except wasmtime.Trap as failure:
        error = str(failure)
    memory = exports["memory"]
    canary = None
    if canary_index >= 0:
        start = runtime["activation_limit"] + canary_index * runtime["region_bytes"]
        canary = str(struct.unpack("<q", memory.read(store, start, start + 8))[0])
    return {"error": error, "canary": canary, "numbers": numbers, "pages": memory.size(store)}


class StableRegions(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(dir=ROOT / "build")
        self.addCleanup(self.tmp.cleanup)
        self.work = Path(self.tmp.name)

    def compile(self, source, level):
        path = self.work / f"O{level}.goose"
        path.write_text(source)
        output = path.with_suffix(".wasm")
        command = [str(GOOSE), str(path), "--target", "wasm-direct", "--offline", f"-O{level}",
                   "--wasm-initial-pages", "1", "--wasm-max-pages", "3", "-o", str(output)]
        result = subprocess.run(command, capture_output=True, text=True, timeout=60)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        runtime = metadata(output.read_bytes())
        self.assertGreater(runtime["region_bytes"], 0)
        self.assertLessEqual(runtime["activation_limit"] + runtime["region_count"] * runtime["region_bytes"], 3 * 65536)
        return output, runtime

    def engines(self, path, runtime, input_value=0, repeats=0, canary_index=-1, corrupt_tag=False):
        result = subprocess.run([NODE, "-e", NODE_HOST, str(path), str(input_value), str(repeats), str(canary_index), str(corrupt_tag).lower()],
                                capture_output=True, text=True, timeout=60)
        self.assertEqual(result.returncode, 0, result.stderr)
        yield "v8", json.loads(result.stdout)
        yield "wasmtime", wasmtime_run(path, runtime, input_value, repeats, canary_index, corrupt_tag)

    def test_growth_cannot_overwrite_next_region(self):
        for operation in ("resize", "push", "append"):
            extra = {"resize": "", "push": "values.push(0);", "append": "values.append([0]);"}[operation]
            source = f'''extern fn bench_input() -> i64;
var values: i64[>..] = [];
var neighbor: i64[>..] = [{CANARY}];
fn main() {{ values.resize(bench_input(), 0); {extra} }}'''
            for level in (0, 2):
                path, runtime = self.compile(source, level)
                # Cross the region boundary while remaining inside already-
                # grown memory. A missing region check corrupts neighbor.
                count = runtime["region_bytes"] // 8 + (operation == "resize")
                for engine, observed in self.engines(path, runtime, count, canary_index=1):
                    with self.subTest(operation=operation, level=level, engine=engine):
                        self.assertIn("data region exhausted", observed["error"])
                        self.assertEqual(observed["canary"], str(CANARY))

    def test_scratch_cannot_overwrite_data_region(self):
        source = f'''extern fn bench_input() -> i64;
var first: i64[>..] = [];
var second: i64[>..] = [];
fn main() {{
    let count = bench_input(); first.resize(count, 0); first[0] = {CANARY};
    second.resize(count, 11); print(first, second);
}}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            for engine, observed in self.engines(path, runtime, runtime["region_bytes"] // 8, canary_index=0):
                with self.subTest(level=level, engine=engine):
                    self.assertIn("activation/scratch arena exhausted", observed["error"])
                    self.assertEqual(observed["canary"], str(CANARY))

    def test_constructor_effects_precede_exhaustion(self):
        programs = {
            "fill": f'''var neighbor: i64[>..] = [{CANARY}];
fn value() -> i64 {{ print(123); return 1; }}
fn main() {{ var values: i64[>..] = [value(); 1000000]; }}''',
            "elements": f'''var data: i64[4096];
var neighbor: i64[>..] = [{CANARY}];
fn value(n: i64) -> const i64[4096]& {{ print(n); return data; }}
fn main() {{ var values: i64[4096][>..] = [value(1), value(2)]; }}''',
        }
        for name, source in programs.items():
            for level in (0, 2):
                path, runtime = self.compile(source, level)
                for engine, observed in self.engines(path, runtime, canary_index=0):
                    with self.subTest(program=name, level=level, engine=engine):
                        self.assertIn("data region exhausted", observed["error"])
                        self.assertEqual(observed["canary"], str(CANARY))
                        self.assertEqual(observed["numbers"], ["123"] if name == "fill" else ["1", "2"])

    def test_activation_cannot_overwrite_data_region(self):
        source = f'''extern fn bench_input() -> i64;
var neighbor: i64[>..] = [{CANARY}];
recursive fn dive(n: i64) -> i64 {{
    if n <= 0 {{ return 0; }}
    let values: i64[1024] = [n; 1024];
    let previous = dive(n - 1);
    return previous + values[n % 1024];
}}
fn main() {{ dive(bench_input()); }}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            for engine, observed in self.engines(path, runtime, 200, canary_index=0):
                with self.subTest(level=level, engine=engine):
                    self.assertIn("activation/scratch arena exhausted", observed["error"])
                    self.assertEqual(observed["canary"], str(CANARY))

    def test_repeated_calls_release_owner_regions(self):
        source = '''export fn tick(n: i64) -> i64 {
    var values: i64[>..] = [if n % 2 == 0 { return n + 1; } else { n }];
    values.push(n + 1); return values[1];
}
fn main() {}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 1)
            for engine, observed in self.engines(path, runtime, repeats=10000):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")
                    self.assertLessEqual(observed["pages"], 3)

    def test_global_regions_and_live_call_owners_are_separate(self):
        source = f'''var first: i64[>..] = [{CANARY}];
var second: i64[>..] = [22];
fn helper() -> i64 {{ var local: i64[>..] = [3]; return local[0]; }}
fn main() {{ var caller: i64[>..] = [4]; print(helper() + caller[0]); }}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual((runtime["global_regions"], runtime["region_count"]), (2, 4))
            for engine, observed in self.engines(path, runtime, canary_index=0):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")
                    self.assertEqual(observed["canary"], str(CANARY))

    def test_owned_results_forward_one_destination_through_recursion(self):
        source = f'''var neighbor: i64[>..] = [{CANARY}];
recursive fn forward(n: i64) -> i64[>..] {{
    if n <= 0 {{ var local: i64[>..] = [7]; return local; }}
    return forward(n - 1);
}}
fn main() {{ let values = forward(100); print(values[0]); }}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            # One global, one caller result, one base-case local. Recursive
            # forwarding must not acquire another result region per call.
            self.assertEqual((runtime["global_regions"], runtime["region_count"]), (1, 3))
            for engine, observed in self.engines(path, runtime, canary_index=0):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")
                    self.assertEqual(observed["numbers"], ["7"])
                    self.assertEqual(observed["canary"], str(CANARY))

    def test_owned_results_release_between_export_calls(self):
        source = '''fn make(n: i64) -> i64[>..] { return [n, n + 1]; }
export fn tick(n: i64) -> i64 { let values = make(n); return values[1]; }
fn main() {}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 1)
            for engine, observed in self.engines(path, runtime, repeats=10000):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")
                    self.assertLessEqual(observed["pages"], 3)

    def test_owned_arguments_release_on_call_and_interrupted_construction(self):
        source = f'''var neighbor: i64[>..] = [{CANARY}];
fn transform(values: i64[>..]) -> i64[>..] {{ values.push(9); return values; }}
fn consume(values: i64[>..]) -> i64 {{ return values[0] + 1; }}
export fn tick(n: i64) -> i64 {{
    let result = transform([if n % 2 == 0 {{ return n + 1; }} else {{ n }}]);
    return consume(copy(result));
}}
fn main() {{ print(consume([1]) + consume([2]) + consume([3])); }}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual((runtime["global_regions"], runtime["region_count"]), (1, 3))
            for engine, observed in self.engines(path, runtime, repeats=10000, canary_index=0):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")
                    self.assertEqual(observed["numbers"], ["9"])
                    self.assertEqual(observed["canary"], str(CANARY))
                    self.assertLessEqual(observed["pages"], 3)

    def test_owned_argument_growth_cannot_overwrite_later_argument(self):
        source = f'''extern fn bench_input() -> i64;
fn grow(values: i64[>..], neighbor: i64[>..]) -> i64 {{
    values.resize(bench_input(), 7); return neighbor[0];
}}
fn main() {{ print(grow([1], [{CANARY}])); }}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 2)
            count = runtime["region_bytes"] // 8 + 1
            for engine, observed in self.engines(path, runtime, input_value=count, canary_index=1):
                with self.subTest(level=level, engine=engine):
                    self.assertIn("data region exhausted", observed["error"])
                    self.assertEqual(observed["canary"], str(CANARY))

    def test_later_argument_exits_release_already_constructed_arguments(self):
        bodies = (
            'return consume([n], [if n % 2 == 0 { return n + 1; } else { 0 }]);',
            '''var answer = 0;
    for i in 3 {
        answer += consume([n], [if i == 0 { continue; } else { if i == 2 { break; } else { 0 } }]);
    }
    return answer;''',
        )
        for body in bodies:
            source = '''fn consume(a: i64[>..], b: i64[>..]) -> i64 { return a[0] + b[0] + 1; }
export fn tick(n: i64) -> i64 { ''' + body + ' }\nfn main() {}'
            for level in (0, 2):
                path, runtime = self.compile(source, level)
                self.assertEqual(runtime["region_count"], 2)
                for engine, observed in self.engines(path, runtime, repeats=10000):
                    with self.subTest(body=body, level=level, engine=engine):
                        self.assertEqual(observed["error"], "")

    def test_nested_owned_calls_count_peak_regions(self):
        source = '''fn transform(values: i64[>..]) -> i64[>..] { values.push(9); return values; }
export fn tick(n: i64) -> i64 {
    let result = transform(transform([n])); return result[0] + 1;
}
fn main() {}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            # At O2 the inline parameter bindings are named results and
            # construct directly in the receiving region.
            self.assertEqual(runtime["region_count"], 3 if level == 0 else 1)
            for engine, observed in self.engines(path, runtime, repeats=10000):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")

    def test_named_results_share_data_but_publish_separate_lengths(self):
        source = f'''var neighbor: i64[>..] = [{CANARY}];
fn grow(values: i64[>..]&) -> i64 {{ values[0] += 10; values.push(99); return values.len; }}
fn make(n: i64) -> i64[>..], i64, i64[>..] {{
    var values: i64[>..] = [n]; return values, grow(values), values;
}}
export fn tick(n: i64) -> i64 {{
    let first, length, second = make(n);
    if first.len != 1 || second.len != 2 || length != 2 || first[0] != n + 10 || second[1] != 99 {{ abort("bad result"); }}
    return first[0] - 9;
}}
fn main() {{}}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual((runtime["global_regions"], runtime["region_count"]), (1, 3))
            for engine, observed in self.engines(path, runtime, repeats=10000, canary_index=0):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")
                    self.assertEqual(observed["canary"], str(CANARY))

    def test_recursive_multiple_results_forward_two_regions(self):
        source = '''recursive fn forward(n: i64) -> i64[>..], i64, i64[>..] {
    if n <= 0 { return [7], 8, [9]; } return forward(n - 1);
}
fn main() { let a, b, c = forward(100); print(a[0] + b + c[0]); }'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 2)
            for engine, observed in self.engines(path, runtime):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")
                    self.assertEqual(observed["numbers"], ["24"])

    def test_two_named_locals_bind_independent_result_regions(self):
        source = '''fn make(n: i64) -> i64[>..], i64[>..] {
    var a: i64[>..] = [n]; var b: i64[>..] = [n + 1]; return a, b;
}
export fn tick(n: i64) -> i64 {
    let a, b = make(n); a[0] += 100;
    if b[0] != n + 1 { abort("aliased result regions"); } return b[0];
}
fn main() {}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 2)
            for engine, observed in self.engines(path, runtime, repeats=10000):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")

    def test_nested_owned_control_values_release_iteration_regions(self):
        source = '''export fn tick(n: i64) -> i64 {
    var step = 0;
    let result: i64[>..] = loop {
        var local: i64[>..] = [n];
        if step == 0 { step++; continue; }
        break match n % 2 {
            0 => block { var nested: i64[>..] = [n + 1]; break copy(nested); },
            _ => { local.push(n + 1); copy(local) }
        };
    };
    return result[result.len - 1];
}
fn main() {}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 3)
            for engine, observed in self.engines(path, runtime, repeats=10000):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")

    def test_interrupted_global_assignment_cannot_publish_unsafe_extent(self):
        for count in (1000000, 4294967296):
            source = f'''extern fn bench_input() -> i64;
var values: i64[>..] = [1]; var neighbor: i64[>..] = [{CANARY}];
fn reset() -> i64 {{ values = [if bench_input() >= 0 {{ return 7; }} else {{ 1 }}; {count}]; return 0; }}
fn main() {{ reset(); values[bench_input()] = 123; }}'''
            for level in (0, 2):
                path, runtime = self.compile(source, level)
                self.assertEqual((runtime["global_regions"], runtime["region_count"]), (2, 2))
                index = runtime["region_bytes"] // 8
                for engine, observed in self.engines(path, runtime, input_value=index, canary_index=1):
                    with self.subTest(count=count, level=level, engine=engine):
                        self.assertIn("data region exhausted", observed["error"])
                        self.assertEqual(observed["canary"], str(CANARY))

    def test_abandoned_dying_headers_do_not_reserve_their_extent(self):
        source = '''fn local(n: i64) -> i64 {
    var values: i64[>..] = [1]; let alias: i64[>..]& = values;
    alias = [if n >= 0 { return 7; } else { 1 }; 4294967296]; return 0;
}
fn parameter(values: i64[>..], n: i64) -> i64 {
    let alias: i64[>..]& = values;
    alias = [if n >= 0 { return 7; } else { 1 }; 4294967296]; return 0;
}
fn named(n: i64) -> i64[>..] {
    var values: i64[>..] = [1];
    values = [if n >= 0 { return [7]; } else { 1 }; 4294967296]; return values;
}
export fn tick(n: i64) -> i64 {
    let a = local(n); let b = parameter([1], n);
    for i in 2 {
        var dying: i64[>..] = [1];
        dying = [if n >= 0 { continue; } else { 1 }; 4294967296];
    }
    let result = named(n);
    if a != 7 || b != 7 { abort("wrong interrupted result"); } return n + result[0] - 6;
}
fn main() {}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 1)
            for engine, observed in self.engines(path, runtime, repeats=10000):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")

    def test_outer_headers_surviving_loop_exits_check_their_extent(self):
        bodies = (
            'loop { values = [if bench_input() >= 0 { break; } else { 1 }; 1000000]; }',
            'for i in 1 { values = [if bench_input() >= 0 { continue; } else { 1 }; 1000000]; }',
        )
        for body in bodies:
            source = f'''extern fn bench_input() -> i64;
fn main() {{
    var values: i64[>..] = [1]; var neighbor: i64[>..] = [{CANARY}];
    {body}
    values[bench_input()] = 123;
}}'''
            for level in (0, 2):
                path, runtime = self.compile(source, level)
                self.assertEqual(runtime["region_count"], 2)
                index = runtime["region_bytes"] // 8
                for engine, observed in self.engines(path, runtime, input_value=index, canary_index=1):
                    with self.subTest(body=body, level=level, engine=engine):
                        self.assertIn("data region exhausted", observed["error"])
                        self.assertEqual(observed["canary"], str(CANARY))

    def test_fixed_and_slice_results_adapt_in_two_receiving_regions(self):
        source = '''var numbers: i64[2] = [10, 11];
fn sources(n: i64) -> i64[2], i64[:], i64 { return [n, n + 1], numbers[..], n + 2; }
fn roots(n: i64) -> i64[>..], i64[>..], i64 { return sources(n); }
export fn tick(n: i64) -> i64 {
    let a, b, c = roots(n);
    if a[1] != n + 1 || b[0] != 10 || c != n + 2 { abort("wrong adapted result"); } return a[1];
}
fn main() {}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 2)
            for engine, observed in self.engines(path, runtime, repeats=10000):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")

    def test_borrowed_arguments_survive_nested_inline_calls_and_later_allocations(self):
        source = '''extern fn bench_input() -> i64;
recursive fn make(n: i64) -> i64[>..] { return [n, n + 1]; }
fn keep(owned: i64[>..], view: const i64[:]) -> const i64[:] { owned.push(99); return view; }
inline fn relay(owned: i64[>..], view: const i64[:]) -> const i64[:] {
    let body_temporary = make(200).len; if body_temporary != 2 { abort("bad body temp"); } return view;
}
fn churn(a: i64[>..], b: i64[>..], c: i64[>..]) -> i64 {
    return a[bench_input() % 2] + b[bench_input() % 2] + c[bench_input() % 2];
}
fn observe(view: const i64[:], marker: i64) -> i64 { return view[0] + view[1] + marker; }
export fn tick(n: i64) -> i64 {
    let got = observe(relay([90], keep([80], make(n))), churn([900, 901], [910, 911], [920, 921]));
    return got - n - 2730;
}
fn main() {}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 6)
            for engine, observed in self.engines(path, runtime, repeats=10000):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")

    def test_owned_control_temporary_survives_body_cleanup(self):
        expressions = (
            'block { var local: i64[>..] = [n, n + 1]; break copy(local); }',
            'if n % 2 == 0 { make(n) } else { make(n) }',
            'loop { break make(n); }',
            'match n % 2 { 0 => make(n), _ => make(n) }',
        )
        for expression in expressions:
            source = '''extern fn bench_input() -> i64;
recursive fn make(n: i64) -> i64[>..] { return [n, n + 1]; }
fn churn(a: i64[>..], b: i64[>..], c: i64[>..]) -> i64 {
    return a[bench_input() % 2] + b[bench_input() % 2] + c[bench_input() % 2];
}
fn observe(view: const i64[:], marker: i64) -> i64 { return view[0] + view[1] + marker; }
export fn tick(n: i64) -> i64 {
    let got = observe((''' + expression + ''')[..], churn([900, 901], [910, 911], [920, 921]));
    return got - n - 2730;
}
fn main() {}'''
            for level in (0, 2):
                path, runtime = self.compile(source, level)
                self.assertEqual(runtime["region_count"], 4)
                for engine, observed in self.engines(path, runtime, repeats=10000):
                    with self.subTest(expression=expression, level=level, engine=engine):
                        self.assertEqual(observed["error"], "")

    def test_condition_sequence_and_default_temporaries_release_between_evaluations(self):
        source = '''extern fn bench_input() -> i64;
recursive fn make(n: i64) -> i64[>..] { return [n, n + 1]; }
struct Defaulted { value: i64 = make(1).len }
fn churn(a: i64[>..], b: i64[>..], c: i64[>..]) -> i64 {
    return a[bench_input() % 2] + b[bench_input() % 2] + c[bench_input() % 2];
}
export fn tick(n: i64) -> i64 {
    var remaining = 20;
    while make(remaining).len == 2 && remaining > 0 { remaining--; }
    var total = 0;
    for value in make(n) { make(200); churn([900, 901], [910, 911], [920, 921]); total += value; }
    let defaults = default<Defaulted[300]>();
    return total + defaults[299].value - n - 2;
}
fn main() {}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 4)
            for engine, observed in self.engines(path, runtime, repeats=10000):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")

    def test_completed_temporary_statement_releases_region_before_recursion(self):
        source = '''recursive fn make(n: i64) -> i64[>..] { return [n, n + 1]; }
recursive fn total(n: i64) -> i64 {
    if n <= 0 { return 0; } let value = make(n).len; return total(n - 1) + value;
}
export fn tick(n: i64) -> i64 { if total(50) != 100 { abort("bad recursion"); } return n + 1; }
fn main() {}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 1)
            for engine, observed in self.engines(path, runtime, repeats=10000):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")

    def test_later_argument_exit_releases_earlier_anonymous_value(self):
        source = '''extern fn bench_input() -> i64;
recursive fn make(n: i64) -> i64[>..] { return [n, n + 1]; }
fn churn(a: i64[>..], b: i64[>..], c: i64[>..]) -> i64 {
    return a[bench_input() % 2] + b[bench_input() % 2] + c[bench_input() % 2];
}
fn observe(view: const i64[:], marker: i64) -> i64 { return view[0] + view[1] + marker; }
export fn tick(n: i64) -> i64 {
    let got = observe(make(n)[..], churn([if n % 2 == 0 { return n + 1; } else { 900 }, 901], [910, 911], [920, 921]));
    return got - n - 2730;
}
fn main() {}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 4)
            for engine, observed in self.engines(path, runtime, repeats=10000):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")

    def test_discarded_multiple_owned_results_release_both_regions(self):
        source = '''var calls = 0;
fn many(n: i64) -> i64[>..], i64[2], i64[>..<] {
    calls++; return [n], [n + 1, n + 2], [n + 3];
}
export fn tick(n: i64) -> i64 {
    many(n); if calls != n + 1 { abort("wrong discarded call"); } return calls;
}
fn main() {}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 2)
            for engine, observed in self.engines(path, runtime, repeats=10000):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")

    def test_anonymous_results_allocate_after_recursive_arguments(self):
        source = '''var calls = 0;
recursive fn pair(n: i64) -> i64, i64[>..], i64[>..<] {
    calls++; return n, [n + 1], [n + 2];
}
fn single(n: i64) -> i64[>..] { calls++; return [n]; }
recursive fn descend(n: i64) -> i64 {
    if n <= 0 { return 0; }
    pair(descend(n - 1)); single(descend(n - 1)); return n;
}
export fn tick(n: i64) -> i64 {
    calls = 0;
    if descend(5) != 5 || calls != 62 { abort("wrong recursive result"); } return n + 1;
}
fn main() {}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 2)
            for engine, observed in self.engines(path, runtime, repeats=10000):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")

    def test_variable_array_copies_and_scoped_results(self):
        source = '''recursive fn make(n: i64) -> i64[] { return [n, n + 1]; }
recursive fn changed(values: i64[]) -> i64[u32] { values[0] += 10; return values; }
fn first(values: const i64[:]) -> i64 { return values[0]; }
export fn tick(n: i64) -> i64 {
    let a = make(n); let b = changed(copy(a));
    if a[0] != n || b[0] != n + 10 || b.len != 2 { abort("bad variable copy"); }
    for i in 100 { if first(make(i)) != i { abort("bad variable temporary"); } }
    return n + 1;
}
fn main() {}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 3)
            for engine, observed in self.engines(path, runtime, repeats=10000):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")

    def test_runtime_limited_assignment_pins_receiver_and_survives_rhs_exit(self):
        source = '''fn replace(var route: i64[..]&, other: i64[..]&, n: i64) {
    route = [if n >= 0 { route .= other; 42 } else { 43 }, 44];
}
fn interrupted(values: i64[..]&, n: i64) -> i64 { values = [1, if n >= 0 { return 77; } else { 2 }]; return 0; }
export fn tick(n: i64) -> i64 {
    var left: i64[..] = [..4]; left.push(1);
    var right: i64[..] = [..5]; right.push(9);
    replace(left, right, n);
    if left.len != 2 || left[0] != 42 || left.cap != 4 || right[0] != 9 { abort("bad pinned receiver"); }
    if interrupted(left, n) != 77 || left[0] != 42 || left.len != 2 { abort("bad interrupted assignment"); }
    left = left[1..]; left.append([7, 8, 9]);
    if left.len != 4 || left.cap != 4 || left[0] != 44 || left[3] != 9 { abort("bad retained capacity"); }
    return n + 1;
}
fn main() {}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 3)
            for engine, observed in self.engines(path, runtime, repeats=10000):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")

    def test_runtime_limited_capacity_is_checked_independently_of_region_size(self):
        for operation in ("push", "append", "resize", "assign"):
            change = {"push": "values.push(3);", "append": "values.append([3]);",
                      "resize": "values.resize(3, 0);", "assign": "values = [3, 4, 5];"}[operation]
            source = f'''var values: i64[..] = [1, 2];
var neighbor: i64[>..] = [{CANARY}];
fn main() {{ {change} }}'''
            for level in (0, 2):
                path, runtime = self.compile(source, level)
                for engine, observed in self.engines(path, runtime, canary_index=1):
                    with self.subTest(operation=operation, level=level, engine=engine):
                        self.assertIn("capacity", observed["error"])
                        self.assertEqual(observed["canary"], str(CANARY))

    def test_runtime_limited_reservation_obeys_physical_region_limit(self):
        source = f'''extern fn bench_input() -> i64;
var neighbor: i64[>..] = [{CANARY}];
fn main() {{ let values: i64[..] = [..bench_input()]; print(values.len); }}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            for engine, observed in self.engines(path, runtime, input_value=runtime["region_bytes"] // 8 + 1, canary_index=0):
                with self.subTest(level=level, engine=engine):
                    self.assertIn("data region exhausted", observed["error"])
                    self.assertEqual(observed["canary"], str(CANARY))

    def test_element_run_append_temporaries_and_recursive_arguments(self):
        source = '''extern fn bench_input() -> i64;
var target: u8[>..<] = [];
var calls = 0;
recursive fn produce(n: i64) -> u8[u8] {
    var xs: u8[>..] = []; xs.resize(bench_input() + n, 7); return xs;
}
recursive fn descend(n: i64) -> i64 {
    calls++; if n <= 0 { return 0; } return descend(n - 1) + 1;
}
export fn tick(n: i64) -> i64 {
    target.clear(); calls = 0;
    for i in 5 { target.append(produce(descend(i))); }
    if calls != 15 || target.len != 1290 || target[1289] != 7 { abort("bad element run"); }
    return n + 1;
}
fn main() {}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 3)
            for engine, observed in self.engines(path, runtime, input_value=256, repeats=10000):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")

    def test_variable_struct_copies_parameters_and_prefix_references(self):
        source = '''struct Packet { tag: u8, id: i64, values: i64[] }
recursive fn make(n: i64) -> Packet { var packet = Packet { 1, n, [n, n + 1] }; return packet; }
recursive fn changed(packet: Packet) -> Packet { packet.id += 10; packet.values[0] += 20; return packet; }
export fn tick(n: i64) -> i64 {
    let a = make(n); let b = copy(a); let c = changed(copy(a));
    let kept: const i64& = a.id; b.values[0] += 100;
    if kept != n || a.values[0] != n || b.values[0] != n + 100 || c.id != n + 10 || c.values[0] != n + 20 { abort("bad struct copy"); }
    for i in 100 { if make(i).id != i { abort("bad struct temporary"); } }
    if kept != n || a.values[0] != n { abort("overwritten struct"); }
    return n + 1;
}
fn main() {}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 4)
            for engine, observed in self.engines(path, runtime, repeats=10000):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")

    def test_variable_struct_interrupted_prefix_and_tail_release_regions(self):
        source = '''struct Packet { tag: u8, id: i64, values: i64[] }
recursive fn prefix(n: i64) -> Packet {
    return Packet { 1, if n > 0 { return Packet { 1, 7, [8, 9] }; } else { 2 }, [3, 4] };
}
recursive fn tail(n: i64) -> Packet {
    return Packet { 1, 2, [3, if n > 0 { return Packet { 1, 7, [8, 9] }; } else { 4 }] };
}
export fn tick(n: i64) -> i64 {
    let a = prefix(n % 2); let b = tail(n % 2);
    let expected = if n % 2 > 0 { 7 } else { 2 };
    if a.id != expected || b.id != expected || a.values[0] != expected + 1 || b.values[1] != expected + 2 { abort("bad interrupted struct"); }
    return n + 1;
}
fn main() {}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 2)
            for engine, observed in self.engines(path, runtime, repeats=10000):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")

    def test_variable_struct_tail_exhaustion_preserves_neighbor_and_field_effects(self):
        source = f'''struct Packet {{ id: i64, values: i64[] }}
var neighbor: i64[>..] = [{CANARY}];
fn value() -> i64 {{ print(123); return 1; }}
var packet = Packet {{ 2, [value(); 1000000] }};
fn main() {{}}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 2)
            for engine, observed in self.engines(path, runtime, canary_index=0):
                with self.subTest(level=level, engine=engine):
                    self.assertIn("data region exhausted", observed["error"])
                    self.assertEqual(observed["numbers"], ["123"])
                    self.assertEqual(observed["canary"], str(CANARY))

    def test_limited_struct_field_assignment_pins_parent_and_preserves_capacity(self):
        source = '''struct Packet { id: i64, values: i64[..] }
recursive fn make(n: i64) -> Packet { return Packet { n, [n] }; }
fn replace(var route: Packet&, other: Packet&) {
    route.values = [if route.id >= 0 { route .= other; 42 } else { 43 }, 44];
}
export fn tick(n: i64) -> i64 {
    let a = Packet { n, [..4] }; a.values.push(1);
    let b = Packet { n + 10, [..5] }; b.values.push(9);
    replace(a, b); a.values = a.values[1..]; a.values.append([7, 8, 9]);
    if a.id != n || a.values.cap != 4 || a.values.len != 4 || a.values[0] != 44 || a.values[3] != 9 || b.values[0] != 9 { abort("bad limited field"); }
    return n + 1;
}
fn main() {}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 3)
            for engine, observed in self.engines(path, runtime, repeats=10000):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")


    def test_frame_struct_named_and_parameter_headers_die_on_early_return(self):
        source = '''struct Packet { id: i64, values: i64[>..] }
recursive fn named(n: i64) -> Packet {
    var packet = Packet { 0, [1] };
    packet = Packet { 2, [if n >= 0 { return Packet { 7, [8] }; } else { 1 }; 1000000] };
    return packet;
}
recursive fn parameter(var packet: Packet, n: i64) -> Packet {
    packet = Packet { 2, [if n >= 0 { return Packet { 7, [8] }; } else { 1 }; 1000000] };
    return packet;
}
export fn tick(n: i64) -> i64 {
    let a = named(n); let b = parameter(Packet { 0, [1] }, n);
    if a.id != 7 || a.values.len != 1 || a.values[0] != 8 || b.id != 7 || b.values.len != 1 || b.values[0] != 8 { abort("bad early frame result"); }
    return n + 1;
}
fn main() {}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 3)
            for engine, observed in self.engines(path, runtime, repeats=10000):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")

    def test_surviving_frame_tail_validates_abandoned_advertised_length(self):
        source = f'''extern fn bench_input() -> i64;
struct Packet {{ id: i64, values: i64[>..] }}
var packet = Packet {{ 1, [2] }};
var neighbor: i64[>..] = [{CANARY}];
fn replace(target: Packet&) {{
    target = Packet {{ 3, [if bench_input() > 0 {{ return; }} else {{ 4 }}; 1000000] }};
}}
fn main() {{ replace(packet); }}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 2)
            for engine, observed in self.engines(path, runtime, input_value=1, canary_index=1):
                with self.subTest(level=level, engine=engine):
                    self.assertIn("data region exhausted", observed["error"])
                    self.assertEqual(observed["canary"], str(CANARY))

    def test_frame_struct_assignment_pins_parent_and_releases_temporaries(self):
        source = '''struct Packet { id: i64, values: i64[>..] }
fn replace(var route: Packet&, other: Packet&) {
    route = Packet { if true { route .= other; 42 } else { 43 }, [44, 45] };
}
recursive fn make(n: i64) -> Packet { return Packet { n, [n, n + 1] }; }
export fn tick(n: i64) -> i64 {
    var a = make(n); var b = make(n + 10); replace(a, b);
    if a.id != 42 || a.values.len != 2 || a.values[0] != 44 || b.id != n + 10 || b.values[0] != n + 10 { abort("bad pinned frame"); }
    for i in 100 { if make(i).values[1] != i + 1 { abort("bad frame temporary"); } }
    return n + 1;
}
fn main() {}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 3)
            for engine, observed in self.engines(path, runtime, repeats=10000):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")


    def test_nested_owner_prefix_references_copies_and_one_tail_region(self):
        source = '''struct Inner { tag: u8, values: i64[>..] }
struct Middle { id: i64, inner: Inner }
struct Outer { tag: u16, middle: Middle }
recursive fn make(n: i64) -> Outer { var p = Outer { 1, Middle { n, Inner { 2, [n, n + 1] } } }; return p; }
recursive fn changed(p: Outer) -> Outer { p.middle.id += 10; p.middle.inner.values[0] += 20; return p; }
export fn tick(n: i64) -> i64 {
    let a = make(n); let b = copy(a); let c = changed(copy(a));
    let kept: const i64& = a.middle.id; b.middle.inner.values[0] += 100;
    if kept != n || a.middle.inner.values[0] != n || b.middle.inner.values[0] != n + 100 || c.middle.id != n + 10 || c.middle.inner.values[0] != n + 20 { abort("bad nested copy"); }
    for i in 100 { if make(i).middle.inner.values[1] != i + 1 { abort("bad nested temporary"); } }
    if kept != n || a.middle.inner.values[0] != n { abort("overwritten nested owner"); }
    return n + 1;
}
fn main() {}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 4)
            for engine, observed in self.engines(path, runtime, repeats=10000):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")

    def test_nested_tail_header_cleanup_uses_ultimate_offset(self):
        prefix = '''extern fn bench_input() -> i64;
struct Inner { id: i64, values: i64[>..] }
struct Outer { tag: u8, inner: Inner }
'''
        private = prefix + '''recursive fn make(n: i64) -> Outer {
    var p = Outer { 1, Inner { 2, [3] } };
    p = Outer { 4, Inner { 5, [if n >= 0 { return Outer { 6, Inner { 7, [8] } }; } else { 9 }; 1000000] } };
    return p;
}
export fn tick(n: i64) -> i64 {
    let p = make(n); if p.tag != 6 || p.inner.id != 7 || p.inner.values.len != 1 || p.inner.values[0] != 8 { abort("bad nested early exit"); } return n + 1;
}
fn main() {}'''
        surviving = prefix + f'''var p = Outer {{ 1, Inner {{ 2, [3] }} }};
var neighbor: i64[>..] = [{CANARY}];
fn replace(target: Outer&) {{
    target = Outer {{ 4, Inner {{ 5, [if bench_input() > 0 {{ return; }} else {{ 6 }}; 1000000] }} }};
}}
fn main() {{ replace(p); }}'''
        for level in (0, 2):
            path, runtime = self.compile(private, level)
            self.assertEqual(runtime["region_count"], 1)
            for engine, observed in self.engines(path, runtime, repeats=10000):
                with self.subTest(kind="private", level=level, engine=engine):
                    self.assertEqual(observed["error"], "")
            path, runtime = self.compile(surviving, level)
            self.assertEqual(runtime["region_count"], 2)
            for engine, observed in self.engines(path, runtime, input_value=1, canary_index=1):
                with self.subTest(kind="surviving", level=level, engine=engine):
                    self.assertIn("data region exhausted", observed["error"])
                    self.assertEqual(observed["canary"], str(CANARY))


    def test_variable_enum_images_copies_payload_references_and_temporaries(self):
        source = '''enum Event { Empty, Data { id: i64, values: i64[2] } }
recursive fn make(n: i64) -> Event.. { var e: Event.. = Event.Data { n, [n, n + 1] }; return e; }
fn changed(e: Event..) -> Event.. { match e { Data &p => { p.id += 10; p.values[0] += 20; }, _ => {} } return e; }
export fn tick(n: i64) -> i64 {
    let a = make(n); let b = copy(a); let c = changed(copy(a));
    match a { Data &p => {
        let kept: const i64& = p.id;
        match b { Data &q => { q.values[0] += 100; }, _ => {} }
        if kept != n || p.values[0] != n { abort("bad enum alias"); }
        for i in 100 { let got = match make(i) { Data q => q.id, _ => -1 }; if got != i { abort("bad enum temporary"); } }
        if kept != n || p.values[0] != n { abort("overwritten enum image"); }
    }, _ => abort("wrong enum tag") }
    let b_value = match b { Data p => p.values[0], _ => -1 };
    let c_value = match c { Data p => p.id + p.values[0], _ => -1 };
    if b_value != n + 100 || c_value != 2 * n + 30 { abort("bad enum copy"); }
    return n + 1;
}
fn main() {}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 4)
            for engine, observed in self.engines(path, runtime, repeats=10000):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")

    def test_variable_enum_interrupted_field_releases_owner(self):
        source = '''enum Event { Data { id: i64 }, Other { id: i64 } }
recursive fn make(n: i64) -> Event.. {
    return Event.Data { if n % 2 > 0 { return Event.Other { n + 10 }; } else { n } };
}
export fn tick(n: i64) -> i64 {
    let e = make(n); let value = match e { Data p => p.id, Other p => p.id - 10 };
    if value != n { abort("bad interrupted enum"); } return n + 1;
}
fn main() {}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 1)
            for engine, observed in self.engines(path, runtime, repeats=10000):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")

    def test_inactive_large_enum_alternative_does_not_reserve_data(self):
        source = f'''enum Event {{ Small {{ id:i64 }}, Big {{ values:i64[8192] }} }}
var neighbor:i64[>..] = [{CANARY}];
fn value()->i64 {{ print(123); return 1; }}
fn main() {{ let e:Event.. = Event.Small{{value()}}; }}'''
        for level in (0,2):
            path,runtime=self.compile(source,level)
            self.assertEqual(runtime["region_count"],2)
            for engine,observed in self.engines(path,runtime,canary_index=0):
                with self.subTest(level=level,engine=engine):
                    self.assertEqual(observed["error"],"")
                    self.assertEqual(observed["numbers"],["123"])
                    self.assertEqual(observed["canary"],str(CANARY))

    def test_variable_enum_active_image_overflow_preserves_neighbor(self):
        source = f'''enum Event {{ Empty, Big {{ values:i64[u32] }} }}
var neighbor:i64[>..] = [{CANARY}];
fn value()->i64 {{ print(123); return 1; }}
fn main() {{ let e:Event.. = Event.Big{{[value();1000000]}}; }}'''
        for level in (0,2):
            path,runtime=self.compile(source,level)
            self.assertEqual(runtime["region_count"],2)
            for engine,observed in self.engines(path,runtime,canary_index=0):
                with self.subTest(level=level,engine=engine):
                    self.assertIn("data region exhausted",observed["error"])
                    self.assertEqual(observed["numbers"],["123"])
                    self.assertEqual(observed["canary"],str(CANARY))

    def test_variable_enum_payload_borrows_survive_later_argument_temporaries(self):
        source = '''enum Event { Data { id: i64 } }
recursive fn make(n: i64) -> Event.. { return Event.Data { n }; }
fn observe(a: const i64&, b: const i64&) -> i64 { return a + b; }
export fn tick(n: i64) -> i64 {
    let value = observe(match make(n) { Data &p => p.id }, match make(n + 1) { Data &p => p.id });
    if value != 2 * n + 1 { abort("bad enum temporary borrow"); } return n + 1;
}
fn main() {}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 2)
            for engine, observed in self.engines(path, runtime, repeats=10000):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")


    def test_variable_variant_copies_parameters_and_stable_prefix_references(self):
        source = '''enum Event { Data { id: i64, values: i64[] }, Grow { values: i64[>..] } }
recursive fn make(n: i64) -> Event.Data { var p = Event.Data { n, [n, n + 1] }; return p; }
fn changed(p: Event.Data) -> Event.Data { p.id += 10; p.values[0] += 20; return p; }
export fn tick(n: i64) -> i64 {
    let a = make(n); let b = copy(a); let c = changed(copy(a));
    let kept: const i64& = a.id; b.values[0] += 100;
    if kept != n || a.values[0] != n || b.values[0] != n + 100 || c.id != n + 10 || c.values[0] != n + 20 { abort("bad variable variant copy"); }
    for i in 100 { if make(i).values[1] != i + 1 { abort("bad variant temporary"); } }
    if kept != n || a.values[0] != n { abort("overwritten variant"); } return n + 1;
}
fn main() {}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 4)
            for engine, observed in self.engines(path, runtime, repeats=10000):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")

    def test_variable_variant_interrupted_prefix_and_tail_release_regions(self):
        source = '''enum Event { Data { id: i64, values: i64[] } }
recursive fn prefix(n: i64) -> Event.Data {
    return Event.Data { if n > 0 { return Event.Data { 7, [8, 9] }; } else { 2 }, [3, 4] };
}
recursive fn tail(n: i64) -> Event.Data {
    return Event.Data { 2, [3, if n > 0 { return Event.Data { 7, [8, 9] }; } else { 4 }] };
}
export fn tick(n: i64) -> i64 {
    let a = prefix(n % 2); let b = tail(n % 2); let expected = if n % 2 > 0 { 7 } else { 2 };
    if a.id != expected || b.id != expected || a.values[0] != expected + 1 || b.values[1] != expected + 2 { abort("bad interrupted variant"); }
    return n + 1;
}
fn main() {}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 2)
            for engine, observed in self.engines(path, runtime, repeats=10000):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")

    def test_variable_variant_tail_exhaustion_preserves_prefix_effects_and_neighbor(self):
        source = f'''enum Event {{ Data {{ id: i64, values: i64[] }} }}
var neighbor: i64[>..] = [{CANARY}];
fn value(n: i64) -> i64 {{ print(n); return 1; }}
var p = Event.Data {{ value(123), [value(456); 1000000] }};
fn main() {{}}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 2)
            for engine, observed in self.engines(path, runtime, canary_index=0):
                with self.subTest(level=level, engine=engine):
                    self.assertIn("data region exhausted", observed["error"])
                    self.assertEqual(observed["numbers"], ["123", "456"])
                    self.assertEqual(observed["canary"], str(CANARY))

    def test_limited_variant_field_assignment_pins_parent(self):
        source = '''enum Event { Data { id: i64, values: i64[..] } }
fn replace(var route: Event.Data&, other: Event.Data&) {
    route.values = [if route.id >= 0 { route .= other; 42 } else { 43 }, 44];
}
export fn tick(n: i64) -> i64 {
    let a = Event.Data { n, [..4] }; a.values.push(1);
    let b = Event.Data { n + 10, [..5] }; b.values.push(9);
    replace(a, b); a.values = a.values[1..]; a.values.append([7, 8, 9]);
    if a.id != n || a.values.cap != 4 || a.values.len != 4 || a.values[0] != 44 || a.values[3] != 9 || b.values[0] != 9 { abort("bad limited variant"); }
    return n + 1;
}
fn main() {}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 3)
            for engine, observed in self.engines(path, runtime, repeats=10000):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")


    def test_variable_enum_tail_copies_and_simple_owned_match_arms_release_regions(self):
        source = '''enum Event { Empty, Data { id: i64, values: i64[] } }
recursive fn make(n: i64) -> Event.. { var e: Event.. = Event.Data { n, [n, n + 1] }; return e; }
fn changed(e: Event..) -> Event.. { match e { Data &p => { p.id += 10; p.values[0] += 20; }, _ => {} } return e; }
export fn tick(n: i64) -> i64 {
    let a = make(n); let b = copy(a); let c = changed(copy(a));
    match b { Data &p => { p.values[0] += 100; }, _ => {} }
    for i in 100 { let value = match a { Data p => p.id + p.values[0], _ => -1 }; if value != 2 * n { abort("bad owned match copy"); } }
    let bv = match b { Data p => p.values[0], _ => -1 };
    let cv = match c { Data p => p.id + p.values[0], _ => -1 };
    if bv != n + 100 || cv != 2 * n + 30 { abort("bad enum tail copy"); } return n + 1;
}
fn main() {}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 4)
            for engine, observed in self.engines(path, runtime, repeats=10000):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")

    def test_variable_enum_tail_alternate_returns_guard_inactive_header(self):
        source = f'''enum Event {{ Empty, Data {{ tag: u8, id: i64, values: i64[] }}, Other {{ marker: u8, first: i64, second: i64, third: i64, fourth: i64 }} }}
var neighbor: i64[>..] = [{CANARY}];
recursive fn make(n: i64) -> Event.. {{
    var e: Event.. = Event.Data {{ 1, 2, [if n == 1 {{ return Event.Other {{ 3, 4, 4294967296000000, 0, 0 }}; }} else if n == 2 {{ return Event.Data {{ 5, 6, [7] }}; }} else if n == 3 {{ return Event.Empty; }} else {{ 4 }}; 1000000] }};
    return e;
}}
export fn tick(n: i64) -> i64 {{
    let a = make(n % 3 + 1); let b = make(2);
    let av = match a {{ Empty => 0, Data &p => p.values[0], Other &p => p.first }};
    let bv = match b {{ Data &p => p.values[0], _ => -1 }};
    let expected = if n % 3 == 0 {{ 4 }} else if n % 3 == 1 {{ 7 }} else {{ 0 }};
    if av != expected || bv != 7 {{ abort("bad replaced enum tail"); }} return n + 1;
}}
fn main() {{}}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 3)
            for engine, observed in self.engines(path, runtime, repeats=10000, canary_index=0):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")
                    self.assertEqual(observed["canary"], str(CANARY))

    def test_variable_enum_private_interrupted_constructor_releases_regions(self):
        source = '''enum Event { Empty, Data { id: i64, values: i64[] } }
export fn tick(n: i64) -> i64 {
    let e: Event.. = Event.Data { 1, [if n >= 0 { return n + 1; } else { 2 }; 1000000] };
    return 0;
}
fn main() {}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 1)
            for engine, observed in self.engines(path, runtime, repeats=10000):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")

    def test_inactive_large_enum_alternative_does_not_reserve_variable_payload(self):
        source = f'''enum Event {{ Empty, Data {{ values: i64[] }}, Big {{ values: i64[8192] }} }}
var neighbor: i64[>..] = [{CANARY}];
fn main() {{ let e: Event.. = Event.Data {{ [1] }}; }}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 2)
            for engine, observed in self.engines(path, runtime, canary_index=0):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")
                    self.assertEqual(observed["canary"], str(CANARY))


    def test_variable_enum_omitted_optional_is_zeroed_after_region_reuse(self):
        source = '''enum Event { Values { values: i64[] }, Pointer { point: i64&? } }
export fn tick(n: i64) -> i64 {
    var number = n;
    if n >= 0 {
        let prior: Event.. = Event.Pointer { number };
        match prior { Pointer p => { if p.point == null { abort("missing supplied pointer"); } }, _ => {} }
    }
    let empty: Event.. = Event.Pointer {};
    match empty { Pointer p => { if p.point != null { abort("stale omitted pointer"); } }, _ => {} }
    return n + 1;
}
fn main() {}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 1)
            for engine, observed in self.engines(path, runtime, repeats=10000):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")


    def test_packed_nine_byte_elements_keep_references_and_region_bounds(self):
        source = f'''enum Flat {{ Data {{ lead: u8, value: i64 }} }}
var neighbor: i64[>..] = [{CANARY}];
export fn tick(n: i64) -> i64 {{
    var values: Flat.Data[>..] = [Flat.Data {{ 1, n }}];
    let kept: const i64& = values[0].value;
    values.append([Flat.Data {{ 2, n + 1 }}; 999]); values.append([Flat.Data {{ 3, n + 2 }}]);
    if kept != n || values.len != 1001 || values[1000].value != n + 2 {{ abort("bad packed element stride"); }} return n + 1;
}}
fn main() {{}}'''
        exhausted = f'''extern fn bench_input() -> i64;
enum Flat {{ Data {{ lead: u8, value: i64 }} }}
var values: Flat.Data[>..] = [];
var neighbor: i64[>..] = [{CANARY}];
fn main() {{ values.resize(bench_input(), Flat.Data {{ 1, 42 }}); }}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 2)
            for engine, observed in self.engines(path, runtime, repeats=10000, canary_index=0):
                with self.subTest(kind="repeated", level=level, engine=engine):
                    self.assertEqual(observed["error"], "")
                    self.assertEqual(observed["canary"], str(CANARY))
            path, runtime = self.compile(exhausted, level)
            count = runtime["region_bytes"] // 9 + 1
            for engine, observed in self.engines(path, runtime, input_value=count, canary_index=1):
                with self.subTest(kind="exhausted", level=level, engine=engine):
                    self.assertIn("data region exhausted", observed["error"])
                    self.assertEqual(observed["canary"], str(CANARY))


    def test_static_captured_growable_borrows_one_region(self):
        source = '''export fn tick(n: i64) -> i64 {
    var total = 0; var values: i64[>..] = [n];
    recursive fn add(k: i64) -> i64 { total += k; values.push(k); return values.len; }
    for i in 100 { add(i); }
    if total != 4950 || values.len != 101 || values[0] != n || values[100] != 99 { abort("bad static capture"); }
    return n + 1;
}
fn main() {}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 1)
            for engine, observed in self.engines(path, runtime, repeats=10000):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")

    def test_static_captured_record_and_enum_owners_remain_independent(self):
        source = '''struct Packet { id: i64, values: i64[>..] }
enum Event { Data { id: i64, values: i64[] } }
export fn tick(n: i64) -> i64 {
    var packet = Packet { n, [n] }; let e: Event.. = Event.Data { n, [n] };
    recursive fn change() -> i64, i64 {
        packet.id += 1; packet.values.push(packet.id);
        let value = match e { Data &p => { p.id += 2; p.values[0] += 10; p.id + p.values[0] } };
        return packet.values[1], value;
    }
    let a, b = change();
    if a != n + 1 || b != 2 * n + 12 || packet.id != n + 1 { abort("bad captured owners"); } return n + 1;
}
fn main() {}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 2)
            for engine, observed in self.engines(path, runtime, repeats=10000):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")

    def test_static_captured_owner_survives_nested_return_and_checks_extent(self):
        source = f'''extern fn bench_input() -> i64;
var neighbor: i64[>..] = [{CANARY}];
fn main() {{
    var values: i64[>..] = [1];
    recursive fn replace() {{ values = [if bench_input() > 0 {{ return; }} else {{ 2 }}; 1000000]; }}
    replace();
}}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 2)
            for engine, observed in self.engines(path, runtime, input_value=1, canary_index=0):
                with self.subTest(level=level, engine=engine):
                    self.assertIn("data region exhausted", observed["error"])
                    self.assertEqual(observed["canary"], str(CANARY))

    def test_fixed_record_rendering_releases_statement_snapshots(self):
        source=f'''var neighbor:i64[>..]=[{CANARY}];
struct Text{{value:i64,bytes:u8[2048]}}
export fn tick(n:i64)->i64{{print(Text{{n,[65;2048]}});return n+1;}}
fn main(){{}}'''
        for level in (0,2):
            path,info=self.compile(source,level)
            self.assertEqual(info['region_count'],1)
            for engine,observed in self.engines(path,info,repeats=10000,canary_index=0):
                with self.subTest(level=level,engine=engine):
                    self.assertEqual(observed['error'],'')
                    self.assertEqual(observed['canary'],str(CANARY))
                    self.assertEqual(len(observed['numbers']),10000)
                    self.assertEqual(observed['numbers'][0],'0')
                    self.assertEqual(observed['numbers'][-1],'9999')

    def test_encoded_record_tail_recursive_results_reuse_region(self):
        source=f'''var neighbor:i64[>..]=[{CANARY}];
struct R{{tag:u8,word:u16,values:varint[varint]}}
recursive fn make(n:i64)->R{{if n==0{{return R{{1,7,[64;128]}};}}return make(n-1);}}
export fn tick(n:i64)->i64{{let a=make(20);var total=0;for x in a.values{{total+=x;}}
if a.word!=7 || a.values.len!=128 || total!=8192{{abort("bad record tail");}}return n+1;}}
fn main(){{}}'''
        for level in (0,2):
            path,info=self.compile(source,level)
            self.assertEqual(info['region_count'],2)
            for engine,observed in self.engines(path,info,repeats=10000,canary_index=0):
                with self.subTest(level=level,engine=engine):
                    self.assertEqual(observed['error'],'')
                    self.assertEqual(observed['canary'],str(CANARY))

    def test_encoded_record_tail_expansion_preserves_neighbor(self):
        def source(count):
            return f'''var neighbor:i64[>..]=[{CANARY}];
struct R{{tag:u8,word:u16,values:varint[varint]}}
recursive fn values()->varint[u32]{{print(77);return[0;{count}];}}
fn main(){{let a=R{{1,7,values()}};print(a.values.len);}}'''
        for level in (0,2):
            _,baseline=self.compile(source(1),level)
            path,info=self.compile(source(baseline['region_bytes']-4),level)
            self.assertEqual(info['region_count'],2)
            for engine,observed in self.engines(path,info,canary_index=0):
                with self.subTest(level=level,engine=engine):
                    self.assertIn('data region exhausted',observed['error'])
                    self.assertEqual(observed['numbers'],['77'])
                    self.assertEqual(observed['canary'],str(CANARY))

    def test_combined_varint_repeated_named_grow_returns_reuse_region(self):
        source=f'''var neighbor:i64[>..]=[{CANARY}];
recursive fn make()->varint[varint]{{var a:varint[>..]=[7;128];return a;}}
export fn tick(n:i64)->i64{{let a=make();var total=0;for x in a{{total+=x;}}if a.len!=128 || total!=896{{abort("bad ULEB result");}}return n+1;}}
fn main(){{}}'''
        for level in (0,2):
            path,info=self.compile(source,level)
            # The emitted ER specialization has a conservative local-Grow
            # bound even though this exact Value call shares its named result.
            self.assertEqual(info['region_count'],3)
            for engine,observed in self.engines(path,info,repeats=10000,canary_index=0):
                with self.subTest(level=level,engine=engine):
                    self.assertEqual(observed['error'],'')
                    self.assertEqual(observed['canary'],str(CANARY))

    def test_combined_varint_expansion_checks_space_before_moving_suffix(self):
        def source(count):
            return f'''var neighbor:i64[>..]=[{CANARY}];
recursive fn make()->varint[u32]{{print(77);return[0;{count}];}}
fn main(){{let a:varint[varint]=make();print(a.len);}}'''
        for level in (0,2):
            _,baseline=self.compile(source(1),level)
            path,info=self.compile(source(baseline['region_bytes']-1),level)
            self.assertEqual(info['region_count'],2)
            self.assertEqual(info['region_bytes'],baseline['region_bytes'])
            for engine,observed in self.engines(path,info,canary_index=0):
                with self.subTest(level=level,engine=engine):
                    self.assertIn('data region exhausted',observed['error'])
                    self.assertEqual(observed['numbers'],['77'])
                    self.assertEqual(observed['canary'],str(CANARY))

    def test_uleb_length_repeated_named_grow_returns_reuse_region(self):
        source=f'''var neighbor:i64[>..]=[{CANARY}];
recursive fn make()->u8[varint]{{var a:u8[>..]=[7;128];return a;}}
export fn tick(n:i64)->i64{{let a=make();if a.len!=128 || a[0]!=7 || a[127]!=7{{abort("bad ULEB result");}}return n+1;}}
fn main(){{}}'''
        for level in (0,2):
            path,info=self.compile(source,level)
            # The emitted ER specialization has a conservative local-Grow
            # bound even though this exact Value call shares its named result.
            self.assertEqual(info['region_count'],3)
            for engine,observed in self.engines(path,info,repeats=10000,canary_index=0):
                with self.subTest(level=level,engine=engine):
                    self.assertEqual(observed['error'],'')
                    self.assertEqual(observed['canary'],str(CANARY))

    def test_uleb_length_expansion_checks_space_before_moving_suffix(self):
        def source(count):
            return f'''var neighbor:i64[>..]=[{CANARY}];
recursive fn make()->u8[u32]{{print(77);return[7;{count}];}}
fn main(){{let a:u8[varint]=make();print(a.len);}}'''
        for level in (0,2):
            _,baseline=self.compile(source(1),level)
            path,info=self.compile(source(baseline['region_bytes']-1),level)
            self.assertEqual(info['region_count'],2)
            self.assertEqual(info['region_bytes'],baseline['region_bytes'])
            for engine,observed in self.engines(path,info,canary_index=0):
                with self.subTest(level=level,engine=engine):
                    self.assertIn('data region exhausted',observed['error'])
                    self.assertEqual(observed['numbers'],['77'])
                    self.assertEqual(observed['canary'],str(CANARY))

    def test_varint_grow_recursive_append_uses_no_extra_data_lease(self):
        source=f'''var neighbor:i64[>..]=[{CANARY}];
recursive fn values(n:i64)->varint[>..]{{if n==0{{return[64,-65];}}return values(n-1);}}
export fn tick(n:i64)->i64{{var a:varint[>..]=[n];a.append(values(20));var total=0;for x in a{{total+=x;}}return total+2;}}
fn main(){{}}'''
        for level in (0,2):
            path,info=self.compile(source,level)
            self.assertEqual(info['region_count'],2)
            for engine,observed in self.engines(path,info,repeats=10000,canary_index=0):
                with self.subTest(level=level,engine=engine):
                    self.assertEqual(observed['error'],'')
                    self.assertEqual(observed['canary'],str(CANARY))

    def test_varint_grow_canceled_append_keeps_physical_suffix(self):
        for via_callback in (False,True):
            operation='apply(){values(){if n>=0{return n+1;}else{-65}}};' if via_callback else 'a.append(values(){if n>=0{return n+1;}else{-65}});'
            source=f'''var neighbor:i64[>..]=[{CANARY}];var a:varint[>..]=[];
recursive fn values<F>()->varint[u8]{{return[1,F(),8192];}}
fn apply<F>(){{a.append(F());}}
fn target(n:i64)->i64{{{operation}return 0;}}
export fn tick(n:i64)->i64{{a.clear();a.push(64);let r=target(n);
let kept:const varint& =a.push(9);var total=0;for x in a{{total+=x;}}
if r!=n+1 || a.len!=2 || total!=65 || kept!=9{{abort("bad canceled append");}}return r;}}
fn main(){{}}'''
            for level in (0,2):
                path,info=self.compile(source,level)
                self.assertEqual(info['region_count'],2)
                for engine,observed in self.engines(path,info,repeats=10000,canary_index=0):
                    with self.subTest(level=level,engine=engine,via_callback=via_callback):
                        self.assertEqual(observed['error'],'')
                        self.assertEqual(observed['canary'],str(CANARY))

    def test_varint_grow_push_checks_full_width_before_store(self):
        def source(count):
            return f'''var neighbor:i64[>..]=[{CANARY}];
fn value()->i64{{print(77);return -9223372036854775808;}}
fn main(){{var a:varint[>..]=[];a.append([9223372036854775807;{count}]);a.push(value());}}'''
        for level in (0,2):
            _,baseline=self.compile(source(1),level)
            path,info=self.compile(source(baseline['region_bytes']//10),level)
            self.assertEqual(info['region_count'],2)
            self.assertEqual(info['region_bytes'],baseline['region_bytes'])
            for engine,observed in self.engines(path,info,canary_index=0):
                with self.subTest(level=level,engine=engine):
                    self.assertIn('data region exhausted',observed['error'])
                    self.assertEqual(observed['numbers'],['77'])
                    self.assertEqual(observed['canary'],str(CANARY))

    def test_varint_arrays_reuse_regions_and_preserve_encoded_references(self):
        source=f'''var neighbor:i64[>..]=[{CANARY}];
recursive fn make(n:i64)->varint[u16]{{return[n-5000,-n,8192];}}
recursive fn first(xs:const varint[:])->const varint&{{for x in xs{{return x;}}abort("empty");}}
export fn tick(n:i64)->i64{{
let rows=make(n);let kept:const varint& =first(rows);
for i in 10{{if make(i).len!=3{{abort("bad varint temporary");}}}}
var total=0;for x in rows{{total+=x;}}
if kept!=n-5000 || total!=3192{{abort("bad encoded reference");}}
return n+1;
}}
fn main(){{}}'''
        for level in (0,2):
            path,info=self.compile(source,level)
            self.assertEqual(info['region_count'],3)
            for engine,observed in self.engines(path,info,repeats=10000,canary_index=0):
                with self.subTest(level=level,engine=engine):
                    self.assertEqual(observed['error'],'')
                    self.assertEqual(observed['canary'],str(CANARY))

    def test_varint_array_overflow_preserves_neighbor_after_once_only_fill(self):
        def source(count,width):
            return f'''var neighbor:i64[>..]=[{CANARY}];
fn value()->i64{{print(77);return -9223372036854775808;}}
fn main(){{let rows:varint[u{width}]=[value();{count}];print(rows.len);}}'''
        for level in (0,2):
            _,baseline=self.compile(source(1,32),level)
            width=32 if (baseline['region_bytes']-4)%10 else 16
            count=(baseline['region_bytes']-width//8)//10+1
            path,info=self.compile(source(count,width),level)
            self.assertEqual(info['region_count'],2)
            self.assertEqual(info['region_bytes'],baseline['region_bytes'])
            for engine,observed in self.engines(path,info,canary_index=0):
                with self.subTest(level=level,engine=engine):
                    self.assertIn('data region exhausted',observed['error'])
                    self.assertEqual(observed['numbers'],['77'])
                    self.assertEqual(observed['canary'],str(CANARY))

    def test_varint_array_fixed_target_cancellation_reuses_regions(self):
        source=f'''var neighbor:i64[>..]=[{CANARY}];
recursive fn make<F>()->varint[u16]{{return[1,F(),-65];}}
fn target(n:i64)->i64{{let rows=make(){{if n>=0{{return n+1;}}else{{8192}}}};return rows.len;}}
export fn tick(n:i64)->i64{{target(n)}}
fn main(){{}}'''
        for level in (0,2):
            path,info=self.compile(source,level)
            self.assertEqual(info['region_count'],2)
            for engine,observed in self.engines(path,info,repeats=10000,canary_index=0):
                with self.subTest(level=level,engine=engine):
                    self.assertEqual(observed['error'],'')
                    self.assertEqual(observed['canary'],str(CANARY))

    def test_varint_record_overflow_reserves_the_complete_encoding(self):
        def source(padding):
            return f'''struct R{{pad {padding},value:varint}}
var neighbor:i64[>..]=[{CANARY}];
fn value()->i64{{print(77);return 9223372036854775807;}}
fn main(){{let r=R{{value()}};print(r.value);}}'''
        for level in (0,2):
            _,baseline=self.compile(source(0),level)
            path,info=self.compile(source(baseline['region_bytes']-6),level)
            self.assertEqual(info['region_count'],2)
            self.assertEqual(info['region_bytes'],baseline['region_bytes'])
            for engine,observed in self.engines(path,info,canary_index=0):
                with self.subTest(level=level,engine=engine):
                    self.assertIn('data region exhausted',observed['error'])
                    self.assertEqual(observed['numbers'],['77'])
                    self.assertEqual(observed['canary'],str(CANARY))

    def test_varint_records_preserve_references_and_regions(self):
        source = f'''struct R {{value:varint,other:varint,end:u8}}
var neighbor:i64[>..]=[{CANARY}];
recursive fn make(n:i64)->R {{return R{{n-5000,-n,7}};}}
export fn tick(n:i64)->i64 {{
    let r=make(n);let kept:const varint& =r.value;
    for i in 10 {{if make(i).other!=-i {{abort("bad varint temporary");}}}}
    if kept!=n-5000 || r.other!=-n || r.end!=7 {{abort("bad varint reference");}}
    return n+1;
}}
fn main() {{}}'''
        for level in (0,2):
            path,info=self.compile(source,level)
            self.assertEqual(info['region_count'],3)
            for engine,observed in self.engines(path,info,repeats=10000,canary_index=0):
                with self.subTest(level=level,engine=engine):
                    self.assertEqual(observed['error'],'')
                    self.assertEqual(observed['canary'],str(CANARY))

    def test_varint_record_padding_reserves_after_the_encoded_field(self):
        source = f'''struct R {{value:varint,pad 70000,after:u8}}
var neighbor:i64[>..]=[{CANARY}];
fn value(n:i64)->i64 {{print(n);return n;}}
fn main() {{let r=R{{value(11),value(22) as u8}};}}'''
        for level in (0,2):
            path,info=self.compile(source,level)
            self.assertEqual(info['region_count'],2)
            for engine,observed in self.engines(path,info,canary_index=0):
                with self.subTest(level=level,engine=engine):
                    self.assertIn('data region exhausted',observed['error'])
                    self.assertEqual(observed['numbers'],['11'])
                    self.assertEqual(observed['canary'],str(CANARY))

    def test_varint_record_callback_exit_does_not_reserve_later_padding(self):
        source = f'''struct R {{value:varint,pad 70000,after:u8}}
var neighbor:i64[>..]=[{CANARY}];
fn make<F>()->R {{return R{{F(),7}};}}
fn target(n:i64)->i64 {{let r=make(){{if n>=0 {{return n+1;}}else{{0}}}};return r.value;}}
export fn tick(n:i64)->i64 {{target(n)}}
fn main() {{}}'''
        for level in (0,2):
            path,info=self.compile(source,level)
            self.assertEqual(info['region_count'],2)
            for engine,observed in self.engines(path,info,repeats=10000,canary_index=0):
                with self.subTest(level=level,engine=engine):
                    self.assertEqual(observed['error'],'')
                    self.assertEqual(observed['canary'],str(CANARY))

    def test_variable_prefix_padding_preserves_references_and_regions(self):
        source = f'''struct R {{tag:u8,pad 3,word:u16,pad,values:u8[u8]}}
var neighbor:i64[>..]=[{CANARY}];
recursive fn make(n:i64)->R {{return R{{7,n as u16,[8]}};}}
export fn tick(n:i64)->i64 {{
    let r=make(n);let kept:const u16& =r.word;
    for i in 10 {{if make(i).word!=i as u16 {{abort("bad padded temporary");}}}}
    if kept!=n as u16 || r.values.len!=1 || r.values[0]!=8 {{abort("bad padded reference");}}
    return n+1;
}}
fn main() {{}}'''
        for level in (0,2):
            path,info=self.compile(source,level)
            self.assertEqual(info['region_count'],3)
            for engine,observed in self.engines(path,info,repeats=10000,canary_index=0):
                with self.subTest(level=level,engine=engine):
                    self.assertEqual(observed['error'],'')
                    self.assertEqual(observed['canary'],str(CANARY))

    def test_variable_padding_reserves_at_its_declaration_position(self):
        source = f'''struct R {{first:i64,pad 70000,second:i64,values:u8[u8]}}
var neighbor:i64[>..]=[{CANARY}];
fn value(n:i64)->i64 {{print(n);return n;}}
fn main() {{let r=R{{value(123),value(456),[]}};}}'''
        for level in (0,2):
            path,info=self.compile(source,level)
            self.assertEqual(info['region_count'],2)
            for engine,observed in self.engines(path,info,canary_index=0):
                with self.subTest(level=level,engine=engine):
                    self.assertIn('data region exhausted',observed['error'])
                    self.assertEqual(observed['numbers'],['123'])
                    self.assertEqual(observed['canary'],str(CANARY))

    def test_enum_image_escapes_reuse_independent_regions(self):
        source = f'''enum E {{ A{{id:u8,values:u16[u8]}}, B{{id:u8,values:u16[..]}}, Empty }}
var neighbor:i64[>..] = [{CANARY}];
recursive fn leave(depth:i64,value:i64) {{
    if depth>0 {{leave(depth-1,value);return;}}
    return E.A{{7,[value as u16]}},E.B{{8,[(value+1) as u16]}},17 from target;
}}
recursive fn target(depth:i64,value:i64)->E..,E..,i64 {{
    if depth>0 {{return target(depth-1,value);}}
    leave(3,value);return E.Empty,E.Empty,0;
}}
export fn tick(n:i64)->i64 {{
    var left,right,k=target(12,n);
    let value=match left {{A &p=>{{if p.id!=7 || p.values.len!=1 {{abort("bad enum left");}} p.values[0] as i64}},_=>-1}};
    if value!=n || k!=17 {{abort("bad enum tuple");}}
    return match right {{B &p=>{{if p.id!=8 || p.values.cap!=1 || p.values.len!=1 {{abort("bad enum right");}} p.values.pop();p.values.push((n+1) as u16);p.values[0] as i64}},_=>-1}};
}}
fn main() {{}}'''
        for level in (0,2):
            path,runtime=self.compile(source,level)
            self.assertEqual(runtime["region_count"],3)
            for engine,observed in self.engines(path,runtime,repeats=10000,canary_index=0):
                with self.subTest(level=level,engine=engine):
                    self.assertEqual(observed["error"],"")
                    self.assertEqual(observed["canary"],str(CANARY))

    def test_enum_image_escape_overflow_preserves_live_neighbor(self):
        source = f'''struct Cell {{tag:u8,value:u16}}
enum E {{Data{{values:Cell[u32]}},Empty}}
fn target()->E.. {{
    var neighbor:i64[>..] = [{CANARY}];
    recursive fn leave() {{return E.Data{{[Cell{{1,2}};40000]}} from target;}}
    leave();print(neighbor[0]);return E.Empty;
}}
fn main() {{let e=target();}}'''
        for level in (0,2):
            path,runtime=self.compile(source,level)
            self.assertEqual(runtime["region_count"],2)
            for engine,observed in self.engines(path,runtime,canary_index=1):
                with self.subTest(level=level,engine=engine):
                    self.assertIn("data region exhausted",observed["error"])
                    self.assertEqual(observed["canary"],str(CANARY))

    def test_enum_image_target_activation_exhaustion_preserves_canary(self):
        source = f'''extern fn bench_input()->i64;
enum E {{A{{values:u8[u8]}},B{{values:u16[..]}},Empty}}
var neighbor:i64[>..] = [{CANARY}];
recursive fn target(depth:i64)->E..,E.. {{
    if depth>0 {{return target(depth-1);}}
    recursive fn leave() {{return E.A{{[7]}},E.B{{[8]}} from target;}}
    leave();return E.Empty,E.Empty;
}}
fn main() {{let left,right=target(bench_input());}}'''
        for level in (0,2):
            path,runtime=self.compile(source,level)
            self.assertEqual(runtime["region_count"],3)
            for engine,observed in self.engines(path,runtime,input_value=1000000,canary_index=0):
                with self.subTest(level=level,engine=engine):
                    self.assertIn("activation",observed["error"])
                    self.assertEqual(observed["canary"],str(CANARY))

    def test_enum_image_replacement_releases_dying_payload_controls(self):
        source = f'''enum E {{Data{{values:u8[u32]}},Other{{marker:u8}},Empty}}
var neighbor:i64[>..] = [{CANARY}];
recursive fn leave(n:i64) {{
    if n%2>0 {{return E.Other{{9}} from target;}}
    return E.Data{{[8]}} from target;
}}
recursive fn target(n:i64)->E.. {{
    var own:E..=E.Data{{[if n>=0 {{leave(n);0}} else {{7}};1000000]}};
    return own;
}}
export fn tick(n:i64)->i64 {{
    let e=target(n);
    let value=match e {{Data &p=>p.values[0] as i64,Other p=>p.marker as i64,Empty=>0}};
    if value!=(if n%2>0 {{9}} else {{8}}) {{abort("bad replaced enum");}}
    return n+1;
}}
fn main() {{}}'''
        for level in (0,2):
            path,runtime=self.compile(source,level)
            self.assertEqual(runtime["region_count"],2)
            for engine,observed in self.engines(path,runtime,repeats=10000,canary_index=0):
                with self.subTest(level=level,engine=engine):
                    self.assertEqual(observed["error"],"")
                    self.assertEqual(observed["canary"],str(CANARY))

    def test_enum_image_escape_checks_surviving_global_extent(self):
        source = f'''extern fn bench_input()->i64;
enum E {{Done}}
var values:i64[>..]=[1];
var neighbor:i64[>..]=[{CANARY}];
fn target()->E.. {{
    recursive fn replace() {{
        values=[if bench_input()>0 {{return E.Done from target;}} else {{7}};1000000];
    }}
    replace();return E.Done;
}}
fn main() {{let e=target();}}'''
        for level in (0,2):
            path,runtime=self.compile(source,level)
            self.assertEqual(runtime["region_count"],3)
            for engine,observed in self.engines(path,runtime,input_value=1,canary_index=1):
                with self.subTest(level=level,engine=engine):
                    self.assertIn("data region exhausted",observed["error"])
                    self.assertEqual(observed["canary"],str(CANARY))

    def test_record_image_escapes_reuse_independent_regions(self):
        source = f'''struct R {{ tag:u8,values:u16[u8] }}
struct L {{ tag:u8,values:u16[..] }}
var neighbor:i64[>..] = [{CANARY}];
recursive fn leave(depth:i64,value:i64) {{
    if depth > 0 {{ leave(depth-1,value); return; }}
    return R{{7,[value as u16]}},L{{8,[(value+1) as u16]}} from target;
}}
recursive fn target(depth:i64,value:i64) -> R,L {{
    if depth > 0 {{ return target(depth-1,value); }}
    leave(3,value); return R{{0,[]}},L{{0,[]}};
}}
export fn tick(n:i64) -> i64 {{
    var left,right=target(12,n);
    if left.tag != 7 || right.tag != 8 || left.values.len != 1 || right.values.cap != 1 || right.values.len != 1 || left.values[0] != n as u16 {{ abort("bad record image escape"); }}
    right.values.pop(); right.values.push((n+1) as u16); return right.values[0] as i64;
}}
fn main() {{}}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 3)
            for engine, observed in self.engines(path, runtime, repeats=10000, canary_index=0):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")
                    self.assertEqual(observed["canary"], str(CANARY))

    def test_record_image_escape_overflow_preserves_live_neighbor(self):
        source = f'''struct Cell {{ tag:u8,value:u16 }}
struct R {{ tag:u8,values:Cell[u32] }}
fn target() -> R {{
    var neighbor:i64[>..] = [{CANARY}];
    recursive fn leave() {{ return R{{7,[Cell{{1,2}};40000]}} from target; }}
    leave(); print(neighbor[0]); return R{{0,[]}};
}}
fn main() {{ let value=target(); print(value.values.len); }}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 2)
            for engine, observed in self.engines(path, runtime, canary_index=1):
                with self.subTest(level=level, engine=engine):
                    self.assertIn("data region exhausted", observed["error"])
                    self.assertEqual(observed["canary"], str(CANARY))

    def test_record_image_target_activation_exhaustion_preserves_canary(self):
        source = f'''extern fn bench_input() -> i64;
struct R {{ tag:u8,values:u8[u8] }}
struct L {{ tag:u8,values:u16[..] }}
var neighbor:i64[>..] = [{CANARY}];
recursive fn target(depth:i64) -> R,L {{
    if depth > 0 {{ return target(depth-1); }}
    recursive fn leave() {{ return R{{1,[7]}},L{{2,[8]}} from target; }}
    leave(); return R{{0,[]}},L{{0,[]}};
}}
fn main() {{ let left,right=target(bench_input()); print(left.values.len,right.values.len); }}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 3)
            for engine, observed in self.engines(path, runtime, input_value=1000000, canary_index=0):
                with self.subTest(level=level, engine=engine):
                    self.assertIn("activation", observed["error"])
                    self.assertEqual(observed["canary"], str(CANARY))

    def test_packed_image_escapes_reuse_independent_regions(self):
        source = f'''struct Cell<T> {{ tag:u8,value:T }}
enum E {{ Packed {{ tag:u8,value:u16 }}, Other {{ values:u8[] }} }}
var neighbor:i64[>..] = [{CANARY}];
recursive fn leave(depth:i64,value:i64) {{
    if depth > 0 {{ leave(depth-1,value); return; }}
    return [Cell<u16>{{7,value as u16}}],[E.Packed{{8,(value+1) as u16}}] from target;
}}
recursive fn target(depth:i64,value:i64) -> Cell<u16>[u8],E.Packed[..] {{
    if depth > 0 {{ return target(depth-1,value); }}
    leave(3,value); return [],[];
}}
export fn tick(n:i64) -> i64 {{
    var left,right=target(12,n);
    if left.len != 1 || right.len != 1 || right.cap != 1 || left[0].value != n as u16 {{ abort("bad packed image escape"); }}
    right.pop(); right.push(E.Packed{{8,(n+1) as u16}}); return right[0].value as i64;
}}
fn main() {{}}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 3)
            for engine, observed in self.engines(path, runtime, repeats=10000, canary_index=0):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")
                    self.assertEqual(observed["canary"], str(CANARY))

    def test_packed_image_escape_overflow_preserves_live_neighbor(self):
        source = f'''struct Cell {{ tag:u8,value:u16 }}
fn target() -> Cell[u32] {{
    var neighbor:i64[>..] = [{CANARY}];
    recursive fn leave() {{ return [Cell{{1,2}};40000] from target; }}
    leave(); print(neighbor[0]); return [];
}}
fn main() {{ let value=target(); print(value.len); }}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 2)
            for engine, observed in self.engines(path, runtime, canary_index=1):
                with self.subTest(level=level, engine=engine):
                    self.assertIn("data region exhausted", observed["error"])
                    self.assertEqual(observed["canary"], str(CANARY))

    def test_scalar_image_escapes_reuse_independent_regions(self):
        source = f'''var neighbor:i64[>..] = [{CANARY}];
recursive fn leave(depth:i64,value:i64) {{
    if depth > 0 {{ leave(depth-1,value); return; }}
    return [value as u16,(value+1) as u16],[value as u16,(value+1) as u16] from target;
}}
recursive fn target(depth:i64,value:i64) -> u16[u8],u16[..] {{
    if depth > 0 {{ return target(depth-1,value); }}
    leave(3,value); return [],[];
}}
export fn tick(n:i64) -> i64 {{
    var left,right=target(12,n);
    if left.len != 2 || right.len != 2 || right.cap != 2 || left[0] != n as u16 {{ abort("bad image escape"); }}
    right.pop(); right.push((n+1) as u16); return right[1] as i64;
}}
fn main() {{}}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 3)
            for engine, observed in self.engines(path, runtime, repeats=10000, canary_index=0):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")
                    self.assertEqual(observed["canary"], str(CANARY))

    def test_scalar_image_escape_overflow_preserves_live_neighbor(self):
        source = f'''fn target() -> u8[u32] {{
    var neighbor:i64[>..] = [{CANARY}];
    recursive fn leave() {{ return [1 as u8;100000] from target; }}
    leave(); print(neighbor[0]); return [];
}}
fn main() {{ let value=target(); print(value.len); }}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 2)
            for engine, observed in self.engines(path, runtime, canary_index=1):
                with self.subTest(level=level, engine=engine):
                    self.assertIn("data region exhausted", observed["error"])
                    self.assertEqual(observed["canary"], str(CANARY))

    def test_scalar_image_target_activation_exhaustion_preserves_canary(self):
        source = f'''extern fn bench_input() -> i64;
var neighbor:i64[>..] = [{CANARY}];
recursive fn target(depth:i64) -> u8[u8],u16[..] {{
    if depth > 0 {{ return target(depth-1); }}
    recursive fn leave() {{ return [7],[8] from target; }}
    leave(); return [],[];
}}
fn main() {{ let left,right=target(bench_input()); print(left.len,right.len); }}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 3)
            for engine, observed in self.engines(path, runtime, input_value=1000000, canary_index=0):
                with self.subTest(level=level, engine=engine):
                    self.assertIn("activation", observed["error"])
                    self.assertEqual(observed["canary"], str(CANARY))

    def test_multiple_owned_returns_reuse_independent_regions(self):
        source = f'''struct Frame {{ id: i64, values: i64[>..] }}
var neighbor: i64[>..] = [{CANARY}];
recursive fn leave(depth: i64, value: i64) {{
    if depth > 0 {{ leave(depth - 1, value); return; }}
    return value + 1, [value + 2], Frame {{ 7, [value + 3] }} from target;
}}
recursive fn target(depth: i64, value: i64) -> i64, i64[>..], Frame {{
    if depth > 0 {{ return target(depth - 1, value); }}
    leave(3, value); return 0, [], Frame {{ 0, [] }};
}}
export fn tick(n: i64) -> i64 {{ let a, left, right = target(12, n); a }}
fn main() {{}}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 3)
            for engine, observed in self.engines(path, runtime, repeats=10000, canary_index=0):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")
                    self.assertEqual(observed["canary"], str(CANARY))

    def test_multiple_owned_reservation_preserves_other_live_region(self):
        source = f'''fn target() -> i64[>..], i64[>..] {{
    var right: i64[>..] = [{CANARY}];
    recursive fn leave() {{ return [1; 15000], copy(right) from target; }}
    leave(); return [], right;
}}
fn main() {{ let left, right = target(); print(left.len, right.len); }}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 3)
            for engine, observed in self.engines(path, runtime, canary_index=2):
                with self.subTest(level=level, engine=engine):
                    self.assertIn("data region exhausted", observed["error"])
                    self.assertEqual(observed["canary"], str(CANARY))

    def test_multiple_owned_recursive_activation_exhaustion_preserves_canary(self):
        source = f'''extern fn bench_input() -> i64;
var neighbor: i64[>..] = [{CANARY}];
recursive fn target(depth: i64) -> i64[>..], i64[>..], i64 {{
    if depth > 0 {{ return target(depth - 1); }}
    recursive fn leave() {{ return [7], [8], 9 from target; }}
    leave(); return [], [], 0;
}}
fn main() {{ let left, right, n = target(bench_input()); print(n); }}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 3)
            for engine, observed in self.engines(path, runtime, input_value=1000000, canary_index=0):
                with self.subTest(level=level, engine=engine):
                    self.assertIn("activation", observed["error"])
                    self.assertEqual(observed["canary"], str(CANARY))

    def test_mixed_nonlocal_return_reuses_receiving_region(self):
        for frame in (False, True):
            declaration = "struct Frame { id: i64, values: i64[>..] }" if frame else ""
            owner = "Frame" if frame else "i64[>..]"
            value = "Frame { 7, [value + 2] }" if frame else "[value + 2]"
            empty = "Frame { 0, [] }" if frame else "[]"
            source = f'''{declaration}
var neighbor: i64[>..] = [{CANARY}];
recursive fn leave(depth: i64, value: i64) {{
    if depth > 0 {{ leave(depth - 1, value); return; }}
    return value + 1, {value}, value + 3 from target;
}}
fn target(value: i64) -> i64, {owner}, i64 {{ leave(3, value); return 0, {empty}, 0; }}
export fn tick(n: i64) -> i64 {{ let a, value, b = target(n); a }}
fn main() {{}}'''
            for level in (0, 2):
                path, runtime = self.compile(source, level)
                self.assertEqual(runtime["region_count"], 2)
                for engine, observed in self.engines(path, runtime, repeats=10000, canary_index=0):
                    with self.subTest(frame=frame, level=level, engine=engine):
                        self.assertEqual(observed["error"], "")
                        self.assertEqual(observed["canary"], str(CANARY))

    def test_mixed_nonlocal_return_replaces_abandoned_extent(self):
        for frame in (False, True):
            declaration = "struct Frame { id: i64, values: i64[>..] }" if frame else ""
            owner = "Frame" if frame else "i64[>..]"
            value = "Frame { 7, [value + 2] }" if frame else "[value + 2]"
            interrupted = "Frame { 9, [fill(value); 4294967296] }" if frame else "[fill(value); 4294967296]"
            source = f'''{declaration}
var neighbor: i64[>..] = [{CANARY}];
fn fill(value: i64) -> i64 {{ return value + 1, {value}, value + 3 from target; }}
fn target(value: i64) -> i64, {owner}, i64 {{ return 1, {interrupted}, 2; }}
export fn tick(n: i64) -> i64 {{ let a, value, b = target(n); a }}
fn main() {{}}'''
            for level in (0, 2):
                path, runtime = self.compile(source, level)
                self.assertEqual(runtime["region_count"], 2)
                for engine, observed in self.engines(path, runtime, repeats=10000, canary_index=0):
                    with self.subTest(frame=frame, level=level, engine=engine):
                        self.assertEqual(observed["error"], "")
                        self.assertEqual(observed["canary"], str(CANARY))

    def test_frame_nonlocal_return_reuses_receiving_region(self):
        source = f'''struct Inner {{ id: i64, values: i64[>..] }}
struct Frame {{ tag: u8, child: Inner }}
var neighbor: i64[>..] = [{CANARY}];
recursive fn leave(depth: i64, value: i64) {{
    if depth > 0 {{ leave(depth - 1, value); return; }}
    return Frame {{ 7, Inner {{ value + 1, [value + 2] }} }} from target;
}}
fn target(value: i64) -> Frame {{ leave(3, value); return Frame {{ 0, Inner {{ 0, [] }} }}; }}
export fn tick(n: i64) -> i64 {{ var result = target(n); result.child.id }}
fn main() {{}}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 2)
            for engine, observed in self.engines(path, runtime, repeats=10000, canary_index=0):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")
                    self.assertEqual(observed["canary"], str(CANARY))

    def test_frame_nonlocal_return_replaces_abandoned_oversized_tail(self):
        source = f'''struct Frame {{ id: i64, values: i64[>..] }}
var neighbor: i64[>..] = [{CANARY}];
fn fill(value: i64) -> i64 {{ return Frame {{ value + 1, [value + 2] }} from target; }}
fn target(value: i64) -> Frame {{ return Frame {{ 9, [fill(value); 4294967296] }}; }}
export fn tick(n: i64) -> i64 {{ var result = target(n); result.id }}
fn main() {{}}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 2)
            for engine, observed in self.engines(path, runtime, repeats=10000, canary_index=0):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")
                    self.assertEqual(observed["canary"], str(CANARY))

    def test_owned_nonlocal_return_reuses_receiving_region(self):
        source = f'''var neighbor: i64[>..] = [{CANARY}];
recursive fn leave(depth: i64, value: i64) {{
    if depth > 0 {{ leave(depth - 1, value); return; }}
    return [value + 1] from target;
}}
fn target(value: i64) -> i64[>..] {{ leave(3, value); return []; }}
export fn tick(n: i64) -> i64 {{ var result = target(n); result[0] }}
fn main() {{}}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["schema"], 2)
            self.assertEqual(runtime["region_count"], 2)
            self.assertEqual(runtime["cursor_stride"], 4)
            for engine, observed in self.engines(path, runtime, repeats=10000, canary_index=0):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")
                    self.assertEqual(observed["canary"], str(CANARY))

    def test_owned_nonlocal_return_replaces_abandoned_oversized_result(self):
        source = f'''var neighbor: i64[>..] = [{CANARY}];
fn fill(value: i64) -> i64 {{ return [value + 1] from target; }}
fn target(value: i64) -> i64[>..] {{ return [fill(value); 4294967296]; }}
export fn tick(n: i64) -> i64 {{ var result = target(n); result[0] }}
fn main() {{}}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 2)
            for engine, observed in self.engines(path, runtime, repeats=10000, canary_index=0):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")
                    self.assertEqual(observed["canary"], str(CANARY))

    def test_owned_cursor_module_checks_published_surviving_extent(self):
        source = f'''extern fn bench_input() -> i64;
var values: i64[>..] = [9]; var neighbor: i64[>..] = [{CANARY}];
recursive fn enable_leave() {{ return [1] from enable; }}
fn enable() -> i64[>..] {{ enable_leave(); return []; }}
fn make<F>() -> i64[] {{ return [F(); 1000000]; }}
fn target() -> i64 {{ values = make() {{ if bench_input() >= 0 {{ return 7; }} 4 }}; return 0; }}
fn main() {{ print(enable().len); print(target()); }}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            for engine, observed in self.engines(path, runtime, canary_index=1):
                with self.subTest(level=level, engine=engine):
                    self.assertIn("data region exhausted", observed["error"])
                    self.assertEqual(observed["canary"], str(CANARY))

    def test_nonlocal_return_releases_dying_borrowed_owner(self):
        source = f'''var neighbor: i64[>..] = [{CANARY}];
fn mutate<F>(xs: i64[>..]&) {{ xs = [F(); 4294967296]; }}
fn target(n: i64) -> i64 {{
    var xs: i64[>..] = [9]; mutate(xs) {{ if n >= 0 {{ return n + 1; }} 4 }}; return 0;
}}
export fn tick(n: i64) -> i64 {{ target(n) }}
fn main() {{}}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 2)
            for engine, observed in self.engines(path, runtime, repeats=10000, canary_index=0):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")
                    self.assertEqual(observed["canary"], str(CANARY))

    def test_nonlocal_return_still_checks_surviving_global_owner(self):
        source = f'''extern fn bench_input() -> i64;
var values: i64[>..] = [9]; var neighbor: i64[>..] = [{CANARY}];
fn mutate<F>(xs: i64[>..]&) {{ xs = [F(); 4294967296]; }}
fn target() -> i64 {{ mutate(values) {{ if bench_input() >= 0 {{ return 7; }} 4 }}; return 0; }}
fn main() {{ print(target()); }}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 2)
            for engine, observed in self.engines(path, runtime, canary_index=1):
                with self.subTest(level=level, engine=engine):
                    self.assertIn("data region exhausted", observed["error"])
                    self.assertEqual(observed["canary"], str(CANARY))

    def test_nonlocal_return_recognizes_dying_embedded_enum_header(self):
        source = f'''enum Event {{ Empty, Data {{ tag: i64, values: i64[] }} }}
var neighbor: i64[>..] = [{CANARY}];
fn variant<F>() -> Event.Data {{ return Event.Data {{ 1, [F(); 1000000] }}; }}
fn target(n: i64) -> i64 {{
    let event: Event.. = variant() {{ if n >= 0 {{ return n + 1; }} 4 }}; return 0;
}}
export fn tick(n: i64) -> i64 {{ target(n) }}
fn main() {{}}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 2)
            for engine, observed in self.engines(path, runtime, repeats=10000, canary_index=0):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")
                    self.assertEqual(observed["canary"], str(CANARY))

    def test_nonlocal_return_after_retained_inline_arguments(self):
        source = '''recursive fn make(n: i64) -> i64[>..] { return [n, n + 1]; }
inline fn hold(owned: i64[>..], xs: const i64[:]) -> const i64[:] { if xs.len > 0 { return xs; } xs }
fn use(xs: const i64[:], n: i64) -> i64 { xs.len + n }
fn leave(n: i64) -> i64 { if n > 0 { return n from target; } 0 }
fn target(n: i64) -> i64 { use(hold([9], make(n)), leave(n)) }
export fn tick(n: i64) -> i64 { target(n + 1) }
fn main() { print(target(0)); }'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 2)
            for engine, observed in self.engines(path, runtime, repeats=10000):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")
                    self.assertEqual(observed["numbers"], ["2"])

    def test_dispatch_invalid_tag_aborts_before_a_case_call(self):
        source = f'''enum Choice {{ Empty, Data {{ value: i64 }} }}
var choice: Choice = Choice.Data {{ 1234605616436508552 }};
var neighbor: i64[>..] = [{CANARY}];
fn value(c: Choice.Empty) -> i64 {{ 0 }}
fn value(c: Choice.Data) -> i64 {{ c.value }}
export fn tick(n: i64) -> i64 {{ value(choice) + n }}
fn main() {{}}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            for engine, observed in self.engines(path, runtime, repeats=1, canary_index=0, corrupt_tag=True):
                with self.subTest(level=level, engine=engine):
                    self.assertIn("invalid enum tag in dispatch", observed["error"])
                    self.assertEqual(observed["canary"], str(CANARY))

    def test_dispatch_owned_results_cleanup_without_payload_regions(self):
        source = '''enum Choice { One, Two }
fn build(c: Choice.One, n: i64) -> i64[>..] { return [n, n + 1]; }
fn build(c: Choice.Two, n: i64) -> i64[>..] { return [n, n + 2]; }
export fn tick(n: i64) -> i64 {
    let choice: Choice = if n % 2 == 0 { Choice.One } else { Choice.Two };
    let kept = build(choice, n);
    for i in 100 {
        let other = build(choice, n + i);
        if other.len != 2 || other[0] != n + i { abort("wrong dispatch result"); }
    }
    if kept[0] != n || kept.len != 2 { abort("dispatch result released"); }
    return n + 1;
}
fn main() {}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 2)
            for engine, observed in self.engines(path, runtime, repeats=10000):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")

    def test_dispatch_variable_payload_snapshot_is_independent_and_released(self):
        source = '''enum Event { Empty, Data { tag: i64, values: i64[] } }
fn changed(e: Event.Empty, n: i64) -> i64[>..] { return [n]; }
fn changed(e: Event.Data, n: i64) -> i64[>..] { e.values[0] += n; return copy(e.values); }
export fn tick(n: i64) -> i64 {
    let event: Event.. = Event.Data { n, [n, n + 1] };
    let kept = changed(event, 10);
    for i in 100 {
        let other = changed(event, i);
        if other[0] != n + i { abort("wrong copied dispatch payload"); }
    }
    match event { Data &e => { if e.values[0] != n { abort("dispatch mutated source"); } }, Empty => {} };
    if kept[0] != n + 10 || kept[1] != n + 1 { abort("dispatch snapshot escaped"); }
    return n + 1;
}
fn main() {}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 4)
            for engine, observed in self.engines(path, runtime, repeats=10000):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")

    def test_owned_function_value_parameter_and_result_cleanup(self):
        source = '''fn apply<F>(n: i64) -> i64[>..] { F([n, n + 1]) }
export fn tick(n: i64) -> i64 {
    let kept = apply(n) { xs: i64[>..] => xs.push(9); copy(xs) };
    for i in 100 {
        let value = apply(n + i) { xs: i64[>..] => xs[0] += 10; copy(xs) };
        if value.len != 2 || value[0] != n + i + 10 { abort("wrong owned callback result"); }
    }
    if kept.len != 3 || kept[0] != n || kept[2] != 9 { abort("callback result was released"); }
    return n + 1;
}
fn main() {}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 3)
            for engine, observed in self.engines(path, runtime, repeats=10000):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")

    def test_owned_function_value_body_local_result_is_copied(self):
        source = '''fn build<F>(n: i64) -> i64[>..] { F(n) }
export fn tick(n: i64) -> i64 {
    let kept = build(n) { x => var local: i64[>..] = [x, x + 1]; copy(local) };
    for i in 100 {
        let other = build(n + i) { x => var local: i64[>..] = [x + 2]; copy(local) };
        if other[0] != n + i + 2 { abort("wrong callback local copy"); }
    }
    if kept[0] != n || kept[1] != n + 1 { abort("callback local escaped"); }
    return n + 1;
}
fn main() {}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 3)
            for engine, observed in self.engines(path, runtime, repeats=10000):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")

    def test_fixed_function_value_results_construct_owned_receivers_once(self):
        source = '''fn grown<F>() -> i64[>..] { return F(); }
export fn tick(n: i64) -> i64 {
    let named = grown() { [n, n + 1] };
    var calls = 0;
    for i in 100 {
        let value = grown() { calls++; [n + i] }[0];
        if value != n + i { abort("wrong fixed callback result"); }
    }
    if calls != 100 || named[0] != n || named[1] != n + 1 { abort("bad callback lifetime"); } return n + 1;
}
fn main() {}'''
        for level in (0, 2):
            path, runtime = self.compile(source, level)
            self.assertEqual(runtime["region_count"], 2)
            for engine, observed in self.engines(path, runtime, repeats=10000):
                with self.subTest(level=level, engine=engine):
                    self.assertEqual(observed["error"], "")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--goose", type=Path, default=GOOSE)
    parser.add_argument("--node", default=NODE)
    args, remaining = parser.parse_known_args()
    GOOSE, NODE = args.goose.resolve(), args.node
    unittest.main(argv=[sys.argv[0], *remaining])
