# Wasmtime host comparison

A native C++ host links the exact Wasmtime 50.0.1 library used by the Python host. On the ten constant-input examples it reduces fresh-process time; direct Wasm still trails native C. The host also changes callbacks and I/O, so the difference is not Python startup alone. Direct Wasm uses memory32; C-to-Wasm uses memory64.

![Direct Wasm process times](charts/wasmtime-host-runtime.svg)

![C-to-Wasm process times](charts/wasmtime-host-c-wasm.svg)

![Precompiled artifact preparation](charts/wasmtime-host-preparation.svg)

The 2026-11-02 run used a shared AMD Ryzen 7 3800X Linux machine, Goose revision `2e2bedef5b980bf013cac5aaa0095bfea64e5569`, compiler SHA-256 `3316710bb9d2b3100e94c2023000f0cb1b7517010ef04076314b4703fdcfcbba`, GCC 16.2.1, Emscripten 6.0.13, and Wasmtime 50.0.1. The direct Wasm, C-Wasm and native C artifact bytes were reused from the qualified prior example cohort; native C was freshly executed in the same runtime blocks. Each runtime cell has one fresh-process warmup and 15 measured launches, with checked output bytes. There are 1,440 observations across 90 cells. Preparation is measured separately with five fresh preparations for each example, backend and parallel/serial setting: 200 total. Forty unique artifact/configuration pairs were qualified.

Selected direct-process medians in milliseconds:

| Example | Python host | Native host | Precompiled run | Native C |
| --- | ---: | ---: | ---: | ---: |
| Squares | 84.204 | 5.108 | 2.233 | 0.773 |
| Sorting | 235.587 | 159.334 | 118.099 | 46.074 |
| Sudoku | 103.667 | 18.954 | 8.952 | 4.393 |
| Maze | 111.031 | 30.126 | 2.851 | 0.836 |
| Life | 133.619 | 53.319 | 26.931 | 18.572 |

For Life, precompiled C-to-Wasm runs in 6.754 ms versus 18.572 ms for native C. Its separate parallel preparation median is 17.666 ms; adding the medians estimates 24.420 ms for preparation plus one run.

Precompiled run times exclude preparation. Default parallel preparation medians for those examples are respectively 5.110, 56.448, 8.003, 31.374 and 24.497 ms, including launch, compilation, serialization and writing. Adding separately measured medians estimates one preparation plus one run at 7.343 ms for Squares and 174.547 ms for Sorting, versus 5.108 and 159.334 ms for ordinary native-host launches. Dividing preparation by per-run savings estimates break-even at 1.78 and 1.37 runs respectively; these sums and ratios are estimates, not separately measured end-to-end samples. Serial compilation was mostly slower and remains a control, not the default.

The retained replay passed 11,340 executions: 3,780 case/backend/level combinations across normal default, normal serial and precompiled serial modes. Native and Python references were collected separately. Default precompiled loading also passed ten public WAT unit methods across four modes and twenty example artifacts; it did not receive the full replay. The unit tests cover floating point, random, NUL and UTF-8 bytes, memory64 and bounds. Numeric benchmark input tokens are ASCII; this does not establish arbitrary Python stdin Unicode parity.

## Reproduce

Install the [toolchain and optional native host](../docs/GUIDE.md#optional-native-wasmtime-host), including the oracle SDK, then run:

```sh
python bench/examples.py --output-dir build/example-benchmarks
python bench/wasmtime_host.py --example-report build/example-benchmarks/report.json
python bench/wasmtime_host_charts.py build/wasmtime-host/bench/report.json --output-dir bench/charts
```

Chart rendering requires Matplotlib. The host benchmark's default output path can be changed with `--output-dir`; use its generated report path for chart rendering. See the [dated evidence](results/2026-11-02/wasmtime-host/README.md) for retained raw data and qualification.
