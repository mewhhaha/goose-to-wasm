# Direct target contract

## Engines and features

The qualified engines are V8 13.6.233.17-node.58 through Node 24.22.1, and Wasmtime
through Python package 50.0.1. An optional native C API host links the same
Wasmtime library; both hosts implement the known direct and standalone C ABI.
`scripts/check_engines.py` assembles and executes
feature probes in both engines. It checks numeric operations, sign extension,
multi-value, bulk memory, SIMD, tail calls, memory64, multi-memory, and standard
exception handling (`try_table`). Engine support does not imply that every Goose
construct has a corresponding lowering in this backend.

The direct emitter currently uses numeric wasm32, sign extension, multi-value,
and bulk-memory operations. The C oracle's standalone profile uses memory64.
The compiler has no need to preserve compatibility with older browser engines.

## Representations and host ABI

The direct target uses i32/i64/f32/f64 numeric values. References are i32 linear
memory addresses; slices are an i64 containing a pointer in the low 32 bits and an
element count in the high 32 bits. Fixed structs and variants place fields next
to each other with alignment one; arrays use their element's allocation stride.
Other representations remain target-specific. This is a semantic target, not binary-layout
compatibility with Goose's packed 64-bit C ABI. Relative/pool
references and binary serialization are refused until their target semantics
are implemented and qualified.

Internal layout version 3 records packed fixed struct and variant fields,
without implicit inter-field/trailing alignment. Layout 9 adds fixed alignment
and explicit variable-prefix [padding](RECORD_PADDING.md). Each field keeps its own representation;
owner controls remain separately aligned. See
[the layout migration](IMAGE_LAYOUT.md) for its qualified byte-overlap subset.

Address-taken locals and fixed aggregates live in checked activation frames in
linear memory. Each recursive call receives its own frame. Temporary storage
and frames grow memory when necessary, within the module's declared maximum,
and are restored when their scope/function exits. Initial memory defaults to
16 pages (1 MiB), maximum memory to 256 pages (16 MiB). Driver options
`--initial-pages` and `--maximum-pages` configure them; one page is 64 KiB. These
limits are independent of the C oracle's 16 MiB per data stack profile.

The backend keeps physical locations distinct from converted expression values.
All ordinary aggregate copies require the checked fixed size class; a dynamic
owner's control descriptor cannot be copied as an owned fixed value. Fresh
construction destinations retain the current activation-frame policy, and
assignment evaluates its complete RHS before publishing into its pinned target.
Exit targets record cleanup depth so scratch restorations preserve enclosing
operations that remain live. Stable regions use these same boundaries;
single growable results carry an explicit caller destination, while general
dynamic result destinations remain subsequent work.

Region-backed arrays use internal control ABI version 3: a separately aligned
24-byte control in frame/static storage. Its u32 words are base, raw length,
resource limit, raw capacity, image base and physical mode. Raw element runs use
the first four words. Variable-array values store their unsigned length prefix
in the data region; runtime-limited values store u32 capacity and length followed
by capacity slots. Views decode image metadata and derive element addresses from
the actual mode. Natural function types alone cannot identify an element-run
receiver's physical form. Owner references point to the control; element
references point directly into stable data regions. See [array images](ARRAY_IMAGES.md).
The header is never copied through the fixed-value ownership path. Initializers
construct into an acquired region, including implicit empty globals, literals,
fills, copies, slices and natural fixed-array function results.

Fixed-element variable arrays `T[]`, `T[u8/u16/u32/u64]` use the same region control
header and owned construction channels. Their size class remains variable;
their descriptor never enters the fixed-copy path. The frontend freezes their
length at construction while permitting element writes. Narrow value lengths
are checked before publication; default length storage normalizes to u32. Varint lengths,
variable elements remain refused. Supported containing structs are described below. Named-result binding
also shares a growable local's data with its variable-array result, matching
the pinned native emitter's element-run construction.

Eligible single variable-array functions have normal and element-run emission
forms. The run form omits the producer's prefix-width check and named-result
binding. Growable receivers/append, different-width variable receivers and
forwarded run requests select it; receiving value widths still check afterward.
Local and by-value parameter construction retains its own width check. Mixed
results keep natural checks and adapt receiving ordinals after all results return.
Inline bodies follow their receiving request, which can change narrow-width
behavior compared with ordinary calls, as in the pinned C oracle. Differential
cases record those O0/O2 outcomes separately.

Both forms are emitted for eligible reachable specializations. Region peaks
take their maximum and call edges are accumulated across forms. This is a
conservative bound: an unused form can increase the region count and reduce
per-region capacity compared with demand-driven emission.

Each growable result of an internal function receives an additional i32
destination-header parameter and returns that same header address. Its caller
acquires each region; the callee constructs into it before scoped cleanup.
Forwarded returns reuse the destination, including through recursive cycles.
The header/data ownership is never transferred by a shallow descriptor copy.
Mixed/multiple results preserve the existing fixed result parameter order.
Named-result locals selected by the pinned final-body analysis share their
destination's base and limit while retaining a private length header. Each
return position publishes its length at evaluation time; a later result can
mutate shared elements without changing a previously published result length.
Forwarded calls capture their natural result representations before adapting
them in order. Fixed-array/slice values and references to them can construct
owned receiving arrays without copying an owner descriptor.

Runtime-capacity limited named results instead alias their whole receiving
header, matching the native image semantics: later result expressions can change
an earlier result's live length as well as its elements. Cross-kind result
conversions involving runtime-limited arrays construct into a natural temporary
then copy into the receiving kind after capturing every returned value. Missing
owned channels for fixed receiving ordinals use natural temporaries and the
ordinary fixed-value conversion.

`T[..]` keeps its declared capacity independently of the physical region limit.
Same-type copies preserve spare capacity; construction from other array kinds
or slices chooses capacity equal to initial length. A `[..capacity]` literal
evaluates its expression once, checks the u32 range and reserves its extent with
length zero. Its effects and range check survive inline/branch optimization and
conversion to another array kind. Mutation checks both logical capacity and the
physical region limit. Assignment constructs the complete RHS into temporary
storage, copies live elements into the pinned receiver, and preserves its
capacity. Reads of the existing owner are allowed during that RHS; an early exit
before publication leaves its previous value intact apart from explicit RHS effects.

An internal by-value growable parameter receives the address of a private
header constructed by its caller. Each owned argument acquires a distinct region
before the next argument is evaluated. The caller retains these regions through
the call and then restores its argument watermark; interrupted construction
unwinds it as well. Fixed results and caller-owned dynamic result destinations
survive this cleanup. The frontend rejects escaping views into the parameter's
storage; ordinary reference/slice fields pointing to caller data preserve aliases.

Receiving regions also pass through conditionals, ordinary/early blocks,
value-producing loops and supported matches. Each exit target carries its own
channels. Break values construct before exited scopes release their regions;
loop iterations release body-local owners while retaining the receiving region.
Match scrutinees are evaluated once and divergent arms use their enclosing exit.

Whole-owner assignment reconstructs in the pinned header's existing region;
the frontend rejects RHS reads of the owner under reconstruction. Literals publish
their length before evaluating elements/fill values. Calls and control expressions
publish when their selected producer does. An exit from partial construction
checks/commits the advertised extent of headers that survive that exit. Logical
header lifetimes distinguish them from dying locals, owned parameters and private
named-result headers, even when the underlying region survives. Oversized
published counts saturate instead of wrapping before the resource check.

Named declaration receivers acquire their regions before the initializer's
temporary watermark. Explicit scopes cover statements, tails, match arms,
logical right operands, while conditions and generated default-array iterations.
Scopes restore both runtime watermarks and compile-time live-region counts.
While exits exist during condition evaluation, so condition break/continue
unwind to the current while loop.

Single owned growable expressions allocate temporary headers and regions at their
actual evaluation point. Their scope retains them through immediate views,
indexing, rendering and borrowed argument use. An owned control expression's
receiving temporary is allocated before its body. Inline argument declarations
execute outside body cleanup; borrowed argument temporaries survive that cleanup.
An argument group that materializes such an owner retains its regions until the
enclosing temporary scope ends. Fully owned argument copies keep short call
cleanup when no anonymous owner was created. No materialized value is cached by
AST identity.

Discarded mixed/multiple-result calls materialize a separate region for every
owned result. Ordinary calls evaluate value arguments before acquiring anonymous
result regions, so recursion in those arguments retains no result region.

The planner reserves dedicated global regions plus a call-graph/SCC bound on
simultaneously live transient owners. Scoped cleanup restores transient region
watermarks on normal exit, return, break and continue. Borrowed calls grow the
caller's region; growth does not relocate existing elements or slices.

Supported standalone variable structs have fixed-layout prefix fields and one
final fixed-element variable or runtime-capacity array. Their control layout
retains aligned reference/control storage and an embedded 24-byte tail control.
A separate packed image layout places prefix fields, array metadata and elements
in the owner's one data region. Typed field addresses derive from its immutable
logical tail anchor; prefix references point into region bytes. Construction
appends captured fixed fields in declaration order and uses private physical
producers for final owned fields. Copies transfer the full logical image,
including runtime capacity; normal landing moves the full physical suffix. Whole-object named-result aliasing makes prefix, length and element
mutations by later result expressions visible in an earlier result. Ordinary
and inline calls, by-value parameters and control results use owned destinations.
These objects retain `SC_VARIABLE` and never enter the fixed-copy path.
Standalone variable-size variant payloads use the same record walker, validated
independently of their siblings. Matching requires the same enum instance,
variant and enclosing enum mode. Their named returns alias the whole record;
resizable standalone variants remain outside this slice.
Final owner fields may nest recursively through fixed prefixes to the one
terminal array. Growable-tail frame structs use private prefix/length snapshots
and shared elements for named results, and support pinned whole reconstruction.
Interrupted initializers preserve fields whose positions have not been reached.

Regions partition the memory budget remaining after final static allocation.
For maximum bytes `M`, aligned static end `S` and region count `R > 0`, each data
region receives `B = align_down((M-S)/(R+1), 8)` bytes. Activation frames and
scratch occupy `[S, M-R*B)`, followed by the `R` stable regions. This is a
documented per-owner resource limit, independent of language array capacity.
Increasing `--maximum-pages` increases these budgets. Fixed-only modules retain
the previous unpartitioned activation budget.

Acquisition, growth, frames and scratch check their limits before writes;
successful `memory.grow` does not permit crossing a partition boundary. Released
regions are reused, while linear-memory pages remain allocated. The
`goose.regions` custom section publishes region/global counts, region bytes and
activation addresses. Modules with owned return cursors use schema 2 and add
`cursor_base` and `cursor_stride: 4` for the physical cursor table; other modules
retain schema 1. Compiler statistics publish `region_count`, `region_bytes`
and `activation_bytes`.

The module defines fresh, zero-initialized memory. Static allocations retain
their full logical size, but data segments contain only initialized nonzero
spans, coalescing zero gaps of at most 16 bytes. At most 1,024 segments are
emitted; further spans are merged into the final segment. Omitted zeros still
count toward static addresses, stack placement, initial pages, and maximum
memory checks. This reduces file size without reducing runtime memory use.

Modules export `memory` and `_start`. The host calls `_start` once to initialize
globals and run Goose's main function. Public scalar function exports may also
be used after initialization. Imports under module `goose` are:

| Function | Wasm signature | Meaning |
| --- | --- | --- |
| `write` | `(i32,i32) -> ()` | Write bytes from exported memory |
| `print_i64`, `print_u64` | `(i64) -> ()` | Decimal integer output |
| `print_f64` | `(f64) -> ()` | Goose-compatible float output |
| `print_f32` | `(f32) -> ()` | Goose-compatible float output |
| `print_bool` | `(i32) -> ()` | Boolean output |
| `newline` | `() -> ()` | End a print operation |
| `abort` | `(i32,i32,i32) -> ()` | Message pointer/length and source line; must terminate execution |
| `exit` | `(i32) -> ()` | Terminate with the requested exit status |

Scalar `extern fn` declarations ordinarily become imports under `env`, with their
C symbol names. Exact standard numeric signatures for `sqrt`/`gs_sqrt`, `floor`,
`ceil`, `trunc`, `fabs` (and their f32 forms), and `gs_clz(u64) -> i64` lower to
Wasm instructions instead. These operations do not call the host from numerical
loops. Ordinary Goose function bodies are not recognized by name; for example,
Goose's `abs` retains its existing negative-zero semantics.

Raw-only array-image specialization excludes modules with explicit public
exports or nonintrinsic user imports, preserving host edits to image headers.
Pure math intrinsics do not prevent it.

Hosts must provide matching signatures and semantics for remaining imports. The supplied hosts
include input, timing, and barrier functions used by the tests and benchmarks.
Arbitrary external native libraries are not loaded into a Wasm module.

Internal functions can return fixed arrays, structs, enums and variant payloads, including recursion and
mixed scalar/aggregate multiple results. The caller reserves each owned result's
storage and passes a hidden i32 destination parameter. The callee captures result
expressions in order and copies owned results before releasing its frame. The
ordinary i32 result is the caller-owned address. Aggregate extern/public exports
remain refused until an explicit host ABI is provided.

Static-capacity limited arrays `T[..k]` are packed fixed owned values with the
smallest unsigned live-length field followed by inline capacity slots. Their
alignment is one, without inter-field or trailing padding.
Capacity is part of the type. Their views contain the element address and live
length; copying/assignment/parameters/results retain the existing fixed-value
ownership rules. Mutations evaluate the receiver once before their arguments,
then read its current length. Capacity/count/fill checks precede writes, and
`append` supports overlapping views. `push` returns a stable element reference.
Positive-capacity limited arrays can nest in supported fixed values. Standalone
capacity-zero values allocate one unused C element slot; zero-capacity fields and
elements remain frontend-invalid. Allocation storage is distinct from their
encoded image extent. See [compact static arrays](STATIC_LIMITED_IMAGES.md).

Sequence loops retain their location recipe: index expressions and calls on
the path run once, while reference/slice links and live lengths are reread as
iteration proceeds. Replacing a limited-array or slice slot can shorten the
remaining iteration. Bounds expressions on an index/slice capture their view
before side effects, following the pinned emitter's ordering. Indexing an outer
slice pins its element base as the native emitter does; the indexed row's live
length still changes when that slot is replaced.

Enum tags use one byte for up to 256 variants and two bytes above that.
Fixed-mode enums concatenate that tag with the largest packed payload, without
trailing padding. Empty alternatives take no payload bytes behind the tag;
standalone empty variants retain a one-byte value placeholder. Variant-to-enum
conversion initializes fresh tagged storage and copies only encoded payload
bytes. Field representations such as wasm32 references and static-limited
headers still retain their own target-specific layouts.

Fixed enums and variants have the same owned parameter/result and snapshot
rules as other aggregates. Matches evaluate the scrutinee once and copy a
selected payload into its by-value binding before executing the arm. References
to fixed enums may be matched, but references into replaceable fixed-enum
payloads are prohibited by the frontend. A fixed standalone variant can be used
even when another variant of its enum requires unsupported dynamic storage.

Nonresizable variable-mode enums with supported fixed or single-tail payloads own
one stable region containing the compact tag and active payload only. Separately
aligned owner controls hold the common 24-byte header and a persistent control
slot for each nonfixed variant. No inactive payload data is reserved. Copies move
active image bytes; fixed receiving values use fixed snapshots. Borrowed payload
views retain their own typed offsets through named replacement. Normal/tuple
result staging, final-annotation-aware variant adapters and compact cleanup
guards follow the [enum image contract](VARIABLE_ENUMS.md). Resource bounds cover
active extents and the separate control envelope. Only proved integer payload
images admit nonempty replacement observations through saved old typed views;
other representation-sensitive shapes retain their gate.
See [the enum contract](VARIABLE_ENUMS.md).

## Initial supported fragment

- Signed/unsigned integer widths, narrow wrapping, masked shifts, arithmetic,
  comparisons, booleans, f32/f64 operations, and checked conversions.
  Floating `%` and `%=` follow `fmod`/`fmodf`: the result retains the dividend's
  sign, including signed zero. Invalid operands yield NaN. Binary scaling and
  exact subtraction run inside Wasm, without a host math import or a potentially
  overflowing quotient. Their loops are bounded by the IEEE exponent range.
- Functions, recursion, scalar/fixed-aggregate multi-return, globals, and declared scalar
  externs; specialization and ordinary upstream optimizations remain in use.
- If/while/count/range/array loops, break/continue, integer matches, value blocks,
  and supported optimized inline returns.
- Fixed arrays, fixed struct fields, slices, and supported plain/nullable
  references, with checked indexed access and activation-local storage.
- Static-capacity limited arrays, including len/cap/index_of, push/append,
  pop/pop_n/resize/clear, slices, nested storage and owned results.
- Named fixed-element growable owners, stable views/references, initialization,
  borrowed calls, mutation, primitive rendering and scoped region reuse.
- Fixed-mode enums and fixed variant payloads, including generic/nested types,
  constructors/defaults, arrays, owned returns, and exhaustive/list/wildcard
  matches with by-value payload bindings.
- Nonresizable variable-mode enums with fixed or single-tail payloads, independent copies, internal owned
  parameters/results, mode conversion and by-value/by-reference payload matches.
- Scalar/string, closed fixed-record/variant/enum and nested fixed/limited-array
  rendering, including escaped nested byte sequences and argument snapshots;
  see [fixed aggregate rendering](FIXED_AGGREGATE_RENDERING.md).
- Struct images with direct varint fields and otherwise fixed-size fields,
  sequential field offsets, bounded decoding, copies, references and normal results;
  see [varint records](VARINT_RECORDS.md).
- Standalone immutable varint-element arrays with fixed unsigned or ULEB length metadata,
  whole slices, sequential loops, encoded copies and snapshots; see
  [varint arrays](VARINT_ARRAYS.md).
- Standalone growable varint elements with push/append/clear, whole assignment,
  stable references and private-count append forwarding; see [varint Grow](VARINT_GROW.md).
- Standalone fixed-element arrays with unsigned varint lengths, byte-authoritative
  views and successful-return prefix expansion; see [ULEB lengths](ULEB_LENGTHS.md).

- Fixed-prefix non-frame records and standalone variants with terminal encoded
  arrays, including nested single-tail records; see
  [encoded record tails](ENCODED_RECORD_TAILS.md).

The executable differential suite is the authority for qualified behavior.

## Explicit refusals and remaining work

The current backend refuses callback results that may borrow callback-local
storage, unsupported owned layouts and containing shapes (nonfinal owners, multiple variable fields and
containing variable-mode enums), variable-element
growables beyond scalar varints, encoded arrays after variable prefixes or inside variable enums, and unproved
encoded nonlocal targets; resizable/multiple-owner enum payloads;
unproven packed-overlap observations after nonempty named enum replacement;
variable enum rendering, indirect aggregate snapshots and structural comparison;
relative and pool references;
out-of-line nonlocal returns with unproven aggregate-element Var/runtime-limited arrays or unproved enum/record owned target results;
threads/queues; binary framing/serialization; custom formatters and
unsupported aggregate rendering; padded frame objects, suffix padding after
owned tails and ambiguous bare-pad fixed payloads in variable enums.
Unsupported nodes fail with a source diagnostic. There is no C fallback.

Pinned Goose function values are static and nonescaping. Runtime-selected
function pointers and heap closures are outside that language contract; the
remaining direct-target work concerns static specialization and environments.

The generic frontend can understand more language features than this target can
lower. A successful ordinary Goose type check alone is not proof that a program
belongs to the direct target's supported fragment.

## Reference target

The pinned C backend is retained with the checked stable-stack runtime patch.
The `.mjs` profile uses Emscripten's JavaScript host and retains the earlier
wasm32-compatibility/memory64 options. The standalone `.wasm` profile uses true
memory64 and explicit LP64/WASI64 host adapters. Its supported host services are
documented by the runners, and it is not a drop-in WASI32 executable.

The direct and C targets have different internal layouts. Differential tests
compare language-visible results, errors, and side effects on the common
supported fragment. Binary C-ABI equivalence is not claimed.
