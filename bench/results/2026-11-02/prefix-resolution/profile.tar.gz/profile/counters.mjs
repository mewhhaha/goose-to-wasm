import {readFileSync,writeFileSync} from "node:fs";
import {runModule} from "./run-profile.mjs";
const result=await runModule(readFileSync("build/sorting-climb/profile/sorting-counters.wasm"));
if(result.exitCode || !result.stdout.equals(readFileSync("examples/expected/sorting.out"))) throw new Error("diagnostic output mismatch");
writeFileSync("build/sorting-climb/profile/counters.json",JSON.stringify(result.diagnostics,null,2)+"\n");
console.log(result.diagnostics);
