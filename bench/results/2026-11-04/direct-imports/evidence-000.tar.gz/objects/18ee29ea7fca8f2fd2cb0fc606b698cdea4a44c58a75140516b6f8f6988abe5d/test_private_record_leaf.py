#!/usr/bin/env python3
"""Qualify bounded private-record leaves without changing caller snapshots."""
import argparse
import json
from pathlib import Path
import subprocess
import sys
import unittest

import test_function_value_forwarding as fv
import test_memory_growth_helper as growth
import test_prefix_resolution as prefix
import test_private_snapshot_parameters as snapshots
import test_strip_loops as strip

REFERENCE = None
NESTED = '''struct Name { text:u8[..12] }
struct Entry { tag:u8, name:Name, number:i64 }
inline fn compare_bytes(a:const u8[:],b:const u8[:])->i64 {
    let left=a[..]; let right=b[..];
    var count=left.len; if right.len<count { count=right.len; }
    for i in count {
        if left[i]<right[i] { return -1; }
        if left[i]>right[i] { return 1; }
    }
    return left.len-right.len;
}
recursive fn alphabetic(a:Entry,b:Entry)->i64 {
    let left=a.name.text[1..]; let right=b.name.text[1..];
    return compare_bytes(left,right)+(a.tag as i64)+(a.number-b.number);
}
fn main() {
    print(alphabetic(Entry {2,Name {"xada"},9},Entry {3,Name {"ygrace"},8}));
    print(alphabetic(Entry {2,Name {"xada"},9},Entry {3,Name {"yada"},8}));
}
'''
CALL_FALLBACK = '''struct Pair { first:i64, second:i64 }
recursive fn value(p:Pair)->i64 { p.first+p.second }
recursive fn forwarding(p:Pair)->i64 { value(p) }
recursive fn local_copy(p:Pair)->i64 { var kept=p; kept.first++; return kept.first; }
inline fn inlined(p:Pair)->i64 { p.first }
recursive fn aggregate_inline(p:Pair)->i64 { inlined(p) }
fn main() { let p=Pair {3,4}; print(forwarding(p)," ",local_copy(p)," ",aggregate_inline(p)); }
'''
PREFIX = prefix.ENABLE + '''struct Pair { first:i64, second:i64 }
struct Packet { head:i64[2], values:i64[>..] }
recursive fn make()->Packet { return Packet {[1,2],[3]}; }
recursive fn inspect(p:Pair)->i64 { p.first+p.second }
fn main() { let packet=make(); print(inspect(Pair {4,5})," ",packet.values[0]," ",enable().len); }
'''
PHYSICAL = '''struct Sample { tag:u8, text:u8[..12], value:i64 }
recursive fn inspect(p:Sample,lo:i64,hi:i64)->i64 {
    let view=p.text[lo..hi];
    return (p.tag as i64)+p.value+view.len+(view[0] as i64);
}
recursive fn route(p:Sample&,lo:i64,hi:i64)->i64 { inspect(p,lo,hi) }
fn main() { let sample=Sample {7,[17,34,51],100}; route(sample,0,3); }
'''
NODE_HOST = r'''const fs=require('node:fs');
const [path,mode]=process.argv.slice(1);const module_=new WebAssembly.Module(fs.readFileSync(path));
let e;const aborts=[];const goose=Object.fromEntries(WebAssembly.Module.imports(module_).map(i=>[i.name,()=>{}]));
goose.abort=(p,n,line)=>aborts.push({message:new TextDecoder().decode(new Uint8Array(e.memory.buffer,p>>>0,n>>>0)),line});
e=new WebAssembly.Instance(module_,{goose}).exports;e._start();
e.memory.grow(1);const bytes=Buffer.from(e.memory.buffer);let p=bytes.length-64;
bytes.fill(0,p,p+22);bytes[p]=7;bytes[p+1]=3;bytes.set([17,34,51],p+2);bytes.writeBigInt64LE(100n,p+14);
let lo=0n,hi=3n;if(mode==='short')p=bytes.length-3;
if(mode==='bounds'){lo=3n;hi=2n;}if(mode==='forged'){bytes[p+1]=255;hi=255n;}
let trapped=false,value=null;const pages=bytes.length/65536;
try{value=String(e.attempt(p,lo,hi));}catch(error){if(!(error instanceof WebAssembly.RuntimeError))throw error;trapped=true;}
process.stdout.write(JSON.stringify({trapped,value,aborts,pages,after:e.memory.buffer.byteLength/65536}));
'''


class PrivateRecordLeaf(unittest.TestCase):
    setUp = fv.FunctionValueForwarding.setUp
    compile = fv.FunctionValueForwarding.compile
    compile_file = fv.FunctionValueForwarding.compile_file
    compile_input = fv.FunctionValueForwarding.compile_input
    native = fv.FunctionValueForwarding.native
    run_engines = fv.FunctionValueForwarding.run_engines

    def qualify(self, source, expected, leaves=(), framed=(), caller=None, effects=False):
        if effects:
            source = prefix.ENABLE + source.replace('fn main() {', 'fn main() { enable();')
        for level in (0, 2):
            for debug in (False, True):
                with self.subTest(level=level, debug=debug):
                    path, stats = self.compile_input(source, level, debug)
                    bodies = list(fv.function_bodies(path, stats))
                    for symbol in (*leaves, *framed):
                        selected = [body for name, body in bodies if name.split('#')[0] == symbol]
                        self.assertTrue(selected, symbol)
                        for body in selected:
                            ops = list(strip.instructions(body))
                            if symbol in leaves:
                                self.assertNotIn(0x24, ops, symbol)
                                self.assertEqual(fv.memory_copy_count(body), 0, symbol)
                            else:
                                self.assertIn(0x24, ops, symbol)
                    self.assertEqual(self.native(source, level, debug), expected)
                    for engine, output in self.run_engines(path):
                        with self.subTest(engine=engine):
                            self.assertEqual(output, expected)
                    if REFERENCE is None:
                        continue
                    selected = strip.GOOSE
                    try:
                        strip.GOOSE = REFERENCE
                        previous_path, previous_stats = self.compile_input(source, level, debug)
                        before = list(fv.function_bodies(previous_path, previous_stats))
                    finally:
                        strip.GOOSE = selected
                    if caller:
                        current = next(body for name, body in bodies if name.split('#')[0] == caller)
                        old = next(body for name, body in before if name.split('#')[0] == caller)
                        self.assertGreater(fv.memory_copy_count(current), 0)
                        self.assertEqual(fv.memory_copy_count(current), fv.memory_copy_count(old))
                        if effects:
                            self.assertLess(len(current), len(old))
                        else:
                            self.assertEqual(current, old)
                    for name, body in bodies:
                        if name.split('#')[0] in leaves:
                            old = next(previous for symbol, previous in before if symbol == name)
                            self.assertIn(0x24, list(strip.instructions(old)))
                            self.assertLess(len(body), len(old))

    def test_ordinary_and_inline_slice_comparators_keep_private_caller_copies(self):
        self.qualify(snapshots.SLICES, '-1\n', leaves=('names',), caller='main')
        self.qualify(NESTED, '2\n3\n', leaves=('alphabetic',), caller='main', effects=True)

    def test_later_argument_mutation_keeps_the_first_record_snapshot(self):
        self.qualify(snapshots.ORDER, '1097 99\n', leaves=('receive',), caller='main')

    def test_aggregate_calls_locals_and_inline_parameters_still_need_storage(self):
        self.qualify(CALL_FALLBACK, '7 4 3\n', leaves=('value',),
                     framed=('forwarding', 'local_copy', 'aggregate_inline'))

    def test_unproved_entries_and_prefix_context_keep_frames(self):
        for label, (source, expected, names) in snapshots.FALLBACKS.items():
            with self.subTest(case=label):
                self.qualify(source, expected, framed=names)
        self.qualify(PREFIX, '9 3 1\n', framed=('inspect',))

    def physical_observations(self, path, mode):
        import wasmtime
        result = subprocess.run([strip.NODE, '-e', NODE_HOST, str(path), mode],
                                capture_output=True, text=True, timeout=30)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        v8 = json.loads(result.stdout)
        engine = wasmtime.Engine()
        module = wasmtime.Module.from_file(engine, str(path))
        store = wasmtime.Store(engine)
        linker = wasmtime.Linker(engine)
        aborts = []
        def abort(caller, pointer, length, line):
            memory = caller.get('memory')
            aborts.append({'message': bytes(memory.read(caller, pointer, pointer + length)).decode(), 'line': line})
        for item in module.imports:
            if item.name == 'abort':
                linker.define_func(item.module, item.name, item.type, abort, access_caller=True)
            else:
                linker.define_func(item.module, item.name, item.type, lambda *args: None)
        exports = linker.instantiate(store, module).exports(store)
        exports['_start'](store)
        memory = exports['memory']
        memory.grow(store, 1)
        size = memory.data_len(store)
        pointer = size - 64
        image = bytes([7, 3, 17, 34, 51]) + bytes(9) + (100).to_bytes(8, 'little')
        memory.write(store, image, pointer)
        lo, hi = 0, 3
        if mode == 'short':
            pointer = size - 3
        if mode == 'bounds':
            lo, hi = 3, 2
        if mode == 'forged':
            memory.write(store, bytes([255]), pointer + 1)
            hi = 255
        trapped, value = False, None
        try:
            value = str(exports['attempt'](store, pointer, lo, hi))
        except wasmtime.Trap:
            trapped = True
        observed = {'trapped': trapped, 'value': value, 'aborts': aborts,
                    'pages': size // 65536, 'after': memory.size(store)}
        self.assertEqual(v8, observed)
        return observed

    def test_full_record_span_unaligned_fields_bounds_lengths_and_memory_growth(self):
        for level in (0, 2):
            for debug in (False, True):
                observations = {}
                compilers = [strip.GOOSE]
                if REFERENCE is not None:
                    compilers.insert(0, REFERENCE)
                for compiler in compilers:
                    selected = strip.GOOSE
                    try:
                        strip.GOOSE = compiler
                        path, stats = self.compile_input(PHYSICAL, level, debug)
                    finally:
                        strip.GOOSE = selected
                    route = next(row['index'] for row in stats['function_info'] if row['name'].split('#')[0] == 'route')
                    path.write_bytes(growth.expose_attempt(path.read_bytes(), route))
                    for mode in ('valid', 'short', 'bounds', 'forged'):
                        with self.subTest(level=level, debug=debug, compiler=compiler, mode=mode):
                            observed = self.physical_observations(path, mode)
                            self.assertEqual(observed['pages'], observed['after'])
                            self.assertEqual(observed['trapped'], mode in ('short', 'bounds'))
                            if mode == 'valid':
                                self.assertEqual(observed['value'], '127')
                            if mode == 'forged':
                                self.assertEqual(observed['value'], '379')
                            if mode in observations:
                                self.assertEqual(observed, observations[mode])
                            observations[mode] = observed


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--goose', type=Path, default=strip.GOOSE)
    parser.add_argument('--reference-goose', type=Path)
    parser.add_argument('--node', default=strip.NODE)
    parser.add_argument('--cc', default=prefix.CC)
    args, remaining = parser.parse_known_args()
    strip.GOOSE = prefix.GOOSE = args.goose.resolve()
    strip.NODE = prefix.NODE = args.node
    prefix.CC = args.cc
    if args.reference_goose:
        REFERENCE = args.reference_goose.resolve()
    unittest.main(argv=[sys.argv[0], *remaining])
