import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[3]
WORK = Path(__file__).resolve().parent
CANDIDATE = WORK / 'candidate'
HOSTS = ROOT / 'build/remaining-hills/startup/baseline'
FLOOR = json.loads((ROOT / 'build/functions-floor/run-1/report.json').read_text())
CASE = FLOOR['cases']['functions']
GOLDEN = ROOT / 'examples/expected/functions.out'
WASM = CANDIDATE / 'examples/functions.wasm'
AOT = CANDIDATE / 'functions.cwasm'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


records = []
commands = [
    [str(HOSTS / 'goose-wasmtime'), '--aot-profile', 'minimal', '--no-cache', '--compile', str(WASM), str(AOT)],
    [str(HOSTS / 'goose-wasmtime'), '--aot-profile', 'minimal', '--precompiled', str(AOT)],
    [str(HOSTS / 'goose-wasmtime-aot'), '--precompiled', str(AOT)],
]
for index, command in enumerate(commands):
    result = subprocess.run(command, capture_output=True, timeout=60)
    expected = b''
    if index:
        expected = GOLDEN.read_bytes()
    records.append({'command': command, 'exit_code': result.returncode,
                    'stdout': result.stdout.decode(), 'stderr': result.stderr.decode(),
                    'exact_expected': result.stdout == expected})
    assert result.returncode == 0 and result.stdout == expected and not result.stderr, records[-1]
(CANDIDATE / 'aot-qualification.json').write_text(json.dumps({
    'commands': records, 'wasm_sha256': digest(WASM), 'aot_sha256': digest(AOT),
    'golden_sha256': digest(GOLDEN)}, indent=2) + '\n')
inputs = [
    ROOT / 'toolchain.json', ROOT / 'examples/functions.goose', GOLDEN,
    WORK / 'full10-shapes.json', CANDIDATE / 'identity.json',
    CANDIDATE / 'aot-qualification.json', WASM, CANDIDATE / 'examples/functions.json',
    CANDIDATE / 'source.json', CANDIDATE / 'toolchain.json',
    ROOT / 'build/next-runtime-hills/final/source.json',
    ROOT / 'build/next-runtime-hills/final/toolchain.json',
    HOSTS / 'goose-wasmtime-aot.json', HOSTS / 'goose-wasmtime-aot-aa.json',
    Path(__file__).resolve(),
]
for bundle in [CANDIDATE, ROOT / 'build/next-runtime-hills/final']:
    inputs.extend(sorted((bundle / 'compiler').glob('*.h')))
    for name in ['oracle/patches/0001-webassembly-target.patch', 'patches/direct-target.patch']:
        inputs.append(bundle / name)
configuration = {
    'schema': 'record-leaf-paired-config-v1', 'samples': 61, 'warmups': 2,
    'affinities': ['pool', 'cpu2'], 'seed': 2026110419,
    'inputs': [str(path.resolve()) for path in inputs],
    'cells': {
        'baseline': {'executable': str(HOSTS / 'goose-wasmtime-aot'), 'aot': CASE['aot'], 'expected': str(GOLDEN)},
        'aa': {'executable': str(HOSTS / 'goose-wasmtime-aot-aa'), 'aot': CASE['aot'], 'expected': str(GOLDEN)},
        'candidate': {'executable': str(HOSTS / 'goose-wasmtime-aot'), 'aot': str(AOT), 'expected': str(GOLDEN)},
        'native': {'executable': CASE['native'], 'expected': str(GOLDEN)},
    },
    'comparisons': [['candidate', 'baseline'], ['aa', 'baseline'], ['candidate', 'native']],
}
for path in inputs:
    assert path.is_file(), path
assert (HOSTS / 'goose-wasmtime-aot').stat().st_ino != (HOSTS / 'goose-wasmtime-aot-aa').stat().st_ino
(WORK / 'paired-config.json').write_text(json.dumps(configuration, indent=2) + '\n')
print(WORK / 'paired-config.json')
