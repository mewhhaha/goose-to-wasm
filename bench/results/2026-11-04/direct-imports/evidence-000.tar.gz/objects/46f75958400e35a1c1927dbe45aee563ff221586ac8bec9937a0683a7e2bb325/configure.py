from pathlib import Path
import hashlib,json
ROOT=Path.cwd();B=ROOT/'build/remaining-hills/startup';OUT=B/'raw';fixtures=json.loads((B/'fixture-config.json').read_text())
inputs=[OUT/'prepare.py',OUT/'build_raw.py',OUT/'direct-only.cpp',OUT/'wasmtime.raw-callback.cpp',ROOT/'host/wasmtime-sdk.json',ROOT/'toolchain.json',OUT/'guard-tests.cpp',OUT/'guard-tests.json',OUT/'guard-tests.log']
hosts={'original':B/'baseline/goose-wasmtime-aot','aa_clone':B/'baseline/goose-wasmtime-aot-aa','direct':OUT/'direct/goose-wasmtime-aot','raw':OUT/'goose-wasmtime-aot'}
for host in hosts.values():
    metadata=host.with_suffix('.json');data=json.loads(metadata.read_text());inputs.append(metadata);inputs.extend(Path(path)for path in data['input_sha256'])
cells={};comparisons=[]
for name in ['empty','print-only','functions']:
    fixture=fixtures['cases'][name];expected=OUT/(name+'.out');expected.write_bytes(bytes.fromhex(fixture['expected_stdout_hex']));inputs.append(Path(fixture['wasm']))
    for mode,host in hosts.items():cells[name+'-'+mode]={'executable':str(host),'aot':fixture['original_aot'],'expected':str(expected)}
    native=ROOT/'build/functions-native-hills/current/examples/compile/functions/native/0/program.bin'
    if name!='functions':native=ROOT/'build/functions-floor/run-1'/name/'program.bin'
    cells[name+'-native']={'executable':str(native.resolve()),'expected':str(expected)}
    for numerator,denominator in [('raw','direct'),('raw','original'),('raw','aa_clone'),('direct','original'),('aa_clone','original'),('raw','native')]:comparisons.append([name+'-'+numerator,name+'-'+denominator])
configuration={'schema':'goose-raw-callback-paired-config-v1','purpose':'Unchanged Functions primary comparison: bounded raw adapter versus checked direct binding; same AOT, A/A original host and native controls. Empty/print-only attribution controls. Prepared only; run requires root exclusive timing grant.','samples':201,'warmups':2,'seed':2026110419,'affinities':['pool','cpu2'],'inputs':sorted(set(str(path.resolve())for path in inputs)),'cells':cells,'comparisons':comparisons}
(OUT/'timing-config.json').write_text(json.dumps(configuration,indent=2)+'\n')
print('Prepared 15-cell 201-pair pool/CPU2 timing configuration; no primary runs started.')
