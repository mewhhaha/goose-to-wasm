#define main goose_host_main
#include "wasmtime.no-cow.cpp"
#undef main
int main(int argc, char **argv) {
    if (argc != 2) return 2;
    try {
        Options options;
        options.minimal_profile = true;
        options.precompiled = true;
        options.module = argv[1];
        Runtime runtime(options);
        for (int i = 0; i < 4; ++i) {
            State state;
            if (run(options, state, &runtime) != 0 || state.output != "1048576\n" || !state.failure.empty()) return 1;
        }
        std::puts("Four fresh Stores on one matched no-COW Engine preserve initialized data and zero-grown pages.");
        return 0;
    } catch (const std::exception &error) {
        std::fprintf(stderr, "%s\n", error.what());
        return 1;
    }
}
