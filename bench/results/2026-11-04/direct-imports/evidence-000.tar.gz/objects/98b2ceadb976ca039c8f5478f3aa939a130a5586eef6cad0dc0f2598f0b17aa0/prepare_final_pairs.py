"""Pin final product hosts and identical compiled inputs for confirmation."""
import hashlib
import json
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parents[2]
BUILD = ROOT / 'build/remaining-hills'
OUT = BUILD / 'final-pairs'
OUT.mkdir(exist_ok=True)
if any(OUT.iterdir()):
    raise ValueError('final paired preparation already exists')
CURRENT = BUILD / 'current'
PRIOR = ROOT / 'build/functions-native-hills/current'
PAIR_ARTIFACTS = BUILD / 'final-artifacts'
PAIR_ARTIFACTS.mkdir(exist_ok=False)
sys.path.insert(0, str(ROOT / 'bench'))
import process


def digest(path):
    with Path(path).open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


hosts = {'baseline': BUILD / 'startup/baseline/goose-wasmtime-aot',
         'aa': BUILD / 'startup/baseline/goose-wasmtime-aot-aa',
         'direct': BUILD / 'startup/raw/direct/goose-wasmtime-aot',
         'final': ROOT / 'build/bin/goose-wasmtime-aot'}
inputs = {Path(__file__), ROOT / 'bench/process.py', BUILD / 'qualification/report.json',
          CURRENT / 'examples/report.json', CURRENT / 'host/report.json',
          ROOT / 'examples/manifest.json', ROOT / 'toolchain.json'}
for host in hosts.values():
    metadata_path = host.with_suffix('.json')
    metadata = json.loads(metadata_path.read_bytes())
    assert digest(host) == metadata['host_sha256']
    for path, expected in metadata['input_sha256'].items():
        assert digest(path) == expected, path
    inputs.add(metadata_path)
    inputs.update(map(Path, metadata['input_sha256']))
catalog = json.loads((ROOT / 'examples/manifest.json').read_bytes())['examples']
cells = {}
comparisons = []
artifacts = []
checks = []
for example in catalog:
    name = example['name']
    expected = ROOT / 'examples' / example['expected']
    wasm = CURRENT / 'examples/compile' / name / 'direct/0/program.wasm'
    before = PRIOR / 'examples/compile' / name / 'direct/0/program.wasm'
    assert digest(wasm) == digest(before), name
    prepared_aot = CURRENT / 'host/preparation' / name / 'direct/minimal/0/program.cwasm'
    aot = PAIR_ARTIFACTS / (name + '.cwasm')
    shutil.copyfile(prepared_aot, aot)
    assert digest(prepared_aot) == digest(aot)
    artifacts.append({'name': name, 'wasm': str(wasm), 'previous': str(before), 'sha256': digest(wasm), 'bytes': wasm.stat().st_size,
                      'aot': str(aot), 'aot_sha256': digest(aot), 'prepared_aot': str(prepared_aot)})
    inputs.update([wasm, before, prepared_aot])
    for variant, host in hosts.items():
        key = name + '_' + variant
        cells[key] = {'executable': str(host), 'aot': str(aot), 'expected': str(expected)}
        command = list(map(str, [host, '--precompiled', aot]))
        result = process.run(command, input=b'', capture_output=True, timeout=30, cwd=ROOT)
        checks.append({'command': command, 'exit_code': result.returncode,
                       'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(), 'stderr': result.stderr.decode()})
        assert result.returncode == 0 and result.stdout == expected.read_bytes() and not result.stderr
    cells[name + '_native'] = {'executable': str(CURRENT / 'examples/compile' / name / 'native/0/program.bin'), 'expected': str(expected)}
    comparisons += [[name + '_final', name + '_baseline'], [name + '_aa', name + '_baseline'],
                    [name + '_final', name + '_native'], [name + '_final', name + '_direct']]
regression = {'samples': 31, 'warmups': 2, 'affinities': ['pool', 'cpu2'], 'seed': 2026110461,
              'inputs': sorted(map(str, inputs)), 'cells': cells, 'comparisons': comparisons}
save(OUT / 'regression-config.json', regression)
confirmation = {**regression, 'samples': 201, 'seed': 2026110459,
                'cells': {key: value for key, value in cells.items() if key.startswith('functions_')},
                'comparisons': [row for row in comparisons if row[0].startswith('functions_')]}
save(OUT / 'functions-config.json', confirmation)
save(OUT / 'preparation.json', {'status': 'passed', 'method': 'All ten direct Wasm modules remain byte-identical to the separately collected prior compiler8c09 cohort. '
                                            'All four minimal hosts successfully execute each freshly prepared common AOT with exact golden stdout, empty stderr and exit0. '
                                            'Preflight outside timing; final process harness pins bytes and normalizes inodes again. '
                                            'Freshly prepared AOT bytes are copied to ten regular Btrfs files before pairing, so the original eviction/read normalization protocol remains applicable. '
                                            'Large raw-log outputs and configs remain in RAM scratch; primary final executables/native inputs/AOT live on the original filesystem.',
                              'artifacts': artifacts, 'checks': checks})
print('prepared final paired configurations', OUT)
