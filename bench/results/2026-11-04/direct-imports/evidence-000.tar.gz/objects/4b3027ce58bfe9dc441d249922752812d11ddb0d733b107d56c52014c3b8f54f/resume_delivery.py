"""Resume after checkpoint ENOSPC; preserve the already completed example cohort."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
BUILD = ROOT / 'build/remaining-hills'
SCRATCH = Path('/dev/shm/goose-remaining-hills-20261104')
OUTPUT = SCRATCH / 'execution'


def digest(path):
    with Path(path).open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def save(value):
    path = OUTPUT / 'report.tmp'
    path.write_text(json.dumps(value, indent=2) + '\n')
    path.replace(OUTPUT / 'report.json')


def main():
    old_path = BUILD / 'delivery-execution/report.tmp'
    old = json.loads(old_path.read_bytes())
    example_path = BUILD / 'current/examples/report.json'
    examples = json.loads(example_path.read_bytes())
    assert old['status'] == 'failed' and 'No space left' in old['error']
    assert examples['status'] == 'passed' and len(examples['observations']) == 1600
    first = old['phases'][0]
    assert first['exit_status'] == 0 and first['observations'] == 1600
    assert digest(example_path) == first['report_sha256']
    assert all(digest(path) == sha for path, sha in old['input_sha256'].items())
    report = {**old, 'schema': 'goose-direct-imports-delivery-execution-v2', 'status': 'running',
              'resumed_utc': datetime.now(timezone.utc).isoformat(), 'pid': os.getpid(),
              'phases': [first], 'resumption': {'failed_checkpoint': str(old_path),
                  'failed_checkpoint_sha256': digest(old_path), 'driver_log': str(BUILD / 'measurement-driver.log'),
                  'driver_log_sha256': digest(BUILD / 'measurement-driver.log'), 'scratch_root': str(SCRATCH),
                  'method': 'Original example process exited0 with a complete passed1600-row report. The following checkpoint rename hit Btrfs ENOSPC. '
                            'All original input pins and the completed example report were reverified; those samples are retained without rerunning. '
                            'Remaining sequential cohorts run on dedicated RAM-backed scratch storage; no builds/tests/hash/archive work overlaps them.'}}
    report.pop('error')
    report['input_sha256'].update({str(Path(__file__)): digest(__file__), str(BUILD / 'scratch-storage.json'): digest(BUILD / 'scratch-storage.json')})
    commands = [
        ('host', [sys.executable, ROOT / 'bench/wasmtime_host.py', '--host', ROOT / 'build/bin/goose-wasmtime',
                  '--aot-host', ROOT / 'build/bin/goose-wasmtime-aot', '--example-report', example_path,
                  '--samples', '15', '--prepare-samples', '5', '--warmups', '1', '--machine-label',
                  'AMD Ryzen 7 3800X, shared host', '--output-dir', SCRATCH / 'host'], SCRATCH / 'host/report.json', 1760),
        ('lifecycle', [sys.executable, ROOT / 'bench/runtime_lifecycle.py', '--example-report', example_path,
                       '--host', ROOT / 'build/bin/goose-wasmtime', '--samples', '15', '--warmups', '1',
                       '--machine-label', 'AMD Ryzen 7 3800X, shared host', '--output-dir', SCRATCH / 'lifecycle'],
                      SCRATCH / 'lifecycle/report.json', 960)]
    save(report)
    try:
        for name, command, path, count in commands:
            assert not path.exists()
            command = list(map(str, command))
            row = {'name': name, 'command': command, 'report': str(path), 'started_utc': datetime.now(timezone.utc).isoformat()}
            report['phases'].append(row)
            save(report)
            started = time.monotonic()
            with (OUTPUT / (name + '.log')).open('wb') as log:
                result = subprocess.run(command, cwd=ROOT, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT)
            row.update(exit_status=result.returncode, wall_seconds=time.monotonic() - started,
                       finished_utc=datetime.now(timezone.utc).isoformat())
            assert result.returncode == 0, name
            child = json.loads(path.read_bytes())
            assert child['status'] == 'passed' and len(child['observations']) == count
            if name == 'host':
                assert len(child['preparation']) == 300
            row.update(report_sha256=digest(path), observations=count)
            save(report)
            print('PASS', name, count, flush=True)
        report['input_sha256_after'] = {path: digest(path) for path in report['input_sha256']}
        assert report['input_sha256_after'] == report['input_sha256']
        assert report['environment']['controls'] == {name: os.environ.get(name) for name in report['environment']['controls']}
        report.update(status='passed', finished_utc=datetime.now(timezone.utc).isoformat())
    except BaseException as error:
        report.update(status='failed', error=type(error).__name__ + ': ' + str(error))
        save(report)
        raise
    save(report)
    (OUTPUT / 'completion.json').write_text(json.dumps({'status': 'passed', 'report_sha256': digest(OUTPUT / 'report.json')}, indent=2) + '\n')


if __name__ == '__main__':
    main()
