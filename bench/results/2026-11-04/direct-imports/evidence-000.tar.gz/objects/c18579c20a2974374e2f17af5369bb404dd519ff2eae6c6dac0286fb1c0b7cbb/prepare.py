from pathlib import Path
import hashlib,json,shutil
ROOT=Path.cwd();OUT=ROOT/'build/remaining-hills/startup/raw';source=(OUT/'direct-only.cpp').read_text()
source=source.replace('#include <algorithm>','#include <algorithm>\n#include <bit>',1)
needle='static bool signature(const wasm_valtype_vec_t *types, string_view expected) {'
raw=r'''#ifdef RUNTIME_ONLY
static wasmtime_valkind_t scalar_kind(char type) {
    switch (type) {
    case 'i': return WASMTIME_I32;
    case 'I': return WASMTIME_I64;
    case 'f': return WASMTIME_F32;
    case 'F': return WASMTIME_F64;
    default: return 255;
    }
}
static bool raw_eligible(const Spec &spec) {
    if constexpr (std::endian::native != std::endian::little) return false;
    string_view params(spec.params), results(spec.results);
    if (params.size() > 4 || results.size() > 1) return false;
    for (char type : params) if (scalar_kind(type) == 255) return false;
    for (char type : results) if (scalar_kind(type) == 255) return false;
    return true;
}
template <class Target, class Source> static void copy_scalar(wasmtime_valkind_t kind, Target &target, const Source &source) {
    switch (kind) {
    case WASMTIME_I32: std::memcpy(&target.i32, &source.i32, sizeof(int32_t)); break;
    case WASMTIME_I64: std::memcpy(&target.i64, &source.i64, sizeof(int64_t)); break;
    case WASMTIME_F32: std::memcpy(&target.f32, &source.f32, sizeof(float)); break;
    case WASMTIME_F64: std::memcpy(&target.f64, &source.f64, sizeof(double)); break;
    }
}
static wasm_trap_t *raw_callback(void *env, wasmtime_caller_t *caller, wasmtime_val_raw_t *values, size_t capacity) noexcept {
    const auto &spec = *static_cast<const Spec *>(env);
    string_view params(spec.params), results(spec.results);
    if (params.size() > 4 || results.size() > 1 || capacity < std::max(params.size(), results.size()))
        return wasmtime_trap_new("invalid raw host callback capacity", 34);
    wasmtime_val_t arguments[4]{}, result[1]{};
    // Snapshot every argument before results overwrite the shared raw slots.
    for (size_t i = 0; i < params.size(); ++i) {
        arguments[i].kind = scalar_kind(params[i]);
        if (arguments[i].kind == 255) return wasmtime_trap_new("invalid raw host callback type", 30);
        copy_scalar(arguments[i].kind, arguments[i].of, values[i]);
    }
    auto trap = callback(env, caller, arguments, params.size(), result, results.size());
    if (trap || results.empty()) return trap;
    auto expected = scalar_kind(results[0]);
    if (expected == 255 || result[0].kind != expected)
        return wasmtime_trap_new("invalid raw host callback result", 32);
    copy_scalar(expected, values[0], result[0].of);
    return nullptr;
}
#endif
'''
assert source.count(needle)==1;source=source.replace(needle,raw+needle)
needle='        wasmtime_func_new(context, type, callback, const_cast<Spec *>(found), nullptr, &bound[index].of.func);'
assert source.count(needle)==1;source=source.replace(needle,'''        if (raw_eligible(*found))
            wasmtime_func_new_unchecked(context, type, raw_callback, const_cast<Spec *>(found), nullptr, &bound[index].of.func);
        else wasmtime_func_new(context, type, callback, const_cast<Spec *>(found), nullptr, &bound[index].of.func);''')
(OUT/'wasmtime.raw-callback.cpp').write_text(source)
builder=(ROOT/'scripts/build_wasmtime_host.py').read_text().replace('ROOT = Path(__file__).resolve().parents[1]','ROOT = Path('+repr(str(ROOT))+')').replace("source = ROOT/'host/wasmtime.cpp'","source = ROOT/'build/remaining-hills/startup/raw/wasmtime.raw-callback.cpp'")
(OUT/'build_raw.py').write_text(builder)
# Freeze current direct host artifacts and preserve metadata's provenance aliases.
for name in ['goose-wasmtime','goose-wasmtime-aot']:
    original=OUT.parent/'pilot'/name;target=OUT/'direct'/name;target.parent.mkdir(exist_ok=True)
    shutil.copyfile(original,target);shutil.copymode(original,target)
    original_metadata=original.with_suffix('.json');raw_metadata=original_metadata.read_bytes();meta=json.loads(raw_metadata)
    aliases={str(ROOT/'host/wasmtime.cpp'):str(OUT/'direct-only.cpp'),str(original):str(target)}
    meta['input_sha256']={aliases.get(path,path):value for path,value in meta['input_sha256'].items()}
    meta['command']=[aliases.get(arg,arg)for arg in meta['command']]
    (OUT/'direct'/(name+'.original.json')).write_bytes(raw_metadata)
    meta['snapshot_derivation']={'kind':'byte-identical-path-aliases-not-a-rebuild','original_manifest_sha256':hashlib.sha256(raw_metadata).hexdigest(),'path_aliases':aliases}
    target.with_suffix('.json').write_text(json.dumps(meta,indent=2)+'\n')
print('Prepared private raw wrapper and frozen direct-only source/hosts.')
