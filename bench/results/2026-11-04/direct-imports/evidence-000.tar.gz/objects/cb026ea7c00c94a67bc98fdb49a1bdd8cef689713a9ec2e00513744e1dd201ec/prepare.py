from pathlib import Path
import hashlib,json,subprocess
import wasmtime
ROOT=Path.cwd();B=ROOT/'build/remaining-hills/startup';fixtures=B/'fixtures';fixtures.mkdir(exist_ok=True)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def invoke(command):
    result=subprocess.run(list(map(str,command)),input=b'',capture_output=True,timeout=60)
    assert result.returncode==0,(command,result.stderr)
    assert not result.stdout and not result.stderr,(command,result)
    return {'command':list(map(str,command)),'exit_code':result.returncode}
raw=b'0123456789abcdef'*65536
wat='''(module
(import "goose" "print_i64" (func $print (param i64)))
(import "goose" "newline" (func $newline))
(memory (export "memory") 17 18)
(data (i32.const 0) "'''+raw.decode()+'''")
(func (export "_start")
(if (i32.ne (i32.load8_u (i32.const 0)) (i32.const 48)) (then unreachable))
(if (i32.ne (i32.load8_u (i32.const 524288)) (i32.const 48)) (then unreachable))
(if (i32.ne (i32.load8_u (i32.const 1048575)) (i32.const 102)) (then unreachable))
(if (i32.ne (i32.load8_u (i32.const 1048576)) (i32.const 0)) (then unreachable))
(if (i32.ne (memory.grow (i32.const 1)) (i32.const 17)) (then unreachable))
(if (i32.ne (i32.load8_u (i32.const 1179647)) (i32.const 0)) (then unreachable))
(i32.store8 (i32.const 0) (i32.const 99))
(i32.store8 (i32.const 1179647) (i32.const 99))
(call $print (i64.const 1048576)) (call $newline)))'''
(fixtures/'large-data.wat').write_text(wat);(fixtures/'large-data.wasm').write_bytes(wasmtime.wat2wasm(wat))
verify='''(module (import "goose" "write" (func $write (param i32 i32)))
(memory (export "memory") 17 18) (data (i32.const 0) "'''+raw.decode()+'''")
(func (export "_start") (call $write (i32.const 0) (i32.const 1048576))))'''
(fixtures/'verify-large.wasm').write_bytes(wasmtime.wat2wasm(verify))
floor=ROOT/'build/functions-floor/run-1';current=ROOT/'build/functions-native-hills/current'
cases={
'empty':{'wasm':floor/'empty/program.wasm','original_aot':floor/'empty/program.cwasm','expected':b''},
'print-only':{'wasm':floor/'print-only/program.wasm','original_aot':floor/'print-only/program.cwasm','expected':(ROOT/'examples/expected/functions.out').read_bytes()},
'functions':{'wasm':current/'examples/compile/functions/direct/0/program.wasm','original_aot':current/'host/preparation/functions/direct/minimal/0/program.cwasm','expected':(ROOT/'examples/expected/functions.out').read_bytes()},
'large-data':{'wasm':fixtures/'large-data.wasm','original_aot':fixtures/'large-data.cwasm','expected':b'1048576\n'}}
commands=[]
commands.append(invoke([B/'baseline/goose-wasmtime','--aot-profile','minimal','--no-cache','--compile',cases['large-data']['wasm'],cases['large-data']['original_aot']]))
for name,item in cases.items():
    item['no_cow_aot']=fixtures/(name+'.no-cow.cwasm')
    commands.append(invoke([B/'no-cow/goose-wasmtime','--aot-profile','minimal','--no-cache','--compile',item['wasm'],item['no_cow_aot']]))
    for host,aot in [(B/'baseline/goose-wasmtime-aot',item['original_aot']),(B/'pilot/goose-wasmtime-aot',item['original_aot']),(B/'no-cow/goose-wasmtime-aot',item['no_cow_aot'])]:
        for repeat in range(2):
            result=subprocess.run([str(host),'--precompiled',str(aot)],input=b'',capture_output=True,timeout=60)
            assert (result.returncode,result.stdout,result.stderr)==(0,item['expected'],b''),(name,host,result)
for kind,host in [('original',B/'baseline/goose-wasmtime'),('no-cow',B/'no-cow/goose-wasmtime')]:
    artifact=fixtures/('verify-large.'+kind+'.cwasm')
    commands.append(invoke([host,'--aot-profile','minimal','--no-cache','--compile',fixtures/'verify-large.wasm',artifact]))
    runtime=B/'baseline/goose-wasmtime-aot'
    if kind=='no-cow':runtime=B/'no-cow/goose-wasmtime-aot'
    result=subprocess.run([str(runtime),'--precompiled',str(artifact)],input=b'',capture_output=True,timeout=60)
    assert (result.returncode,result.stdout,result.stderr)==(0,raw,b''),(kind,result.returncode,result.stderr)
config={'schema':'goose-startup-pilot-fixtures-v1','status':'prepared-and-correct','cases':{name:{key:str(value.resolve()) for key,value in item.items()if key!='expected'}|{'expected_stdout_hex':item['expected'].hex()}for name,item in cases.items()},'hosts':{key:str((B/path).resolve())for key,path in {'baseline':'baseline/goose-wasmtime-aot','aa_clone':'baseline/goose-wasmtime-aot-aa','direct':'pilot/goose-wasmtime-aot','no_cow':'no-cow/goose-wasmtime-aot'}.items()},'commands':commands,'input_sha256':{str(p.resolve()):digest(p)for p in [Path(__file__),fixtures/'large-data.wat',fixtures/'verify-large.wasm',*(item[k]for item in cases.values()for k in ['wasm','original_aot','no_cow_aot'])]},'large_fixture':'1 MiB of nonzero patterned initialized data; samples initialized/zero bytes, grows memory, checks new zero bytes, mutates initialized/grown pages; separate verifier checks all 1 MiB bytes exactly','timed_benchmarks_run':False}
(B/'fixture-config.json').write_text(json.dumps(config,indent=2)+'\n')
print('Prepared four matched cases; 24 repeated correctness launches and exact 1MiB data checks passed.')
