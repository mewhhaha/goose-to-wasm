# Example program benchmarks

Status: **passed**.

2026-11-04 · AMD Ryzen 7 3800X, shared host.

Goose O2. Direct Wasm uses memory32; C-Wasm uses memory64. The selected programs, their constant inputs and all printing are unchanged from the [example catalog](../../../../examples/README.md). Compiler constant folding is allowed.

Builds are complete uncached Python-driver invocations, including any C compilation/linking. OS page caches and Emscripten's installed system-library cache remain warm.

Runtime is **whole-process launch-to-exit time**, including host startup, Wasm compilation/instantiation, program initialization, computation, output delivery and teardown. Each observation starts a fresh process/instance and calls the entrypoint once. This measures CLI cost, not warmed kernel throughput.

Each cell has 5 build samples or 15 runtime samples. Untimed fresh-process warmups per runtime cell: 1. Orders are shuffled with the recorded seed; builds and runtime never overlap. Every used artifact must pass its golden output. Values are median milliseconds ± median absolute deviation (MAD).

Headline runtime samples use the ordinary runners without timing-file instrumentation. The Wasm supplements use a separate shuffled set of fresh processes, with the same sample count; timing files are written after their engine intervals end.

## Compilation

| Example | Direct | C-Wasm | Native C |
| --- | ---: | ---: | ---: |
| squares | 72.356 ±9.507 | 545.290 ±35.731 | 200.754 ±10.048 |
| tour | 65.086 ±1.856 | 967.850 ±18.681 | 420.464 ±4.523 |
| functions | 85.874 ±3.538 | 956.677 ±14.770 | 519.320 ±30.094 |
| errors | 80.719 ±5.609 | 820.116 ±25.430 | 370.595 ±15.996 |
| sieve | 75.713 ±7.898 | 557.221 ±26.438 | 258.066 ±11.411 |
| sorting | 102.901 ±7.207 | 901.983 ±26.342 | 544.412 ±16.194 |
| sudoku | 98.714 ±7.113 | 555.754 ±17.976 | 280.141 ±20.962 |
| maze | 80.507 ±5.003 | 697.305 ±23.812 | 364.872 ±24.438 |
| vm | 82.818 ±15.048 | 764.236 ±39.475 | 320.402 ±41.721 |
| life | 84.214 ±15.164 | 647.884 ±30.455 | 296.185 ±3.474 |

## Whole-process runtime

| Example | Direct / V8 | C-Wasm / V8 | Direct / Wasmtime | C-Wasm / Wasmtime | Native C |
| --- | ---: | ---: | ---: | ---: | ---: |
| squares | 44.838 ±6.906 | 31.444 ±2.913 | 70.206 ±1.183 | 80.610 ±3.149 | 1.083 ±0.105 |
| tour | 58.226 ±12.237 | 36.648 ±6.202 | 115.950 ±11.979 | 115.772 ±12.018 | 1.074 ±0.126 |
| functions | 34.261 ±3.963 | 33.736 ±1.707 | 101.289 ±1.500 | 117.838 ±8.974 | 1.012 ±0.177 |
| errors | 41.530 ±12.178 | 33.599 ±4.937 | 87.649 ±12.078 | 92.587 ±5.178 | 1.069 ±0.162 |
| sieve | 31.302 ±2.072 | 34.725 ±3.272 | 81.101 ±6.683 | 88.292 ±7.052 | 1.325 ±0.258 |
| sorting | 68.045 ±4.151 | 238.745 ±8.229 | 102.154 ±2.674 | 237.281 ±10.661 | 47.651 ±1.191 |
| sudoku | 34.202 ±3.593 | 35.190 ±2.689 | 80.109 ±5.250 | 91.061 ±3.470 | 4.443 ±0.553 |
| maze | 29.674 ±3.171 | 35.671 ±6.476 | 83.217 ±6.787 | 102.003 ±12.863 | 1.008 ±0.200 |
| vm | 47.000 ±11.470 | 33.314 ±3.748 | 89.181 ±5.252 | 95.932 ±5.617 | 1.063 ±0.226 |
| life | 38.299 ±4.953 | 41.146 ±2.408 | 90.422 ±3.818 | 94.602 ±3.491 | 19.338 ±1.290 |

## Supplement: Wasm entrypoint

| Example | Direct / V8 | C-Wasm / V8 | Direct / Wasmtime | C-Wasm / Wasmtime |
| --- | ---: | ---: | ---: | ---: |
| squares | 0.195 ±0.011 | 0.968 ±0.010 | 0.132 ±0.003 | 0.647 ±0.013 |
| tour | 14.307 ±0.579 | 3.728 ±0.985 | 1.772 ±0.010 | 1.755 ±0.034 |
| functions | 5.798 ±0.676 | 2.753 ±0.129 | 1.377 ±0.017 | 1.955 ±0.027 |
| errors | 1.639 ±0.117 | 1.880 ±0.152 | 0.867 ±0.013 | 1.718 ±0.015 |
| sieve | 2.009 ±0.051 | 3.416 ±1.480 | 1.169 ±0.016 | 1.375 ±0.022 |
| sorting | 22.755 ±1.747 | 207.974 ±1.957 | 15.538 ±0.270 | 130.653 ±3.888 |
| sudoku | 5.637 ±0.230 | 6.798 ±0.159 | 3.863 ±0.045 | 8.497 ±0.070 |
| maze | 2.411 ±0.115 | 2.016 ±0.107 | 0.784 ±0.006 | 2.290 ±0.036 |
| vm | 4.665 ±0.907 | 2.347 ±0.162 | 0.933 ±0.009 | 3.096 ±0.038 |
| life | 4.518 ±0.276 | 10.235 ±0.380 | 2.822 ±0.023 | 9.783 ±0.113 |

## Supplement: Wasm engine compilation and instantiation

| Example | Direct / V8 | C-Wasm / V8 | Direct / Wasmtime | C-Wasm / Wasmtime |
| --- | ---: | ---: | ---: | ---: |
| squares | 0.270 ±0.027 | 0.540 ±0.038 | 2.970 ±0.200 | 10.775 ±0.734 |
| tour | 0.556 ±0.085 | 0.658 ±0.074 | 32.769 ±2.208 | 34.579 ±3.297 |
| functions | 0.407 ±0.072 | 0.596 ±0.036 | 19.253 ±2.622 | 30.476 ±2.931 |
| errors | 0.377 ±0.048 | 0.712 ±0.045 | 12.269 ±0.915 | 16.234 ±2.533 |
| sieve | 0.333 ±0.053 | 0.684 ±0.097 | 6.370 ±0.239 | 11.215 ±0.635 |
| sorting | 0.393 ±0.039 | 0.671 ±0.113 | 20.926 ±5.075 | 32.650 ±1.566 |
| sudoku | 0.336 ±0.049 | 0.579 ±0.061 | 5.396 ±0.268 | 11.224 ±0.608 |
| maze | 0.389 ±0.062 | 0.603 ±0.068 | 14.288 ±1.915 | 16.681 ±1.900 |
| vm | 0.405 ±0.048 | 0.697 ±0.105 | 15.313 ±0.263 | 16.298 ±0.877 |
| life | 0.341 ±0.049 | 0.588 ±0.059 | 13.401 ±1.384 | 16.384 ±2.627 |

The entrypoint interval includes Goose initialization, host output callbacks and any lazy JIT work. It excludes final Wasm-host output concatenation/delivery. Native Goose prints unbuffered, so no native entrypoint column or cross-boundary speedup is presented. Process time minus engine time also includes loading, bookkeeping and teardown; it is not a pure startup measurement.

These fresh-process examples have different timing rules from LangArena's warmed computational regions. Raw samples, commands, artifact/source/compiler identities and engine versions are in [report.json](report.json). [Method and reproduction](../../../examples.md).
