#!/usr/bin/env python3
"""Prepare a diagnostic-only copy; building is a separate explicit command."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
source = (ROOT/'host/wasmtime.cpp').read_text()
original = source

def replace(old, new):
    global source
    assert source.count(old) == 1, (old, source.count(old))
    source = source.replace(old, new)

replace('template <auto Delete> struct Deleter {', r'''
// Diagnostic spans overlap where documented; no per-span heap allocations.
struct ProfileRecord { const char *name; uint64_t ns = 0, calls = 0; };
static ProfileRecord profile_records[64]{};
static size_t profile_count = 0;
static const char *profile_path = nullptr;
static uint64_t profile_now() {
    return std::chrono::duration_cast<std::chrono::nanoseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count();
}
struct ProfilePhase {
    const char *name;
    uint64_t start = 0;
    explicit ProfilePhase(const char *value) : name(value) {
        if (profile_path && name) start = profile_now();
    }
    void finish() {
        if (!start) return;
        auto elapsed = profile_now() - start;
        for (size_t i = 0; i < profile_count; ++i) {
            if (std::strcmp(profile_records[i].name, name)) continue;
            profile_records[i].ns += elapsed; ++profile_records[i].calls; start = 0; return;
        }
        if (profile_count >= 64) std::abort();
        profile_records[profile_count++] = {name, elapsed, 1}; start = 0;
    }
    ~ProfilePhase() { finish(); }
};
template <auto Delete> struct Deleter {''')
replace('#include <utility>', '#include <utility>\n#include <type_traits>')
replace('template <class T> void operator()(T *value) const { Delete(value); }', '''template <class T> void operator()(T *value) const {
        const char *name = nullptr;
        if constexpr (std::is_same_v<T, wasm_engine_t>) name = "delete_engine";
        if constexpr (std::is_same_v<T, wasmtime_store_t>) name = "delete_store";
        if constexpr (std::is_same_v<T, wasmtime_module_t>) name = "delete_module";
        if constexpr (std::is_same_v<T, wasmtime_linker_t>) name = "delete_linker";
        ProfilePhase phase(name); Delete(value);
    }''')
replace('    Owned<wasm_config_t, wasm_config_delete> config(wasm_config_new());', '    ProfilePhase configuration("config_create_set");\n    Owned<wasm_config_t, wasm_config_delete> config(wasm_config_new());')
replace('    Owned<wasm_engine_t, wasm_engine_delete> engine(wasm_engine_new_with_config(config.release()));', '    configuration.finish();\n    ProfilePhase engine_creation("engine_new");\n    Owned<wasm_engine_t, wasm_engine_delete> engine(wasm_engine_new_with_config(config.release()));')
replace('    string data;\n    if (!options.precompiled) data = read_file(options.module);', '    ProfilePhase total_run("run_including_teardown");\n    string data;\n    if (!options.precompiled) { ProfilePhase phase("wasm_file_read"); data = read_file(options.module); }')
replace('    Owned<wasmtime_store_t, wasmtime_store_delete> store(wasmtime_store_new(engine, &state, nullptr));', '    ProfilePhase store_creation("store_new");\n    Owned<wasmtime_store_t, wasmtime_store_delete> store(wasmtime_store_new(engine, &state, nullptr));')
replace('    auto context = wasmtime_store_context(store.get());', '    auto context = wasmtime_store_context(store.get());\n    store_creation.finish();')
replace('            if (options.precompiled) error = wasmtime_module_deserialize_file(engine, options.module.c_str(), &raw);\n            else error = wasmtime_module_new(engine, reinterpret_cast<const uint8_t *>(data.data()), data.size(), &raw);', '''            {
                const char *phase_name = "compile_wasm";
                if (options.precompiled) phase_name = "deserialize_aot_file";
                ProfilePhase phase(phase_name);
                if (options.precompiled) error = wasmtime_module_deserialize_file(engine, options.module.c_str(), &raw);
                else error = wasmtime_module_new(engine, reinterpret_cast<const uint8_t *>(data.data()), data.size(), &raw);
            }''')
replace('            Owned<wasmtime_linker_t, wasmtime_linker_delete> linker(wasmtime_linker_new(engine));', '            ProfilePhase linker_phase("linker_create_imports");\n            Owned<wasmtime_linker_t, wasmtime_linker_delete> linker(wasmtime_linker_new(engine));')
replace('        auto error = wasmtime_linker_instantiate(module->linker.get(), context, module->module.get(), &instance, &trap);\n        check(error, trap);\n        External limits;', '        ProfilePhase instantiate_phase("instantiate");\n        auto error = wasmtime_linker_instantiate(module->linker.get(), context, module->module.get(), &instance, &trap);\n        check(error, trap);\n        instantiate_phase.finish();\n        ProfilePhase stack_phase("stack_setup_exports");\n        External limits;')
replace('        if (timed) instantiated = monotonic_ns();\n        entered = true;\n        call(context, instance, "_start");', '        stack_phase.finish();\n        if (timed) instantiated = monotonic_ns();\n        entered = true;\n        ProfilePhase start_phase("start_with_buffered_callbacks");\n        call(context, instance, "_start");')
replace('    auto state_pointer = static_cast<State *>(wasmtime_context_get_data(wasmtime_caller_context(caller)));', '    ProfilePhase callback_phase("host_callbacks_inside_start");\n    auto state_pointer = static_cast<State *>(wasmtime_context_get_data(wasmtime_caller_context(caller)));')
replace('int main(int argc, char **argv) {\n    State state;', '''struct ProfiledState {
    ProfilePhase cleanup{nullptr};
    State value;
    ~ProfiledState() {
        cleanup.name = "state_cleanup";
        if (profile_path) cleanup.start = profile_now();
    }
};
static int profiled_main(int argc, char **argv) {
    ProfiledState state_owner;
    State &state = state_owner.value;
    ProfilePhase cli("cli_parse_validate");''')
replace('        if (options.compiled.empty()) state.input = read_all(stdin);\n        code = run(options, state);', '        cli.finish();\n        if (options.compiled.empty()) { ProfilePhase phase("stdin_read"); state.input = read_all(stdin); }\n        code = run(options, state);')
replace('    if (!state.output.empty() && std::fwrite(state.output.data(), 1, state.output.size(), stdout) != state.output.size()) code = 1;', '    ProfilePhase output_phase("output_write_errors_flush");\n    if (!state.output.empty() && std::fwrite(state.output.data(), 1, state.output.size(), stdout) != state.output.size()) code = 1;')
replace('    if (std::fflush(stderr)) code = 1;\n    return code;\n}', '''    if (std::fflush(stderr)) code = 1;
    output_phase.finish();
    return code;
}
int main(int argc, char **argv) {
    uint64_t entry = profile_now();
    profile_path = std::getenv("GOOSE_FRESH_PHASE_PROFILE");
    int code = profiled_main(argc, argv);
    uint64_t ended = profile_now();
    if (profile_path) {
        FILE *file = std::fopen(profile_path, "w");
        if (!file) return 125;
        std::fprintf(file, "{\\"main_entry_ns\\":%llu,\\"main_exit_ns\\":%llu,\\"main_ns\\":%llu,\\"phases\\":{",
            (unsigned long long)entry, (unsigned long long)ended, (unsigned long long)(ended-entry));
        for (size_t i = 0; i < profile_count; ++i) {
            if (i) std::fputc(',', file);
            auto &record = profile_records[i];
            std::fprintf(file, "\\"%s\\":{\\"ns\\":%llu,\\"calls\\":%llu}", record.name,
                (unsigned long long)record.ns, (unsigned long long)record.calls);
        }
        std::fputs("}}\\n", file);
        if (std::fclose(file)) return 125;
    }
    return code;
}''')
(OUT/'wasmtime-profile.cpp').write_text(source)
metadata = json.loads((ROOT/'build/bin/goose-wasmtime.json').read_text())
command = metadata['command'][:]
command[command.index(str(ROOT/'host/wasmtime.cpp'))] = str(OUT/'wasmtime-profile.cpp')
command[command.index('-o')+1] = str(OUT/'goose-wasmtime-profile')
manifest = {
    'purpose':'Diagnostic copy only. Primary benchmark uses unchanged host and native artifacts.',
    'original_source_sha256':hashlib.sha256(original.encode()).hexdigest(),
    'instrumented_source_sha256':hashlib.sha256(source.encode()).hexdigest(),
    'original_command':metadata['command'], 'command':command,
    'host_metadata':metadata,
    'method':'CLOCK_MONOTONIC / steady_clock nanosecond spans. Main excludes profile file write. run includes Wasmtime destructors. Host callback span is nested inside start. Overall main includes timestamp overhead; never treat diagnostic timings as primary benchmark rows.',
}
(OUT/'build-command.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(OUT/'build-command.json')
