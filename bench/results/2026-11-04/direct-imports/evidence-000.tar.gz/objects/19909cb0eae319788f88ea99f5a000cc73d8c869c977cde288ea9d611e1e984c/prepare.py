#!/usr/bin/env python3
"""Adapt the earlier span machinery to the current minimal direct-binding source."""
import ast,hashlib,json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[4];OUT=Path(__file__).resolve().parent
old_tool=ROOT/'build/functions-native-hills/profile-tools/prepare.py'
source_path=ROOT/'host/wasmtime.cpp';original=source_path.read_text();source=original
manifest_path=OUT.parent/'pilot/goose-wasmtime-aot.json';manifest_raw=manifest_path.read_bytes();metadata=json.loads(manifest_raw)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert metadata['runtime_only'] and metadata['input_sha256'][str(source_path)]==digest(source_path)
def replace(old,new):
    global source
    assert source.count(old)==1,(old,source.count(old))
    source=source.replace(old,new)
# Reuse only instrumentation machinery and main/state/I/O wrappers. Old full-host
# linker/compilation replacements are deliberately excluded from this profile.
skip_prefixes=[
'    Owned<wasm_config_t, wasm_config_delete> config(',
'    Owned<wasm_engine_t, wasm_engine_delete> engine(',
'            if (options.precompiled) error = ',
'            Owned<wasmtime_linker_t, wasmtime_linker_delete> linker(',
'        auto error = wasmtime_linker_instantiate(',
'        if (timed) instantiated = monotonic_ns();',
]
for node in ast.parse(old_tool.read_text()).body:
    if not isinstance(node,ast.Expr) or not isinstance(node.value,ast.Call):continue
    call=node.value
    if not isinstance(call.func,ast.Name) or call.func.id!='replace':continue
    old,new=[ast.literal_eval(arg)for arg in call.args]
    if any(old.startswith(prefix)for prefix in skip_prefixes):continue
    new=new.replace('host_callbacks_inside_start','host_callbacks_nested')
    replace(old,new)
replace('    Owned<wasm_config_t, wasm_config_delete> config(wasm_config_new());', '''    ProfilePhase config_create("config_new");
    Owned<wasm_config_t, wasm_config_delete> config(wasm_config_new());
    config_create.finish();
    ProfilePhase config_settings("config_set");''')
replace('    Owned<wasm_engine_t, wasm_engine_delete> engine(wasm_engine_new_with_config(config.release()));', '''    config_settings.finish();
    ProfilePhase engine_creation("engine_new");
    Owned<wasm_engine_t, wasm_engine_delete> engine(wasm_engine_new_with_config(config.release()));''')
replace('            if (options.precompiled) error = wasmtime_module_deserialize_file(engine, options.module.c_str(), &raw);', '''            if (options.precompiled) {
                ProfilePhase phase("deserialize_aot_file");
                error = wasmtime_module_deserialize_file(engine, options.module.c_str(), &raw);
            }''')
replace('static void instantiate(wasmtime_context_t *context, const wasmtime_module_t *module, wasmtime_instance_t &instance) {', '''static void instantiate(wasmtime_context_t *context, const wasmtime_module_t *module, wasmtime_instance_t &instance) {
    ProfilePhase direct_total("direct_bind_instantiate_cleanup");
    ProfilePhase import_binding("import_scan_validate_create_funcs");''')
replace('        wasmtime_func_new(context, type, callback, const_cast<Spec *>(found), nullptr, &bound[index].of.func);', '''        ProfilePhase create_func("func_new_inside_imports");
        wasmtime_func_new(context, type, callback, const_cast<Spec *>(found), nullptr, &bound[index].of.func);''')
replace('    auto error = wasmtime_instance_new(context, module, bound.data(), bound.size(), &instance, &trap);', '''    import_binding.finish();
    ProfilePhase instance_creation("instance_new_including_wasm_start");
    auto error = wasmtime_instance_new(context, module, bound.data(), bound.size(), &instance, &trap);''')
replace('#endif\n        External limits;', '#endif\n        ProfilePhase stack_phase("stack_setup_exports");\n        External limits;')
replace('        if (timed) instantiated = monotonic_ns();\n        entered = true;\n        call(context, instance, "_start");', '''        stack_phase.finish();
        if (timed) instantiated = monotonic_ns();
        entered = true;
        ProfilePhase start_phase("start_with_buffered_callbacks");
        call(context, instance, "_start");''')
instrumented=OUT/'wasmtime-profile.cpp';instrumented.write_text(source)
binary=OUT/'goose-wasmtime-profile';command=metadata['command'][:]
command[command.index(str(source_path))]=str(instrumented);command[command.index('-o')+1]=str(binary)
subprocess.run(command,cwd=ROOT,check=True)
profile_manifest={
'schema':'goose-current-minimal-host-profile-build-v1','purpose':'Diagnostic-only current minimal direct-binding host; no primary benchmark row.',
'original_source':str(source_path),'original_source_sha256':digest(source_path),
'instrumented_source_sha256':digest(instrumented),'host_sha256':digest(binary),
'command':command,'input_sha256':{str(p):digest(p)for p in [source_path,instrumented,Path(__file__).resolve(),old_tool,manifest_path,Path(metadata['library'])]},
'original_minimal_manifest_sha256':hashlib.sha256(manifest_raw).hexdigest(),'original_minimal_manifest':metadata,
'method':'steady_clock nanosecond spans. Main ends before profile file output. Callback spans nest inside _start or Wasm module start; func_new nests inside imports; imports/instance_new nest inside direct-bind; delete phases nest inside run; run and I/O nest inside main. Timings include instrumentation overhead and cannot support primary speed claims.',
}
(OUT/'build-command.json').write_text(json.dumps(profile_manifest,indent=2)+'\n')
print('Built one current-minimal instrumented diagnostic host.')
