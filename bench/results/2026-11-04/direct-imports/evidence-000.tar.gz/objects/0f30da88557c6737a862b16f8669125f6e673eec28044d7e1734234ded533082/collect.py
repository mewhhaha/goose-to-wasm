#!/usr/bin/env python3
"""31 diagnostic launches per current minimal-host fixture, one aggregate JSON."""
from pathlib import Path
import hashlib,json,os,random,statistics,subprocess,time
ROOT=Path(__file__).resolve().parents[4];OUT=Path(__file__).resolve().parent
fixtures_path=OUT.parent/'fixture-config.json';fixtures=json.loads(fixtures_path.read_text());build_path=OUT/'build-command.json';build=json.loads(build_path.read_text());binary=OUT/'goose-wasmtime-profile';scratch=OUT/'phase-scratch.json'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def summary(values):
    values=sorted(values)
    return {'n':len(values),'median':statistics.median(values),'min':values[0],'max':values[-1],'p10':values[int((len(values)-1)*.1)],'p90':values[int((len(values)-1)*.9)]}
paths=[Path(__file__).resolve(),OUT/'prepare.py',OUT/'wasmtime-profile.cpp',binary,build_path,fixtures_path,ROOT/'host/wasmtime.cpp',ROOT/'toolchain.json']
paths.extend(Path(case['original_aot'])for case in fixtures['cases'].values())
identities={str(p):digest(p)for p in paths}
assert digest(binary)==build['host_sha256']
assert digest(ROOT/'host/wasmtime.cpp')==build['original_source_sha256']
report={'schema':'goose-current-minimal-diagnostic-profile-v1','status':'running','repetitions_per_case':31,'primary_timing_rows':False,
'host_mode':'RUNTIME_ONLY minimal trusted-AOT, current direct import binding, default memory COW','cpu_affinity':sorted(os.sched_getaffinity(0)),
'method':'31 fresh-process diagnostic launches for each of four existing/matched fixtures. Case order shuffled each iteration with seed 202611047. stdout/exit/stderr checked exactly. One scratch JSON replaced on each run; all profiles preserved in this report. Warm filesystem state from preparation/correctness, no cache eviction/normalization. Ordinary inherited pool affinity. No native/reference or primary-host timings collected. Main excludes writing its profile; parent-after-main includes profile I/O. Nested chrono spans include their own instrumentation overhead; do not add overlapping spans or interpret differences of medians causally.',
'build':build,'fixture_config':fixtures,'input_sha256':identities,'runs':[],'clock':'C++ steady_clock and Python perf_counter_ns, Linux monotonic nanoseconds'}
rng=random.Random(202611047)
try:
    for iteration in range(31):
        cases=list(fixtures['cases']);rng.shuffle(cases)
        for name in cases:
            case=fixtures['cases'][name];command=[str(binary),'--precompiled',case['original_aot']]
            env=os.environ.copy()
            for key in ['GOOSE_FRESH_PHASE_PROFILE','GOOSE_NATIVE_MAIN_TIMING','LD_PRELOAD']:env.pop(key,None)
            env['GOOSE_FRESH_PHASE_PROFILE']=str(scratch)
            scratch.unlink(missing_ok=True)
            begin=time.perf_counter_ns();result=subprocess.run(command,input=b'',capture_output=True,env=env,timeout=30,cwd=ROOT);end=time.perf_counter_ns()
            assert result.returncode==0 and result.stdout==bytes.fromhex(case['expected_stdout_hex']) and not result.stderr,(name,result)
            profile=json.loads(scratch.read_text())
            assert profile['main_ns']==profile['main_exit_ns']-profile['main_entry_ns']
            report['runs'].append({'iteration':iteration,'case':name,'command':command,'returncode':result.returncode,'stdout_sha256':hashlib.sha256(result.stdout).hexdigest(),'stdout_matches':True,'stderr':'','parent_launch_ns':begin,'parent_return_ns':end,'diagnostic_wall_ns':end-begin,'parent_launch_to_main_ns':profile['main_entry_ns']-begin,'main_end_to_parent_return_ns':end-profile['main_exit_ns'],'profile':profile})
    after={str(p):digest(p)for p in paths};assert after==identities,'profile inputs changed during collection'
    report['input_sha256_after']=after;report['summary_ns']={}
    for name in fixtures['cases']:
        rows=[r for r in report['runs']if r['case']==name];values={}
        for row in rows:
            for field in ['diagnostic_wall_ns','parent_launch_to_main_ns','main_end_to_parent_return_ns']:values.setdefault(field,[]).append(row[field])
            values.setdefault('main_ns',[]).append(row['profile']['main_ns'])
            for phase,value in row['profile']['phases'].items():
                values.setdefault(phase+'_ns',[]).append(value['ns']);values.setdefault(phase+'_calls',[]).append(value['calls'])
        report['summary_ns'][name]={field:summary(samples)for field,samples in values.items()}
    report['status']='passed'
finally:
    (OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
for name,values in report['summary_ns'].items():
    print(name,json.dumps({field:round(value['median']/1000,3)for field,value in values.items()if field.endswith('_ns')},sort_keys=True))
