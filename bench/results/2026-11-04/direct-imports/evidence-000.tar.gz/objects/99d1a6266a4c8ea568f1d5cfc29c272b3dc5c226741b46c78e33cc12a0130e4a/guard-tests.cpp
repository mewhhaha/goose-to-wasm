#define main goose_raw_host_main
#include "wasmtime.raw-callback.cpp"
#undef main
static void require(bool condition) { if (!condition) fail("raw wrapper guard test failed"); }
static void expect_trap(wasm_trap_t *raw, string_view expected) {
    require(raw != nullptr);
    Owned<wasm_trap_t, wasm_trap_delete> trap(raw);
    Bytes text; wasm_trap_message(trap.get(), &text.value);
    require(string_view(text.value.data, text.value.size).find(expected) != string_view::npos);
}
int main() {
    try {
        for (const auto &spec : imports) require(raw_eligible(spec));
        Spec too_many{"test", "too_many", "iiiii", "", Op::Growth};
        Spec too_many_results{"test", "too_many_results", "", "ii", Op::Growth};
        Spec reference{"test", "reference", "r", "", Op::Growth};
        require(!raw_eligible(too_many) && !raw_eligible(too_many_results) && !raw_eligible(reference));
        expect_trap(raw_callback(&too_many, nullptr, nullptr, 0), "capacity");
        Spec short_buffer{"test", "short_buffer", "i", "", Op::Growth};
        expect_trap(raw_callback(&short_buffer, nullptr, nullptr, 0), "capacity");
        wasmtime_val_raw_t value{};
        expect_trap(raw_callback(&reference, nullptr, &value, 1), "type");
        for (uint64_t bits : {uint64_t(0), uint64_t(0x8000000000000000), uint64_t(0x7ff0000000000000), uint64_t(0x7ff8123456789abc), UINT64_MAX}) {
            wasmtime_val_raw_t input{}, output{}; wasmtime_val_t typed{};
            std::memcpy(&input.f64, &bits, sizeof bits);
            copy_scalar(WASMTIME_F64, typed.of, input); copy_scalar(WASMTIME_F64, output, typed.of);
            require(std::memcmp(&input.f64, &output.f64, sizeof bits) == 0);
        }
        for (uint32_t bits : {uint32_t(0), uint32_t(0x80000000), uint32_t(0x7f800000), uint32_t(0x7fc12345), UINT32_MAX}) {
            wasmtime_val_raw_t input{}, output{}; wasmtime_val_t typed{};
            std::memcpy(&input.f32, &bits, sizeof bits);
            copy_scalar(WASMTIME_F32, typed.of, input); copy_scalar(WASMTIME_F32, output, typed.of);
            require(std::memcmp(&input.f32, &output.f32, sizeof bits) == 0);
        }
        Options options; bool cache = false; auto engine = make_engine(options, cache);
        State state; state.input = "5";
        Owned<wasmtime_store_t, wasmtime_store_delete> store(wasmtime_store_new(engine.get(), &state, nullptr));
        auto context = wasmtime_store_context(store.get());
        Owned<wasm_functype_t, wasm_functype_delete> type(wasm_functype_new_0_1(wasm_valtype_new_i32()));
        Spec wrong_result{"test", "wrong_result", "", "i", Op::Input};
        wasmtime_func_t function; wasmtime_func_new_unchecked(context, type.get(), raw_callback, &wrong_result, nullptr, &function);
        wasm_trap_t *trap = nullptr; wasmtime_val_t result{};
        auto error = wasmtime_func_call(context, &function, nullptr, 0, &result, 1, &trap);
        bool rejected = false;
        try { check(error, trap); } catch (const HostError &failure) {
            rejected = failure.message.find("invalid raw host callback result") != string::npos;
        }
        require(rejected);
        Spec early_exit{"test", "early_exit", "", "i", Op::Exit};
        wasmtime_func_new_unchecked(context, type.get(), raw_callback, &early_exit, nullptr, &function);
        trap = nullptr; error = wasmtime_func_call(context, &function, nullptr, 0, &result, 1, &trap);
        bool exited = false;
        try { check(error, trap); } catch (const HostError &failure) {
            exited = failure.message.find("program exit") != string::npos && failure.message.find("raw host callback result") == string::npos;
        }
        require(exited && state.exited);
        std::puts("Raw signature fallback, capacity/type/result guards, immediate traps, and exact floating bits passed.");
        return 0;
    } catch (const std::exception &error) { std::fprintf(stderr, "%s\n", error.what()); return 1; }
}
