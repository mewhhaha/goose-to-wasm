#!/usr/bin/env python3
"""Collect final process cohorts sequentially after correctness qualification."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
BUILD = ROOT / 'build/remaining-hills'
OUTPUT = BUILD / 'delivery-execution'
CURRENT = BUILD / 'current'
COMPILER = ROOT / 'build/next-runtime-hills/final/bin/goose'
FULL = ROOT / 'build/bin/goose-wasmtime'
MINIMAL = ROOT / 'build/bin/goose-wasmtime-aot'
EXPECTED_COMPILER = '8c09c1a6bcc782de5b86dda621a91ae234acba8fbe108d146582113eb6a110b6'


def digest(path):
    with Path(path).open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def utc():
    return datetime.now(timezone.utc).isoformat()


def save(value):
    temporary = OUTPUT / 'report.tmp'
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(OUTPUT / 'report.json')


def main():
    OUTPUT.mkdir(parents=True, exist_ok=False)
    qualification_path = BUILD / 'qualification/report.json'
    qualification = json.loads(qualification_path.read_bytes())
    if qualification['status'] != 'passed':
        raise ValueError('correctness qualification has not passed')
    if digest(COMPILER) != EXPECTED_COMPILER:
        raise ValueError('compiler changed')
    controls = {name: os.environ.get(name) for name in
                ['RAYON_NUM_THREADS', 'OMP_NUM_THREADS', 'BINARYEN_CORES', 'LD_PRELOAD',
                 'LD_LIBRARY_PATH', 'NODE_OPTIONS', 'GOOSE_STDLIB']}
    if any(value is not None for value in controls.values()):
        raise ValueError('runtime controls must be unset')
    pins = {}
    sources = [Path(__file__), qualification_path, COMPILER, FULL, MINIMAL,
               FULL.with_suffix('.json'), MINIMAL.with_suffix('.json'),
               ROOT / 'host/wasmtime.cpp', ROOT / 'scripts/build_wasmtime_host.py',
               ROOT / 'toolchain.json', ROOT / 'examples/manifest.json']
    sources += [ROOT / 'bench' / name for name in
                ['process.py', 'benchmark.py', 'examples.py', 'wasmtime_host.py', 'runtime_lifecycle.py']]
    sources += list((ROOT / 'examples').glob('*.goose'))
    sources += list((ROOT / 'examples/expected').glob('*.out'))
    pins.update((str(path), digest(path)) for path in sources)
    py = sys.executable
    commands = [
        ('examples', [py, ROOT / 'bench/examples.py', '--goose', COMPILER,
                      '--compile-samples', '5', '--samples', '15', '--warmups', '1',
                      '--machine-label', 'AMD Ryzen 7 3800X, shared host',
                      '--output-dir', CURRENT / 'examples'], CURRENT / 'examples/report.json', 1600),
        ('host', [py, ROOT / 'bench/wasmtime_host.py', '--host', FULL, '--aot-host', MINIMAL,
                  '--example-report', CURRENT / 'examples/report.json', '--samples', '15',
                  '--prepare-samples', '5', '--warmups', '1',
                  '--machine-label', 'AMD Ryzen 7 3800X, shared host',
                  '--output-dir', CURRENT / 'host'], CURRENT / 'host/report.json', 1760),
        ('lifecycle', [py, ROOT / 'bench/runtime_lifecycle.py',
                       '--example-report', CURRENT / 'examples/report.json', '--host', FULL,
                       '--samples', '15', '--warmups', '1',
                       '--machine-label', 'AMD Ryzen 7 3800X, shared host',
                       '--output-dir', CURRENT / 'lifecycle'], CURRENT / 'lifecycle/report.json', 960),
    ]
    for _, command, path, _ in commands:
        if path.exists():
            raise ValueError('preserve previous result: ' + str(path))
        pins[str(command[1])] = digest(command[1])
    report = {'schema': 'goose-direct-imports-delivery-execution-v1', 'status': 'running',
              'started_utc': utc(), 'compiler_sha256': EXPECTED_COMPILER,
              'environment': {'controls': controls, 'cpu_affinity': sorted(os.sched_getaffinity(0))},
              'input_sha256': pins, 'phases': [],
              'method': 'Sequential complete process cohorts after qualification. No builds, tests, rendering, '
                        'archiving or unrelated hash scans overlap timing. Warmed language kernel charts remain '
                        'separately collected unchanged-compiler references.'}
    save(report)
    try:
        for name, command, path, count in commands:
            command = list(map(str, command))
            row = {'name': name, 'command': command, 'report': str(path), 'started_utc': utc()}
            report['phases'].append(row)
            save(report)
            started = time.monotonic()
            with (OUTPUT / (name + '.log')).open('wb') as log:
                result = subprocess.run(command, cwd=ROOT, stdin=subprocess.DEVNULL,
                                        stdout=log, stderr=subprocess.STDOUT)
            row.update(exit_status=result.returncode, wall_seconds=time.monotonic() - started,
                       finished_utc=utc())
            if result.returncode:
                raise ValueError(name + ' exited ' + str(result.returncode))
            child = json.loads(path.read_bytes())
            if child['status'] != 'passed' or len(child['observations']) != count:
                raise ValueError(name + ' status or coverage differs')
            if name == 'host' and len(child['preparation']) != 300:
                raise ValueError('host preparation coverage differs')
            row.update(report_sha256=digest(path), observations=count)
            save(report)
            print('PASS', name, count, flush=True)
        after = {path: digest(path) for path in pins}
        if after != pins:
            raise ValueError('delivered input changed')
        if controls != {name: os.environ.get(name) for name in controls}:
            raise ValueError('runtime controls changed')
        report.update(status='passed', input_sha256_after=after, finished_utc=utc())
    except BaseException as error:
        report.update(status='failed', error=type(error).__name__ + ': ' + str(error), finished_utc=utc())
        save(report)
        raise
    save(report)
    (OUTPUT / 'completion.json').write_text(json.dumps({'status': 'passed', 'report_sha256': digest(OUTPUT / 'report.json'),
                                                      'finished_utc': utc()}, indent=2) + '\n')


if __name__ == '__main__':
    main()
