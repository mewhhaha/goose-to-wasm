"""Independent paired-endpoint arithmetic; read reports, never run a guest."""
import sys
sys.dont_write_bytecode = True
from pathlib import Path
import hashlib
import itertools
import json
import math
import random
import statistics

ROOT = Path(__file__).resolve().parents[3]
BUILD = ROOT / 'build/remaining-hills'
OUT = Path(__file__).with_name('final-endpoint-assessment.json')


def identity(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def close(a, b):
    assert math.isfinite(a) and math.isclose(a, b, rel_tol=1e-12, abs_tol=1e-15), (a, b)


def describe(values):
    median = statistics.median(values)
    return {'n': len(values), 'median': median,
            'mad': statistics.median(abs(value - median) for value in values)}


def check(name, samples, names, selected):
    path = BUILD / 'final-pairs' / name / 'report.json'
    report = json.loads(path.read_bytes())
    config = report['configuration']
    assert report['status'] == 'passed'
    assert report['input_sha256'] == report['input_sha256_after']
    assert config['samples'] == samples and config['warmups'] == 2
    assert config['affinities'] == ['pool', 'cpu2']
    cells = {workload + '_' + variant for workload in names
             for variant in ['baseline', 'aa', 'direct', 'final', 'native']}
    assert set(config['cells']) == cells
    rows = {(row['affinity'], row['cell'], row['phase'], row['sample']): row
            for row in report['observations']}
    expected = {(affinity, cell, phase, sample)
                for affinity in config['affinities'] for cell in cells
                for phase, count in [('warmup', 2), ('measure', samples)] for sample in range(count)}
    assert len(rows) == len(report['observations']) and set(rows) == expected
    for cell, definition in config['cells'].items():
        golden_path = Path(definition['expected'])
        assert identity(golden_path) == report['input_sha256'][str(golden_path)]
        golden = golden_path.read_text()
        for key, row in rows.items():
            if key[1] == cell:
                assert row['exit_code'] == 0 and row['stderr'] == '' and row['stdout'] == golden
                assert isinstance(row['wall_ns'], int) and row['wall_ns'] > 0
        if cell.endswith('_final'):
            assert report['input_sha256'][definition['executable']] == '51873433f6bf52b64462b21cc8e8fb5eecb85c3acdf87d9accbdccb58128f1bf'
    comparisons = set(map(tuple, config['comparisons']))
    expected_comparisons = {(workload + '_final', workload + '_' + other)
                            for workload in names for other in ['baseline', 'native', 'direct']}
    expected_comparisons.update((workload + '_aa', workload + '_baseline') for workload in names)
    assert len(comparisons) == len(config['comparisons']) and comparisons == expected_comparisons
    output = {'report': str(path), 'report_sha256': identity(path), 'rows': len(rows),
              'measured_rows': len(cells) * samples * 2, 'sample_count_per_cell': samples,
              'outcomes_and_exact_matrix': 'passed', 'affinities': {}}
    for affinity in config['affinities']:
        group = report['summary'][affinity]
        vectors = {cell: [rows[affinity, cell, 'measure', sample]['wall_ns'] for sample in range(samples)]
                   for cell in cells}
        assert set(group['wall_us']) == cells
        assert set(group['paired_ratios']) == {a + '/' + b for a, b in comparisons}
        for cell, values in vectors.items():
            observed = describe([value / 1000 for value in values])
            for field, value in observed.items():
                close(group['wall_us'][cell][field], value)
        checked = {}
        for numerator, denominator in comparisons:
            key = numerator + '/' + denominator
            values = [a / b for a, b in zip(vectors[numerator], vectors[denominator])]
            observed = describe(values)
            for field, value in observed.items():
                close(group['paired_ratios'][key][field], value)
            if numerator not in selected:
                continue
            rng = random.Random(config['seed'])
            boot = sorted(statistics.median(rng.choices(values, k=samples)) for _ in range(10000))
            observed['bootstrap_95_ci'] = [boot[249], boot[9749]]
            assert len(group['paired_ratios'][key]['bootstrap_95_ci']) == 2
            for actual, recomputed in zip(group['paired_ratios'][key]['bootstrap_95_ci'], observed['bootstrap_95_ci']):
                close(actual, recomputed)
            checked[key] = observed
        output['affinities'][affinity] = checked
    return output


names = ['squares', 'tour', 'functions', 'errors', 'sieve', 'sorting', 'sudoku', 'maze', 'vm', 'life']
reports = [check('functions', 201, ['functions'], {'functions_final', 'functions_aa'}),
           check('regression', 31, names, {'vm_final'}),
           check('vm-confirmation', 201, ['vm'], {'vm_final', 'vm_aa'})]
result = {
    'schema': 'goose-independent-final-endpoints-v1', 'status': 'passed',
    'script': str(Path(__file__).resolve()), 'script_sha256': identity(Path(__file__)),
    'reports': reports,
    'decision': 'KEEP the final minimal-host change as a small measured improvement; do not claim native equivalence.',
    'interpretation': [
        'The final Functions endpoint uses201 paired samples per cell and affinity. Its normal-pool final/baseline confidence interval lies below1, while A/A includes1.',
        'Functions remains about16% above the selected native process in the primary paired cohort; the CPU2 diagnostic has a larger remaining gap.',
        'The original31-pair VM screen and the targeted201-pair follow-up are both retained. The follow-up does not reproduce the screen slowdown; it does not erase that observation or become a new general all-ten headline.',
        'The compiler and unchanged benchmark program/input are held fixed. This is a runtime-host comparison, not a compiler throughput gain.',
        'Ratios are medians of paired elapsed-time ratios. Ratios of separately reported medians are not substituted, including when shared-host load skews marginal medians.',
        'This review checks raw paired arithmetic, exact matrices, successful outputs and declared final-host input pins. Byte/archive closure, broad-cohort semantics, docs/charts and source identity verification are separate final-delivery checks.'
    ]
}
OUT.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps({'status': result['status'], 'output': str(OUT),
                  'reports': [{'rows': item['rows'], 'report': item['report']} for item in reports]}, indent=2))
