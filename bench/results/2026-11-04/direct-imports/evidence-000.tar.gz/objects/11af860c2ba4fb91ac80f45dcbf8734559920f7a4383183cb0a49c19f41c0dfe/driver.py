"""Fresh host qualification with a byte-verified unchanged compiler reference."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
BASELINE = ROOT / 'build/next-runtime-hills/qualification/attempt-1/differential'
COMPILER_SHA = '8c09c1a6bcc782de5b86dda621a91ae234acba8fbe108d146582113eb6a110b6'
sys.path.insert(0, str(ROOT / 'bench'))
import qualify_wasmtime_host as canonical


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    with Path(path).open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def save(report):
    temporary = OUT / 'report.tmp'
    temporary.write_text(json.dumps(report, indent=2) + '\n')
    temporary.replace(OUT / 'report.json')


def run(report, name, command, tests=None):
    command = list(map(str, command))
    row = {'name': name, 'command': command, 'started_utc': now()}
    report['commands'].append(row)
    report['active'] = name
    save(report)
    started = time.monotonic()
    log_path = OUT / (name + '.log')
    with log_path.open('wb') as log:
        process = subprocess.run(command, cwd=ROOT, stdin=subprocess.DEVNULL,
                                 stdout=log, stderr=subprocess.STDOUT, timeout=1800)
    row.update(exit_status=process.returncode, finished_utc=now(),
               wall_seconds_correctness_only=time.monotonic() - started,
               log=str(log_path), log_sha256=digest(log_path))
    if tests is not None:
        matches = re.findall(r'Ran (\d+) tests?', log_path.read_text(errors='replace'))
        count = None
        if matches:
            count = int(matches[-1])
        row.update(expected_tests=tests, observed_tests=count, coverage_exact=count == tests)
    save(report)
    if process.returncode:
        raise ValueError(name + ' failed with exit ' + str(process.returncode))
    if tests is not None and row['observed_tests'] != tests:
        raise ValueError(name + ' test count differs')
    print('PASS', name, flush=True)


def validate(path, count, modes):
    value = json.loads(path.read_bytes())
    assert value['status'] == 'pass', value.get('error')
    assert value['coverage_exact'] and value['failures'] == 0
    assert value['observations'] == value['expected_observations'] == len(value['results']) == count
    assert set(value['configuration']['modes']) == set(modes)
    assert value['configuration']['filter'] == ''
    assert value['input_sha256'] == value['input_sha256_after']
    assert value['aot_sha256'] == value['aot_sha256_after']
    assert all(row['status'] == 'pass' and all(row['comparisons'].values()) for row in value['results'])
    logs = value['command_logs']
    assert logs['complete'] and logs['closed'] and not logs['error']
    assert digest(logs['path']) == logs['sha256']
    return {'status': 'pass', 'report': str(path), 'report_sha256': digest(path),
            'observations': count, 'cases': value['cases'], 'unique_aot': len(value['aot_sha256']),
            'backends': value['configuration']['backends'], 'modes': modes,
            'coverage_exact': True, 'command_logs': logs}


def main():
    report = {'schema': 'goose-direct-imports-qualification-v1', 'status': 'running',
              'started_utc': now(), 'pid': os.getpid(), 'active': 'preflight', 'commands': [],
              'compiler_sha256': COMPILER_SHA,
              'method': 'Correctness only. Prior unchanged-compiler9573 rows and1487 input pins are byte-verified; '
                        'fresh general-host11484 and minimal direct1914 replays. No case filters or waivers. '
                        'Compile refusals remain separately collected compiler reference observations; '
                        'C-Wasm EH requires the full host. Compact logs preserve raw logical file bytes.'}
    save(report)
    try:
        view = canonical.baseline_report(OUT / 'baseline-report.json', BASELINE)
        canonical.verify_pins(view['qualification_execution']['input_sha256'])
        assert digest(ROOT / 'build/bin/goose') == view['compiler_sha256'] == COMPILER_SHA
        assert view['failures'] == 0 and view['observations'] == len(view['results']) == 9573
        gates = [('process', 'tests/test_benchmark_process.py', 13, []),
                 ('native', 'tests/test_native_wasmtime.py', 14, ['--minimal-host', ROOT / 'build/bin/goose-wasmtime-aot']),
                 ('aot', 'tests/test_aot_wasmtime.py', 18, []),
                 ('session', 'tests/test_runtime_session.py', 9, []),
                 ('compact-logs', 'tests/test_command_logs.py', 9, []),
                 ('langarena', 'tests/test_langarena.py', 16, []),
                 ('runtime-reference', 'tests/test_runtime_reference.py', 12, [])]
        paths = {Path(__file__), ROOT / 'host/wasmtime.cpp', ROOT / 'scripts/build_wasmtime_host.py',
                 ROOT / 'bench/qualify_wasmtime_host.py', ROOT / 'bench/qualify_compiler.py',
                 ROOT / 'bench/process.py', ROOT / 'bench/command_logs.py', ROOT / 'tests/run_differential.py',
                 ROOT / '.github/workflows/ci.yml', OUT / 'baseline-report.json', ROOT / 'build/bin/goose'}
        paths.update(ROOT / path for _, path, _, _ in gates)
        for name in ['goose-wasmtime', 'goose-wasmtime-aot']:
            host = ROOT / 'build/bin' / name
            metadata_path = host.with_suffix('.json')
            metadata = json.loads(metadata_path.read_bytes())
            assert digest(host) == metadata['host_sha256']
            canonical.verify_pins(metadata['input_sha256'])
            paths.update([host, metadata_path])
            paths.update(Path(path) for path in metadata['input_sha256'])
        report['input_sha256'] = {str(path): digest(path) for path in sorted(paths)}
        report['reused_compiler'] = {'status': 'verified-prior', 'report': str(BASELINE / 'report.json'),
            'report_sha256': digest(BASELINE / 'report.json'), 'cases': view['cases'], 'observations': 9573,
            'reference_derivation': view['reference_derivation'],
            'verified_input_pins': len(view['qualification_execution']['input_sha256'])}
        save(report)
        for name, path, count, arguments in gates:
            run(report, name, [sys.executable, ROOT / path, *arguments, '-v'], count)
        report['fresh_gate_tests'] = sum(count for _, _, count, _ in gates)
        replay = [sys.executable, ROOT / 'bench/qualify_wasmtime_host.py', '--baseline-dir', BASELINE,
                  '--baseline-report', OUT / 'baseline-report.json', '--host', ROOT / 'build/bin/goose-wasmtime',
                  '--jobs', '4', '--compact-logs']
        run(report, 'host-replay', [*replay, '--output-dir', OUT / 'host'])
        report['host'] = validate(OUT / 'host/report.json', 11484,
                                  ['wasm', 'wasm-no-parallel', 'precompiled-no-parallel'])
        run(report, 'minimal-replay', [*replay, '--aot-host', ROOT / 'build/bin/goose-wasmtime-aot',
                                      '--backends', 'direct', '--output-dir', OUT / 'minimal'])
        report['minimal'] = validate(OUT / 'minimal/report.json', 1914, ['precompiled-minimal'])
        report['input_sha256_after'] = {path: digest(path) for path in report['input_sha256']}
        assert report['input_sha256'] == report['input_sha256_after']
        report.update(status='passed', coverage_exact=True)
    except BaseException as error:
        report.update(status='failed', error=type(error).__name__ + ': ' + str(error), traceback=traceback.format_exc())
    report.update(active=None, complete=True, finished_utc=now())
    save(report)
    completion = {'status': report['status'], 'report_sha256': digest(OUT / 'report.json'),
                  'complete': True, 'finished_utc': report['finished_utc']}
    (OUT / 'completion.json').write_text(json.dumps(completion, indent=2) + '\n')
    return int(report['status'] != 'passed')


if __name__ == '__main__':
    raise SystemExit(main())
