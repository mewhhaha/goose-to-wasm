"""Pinned, interleaved fresh-process pilot; configuration is the entire input."""
from datetime import datetime, timezone
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import random
import shutil
import statistics
import sys
import time

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location('pilot_helpers', ROOT / 'build/functions-native-hills/projection/measure.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)


def save(path, value):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('configuration', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    configuration = json.loads(args.configuration.read_bytes())
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    pins = {}
    for path in [Path(__file__), args.configuration, Path(sys.executable), ROOT / 'bench/process.py',
                 ROOT / 'build/functions-native-hills/projection/measure.py', *configuration['inputs']]:
        helper.pin(pins, path)
    controls = {key: os.environ.get(key) for key in [
        'RAYON_NUM_THREADS', 'OMP_NUM_THREADS', 'BINARYEN_CORES', 'LD_PRELOAD',
        'LD_LIBRARY_PATH', 'NODE_OPTIONS', 'GOOSE_STDLIB', 'WASMTIME_BACKTRACE_DETAILS']}
    if any(value is not None for value in controls.values()):
        raise ValueError('runtime environment controls must be unset')
    cells = configuration['cells']
    names = list(cells)
    expected = {}
    normalization = set()
    for index, (name, cell) in enumerate(cells.items()):
        executable = helper.pin(pins, cell['executable'])
        normalization.add(str(executable))
        alias = output / 'exec' / f'{index:03d}' / 'program'
        alias.parent.mkdir(parents=True)
        alias.symlink_to(executable)
        command = [str(alias), *cell.get('arguments', [])]
        if 'aot' in cell:
            aot = helper.pin(pins, cell['aot'])
            normalization.add(str(aot))
            guest = output / 'aot' / f'{index:03d}' / 'program.cwasm'
            guest.parent.mkdir(parents=True)
            guest.symlink_to(aot)
            command += ['--precompiled', str(guest)]
        cell['command'] = command
        expected[name] = helper.pin(pins, cell['expected']).read_bytes()
    for filename in pins:
        source = Path(filename)
        if source.suffix in {'.py', '.cpp', '.h', '.json', '.goose', '.patch', '.out'}:
            target = output / 'inputs' / pins[filename] / source.name
            target.parent.mkdir(parents=True, exist_ok=True)
            if not target.exists():
                shutil.copyfile(source, target)
    report = {'schema': 'goose-remaining-hills-paired-v1', 'status': 'running',
              'started_utc': datetime.now(timezone.utc).isoformat(), 'configuration': configuration,
              'input_sha256': pins, 'environment': controls, 'observations': [],
              'method': 'Shuffled complete blocks; normal-pool primary, CPU2 diagnostic. Fresh subprocesses, exact stdout/exit/stderr checks. '
                        'Same-length aliases; scoped inode normalization after pins. No concurrent builds/tests/scans in this campaign; other shared-host work is uncontrolled. '
                        'Dependencies outside scoped normalization. No outliers removed.'}
    initial = sorted(os.sched_getaffinity(0))
    report['initial_cpu_affinity'] = initial
    report['cache_preparation'] = [helper.normalize(path) for path in sorted(normalization)]
    save(output / 'initial.json', report)
    rng = random.Random(configuration.get('seed', 2026110412))
    try:
        for affinity in configuration.get('affinities', ['pool', 'cpu2']):
            cpus = initial
            if affinity == 'cpu2':
                cpus = [2]
            os.sched_setaffinity(0, cpus)
            for phase, count in [('warmup', configuration.get('warmups', 2)), ('measure', configuration.get('samples', 61))]:
                for sample in range(count):
                    order = names.copy()
                    rng.shuffle(order)
                    for name in order:
                        command = cells[name]['command']
                        started = time.perf_counter_ns()
                        result = helper.process.run(command, input=b'', capture_output=True, timeout=30, cwd=ROOT)
                        elapsed = time.perf_counter_ns() - started
                        row = {'affinity': affinity, 'phase': phase, 'sample': sample, 'cell': name,
                               'wall_ns': elapsed, 'exit_code': result.returncode,
                               'stdout': result.stdout.decode(errors='replace'), 'stderr': result.stderr.decode(errors='replace')}
                        report['observations'].append(row)
                        if result.returncode != 0 or result.stdout != expected[name] or result.stderr:
                            raise ValueError('output check failed: ' + name)
        report['input_sha256_after'] = {path: helper.digest(path) for path in pins}
        if report['input_sha256_after'] != pins:
            raise ValueError('input changed during measurement')
        if controls != {key: os.environ.get(key) for key in controls}:
            raise ValueError('runtime controls changed')
        report['summary'] = {}
        for affinity in configuration.get('affinities', ['pool', 'cpu2']):
            rows = [row for row in report['observations'] if row['affinity'] == affinity and row['phase'] == 'measure']
            index = {(row['sample'], row['cell']): row['wall_ns'] for row in rows}
            summary = {'wall_us': {name: helper.describe([index[i, name] / 1000 for i in range(configuration.get('samples', 61))]) for name in names}, 'paired_ratios': {}}
            for comparison in configuration['comparisons']:
                numerator, denominator = comparison
                ratios = [index[i, numerator] / index[i, denominator] for i in range(configuration.get('samples', 61))]
                estimates = []
                bootstrap = random.Random(configuration.get('seed', 2026110412))
                for _ in range(10000):
                    estimates.append(statistics.median(bootstrap.choices(ratios, k=len(ratios))))
                estimates.sort()
                description = helper.describe(ratios)
                description['bootstrap_95_ci'] = [estimates[249], estimates[9749]]
                summary['paired_ratios'][numerator + '/' + denominator] = description
            report['summary'][affinity] = summary
        report['status'] = 'passed'
    except BaseException as error:
        report.update(status='failed', error=type(error).__name__ + ': ' + str(error))
        raise
    finally:
        os.sched_setaffinity(0, initial)
        report['finished_utc'] = datetime.now(timezone.utc).isoformat()
        save(output / 'report.json', report)
        print(report['status'], output / 'report.json', flush=True)
    for affinity, summary in report['summary'].items():
        print(affinity, {key: round(value['median'], 4) for key, value in summary['paired_ratios'].items()}, flush=True)


if __name__ == '__main__':
    main()
