"""Fresh-process floor controls; exploratory, not a compiler performance change."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import hashlib,importlib.util,json,os,random,statistics,time
ROOT=Path(__file__).resolve().parents[2]
B=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('measurement_helpers',ROOT/'build/functions-native-hills/projection/measure.py')
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
process=helper.process
OUT=B/'run-1';OUT.mkdir(exist_ok=False)
COMPILER=ROOT/'build/next-runtime-hills/final/bin/goose'
HOST=ROOT/'build/bin/goose-wasmtime';MIN=ROOT/'build/bin/goose-wasmtime-aot'
pins={}
def pin(p,expected=None):return helper.pin(pins,p,expected)
def digest(p):return helper.digest(p)
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
for p in [Path(__file__),Path(sys.executable),ROOT/'bench/process.py',ROOT/'scripts/goose_wasm.py',ROOT/'oracle/goose_wasm.py',ROOT/'toolchain.json']:
 pin(p)
helper.pin_compiler(pins,COMPILER.parent.parent)
for host in [HOST,MIN]:helper.pin_host(pins,host)
golden=pin(ROOT/'examples/expected/functions.out').read_bytes()
assert golden.endswith(b'\n')
controls={k:os.environ.get(k)for k in ['RAYON_NUM_THREADS','OMP_NUM_THREADS','BINARYEN_CORES','LD_PRELOAD','LD_LIBRARY_PATH','NODE_OPTIONS','GOOSE_STDLIB']}
assert all(v is None for v in controls.values())
preparations=[];cases={}
for name,body,expected in [('empty','',''.encode()),('print-only','print('+json.dumps(golden[:-1].decode())+');',golden)]:
 directory=OUT/name;directory.mkdir()
 source=directory/'main.goose';source.write_text('import std;\nfn main() { '+body+' }\n');pin(source)
 artifacts={}
 for backend in ['direct','native']:
  suffix='.wasm'
  if backend=='native':suffix='.bin'
  artifact=directory/('program'+suffix)
  cmd=[sys.executable,ROOT/'scripts/goose_wasm.py','build',source,'--backend',backend,'--goose',COMPILER,'--offline','--no-cache','-O2','-o',artifact]
  r=process.run(list(map(str,cmd)),input=b'',capture_output=True,timeout=180,cwd=ROOT)
  preparations.append({'command':list(map(str,cmd)),'exit_code':r.returncode,'stdout':r.stdout.decode(),'stderr':r.stderr.decode()})
  assert r.returncode==0,preparations[-1]
  artifacts[backend]=pin(artifact)
 aot=directory/'program.cwasm'
 cmd=[HOST,'--aot-profile','minimal','--no-cache','--compile',artifacts['direct'],aot]
 r=process.run(list(map(str,cmd)),input=b'',capture_output=True,timeout=60,cwd=ROOT)
 preparations.append({'command':list(map(str,cmd)),'exit_code':r.returncode,'stdout':r.stdout.decode(),'stderr':r.stderr.decode()})
 assert r.returncode==0 and not r.stdout and not r.stderr,preparations[-1]
 cases[name]={'native':artifacts['native'],'wasm':artifacts['direct'],'aot':pin(aot),'expected':expected}
previous=ROOT/'build/functions-native-hills/current'
cases['functions']={'native':pin(previous/'examples/compile/functions/native/0/program.bin'),'wasm':pin(previous/'examples/compile/functions/direct/0/program.wasm'),'aot':pin(previous/'host/preparation/functions/direct/minimal/0/program.cwasm'),'expected':golden}
paths={MIN}
for case,items in cases.items():
 paths.update([items['native'],items['wasm'],items['aot']])
 commands={}
 for backend in ['native','aot']:
  alias=OUT/'exec'/case[0]/backend[0]/'program';alias.parent.mkdir(parents=True);target=MIN
  if backend=='native':target=items['native']
  alias.symlink_to(target);command=[str(alias)]
  if backend=='aot':
   guest=OUT/'aot'/case[0]/'program.cwasm';guest.parent.mkdir(parents=True);guest.symlink_to(items['aot'])
   command+=['--precompiled',str(guest)]
  commands[backend]=command
 items['commands']=commands
report={'schema':'goose-process-floor-probe-v1','status':'running','compiler_sha256':digest(COMPILER),'host_sha256':digest(MIN),'source_commit':'0d1715ceef998e65737335ee3ac88433a90672ef','samples':61,'warmups':2,'method':'Same source compiler/toolchain and current minimal AOT host; native O2. Empty program and print-only program emitting exact Functions stdout once, versus unchanged full Functions. Six cells shuffled per round; two fresh warmups and61 observations/cell/affinity, normal pool primary and CPU2 diagnostic. Captured stdout and returncodes checked. Same-length exec aliases. All hashing precedes scoped cache normalization; no overlapping builds or tests.','limit':'These smaller control modules/binaries also reduce code/data footprint and print formatting/callback work. They estimate an attainable best-case process floor for these controls, not an exact decomposition or a guaranteed Functions speedup. Separate from the delivered cohorts.','controls':controls,'input_sha256':pins,'preparations':preparations,'cases':{k:{n:str(p)for n,p in v.items()if n in ['native','wasm','aot']}for k,v in cases.items()},'observations':[]}
report['cache_preparation']=[helper.normalize(str(p))for p in sorted(paths)]
save(OUT/'initial.json',report)
initial=sorted(os.sched_getaffinity(0));rng=random.Random(202611041)
try:
 for affinity in ['pool','cpu2']:
  cpus=initial
  if affinity=='cpu2':cpus=[2]
  os.sched_setaffinity(0,cpus)
  for phase,count in [('warmup',2),('measure',61)]:
   for sample in range(count):
    cells=[(n,b)for n in cases for b in ['native','aot']];rng.shuffle(cells)
    for name,backend in cells:
     command=cases[name]['commands'][backend]
     started=time.perf_counter_ns();r=process.run(command,input=b'',capture_output=True,timeout=30,cwd=ROOT);elapsed=time.perf_counter_ns()-started
     assert r.returncode==0 and r.stdout==cases[name]['expected'] and not r.stderr,(name,backend,r)
     report['observations'].append({'affinity':affinity,'phase':phase,'sample':sample,'case':name,'backend':backend,'wall_ns':elapsed,'command':command,'exit_code':r.returncode,'stdout':r.stdout.decode(),'stderr':r.stderr.decode()})
finally:os.sched_setaffinity(0,initial)
report['summary']={}
for affinity in ['pool','cpu2']:
 rows=[r for r in report['observations']if r['affinity']==affinity and r['phase']=='measure'];ix={(r['sample'],r['case'],r['backend']):r['wall_ns']for r in rows}
 summary={}
 for n in cases:
  for b in ['native','aot']:summary[n+'/'+b]=helper.describe([ix[i,n,b]/1000 for i in range(61)])
 report['summary'][affinity]={'wall_us':summary,'ratios':{n:helper.describe([ix[i,n,'aot']/ix[i,n,'native']for i in range(61)])for n in cases},'functions_aot_over_print_only':helper.describe([ix[i,'functions','aot']/ix[i,'print-only','aot']for i in range(61)])}
report['input_sha256_after']={p:digest(p)for p in pins};assert report['input_sha256_after']==pins
assert controls=={k:os.environ.get(k)for k in controls}
report['status']='passed';save(OUT/'report.json',report)
for a,r in report['summary'].items():print(a,{k:round(v['median'],3)for k,v in r['wall_us'].items()},'ratios',{k:round(v['median'],4)for k,v in r['ratios'].items()},'full/print',round(r['functions_aot_over_print_only']['median'],4))
