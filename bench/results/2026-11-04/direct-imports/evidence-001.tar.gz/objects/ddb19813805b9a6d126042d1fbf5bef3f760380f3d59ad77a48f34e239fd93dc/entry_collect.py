from pathlib import Path
import hashlib,json,os,random,statistics,subprocess
b=Path('build/remaining-hills/startup/raw').resolve();root=Path.cwd();artifact=(root/'build/functions-native-hills/current/host/preparation/functions/direct/minimal/0/program.cwasm').resolve();expected=(root/'examples/expected/functions.out').read_bytes();scratch=b/'entry-scratch.json';rng=random.Random(2026110420)
hosts={'checked_direct':b/'direct/goose-wasmtime-aot','raw':b/'goose-wasmtime-aot'};paths=[artifact,*(hosts.values()),*(h.with_suffix('.json')for h in hosts.values()),b/'direct-only.cpp',b/'wasmtime.raw-callback.cpp'];identities={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in paths}
report={'schema':'goose-raw-callback-entry-diagnostic-v1','status':'running','input_sha256':identities,'cpu_affinity':sorted(os.sched_getaffinity(0)),'method':'31 shuffled fresh-process launches per host, unchanged Functions AOT and exact stdout. Host --timing-json boundaries cover engine/config/Store/deserialize/instantiate through entry return; teardown and writing the scratch JSON are excluded by host boundaries. No process-wall rows collected. Ordinary pool, diagnostic only; potentially concurrent compiler restoration.','runs':[]}
for iteration in range(31):
    modes=list(hosts);rng.shuffle(modes)
    for mode in modes:
        command=[str(hosts[mode]),'--precompiled',str(artifact),'--timing-json',str(scratch)];scratch.unlink(missing_ok=True)
        result=subprocess.run(command,input=b'',capture_output=True,timeout=30);assert (result.returncode,result.stdout,result.stderr)==(0,expected,b'')
        row=json.loads(scratch.read_text());assert row['aot_profile']=='minimal'
        report['runs'].append({'iteration':iteration,'mode':mode,'command':command,'exit_code':0,'stdout_matches':True,'timing':row})
report['input_sha256_after']={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in paths};assert report['input_sha256_after']==identities
report['summary_ns']={mode:{field:statistics.median([row['timing'][field]for row in report['runs']if row['mode']==mode])for field in ['compile_instantiate_ns','start_function_ns','engine_total_ns']}for mode in hosts};report['status']='passed'
(b/'entry-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report['summary_ns']))
