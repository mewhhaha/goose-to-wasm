# Example program benchmarks

Status: **passed**.

2026-11-04 · AMD Ryzen 7 3800X; pinned CPU 7.

Goose O2. Direct Wasm uses memory32; Native C is emitted by the Goose compiler. The selected programs, their constant inputs and all printing are unchanged from the [example catalog](../../../../examples/README.md). Compiler constant folding is allowed.

Builds are complete uncached Python-driver invocations, including any C compilation/linking. OS page caches remain warm.

Runtime is **whole-process launch-to-exit time**, including host startup, Wasm compilation/instantiation, program initialization, computation, output delivery and teardown. Each observation starts a fresh process/instance and calls the entrypoint once. This measures CLI cost, not warmed kernel throughput.

Each cell has 5 build samples or 5 runtime samples. Untimed fresh-process warmups per runtime cell: 1. Orders are shuffled with the recorded seed; builds and runtime never overlap. Every used artifact must pass its golden output. Values are median milliseconds ± median absolute deviation (MAD).

Headline runtime samples use the ordinary runners without timing-file instrumentation. The Wasm supplements use a separate shuffled set of fresh processes, with the same sample count; timing files are written after their engine intervals end.

## Compilation

| Example | Direct Wasm | Goose Native C |
| --- | ---: | ---: |
| squares | 48.870 ±0.052 | 144.228 ±0.421 |
| tour | 69.310 ±0.695 | 684.734 ±7.111 |
| functions | 237.267 ±4.136 | 1236.302 ±2.439 |
| errors | 110.417 ±0.097 | 612.475 ±5.262 |
| sieve | 83.120 ±1.161 | 302.236 ±3.015 |
| sorting | 276.414 ±8.767 | 1180.769 ±3.959 |
| sudoku | 91.464 ±0.443 | 392.246 ±4.680 |
| maze | 112.198 ±0.973 | 537.994 ±2.159 |
| vm | 109.201 ±0.673 | 444.993 ±1.979 |
| life | 93.655 ±1.415 | 378.119 ±1.162 |

## Whole-process runtime

| Example | Direct / V8 | Direct / Wasmtime | Goose Native C |
| --- | ---: | ---: | ---: |
| squares | 26.654 ±1.253 | 69.049 ±0.256 | 0.633 ±0.006 |
| tour | 53.276 ±0.043 | 112.866 ±0.448 | 0.689 ±0.019 |
| functions | 45.982 ±0.514 | 178.064 ±0.946 | 0.679 ±0.012 |
| errors | 34.192 ±1.273 | 107.479 ±1.199 | 0.560 ±0.010 |
| sieve | 52.846 ±0.815 | 82.815 ±0.085 | 5.606 ±0.021 |
| sorting | 378.035 ±6.109 | 352.613 ±13.016 | 1514.886 ±3.260 |
| sudoku | 47.341 ±0.926 | 93.729 ±0.073 | 8.954 ±0.060 |
| maze | 34.662 ±0.345 | 114.017 ±0.608 | 0.662 ±0.034 |
| vm | 56.371 ±2.349 | 125.158 ±0.249 | 0.686 ±0.007 |
| life | 69.087 ±0.200 | 125.890 ±0.860 | 32.117 ±0.153 |

## Supplement: Wasm entrypoint

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.211 ±0.001 | 0.127 ±0.005 |
| tour | 22.208 ±0.099 | 1.765 ±0.002 |
| functions | 15.765 ±0.439 | 1.327 ±0.009 |
| errors | 5.860 ±0.004 | 0.843 ±0.009 |
| sieve | 11.808 ±1.284 | 1.978 ±0.010 |
| sorting | 347.059 ±1.937 | 162.656 ±0.143 |
| sudoku | 18.656 ±1.301 | 11.293 ±0.049 |
| maze | 6.373 ±0.121 | 0.784 ±0.009 |
| vm | 23.129 ±0.282 | 0.931 ±0.007 |
| life | 40.991 ±0.731 | 30.803 ±0.109 |

## Supplement: Wasm engine compilation and instantiation

| Example | Direct / V8 | Direct / Wasmtime |
| --- | ---: | ---: | ---: |
| squares | 0.273 ±0.010 | 4.099 ±0.018 |
| tour | 0.477 ±0.021 | 44.431 ±0.031 |
| functions | 0.780 ±0.015 | 110.677 ±0.315 |
| errors | 0.520 ±0.033 | 39.418 ±0.189 |
| sieve | 0.336 ±0.002 | 15.865 ±0.051 |
| sorting | 0.798 ±0.006 | 111.240 ±0.937 |
| sudoku | 0.406 ±0.031 | 18.070 ±0.146 |
| maze | 0.521 ±0.031 | 48.293 ±0.601 |
| vm | 0.540 ±0.007 | 59.159 ±1.111 |
| life | 0.403 ±0.004 | 28.636 ±0.238 |

The entrypoint interval includes Goose initialization, host output callbacks and any lazy JIT work. It excludes final Wasm-host output concatenation/delivery. Native Goose prints unbuffered, so no native entrypoint column or cross-boundary speedup is presented. Process time minus engine time also includes loading, bookkeeping and teardown; it is not a pure startup measurement.

These fresh-process examples have different timing rules from LangArena's warmed computational regions. Raw samples, commands, artifact/source/compiler identities and engine versions are in [report.json](report.json). [Method and reproduction](../../../examples.md).
