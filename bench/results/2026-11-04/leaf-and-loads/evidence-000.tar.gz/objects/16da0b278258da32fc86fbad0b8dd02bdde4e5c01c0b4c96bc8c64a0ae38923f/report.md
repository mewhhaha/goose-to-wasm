# LangArena qualification and measurements

Status: **passed**.

Upstream pin: `aab9b14998231ba905523b5ba3990ee03c46f64d`. Catalog: **50 tasks**. Adapted entrypoints: **7 tasks**, including six storage adaptations.

Mode: `measure`. Machine: AMD Ryzen 7 3800X, shared desktop host.
Compiler SHA-256: `8c09c1a6bcc782de5b86dda621a91ae234acba8fbe108d146582113eb6a110b6`.

## Measurement contract

Whole-suite results use all original Goose kernel sources. The only staging patch changes the marker destination from `/tmp/recompile_marker` to a relative file inside the isolated run directory. The original checkout is hash-verified and never edited. Whole-suite compile times include all 50 tasks.

The adapted track uses the same seven port sources across native C, direct Wasm, and C-Wasm. Six ports replace growable storage; Fannkuch keeps its original fixed-array kernel. Official test/run inputs and checksums are unchanged. Preparation stays outside the clock; warmups mutate the same state used for measurement; the deterministic RNG is reset before measured iterations. Existing checksum work retains its original placement.

Cold builds and marker-edit builds launch fresh driver/compiler processes with `--no-cache`. OS caches and installed compiler/system-library caches are retained. A port marker edit changes its exit status from 0 to 1 after its two output lines, and the edited executable must retain the official checksum. Whole-suite edits change the actual marker file contents. Source bytes are restored in all cases. Optional unchanged cache hits are a separate phase. Edited sources still rerun the complete frontend.

The official whole-suite timer prints milliseconds; adapted ports print integer nanoseconds. Timed regions exclude process startup and preparation. Process wall time is retained separately. Sample counts below five are preliminary estimates; raw values and MAD are provided. These are local comparisons, not LangArena leaderboard scores or claims of complete direct-backend language support.

## Whole-suite compilation

| Backend | Phase | Samples | Median ms | MAD ms | Artifact bytes |
| --- | --- | ---: | ---: | ---: | ---: |

## Original-source correctness and runtime

| Task | Backend / engine | Profile | Samples | Region median ms | MAD ms | Process median ms |
| --- | --- | --- | ---: | ---: | ---: | ---: |

## Adapted workload compilation

| Task | Backend | Phase | Samples | Median ms | MAD ms | Artifact bytes |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| CLBG::Fannkuchredux | c-wasm | cold | 5 | 649.900 | 16.820 | 51991 |
| CLBG::Fannkuchredux | direct | cold | 5 | 74.765 | 8.456 | 3917 |
| CLBG::Fannkuchredux | native | cold | 5 | 316.745 | 13.401 | 22984 |
| CLBG::Mandelbrot | c-wasm | cold | 5 | 638.240 | 13.565 | 52065 |
| CLBG::Mandelbrot | direct | cold | 5 | 73.201 | 5.742 | 4467 |
| CLBG::Mandelbrot | native | cold | 5 | 290.039 | 6.465 | 23160 |
| Etc::Sieve | c-wasm | cold | 5 | 653.835 | 34.779 | 51613 |
| Etc::Sieve | direct | cold | 5 | 65.551 | 0.264 | 3576 |
| Etc::Sieve | native | cold | 5 | 285.289 | 28.402 | 23128 |
| Hash::CRC32 | c-wasm | cold | 5 | 659.877 | 16.771 | 51823 |
| Hash::CRC32 | direct | cold | 5 | 66.714 | 1.533 | 3132 |
| Hash::CRC32 | native | cold | 5 | 278.559 | 18.094 | 23008 |
| Hash::SHA256 | c-wasm | cold | 5 | 676.633 | 48.011 | 51838 |
| Hash::SHA256 | direct | cold | 5 | 68.036 | 1.479 | 6598 |
| Hash::SHA256 | native | cold | 5 | 282.079 | 13.215 | 23008 |
| Sort::Merge | c-wasm | cold | 5 | 657.162 | 23.165 | 52490 |
| Sort::Merge | direct | cold | 5 | 73.793 | 3.702 | 5527 |
| Sort::Merge | native | cold | 5 | 307.058 | 9.909 | 27416 |
| Sort::Quick | c-wasm | cold | 5 | 656.197 | 2.941 | 52049 |
| Sort::Quick | direct | cold | 5 | 67.036 | 1.450 | 4480 |
| Sort::Quick | native | cold | 5 | 287.343 | 18.421 | 23168 |

## Adapted workload runtime

| Task | Backend / engine | Profile | Samples | Region median ms | MAD ms | Engine compile + instantiate ms | Process median ms | Checksum |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| CLBG::Fannkuchredux | c-wasm / v8 | run | 5 | 2123.231 | 4.597 | 0.554 | 2573.474 | 135762480 |
| CLBG::Fannkuchredux | c-wasm / v8 | test | 1 | 0.020 | 0.000 | 0.578 | 29.053 | 4428 |
| CLBG::Fannkuchredux | c-wasm / wasmtime | run | 5 | 1459.040 | 2.013 | 30.685 | 1864.978 | 135762480 |
| CLBG::Fannkuchredux | c-wasm / wasmtime | test | 1 | 0.053 | 0.000 | 23.198 | 136.524 | 4428 |
| CLBG::Fannkuchredux | direct / v8 | run | 5 | 1246.257 | 1.876 | 0.267 | 1530.728 | 135762480 |
| CLBG::Fannkuchredux | direct / v8 | test | 1 | 0.028 | 0.000 | 0.277 | 25.575 | 4428 |
| CLBG::Fannkuchredux | direct / wasmtime | run | 5 | 1364.547 | 8.522 | 4.560 | 1717.371 | 135762480 |
| CLBG::Fannkuchredux | direct / wasmtime | test | 1 | 0.024 | 0.000 | 4.272 | 82.030 | 4428 |
| CLBG::Fannkuchredux | native / native | run | 5 | 1317.656 | 9.757 | — | 1566.287 | 135762480 |
| CLBG::Fannkuchredux | native / native | test | 1 | 0.016 | 0.000 | — | 0.907 | 4428 |
| CLBG::Mandelbrot | c-wasm / v8 | run | 5 | 947.786 | 0.369 | 0.643 | 1181.227 | 3455988829 |
| CLBG::Mandelbrot | c-wasm / v8 | test | 1 | 0.334 | 0.000 | 0.692 | 27.541 | 2236342953 |
| CLBG::Mandelbrot | c-wasm / wasmtime | run | 5 | 1057.004 | 1.705 | 23.654 | 1375.894 | 3455988829 |
| CLBG::Mandelbrot | c-wasm / wasmtime | test | 1 | 0.218 | 0.000 | 24.439 | 132.767 | 2236342953 |
| CLBG::Mandelbrot | direct / v8 | run | 5 | 967.109 | 9.360 | 0.247 | 1209.147 | 3455988829 |
| CLBG::Mandelbrot | direct / v8 | test | 1 | 0.377 | 0.000 | 0.233 | 26.360 | 2236342953 |
| CLBG::Mandelbrot | direct / wasmtime | run | 5 | 993.664 | 1.892 | 3.851 | 1280.163 | 3455988829 |
| CLBG::Mandelbrot | direct / wasmtime | test | 1 | 0.186 | 0.000 | 3.799 | 82.985 | 2236342953 |
| CLBG::Mandelbrot | native / native | run | 5 | 923.636 | 5.622 | — | 1118.315 | 3455988829 |
| CLBG::Mandelbrot | native / native | test | 1 | 0.153 | 0.000 | — | 2.643 | 2236342953 |
| Etc::Sieve | c-wasm / v8 | run | 5 | 6595.517 | 548.164 | 0.590 | 7745.932 | 1042248060 |
| Etc::Sieve | c-wasm / v8 | test | 1 | 0.020 | 0.000 | 0.632 | 31.406 | 4660 |
| Etc::Sieve | c-wasm / wasmtime | run | 5 | 5334.932 | 34.090 | 23.864 | 6525.801 | 1042248060 |
| Etc::Sieve | c-wasm / wasmtime | test | 1 | 0.048 | 0.000 | 27.293 | 114.223 | 4660 |
| Etc::Sieve | direct / v8 | run | 5 | 728.241 | 1.233 | 0.271 | 908.581 | 1042248060 |
| Etc::Sieve | direct / v8 | test | 1 | 0.005 | 0.000 | 0.270 | 26.896 | 4660 |
| Etc::Sieve | direct / wasmtime | run | 5 | 735.930 | 3.378 | 3.928 | 969.478 | 1042248060 |
| Etc::Sieve | direct / wasmtime | test | 1 | 0.018 | 0.000 | 4.001 | 83.576 | 4660 |
| Etc::Sieve | native / native | run | 5 | 853.477 | 0.627 | — | 1028.300 | 1042248060 |
| Etc::Sieve | native / native | test | 1 | 0.002 | 0.000 | — | 2.716 | 4660 |
| Hash::CRC32 | c-wasm / v8 | run | 5 | 456.733 | 3.254 | 0.614 | 587.084 | 2318723244 |
| Hash::CRC32 | c-wasm / v8 | test | 1 | 0.014 | 0.000 | 3.726 | 31.999 | 3031698216 |
| Hash::CRC32 | c-wasm / wasmtime | run | 5 | 410.361 | 6.408 | 26.422 | 610.037 | 2318723244 |
| Hash::CRC32 | c-wasm / wasmtime | test | 1 | 0.051 | 0.000 | 24.796 | 129.057 | 3031698216 |
| Hash::CRC32 | direct / v8 | run | 5 | 497.604 | 2.907 | 0.232 | 640.277 | 2318723244 |
| Hash::CRC32 | direct / v8 | test | 1 | 0.017 | 0.000 | 0.271 | 45.094 | 3031698216 |
| Hash::CRC32 | direct / wasmtime | run | 5 | 428.934 | 2.082 | 3.869 | 606.092 | 2318723244 |
| Hash::CRC32 | direct / wasmtime | test | 1 | 0.025 | 0.000 | 4.553 | 87.064 | 3031698216 |
| Hash::CRC32 | native / native | run | 5 | 1353.088 | 5.795 | — | 1632.298 | 2318723244 |
| Hash::CRC32 | native / native | test | 1 | 0.027 | 0.000 | — | 1.437 | 3031698216 |
| Hash::SHA256 | c-wasm / v8 | run | 5 | 1030.993 | 4.760 | 0.643 | 1282.430 | 2844672256 |
| Hash::SHA256 | c-wasm / v8 | test | 1 | 0.014 | 0.000 | 0.676 | 50.123 | 1036619072 |
| Hash::SHA256 | c-wasm / wasmtime | run | 5 | 954.947 | 14.107 | 23.969 | 1259.943 | 2844672256 |
| Hash::SHA256 | c-wasm / wasmtime | test | 1 | 0.045 | 0.000 | 25.413 | 109.125 | 1036619072 |
| Hash::SHA256 | direct / v8 | run | 5 | 260.512 | 0.865 | 0.267 | 356.777 | 2844672256 |
| Hash::SHA256 | direct / v8 | test | 1 | 0.003 | 0.000 | 0.261 | 28.507 | 1036619072 |
| Hash::SHA256 | direct / wasmtime | run | 5 | 256.681 | 1.592 | 5.357 | 401.891 | 2844672256 |
| Hash::SHA256 | direct / wasmtime | test | 1 | 0.017 | 0.000 | 5.024 | 86.146 | 1036619072 |
| Hash::SHA256 | native / native | run | 5 | 582.871 | 4.964 | — | 703.726 | 2844672256 |
| Hash::SHA256 | native / native | test | 1 | 0.002 | 0.000 | — | 1.959 | 1036619072 |
| Sort::Merge | c-wasm / v8 | run | 5 | 1305.934 | 8.618 | 0.575 | 1602.237 | 61757772 |
| Sort::Merge | c-wasm / v8 | test | 1 | 13.912 | 0.000 | 0.773 | 59.689 | 2548773 |
| Sort::Merge | c-wasm / wasmtime | run | 5 | 2698.393 | 25.749 | 24.213 | 3358.783 | 61757772 |
| Sort::Merge | c-wasm / wasmtime | test | 1 | 24.200 | 0.000 | 24.827 | 169.393 | 2548773 |
| Sort::Merge | direct / v8 | run | 5 | 1435.092 | 7.957 | 0.321 | 1758.290 | 61757772 |
| Sort::Merge | direct / v8 | test | 1 | 13.240 | 0.000 | 0.294 | 52.175 | 2548773 |
| Sort::Merge | direct / wasmtime | run | 5 | 1483.725 | 1.574 | 4.605 | 1871.195 | 61757772 |
| Sort::Merge | direct / wasmtime | test | 1 | 13.591 | 0.000 | 4.373 | 104.150 | 2548773 |
| Sort::Merge | native / native | run | 5 | 1382.634 | 5.836 | — | 1663.578 | 61757772 |
| Sort::Merge | native / native | test | 1 | 13.281 | 0.000 | — | 22.334 | 2548773 |
| Sort::Quick | c-wasm / v8 | run | 5 | 1404.040 | 10.772 | 0.576 | 1719.878 | 61757772 |
| Sort::Quick | c-wasm / v8 | test | 1 | 13.370 | 0.000 | 0.637 | 52.599 | 2548773 |
| Sort::Quick | c-wasm / wasmtime | run | 5 | 1621.007 | 1.265 | 23.335 | 2061.661 | 61757772 |
| Sort::Quick | c-wasm / wasmtime | test | 1 | 15.769 | 0.000 | 24.318 | 129.833 | 2548773 |
| Sort::Quick | direct / v8 | run | 5 | 1335.074 | 9.405 | 0.262 | 1637.384 | 61757772 |
| Sort::Quick | direct / v8 | test | 1 | 13.342 | 0.000 | 0.290 | 53.013 | 2548773 |
| Sort::Quick | direct / wasmtime | run | 5 | 1436.533 | 5.319 | 3.900 | 1809.649 | 61757772 |
| Sort::Quick | direct / wasmtime | test | 1 | 13.801 | 0.000 | 3.530 | 105.582 | 2548773 |
| Sort::Quick | native / native | run | 5 | 1181.687 | 4.655 | — | 1421.870 | 61757772 |
| Sort::Quick | native / native | test | 1 | 11.635 | 0.000 | — | 19.792 | 2548773 |

## Qualification and limits

- Seven adapted entrypoints (six change storage, one changes only the harness) are a subset of the 50-task catalog; they do not establish unmodified whole-suite Wasm support.
- No local result is a LangArena leaderboard rank: source/compiler versions, target layout, host, flags, and coverage differ.
- Cold builds retain OS and compiler system-library caches; they are complete uncached driver builds, not disk-cold experiments.

The full 50-task coverage matrix, raw commands/output, source and artifact hashes, tool versions, input values, environment overrides (including `EM_NODE_JS`), and phase timings are in `report.json` and adjacent logs. `Hash::SHA256` retains LangArena's custom hash workload; it is not standard cryptographic SHA-256.
