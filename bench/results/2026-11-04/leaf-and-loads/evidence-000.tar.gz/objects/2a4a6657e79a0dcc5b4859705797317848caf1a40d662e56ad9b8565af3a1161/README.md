# Example program benchmarks

Status: **passed**.

2026-11-04 · AMD Ryzen 7 3800X, shared desktop host.

Goose O2. Direct Wasm uses memory32; C-Wasm uses memory64. The selected programs, their constant inputs and all printing are unchanged from the [example catalog](../../../../examples/README.md). Compiler constant folding is allowed.

Builds are complete uncached Python-driver invocations, including any C compilation/linking. OS page caches and Emscripten's installed system-library cache remain warm.

Runtime is **whole-process launch-to-exit time**, including host startup, Wasm compilation/instantiation, program initialization, computation, output delivery and teardown. Each observation starts a fresh process/instance and calls the entrypoint once. This measures CLI cost, not warmed kernel throughput.

Each cell has 5 build samples or 15 runtime samples. Untimed fresh-process warmups per runtime cell: 1. Orders are shuffled with the recorded seed; builds and runtime never overlap. Every used artifact must pass its golden output. Values are median milliseconds ± median absolute deviation (MAD).

Headline runtime samples use the ordinary runners without timing-file instrumentation. The Wasm supplements use a separate shuffled set of fresh processes, with the same sample count; timing files are written after their engine intervals end.

## Compilation

| Example | Direct | C-Wasm | Native C |
| --- | ---: | ---: | ---: |
| squares | 62.457 ±0.837 | 546.631 ±19.618 | 208.261 ±4.039 |
| tour | 66.969 ±2.223 | 989.569 ±26.983 | 459.427 ±5.839 |
| functions | 89.196 ±0.865 | 962.529 ±12.691 | 556.301 ±13.665 |
| errors | 76.477 ±0.903 | 706.496 ±18.327 | 376.855 ±47.492 |
| sieve | 69.172 ±0.387 | 600.661 ±48.794 | 269.449 ±11.134 |
| sorting | 96.167 ±5.302 | 889.889 ±10.364 | 577.841 ±15.445 |
| sudoku | 82.494 ±6.677 | 547.745 ±19.859 | 288.665 ±10.364 |
| maze | 74.678 ±3.651 | 691.123 ±22.373 | 361.275 ±9.437 |
| vm | 79.857 ±10.769 | 684.258 ±15.145 | 288.133 ±5.712 |
| life | 70.933 ±1.127 | 623.557 ±8.121 | 319.361 ±15.438 |

## Whole-process runtime

| Example | Direct / V8 | C-Wasm / V8 | Direct / Wasmtime | C-Wasm / Wasmtime | Native C |
| --- | ---: | ---: | ---: | ---: | ---: |
| squares | 34.622 ±5.910 | 40.023 ±8.651 | 95.396 ±4.177 | 85.915 ±3.239 | 0.825 ±0.075 |
| tour | 47.327 ±1.768 | 37.779 ±7.794 | 127.322 ±3.861 | 108.955 ±5.325 | 1.126 ±0.188 |
| functions | 48.871 ±11.675 | 35.970 ±4.682 | 102.716 ±12.195 | 105.581 ±4.649 | 1.285 ±0.135 |
| errors | 30.520 ±3.452 | 31.511 ±2.303 | 83.588 ±3.266 | 102.018 ±10.512 | 0.927 ±0.143 |
| sieve | 31.185 ±1.897 | 33.600 ±1.438 | 83.277 ±5.382 | 89.628 ±5.323 | 1.166 ±0.205 |
| sorting | 69.246 ±7.568 | 248.549 ±10.560 | 117.574 ±8.282 | 257.195 ±18.219 | 51.622 ±3.997 |
| sudoku | 52.016 ±9.280 | 36.022 ±2.591 | 79.662 ±4.299 | 99.402 ±7.013 | 4.455 ±0.540 |
| maze | 48.707 ±6.243 | 32.047 ±2.641 | 87.952 ±7.716 | 96.117 ±9.800 | 1.178 ±0.197 |
| vm | 35.841 ±4.824 | 37.491 ±8.267 | 97.118 ±5.877 | 91.025 ±2.300 | 0.903 ±0.073 |
| life | 46.674 ±10.200 | 44.657 ±4.253 | 100.097 ±12.457 | 101.251 ±6.389 | 20.106 ±1.795 |

## Supplement: Wasm entrypoint

| Example | Direct / V8 | C-Wasm / V8 | Direct / Wasmtime | C-Wasm / Wasmtime |
| --- | ---: | ---: | ---: | ---: |
| squares | 0.193 ±0.008 | 1.007 ±0.030 | 0.136 ±0.003 | 0.650 ±0.008 |
| tour | 14.362 ±0.624 | 3.747 ±1.006 | 1.828 ±0.035 | 1.785 ±0.013 |
| functions | 6.084 ±1.163 | 2.783 ±0.128 | 1.387 ±0.024 | 1.989 ±0.018 |
| errors | 1.636 ±0.049 | 1.815 ±0.042 | 0.882 ±0.025 | 1.749 ±0.017 |
| sieve | 2.090 ±0.166 | 3.156 ±1.304 | 1.196 ±0.021 | 1.398 ±0.018 |
| sorting | 24.963 ±3.019 | 213.790 ±6.860 | 15.985 ±0.287 | 133.417 ±1.689 |
| sudoku | 5.612 ±0.095 | 7.009 ±0.620 | 3.887 ±0.059 | 8.700 ±0.136 |
| maze | 2.454 ±0.187 | 2.755 ±0.735 | 0.821 ±0.025 | 2.313 ±0.029 |
| vm | 3.075 ±0.428 | 2.297 ±0.088 | 0.949 ±0.015 | 3.112 ±0.021 |
| life | 5.992 ±1.557 | 10.488 ±0.490 | 2.915 ±0.064 | 9.906 ±0.122 |

## Supplement: Wasm engine compilation and instantiation

| Example | Direct / V8 | C-Wasm / V8 | Direct / Wasmtime | C-Wasm / Wasmtime |
| --- | ---: | ---: | ---: | ---: |
| squares | 0.248 ±0.011 | 0.589 ±0.069 | 2.980 ±0.161 | 11.120 ±1.086 |
| tour | 0.564 ±0.112 | 0.677 ±0.082 | 32.307 ±1.427 | 36.712 ±3.896 |
| functions | 0.428 ±0.055 | 0.589 ±0.052 | 21.007 ±3.369 | 29.392 ±1.050 |
| errors | 0.332 ±0.033 | 0.635 ±0.056 | 10.705 ±0.891 | 14.685 ±1.258 |
| sieve | 0.303 ±0.034 | 0.600 ±0.048 | 8.288 ±1.819 | 12.443 ±1.091 |
| sorting | 0.459 ±0.062 | 0.687 ±0.103 | 20.398 ±4.580 | 32.614 ±1.533 |
| sudoku | 0.337 ±0.060 | 0.629 ±0.091 | 6.664 ±0.850 | 12.480 ±1.428 |
| maze | 0.401 ±0.060 | 0.659 ±0.083 | 12.284 ±2.205 | 16.914 ±2.400 |
| vm | 0.377 ±0.062 | 0.617 ±0.057 | 17.175 ±1.801 | 17.163 ±1.439 |
| life | 0.376 ±0.055 | 0.615 ±0.053 | 12.591 ±0.415 | 14.225 ±0.861 |

The entrypoint interval includes Goose initialization, host output callbacks and any lazy JIT work. It excludes final Wasm-host output concatenation/delivery. Native Goose prints unbuffered, so no native entrypoint column or cross-boundary speedup is presented. Process time minus engine time also includes loading, bookkeeping and teardown; it is not a pure startup measurement.

These fresh-process examples have different timing rules from LangArena's warmed computational regions. Raw samples, commands, artifact/source/compiler identities and engine versions are in [report.json](report.json). [Method and reproduction](../../../examples.md).
