"""Read-only independent postmeasurement arithmetic and identity audit."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import itertools
import json
import math
import statistics

ROOT = Path(__file__).resolve().parents[3]
BUILD = ROOT / 'build/next-runtime-hills'
OUT = Path(__file__).resolve().parent


def load(path):
    return json.loads(Path(path).read_bytes())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def pin(path):
    return {'path': str(Path(path).relative_to(ROOT)), 'sha256': sha(path)}


checked = 0


def check(values, recorded):
    global checked
    assert values and all(math.isfinite(x) for x in values)
    mid = statistics.median(values)
    assert recorded['n'] == len(values)
    assert recorded['median'] == mid
    assert recorded['mad'] == statistics.median(abs(x - mid) for x in values)
    assert recorded['samples'] == values
    for key, value in [('min', min(values)), ('max', max(values))]:
        if key in recorded:
            assert recorded[key] == value
    ordered = sorted(values)
    for key, fraction in [('p25', .25), ('p75', .75)]:
        at = (len(values) - 1) * fraction
        lo, hi = math.floor(at), math.ceil(at)
        value = ordered[lo] + (ordered[hi] - ordered[lo]) * (at - lo)
        if key in recorded:
            assert math.isclose(recorded[key], value, rel_tol=1e-14, abs_tol=1e-15)
    checked += 1


paths = {
    'wasmtime': 'delivered-warmed/report.json', 'v8': 'delivered-v8/report.json',
    'examples': 'current/examples/report.json', 'host': 'current/host/report.json',
    'langarena': 'current/langarena-resumed/report.json', 'lifecycle': 'current/lifecycle/report.json',
}
reports = {name: load(BUILD / path) for name, path in paths.items()}
selected = '8c09c1a6bcc782de5b86dda621a91ae234acba8fbe108d146582113eb6a110b6'
baseline = 'b431c62fdb28463c72a50c24fb41fa28ff71262fb515a527b9fa903e933ca8a0'
delivery = load(BUILD / 'delivery-execution-resumed/report.json')
assert delivery['status'] == 'passed' and delivery['compiler_sha256'] == selected
assert delivery['input_sha256'] == delivery['input_sha256_after']
assert len(delivery['phases']) == 6
assert {Path(p['report']).resolve() for p in delivery['phases']} == {(BUILD / p).resolve() for p in paths.values()}
for p in delivery['phases']:
    assert p['status'] == 'passed' and p['exit_status'] == 0
    assert sha(p['report']) == p['report_sha256']
    assert sha(BUILD / 'delivery-execution-resumed' / (p['name'] + '.stdout')) == p['stdout_sha256']
    assert sha(BUILD / 'delivery-execution-resumed' / (p['name'] + '.stderr')) == p['stderr_sha256']
for report in reports.values():
    assert report['status'] == 'passed' and not report.get('failures')

findings = {}
for engine in ['wasmtime', 'v8']:
    r = reports[engine]
    assert r['configuration']['samples'] == 9 and r['input_sha256'] == r['input_sha256_after']
    assert r['compilers']['baseline']['sha256'] == baseline and r['compilers']['final']['sha256'] == selected
    assert set(r['compilers']) == {'baseline', 'final'}
    indexed = {(x['task'], x['variant'], x['round']): x['timed_region_seconds']
               for x in r['observations'] if x['phase'] == 'measure'}
    expected = {(t, v, phase, i) for t, variants in r['artifacts'].items() for v in variants
                for phase, n in [('qualify', 1), ('measure', 9)] for i in range(n)}
    actual = [(x['task'], x['variant'], x['phase'], x['round']) for x in r['observations']]
    assert len(actual) == len(set(actual)) and set(actual) == expected
    for x in r['observations']:
        assert x['checksum'] == x['expected_checksum'] and x['runtime_affinity'] == [2]
        lines = (Path(x['log_directory']) / 'stdout.txt').read_text().splitlines()
        assert len(lines) == 2 and int(lines[0]) == x['checksum']
        assert int(lines[1]) / 1e9 == x['timed_region_seconds']
    task_findings = []
    for row in r['summary']:
        task = row['task']
        variants = list(r['artifacts'][task])
        for v in variants:
            check([indexed[task, v, i] for i in range(9)], row['times'][v])
        assert {(x['numerator'], x['denominator']) for x in row['paired_ratios']} == set(itertools.combinations(variants, 2))
        for p in row['paired_ratios']:
            values = [indexed[task, p['numerator'], i] / indexed[task, p['denominator'], i] for i in range(9)]
            assert p['per_round'] == [{'round': i, 'ratio': v} for i, v in enumerate(values)]
            check(values, p['ratio'])
        for v in ['baseline', 'final']:
            artifact = r['artifacts'][task][v]
            assert sha(artifact['path']) == artifact['sha256']
            if engine == 'wasmtime':
                assert sha(artifact['aot_path']) == artifact['aot_sha256']
        paired = next(p['ratio'] for p in row['paired_ratios'] if p['numerator'] == 'baseline' and p['denominator'] == 'final')
        task_findings.append({'task': task, 'baseline_ms': row['times']['baseline']['median'] * 1000,
                              'final_ms': row['times']['final']['median'] * 1000,
                              'paired_speedup': paired['median'], 'mad': paired['mad'],
                              'guest_identical': r['artifacts'][task]['baseline']['sha256'] == r['artifacts'][task]['final']['sha256']})
    for g in r['geometric_ratios']:
        values = []
        for i in range(9):
            ratios = []
            for task in g['tasks']:
                target = g['denominator']
                if g['kind'] == 'reference_role':
                    target = r['reference_roles'][task][target]
                ratios.append(indexed[task, g['numerator'], i] / indexed[task, target, i])
            values.append(math.exp(sum(map(math.log, ratios)) / len(ratios)))
        assert g['per_round'] == [{'round': i, 'ratio': v} for i, v in enumerate(values)]
        check(values, g['ratio'])
    assert sum(x['guest_identical'] for x in task_findings) == 8
    findings[engine] = {'tasks': task_findings, 'host_sha256': r['host_build']['host_sha256']}

ex, host, arena, lifecycle = [reports[k] for k in ['examples', 'host', 'langarena', 'lifecycle']]
for r, count in [(ex, 1600), (host, 1440), (arena, 315), (lifecycle, 960)]:
    assert len(r['observations']) == count
for row in ex['compile_summary']:
    rows = [x for x in ex['observations'] if x['kind'] == 'build' and x['name'] == row['name'] and x['backend'] == row['backend']]
    check([x['wall_seconds'] for x in rows], row['wall_seconds'])
for row in ex['runtime_summary']:
    rows = [x for x in ex['observations'] if x['kind'] == 'execution' and all(x[k] == row[k] for k in ['name', 'backend', 'engine'])]
    check([x['process_wall_seconds'] for x in rows if x['phase'] == 'measure'], row['process_wall_seconds'])
    if row['engine'] != 'native':
        for metric, raw in [('entry_function_seconds', 'start_function_ns'), ('engine_compile_instantiate_seconds', 'compile_instantiate_ns')]:
            check([x['wasm_timing'][raw] / 1e9 for x in rows if x['phase'] == 'measure-engine'], row[metric])
for row in host['runtime_summary']:
    values = [x['wall_seconds'] for x in host['observations'] if x['phase'] == 'measure' and all(x[k] == row[k] for k in ['name', 'backend', 'mode'])]
    check(values, row['wall_seconds'])
assert len(host['preparation']) == 200
for row in host['preparation_summary']:
    check([x['wall_seconds'] for x in host['preparation'] if all(x[k] == row[k] for k in ['name', 'backend', 'configuration'])], row['wall_seconds'])
for row in arena['compile_summary']:
    check([x['wall_seconds'] for x in arena['observations'] if x['kind'] == 'build' and all(x[k] == row[k] for k in ['track', 'task', 'backend', 'phase'])], row['wall_seconds'])
for row in arena['runtime_summary']:
    rows = [x for x in arena['observations'] if x['kind'] == 'execution' and all(x[k] == row[k] for k in ['track', 'task', 'backend', 'engine', 'profile'])]
    for metric, raw in [('timed_region_seconds', 'timed_region_seconds'), ('process_wall_seconds', 'wall_seconds')]:
        check([x[raw] for x in rows], row[metric])
    for metric, raw in [('entry_function_seconds', 'start_function_ns'), ('engine_compile_instantiate_seconds', 'compile_instantiate_ns')]:
        if row[metric] is not None:
            check([x['engine_timing'][raw] / 1e9 for x in rows if 'engine_timing' in x], row[metric])
for case in lifecycle['examples']:
    for mode, s in case['modes'].items():
        vals = [x['wall_seconds'] for x in lifecycle['observations'] if x['name'] == case['name'] and x['mode'] == mode and x['phase'] == 'measure']
        check(vals, {'n': s['n'], 'median': s['median_seconds'], 'mad': s['mad_seconds'], 'samples': s['samples_seconds']})

analysis = load(BUILD / 'module-analysis.json')
assert analysis['compiler_sha256'] == selected and analysis['baseline_compiler_sha256'] == baseline
assert not [x['task'] for x in analysis['examples'] if not x['byte_identical']]
for row in analysis['examples'] + analysis['warmed']:
    for v in ['baseline', 'final']:
        a = row[v]
        assert sha(a['wasm']) == a['sha256'] and Path(a['wasm']).stat().st_size == a['bytes']
        assert sha(a['disassembly']) == a['disassembly_sha256']
    assert row['byte_identical'] == (row['baseline']['sha256'] == row['final']['sha256'])
    assert row['bytes_delta'] == row['final']['bytes'] - row['baseline']['bytes']
source = load(BUILD / 'final/source.json')
assert len(source['headers']) == 37 and len(source['patches']) == 2
for name, value in source['headers'].items():
    assert sha(ROOT / 'compiler' / name) == value
for name, value in source['patches'].items():
    assert sha(ROOT / name) == value

# Exact matrices, not just aggregate row counts.
names = {x['name'] for x in ex['examples']}
pairs = [('native', 'native'), ('direct', 'v8'), ('direct', 'wasmtime'),
         ('c-wasm', 'v8'), ('c-wasm', 'wasmtime')]
expected = {(n, 'build', b, None, None, i) for n in names
            for b in ['native', 'direct', 'c-wasm'] for i in range(5)}
expected.update((n, 'execution', b, e, phase, i) for n in names for b, e in pairs
                for phase, length in [('warmup', 1), ('measure', 15)]
                for i in range(length))
expected.update((n, 'execution', b, e, 'measure-engine', i) for n in names
                for b, e in pairs if b != 'native' for i in range(15))

def matrix(rows, keys, expected):
    actual = [tuple(row.get(k) for k in keys) for row in rows]
    assert len(actual) == len(set(actual)) and set(actual) == expected

matrix([x for x in ex['observations'] if x.get('phase') != 'qualification'],
       ['name', 'kind', 'backend', 'engine', 'phase', 'sample'], expected)
matrix([x for x in ex['observations'] if x.get('phase') == 'qualification'],
       ['name', 'backend', 'engine'], {(n, b, e) for n in names for b, e in pairs})
host_modes = [('native', 'native-C')]
host_modes.extend((b, m) for b in ['direct', 'c-wasm']
                  for m in ['python', 'native', 'native-serial', 'precompiled'])
matrix(host['observations'], ['name', 'backend', 'mode', 'phase', 'sample'],
       {(n, b, m, phase, i) for n in names for b, m in host_modes
        for phase, length in [('warmup', 1), ('measure', 15)] for i in range(length)})
matrix(host['preparation'], ['name', 'backend', 'configuration', 'sample'],
       {(n, b, c, i) for n in names for b in ['direct', 'c-wasm']
        for c in ['parallel', 'serial'] for i in range(5)})
tasks = {x['task'] for x in arena['observations']}
assert len(tasks) == 7
expected = {('build', t, b, None, None, 'cold', i) for t in tasks
            for b in ['native', 'direct', 'c-wasm'] for i in range(5)}
expected.update(('execution', t, b, e, p, 'normal', i) for t in tasks for b, e in pairs
                for p, length in [('test', 1), ('run', 5)] for i in range(length))
matrix(arena['observations'], ['kind', 'task', 'backend', 'engine', 'profile', 'phase', 'sample'], expected)
assert {x['track'] for x in arena['observations']} == {'adapted'}
matrix([dict(x, sample=x.get('sample', 0)) for x in lifecycle['observations']],
       ['name', 'mode', 'phase', 'sample'],
       {(n, m, p, i) for n in names
        for m in ['ordinary', 'cache-miss', 'cache-hit', 'precompiled', 'native-C', 'worker-hit']
        for p, length in [('warmup', 1), ('measure', 15)] for i in range(length)})

goldens = {x['name']: ROOT / 'examples' / x['expected'] for x in ex['examples']}
golden_sha = {n: sha(p) for n, p in goldens.items()}
artifact_checks = 0
seen_files = {}

def artifact(path, digest):
    global artifact_checks
    path = Path(path)
    if path not in seen_files:
        seen_files[path] = sha(path)
    assert seen_files[path] == digest, str(path)
    artifact_checks += 1

for r in [ex, host, arena]:
    assert r['environment']['compiler_sha256'] == selected
assert ex['environment']['compiler_source_identity']['headers'] == source['headers']
assert lifecycle['environment']['compiler_source_identity']['headers'] == source['headers']
for x in ex['observations']:
    assert x['status'] == 'passed'
    if x['kind'] == 'build':
        artifact(x['artifact'], x['artifact_sha256'])
        if x['backend'] != 'native':
            assert x['artifact_sha256'] == x['driver_stats']['module_sha256']
    else:
        assert x['stdout_sha256'] == golden_sha[x['name']]
for x in host['observations']:
    assert x['exit_code'] == 0 and x['stdout_sha256'] == golden_sha[x['name']]
    if x['mode'] in ['native', 'native-serial']:
        assert '--no-cache' in x['command'] and '--cache-config' not in x['command']
for x in host['preparation']:
    assert '--no-cache' in x['command'] and '--cache-config' not in x['command']
    artifact(x['artifact'], x['sha256'])
for x in arena['observations']:
    assert x['status'] == 'passed' and x['returncode'] == 0 and not x['error']
    if x['kind'] == 'build':
        artifact(x['artifact'], x['artifact_sha256'])
    else:
        lines = x['stdout'].splitlines()
        assert int(lines[0]) == x['checksum'] == x['expected_checksum']
        assert int(lines[1]) / 1e9 == x['timed_region_seconds'] and x['revision_exit'] == 0
for x in lifecycle['observations']:
    assert x['returncode'] == 0 and x['stderr_empty']
    assert x['wall_ns'] / 1e9 == x['wall_seconds']
    if x['mode'] == 'worker-hit':
        assert x['stdout_sha256'] == golden_sha[x['name']] and x['cache_hit'] is True
        assert x['process_command'][1:] == ['--serve', '--no-cache']
    else:
        assert x['stdout'].encode() == goldens[x['name']].read_bytes() and x['golden_match']
        if 'status' in x:
            assert x['status'] == 'passed'
        if x['mode'] == 'ordinary':
            assert '--no-cache' in x['command']
for name, x in lifecycle['worker_lifecycle'].items():
    assert x['first_stdout'].encode() == goldens[name].read_bytes()
    assert x['first_returncode'] == 0 and not x['first_stderr'] and x['first_cache_hit'] is False
    assert x['resident_process_count'] == 1
for x in lifecycle['examples']:
    for a in x['artifacts'].values():
        artifact(a['path'], a['sha256'])
for x in lifecycle['preparation'].values():
    artifact(x['precompiled'], x['precompiled_sha256'])
    artifact(x['cache_config'], x['cache_config_sha256'])

host_by_round = {(x['name'], x['backend'], x['mode'], x['sample']): x['wall_seconds']
                 for x in host['observations'] if x['phase'] == 'measure'}
for x in host['paired_speedup']:
    check([host_by_round[x['name'], x['backend'], x['reference'], i] /
           host_by_round[x['name'], x['backend'], x['mode'], i] for i in range(15)], x['speedup'])
for engine in ['wasmtime', 'v8']:
    r = reports[engine]
    workloads = {w['name']: w for w in r['workloads']}
    for variants in r['artifacts'].values():
        for x in variants.values():
            artifact(x['path'], x['sha256'])
            if x.get('aot_path'):
                artifact(x['aot_path'], x['aot_sha256'])
    for x in r['observations']:
        assert x['revision_exit'] == 0
        assert x['expected_checksum'] == workloads[x['task']][x['profile']]['checksum']
        assert x['artifact_sha256'] == r['artifacts'][x['task']][x['variant']]['sha256']
    for w in r['workloads']:
        assert sha(w['source']) == r['input_sha256'][w['source']]
    assert [x['task'] for x in findings[engine]['tasks'] if not x['guest_identical']] == ['Sort::Quick', 'Hash::SHA256']
assert [(x['task'], x['bytes_delta']) for x in analysis['examples'] if not x['byte_identical']] == []
assert [(x['task'], x['bytes_delta']) for x in analysis['warmed'] if not x['byte_identical']] == [('Sort::Quick', 124), ('Hash::SHA256', -13)]
for left, right in zip(delivery['phases'], delivery['phases'][1:]):
    assert left['finished_utc'] <= right['started_utc']

qualification = load(BUILD / 'qualification/summary.json')
assert qualification['status'] == 'passed' and qualification['compiler_sha256'] == selected
assert qualification['input_pins_rechecked'] and qualification['input_pins'] == 1487
assert qualification['coverage'] == {'focused_commands': 77, 'cases': 978,
    'differential_observations': 9573, 'native_stdout_comparisons': 7656,
    'host_observations': 11484, 'host_unique_wasm': 1574, 'worker_observations': 3001,
    'worker_underlying_aliases': 3828, 'worker_unique_wasm': 1574}
for p in qualification['reports'].values():
    artifact(p['path'], p['sha256'])
for name in ['focused', 'differential', 'host', 'worker-replay']:
    p = BUILD / 'qualification/attempt-1' / name / 'report.json'
    assert sha(p) == delivery['input_sha256'][str(p)]
nums = load(BUILD / 'final-numbers.json')
campaign = load(BUILD / 'campaign.json')
assert campaign['numbers_sha256'] == sha(BUILD / 'final-numbers.json')
assert nums['compiler_sha256'] == campaign['compiler_sha256'] == selected
assert nums['baseline_compiler_sha256'] == campaign['baseline_compiler_sha256'] == baseline
assert nums['module_analysis'] == analysis and nums['lifecycle'] == lifecycle['examples']
for out_name, report_name in [('warmed', 'wasmtime'), ('v8', 'v8')]:
    assert nums['warmed'][out_name]['geometric_ratios'] == reports[report_name]['geometric_ratios']
    assert nums['warmed'][out_name]['tasks'] == [{k: r[k] for k in ['task', 'times', 'paired_ratios']}
                                              for r in reports[report_name]['summary']]
for name, value in nums['examples'].items():
    for key, rows in [('compile', ex['compile_summary']), ('python_v8_native', ex['runtime_summary']),
                      ('native_host', host['runtime_summary']), ('preparation', host['preparation_summary'])]:
        assert value[key] == [r for r in rows if r['name'] == name]
assert nums['langarena']['compile_summary'] == arena['compile_summary']
assert nums['langarena']['runtime_summary'] == arena['runtime_summary']
for backend, bounds in nums['langarena']['compile_ranges_ms'].items():
    vals = [r['wall_seconds']['median'] * 1000 for r in arena['compile_summary'] if r['backend'] == backend]
    assert bounds == {'min': min(vals), 'max': max(vals)}

# Explicit source/reference/engine boundaries and complete discarded-attempt exclusion.
reference_path = ROOT / 'build/runtime-reference/production/report.json'
assert sha(reference_path) == '06c1f5b883af43d5f5563416fec01d5a1ff5ec309a5005e3abb5293654e59350'
reference = load(reference_path)
assert reports['wasmtime']['selection'] == reference['selection']
assert reports['wasmtime']['workloads'] == reference['workloads']
for task, variants in reports['wasmtime']['artifacts'].items():
    task_id = next(w['id'] for w in reference['workloads'] if w['name'] == task)
    for variant, a in variants.items():
        if variant.startswith('ref--'):
            original = reference['artifacts'][task_id + '/' + variant.removeprefix('ref--')]
            assert a['sha256'] == original['sha256']
            if a.get('aot_path'):
                assert a['aot_sha256'] == original['aot_sha256']
source_checks = 0
for path, digest in delivery['input_sha256'].items():
    if Path(path).suffix in {'.py', '.mjs', '.json', '.h', '.c', '.cpp', '.goose', '.patch', '.sh'}:
        artifact(path, digest)
        source_checks += 1
engine_checks = {}
for path in [delivery['configuration']['host'], delivery['configuration']['node'],
             delivery['python_engine']['library'], delivery['compiler_root'] + '/bin/goose',
             reports['wasmtime']['configuration']['host']]:
    digest = delivery['input_sha256'].get(path)
    if digest is None:
        digest = reports['wasmtime']['input_sha256'][path]
    artifact(path, digest)
    engine_checks[path] = digest
assert host['host_build']['host_sha256'] == lifecycle['environment']['host_build']['host_sha256'] == delivery['host_build']['host_sha256']
assert host['host_build']['host_sha256'] == 'e303865d7661dc5d0dad1e1719753d1101bfe7f7e16d5b1eb2e174f416fbbf28'
assert reports['wasmtime']['host_build']['host_sha256'] == 'e0468623661130c89eec4902c287c1ec971928b75469a47303c3392733c51cd3'
assert host['python_engine']['library_sha256'] == delivery['python_engine']['library_sha256'] == '3127ca42fe7cdd3f0a43a358e79177dcfedd46c1746329826403b9d854de6178'
assert lifecycle['environment']['example_build_report_sha256'] == sha(BUILD / paths['examples'])
assert sha(lifecycle['environment']['host_build_metadata_path']) == lifecycle['environment']['host_build_metadata_sha256']
assert load(lifecycle['environment']['host_build_metadata_path']) == lifecycle['environment']['host_build']
assert all(v is None for v in delivery['environment']['controls'].values())
assert all(report.get(k, True) is True for report in [ex, arena] for k in ('source_hashes_still_match', 'compiler_hash_still_matches', 'artifact_hashes_still_match'))
# Recovered controller: four observed successes plus two freshly collected phases.
original_path = BUILD / 'delivery-execution/report.json'
original = load(original_path)
recovery = delivery['recovery']
assert original['status'] == 'running' and len(original['phases']) == 5
assert original['phases'][4]['name'] == 'langarena' and original['phases'][4]['status'] == 'running'
assert 'exit_status' not in original['phases'][4]
assert recovery['schema'] == 'goose-controller-recovery-v1' and recovery['status'] == 'passed'
assert recovery['original_coordinator'] == {'path': str(original_path), 'sha256': sha(original_path)}
assert recovery['retained_phase_records'] == original['phases'][:4] == delivery['phases'][:4]
assert len(recovery['retained_phase_records']) == 4
assert recovery['observed_tool_exit_status'] == 143 and recovery['termination_cause'] == 'unconfirmed'
assert recovery['original_input_pins_verified_before'] and recovery['original_input_pins_verified_after']
assert recovery['source_and_engine_changes'] is False
for key in ['compiler_sha256','compiler_root','host_build','python_engine','environment']:
    assert delivery[key] == original[key], key
for key,value in original['configuration'].items():
    if key != 'execution_dir': assert delivery['configuration'][key] == value
for path,value in original['input_sha256'].items():
    assert delivery['input_sha256'][path] == delivery['input_sha256_after'][path] == value
for row in original['phases'][:4]:
    for stream in ['stdout','stderr']:
        assert (BUILD/'delivery-execution'/(row['name']+'.'+stream)).read_bytes() == (BUILD/'delivery-execution-resumed'/(row['name']+'.'+stream)).read_bytes()
excluded = recovery['excluded_child']; old_arena = load(excluded['path'])
assert sha(excluded['path']) == excluded['sha256']
assert old_arena['status'] == excluded['observed_report_status'] == 'passed' and not old_arena['failures']
assert len(old_arena['observations']) == excluded['observations'] == 315
assert excluded['process_exit_status'] is None and excluded['primary_rows_used'] == 0
assert reports['langarena']['configuration']['output_dir'] != old_arena['configuration']['output_dir']
assert all(row['report'] != excluded['path'] for row in delivery['phases'])
assert recovery['final_phase_map'] == {p['name']:p['report'] for p in delivery['phases']}
assert delivery['planned_commands'][:4] == original['planned_commands'][:4]
for row,planned in zip(delivery['phases'],delivery['planned_commands']):
    assert row['command'] == planned['command'] and row['report'] == planned['report']
assert [p['name'] for p in delivery['phases'][4:]] == ['langarena','lifecycle']
assert recovery['resumed_utc'] <= delivery['phases'][4]['started_utc']
assert old_arena['finished_utc'] < delivery['phases'][4]['started_utc']
assert reports['langarena']['started_utc'] >= delivery['phases'][4]['started_utc']
completion_path = BUILD / 'delivery-execution-resumed/coordinator-completion.json'
completion = load(completion_path)
assert completion['status'] == 'passed' and completion['all_six_observed_exit_statuses'] == [0]*6
assert completion['report'] == str(BUILD/'delivery-execution-resumed/report.json')
assert completion['report_sha256'] == sha(completion['report'])
assert completion['finished_utc'] >= delivery['finished_utc']
qual_completion = load(BUILD/'qualification/completion.json')
assert qual_completion['status'] == 'passed' and qual_completion['input_pins'] == 1487
assert qual_completion['input_pins_rechecked'] and qual_completion['matched_control_binaries_rechecked'] == 8
assert qual_completion['coverage'] == qualification['coverage']
assert qual_completion['created_utc'] < delivery['phases'][0]['started_utc']
recovery_evidence = {'original_coordinator':pin(original_path), 'completion':pin(completion_path),
                     'retained_successful_phases':4,'recollected_phases':['langarena','lifecycle'],
                     'excluded_child':excluded,'termination_cause':'unconfirmed',
                     'original_pins_preserved':len(original['input_sha256']),
                     'exact_reused_rows_streams_and_environment_verified':True}
native_findings = {}
for task in ['Sort::Quick','Hash::SHA256']:
    row=next(x for x in reports['wasmtime']['summary'] if x['task']==task)
    role=reports['wasmtime']['reference_roles'][task]['selected_native']
    ratio=next(x['ratio'] for x in row['paired_ratios'] if x['numerator']=='final' and x['denominator']==role)
    native_findings[task]={'variant':role,'native_median_ms':row['times'][role]['median']*1000,'paired_direct_over_native':ratio}
review = {'schema': 'goose-leaf-and-loads-independent-arithmetic-v1', 'status': 'passed',
          'created_utc': datetime.now(timezone.utc).isoformat(), 'reviewer': 'astra_campaign',
          'compiler_sha256': selected, 'baseline_compiler_sha256': baseline,
          'scope': 'Independent read-only calculation from raw observations and exact guest/source identities; no compiler/test/engine execution. Final public prose/chart/archive review remains separate.',
          'summary_cells_recomputed': checked, 'cohorts': {k: len(v['observations']) for k, v in reports.items()},
          'exact_six_cohort_matrices_verified': True, 'host_preparations': 200,
          'artifact_identity_checks': artifact_checks, 'distinct_hashed_files': len(seen_files),
          'delivery_input_pins': len(delivery['input_sha256']),
          'current_source_input_checks': source_checks, 'engine_identity_checks': engine_checks,
          'controller_recovery': recovery_evidence,
          'collection_started_utc': delivery['started_utc'], 'collection_finished_utc': delivery['finished_utc'],
          'qualification': qualification['coverage'], 'qualification_input_pins': 1487,
          'selected_native_comparisons': native_findings,
          'warmed': findings, 'source_inventory': {'headers': 37, 'patches': 2},
          'interpretation': ['Only Quicksort and custom hash change among ten warmed guests; other eight byte-identical guests are controls.',
                             'All ten full-example direct modules remain byte-identical to baseline b431. Full-process differences in these independent cohorts are not compiler code-generation gains.',
                             'Wasmtime paired Quick/hash improve; V8 Quick is near flat and custom hash slightly below1 with spread covering the small shift. No V8 JIT mechanism is inferred without machine evidence.',
                             'Selected frozen native references apply only to these artifacts, inputs and machine profile; no universal ceiling claim.',
                             'Full-process host and lifecycle are separate nonpaired cohorts; no cross-cohort ratios or mixed native medians.',
                             'Warmed Wasmtime uses the frozen reference host; full host/lifecycle use canonical e303; Python library and static SDK identities remain separately pinned.',
                             'Resident worker includes IPC and fresh Store/instance, excludes resident startup/initial compilation. Ordinary fresh process is explicitly no-cache.',
                             'Controller termination cause is unconfirmed. Four observed exit0 phases are retained exactly; unobserved-exit old LangArena315rows contribute0primary; new LangArena plus lifecycle have recorded observed exit0.'],
          'inputs': [pin(BUILD / path) for path in paths.values()] + [pin(BUILD / 'delivery-execution-resumed/report.json'), pin(BUILD / 'module-analysis.json'), pin(BUILD / 'final-numbers.json'), pin(BUILD / 'campaign.json'), pin(BUILD / 'qualification/summary.json'), pin(BUILD / 'qualification/completion.json'), pin(completion_path), pin(original_path), pin(Path(excluded['path'])), pin(reference_path), pin(Path(__file__))],
          'blockers': []}
path = OUT / 'independent-arithmetic.json'
assert not path.exists()
path.write_text(json.dumps(review, indent=2) + '\n')
print(json.dumps({'status':'passed','summary_cells':checked,'review':pin(path),
                  'changed_tasks':{k:[x for x in v['tasks'] if not x['guest_identical']] for k,v in findings.items()},
                  'primary_observations':sum(len(r['observations']) for r in reports.values())},indent=2))
