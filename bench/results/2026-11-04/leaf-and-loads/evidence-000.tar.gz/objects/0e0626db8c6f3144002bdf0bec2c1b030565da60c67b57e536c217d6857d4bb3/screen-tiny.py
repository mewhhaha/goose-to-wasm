from pathlib import Path
import json,subprocess,sys
R=Path(__file__).resolve().parents[2]; B=R/'build/next-runtime-hills'
compilers=['--compiler','baseline='+str(R/'build/scan-hills/final/bin/goose'),'--compiler','hash='+str(B/'hash-load/bin/goose'),'--compiler','tiny='+str(B/'tiny-leaf/bin/goose')]
for engine,tool in [('wasmtime','measure_kernels.py'),('v8','measure_v8_kernels.py')]:
    command=[sys.executable,str(R/'build/functions-grow'/tool),*compilers,'--samples','5','--filter','Sort::Quick','--filter','Hash::SHA256','--filter','Sort::Merge','--output',str(B/('tiny-'+engine))]
    if engine=='v8':command+=['--node','/home/jacobt/.local/share/fnm/node-versions/v24.22.1/installation/bin/node']
    print('START',engine,flush=True)
    with (B/('tiny-'+engine+'.log')).open('w')as stream:subprocess.run(command,cwd=R,stdout=stream,stderr=subprocess.STDOUT,check=True)
    report=json.loads((B/('tiny-'+engine)/'report.json').read_bytes())
    print(json.dumps({'engine':engine,'status':report['status'],'summary':report['summary']},indent=2),flush=True)
