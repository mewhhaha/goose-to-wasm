#!/usr/bin/env python3
"""Build or reverify selected controls, with at most two two-job builds."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import argparse
import json
import time
from controls import CONTROLS, build, match, control_root, load

HERE=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output',type=Path,default=HERE/'controls-execution.json')
args=parser.parse_args()
if args.output.exists():raise RuntimeError('preserve the prior control execution report and choose --output')
plan=load(HERE/'plan.json')
if plan['status']!='approved' or not plan['selection']['selected_compiler_sha256']:raise RuntimeError('final selection and execution approval required')
if set(plan['controls'])!=set(CONTROLS):raise RuntimeError('planned control inventory differs')
if len(CONTROLS)!=plan['expected']['matched_controls']:raise RuntimeError('planned control count differs')
started=time.monotonic()
rows=[]
def execute(name):
    folder=control_root(name)
    print('START',name,flush=True)
    built=True
    if (folder/'build-execution.json').exists():
        match(folder)
        built=False
    else:build(folder)
    proof=load(folder/'build/control-toolchain-match.json')
    plan=load(HERE/'plan.json')
    selected=plan['selection']['selected_compiler_sha256']
    if plan['status']!='approved' or not selected:raise RuntimeError('final selection and execution approval required')
    if proof['selected_compiler_sha256']!=selected:raise RuntimeError('control belongs to another candidate: '+name)
    print('READY',name,flush=True)
    return {'control':name,'status':'passed','built_in_this_run':built}
with ThreadPoolExecutor(max_workers=2) as pool:
    futures={pool.submit(execute,name):name for name in CONTROLS}
    for future in as_completed(futures):
        try:rows.append(future.result())
        except Exception as error:rows.append({'control':futures[future],'status':'failed','error':repr(error)})
status='passed'
if any(row['status']!='passed' for row in rows):status='failed'
args.output.write_text(json.dumps({'status':status,'controls':rows,'maximum_concurrent_controls':2,'ninja_jobs_per_control':2,'wall_seconds':time.monotonic()-started},indent=2)+'\n')
raise SystemExit(status!='passed')
