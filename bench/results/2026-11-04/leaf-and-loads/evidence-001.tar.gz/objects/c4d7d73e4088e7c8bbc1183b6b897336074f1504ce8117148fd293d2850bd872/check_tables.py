"""Match documentation table cells by workload identity to current reports."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[2]
BUILD=ROOT/'build/next-runtime-hills'
PUBLIC=ROOT/'bench/results/2026-11-04/leaf-and-loads'

def load(path):return json.loads(path.read_bytes())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def table(path):
    rows={}
    for line in path.read_text().splitlines():
        if line.startswith('|'):
            cells=[c.strip() for c in line.split('|')[1:-1]]
            rows[cells[0]]=cells[1:]
    return rows

warmed=load(PUBLIC/'final-warmed.json');rows={r['task']:r for r in warmed['summary']}
doc=ROOT/'docs/RUNTIME_TARGETS.md';text=table(doc);checks=[]
labels={'Fannkuch':'CLBG::Fannkuchredux','Mandelbrot':'CLBG::Mandelbrot','Sieve':'Etc::Sieve',
    'CRC32':'Hash::CRC32','Custom hash':'Hash::SHA256','Merge sort':'Sort::Merge','Quicksort':'Sort::Quick',
    'Life adapter':'Example::Life','Insertion-sort adapter':'Example::Sorting','Sudoku adapter':'Example::Sudoku'}
for label,task in labels.items():
    row=rows[task];variants=['final',row['reference_roles']['selected_wasm'],row['reference_roles']['selected_native']]
    expected=[f"{row['times'][variant]['median']*1000:,.0f}" for variant in variants]
    assert text[label]==expected,(label,text[label],expected)
    checks.append({'document':str(doc.relative_to(ROOT)),'task':task,'cells':expected})
host=load(PUBLIC/'host.json');rows={(r['name'],r['backend'],r['mode']):r for r in host['runtime_summary']}
doc=ROOT/'bench/wasmtime-host.md';text=table(doc)
for label,task in [('Functions','functions'),('Sorting','sorting'),('Sudoku','sudoku'),('Life','life')]:
    expected=[]
    for backend,mode in [('direct','python'),('direct','native'),('direct','precompiled'),('native','native-C')]:
        expected.append(f"{rows[task,backend,mode]['wall_seconds']['median']*1000:.3f} ms")
    assert text[label]==expected,(label,text[label],expected)
    checks.append({'document':str(doc.relative_to(ROOT)),'task':task,'cells':expected})
report={'status':'passed','cells_checked':sum(len(r['cells']) for r in checks),'method':'Exact formatted cells matched by workload identity; no report-order zipping.',
    'checks':checks,'inputs':{str(p.relative_to(ROOT)):sha(p) for p in [PUBLIC/'final-warmed.json',PUBLIC/'host.json',ROOT/'docs/RUNTIME_TARGETS.md',ROOT/'bench/wasmtime-host.md']}}
(BUILD/'table-verification.json').write_text(json.dumps(report,indent=2)+'\n')
(PUBLIC/'table-verification.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS46document table cells')
