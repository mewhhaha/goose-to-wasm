"""Record the independently reviewed scan-lowering selection before qualification."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[2]
BUILD=ROOT/'build/scan-hills'
FINAL='b431c62fdb28463c72a50c24fb41fa28ff71262fb515a527b9fa903e933ca8a0'
BASELINE='f76ea0f4bfa57949f5b04d42884f8316546a7eb50720b31e564afafcad9a0af8'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
out=BUILD/'campaign-selection.json';assert not out.exists()
paths=[BUILD/(variant+'-'+engine)/'report.json' for variant in ('select','wide') for engine in ('wasmtime','v8')]
r={'schema':'goose-byte-scan-selection-v1','status':'selected','selected_root':str(BUILD/'final'),
   'selected_compiler_sha256':FINAL,'baseline_root':str(ROOT/'build/stride-hills/final'),
   'baseline_compiler_sha256':BASELINE,
   'scope':'Byte equality reductions select the last matching index without a mask branch and process two SIMD128 vectors per 32-byte group, followed by at most one 16-byte vector tail and the original scalar tail. Existing eligibility, complete span guards and debug/failed-guard behavior remain unchanged.',
   'decision':'Select the wide candidate: its total gain over the shipped compiler is clear on both engines. Select-only already gives about 13 percent without module growth; width adds a modest observed 2.8 percent Wasmtime / 4.0 percent V8 for 94 bytes. V8 width wins 3 of 5 rounds; that marginal result is a screen observation, not an established 5 percent hill or hardware attribution.',
   'criteria':'Repeated material primary-workload improvement, check both engines and investigate controls over 3 percent. Fresh final qualification and nine-pair delivery required; avoid overstating marginal screens.',
   'qualification_status_at_selection':'Pending final full 76-command corpus, host/worker replays and six fresh delivery cohorts.',
   'screens':{},'input_sha256':{str(p):sha(p) for p in paths},
   'retained_experiments':['last-select: isolated branchless choice, unchanged 3482-byte guest, valid smaller alternative.','wide-32: selected 3576-byte guest including a 16-byte vector tail; upper-bit and span proofs covered by expanded oracle fixtures.']}
for p in paths:
 v=json.loads(p.read_bytes());assert v['status']=='passed' and not v['failures'] and v['coverage_exact']
 assert v['input_sha256']==v['input_sha256_after'] and v['compilers']['baseline']['sha256']==BASELINE
 assert len({a['sha256'] for a in v['artifacts']['Sort::Merge'].values()})==1
 r['screens'][str(p.relative_to(BUILD))]={'report_sha256':sha(p),'observations':len(v['observations']),'summary':v['summary']}
 if p.parent.name.startswith('wide'):
  assert v['compilers']['wide']['sha256']==FINAL
  row=next(x for x in v['summary'] if x['task']=='Etc::Sieve')
  gain=next(x['ratio'] for x in row['paired_ratios'] if x['numerator']=='baseline' and x['denominator']=='wide')
  assert gain['median']>=1.05
m=json.loads((BUILD/'final/toolchain.json').read_bytes())
assert m['compiler_sha256']==FINAL and len(m['headers'])==36 and len(m['patches'])==2
assert sha(BUILD/'final/bin/goose')==sha(ROOT/'build/bin/goose')==FINAL
out.write_text(json.dumps(r,indent=2)+'\n')
print('Selected wide b431 with isolated select and width tradeoffs preserved.')
