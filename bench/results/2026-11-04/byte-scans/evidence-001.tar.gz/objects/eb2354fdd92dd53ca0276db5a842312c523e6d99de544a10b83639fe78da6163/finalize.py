#!/usr/bin/env python3
"""Summarize the sealed correctness run without replacing any evidence."""
from datetime import datetime, timezone
from pathlib import Path
import argparse
import json
import run as qualification
from controls import CONTROLS, control_root

HERE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', type=Path, default=HERE / 'attempt-1')
    parser.add_argument('--output', type=Path, default=HERE / 'summary.json')
    args = parser.parse_args()
    run = args.run.resolve()
    qualification.require(run.is_relative_to(HERE.resolve()), 'run must remain within this campaign')
    output = args.output.resolve()
    qualification.require(not output.exists(), 'refusing to replace qualification summary')
    load = qualification.load
    selected = load(run / 'selected.json')
    pins = load(run / 'input-pins.json')
    qualification.verify(run, selected, pins)
    gates = load(run / 'execution.json')
    focused = load(run / 'focused/report.json')
    differential = load(run / 'differential/report.json')
    host = load(run / 'host/report.json')
    worker = load(run / 'worker-replay/report.json')
    catalog = load(run / 'artifact-catalog.json')
    snapshot = load(Path(selected['source_snapshot']) / 'snapshot.json')
    qualification.require(gates['status'] == focused['status'] == worker['status'] == 'passed', 'qualification not passed')
    qualification.require(host['status'] == 'pass' and host['coverage_exact'] and worker['coverage_exact'], 'replay coverage differs')
    qualification.require(len(focused['commands']) == 76 and all(row['exit_status'] == 0 for row in focused['commands']), 'focused coverage differs')
    qualification.require(differential['cases'] == 978 and differential['observations'] == 9573 and differential['failures'] == 0, 'differential coverage differs')
    qualification.require(host['observations'] == 11484 and host['failures'] == worker['failures'] == 0, 'replay failures')
    qualification.require(worker['observations'] == worker['derived_effective_cases'] and worker['underlying_aliases'] == 3828, 'worker coverage differs')
    reports = {}
    for name in ['selected.json', 'input-pins.json', 'execution.json', 'focused/report.json',
                 'differential/report.json', 'host/report.json', 'worker-replay/report.json',
                 'host-execution.json', 'worker-execution.json', 'artifact-catalog.json']:
        path = run / name
        reports[name] = {'path': str(path), 'sha256': qualification.sha(path)}
    controls = {}
    for name in CONTROLS:
        path = control_root(name) / 'build-execution.json'
        row = load(path)
        qualification.require(row['exit_status'] == 0, 'control build failed: ' + name)
        controls[name] = {'path': str(path), 'sha256': qualification.sha(path),
                          'wall_seconds': row['wall_seconds']}
    summary = {
        'status': 'passed', 'created_utc': datetime.now(timezone.utc).isoformat(),
        'compiler_sha256': selected['compiler_sha256'],
        'host_sha256': host['host_build']['host_sha256'],
        'header_count': snapshot['header_count'], 'patch_count': snapshot['patch_count'],
        'input_pins': len(pins), 'input_pins_rechecked': True,
        'coverage': {'focused_commands': len(focused['commands']), 'cases': differential['cases'],
                     'differential_observations': differential['observations'],
                     'native_stdout_comparisons': differential['qualification_execution']['native_stdout_comparisons'],
                     'host_observations': host['observations'], 'host_unique_wasm': host['unique_wasm'],
                     'worker_observations': worker['observations'], 'worker_underlying_aliases': worker['underlying_aliases'],
                     'worker_unique_wasm': worker['unique_wasm']},
        'guest_catalog': {'fresh_paths': catalog['fresh_paths'], 'unique_objects': catalog['unique_objects']},
        'reports': reports,
        'durations': {
            'purpose': 'Correctness-run iteration evidence, not performance benchmark observations. Concurrent phase durations must not be added.',
            'gates_wall_seconds': gates['wall_seconds'],
            'gate_jobs': gates['observations'],
            'focused_command_sum_seconds': sum(row['wall_seconds'] for row in focused['commands']),
            'focused_commands': focused['commands'],
            'host': load(run / 'host-execution.json'),
            'worker': load(run / 'worker-execution.json'),
            'control_builds': controls,
            'unmeasured_overhead': 'Seal, catalog and final pin-check durations were not separately timed.'}}
    output.write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps({key: summary[key] for key in ['status', 'compiler_sha256', 'input_pins', 'coverage', 'guest_catalog']}, indent=2))


if __name__ == '__main__':
    main()
