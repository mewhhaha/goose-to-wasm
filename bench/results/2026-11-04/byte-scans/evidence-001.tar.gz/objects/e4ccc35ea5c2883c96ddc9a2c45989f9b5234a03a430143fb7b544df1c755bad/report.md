# LangArena qualification and measurements

Status: **passed**.

Upstream pin: `aab9b14998231ba905523b5ba3990ee03c46f64d`. Catalog: **50 tasks**. Adapted entrypoints: **7 tasks**, including six storage adaptations.

Mode: `measure`. Machine: AMD Ryzen 7 3800X, shared desktop host.
Compiler SHA-256: `b431c62fdb28463c72a50c24fb41fa28ff71262fb515a527b9fa903e933ca8a0`.

## Measurement contract

Whole-suite results use all original Goose kernel sources. The only staging patch changes the marker destination from `/tmp/recompile_marker` to a relative file inside the isolated run directory. The original checkout is hash-verified and never edited. Whole-suite compile times include all 50 tasks.

The adapted track uses the same seven port sources across native C, direct Wasm, and C-Wasm. Six ports replace growable storage; Fannkuch keeps its original fixed-array kernel. Official test/run inputs and checksums are unchanged. Preparation stays outside the clock; warmups mutate the same state used for measurement; the deterministic RNG is reset before measured iterations. Existing checksum work retains its original placement.

Cold builds and marker-edit builds launch fresh driver/compiler processes with `--no-cache`. OS caches and installed compiler/system-library caches are retained. A port marker edit changes its exit status from 0 to 1 after its two output lines, and the edited executable must retain the official checksum. Whole-suite edits change the actual marker file contents. Source bytes are restored in all cases. Optional unchanged cache hits are a separate phase. Edited sources still rerun the complete frontend.

The official whole-suite timer prints milliseconds; adapted ports print integer nanoseconds. Timed regions exclude process startup and preparation. Process wall time is retained separately. Sample counts below five are preliminary estimates; raw values and MAD are provided. These are local comparisons, not LangArena leaderboard scores or claims of complete direct-backend language support.

## Whole-suite compilation

| Backend | Phase | Samples | Median ms | MAD ms | Artifact bytes |
| --- | --- | ---: | ---: | ---: | ---: |

## Original-source correctness and runtime

| Task | Backend / engine | Profile | Samples | Region median ms | MAD ms | Process median ms |
| --- | --- | --- | ---: | ---: | ---: | ---: |

## Adapted workload compilation

| Task | Backend | Phase | Samples | Median ms | MAD ms | Artifact bytes |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| CLBG::Fannkuchredux | c-wasm | cold | 5 | 660.553 | 22.082 | 51975 |
| CLBG::Fannkuchredux | direct | cold | 5 | 69.488 | 0.325 | 3917 |
| CLBG::Fannkuchredux | native | cold | 5 | 290.899 | 4.294 | 22984 |
| CLBG::Mandelbrot | c-wasm | cold | 5 | 632.027 | 28.121 | 52049 |
| CLBG::Mandelbrot | direct | cold | 5 | 73.170 | 3.950 | 4467 |
| CLBG::Mandelbrot | native | cold | 5 | 271.131 | 5.980 | 23160 |
| Etc::Sieve | c-wasm | cold | 5 | 650.121 | 10.330 | 51597 |
| Etc::Sieve | direct | cold | 5 | 68.347 | 0.729 | 3576 |
| Etc::Sieve | native | cold | 5 | 294.133 | 10.761 | 23128 |
| Hash::CRC32 | c-wasm | cold | 5 | 649.265 | 29.802 | 51807 |
| Hash::CRC32 | direct | cold | 5 | 67.855 | 0.700 | 3132 |
| Hash::CRC32 | native | cold | 5 | 263.908 | 12.313 | 23008 |
| Hash::SHA256 | c-wasm | cold | 5 | 635.419 | 22.983 | 51822 |
| Hash::SHA256 | direct | cold | 5 | 70.780 | 2.061 | 6611 |
| Hash::SHA256 | native | cold | 5 | 308.341 | 21.913 | 23008 |
| Sort::Merge | c-wasm | cold | 5 | 649.609 | 26.556 | 52474 |
| Sort::Merge | direct | cold | 5 | 69.357 | 1.231 | 5527 |
| Sort::Merge | native | cold | 5 | 321.128 | 3.805 | 27416 |
| Sort::Quick | c-wasm | cold | 5 | 714.354 | 49.271 | 52033 |
| Sort::Quick | direct | cold | 5 | 68.726 | 1.159 | 4356 |
| Sort::Quick | native | cold | 5 | 280.295 | 10.253 | 23168 |

## Adapted workload runtime

| Task | Backend / engine | Profile | Samples | Region median ms | MAD ms | Engine compile + instantiate ms | Process median ms | Checksum |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| CLBG::Fannkuchredux | c-wasm / v8 | run | 5 | 2141.321 | 19.394 | 0.576 | 2597.058 | 135762480 |
| CLBG::Fannkuchredux | c-wasm / v8 | test | 1 | 0.021 | 0.000 | 0.592 | 28.871 | 4428 |
| CLBG::Fannkuchredux | c-wasm / wasmtime | run | 5 | 1502.337 | 4.254 | 23.251 | 1908.866 | 135762480 |
| CLBG::Fannkuchredux | c-wasm / wasmtime | test | 1 | 0.058 | 0.000 | 26.415 | 109.452 | 4428 |
| CLBG::Fannkuchredux | direct / v8 | run | 5 | 1290.078 | 5.120 | 0.299 | 1578.376 | 135762480 |
| CLBG::Fannkuchredux | direct / v8 | test | 1 | 0.038 | 0.000 | 0.284 | 30.612 | 4428 |
| CLBG::Fannkuchredux | direct / wasmtime | run | 5 | 1385.021 | 8.380 | 4.614 | 1747.559 | 135762480 |
| CLBG::Fannkuchredux | direct / wasmtime | test | 1 | 0.025 | 0.000 | 5.468 | 86.159 | 4428 |
| CLBG::Fannkuchredux | native / native | run | 5 | 1334.969 | 9.042 | — | 1583.753 | 135762480 |
| CLBG::Fannkuchredux | native / native | test | 1 | 0.022 | 0.000 | — | 1.119 | 4428 |
| CLBG::Mandelbrot | c-wasm / v8 | run | 5 | 964.225 | 6.572 | 0.555 | 1203.866 | 3455988829 |
| CLBG::Mandelbrot | c-wasm / v8 | test | 1 | 0.672 | 0.000 | 0.611 | 37.357 | 2236342953 |
| CLBG::Mandelbrot | c-wasm / wasmtime | run | 5 | 1081.811 | 3.136 | 24.051 | 1409.939 | 3455988829 |
| CLBG::Mandelbrot | c-wasm / wasmtime | test | 1 | 0.223 | 0.000 | 39.801 | 124.335 | 2236342953 |
| CLBG::Mandelbrot | direct / v8 | run | 5 | 985.097 | 4.231 | 0.242 | 1231.500 | 3455988829 |
| CLBG::Mandelbrot | direct / v8 | test | 1 | 0.361 | 0.000 | 0.238 | 25.628 | 2236342953 |
| CLBG::Mandelbrot | direct / wasmtime | run | 5 | 1026.769 | 14.146 | 4.208 | 1317.274 | 3455988829 |
| CLBG::Mandelbrot | direct / wasmtime | test | 1 | 0.188 | 0.000 | 3.723 | 113.784 | 2236342953 |
| CLBG::Mandelbrot | native / native | run | 5 | 942.850 | 5.418 | — | 1137.521 | 3455988829 |
| CLBG::Mandelbrot | native / native | test | 1 | 0.160 | 0.000 | — | 2.678 | 2236342953 |
| Etc::Sieve | c-wasm / v8 | run | 5 | 6538.181 | 288.169 | 0.634 | 7699.797 | 1042248060 |
| Etc::Sieve | c-wasm / v8 | test | 1 | 0.020 | 0.000 | 0.698 | 30.080 | 4660 |
| Etc::Sieve | c-wasm / wasmtime | run | 5 | 5453.626 | 3.919 | 23.546 | 6653.929 | 1042248060 |
| Etc::Sieve | c-wasm / wasmtime | test | 1 | 0.047 | 0.000 | 24.344 | 107.924 | 4660 |
| Etc::Sieve | direct / v8 | run | 5 | 743.315 | 2.206 | 0.271 | 925.857 | 1042248060 |
| Etc::Sieve | direct / v8 | test | 1 | 0.005 | 0.000 | 0.348 | 27.314 | 4660 |
| Etc::Sieve | direct / wasmtime | run | 5 | 752.938 | 4.583 | 4.043 | 988.509 | 1042248060 |
| Etc::Sieve | direct / wasmtime | test | 1 | 0.018 | 0.000 | 3.983 | 85.284 | 4660 |
| Etc::Sieve | native / native | run | 5 | 874.135 | 2.317 | — | 1053.738 | 1042248060 |
| Etc::Sieve | native / native | test | 1 | 0.005 | 0.000 | — | 3.914 | 4660 |
| Hash::CRC32 | c-wasm / v8 | run | 5 | 462.875 | 2.650 | 0.602 | 592.297 | 2318723244 |
| Hash::CRC32 | c-wasm / v8 | test | 1 | 0.015 | 0.000 | 0.698 | 28.782 | 3031698216 |
| Hash::CRC32 | c-wasm / wasmtime | run | 5 | 411.867 | 4.919 | 24.330 | 606.092 | 2318723244 |
| Hash::CRC32 | c-wasm / wasmtime | test | 1 | 0.053 | 0.000 | 24.097 | 108.350 | 3031698216 |
| Hash::CRC32 | direct / v8 | run | 5 | 508.493 | 2.108 | 0.242 | 653.763 | 2318723244 |
| Hash::CRC32 | direct / v8 | test | 1 | 0.034 | 0.000 | 0.365 | 52.160 | 3031698216 |
| Hash::CRC32 | direct / wasmtime | run | 5 | 440.676 | 1.690 | 3.920 | 619.754 | 2318723244 |
| Hash::CRC32 | direct / wasmtime | test | 1 | 0.025 | 0.000 | 3.879 | 85.464 | 3031698216 |
| Hash::CRC32 | native / native | run | 5 | 1376.440 | 7.785 | — | 1656.769 | 2318723244 |
| Hash::CRC32 | native / native | test | 1 | 0.057 | 0.000 | — | 2.702 | 3031698216 |
| Hash::SHA256 | c-wasm / v8 | run | 5 | 1056.867 | 8.606 | 0.663 | 1322.495 | 2844672256 |
| Hash::SHA256 | c-wasm / v8 | test | 1 | 0.010 | 0.000 | 0.637 | 39.122 | 1036619072 |
| Hash::SHA256 | c-wasm / wasmtime | run | 5 | 960.795 | 7.550 | 24.074 | 1271.977 | 2844672256 |
| Hash::SHA256 | c-wasm / wasmtime | test | 1 | 0.045 | 0.000 | 23.863 | 136.037 | 1036619072 |
| Hash::SHA256 | direct / v8 | run | 5 | 268.085 | 1.964 | 0.293 | 365.586 | 2844672256 |
| Hash::SHA256 | direct / v8 | test | 1 | 0.004 | 0.000 | 0.386 | 43.736 | 1036619072 |
| Hash::SHA256 | direct / wasmtime | run | 5 | 336.186 | 2.295 | 6.698 | 498.323 | 2844672256 |
| Hash::SHA256 | direct / wasmtime | test | 1 | 0.018 | 0.000 | 6.362 | 112.470 | 1036619072 |
| Hash::SHA256 | native / native | run | 5 | 607.058 | 2.769 | — | 732.734 | 2844672256 |
| Hash::SHA256 | native / native | test | 1 | 0.003 | 0.000 | — | 2.513 | 1036619072 |
| Sort::Merge | c-wasm / v8 | run | 5 | 1330.167 | 4.764 | 0.560 | 1632.942 | 61757772 |
| Sort::Merge | c-wasm / v8 | test | 1 | 12.846 | 0.000 | 0.583 | 54.114 | 2548773 |
| Sort::Merge | c-wasm / wasmtime | run | 5 | 2728.216 | 37.697 | 25.219 | 3388.283 | 61757772 |
| Sort::Merge | c-wasm / wasmtime | test | 1 | 25.779 | 0.000 | 26.030 | 148.917 | 2548773 |
| Sort::Merge | direct / v8 | run | 5 | 1453.259 | 4.822 | 0.287 | 1781.783 | 61757772 |
| Sort::Merge | direct / v8 | test | 1 | 20.770 | 0.000 | 0.412 | 83.738 | 2548773 |
| Sort::Merge | direct / wasmtime | run | 5 | 1526.379 | 2.656 | 4.190 | 1920.246 | 61757772 |
| Sort::Merge | direct / wasmtime | test | 1 | 14.055 | 0.000 | 4.953 | 109.051 | 2548773 |
| Sort::Merge | native / native | run | 5 | 1416.830 | 7.802 | — | 1705.555 | 61757772 |
| Sort::Merge | native / native | test | 1 | 13.498 | 0.000 | — | 23.103 | 2548773 |
| Sort::Quick | c-wasm / v8 | run | 5 | 1414.704 | 5.699 | 0.604 | 1753.709 | 61757772 |
| Sort::Quick | c-wasm / v8 | test | 1 | 14.848 | 0.000 | 0.691 | 57.448 | 2548773 |
| Sort::Quick | c-wasm / wasmtime | run | 5 | 1633.252 | 9.889 | 25.297 | 2069.771 | 61757772 |
| Sort::Quick | c-wasm / wasmtime | test | 1 | 16.429 | 0.000 | 24.228 | 161.480 | 2548773 |
| Sort::Quick | direct / v8 | run | 5 | 1366.470 | 6.002 | 0.292 | 1674.838 | 61757772 |
| Sort::Quick | direct / v8 | test | 1 | 13.228 | 0.000 | 0.279 | 52.989 | 2548773 |
| Sort::Quick | direct / wasmtime | run | 5 | 1693.729 | 58.685 | 3.970 | 2101.150 | 61757772 |
| Sort::Quick | direct / wasmtime | test | 1 | 15.482 | 0.000 | 4.425 | 109.004 | 2548773 |
| Sort::Quick | native / native | run | 5 | 1221.329 | 11.248 | — | 1481.126 | 61757772 |
| Sort::Quick | native / native | test | 1 | 11.821 | 0.000 | — | 20.551 | 2548773 |

## Qualification and limits

- Seven adapted entrypoints (six change storage, one changes only the harness) are a subset of the 50-task catalog; they do not establish unmodified whole-suite Wasm support.
- No local result is a LangArena leaderboard rank: source/compiler versions, target layout, host, flags, and coverage differ.
- Cold builds retain OS and compiler system-library caches; they are complete uncached driver builds, not disk-cold experiments.

The full 50-task coverage matrix, raw commands/output, source and artifact hashes, tool versions, input values, environment overrides (including `EM_NODE_JS`), and phase timings are in `report.json` and adjacent logs. `Hash::SHA256` retains LangArena's custom hash workload; it is not standard cryptographic SHA-256.
