"""Read-only independent postmeasurement arithmetic and identity audit."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import itertools
import json
import math
import statistics

ROOT = Path(__file__).resolve().parents[3]
BUILD = ROOT / 'build/scan-hills'
OUT = Path(__file__).resolve().parent


def load(path):
    return json.loads(Path(path).read_bytes())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def pin(path):
    return {'path': str(Path(path).relative_to(ROOT)), 'sha256': sha(path)}


checked = 0


def check(values, recorded):
    global checked
    assert values and all(math.isfinite(x) for x in values)
    mid = statistics.median(values)
    assert recorded['n'] == len(values)
    assert recorded['median'] == mid
    assert recorded['mad'] == statistics.median(abs(x - mid) for x in values)
    assert recorded['samples'] == values
    for key, value in [('min', min(values)), ('max', max(values))]:
        if key in recorded:
            assert recorded[key] == value
    ordered = sorted(values)
    for key, fraction in [('p25', .25), ('p75', .75)]:
        at = (len(values) - 1) * fraction
        lo, hi = math.floor(at), math.ceil(at)
        value = ordered[lo] + (ordered[hi] - ordered[lo]) * (at - lo)
        if key in recorded:
            assert math.isclose(recorded[key], value, rel_tol=1e-14, abs_tol=1e-15)
    checked += 1


paths = {
    'wasmtime': 'delivered-warmed/report.json', 'v8': 'delivered-v8/report.json',
    'examples': 'current/examples/report.json', 'host': 'current/host/report.json',
    'langarena': 'current/langarena/report.json', 'lifecycle': 'current/lifecycle/report.json',
}
reports = {name: load(BUILD / path) for name, path in paths.items()}
selected = 'b431c62fdb28463c72a50c24fb41fa28ff71262fb515a527b9fa903e933ca8a0'
baseline = 'f76ea0f4bfa57949f5b04d42884f8316546a7eb50720b31e564afafcad9a0af8'
delivery = load(BUILD / 'delivery-execution/report.json')
assert delivery['status'] == 'passed' and delivery['compiler_sha256'] == selected
assert delivery['input_sha256'] == delivery['input_sha256_after']
assert len(delivery['phases']) == 6
assert {Path(p['report']).resolve() for p in delivery['phases']} == {(BUILD / p).resolve() for p in paths.values()}
for p in delivery['phases']:
    assert p['status'] == 'passed' and p['exit_status'] == 0
    assert sha(p['report']) == p['report_sha256']
    assert sha(BUILD / 'delivery-execution' / (p['name'] + '.stdout')) == p['stdout_sha256']
    assert sha(BUILD / 'delivery-execution' / (p['name'] + '.stderr')) == p['stderr_sha256']
for report in reports.values():
    assert report['status'] == 'passed' and not report.get('failures')

findings = {}
for engine in ['wasmtime', 'v8']:
    r = reports[engine]
    assert r['configuration']['samples'] == 9 and r['input_sha256'] == r['input_sha256_after']
    assert r['compilers']['baseline']['sha256'] == baseline and r['compilers']['final']['sha256'] == selected
    assert set(r['compilers']) == {'baseline', 'final'}
    indexed = {(x['task'], x['variant'], x['round']): x['timed_region_seconds']
               for x in r['observations'] if x['phase'] == 'measure'}
    expected = {(t, v, phase, i) for t, variants in r['artifacts'].items() for v in variants
                for phase, n in [('qualify', 1), ('measure', 9)] for i in range(n)}
    actual = [(x['task'], x['variant'], x['phase'], x['round']) for x in r['observations']]
    assert len(actual) == len(set(actual)) and set(actual) == expected
    for x in r['observations']:
        assert x['checksum'] == x['expected_checksum'] and x['runtime_affinity'] == [2]
        lines = (Path(x['log_directory']) / 'stdout.txt').read_text().splitlines()
        assert len(lines) == 2 and int(lines[0]) == x['checksum']
        assert int(lines[1]) / 1e9 == x['timed_region_seconds']
    task_findings = []
    for row in r['summary']:
        task = row['task']
        variants = list(r['artifacts'][task])
        for v in variants:
            check([indexed[task, v, i] for i in range(9)], row['times'][v])
        assert {(x['numerator'], x['denominator']) for x in row['paired_ratios']} == set(itertools.combinations(variants, 2))
        for p in row['paired_ratios']:
            values = [indexed[task, p['numerator'], i] / indexed[task, p['denominator'], i] for i in range(9)]
            assert p['per_round'] == [{'round': i, 'ratio': v} for i, v in enumerate(values)]
            check(values, p['ratio'])
        for v in ['baseline', 'final']:
            artifact = r['artifacts'][task][v]
            assert sha(artifact['path']) == artifact['sha256']
            if engine == 'wasmtime':
                assert sha(artifact['aot_path']) == artifact['aot_sha256']
        paired = next(p['ratio'] for p in row['paired_ratios'] if p['numerator'] == 'baseline' and p['denominator'] == 'final')
        task_findings.append({'task': task, 'baseline_ms': row['times']['baseline']['median'] * 1000,
                              'final_ms': row['times']['final']['median'] * 1000,
                              'paired_speedup': paired['median'], 'mad': paired['mad'],
                              'guest_identical': r['artifacts'][task]['baseline']['sha256'] == r['artifacts'][task]['final']['sha256']})
    for g in r['geometric_ratios']:
        values = []
        for i in range(9):
            ratios = []
            for task in g['tasks']:
                target = g['denominator']
                if g['kind'] == 'reference_role':
                    target = r['reference_roles'][task][target]
                ratios.append(indexed[task, g['numerator'], i] / indexed[task, target, i])
            values.append(math.exp(sum(map(math.log, ratios)) / len(ratios)))
        assert g['per_round'] == [{'round': i, 'ratio': v} for i, v in enumerate(values)]
        check(values, g['ratio'])
    assert sum(x['guest_identical'] for x in task_findings) == 9
    findings[engine] = {'tasks': task_findings, 'host_sha256': r['host_build']['host_sha256']}

ex, host, arena, lifecycle = [reports[k] for k in ['examples', 'host', 'langarena', 'lifecycle']]
for r, count in [(ex, 1600), (host, 1440), (arena, 315), (lifecycle, 960)]:
    assert len(r['observations']) == count
for row in ex['compile_summary']:
    rows = [x for x in ex['observations'] if x['kind'] == 'build' and x['name'] == row['name'] and x['backend'] == row['backend']]
    check([x['wall_seconds'] for x in rows], row['wall_seconds'])
for row in ex['runtime_summary']:
    rows = [x for x in ex['observations'] if x['kind'] == 'execution' and all(x[k] == row[k] for k in ['name', 'backend', 'engine'])]
    check([x['process_wall_seconds'] for x in rows if x['phase'] == 'measure'], row['process_wall_seconds'])
    if row['engine'] != 'native':
        for metric, raw in [('entry_function_seconds', 'start_function_ns'), ('engine_compile_instantiate_seconds', 'compile_instantiate_ns')]:
            check([x['wasm_timing'][raw] / 1e9 for x in rows if x['phase'] == 'measure-engine'], row[metric])
for row in host['runtime_summary']:
    values = [x['wall_seconds'] for x in host['observations'] if x['phase'] == 'measure' and all(x[k] == row[k] for k in ['name', 'backend', 'mode'])]
    check(values, row['wall_seconds'])
assert len(host['preparation']) == 200
for row in host['preparation_summary']:
    check([x['wall_seconds'] for x in host['preparation'] if all(x[k] == row[k] for k in ['name', 'backend', 'configuration'])], row['wall_seconds'])
for row in arena['compile_summary']:
    check([x['wall_seconds'] for x in arena['observations'] if x['kind'] == 'build' and all(x[k] == row[k] for k in ['track', 'task', 'backend', 'phase'])], row['wall_seconds'])
for row in arena['runtime_summary']:
    rows = [x for x in arena['observations'] if x['kind'] == 'execution' and all(x[k] == row[k] for k in ['track', 'task', 'backend', 'engine', 'profile'])]
    for metric, raw in [('timed_region_seconds', 'timed_region_seconds'), ('process_wall_seconds', 'wall_seconds')]:
        check([x[raw] for x in rows], row[metric])
    for metric, raw in [('entry_function_seconds', 'start_function_ns'), ('engine_compile_instantiate_seconds', 'compile_instantiate_ns')]:
        if row[metric] is not None:
            check([x['engine_timing'][raw] / 1e9 for x in rows if 'engine_timing' in x], row[metric])
for case in lifecycle['examples']:
    for mode, s in case['modes'].items():
        vals = [x['wall_seconds'] for x in lifecycle['observations'] if x['name'] == case['name'] and x['mode'] == mode and x['phase'] == 'measure']
        check(vals, {'n': s['n'], 'median': s['median_seconds'], 'mad': s['mad_seconds'], 'samples': s['samples_seconds']})

analysis = load(BUILD / 'module-analysis.json')
assert analysis['compiler_sha256'] == selected and analysis['baseline_compiler_sha256'] == baseline
assert not [x['task'] for x in analysis['examples'] if not x['byte_identical']]
for row in analysis['examples'] + analysis['warmed']:
    for v in ['baseline', 'final']:
        a = row[v]
        assert sha(a['wasm']) == a['sha256'] and Path(a['wasm']).stat().st_size == a['bytes']
        assert sha(a['disassembly']) == a['disassembly_sha256']
    assert row['byte_identical'] == (row['baseline']['sha256'] == row['final']['sha256'])
    assert row['bytes_delta'] == row['final']['bytes'] - row['baseline']['bytes']
source = load(BUILD / 'final/source.json')
assert len(source['headers']) == 36 and len(source['patches']) == 2
for name, value in source['headers'].items():
    assert sha(ROOT / 'compiler' / name) == value
for name, value in source['patches'].items():
    assert sha(ROOT / name) == value

# Exact matrices, not just aggregate row counts.
names = {x['name'] for x in ex['examples']}
pairs = [('native', 'native'), ('direct', 'v8'), ('direct', 'wasmtime'),
         ('c-wasm', 'v8'), ('c-wasm', 'wasmtime')]
expected = {(n, 'build', b, None, None, i) for n in names
            for b in ['native', 'direct', 'c-wasm'] for i in range(5)}
expected.update((n, 'execution', b, e, phase, i) for n in names for b, e in pairs
                for phase, length in [('warmup', 1), ('measure', 15)]
                for i in range(length))
expected.update((n, 'execution', b, e, 'measure-engine', i) for n in names
                for b, e in pairs if b != 'native' for i in range(15))

def matrix(rows, keys, expected):
    actual = [tuple(row.get(k) for k in keys) for row in rows]
    assert len(actual) == len(set(actual)) and set(actual) == expected

matrix([x for x in ex['observations'] if x.get('phase') != 'qualification'],
       ['name', 'kind', 'backend', 'engine', 'phase', 'sample'], expected)
matrix([x for x in ex['observations'] if x.get('phase') == 'qualification'],
       ['name', 'backend', 'engine'], {(n, b, e) for n in names for b, e in pairs})
host_modes = [('native', 'native-C')]
host_modes.extend((b, m) for b in ['direct', 'c-wasm']
                  for m in ['python', 'native', 'native-serial', 'precompiled'])
matrix(host['observations'], ['name', 'backend', 'mode', 'phase', 'sample'],
       {(n, b, m, phase, i) for n in names for b, m in host_modes
        for phase, length in [('warmup', 1), ('measure', 15)] for i in range(length)})
matrix(host['preparation'], ['name', 'backend', 'configuration', 'sample'],
       {(n, b, c, i) for n in names for b in ['direct', 'c-wasm']
        for c in ['parallel', 'serial'] for i in range(5)})
tasks = {x['task'] for x in arena['observations']}
assert len(tasks) == 7
expected = {('build', t, b, None, None, 'cold', i) for t in tasks
            for b in ['native', 'direct', 'c-wasm'] for i in range(5)}
expected.update(('execution', t, b, e, p, 'normal', i) for t in tasks for b, e in pairs
                for p, length in [('test', 1), ('run', 5)] for i in range(length))
matrix(arena['observations'], ['kind', 'task', 'backend', 'engine', 'profile', 'phase', 'sample'], expected)
assert {x['track'] for x in arena['observations']} == {'adapted'}
matrix([dict(x, sample=x.get('sample', 0)) for x in lifecycle['observations']],
       ['name', 'mode', 'phase', 'sample'],
       {(n, m, p, i) for n in names
        for m in ['ordinary', 'cache-miss', 'cache-hit', 'precompiled', 'native-C', 'worker-hit']
        for p, length in [('warmup', 1), ('measure', 15)] for i in range(length)})

goldens = {x['name']: ROOT / 'examples' / x['expected'] for x in ex['examples']}
golden_sha = {n: sha(p) for n, p in goldens.items()}
artifact_checks = 0
seen_files = {}

def artifact(path, digest):
    global artifact_checks
    path = Path(path)
    if path not in seen_files:
        seen_files[path] = sha(path)
    assert seen_files[path] == digest, str(path)
    artifact_checks += 1

for r in [ex, host, arena]:
    assert r['environment']['compiler_sha256'] == selected
assert ex['environment']['compiler_source_identity']['headers'] == source['headers']
assert lifecycle['environment']['compiler_source_identity']['headers'] == source['headers']
for x in ex['observations']:
    assert x['status'] == 'passed'
    if x['kind'] == 'build':
        artifact(x['artifact'], x['artifact_sha256'])
        if x['backend'] != 'native':
            assert x['artifact_sha256'] == x['driver_stats']['module_sha256']
    else:
        assert x['stdout_sha256'] == golden_sha[x['name']]
for x in host['observations']:
    assert x['exit_code'] == 0 and x['stdout_sha256'] == golden_sha[x['name']]
    if x['mode'] in ['native', 'native-serial']:
        assert '--no-cache' in x['command'] and '--cache-config' not in x['command']
for x in host['preparation']:
    assert '--no-cache' in x['command'] and '--cache-config' not in x['command']
    artifact(x['artifact'], x['sha256'])
for x in arena['observations']:
    assert x['status'] == 'passed' and x['returncode'] == 0 and not x['error']
    if x['kind'] == 'build':
        artifact(x['artifact'], x['artifact_sha256'])
    else:
        lines = x['stdout'].splitlines()
        assert int(lines[0]) == x['checksum'] == x['expected_checksum']
        assert int(lines[1]) / 1e9 == x['timed_region_seconds'] and x['revision_exit'] == 0
for x in lifecycle['observations']:
    assert x['returncode'] == 0 and x['stderr_empty']
    assert x['wall_ns'] / 1e9 == x['wall_seconds']
    if x['mode'] == 'worker-hit':
        assert x['stdout_sha256'] == golden_sha[x['name']] and x['cache_hit'] is True
        assert x['process_command'][1:] == ['--serve', '--no-cache']
    else:
        assert x['stdout'].encode() == goldens[x['name']].read_bytes() and x['golden_match']
        if 'status' in x:
            assert x['status'] == 'passed'
        if x['mode'] == 'ordinary':
            assert '--no-cache' in x['command']
for name, x in lifecycle['worker_lifecycle'].items():
    assert x['first_stdout'].encode() == goldens[name].read_bytes()
    assert x['first_returncode'] == 0 and not x['first_stderr'] and x['first_cache_hit'] is False
    assert x['resident_process_count'] == 1
for x in lifecycle['examples']:
    for a in x['artifacts'].values():
        artifact(a['path'], a['sha256'])
for x in lifecycle['preparation'].values():
    artifact(x['precompiled'], x['precompiled_sha256'])
    artifact(x['cache_config'], x['cache_config_sha256'])

host_by_round = {(x['name'], x['backend'], x['mode'], x['sample']): x['wall_seconds']
                 for x in host['observations'] if x['phase'] == 'measure'}
for x in host['paired_speedup']:
    check([host_by_round[x['name'], x['backend'], x['reference'], i] /
           host_by_round[x['name'], x['backend'], x['mode'], i] for i in range(15)], x['speedup'])
for engine in ['wasmtime', 'v8']:
    r = reports[engine]
    workloads = {w['name']: w for w in r['workloads']}
    for variants in r['artifacts'].values():
        for x in variants.values():
            artifact(x['path'], x['sha256'])
            if x.get('aot_path'):
                artifact(x['aot_path'], x['aot_sha256'])
    for x in r['observations']:
        assert x['revision_exit'] == 0
        assert x['expected_checksum'] == workloads[x['task']][x['profile']]['checksum']
        assert x['artifact_sha256'] == r['artifacts'][x['task']][x['variant']]['sha256']
    for w in r['workloads']:
        assert sha(w['source']) == r['input_sha256'][w['source']]
    assert [x['task'] for x in findings[engine]['tasks'] if not x['guest_identical']] == ['Etc::Sieve']
assert [(x['task'], x['bytes_delta']) for x in analysis['examples'] if not x['byte_identical']] == []
assert [(x['task'], x['bytes_delta']) for x in analysis['warmed'] if not x['byte_identical']] == [('Etc::Sieve', 94)]
for left, right in zip(delivery['phases'], delivery['phases'][1:]):
    assert left['finished_utc'] <= right['started_utc']

qualification = load(BUILD / 'qualification/summary.json')
assert qualification['status'] == 'passed' and qualification['compiler_sha256'] == selected
assert qualification['input_pins_rechecked'] and qualification['input_pins'] == 1368
assert qualification['coverage'] == {'focused_commands': 76, 'cases': 978,
    'differential_observations': 9573, 'native_stdout_comparisons': 7656,
    'host_observations': 11484, 'host_unique_wasm': 1574, 'worker_observations': 3001,
    'worker_underlying_aliases': 3828, 'worker_unique_wasm': 1574}
for p in qualification['reports'].values():
    artifact(p['path'], p['sha256'])
for name in ['focused', 'differential', 'host', 'worker-replay']:
    p = BUILD / 'qualification/attempt-1' / name / 'report.json'
    assert sha(p) == delivery['input_sha256'][str(p)]
nums = load(BUILD / 'final-numbers.json')
campaign = load(BUILD / 'campaign.json')
assert campaign['numbers_sha256'] == sha(BUILD / 'final-numbers.json')
assert nums['compiler_sha256'] == campaign['compiler_sha256'] == selected
assert nums['baseline_compiler_sha256'] == campaign['baseline_compiler_sha256'] == baseline
assert nums['module_analysis'] == analysis and nums['lifecycle'] == lifecycle['examples']
for out_name, report_name in [('warmed', 'wasmtime'), ('v8', 'v8')]:
    assert nums['warmed'][out_name]['geometric_ratios'] == reports[report_name]['geometric_ratios']
    assert nums['warmed'][out_name]['tasks'] == [{k: r[k] for k in ['task', 'times', 'paired_ratios']}
                                              for r in reports[report_name]['summary']]
for name, value in nums['examples'].items():
    for key, rows in [('compile', ex['compile_summary']), ('python_v8_native', ex['runtime_summary']),
                      ('native_host', host['runtime_summary']), ('preparation', host['preparation_summary'])]:
        assert value[key] == [r for r in rows if r['name'] == name]
assert nums['langarena']['compile_summary'] == arena['compile_summary']
assert nums['langarena']['runtime_summary'] == arena['runtime_summary']
for backend, bounds in nums['langarena']['compile_ranges_ms'].items():
    vals = [r['wall_seconds']['median'] * 1000 for r in arena['compile_summary'] if r['backend'] == backend]
    assert bounds == {'min': min(vals), 'max': max(vals)}

# Explicit source/reference/engine boundaries and complete discarded-attempt exclusion.
reference_path = ROOT / 'build/runtime-reference/production/report.json'
assert sha(reference_path) == '06c1f5b883af43d5f5563416fec01d5a1ff5ec309a5005e3abb5293654e59350'
reference = load(reference_path)
assert reports['wasmtime']['selection'] == reference['selection']
assert reports['wasmtime']['workloads'] == reference['workloads']
for task, variants in reports['wasmtime']['artifacts'].items():
    task_id = next(w['id'] for w in reference['workloads'] if w['name'] == task)
    for variant, a in variants.items():
        if variant.startswith('ref--'):
            original = reference['artifacts'][task_id + '/' + variant.removeprefix('ref--')]
            assert a['sha256'] == original['sha256']
            if a.get('aot_path'):
                assert a['aot_sha256'] == original['aot_sha256']
source_checks = 0
for path, digest in delivery['input_sha256'].items():
    if Path(path).suffix in {'.py', '.mjs', '.json', '.h', '.c', '.cpp', '.goose', '.patch', '.sh'}:
        artifact(path, digest)
        source_checks += 1
engine_checks = {}
for path in [delivery['configuration']['host'], delivery['configuration']['node'],
             delivery['python_engine']['library'], delivery['compiler_root'] + '/bin/goose',
             reports['wasmtime']['configuration']['host']]:
    digest = delivery['input_sha256'].get(path)
    if digest is None:
        digest = reports['wasmtime']['input_sha256'][path]
    artifact(path, digest)
    engine_checks[path] = digest
assert host['host_build']['host_sha256'] == lifecycle['environment']['host_build']['host_sha256'] == delivery['host_build']['host_sha256']
assert host['host_build']['host_sha256'] == 'e303865d7661dc5d0dad1e1719753d1101bfe7f7e16d5b1eb2e174f416fbbf28'
assert reports['wasmtime']['host_build']['host_sha256'] == 'e0468623661130c89eec4902c287c1ec971928b75469a47303c3392733c51cd3'
assert host['python_engine']['library_sha256'] == delivery['python_engine']['library_sha256'] == '3127ca42fe7cdd3f0a43a358e79177dcfedd46c1746329826403b9d854de6178'
assert lifecycle['environment']['example_build_report_sha256'] == sha(BUILD / paths['examples'])
assert sha(lifecycle['environment']['host_build_metadata_path']) == lifecycle['environment']['host_build_metadata_sha256']
assert load(lifecycle['environment']['host_build_metadata_path']) == lifecycle['environment']['host_build']
assert all(v is None for v in delivery['environment']['controls'].values())
assert all(report.get(k, True) is True for report in [ex, arena] for k in ('source_hashes_still_match', 'compiler_hash_still_matches', 'artifact_hashes_still_match'))
discard_folder = BUILD / 'delivery-preparation/window-overlap-1'
discard = load(discard_folder / 'status.json')
stop = load(discard_folder / 'delivery-overlap-stop.json')
discard_execution = load(discard_folder / 'delivery-execution/report.json')
discard_warmed = load(discard_folder / 'delivered-warmed/report.json')
assert discard['status'] == 'discarded-interrupted-measurement' and discard['primary_observations_used'] == 0
assert discard['qualification_reused'] and discard['qualification_source_inputs_unchanged']
assert discard_execution['status'] == 'failed' and len(discard_execution['phases']) == 1
assert discard_execution['phases'][0]['name'] == 'delivered-warmed'
assert discard_warmed['status'] == 'running' and len(discard_warmed['observations']) == 134
assert next(p['utc'] for p in discard_warmed['phases'] if p['name'] == 'measure' and p['boundary'] == 'start') == stop['measurement_started_utc']
overlap_seconds = (datetime.fromisoformat(stop['completion_file_mtime_utc']) - datetime.fromisoformat(stop['measurement_started_utc'])).total_seconds()
assert math.isclose(overlap_seconds, .731880, abs_tol=1e-6)
assert discard_execution['finished_utc'] < delivery['started_utc']
assert all(p['started_utc'] > discard_execution['finished_utc'] for p in delivery['phases'])
assert all(report['started_utc'] > discard_execution['finished_utc'] for report in reports.values())
assert sha(discard_folder / 'delivered-warmed/report.json') != sha(BUILD / paths['wasmtime'])
assert not any('window-overlap-1' in path for path in delivery['input_sha256'])
completion = load(BUILD / 'qualification/completion.json')
assert completion['status'] == 'passed' and completion['attempts'] == 1 and completion['failed_phases'] == 0
assert completion['summary_sha256'] == sha(BUILD / 'qualification/summary.json')
assert completion['input_pins_rechecked'] and completion['helper_and_test_freeze_rechecked']
discard_evidence = {'status': discard, 'interruption': stop, 'overlap_seconds': overlap_seconds,
                    'retained_raw_rows': len(discard_warmed['observations']), 'primary_rows_used': 0,
                    'inputs': [pin(discard_folder / p) for p in ['status.json', 'delivery-overlap-stop.json',
                               'delivery-execution/report.json', 'delivered-warmed/report.json']]}

native_task = next(x for x in reports['wasmtime']['summary'] if x['task'] == 'Etc::Sieve')
role = reports['wasmtime']['reference_roles']['Etc::Sieve']['selected_native']
native_comparison = next(x['ratio'] for x in native_task['paired_ratios']
                         if x['numerator'] == 'final' and x['denominator'] == role)
review = {'schema': 'goose-byte-scan-independent-arithmetic-v1', 'status': 'passed',
          'created_utc': datetime.now(timezone.utc).isoformat(), 'reviewer': 'astra_campaign',
          'compiler_sha256': selected, 'baseline_compiler_sha256': baseline,
          'scope': 'Independent read-only calculation from raw observations and exact guest/source identities; no compiler/test/engine execution. Final public prose/chart/archive review remains separate.',
          'summary_cells_recomputed': checked, 'cohorts': {k: len(v['observations']) for k, v in reports.items()},
          'exact_six_cohort_matrices_verified': True, 'host_preparations': 200,
          'artifact_identity_checks': artifact_checks, 'distinct_hashed_files': len(seen_files),
          'delivery_input_pins': len(delivery['input_sha256']),
          'current_source_input_checks': source_checks, 'engine_identity_checks': engine_checks,
          'discarded_attempt': discard_evidence,
          'collection_started_utc': delivery['started_utc'], 'collection_finished_utc': delivery['finished_utc'],
          'qualification': qualification['coverage'], 'qualification_input_pins': 1368,
          'sieve_selected_native': {'variant': role, 'native_median_ms': native_task['times'][role]['median'] * 1000,
                                    'paired_direct_over_native': native_comparison,
                                    'interpretation': 'Direct takes about14 percent less time than this frozen selected native profile in these paired rounds. This is not a universal native ceiling.'},
          'warmed': findings, 'source_inventory': {'headers': 36, 'patches': 2},
          'interpretation': ['Only Sieve changes among ten warmed guests; the other nine byte-identical guests are noise controls.',
                             'All ten full-example direct modules are byte-identical to f76. Only the warmed Sieve port grows94bytes. Full-process differences in these independent cohorts are not compiler code-generation gains; full Sieve is a distinct workload.',
                             'Full-process host and lifecycle observations are separate nonpaired cohorts; do not form cross-cohort speedups or mix native reference medians.',
                             'Warmed Wasmtime uses the frozen reference host; normal host/lifecycle use canonical e303. Python shared-library and full static SDK identities remain separate.',
                             'Resident worker samples include IPC and a fresh Store/instance; they exclude resident process startup and initial module preparation. Fresh process ordinary is explicitly --no-cache; cache-hit/miss and precompiled are separate modes.',
                             'The interrupted first delivery overlapped final qualification bookkeeping by0.731880seconds. Its complete134-row partial warmed report is retained as discarded context and supplies0primaryobservations. All six primary cohorts were recollected after the prior attempt ended; no correctness failure or data-driven exclusion is claimed.'],
          'inputs': [pin(BUILD / path) for path in paths.values()] + [pin(BUILD / 'delivery-execution/report.json'), pin(BUILD / 'module-analysis.json'), pin(BUILD / 'final-numbers.json'), pin(BUILD / 'campaign.json'), pin(BUILD / 'qualification/summary.json'), pin(BUILD / 'qualification/completion.json'), pin(reference_path), pin(Path(__file__))],
          'blockers': []}
path = OUT / 'independent-arithmetic.json'
assert not path.exists()
path.write_text(json.dumps(review, indent=2) + '\n')
print(json.dumps({'status': 'passed', 'summary_cells': checked, 'review': pin(path),
                  'sieve': {k: next(x for x in v['tasks'] if x['task'] == 'Etc::Sieve') for k, v in findings.items()}}, indent=2))
