#!/usr/bin/env python3
"""Normalized fresh-process comparison of the explicit official-min profile."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import random
import statistics
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
BASE = Path(__file__).resolve().parent
PROFILE = BASE / "v2"
sys.path.insert(0, str(ROOT / "bench"))
import process

NORMALIZER_PATH = ROOT / "build/functions-native-hills/projection/measure.py"
SPEC = importlib.util.spec_from_file_location("projection_measurement", NORMALIZER_PATH)
NORMALIZER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(NORMALIZER)


def digest(path):
    with Path(path).open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest()


def describe(values):
    middle = statistics.median(values)
    return {"n": len(values), "median": middle,
            "mad": statistics.median(abs(value-middle) for value in values), "samples": values}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--samples", type=int, default=61)
    parser.add_argument("--example-report", type=Path, required=True)
    parser.add_argument("--baseline-host", type=Path, default=BASE / "frozen-baseline/bin/goose-wasmtime")
    parser.add_argument("--aa-host", type=Path, default=BASE / "frozen-baseline/clone/goose-wasmtime")
    parser.add_argument("--subset-full-host", type=Path, default=PROFILE / "preparation/goose-wasmtime")
    parser.add_argument("--minimal-host", type=Path, default=PROFILE / "runtime/goose-wasmtime")
    parser.add_argument("--subset-full-arg", action="append", default=[])
    parser.add_argument("--minimal-arg", action="append", default=[])
    parser.add_argument("--subset-functions-aot", type=Path, default=PROFILE / "functions-baseline.cwasm")
    parser.add_argument("--subset-squares-aot", type=Path, default=PROFILE / "squares.cwasm")
    parser.add_argument("--extra-pin", type=Path, action="append", default=[])
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    previous = ROOT / "build/next-runtime-hills/current"
    current_examples = json.loads(args.example_report.read_bytes())
    full = args.baseline_host.resolve()
    clone = args.aa_host.resolve()
    hosts = {"default": full, "default_aa": clone,
             "subset_full": args.subset_full_host.resolve(),
             "subset_min": args.minimal_host.resolve()}
    pins = {}

    def pin(path, expected=None):
        path = Path(path).resolve()
        actual = digest(path)
        if expected is not None and actual != expected:
            raise ValueError("input hash mismatch: " + str(path))
        if str(path) in pins and pins[str(path)] != actual:
            raise ValueError("input changed: " + str(path))
        pins[str(path)] = actual

    for path in [Path(__file__), NORMALIZER_PATH, ROOT / "bench/process.py", Path(sys.executable),
                 PROFILE / "manifest.json", PROFILE / "correctness.json", PROFILE / "abi.json",
                 PROFILE / "abi.log", BASE / "prepare-v2.py", BASE / "check-v2.py",
                 BASE / "check-abi-v2.py", ROOT / "tests/test_native_wasmtime.py"]:
        pin(path)
    pin(args.example_report)
    for path in args.extra_pin:
        pin(path)
    builds = {}
    for name, host in hosts.items():
        metadata_path = host.with_suffix(".json")
        if not metadata_path.is_file():
            metadata_path = host.parent / "build.json"
        pin(metadata_path)
        metadata = json.loads(metadata_path.read_text())
        pin(host, metadata["host_sha256"])
        for filename, expected in metadata["input_sha256"].items():
            pin(filename, expected)
        builds[name] = metadata
    assert digest(full) == digest(clone) == "e303865d7661dc5d0dad1e1719753d1101bfe7f7e16d5b1eb2e174f416fbbf28"

    artifact_paths = {}
    expected = {}
    native = {}
    cells = {}
    normalization = set(hosts.values())
    for workload in ["functions", "squares"]:
        old_native = previous / f"examples/compile/{workload}/native/0/program.bin"
        old_guest = previous / f"examples/compile/{workload}/direct/0/program.wasm"
        def current_artifact(backend):
            row = next(row for row in current_examples["observations"]
                       if row["kind"] == "build" and row["name"] == workload
                       and row["backend"] == backend and row["sample"] == 0)
            artifact = Path(row["artifact"])
            pin(artifact, row["artifact_sha256"])
            return artifact
        native[workload] = current_artifact("native")
        guest = current_artifact("direct")
        pin(old_native); pin(old_guest)
        assert digest(native[workload]) == digest(old_native), "native artifact bytes changed"
        assert digest(guest) == digest(old_guest), "guest artifact bytes changed"
        default_aot = previous / f"host/preparation/{workload}/direct/parallel/0/program.cwasm"
        subset_name = workload
        if workload == "functions":
            subset_name = "functions-baseline"
        subset_aot = args.subset_squares_aot.resolve()
        if workload == "functions":
            subset_aot = args.subset_functions_aot.resolve()
        golden = ROOT / f"examples/expected/{workload}.out"
        for path in [native[workload], guest, default_aot, subset_aot, golden,
                     ROOT / f"examples/{workload}.goose"]:
            pin(path)
        normalization.update([native[workload], guest, default_aot, subset_aot])
        expected[workload] = golden.read_bytes()
        artifact_paths[workload] = {"wasm": str(guest), "native": str(native[workload]),
                                   "default_aot": str(default_aot), "subset_aot": str(subset_aot)}
        cells[workload] = {}
        for index, (variant, executable) in enumerate([*hosts.items(), ("native", native[workload])]):
            letter = chr(ord("a") + index)
            alias = output / "exec" / workload[0] / letter / "program"
            alias.parent.mkdir(parents=True)
            alias.symlink_to(executable)
            command = [str(alias)]
            if variant == "subset_full":
                command += args.subset_full_arg
            if variant == "subset_min":
                command += args.minimal_arg
            if variant != "native":
                aot = subset_aot
                if variant.startswith("default"):
                    aot = default_aot
                alias_aot = output / "aot" / workload[0] / letter / "program.cwasm"
                alias_aot.parent.mkdir(parents=True)
                alias_aot.symlink_to(aot)
                command += ["--precompiled", str(alias_aot)]
            cells[workload][variant] = command

    initial_affinity = sorted(os.sched_getaffinity(0))
    controls = {key: os.environ.get(key) for key in ["LD_PRELOAD", "LD_LIBRARY_PATH", "RAYON_NUM_THREADS", "OMP_NUM_THREADS"]}
    assert not controls["LD_PRELOAD"]
    report = {"schema": "goose-official-min-configurable-final-comparison-v1", "status": "running",
              "started_utc": datetime.now(timezone.utc).isoformat(), "samples": args.samples,
              "warmups": 2, "seed": 116603, "cells": cells, "host_builds": builds,
              "artifacts": artifact_paths, "input_sha256": pins, "environment": controls,
              "initial_affinity": initial_affinity, "configuration": {name: str(value) for name, value in vars(args).items()},
              "method": "Complete unchanged Functions/Squares programs, checked canonical stdout and empty stderr. Fresh process, hard timeout via production pidfd helper. Equal-length exec/AOT aliases. Five cells shuffled each round; paired ratios within the same workload/round. Normal CPU pool primary; parent/child CPU2 diagnostic. All source checks and hashes precede scoped inode cache normalization and two warmups; no compilation in timed region.",
              "causal_limit": "Compared with the frozen original full host, subset_full includes the selected stdio implementation and an explicit restricted engine profile. subset_min uses the same shared host source compiled for the official minimal SDK with AOT-only guards. Profile, source, SDK and artifact identities differ as recorded; the package gain does not isolate compiler removal or binary-size causality. Newly compiled native and guest bytes match the frozen prior artifacts; native execution is fresh in every round.",
              "observations": []}
    report["cache_preparation"] = [NORMALIZER.normalize(str(path)) for path in sorted(normalization)]
    (output / "initial.json").write_text(json.dumps(report, indent=2) + "\n")
    rng = random.Random(report["seed"])
    try:
        for affinity in ["pool", "cpu2"]:
            cpus = initial_affinity
            if affinity == "cpu2":
                cpus = [2]
            os.sched_setaffinity(0, cpus)
            for phase, count in [("warmup", 2), ("measure", args.samples)]:
                for sample in range(count):
                    jobs = [(workload, variant) for workload in cells for variant in hosts]
                    jobs += [(workload, "native") for workload in cells]
                    rng.shuffle(jobs)
                    for workload, variant in jobs:
                        command = cells[workload][variant]
                        started = time.perf_counter_ns()
                        result = process.run(command, input=b"", capture_output=True, cwd=ROOT, timeout=30)
                        elapsed = time.perf_counter_ns() - started
                        row = {"affinity": affinity, "phase": phase, "sample": sample,
                               "workload": workload, "variant": variant, "command": command,
                               "wall_ns": elapsed, "returncode": result.returncode,
                               "stdout": result.stdout.decode(errors="replace"),
                               "stderr": result.stderr.decode(errors="replace")}
                        report["observations"].append(row)
                        if result.returncode or result.stdout != expected[workload] or result.stderr:
                            raise RuntimeError(row)
            print("finished", affinity, flush=True)
    finally:
        os.sched_setaffinity(0, initial_affinity)
    report["summary"] = {}
    for affinity in ["pool", "cpu2"]:
        for workload in cells:
            rows = [row for row in report["observations"] if row["affinity"] == affinity and
                    row["workload"] == workload and row["phase"] == "measure"]
            indexed = {(row["sample"], row["variant"]): row["wall_ns"] for row in rows}
            summary = {"wall_us": {}, "paired_ratios": {}}
            for variant in [*hosts, "native"]:
                summary["wall_us"][variant] = describe([indexed[index, variant] / 1000 for index in range(args.samples)])
            pairs = [(variant, "default") for variant in hosts if variant != "default"]
            pairs += [(variant, "native") for variant in hosts]
            pairs += [("subset_min", "subset_full")]
            for numerator, denominator in pairs:
                values = [indexed[index, numerator] / indexed[index, denominator] for index in range(args.samples)]
                summary["paired_ratios"][numerator + "_over_" + denominator] = describe(values)
            report["summary"][affinity + "/" + workload] = summary
    report["input_sha256_after"] = {filename: digest(filename) for filename in pins}
    assert report["input_sha256_after"] == pins
    assert controls == {key: os.environ.get(key) for key in controls}
    report.update(status="passed", finished_utc=datetime.now(timezone.utc).isoformat())
    (output / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    for key, row in report["summary"].items():
        print(key, {name: round(value["median"], 3) for name, value in row["wall_us"].items()},
              {name: round(value["median"], 5) for name, value in row["paired_ratios"].items()})


if __name__ == "__main__":
    main()
