#pragma once
namespace goose::direct_wasm {

// A pure scalar callback cannot observe its record parameter storage. Capture
// the fields it reads at each argument's original snapshot boundary instead.
inline bool Function::ProjectFunctionValue(Call *node, const vector<Node *> &args, bool adapt_result,
                                           const ResultDestinations &destinations, bool elements) {
    if (c.opts.debug || (c.region_cursors && c.may_have_prefix_mappings) || elements ||
        !destinations.empty() || node->builtin >= 0 || node->defaultinit || !node->dispatch.empty() ||
        !node->fvremap.empty() || !node->fvbody || !node->fvbody->stmts.empty() ||
        args.empty() || args.size() != node->fvparams.size()) return false;
    auto scalar = [](TypeExpr *type) {
        return type && !type->ix && !Compiler::Varint(type) &&
            (type->kind == TY_INT || type->kind == TY_FLT || type->kind == TY_BOOL);
    };
    if (node->exprtype && node->exprtype->kind != TY_VOID && !scalar(node->exprtype)) return false;
    auto natural = NaturalResults(node);
    if (natural.size() != 1 || !scalar(natural[0]) || !node->fvbody->tail ||
        !SameFunctionValueType(natural[0], node->fvbody->tail->exprtype) ||
        (!SameFunctionValueType(natural[0], node->exprtype) &&
         (!adapt_result || !node->exprtype || node->exprtype->kind != TY_VOID))) return false;

    int budget = 512;
    function<bool(TypeExpr *)> closed = [&](TypeExpr *type) {
        if (!type || budget-- == 0 || c.Class(type) != SC_FIXED || Compiler::RegionOwner(type)) return false;
        if (scalar(type)) return true;
        if (type->kind == TY_ARRAY) {
            if ((type->arr->akind != A_FIXED && type->arr->akind != A_LIMITED) ||
                type->arr->size < 0 || Compiler::LengthStorage(type) == IS_VARINT) return false;
            return closed(type->arr->sub);
        }
        if (type->kind != TY_STRUCT) return false;
        for (auto field : c.RecordFields(type)) if (field && !closed(field)) return false;
        return true;
    };
    unordered_map<VarDef *, size_t> parameters;
    vector<vector<Dot *>> fields(args.size());
    vector<uint32_t> sizes;
    for (size_t i = 0; i < args.size(); i++) {
        auto parameter = node->fvparams[i];
        if (!parameter || Resolve(parameter) != parameter || parameter->captured || parameter->isvar ||
            parameter->reusable || addressed.count(parameter) || !parameter->type ||
            parameter->type->kind != TY_STRUCT || !closed(parameter->type) ||
            !SameFunctionValueType(parameter->type, args[i]->exprtype) || MayMaterialize(args[i]) ||
            !parameters.emplace(parameter, i).second) return false;
        sizes.push_back(c.Size(parameter->type).size);
    }
    function<bool(Node *)> pure = [&](Node *part) {
        if (!part || budget-- == 0 || !scalar(part->exprtype)) return false;
        switch (part->nkind) {
            case NK_IntLit: case NK_FltLit: case NK_BoolLit: return true;
            case NK_Dot: {
                auto dot = static_cast<Dot *>(part);
                auto id = Is<Ident>(dot->obj);
                if (!dot->IsField() || dot->fieldidx < 0 || !id || !id->vdef) return false;
                auto parameter = parameters.find(id->vdef);
                if (parameter == parameters.end() || Resolve(id->vdef) != id->vdef ||
                    !SameFunctionValueType(id->exprtype, id->vdef->type)) return false;
                auto type = id->vdef->type;
                auto declared = c.RecordFields(type);
                if (size_t(dot->fieldidx) >= declared.size() || !scalar(declared[dot->fieldidx])) return false;
                auto offset = c.FieldOffset(type, size_t(dot->fieldidx));
                auto width = c.Size(declared[dot->fieldidx]).size;
                if (offset > sizes[parameter->second] || width > sizes[parameter->second] - offset) return false;
                fields[parameter->second].push_back(dot); return true;
            }
            case NK_Unary: {
                auto unary = static_cast<Unary *>(part);
                if (unary->op != T_MINUS && unary->op != T_NOT && unary->op != T_BITNOT) return false;
                return pure(unary->child);
            }
            case NK_AsCast: {
                auto cast = static_cast<AsCast *>(part);
                return scalar(cast->totype) && pure(cast->child);
            }
            case NK_Binary: {
                auto binary = static_cast<Binary *>(part);
                switch (binary->op) {
                    case T_PLUS: case T_MINUS: case T_MUL: case T_DIV: case T_MOD:
                    case T_BITAND: case T_BITOR: case T_XOR: case T_SHL: case T_SHR:
                    case T_EQ: case T_NEQ: case T_LT: case T_GT: case T_LTEQ: case T_GTEQ:
                    case T_ANDAND: case T_OROR: break;
                    default: return false;
                }
                return pure(binary->left) && pure(binary->right);
            }
            default: return false;
        }
    };
    if (!pure(node->fvbody->tail)) return false;

    unordered_map<Dot *, pair<TypeExpr *, uint32_t>> snapshots;
    for (size_t i = 0; i < args.size(); i++) {
        auto type = node->fvparams[i]->type;
        To(args[i], type); auto address = Save(I32);
        // memory.copy checked the complete source, including unused fields.
        // A memory immediate uses nonwrapping effective-address arithmetic.
        Get(address); code.Mem(0x2d, 0, sizes[i] - 1); code.Op(0x1a);
        for (auto dot : fields[i]) {
            auto declared = c.FieldType(type, dot->fieldidx);
            Get(address);
            auto offset = c.FieldOffset(type, size_t(dot->fieldidx));
            if (offset) { code.I32Const(int32_t(offset)); code.Op(0x6a); }
            Load(declared); snapshots.emplace(dot, make_pair(declared, Save(declared)));
        }
    }
    auto previous = std::move(projected_fields);
    projected_fields = std::move(snapshots);
    To(node->fvbody->tail, natural[0]);
    projected_fields = std::move(previous);
    if (adapt_result) {
        if (node->exprtype->kind == TY_VOID) code.Op(0x1a);
        else Convert(natural[0], node->exprtype, node->line);
    }
    return true;
}

} // namespace goose::direct_wasm
