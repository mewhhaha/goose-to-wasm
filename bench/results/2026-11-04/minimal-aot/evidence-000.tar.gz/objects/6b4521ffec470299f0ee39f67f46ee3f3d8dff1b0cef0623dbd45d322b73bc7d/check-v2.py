#!/usr/bin/env python3
"""Check compatible subset artifacts without changing general host features."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

import wasmtime

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent / "v2"
PREPARATION = OUT / "preparation/goose-wasmtime"
RUNTIME = OUT / "runtime/goose-wasmtime"


def run(label, command, stdin=b""):
    directory = OUT / "checks" / label
    directory.mkdir(parents=True, exist_ok=False)
    result = subprocess.run(list(map(str, command)), input=stdin, capture_output=True, timeout=60)
    (directory / "stdout").write_bytes(result.stdout)
    (directory / "stderr").write_bytes(result.stderr)
    record = {"command": list(map(str, command)), "returncode": result.returncode,
              "stdout_hex": result.stdout.hex(), "stderr": result.stderr.decode(errors="replace")}
    (directory / "result.json").write_text(json.dumps(record, indent=2) + "\n")
    return result, record


def main():
    observations = []
    artifacts = {
        "functions-baseline": ROOT / "build/next-runtime-hills/current/examples/compile/functions/direct/0/program.wasm",
        "functions-candidate": ROOT / "build/functions-native-hills/projection/pilot-v2/O2.wasm",
        "squares": ROOT / "build/next-runtime-hills/current/examples/compile/squares/direct/0/program.wasm",
    }
    for name, module in artifacts.items():
        compiled = OUT / (name + ".cwasm")
        result, record = run(name + "-compile", [PREPARATION, "--no-cache", "--compile", module, compiled])
        observations.append(record)
        assert result.returncode == 0, record
        golden_name = "functions"
        if name == "squares":
            golden_name = "squares"
        golden = (ROOT / "examples/expected" / (golden_name + ".out")).read_bytes()
        result, record = run(name + "-official-min", [RUNTIME, "--precompiled", compiled])
        observations.append(record)
        assert result.returncode == 0 and result.stdout == golden and not result.stderr, record
        result, record = run(name + "-full-profile", [PREPARATION, "--precompiled", compiled])
        observations.append(record)
        assert result.returncode == 0 and result.stdout == golden and not result.stderr, record

    negative_modules = {
        "gc": "(module (type $record (struct (field i32))) (func (export \"_start\") (drop (struct.new $record (i32.const 1)))))",
        "exceptions": "(module (tag $e) (func (export \"_start\") (throw $e)))",
    }
    for name, wat in negative_modules.items():
        module = OUT / (name + ".wasm")
        module.write_bytes(wasmtime.wat2wasm(wat))
        (OUT / (name + ".wat")).write_text(wat + "\n")
        result, record = run(name + "-subset-rejects", [PREPARATION, "--no-cache", "--compile", module, OUT / (name + ".cwasm")])
        observations.append(record)
        assert result.returncode != 0 and result.stderr, record
        result, record = run(name + "-general-still-compiles", [ROOT / "build/bin/goose-wasmtime", "--no-cache", "--compile", module, OUT / (name + "-general.cwasm")])
        observations.append(record)
        assert result.returncode == 0, record

    old = ROOT / "build/next-runtime-hills/current/host/preparation/functions/direct/parallel/0/program.cwasm"
    result, record = run("old-general-artifact-rejected", [RUNTIME, "--precompiled", old])
    observations.append(record)
    assert result.returncode != 0 and b"GC" in result.stderr, record
    for name, args in [("ordinary", [artifacts["functions-baseline"]]),
                       ("serve", ["--serve"]), ("cache", ["--cache"]),
                       ("compile", ["--compile", artifacts["functions-baseline"], OUT / "invalid.cwasm"])]:
        result, record = run(name + "-min-cli-rejects", [RUNTIME, *args])
        observations.append(record)
        assert result.returncode != 0 and result.stderr, record
    result = {"passed": True, "observations": observations,
              "profile": "Explicit numeric/linear-memory no-GC/no-EH profile; general feature host unchanged.",
              "wasm_sha256": {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in artifacts.items()}}
    (OUT / "correctness.json").write_text(json.dumps(result, indent=2) + "\n")
    print("passed", len(observations), "compatibility/negative/CLI observations")


if __name__ == "__main__":
    main()
