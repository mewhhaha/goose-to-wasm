#!/usr/bin/env python3
"""Detached final correctness gates and exact retained-module host replays."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
BASELINE = ROOT / "build/next-runtime-hills/qualification/attempt-1/differential"
PYTHON = str(ROOT / ".venv/bin/python")


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    with Path(path).open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest()


def checkpoint(report):
    temporary = OUT / "report.tmp"
    temporary.write_text(json.dumps(report, indent=2) + "\n")
    temporary.replace(OUT / "report.json")


def run(report, name, command, expected_tests=None):
    log_path = OUT / (name + ".log")
    report["active"] = name
    checkpoint(report)
    started = time.monotonic()
    with log_path.open("wb") as log:
        child = subprocess.Popen(command, cwd=ROOT, stdin=subprocess.DEVNULL,
                                 stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        timed_out = False
        try:
            code = child.wait(timeout=1800)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(child.pid, signal.SIGKILL)
            code = child.wait()
    record = {"name": name, "command": command, "exit_status": code,
              "timed_out": timed_out, "wall_seconds_correctness_only": time.monotonic()-started,
              "log": str(log_path), "log_sha256": digest(log_path)}
    if expected_tests is not None:
        observed = re.findall(r"Ran (\d+) tests?", log_path.read_text(errors="replace"))
        record.update(expected_tests=expected_tests, observed_tests=int(observed[-1]) if observed else None)
        record["coverage_exact"] = record["observed_tests"] == expected_tests
    report["commands"].append(record)
    report["active"] = None
    checkpoint(report)
    return record


def validate_replay(path, expected_count, expected_modes):
    replay = json.loads(path.read_text())
    assert replay["status"] == "pass", replay.get("error", str(path))
    assert replay["coverage_exact"] is True
    assert replay["expected_observations"] == replay["observations"] == len(replay["results"]) == expected_count
    assert replay["failures"] == 0
    assert set(replay["configuration"]["modes"]) == set(expected_modes)
    assert replay["input_sha256"] == replay["input_sha256_after"]
    assert replay["aot_sha256"] == replay["aot_sha256_after"]
    assert all(row["status"] == "pass" and all(row["comparisons"].values()) for row in replay["results"])
    assert len(replay["results"]) == len({(row["case"], row["optimization"], row["debug"], row["backend"], row["mode"]) for row in replay["results"]})
    return {"status": "pass", "report": str(path), "report_sha256": digest(path),
            "cases": replay["cases"], "observations": expected_count,
            "backends": sorted({row["backend"] for row in replay["results"]}),
            "modes": list(expected_modes), "coverage_exact": True,
            "source_and_artifact_pins_unchanged": True, "unique_aot": len(replay["aot_sha256"])}


def main():
    report = {"schema": "goose-final-minimal-host-qualification-v1", "status": "running",
              "started_utc": now(), "pid": os.getpid(), "active": "preflight", "commands": [],
              "measurement": "Correctness qualification only; no benchmark timing claims.",
              "reused_compiler": {"report": str(BASELINE / "report.json"),
                  "method": "Prior separately collected compiler/native/V8/Python-Wasmtime qualification; not rerun. Every retained input pin and compiler identity must still match. Compile-refusal rows remain prior evidence."}}
    checkpoint(report)
    try:
        old = json.loads((BASELINE / "report.json").read_text())
        old_pins = old["qualification_execution"]["input_sha256"]
        assert old_pins and old["failures"] == 0
        for filename, expected in old_pins.items():
            assert digest(filename) == expected, "prior compiler input changed: " + filename
        compiler = digest(ROOT / "build/bin/goose")
        assert compiler == old["compiler_sha256"] == "8c09c1a6bcc782de5b86dda621a91ae234acba8fbe108d146582113eb6a110b6"
        assert len(old["results"]) == old["observations"] == 9573
        report["reused_compiler"].update(status="verified-prior", report_sha256=digest(BASELINE / "report.json"),
            compiler_sha256=compiler, cases=old["cases"], observations=9573, input_sha256=old_pins,
            compile_refusals=sum(row.get("kind") == "compile-refusal" for row in old["results"]))
        source_paths = [Path(__file__), ROOT / "bench/qualify_wasmtime_host.py", ROOT / "bench/process.py"]
        gates = [("process", "tests/test_benchmark_process.py", 13),
                 ("native", "tests/test_native_wasmtime.py", 12),
                 ("aot", "tests/test_aot_wasmtime.py", 16),
                 ("session", "tests/test_runtime_session.py", 9),
                 ("langarena", "tests/test_langarena.py", 16),
                 ("runtime-reference", "tests/test_runtime_reference.py", 12)]
        source_paths += [ROOT / path for _, path, _ in gates]
        for name, expected in [("goose-wasmtime", "9c387aac2f4057e007f50cf421a7c7895c4c9a02b9496ca2fb45cd1291b27bf8"),
                               ("goose-wasmtime-aot", "b3460d7f5dbae2abe3177fddcce4cfbdffa428824e723c65d00bfa8bffd2498e")]:
            host = ROOT / "build/bin" / name
            assert digest(host) == expected
            metadata = host.with_suffix(".json")
            source_paths += [host, metadata]
            source_paths += [Path(filename) for filename in json.loads(metadata.read_text())["input_sha256"]]
        report["fresh_input_sha256"] = {str(path.resolve()): digest(path) for path in source_paths}
        checkpoint(report)
        for name, path, count in gates:
            result = run(report, name, [PYTHON, str(ROOT / path), "-v"], count)
            assert result["exit_status"] == 0 and result["coverage_exact"], "unit gate failed: " + name
        canonical = [PYTHON, str(ROOT / "bench/qualify_wasmtime_host.py"), "--baseline-dir", str(BASELINE),
                     "--host", str(ROOT / "build/bin/goose-wasmtime"), "--jobs", "4"]
        result = run(report, "host-replay", [*canonical, "--output-dir", str(OUT / "host")])
        report["host"] = validate_replay(OUT / "host/report.json", 11484,
                                         ["wasm", "wasm-no-parallel", "precompiled-no-parallel"])
        assert result["exit_status"] == 0
        result = run(report, "minimal-replay", [*canonical, "--aot-host", str(ROOT / "build/bin/goose-wasmtime-aot"),
                                                "--output-dir", str(OUT / "minimal")])
        report["minimal"] = validate_replay(OUT / "minimal/report.json", 3828, ["precompiled-minimal"])
        assert result["exit_status"] == 0
        report["fresh_input_sha256_after"] = {filename: digest(filename) for filename in report["fresh_input_sha256"]}
        assert report["fresh_input_sha256_after"] == report["fresh_input_sha256"]
        report["status"] = "passed"
    except BaseException as error:
        report.update(status="failed", error=type(error).__name__ + ": " + str(error), traceback=traceback.format_exc())
    report.update(active=None, finished_utc=now(), complete=True)
    checkpoint(report)
    completion = {"status": report["status"], "complete": True,
                  "exit_status": int(report["status"] != "passed"), "finished_utc": report["finished_utc"],
                  "report_sha256": digest(OUT / "report.json"), "pid": os.getpid()}
    (OUT / "completion.json").write_text(json.dumps(completion, indent=2) + "\n")
    return completion["exit_status"]


if __name__ == "__main__":
    raise SystemExit(main())
