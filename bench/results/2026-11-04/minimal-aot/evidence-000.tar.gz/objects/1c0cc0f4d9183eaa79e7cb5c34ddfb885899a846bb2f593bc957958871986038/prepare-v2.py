#!/usr/bin/env python3
"""Build two private, explicitly restricted AOT-profile hosts from cached SDKs."""
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent / "v2"
OUT.mkdir(exist_ok=False)
FULL = ROOT / "build/wasmtime-host/wasmtime-v50.0.1-x86_64-linux-c-api"
MINIMUM = FULL / "min"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def restricted_source(source):
    old = "    wasmtime_config_wasm_exceptions_set(config.get(), true);"
    assert source.count(old) == 1
    source = source.replace(old, '''    // Explicit numeric/linear-memory AOT profile, separate from the general host.
#ifdef WASMTIME_FEATURE_COMPONENT_MODEL
    wasmtime_config_wasm_component_model_set(config.get(), false);
    wasmtime_config_concurrency_support_set(config.get(), false);
#endif
    wasmtime_config_gc_support_set(config.get(), false);
#ifdef WASMTIME_FEATURE_GC
    wasmtime_config_wasm_gc_set(config.get(), false);
    wasmtime_config_wasm_function_references_set(config.get(), false);
    wasmtime_config_wasm_reference_types_set(config.get(), false);
    wasmtime_config_wasm_exceptions_set(config.get(), false);
#endif''')
    old = "    wasmtime_config_wasm_threads_set(config.get(), false);"
    assert source.count(old) == 1
    return source.replace(old, "#ifdef WASMTIME_FEATURE_THREADS\n" + old + "\n#endif")


def main():
    original_metadata = json.loads((ROOT / "build/bin/goose-wasmtime.json").read_text())
    variants = [
        ("preparation", ROOT / "host/wasmtime.cpp", FULL, False),
        ("runtime", ROOT / "build/functions-native-hills/aot-runtime/stdio/wasmtime.cpp", MINIMUM, True),
    ]
    manifest = {"schema": "goose-official-min-numeric-aot-profile-v1",
                "profile": "Separate numeric/linear-memory profile. GC infrastructure, Wasm GC, function references, reference types, exception handling, components and concurrency disabled. SIMD, memory64, tail calls, bulk memory and multi-value retained. General host and historical SDK/artifacts unchanged.",
                "variants": {}}
    for name, original, sdk, runtime_only in variants:
        directory = OUT / name
        directory.mkdir(exist_ok=False)
        source = directory / "wasmtime.cpp"
        source.write_text(restricted_source(original.read_text()))
        library = sdk / "lib/libwasmtime.a"
        command = original_metadata["command"][:]
        source_index = command.index(str(ROOT / "host/wasmtime.cpp"))
        command[source_index] = str(source)
        command[source_index + 1] = str(library)
        command[command.index("-o") + 1] = str(directory / "goose-wasmtime")
        command = [argument.replace("-I" + str(FULL / "include"), "-I" + str(sdk / "include")) for argument in command]
        if runtime_only:
            command.insert(1, "-DRUNTIME_ONLY")
        inputs = [original, source, library, Path(__file__), ROOT / "build/bin/goose-wasmtime.json"]
        inputs += sorted((sdk / "include").rglob("*.h"))
        start = time.perf_counter_ns()
        result = subprocess.run(command, capture_output=True)
        elapsed = time.perf_counter_ns() - start
        (directory / "build.stdout").write_bytes(result.stdout)
        (directory / "build.stderr").write_bytes(result.stderr)
        metadata = {"command": command, "returncode": result.returncode, "build_wall_ns": elapsed,
                    "input_sha256": {str(path): digest(path) for path in inputs},
                    "sdk": str(sdk), "official_release": "50.0.1", "runtime_only": runtime_only}
        if not result.returncode:
            metadata["host_sha256"] = digest(directory / "goose-wasmtime")
            metadata["host_bytes"] = (directory / "goose-wasmtime").stat().st_size
        (directory / "build.json").write_text(json.dumps(metadata, indent=2) + "\n")
        manifest["variants"][name] = metadata
        (OUT / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
        print(name, result.returncode, elapsed / 1e9, flush=True)
        if result.returncode:
            print(result.stderr.decode())
            raise SystemExit(result.returncode)


if __name__ == "__main__":
    main()
