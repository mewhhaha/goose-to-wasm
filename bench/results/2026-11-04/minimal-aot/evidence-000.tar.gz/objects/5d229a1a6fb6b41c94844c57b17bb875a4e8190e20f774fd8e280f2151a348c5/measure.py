#!/usr/bin/env python3
"""Prepare and measure the complete Functions projection experiment."""

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import random
import shutil
import statistics
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
HILLS = ROOT / "build/functions-native-hills"
sys.path.insert(0, str(ROOT / "bench"))
sys.path.insert(0, str(ROOT / "scripts"))
import process
from wasmtime_session import RuntimeSession

BASELINE_WASM = "048eb4b49710c64615529758ce76944ae591ebd63325b3c6ae5deb580da2a762"
CANDIDATE_WASM = "e3bcff27390395f0b93d89e6b3465e6868e94abe1d733844b8416a67c0de315c"
FULL_HOST = "e303865d7661dc5d0dad1e1719753d1101bfe7f7e16d5b1eb2e174f416fbbf28"
ENVIRONMENT_KEYS = (
    "LD_PRELOAD", "LD_LIBRARY_PATH", "RAYON_NUM_THREADS", "OMP_NUM_THREADS",
    "GOOSE_STDLIB", "WASMTIME_BACKTRACE_DETAILS",
)


def now():
    return datetime.now(timezone.utc).isoformat()


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + "\n")


def digest(path):
    with Path(path).open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest()


def describe(values):
    middle = statistics.median(values)
    return {
        "n": len(values), "median": middle,
        "mad": statistics.median(abs(value - middle) for value in values),
        "min": min(values), "max": max(values), "samples": values,
    }


def pin(pins, path, expected=None):
    path = Path(path).resolve()
    actual = digest(path)
    if expected is not None and actual != expected:
        raise ValueError("input hash mismatch: " + str(path))
    previous = pins.setdefault(str(path), actual)
    if previous != actual:
        raise ValueError("input changed during preparation: " + str(path))
    return path


def pin_compiler(pins, bundle):
    source_path = pin(pins, bundle / "source.json")
    toolchain_path = pin(pins, bundle / "toolchain.json")
    source = json.loads(source_path.read_text())
    toolchain = json.loads(toolchain_path.read_text())
    pin(pins, bundle / "bin/goose", toolchain["compiler_sha256"])
    for name, expected in source["headers"].items():
        pin(pins, bundle / "compiler" / name, expected)
    for name, expected in source["patches"].items():
        pin(pins, bundle / name, expected)
    for directory in [bundle / "bin/stdlib", bundle / "bin/include"]:
        for path in sorted(directory.rglob("*")):
            if path.is_file():
                pin(pins, path)


def pin_host(pins, host):
    metadata_path = pin(pins, host.with_suffix(".json"))
    metadata = json.loads(metadata_path.read_text())
    pin(pins, host, metadata["host_sha256"])
    for filename, expected in metadata["input_sha256"].items():
        pin(pins, filename, expected)
    return metadata


def preparation_command(command, directory):
    directory.mkdir(parents=True, exist_ok=False)
    write_json(directory / "command.json", command)
    result = process.run(command, input=b"", capture_output=True, cwd=ROOT, timeout=180)
    (directory / "stdout").write_bytes(result.stdout)
    (directory / "stderr").write_bytes(result.stderr)
    write_json(directory / "result.json", {"returncode": result.returncode})
    if result.returncode:
        raise RuntimeError("preparation failed: " + str(directory))


def prepare(args):
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    baseline_bundle = ROOT / "build/next-runtime-hills/final"
    candidate_bundle = HILLS / "projection/pilot-v2"
    full = ROOT / "build/bin/goose-wasmtime"
    clone = HILLS / "host-variants/rebuilt/bin/goose-wasmtime"
    lean = HILLS / "aot-runtime/stdio/goose-wasmtime"
    previous = ROOT / "build/next-runtime-hills/current"
    baseline = previous / "examples/compile/functions/direct/0/program.wasm"
    native = previous / "examples/compile/functions/native/0/program.bin"
    pins = {}
    for path in [Path(__file__), ROOT / "bench/process.py", ROOT / "scripts/goose_wasm.py",
                 ROOT / "scripts/wasmtime_session.py", ROOT / "oracle/goose_wasm.py",
                 ROOT / "toolchain.json", ROOT / "examples/functions.goose",
                 ROOT / "examples/expected/functions.out", Path(sys.executable),
                 previous / "examples/report.json", candidate_bundle / "O2.json",
                 candidate_bundle / "shape.json"]:
        pin(pins, path)
    pin(pins, shutil.which("fincore"))
    for path in [HILLS / "aot-runtime/manifest.json", HILLS / "aot-runtime/sdk-build.json",
                 ROOT / "build/full-hills/hosts/h01-runtime/source-archive.json",
                 ROOT / "build/full-hills/hosts/h01-runtime/commands.json",
                 ROOT / "build/full-hills/hosts/h01-runtime/tool-identities.json"]:
        pin(pins, path)
    pin_compiler(pins, baseline_bundle)
    pin_compiler(pins, candidate_bundle)
    metadata = {"full": pin_host(pins, full), "clone": pin_host(pins, clone),
                "lean": pin_host(pins, lean)}
    pin(pins, full, FULL_HOST)
    pin(pins, clone, FULL_HOST)
    pin(pins, baseline, BASELINE_WASM)
    pin(pins, candidate_bundle / "O2.wasm", CANDIDATE_WASM)
    pin(pins, native)

    wasm = {"baseline": output / "artifacts/a/program.wasm",
            "candidate": output / "artifacts/b/program.wasm"}
    for path in wasm.values():
        path.parent.mkdir(parents=True)
    shutil.copyfile(baseline, wasm["baseline"])
    command = [sys.executable, str(ROOT / "scripts/goose_wasm.py"), "build",
               str(ROOT / "examples/functions.goose"), "--backend", "direct",
               "--goose", str(candidate_bundle / "bin/goose"), "--offline", "--no-cache",
               "-O2", "-o", str(wasm["candidate"]), "--stats", str(output / "candidate-build.json")]
    preparation_command(command, output / "preparation/candidate")
    pin(pins, wasm["baseline"], BASELINE_WASM)
    pin(pins, wasm["candidate"], CANDIDATE_WASM)
    pin(pins, output / "candidate-build.json")
    aot = {}
    for name, path in wasm.items():
        aot[name] = path.with_suffix(".cwasm")
        preparation_command([str(full), "--no-cache", "--compile", str(path), str(aot[name])],
                            output / "preparation" / (name + "-aot"))
        pin(pins, aot[name])

    specifications = [
        ("full_baseline", full, "baseline"), ("full_candidate", full, "candidate"),
        ("full_aa", clone, "baseline"), ("lean_baseline", lean, "baseline"),
        ("lean_candidate", lean, "candidate"), ("native", native, None),
    ]
    cells = {}
    for index, (name, executable, guest) in enumerate(specifications):
        letter = chr(ord("a") + index)
        alias = output / "exec" / letter / "program"
        alias.parent.mkdir(parents=True)
        alias.symlink_to(executable)
        command = [str(alias)]
        if guest is not None:
            artifact_alias = output / "aot" / letter / "program.cwasm"
            artifact_alias.parent.mkdir(parents=True)
            artifact_alias.symlink_to(aot[guest])
            command += ["--precompiled", str(artifact_alias)]
        cells[name] = {"command": command, "executable": str(executable), "guest": guest}
    for path in sorted((output / "preparation").rglob("*")):
        if path.is_file():
            pin(pins, path)
    for filename, identity in pins.items():
        path = Path(filename)
        if path.suffix in {".h", ".cpp", ".py", ".json", ".goose", ".patch"}:
            destination = output / "inputs" / identity / path.name
            destination.parent.mkdir(parents=True, exist_ok=True)
            if not destination.exists():
                shutil.copyfile(path, destination)
    normalization = {str(full), str(clone), str(lean), str(native)}
    normalization.update(str(path) for path in [*wasm.values(), *aot.values()])
    prepared = {
        "schema": "goose-functions-projection-preparation-v1", "prepared_utc": now(),
        "cells": cells, "wasm": {key: str(value) for key, value in wasm.items()},
        "aot": {key: str(value) for key, value in aot.items()}, "host_builds": metadata,
        "normalization_files": sorted(normalization), "input_sha256": pins,
        "environment": {key: os.environ.get(key) for key in ENVIRONMENT_KEYS},
        "note": "Preparation is outside headline timing. Measure revalidates pins and normalizes inodes after all hashing, immediately before warmups.",
    }
    write_json(output / "prepared.json", prepared)
    print(output / "prepared.json")


def normalize(filename):
    descriptor = os.open(filename, os.O_RDONLY)
    try:
        os.fsync(descriptor)
        os.posix_fadvise(descriptor, 0, 0, os.POSIX_FADV_DONTNEED)
        command = ["fincore", "-n", "-b", "-o", "RES,PAGES", filename]
        cold = process.run(command, capture_output=True, check=True, timeout=30).stdout.decode().strip()
        if cold.split()[0] != "0":
            raise RuntimeError("executable/artifact did not leave page cache: " + filename)
        count = 0
        while True:
            chunk = os.read(descriptor, 1024 * 1024)
            if not chunk:
                break
            count += len(chunk)
        warm = process.run(command, capture_output=True, check=True, timeout=30).stdout.decode().strip()
        if count != Path(filename).stat().st_size:
            raise RuntimeError("cache warm read was incomplete: " + filename)
        return {"file": filename, "bytes": count, "after_local_drop": cold, "after_warm": warm}
    finally:
        os.close(descriptor)


def checked_run(command, expected):
    before = time.perf_counter_ns()
    result = process.run(command, input=b"", capture_output=True, cwd=ROOT, timeout=30)
    elapsed = time.perf_counter_ns() - before
    if result.returncode or result.stdout != expected or result.stderr:
        raise RuntimeError({"command": command, "returncode": result.returncode,
                            "stdout": result.stdout, "stderr": result.stderr})
    return elapsed, result


def fresh_entry_supplement(output, prepared, expected, affinity, count, rng):
    rows = []
    for sample in range(count):
        variants = ["baseline", "candidate"]
        rng.shuffle(variants)
        for variant in variants:
            timing_path = output / "entry" / affinity / f"{sample:03}" / (variant[0] + ".json")
            timing_path.parent.mkdir(parents=True, exist_ok=True)
            command = prepared["cells"]["full_" + variant]["command"] + ["--timing-json", str(timing_path)]
            elapsed, result = checked_run(command, expected)
            rows.append({"affinity": affinity, "sample": sample, "variant": variant,
                         "wall_ns_diagnostic": elapsed, "command": command,
                         "stdout": result.stdout.decode(), "timing": json.loads(timing_path.read_text())})
    return rows


def resident_supplement(prepared, expected, affinity, count, rng):
    rows = []
    host = prepared["cells"]["full_baseline"]["command"][0]
    with RuntimeSession(host, cache=False) as session:
        for variant in ["baseline", "candidate"]:
            first = session.run(prepared["wasm"][variant])
            if first.returncode or first.stdout != expected or first.stderr:
                raise RuntimeError("resident preparation failed: " + variant)
        for sample in range(count):
            variants = ["baseline", "candidate"]
            rng.shuffle(variants)
            for variant in variants:
                before = time.perf_counter_ns()
                result = session.run(prepared["wasm"][variant])
                elapsed = time.perf_counter_ns() - before
                if result.returncode or result.stdout != expected or result.stderr or not result.module_cache_hit:
                    raise RuntimeError("resident checked hit failed: " + variant)
                rows.append({"affinity": affinity, "sample": sample, "variant": variant,
                             "wall_ns_diagnostic": elapsed, "prepare_ns": result.prepare_ns,
                             "start_ns": result.start_ns, "module_cache_hit": result.module_cache_hit,
                             "stdout": result.stdout.decode()})
    return rows


def summarize(rows, samples):
    result = {}
    for affinity in ["pool", "cpu2"]:
        selected = [row for row in rows if row["affinity"] == affinity and row["phase"] == "measure"]
        indexed = {(row["sample"], row["cell"]): row["wall_ns"] for row in selected}
        cells = list(dict.fromkeys(row["cell"] for row in selected))
        summary = {"wall_us": {}, "paired_ratios": {}}
        for cell in cells:
            summary["wall_us"][cell] = describe([indexed[index, cell] / 1000 for index in range(samples)])
        comparisons = [
            ("full_candidate", "full_baseline"), ("full_aa", "full_baseline"),
            ("lean_candidate", "lean_baseline"), ("lean_baseline", "full_baseline"),
            ("lean_candidate", "full_baseline"),
        ]
        comparisons += [(cell, "native") for cell in cells if cell != "native"]
        for numerator, denominator in comparisons:
            values = [indexed[index, numerator] / indexed[index, denominator] for index in range(samples)]
            summary["paired_ratios"][numerator + "_over_" + denominator] = describe(values)
        result[affinity] = summary
    return result


def summarize_supplements(report):
    summary = {}
    for affinity in ["pool", "cpu2"]:
        fresh = [row for row in report["fresh_entry"] if row["affinity"] == affinity]
        resident = [row for row in report["resident"] if row["affinity"] == affinity]
        entry = {"fresh_entry": {}, "resident": {}}
        for variant in ["baseline", "candidate"]:
            selected = [row for row in fresh if row["variant"] == variant]
            entry["fresh_entry"][variant] = {
                key: describe([row["timing"][key] for row in selected])
                for key in ["compile_instantiate_ns", "start_function_ns", "engine_total_ns"]
            }
            selected = [row for row in resident if row["variant"] == variant]
            if selected:
                entry["resident"][variant] = {
                    key: describe([row[key] for row in selected])
                    for key in ["prepare_ns", "start_ns", "wall_ns_diagnostic"]
                }
        for label, rows, metric in [("fresh_entry", fresh, "start_function_ns"),
                                     ("resident", resident, "start_ns")]:
            if not rows:
                continue
            ratios = []
            for sample in sorted({row["sample"] for row in rows}):
                pair = {row["variant"]: row for row in rows if row["sample"] == sample}
                baseline = pair["baseline"]
                candidate = pair["candidate"]
                if label == "fresh_entry":
                    baseline = baseline["timing"]
                    candidate = candidate["timing"]
                ratios.append(candidate[metric] / baseline[metric])
            entry[label]["paired_candidate_over_baseline_start"] = describe(ratios)
        summary[affinity] = entry
    return summary


def measure(args):
    output = args.output.resolve()
    if (output / "report.json").exists() or (output / "initial.json").exists():
        raise ValueError("measurement output already exists; prepare a separate output for another run")
    prepared_path = output / "prepared.json"
    prepared = json.loads(prepared_path.read_text())
    pins = dict(prepared["input_sha256"])
    pin(pins, prepared_path)
    for filename, expected_hash in pins.items():
        if digest(filename) != expected_hash:
            raise ValueError("prepared input changed: " + filename)
    controls = {key: os.environ.get(key) for key in ENVIRONMENT_KEYS}
    if controls != prepared["environment"] or controls["LD_PRELOAD"]:
        raise ValueError("benchmark environment changed or includes a diagnostic preload")
    expected = (ROOT / "examples/expected/functions.out").read_bytes()
    initial_affinity = sorted(os.sched_getaffinity(0))
    report = {
        "schema": "goose-functions-projection-measurement-v1", "status": "running",
        "started_utc": now(), "samples": args.samples, "warmups": args.warmups,
        "supplement_samples": args.supplement_samples, "seed": 773061,
        "method": "Complete unchanged Functions output. Fresh process, captured stdout, hard deadlines through production pidfd helper. Six cells shuffled per round; paired ratios use the same round. Pool is primary; parent/child CPU2 is diagnostic. Equal-length executable/AOT aliases. AOT preparation and source validation are outside timing. Source/compiler/SDK identities are pinned separately. No runtime equivalence implied by static shape.",
        "supplement_method": "Separate fresh --timing-json rows use the same full host; prepare/start excludes output and destructors as defined by that host. Separate resident module-cache-hit requests use that full host with fresh stores/instances, cache disabled, and internal prepare/start timing. Neither supplement is a headline process score.",
        "prepared": prepared, "input_sha256": pins, "initial_affinity": initial_affinity,
        "environment": controls, "observations": [], "fresh_entry": [], "resident": [],
    }
    # This occurs after every hash/validation, even if prepare ran much earlier.
    report["cache_preparation"] = [normalize(path) for path in prepared["normalization_files"]]
    write_json(output / "initial.json", report)
    rng = random.Random(report["seed"])
    try:
        for affinity in ["pool", "cpu2"]:
            cpus = initial_affinity
            if affinity == "cpu2":
                cpus = [args.cpu]
            os.sched_setaffinity(0, cpus)
            for phase, count in [("warmup", args.warmups), ("measure", args.samples)]:
                for sample in range(count):
                    names = list(prepared["cells"])
                    rng.shuffle(names)
                    for cell in names:
                        command = prepared["cells"][cell]["command"]
                        elapsed, observed = checked_run(command, expected)
                        report["observations"].append({"affinity": affinity, "phase": phase,
                            "sample": sample, "cell": cell, "wall_ns": elapsed, "command": command,
                            "returncode": observed.returncode, "stdout": observed.stdout.decode(), "stderr": ""})
            report["fresh_entry"] += fresh_entry_supplement(output, prepared, expected, affinity, args.supplement_samples, rng)
            if not args.skip_resident:
                report["resident"] += resident_supplement(prepared, expected, affinity, args.supplement_samples, rng)
            print("finished", affinity, flush=True)
    finally:
        os.sched_setaffinity(0, initial_affinity)
    report["summary"] = summarize(report["observations"], args.samples)
    report["supplement_summary"] = summarize_supplements(report)
    report["input_sha256_after"] = {filename: digest(filename) for filename in pins}
    if report["input_sha256_after"] != pins:
        raise ValueError("an input changed during collection")
    if controls != {key: os.environ.get(key) for key in ENVIRONMENT_KEYS}:
        raise ValueError("an environment control changed during collection")
    report.update(status="passed", finished_utc=now())
    write_json(output / "report.json", report)
    print(json.dumps(report["summary"], indent=2))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=["prepare", "measure"])
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--samples", type=int, default=61)
    parser.add_argument("--warmups", type=int, default=2)
    parser.add_argument("--supplement-samples", type=int, default=15)
    parser.add_argument("--cpu", type=int, default=2)
    parser.add_argument("--skip-resident", action="store_true")
    args = parser.parse_args()
    if args.samples < 1 or args.warmups < 0 or args.supplement_samples < 1:
        parser.error("sample counts must be positive and warmups nonnegative")
    if args.action == "prepare":
        prepare(args)
    else:
        measure(args)


if __name__ == "__main__":
    main()
