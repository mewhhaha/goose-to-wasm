#!/usr/bin/env python3
"""Collect explicit exit statuses for final product correctness gates."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(report):
    temporary = OUT / "gates.tmp"
    temporary.write_text(json.dumps(report, indent=2) + "\n")
    temporary.replace(OUT / "gates.json")


def main():
    gates = [("process", "tests/test_benchmark_process.py", 13),
             ("native", "tests/test_native_wasmtime.py", 12),
             ("aot", "tests/test_aot_wasmtime.py", 16),
             ("session", "tests/test_runtime_session.py", 9),
             ("langarena", "tests/test_langarena.py", 16),
             ("runtime-reference", "tests/test_runtime_reference.py", 12)]
    inputs = [ROOT / path for _, path, _ in gates]
    inputs += [ROOT / "build/bin/goose", ROOT / "build/bin/goose-wasmtime",
               ROOT / "build/bin/goose-wasmtime-aot", ROOT / "bench/process.py", Path(__file__)]
    report = {"status": "running", "started_utc": datetime.now(timezone.utc).isoformat(),
              "input_sha256": {str(path): digest(path) for path in inputs}, "commands": []}
    save(report)
    for name, filename, count in gates:
        command = [str(ROOT / ".venv/bin/python"), str(ROOT / filename), "-v"]
        log_path = OUT / (name + ".log")
        started = time.monotonic()
        with log_path.open("wb") as log:
            result = subprocess.run(command, cwd=ROOT, stdin=subprocess.DEVNULL,
                                    stdout=log, stderr=subprocess.STDOUT, timeout=600)
        matches = re.findall(r"Ran (\d+) tests?", log_path.read_text(errors="replace"))
        actual = int(matches[-1]) if matches else None
        report["commands"].append({"name": name, "command": command, "exit_status": result.returncode,
            "expected_tests": count, "observed_tests": actual, "coverage_exact": count == actual,
            "log": str(log_path), "log_sha256": digest(log_path),
            "wall_seconds_correctness_only": time.monotonic()-started})
        save(report)
    report["input_sha256_after"] = {str(path): digest(path) for path in inputs}
    passed = report["input_sha256"] == report["input_sha256_after"]
    passed = passed and all(row["exit_status"] == 0 and row["coverage_exact"] for row in report["commands"])
    report.update(status="passed" if passed else "failed", complete=True,
                  exit_status=int(not passed), finished_utc=datetime.now(timezone.utc).isoformat())
    save(report)
    return report["exit_status"]


if __name__ == "__main__":
    raise SystemExit(main())
