#!/usr/bin/env python3
"""Verify task-local raw-log archive before removing only archived log trees."""
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import tarfile

ROOT = Path(__file__).resolve().parent
STAGE = Path("/dev/shm/goose-final-qualification-compaction")
STAGE.mkdir(exist_ok=False)
TREES = [ROOT / name for name in ["host/runs", "host/preparation", "minimal/runs", "minimal/preparation"]]
FILES = sorted(path for tree in TREES if tree.exists() for path in tree.rglob("*") if path.is_file())
INVENTORY = {}
ARCHIVE = STAGE / "raw-logs.tar.gz"


def digest(path):
    with path.open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest()


with tarfile.open(ARCHIVE, "w:gz") as archive:
    for index, path in enumerate(FILES):
        assert not path.is_symlink()
        name = str(path.relative_to(ROOT))
        payload = path.read_bytes()
        INVENTORY[name] = {"bytes": len(payload), "sha256": hashlib.sha256(payload).hexdigest()}
        information = archive.gettarinfo(str(path), arcname=name)
        archive.addfile(information, io.BytesIO(payload))
        if index % 10000 == 0:
            print("archived", index, flush=True)
seen = set()
with tarfile.open(ARCHIVE, "r:gz") as archive:
    for member in archive:
        assert member.isfile() and member.name not in seen
        payload = archive.extractfile(member).read()
        assert INVENTORY[member.name] == {"bytes": len(payload), "sha256": hashlib.sha256(payload).hexdigest()}
        seen.add(member.name)
assert seen == set(INVENTORY)
inventory_path = STAGE / "raw-log-inventory.json"
inventory_path.write_text(json.dumps(INVENTORY, indent=2) + "\n")
for source in [ARCHIVE, inventory_path]:
    target = ROOT / source.name
    with source.open("rb") as source_file, target.open("wb") as target_file:
        shutil.copyfileobj(source_file, target_file, 1024 * 1024)
        target_file.flush()
        os.fsync(target_file.fileno())
    assert digest(source) == digest(target)
record = {"status": "verified-before-deletion", "archive": str(ROOT / ARCHIVE.name),
          "archive_sha256": digest(ARCHIVE), "archive_bytes": ARCHIVE.stat().st_size,
          "inventory": str(ROOT / inventory_path.name), "inventory_sha256": digest(inventory_path),
          "files": len(INVENTORY), "payload_bytes": sum(value["bytes"] for value in INVENTORY.values()),
          "trees": [str(tree) for tree in TREES if tree.exists()],
          "verification": "Every archived regular payload checked against full SHA256/size inventory; exact inventory/path set; staged and copied archive/inventory SHA256 match. Reports/AOT/source snapshots/old corpus untouched.",
          "staging": str(STAGE), "deleted_trees": []}
index_path = ROOT / "raw-log-compaction.json"
index_path.write_text(json.dumps(record, indent=2) + "\n")
for tree in TREES:
    if tree.exists():
        shutil.rmtree(tree)
        record["deleted_trees"].append(str(tree))
record["status"] = "verified-compacted"
index_path.write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(record, indent=2), flush=True)
