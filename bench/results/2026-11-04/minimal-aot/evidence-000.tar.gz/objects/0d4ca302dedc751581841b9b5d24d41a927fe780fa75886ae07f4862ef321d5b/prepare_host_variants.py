from pathlib import Path
import copy,hashlib,json,subprocess,concurrent.futures,time
R=Path(__file__).resolve().parents[2];B=Path(__file__).resolve().parent
source=(R/'host/wasmtime.cpp').read_text();M=json.loads((R/'build/bin/goose-wasmtime.json').read_bytes())
keep=B/'source-before';keep.mkdir(exist_ok=True)
p=keep/'wasmtime.cpp'
if p.exists():assert p.read_text()==source
else:p.write_text(source)

def replace(text,old,new):
 assert text.count(old)==1,old
 return text.replace(old,new,1)

def lazy(text):
 text=replace(text,'    bool exited = false;','    bool pending_stdin = false;\n    bool exited = false;')
 text=replace(text,'    string token() {','''    void load_input() {
        if (!pending_stdin) return;
        pending_stdin = false;
        try { input = read_all(stdin); }
        catch (const std::exception &error) {
            fail("direct Wasmtime host: " + error_text(error));
        }
    }
    string token() {
        load_input();''')
 text=replace(text,'                if (reading) {\n                    auto count =', '''                if (reading) {
                    memory.range(start, 0);
                    if (size) state.load_input();
                    auto count =''')
 return replace(text,'        if (options.compiled.empty()) state.input = read_all(stdin);','        if (options.compiled.empty()) state.pending_stdin = true;')

def append(text):
 return replace(text,'        case Op::Write: state.output += Memory(caller).bytes(address(a[0].of.i32), address(a[1].of.i32)); break;', '''        case Op::Write: {
            Memory memory(caller);
            auto size = address(a[1].of.i32);
            auto data = memory.range(address(a[0].of.i32), size);
            if (size) state.output.append(reinterpret_cast<const char *>(data), size_t(size));
            break;
        }''')

def stdio(text):
 text=replace(text,'#include <fstream>\n','')
 text=replace(text,'template <class T> static string goose_float(T value) {','''static void write_file(const string &path, string_view bytes) {
    Owned<FILE, std::fclose> file(std::fopen(path.c_str(), "wb"));
    if (!file) fail("cannot write " + path);
    if (std::fwrite(bytes.data(), 1, bytes.size(), file.get()) != bytes.size()) fail("cannot write " + path);
    if (std::fclose(file.release())) fail("cannot write " + path);
}
template <class T> static string goose_float(T value) {''')
 text=replace(text,'''            std::ofstream output(options.compiled, std::ios::binary);
            output.write(serialized.value.data, serialized.value.size); output.close();
            if (!output) fail("cannot write " + options.compiled);''','''            write_file(options.compiled, string_view(serialized.value.data, serialized.value.size));''')
 start=text.index('    if (!options.timing.empty()) {',text.index('static int run('));end=text.index('    return exit_code;',start)
 text=text[:start]+'''    if (!options.timing.empty()) {
        const char *mode = "wasm", *parallel = "true", *cached = "false";
        if (options.precompiled) mode = "precompiled";
        if (options.no_parallel_compilation) parallel = "false";
        if (shared->cache_enabled) cached = "true";
        char timing[1024];
        int length = std::snprintf(timing, sizeof timing,
            "{\\n  \\"engine\\": \\"Wasmtime\\",\\n  \\"wasmtime\\": \\"%s\\",\\n"
            "  \\"host\\": \\"native C API\\",\\n  \\"module_mode\\": \\"%s\\",\\n"
            "  \\"parallel_compilation\\": %s,\\n  \\"compilation_cache_enabled\\": %s,\\n"
            "  \\"optimization\\": \\"cranelift speed\\",\\n  \\"compile_instantiate_ns\\": %llu,\\n"
            "  \\"start_function_ns\\": %llu,\\n  \\"engine_total_ns\\": %llu\\n}\\n",
            WASMTIME_VERSION, mode, parallel, cached,
            static_cast<unsigned long long>(instantiated - started),
            static_cast<unsigned long long>(ended - instantiated),
            static_cast<unsigned long long>(ended - started));
        if (length < 0 || size_t(length) >= sizeof timing) fail("cannot format timing");
        write_file(options.timing, string_view(timing, size_t(length)));
    }
'''+text[end:]
 return text

variants={'rebuilt':source,'lazy':lazy(source),'append':append(source),'stdio':stdio(source),'combined':stdio(append(lazy(source)))}

def build(item):
 name,text=item;folder=B/'host-variants'/name;folder.mkdir(parents=True,exist_ok=False)
 cpp=folder/'wasmtime.cpp';cpp.write_text(text);out=folder/'bin/goose-wasmtime';out.parent.mkdir()
 cmd=M['command'][:];cmd[cmd.index(str(R/'host/wasmtime.cpp'))]=str(cpp);cmd[cmd.index('-o')+1]=str(out)
 start=time.monotonic()
 with (folder/'build.log').open('w')as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 data=copy.deepcopy(M);data['command']=cmd;data['build_wall_seconds']=time.monotonic()-start;data['exit_status']=r.returncode
 if r.returncode:
  (folder/'failed-build.json').write_text(json.dumps(data,indent=2)+'\n');raise RuntimeError(name+' failed')
 data['host_sha256']=hashlib.sha256(out.read_bytes()).hexdigest();data['input_sha256'].pop(str(R/'host/wasmtime.cpp'));data['input_sha256'][str(cpp)]=hashlib.sha256(cpp.read_bytes()).hexdigest();data['input_sha256'][str(Path(__file__).resolve())]=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
 out.with_suffix('.json').write_text(json.dumps(data,indent=2)+'\n')
 print(name,out.stat().st_size,data['host_sha256'],flush=True)
 return name
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:list(pool.map(build,variants.items()))
