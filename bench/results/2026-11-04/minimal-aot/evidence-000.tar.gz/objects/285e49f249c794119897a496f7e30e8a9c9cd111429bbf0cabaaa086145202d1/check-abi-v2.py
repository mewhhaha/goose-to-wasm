#!/usr/bin/env python3
"""Run the existing ABI contracts through the explicit official-min profile."""
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import unittest

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent / "v2"
PREPARATION = OUT / "preparation/goose-wasmtime"
RUNTIME = OUT / "runtime/goose-wasmtime"
SPEC = importlib.util.spec_from_file_location("native_host_abi", ROOT / "tests/test_native_wasmtime.py")
TESTS = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(TESTS)
OBSERVATIONS = []


class MinimalProfileABI(TESTS.NativeHost):
    def setUp(self):
        self.directory = OUT / "abi-fixtures" / self._testMethodName
        self.directory.mkdir(parents=True, exist_ok=False)
        self.count = 0

    def module(self, wat):
        path = super().module(wat)
        path.with_suffix(".wat").write_text(wat)
        return path

    def observe(self, command, data=b""):
        result = subprocess.run(list(map(str, command)), input=data, capture_output=True, timeout=30)
        OBSERVATIONS.append({"test": self._testMethodName, "command": list(map(str, command)),
                             "stdin_hex": data.hex(), "returncode": result.returncode,
                             "stdout_hex": result.stdout.hex(), "stderr_hex": result.stderr.hex()})
        return result

    def prepare(self, path):
        compiled = path.with_suffix(".cwasm")
        result = self.observe([PREPARATION, "--no-cache", "--no-parallel-compilation",
                               "--compile", path, compiled])
        self.assertEqual(result.returncode, 0, result.stderr)
        return compiled

    def execute(self, command, data=b""):
        if Path(command[0]).resolve() != TESTS.HOST.resolve():
            return self.observe(command, data)
        self.assertEqual(len(command), 2)
        compiled = self.prepare(command[1])
        reference = self.observe([PREPARATION, "--precompiled", compiled], data)
        actual = self.observe([RUNTIME, "--precompiled", compiled], data)
        self.assertEqual((actual.returncode, actual.stdout, actual.stderr),
                         (reference.returncode, reference.stdout, reference.stderr))
        return actual

    def compare(self, path, data=b"", diagnostic=None):
        reference = self.observe([sys.executable, ROOT / "scripts/run_wasmtime.py", path], data)
        compiled = self.prepare(path)
        for host in [PREPARATION, RUNTIME]:
            actual = self.observe([host, "--precompiled", compiled], data)
            self.assertEqual(actual.returncode, reference.returncode, actual.stderr)
            self.assertEqual(actual.stdout, reference.stdout)
            if diagnostic is not None:
                self.assertIn(diagnostic, actual.stderr)
            elif reference.returncode == 0 or b"goose runtime error:" in reference.stderr:
                self.assertEqual(actual.stderr, reference.stderr)
        return reference

    def test_fd_read_validates_bytes_written_instead_of_requested_span(self):
        # The current repository ABI class has eleven of the twelve earlier
        # AOT fixtures. Retain this explicit boundary fixture in the adapter.
        path = self.module('''(module
          (import "wasi_snapshot_preview1" "fd_read" (func $read (param i32 i64 i64 i64) (result i32)))
          (import "wasi_snapshot_preview1" "fd_write" (func $write (param i32 i64 i64 i64) (result i32)))
          (memory (export "memory") i64 1)
          (func (export "_start")
            (i64.store (i64.const 0) (i64.const 65535))
            (i64.store (i64.const 8) (i64.const 2))
            (drop (call $read (i32.const 0) (i64.const 0) (i64.const 1) (i64.const 64)))
            (i64.store (i64.const 8) (i64.load (i64.const 64)))
            (drop (call $write (i32.const 1) (i64.const 0) (i64.const 1) (i64.const 72)))))''')
        for data in [b"", b"x"]:
            self.assertEqual(self.compare(path, data).stdout, data)
        self.compare(path, b"xy", diagnostic=b"outside exported memory")


names = [
    "test_float_spelling_and_integer_extremes", "test_stdout_bytes_and_output_before_abort_or_exit",
    "test_checked_goose_ranges_and_empty_memory", "test_duplicate_imports_and_invalid_signatures",
    "test_imports_during_instantiation_and_memory_growth", "test_iovec_output_before_invalid_later_range",
    "test_memory_growth_notifications_in_both_memory_models", "test_numeric_input_validation",
    "test_fd_read_validates_bytes_written_instead_of_requested_span", "test_memory64_iovecs_and_utf8_stderr",
    "test_iovec_snapshot_before_aliasing_input_writes", "test_emscripten_stack_initialization",
]
suite = unittest.TestSuite(MinimalProfileABI(name) for name in names)
with (OUT / "abi.log").open("w") as log:
    result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
report = {"tests": names, "tests_run": result.testsRun, "passed": result.wasSuccessful(),
          "failures": len(result.failures), "errors": len(result.errors), "observations": OBSERVATIONS,
          "scope": "Existing ABI fixtures, compiled with separate numeric no-GC/no-EH profile. Full profile and official-min runtime compared with independent Python host. Excludes general compiler/service CLI and live-pipe lifecycle tests; those modes are not supported by AOT-only runner."}
(OUT / "abi.json").write_text(json.dumps(report, indent=2) + "\n")
print(result.testsRun, result.wasSuccessful(), len(OBSERVATIONS), flush=True)
raise SystemExit(not result.wasSuccessful())
