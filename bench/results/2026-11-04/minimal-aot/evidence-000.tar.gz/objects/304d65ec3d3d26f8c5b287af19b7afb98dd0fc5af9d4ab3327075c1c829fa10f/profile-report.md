# Fresh Functions process profile, 2026-11-04

RELR is rejected by the paired selector. The Functions guest `_start` is already shorter than native `main` in these diagnostics; fresh process preparation and process machinery remain material. No product source was edited by this profiling task.

## Pinned artifacts and method

- Source HEAD: `95146ea85acb2d4762df84617ae1b58ba3dcf37b`.
- Unchanged host SHA256: `e303865d7661dc5d0dad1e1719753d1101bfe7f7e16d5b1eb2e174f416fbbf28`.
- Host source SHA256: `8573711cb0ae48a0cbcb6202b513af442ef06dbfdb1f1a4749c4145ed8a07d61`.
- RELR host SHA256: `deb8dbc490f414b42df568e7d746713563db52a284a24e8f1ddb62b66d82798f`.
- Native Functions SHA256: `d656c7ea7f15b3d49973196a4efd1eef871d711233f1ca6e7272d0a0e09c62c5`.
- Diagnostic host SHA256: `8403f3a4a707e5e9ade859b2280c8614a41ea35b5f6cce568403c694856da611`.
- Diagnostic native preload SHA256: `e7197d4546ac53930df7bda65191e444a2ee7733b0aef654071cdce7c306dfbe`.
- Wasmtime SDK static 50.0.1. Every collection manifest pins actual compiler, host, SDK library, native, Wasm, AOT, workload, golden output and collector bytes before and after all runs. Pins were unchanged within each collection.
- Build command in `profile-tools/build-command.json` changes only the current host source and output paths to a private instrumented copy. Host compilation took 2.158 seconds. `profile-tools/prepare.py` records all instrumentation edits. Native diagnosis uses the unchanged binary with a separately built preload; native benchmark source was not edited.
- Primary samples use unchanged host/native artifacts, each in a fresh process, with captured stdout checked byte-for-byte against the golden file. Each repetition shuffles native, baseline AOT and candidate AOT order using seed 4001. Normal pool is CPU affinity 0–15; diagnostic affinity is CPU 2. These are warm filesystem-cache process measurements, not cold disk experiments.
- Separate instrumented runs measure monotonic spans. Main excludes the profile-file write. Callback spans are inside `_start`; destructor spans are inside `run`; `run` is inside `main`. They must not be added as independent costs. Counter/timestamp overhead and the native preload change diagnostic execution. Native `main` does not include automatic exit-time stdio flush; host `main` includes its explicit output flush. These are phase diagnostics, not substitute primary benchmark scores.

## Paired RELR decision

61 pairs per workload per affinity for each of two separately preserved collection methods. Selector is median per-repetition candidate/baseline wall ratio; lower is better. Intervals are 10,000 bootstrap resamples of paired ratios, seed 711, percentile interval of the median. Raw observations and the precise summary procedure are preserved.

| Method | Affinity | Functions candidate/baseline | 95% interval | Candidate faster pairs | Squares candidate/baseline |
|---|---|---:|---:|---:|---:|
| Existing Python timeout wait | 0–15 | 1.0711 | 1.0502–1.0944 | 17/61 | 1.0642 |
| Existing Python timeout wait | CPU 2 | 1.0359 | 1.0323–1.0398 | 0/61 | 1.0336 |
| Blocking waitpid | 0–15 | 1.0849 | 1.0680–1.1029 | 14/61 | 1.0786 |
| Blocking waitpid | CPU 2 | 1.0783 | 1.0664–1.0887 | 4/61 | 1.0774 |

Unpaired wall medians in the noisy CPU pool can suggest an opposite result because ratios of medians differ from medians of paired ratios. The declared paired selector rejects the candidate in every collection and control. RELR saves file bytes but does not improve this fresh-process benchmark.

Blocking-wait CPU 2 Functions primary medians: native **637.335 us**, unchanged AOT **1014.836 us**, RELR AOT **1090.209 us**. Paired baseline AOT/native median is **1.5931**. The corresponding CPU-pool baseline ratio is **1.6271**. These results do not establish native equivalence.

## A measured harness hill

Python `subprocess.run(..., timeout=120)` eventually calls `Popen._wait(timeout)`, which polls `waitpid(..., WNOHANG)` and initially sleeps **1 ms** if the child has closed its pipes but has not completed process exit. A parent and child sharing CPU 2 reliably expose this path. The existing benchmark helpers also use timed `subprocess.run` or `communicate`.

The original requested matrix is retained in `primary-{pool,cpu2}` and `phases-{pool,cpu2}`. A separately labelled follow-up in `waitpid-*` changes the private collector to blocking waitpid (`timeout=None`). It does not change the program binaries or output checks. CPU 2 Functions primary medians fall from native 1672.981 / AOT 2053.597 us to native 637.335 / AOT 1014.836 us. This reduction is a measurement-method correction, not a compiler/runtime speedup.

Instrumented CPU 2 native main-to-parent-return median falls from **1254.413 to 197.216 us**; host from **1330.628 to 276.968 us**. The remaining interval includes actual exit, scheduler, pipe handling and diagnostic profile I/O. It does not isolate teardown. Parent-launch-to-main similarly includes Python spawn setup, dynamic loading, scheduler and C/C++ startup, not just OS exec. We do not assign these residuals to a guessed cause.

## Fresh phase profile

31 independent instrumented processes per workload per affinity per method. The following CPU 2 blocking-wait diagnostic medians, in microseconds, provide a reproducible phase view. CPU-pool phase results and original timeout rows remain in their own summaries; they were not substituted into this table.

| Phase | Functions | Squares |
|---|---:|---:|
| Main entry through return, all cleanup | 373.663 | 301.054 |
| CLI parsing/validation | 2.676 | 2.595 |
| stdin read | 44.986 | 45.407 |
| Wasmtime config creation/settings | 29.176 | 29.195 |
| Engine creation | 44.855 | 46.599 |
| Store creation/context | 9.909 | 9.979 |
| AOT file deserialization | 91.435 | 80.564 |
| Linker creation/import definitions | 20.479 | 21.431 |
| Instantiation | 18.836 | 18.725 |
| Stack-limit export setup | 0.151 | 0.160 |
| `_start`, including buffered host callbacks | 69.122 | 12.314 |
| Host callbacks, nested inside `_start` | 20.578 | 0.731 |
| Linker deletion | 0.361 | 0.341 |
| Module deletion | 0.060 | 0.060 |
| Store deletion | 26.531 | 18.776 |
| Engine deletion | 3.286 | 3.306 |
| Run, including Wasmtime teardown | 316.494 | 244.507 |
| Actual output/error writes and explicit flush | 5.711 | 5.731 |
| State string cleanup | 0.080 | 0.060 |
| Native main entry through return, preload diagnostic | 152.451 | 110.661 |

Each phase is summarized independently, so phase medians do not form an additive measured decomposition of the median main duration. CPU 2 stdin timing includes the empty input-pipe scheduling handoff; it is not guest computation. State cleanup is negligible; store teardown is not. Fresh initialization is substantially larger than resident preparation, so resident prepare/start numbers cannot explain the full process wall by themselves.

The instrumented CPU 2 Functions host launch-to-main median is **487.500 us**, compared with native diagnostic **374.845 us**. The native preload changes loader work; subtracting them would not be an unbiased loader-cost estimate. The host and native main-to-parent-return medians are **276.968** and **197.216 us**, with the profile write outside both main intervals.

## Loader diagnostics

One `LD_DEBUG=statistics` execution per actual host/native binary, with golden stdout verified. These are attribution-only loader cycle counts, not headline timings:

| Binary | Loader startup cycles | Relocation cycles | Reported relative relocations |
|---|---:|---:|---:|
| Native Functions | 154272 | 8794 | 8 |
| Baseline host | 237549 | 114835 | 14941 |
| RELR host | 232892 | 112011 | 0 |

The reported relative count excludes the RELR table; the relocations still need applying. A compact table did not remove that work. Raw loader stderr is preserved in `ld-debug`.

## Files and qualification

- `profile-collection-commands.json`: exact original collection commands and completion status.
- `profile-waitpid-collection-commands.json`: exact blocking-wait follow-up commands and status.
- `profile-paired-selector.json`: paired selector statistics for both methods and both workloads.
- Each collection directory has immutable manifest, summary, per-run command, stdout, stderr and diagnostic phase JSON where applicable.
- Every one of **1,963** program executions across both primary matrices, phase matrices and the three loader probes passed exit/golden checks. Primary and phase matrices remained separate throughout. The optional empty-program floor was not run; Squares is the measured control.
- No builds, engine invocations or child benchmark processes remain active at handoff.
