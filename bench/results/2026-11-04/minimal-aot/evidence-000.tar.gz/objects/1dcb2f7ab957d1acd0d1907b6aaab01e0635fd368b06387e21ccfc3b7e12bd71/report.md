# Official minimal SDK profile: select eager v2

The cached official Wasmtime 50.0.1 minimal SDK can run the complete, unchanged Functions program. It needs an explicitly separate preparation profile; the earlier rejection was engine configuration metadata, not guest GC instructions. No Rust/CMake SDK build or download was needed.

Select the eager-input v2 prototype for production integration and final qualification. The normalized primary Functions paired wall ratio is **0.74998** versus the current full host, and **1.18208** versus native: about 25% lower launch-to-exit latency, still about 18% above native. This is a prototype selection, not evidence that production has been delivered or native equivalence achieved.

## Compatibility and configuration

The official cached min headers omit compiler, GC/collectors, threads and component features. `wasmtime_config_gc_support_set(false)` remains available even without the GC build feature. The full-SDK preparation profile explicitly disables:

- GC infrastructure, Wasm GC, function references, reference types and exceptions.
- Component model and concurrency support.
- Wasm threads, as the general host already does.

SIMD, memory64, tail calls, bulk memory and multi-value settings remain enabled. GC-specific setters are guarded by `WASMTIME_FEATURE_GC`; component/concurrency setters by `WASMTIME_FEATURE_COMPONENT_MODEL`; the thread setter by `WASMTIME_FEATURE_THREADS`. The official-min runner accepts only precompiled execution and timing output. The general host's default profile is unchanged.

The first private prototype disabled reference types while component-model async was still enabled, causing configuration rejection at engine creation. Its source, binary metadata and failure output remain preserved at this profile root. V2 disables component/concurrency support too and succeeds. This failed experiment is not hidden or treated as a successful run.

The serialization source stores `engine.features()` and collector configuration for the engine, rather than only proposals actually used by the guest. The old default-profile artifact therefore correctly fails on the min runtime with “module was compiled with GC however GC is disabled in the host.” Newly prepared subset-profile artifacts load successfully. The direct backend's scalar/vector function types and memory/code/data emission do not require GC types or EH tags.

V2 compatibility checks include unchanged baseline Functions Wasm `048eb4b49710c64615529758ce76944ae591ebd63325b3c6ae5deb580da2a762`, projection-pilot Functions `e3bcff27390395f0b93d89e6b3465e6868e94abe1d733844b8416a67c0de315c`, and Squares. Each exact canonical output passed on both private hosts. GC/EH fixtures reject in the subset preparer and still compile on the unchanged general host. Old-profile AOT and unsupported min CLI modes reject explicitly. There are **18** compatibility/negative/CLI observations in `v2/correctness.json`.

Twelve ABI tests passed with **158** recorded preparation/reference/runtime operations. Eleven selected tests come from the current repository suite; the adapter retains the additional partial `fd_read` boundary fixture from the earlier qualification scope. Exact WAT, Wasm and AOT fixtures persist under `v2/abi-fixtures`, with observations in `v2/abi.json`. This covers numeric spelling, memory32/64 bounds, imports/signatures, partial output/traps, input parsing, iovec snapshot aliasing, growth notification and stack initialization. It does not claim that the AOT-only runtime supports service or compiler modes.

## Qualified private artifacts

| Artifact | Bytes | SHA256 |
|---|---:|---|
| Original full host | 22,751,120 | `e303865d7661dc5d0dad1e1719753d1101bfe7f7e16d5b1eb2e174f416fbbf28` |
| V2 full-SDK subset preparer | 22,751,488 | `dd6d8f9e2df5556a36dae4585e031e90e413d43b9d912721c9ba722f7b04515d` |
| V2 official-min stdio runtime | 1,408,152 | `2a02c9f4153d56bd57b64d6d428ea8a34c2fe5cf5271474cc4ec3c731c14e654` |

The full subset preparer changes the original full C++ host only in feature configuration. The official-min runtime additionally uses the already reviewed private stdio AOT-only source. Thus the package comparison changes SDK, profile and output implementation; it does not isolate compiler-removal or binary-size causality. Exact build commands, headers, libraries, C++ sources and hashes are in each `build.json`. Link diagnostics were 2.149 seconds for the full subset preparer and 1.355 seconds for official min, outside performance sampling.

## V2 fresh-process results

Each affinity/workload has 61 shuffled matched rounds plus two warmups, with five cells: original full/default artifact, unchanged-byte full clone, full subset/subset artifact, official-min subset runtime, and unchanged native binary. Canonical stdout, empty stderr and zero exit were required in all **1,260** executions. Production pidfd deadlines remain enabled. Actual executable, native, Wasm and AOT inodes were locally evicted and identically sequentially warmed **after all input hashing**. Exact cache-residency evidence is in the report. Equal-length executable and AOT aliases control launch path length.

| Workload / affinity | Full us | Min us | Native us | Paired min/full | Paired min/native |
|---|---:|---:|---:|---:|---:|
| Functions / pool | 955.195 | 719.578 | 606.924 | **0.74998** | **1.18208** |
| Squares / pool | 896.173 | 653.241 | 542.471 | **0.72963** | **1.20420** |
| Functions / CPU2 | 1077.939 | 818.015 | 664.914 | 0.75741 | 1.21310 |
| Squares / CPU2 | 1017.845 | 744.345 | 597.405 | 0.73698 | 1.24603 |

Normal pool is primary; parent and child pinned to CPU2 is a diagnostic. Wall columns are independently summarized medians; paired ratios are medians of within-round ratios, not ratios of those wall medians. MAD and every sample remain in `v2/measurement-1/report.json`.

Pool Functions min/full has bootstrap 95% interval **0.74446–0.75612** and min/native **1.17123–1.19387**. Pool Squares min/full is **0.72261–0.73598**. These use 10,000 paired bootstrap resamples with seed 116603, preserved in `paired-selection.json`.

The unchanged-byte A/A pool ratios are **1.00139** for Functions (interval **0.99099–1.00918**) and **0.99452** for Squares (interval **0.98423–1.00871**). CPU2 Functions retains a small 1.46% A/A offset (interval 1.00360–1.02739), disclosed rather than interpreted as a code effect. It is much smaller than the package result. Feature-profile change alone is flat for Functions (full subset/full default 1.00245 pool); that is a useful control against attributing the package gain to merely toggling GC/EH settings.

## Rejected v3 lazy-input experiment

V3 applies exactly the reviewed `pending_stdin`, once-only `load_input`, token trigger, checked nonzero fd0-read trigger, and CLI pending flag to both private hosts. It retains the same SDKs, profile and stdio source. Eighteen adapted reviewed host tests passed. The full subset lazy preparer exercises ordinary/compiler/worker contracts; actual min AOT runs cover normal ABI comparisons and open-pipe/no-input, token EOF, invalid/empty reads and unreadable/closed stdin cases. Scope and frozen test source are in `v3`.

Another independently collected normalized 61-round matrix, **1,260** checked executions, compares eager min, lazy min, native, full host and unchanged-byte A/A. Primary pool lazy/eager is **0.98899** for Functions with interval **0.95613–1.00305**, and **1.00298** for Squares with interval **0.98369–1.03303**. Both include equality. CPU2 improves about 3.5–3.9%, consistent with removing the empty-stdin pipe handoff, but it does not establish a primary-pool win. The Functions min/native paired ratio remains about 1.187 in the pool.

Lazy input also deliberately stops waiting for/draining stdin in no-input CLI programs, and moves input-read time into the first reader callback's entry timing. That behavior tradeoff is real. V3 is rejected as the performance selection; its successful correctness tests and diagnostic CPU2 gain are preserved.

## Final-run handoff

`frozen-baseline/bin/goose-wasmtime` and `frozen-baseline/clone/goose-wasmtime` are two copied, byte-identical original e303 executables. Their new metadata keeps the historical build command verbatim and remaps the four mutable source/build input hashes to `sources-before`. Original metadata is retained unchanged. These files survive production host/builder edits without rewriting historical reports.

`screen-final-template.py` is a configurable source-only handoff, not yet executed. It defaults to these frozen baseline/A/A copies and accepts final full/minimal hosts, full-host profile arguments, final Functions/Squares AOT paths and additional evidence pins. It revalidates all inputs, normalizes actual inodes, and runs the same 61-round/two-warmup comparison. Product integration, final binaries, broader cohorts and publication remain the root agent's work. No production source was changed by this private profile experiment.
