# Example program benchmarks

Status: **passed**.

2026-11-04 · AMD Ryzen 7 3800X, shared host.

Goose O2. Direct Wasm uses memory32; C-Wasm uses memory64. The selected programs, their constant inputs and all printing are unchanged from the [example catalog](../../../../examples/README.md). Compiler constant folding is allowed.

Builds are complete uncached Python-driver invocations, including any C compilation/linking. OS page caches and Emscripten's installed system-library cache remain warm.

Runtime is **whole-process launch-to-exit time**, including host startup, Wasm compilation/instantiation, program initialization, computation, output delivery and teardown. Each observation starts a fresh process/instance and calls the entrypoint once. This measures CLI cost, not warmed kernel throughput.

Each cell has 5 build samples or 15 runtime samples. Untimed fresh-process warmups per runtime cell: 1. Orders are shuffled with the recorded seed; builds and runtime never overlap. Every used artifact must pass its golden output. Values are median milliseconds ± median absolute deviation (MAD).

Headline runtime samples use the ordinary runners without timing-file instrumentation. The Wasm supplements use a separate shuffled set of fresh processes, with the same sample count; timing files are written after their engine intervals end.

## Compilation

| Example | Direct | C-Wasm | Native C |
| --- | ---: | ---: | ---: |
| squares | 61.243 ±0.803 | 487.020 ±28.686 | 213.174 ±15.176 |
| tour | 61.492 ±0.280 | 937.259 ±13.157 | 399.546 ±9.400 |
| functions | 95.774 ±11.845 | 931.904 ±26.728 | 524.430 ±16.046 |
| errors | 74.100 ±6.863 | 692.163 ±8.807 | 355.283 ±24.040 |
| sieve | 66.531 ±2.094 | 595.024 ±8.872 | 263.573 ±10.249 |
| sorting | 100.945 ±7.952 | 851.361 ±3.020 | 510.966 ±7.250 |
| sudoku | 71.693 ±4.229 | 530.441 ±39.943 | 266.772 ±9.051 |
| maze | 80.904 ±5.260 | 677.549 ±17.707 | 351.533 ±26.210 |
| vm | 66.600 ±0.912 | 656.981 ±17.139 | 299.063 ±5.325 |
| life | 93.962 ±10.625 | 582.108 ±37.133 | 291.535 ±10.624 |

## Whole-process runtime

| Example | Direct / V8 | C-Wasm / V8 | Direct / Wasmtime | C-Wasm / Wasmtime | Native C |
| --- | ---: | ---: | ---: | ---: | ---: |
| squares | 27.235 ±2.077 | 29.081 ±3.410 | 67.672 ±1.059 | 99.447 ±8.729 | 1.125 ±0.167 |
| tour | 49.461 ±7.843 | 33.035 ±4.609 | 104.614 ±6.757 | 118.177 ±14.595 | 0.901 ±0.145 |
| functions | 34.093 ±4.625 | 33.475 ±2.409 | 92.210 ±6.536 | 104.141 ±7.428 | 0.866 ±0.106 |
| errors | 27.429 ±1.912 | 29.154 ±1.415 | 94.472 ±13.795 | 87.728 ±6.611 | 1.220 ±0.069 |
| sieve | 34.045 ±7.953 | 33.145 ±4.086 | 75.644 ±2.709 | 84.820 ±4.284 | 1.540 ±0.252 |
| sorting | 64.541 ±4.007 | 224.987 ±5.444 | 108.418 ±5.066 | 229.232 ±12.528 | 45.607 ±0.706 |
| sudoku | 34.482 ±3.775 | 34.027 ±1.634 | 81.044 ±4.011 | 92.531 ±6.043 | 4.035 ±0.104 |
| maze | 28.633 ±1.488 | 32.260 ±3.428 | 89.968 ±14.231 | 93.137 ±7.389 | 0.851 ±0.199 |
| vm | 32.094 ±3.953 | 34.245 ±5.514 | 93.224 ±4.805 | 90.247 ±4.860 | 1.077 ±0.229 |
| life | 43.341 ±8.578 | 39.606 ±1.705 | 109.015 ±7.580 | 95.717 ±5.488 | 18.880 ±1.196 |

## Supplement: Wasm entrypoint

| Example | Direct / V8 | C-Wasm / V8 | Direct / Wasmtime | C-Wasm / Wasmtime |
| --- | ---: | ---: | ---: | ---: |
| squares | 0.198 ±0.021 | 0.940 ±0.010 | 0.127 ±0.005 | 0.628 ±0.006 |
| tour | 13.854 ±0.203 | 3.771 ±1.065 | 1.718 ±0.025 | 1.692 ±0.019 |
| functions | 5.792 ±1.127 | 2.641 ±0.088 | 1.328 ±0.024 | 1.900 ±0.016 |
| errors | 1.537 ±0.051 | 1.734 ±0.023 | 0.830 ±0.009 | 1.675 ±0.014 |
| sieve | 1.929 ±0.048 | 2.642 ±0.822 | 1.141 ±0.011 | 1.329 ±0.013 |
| sorting | 22.234 ±0.843 | 195.079 ±5.890 | 14.786 ±0.107 | 122.150 ±1.260 |
| sudoku | 5.316 ±0.074 | 6.577 ±0.155 | 3.740 ±0.023 | 8.276 ±0.091 |
| maze | 2.335 ±0.068 | 1.910 ±0.056 | 0.757 ±0.007 | 2.211 ±0.007 |
| vm | 3.035 ±0.378 | 2.922 ±0.715 | 0.895 ±0.005 | 2.948 ±0.037 |
| life | 6.250 ±1.405 | 13.581 ±4.024 | 2.743 ±0.019 | 9.424 ±0.054 |

## Supplement: Wasm engine compilation and instantiation

| Example | Direct / V8 | C-Wasm / V8 | Direct / Wasmtime | C-Wasm / Wasmtime |
| --- | ---: | ---: | ---: | ---: |
| squares | 0.256 ±0.040 | 0.520 ±0.052 | 2.834 ±0.145 | 11.854 ±1.641 |
| tour | 0.370 ±0.016 | 0.598 ±0.076 | 30.005 ±0.580 | 31.606 ±1.882 |
| functions | 0.414 ±0.023 | 0.568 ±0.051 | 17.718 ±1.333 | 28.524 ±2.073 |
| errors | 0.333 ±0.057 | 0.629 ±0.133 | 11.246 ±1.468 | 15.688 ±2.893 |
| sieve | 0.261 ±0.024 | 0.639 ±0.088 | 6.296 ±0.123 | 14.904 ±1.130 |
| sorting | 0.400 ±0.067 | 0.695 ±0.102 | 16.877 ±2.018 | 30.250 ±1.048 |
| sudoku | 0.287 ±0.027 | 0.610 ±0.060 | 5.720 ±0.695 | 12.048 ±1.382 |
| maze | 0.330 ±0.042 | 0.617 ±0.093 | 11.931 ±2.325 | 14.768 ±0.492 |
| vm | 0.359 ±0.064 | 0.634 ±0.097 | 16.916 ±2.169 | 17.101 ±1.558 |
| life | 0.323 ±0.048 | 0.586 ±0.081 | 11.988 ±0.368 | 13.568 ±1.047 |

The entrypoint interval includes Goose initialization, host output callbacks and any lazy JIT work. It excludes final Wasm-host output concatenation/delivery. Native Goose prints unbuffered, so no native entrypoint column or cross-boundary speedup is presented. Process time minus engine time also includes loading, bookkeeping and teardown; it is not a pure startup measurement.

These fresh-process examples have different timing rules from LangArena's warmed computational regions. Raw samples, commands, artifact/source/compiler identities and engine versions are in [report.json](report.json). [Method and reproduction](../../../examples.md).
