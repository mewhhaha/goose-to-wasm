from pathlib import Path
from collections import Counter
import hashlib,json,re,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[3]
B=ROOT/'build/functions-native-hills'
def read(path):return json.loads(Path(path).read_bytes())
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
host=read(B/'current/host/report.json');examples=read(B/'current/examples/report.json')
rows={(r['name'],r['backend'],r['mode']):r['wall_seconds'] for r in host['runtime_summary']}
expected={}
for n in [r['name'] for r in host['examples']]:
 expected[n]=[f"{rows[n,'direct',m]['median']*1000:.3f}" for m in ['native','precompiled','precompiled-minimal']]
 expected[n].append(f"{rows[n,'native','native-C']['median']*1000:.3f}")
def table(path):
 checked=[]
 for line in Path(path).read_text().splitlines():
  if not line.startswith('|'):continue
  cells=[s.strip() for s in line.strip('|').split('|')];name=cells[0].lower()
  if name not in expected:continue
  assert cells[1:]==expected[name],(path,name,cells,expected[name]);checked.append(name)
 return checked
all_names=table(B/'copy/public-README.md');assert set(all_names)==set(expected)
assert len(table(ROOT/'bench/wasmtime-host.md'))==4
main=ROOT/'bench/charts/examples-runtime.svg';tree=ET.parse(main)
texts=[''.join(e.itertext()) for e in tree.iter('{http://www.w3.org/2000/svg}text')]
labels=Counter()
for n in expected:
 for mode in ['native','precompiled','precompiled-minimal']:
  for backend in ['direct','c-wasm','native']:
   m=mode
   if backend=='native':m='native-C'
   x=rows[n,backend,m];labels[f"{x['median']*1000:.3g} ±{x['mad']*1000:.2g}"]+=1
actual=Counter(texts)
assert all(actual[k]>=v for k,v in labels.items()),'runtime chart data label missing'
description=next(tree.iter('{http://purl.org/dc/elements/1.1/}description')).text
assert json.loads(description)['bar_count']==90
assert 'Minimal Wasmtime host · precompiled' in texts
selection=read(B/'final-measurement/selection.json')
ratio=selection['summary']['pool/functions']['ratios']['subset_min_over_default']['median']
assert f'{(1-ratio)*100:.1f}%' in (ROOT/'README.md').read_text()
for filename,raw,schema in [('examples-latest.json','current/examples/report.json','goose-example-benchmarks-latest-v1'),('wasmtime-host-latest.json','current/host/report.json','goose-wasmtime-host-latest-v1'),('runtime-lifecycle-latest.json','current/lifecycle/report.json','goose-runtime-lifecycle-latest-v1')]:
 short=Path(raw).parts[1]
 target=f'2026-11-04/minimal-aot/{short}.json'
 (ROOT/'bench/results'/filename).write_text(json.dumps({'schema':schema,'report':target,'sha256':sha(B/raw)},indent=2)+'\n')
result={'status':'passed','runtime_bars':90,'example_table_rows':len(all_names),'host_table_rows':4,
        'chart_sha256':sha(main),'examples_report_sha256':sha(B/'current/examples/report.json'),'host_report_sha256':sha(B/'current/host/report.json'),
        'paired_selection_sha256':sha(B/'final-measurement/selection.json'),
        'visual_review':{'status':'passed','previews':['examples-runtime.png','wasmtime-host-runtime.png','examples-compilation.png','lifecycle.png'],'findings':'All10 labels, bars, numeric labels, legends and footers are readable and unclipped. Runtime chart has3panels including minimalAOT. Lifecycle remains fullhostonly.'}}
(B/'validation/results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
