#!/usr/bin/env python3
"""Qualify scalar field snapshots in pure fixed-record function values."""
import argparse
import json
from pathlib import Path
import struct
import subprocess
import sys
import tempfile
import unittest

import test_function_value_forwarding as fv
import test_prefix_resolution as prefix
import test_strip_loops as strip

ROOT=Path(__file__).resolve().parents[1]
REFERENCE=None
EVIDENCE=ROOT/'build/functions-native-hills/projection/test-development'

SALARY='''struct Employee { name:u8[..12], salary:i32, padding:i64 }
recursive fn compare<F>(a:Employee,b:Employee)->bool { F(a,b) }
recursive fn best<F>(xs:Employee[:])->Employee {
    var result=xs[0]; var key=F(result);
    for value in xs[1..] { let next=F(value); if next>key { result=value; key=next; } }
    return result;
}
fn main() {
    let staff:Employee[3]=[Employee { "ada",120,1 },Employee { "grace",135,2 },Employee { "ken",95,3 }];
    print(compare(staff[0],staff[1]) { a,b=>a.salary>b.salary });
    let winner=best(staff[..]) { it.salary };
    print(winner.name," ",winner.salary);
}
'''

ORDER='''struct Pair { first:i64, second:i64 }
var xs:Pair[1]=[Pair { 1,10 }]; var ys:Pair[1]=[Pair { 3,30 }];
var order:i64=0; var left_calls:i64=0; var later_calls:i64=0;
recursive fn first_index()->i64 { left_calls++; order=order*10+1; return 0; }
recursive fn later_index()->i64 { later_calls++; order=order*10+2; xs[0].first=99; return 0; }
recursive fn select<F>(left:Pair[:],right:Pair[:])->i64 {
    F(left[first_index()],right[later_index()])
}
fn main() {
    print(select(xs[..],ys[..]) { a,b=>a.first*100+b.first });
    print(xs[0].first," ",left_calls," ",later_calls," ",order);
}
'''

REPEAT='''struct Pair { first:i64, second:i64 }
recursive fn twice<F>(left:Pair,right:Pair)->i64 { F(left,right)*100+F(right,left) }
fn main() {
    for i in 3 {
        let left=Pair { i+1,100 }; let right=Pair { i+3,200 };
        print(twice(left,right) { a,b=>a.first*10+b.first });
    }
}
'''

BOUNDS='''struct Pair { first:i64, second:i64 }
var calls:i64=0;
var backing:Pair[1]=[Pair { 11,22 }]; var saved:Pair[:];
recursive fn later()->Pair { calls++; return Pair { 2,3 }; }
recursive fn first_call<F>(xs:Pair[:])->i64 { F(xs[0],later()) }
recursive fn unused_call<F>(xs:Pair[:])->i64 { F(later(),xs[0]) }
export fn first()->i64 { first_call(saved) { a,b=>a.first+b.first } }
export fn unused()->i64 { unused_call(saved) { a,b=>a.first } }
export fn clear() { calls=0; }
export fn state()->i64 { calls }
fn main() {
    saved=backing[..];
    print(first()," ",state()); print(unused()," ",state());
}
'''

CAST='''struct Pair { first:i64, second:i64 }
var calls:i64=0;
var backing:Pair[1]=[Pair { 1,0 }]; var saved:Pair[:];
recursive fn later()->Pair { calls++; return Pair { 2,3 }; }
recursive fn apply<F>(xs:Pair[:])->u8 { F(xs[0],later()) }
export fn attempt()->u8 { apply(saved) { a,b=>(a.first as u8)+(b.first as u8) } }
export fn clear() { calls=0; }
export fn state()->i64 { calls }
fn main() { saved=backing[..]; print(attempt()," ",state()); }
'''

BASE='''struct Pair { first:i64, second:i64 }
recursive fn invoke<F>(left:Pair,right:Pair)->i64 { F(left,right) }
{extra}
fn main() {
    let left=Pair { 1,10 }; let right=Pair { 3,30 }; let bonus=7;
    print(invoke(left,right) { callback });
}
'''
NEGATIVES={
    'capture':BASE.replace('{extra}','recursive fn seed()->i64 { 7 }').replace(
        'let bonus=7','let bonus=seed()').replace('callback','a,b=>a.first+b.first+bonus'),
    'call':BASE.replace('{extra}','recursive fn plus(a:i64,b:i64)->i64 { a+b }').replace(
        'callback','a,b=>plus(a.first,b.first)'),
    'assignment':BASE.replace('{extra}','').replace('callback','var a,b=>a.first++; a.first+b.first'),
    'addressed':BASE.replace('{extra}','').replace('callback','a:Pair&,b=>a.first+b.first'),
    'nested-field':'''struct Inner { first:i64 } struct Pair { inner:Inner,second:i64 }
recursive fn invoke<F>(a:Pair,b:Pair)->i64 { F(a,b) }
fn main() { let a=Pair { Inner { 1 },10 }; let b=Pair { Inner { 3 },30 };
print(invoke(a,b) { x,y=>x.inner.first+y.inner.first }); }
''',
    'owner':'''struct Pair { first:i64,items:i64[>..] }
recursive fn invoke<F>(a:Pair,b:Pair)->i64 { F(copy(a),copy(b)) }
fn main() { let a=Pair { 1,[10] }; let b=Pair { 3,[30] };
print(invoke(copy(a),copy(b)) { x,y=>x.first+y.first }); }
''',
    'varint':'''struct Pair { first:i64,second:varint }
recursive fn invoke<F>(a:Pair,b:Pair)->i64 { F(copy(a),copy(b)) }
fn main() { let a=Pair { 1,-65 }; let b=Pair { 3,8192 };
print(invoke(copy(a),copy(b)) { x,y=>x.first+y.first }); }
''',
    'prefix-mapping':BASE.replace('{extra}', '''struct Owner { id:i64,items:i64[>..] }
recursive fn owned()->Owner { Owner { 7,[8] } }''').replace(
        'print(invoke(left,right)',
        'let owner=owned(); let kept:const i64& =owner.id; owner.id+=1; print(kept);\n    print(invoke(left,right)'
    ).replace('callback','a,b=>a.first+b.first'),
}

NODE_HOST=r'''const fs=require('node:fs');
const [file,name,scenario]=process.argv.slice(1);const m=new WebAssembly.Module(fs.readFileSync(file));
const imports={};for(const item of WebAssembly.Module.imports(m)){
  if(!imports[item.module])imports[item.module]={};imports[item.module][item.name]=()=>{};
}
const e=new WebAssembly.Instance(m,imports).exports;e._start();e.clear();
const image=Buffer.from(e.memory.buffer),marker=Buffer.alloc(16);
let first=11n,second=22n;if(name==='attempt'){first=1n;second=0n;}
if(scenario==='division')second=1n;marker.writeBigInt64LE(first);marker.writeBigInt64LE(second,8);
const backing=image.indexOf(marker);if(backing<0)throw Error('missing backing sentinel');
const header=Buffer.alloc(8);header.writeUInt32LE(backing);header.writeUInt32LE(1,4);
const headers=[];for(let at=image.indexOf(header);at>=0;at=image.indexOf(header,at+1))headers.push(at);
if(!headers.length)throw Error('missing live slice header');
const end=e.memory.buffer.byteLength;let pointer=end-16;
if(scenario==='short')pointer=end-8;if(scenario==='wrap')pointer=0xfffffff8;
for(const at of headers){image.writeUInt32LE(pointer,at);image.writeUInt32LE(1,at+4);}
if(pointer<end){const view=new DataView(e.memory.buffer);let head=11n,tail=22n;
  if(scenario==='cast')head=256n;if(scenario==='division')tail=0n;
  view.setBigInt64(pointer,head,true);if(pointer+16<=end)view.setBigInt64(pointer+8,tail,true);}
let trapped=false,value=null;
try{value=String(e[name]());}catch(error){
  if(!(error instanceof WebAssembly.RuntimeError))throw error;trapped=true;
}
process.stdout.write(JSON.stringify({trapped,value,calls:String(e.state())}));
'''


class FunctionValueProjection(unittest.TestCase):
    def setUp(self):
        EVIDENCE.mkdir(parents=True,exist_ok=True)
        self.work=Path(tempfile.mkdtemp(prefix=self._testMethodName+'-',dir=EVIDENCE))
        self.sequence=0

    def command(self,command,timeout=60):
        result=subprocess.run(list(map(str,command)),capture_output=True,text=True,timeout=timeout)
        (self.work/f'command-{self.sequence}.json').write_text(json.dumps({
            'command':list(map(str,command)),'returncode':result.returncode,
            'stdout':result.stdout,'stderr':result.stderr},indent=2)+'\n')
        self.sequence+=1
        self.assertEqual(result.returncode,0,result.stdout+result.stderr)
        return result

    def compile_input(self,source,level,debug,compiler=None):
        if compiler is None:compiler=strip.GOOSE
        path=self.work/'main.goose'
        if isinstance(source,Path):path.write_text(source.read_text())
        else:path.write_text(source)
        stem=self.work/f'case-{self.sequence}-O{level}'
        stem.with_suffix('.goose').write_text(path.read_text())
        wasm=stem.with_suffix('.wasm');stats=stem.with_suffix('.json')
        command=[compiler,path,'--offline','--target','wasm-direct',f'-O{level}',
                 '--wasm-stats',stats,'-o',wasm]
        if debug:command.append('--debug')
        self.command(command)
        return wasm,json.loads(stats.read_text())

    def native(self,source,level,debug):
        path=self.work/'main.goose'
        if isinstance(source,Path):path.write_text(source.read_text())
        else:path.write_text(source)
        cfile=self.work/f'native-{self.sequence}.c';binary=cfile.with_suffix('')
        command=[strip.GOOSE,path,'--offline','--target','native','--standalone',f'-O{level}','-o',cfile]
        if debug:command.append('--debug')
        self.command(command);self.command([prefix.CC,cfile,'-lm','-o',binary])
        return self.command([binary]).stdout

    def bodies(self,path,stats):
        return list(fv.function_bodies(path,stats))

    def compare_structure(self,current,previous,debug,reduced=None):
        self.assertEqual([n for n,_ in current],[n for n,_ in previous])
        changed=0
        for (name,body),(_,before) in zip(current,previous):
            if debug or reduced is None:
                self.assertEqual(body,before,name)
            elif name.split('#')[0] in reduced:
                copies=fv.memory_copy_count(body);prior=fv.memory_copy_count(before)
                self.assertLessEqual(copies,prior,name)
                changed+=prior-copies
        if not debug and reduced is not None:self.assertGreater(changed,0,reduced)

    def qualify(self,source,expected,reduced=None):
        for level in (0,2):
            for debug in (False,True):
                with self.subTest(level=level,debug=debug):
                    wasm,stats=self.compile_input(source,level,debug)
                    current=self.bodies(wasm,stats)
                    self.assertEqual(self.native(source,level,debug),expected)
                    for engine,command in [
                        ('v8',[strip.NODE,ROOT/'scripts/run_wasm.mjs',wasm]),
                        ('wasmtime',[sys.executable,ROOT/'scripts/run_wasmtime.py',wasm]),
                    ]:
                        with self.subTest(engine=engine):self.assertEqual(self.command(command).stdout,expected)
                    if REFERENCE is not None:
                        old,oldstats=self.compile_input(source,level,debug,REFERENCE)
                        self.compare_structure(current,self.bodies(old,oldstats),debug,reduced)

    def observations(self,wasm,name,scenario):
        import wasmtime
        observed=json.loads(self.command([strip.NODE,'-e',NODE_HOST,wasm,name,scenario]).stdout)
        engine=wasmtime.Engine();module=wasmtime.Module.from_file(engine,str(wasm))
        store=wasmtime.Store(engine);linker=wasmtime.Linker(engine)
        for item in module.imports:linker.define_func(item.module,item.name,item.type,lambda *args:None)
        exports=linker.instantiate(store,module).exports(store);exports['_start'](store);exports['clear'](store)
        memory=exports['memory'];image=bytes(memory.read(store));end=len(image);pointer=end-16
        marker=struct.pack('<qq',11,22)
        if name=='attempt':marker=struct.pack('<qq',1,0)
        if scenario=='division':marker=struct.pack('<qq',1,1)
        backing=image.find(marker);self.assertGreaterEqual(backing,0,'missing backing sentinel')
        header=struct.pack('<II',backing,1);headers=[];at=image.find(header)
        while at>=0:
            headers.append(at);at=image.find(header,at+1)
        self.assertTrue(headers,'missing live slice header')
        if scenario=='short':pointer=end-8
        if scenario=='wrap':pointer=0xfffffff8
        for at in headers:memory.write(store,struct.pack('<II',pointer,1),at)
        if pointer<end:
            value=11
            if scenario=='cast':value=256
            memory.write(store,value.to_bytes(8,'little',signed=True),pointer)
            tail=22
            if scenario=='division':tail=0
            if pointer+16<=end:memory.write(store,tail.to_bytes(8,'little'),pointer+8)
        trapped=False;value=None
        try:value=str(exports[name](store))
        except wasmtime.Trap:trapped=True
        other={'trapped':trapped,'value':value,'calls':str(exports['state'](store))}
        self.assertEqual(other,observed)
        return observed

    def qualify_host(self,source,name,cases,expected,reduced):
        self.qualify(source,expected,reduced)
        for level in (0,2):
            for debug in (False,True):
                compilers=[strip.GOOSE]
                if REFERENCE is not None:compilers.append(REFERENCE)
                for compiler in compilers:
                    wasm,_=self.compile_input(source,level,debug,compiler)
                    for scenario,result in cases.items():
                        with self.subTest(level=level,debug=debug,compiler=compiler,scenario=scenario):
                            if callable(result):result=result(debug)
                            self.assertEqual(self.observations(wasm,name,scenario),result)

    def test_salary_comparison_and_single_field_best_by_remove_record_copies(self):
        self.qualify(SALARY,'false\ngrace 135\n',{'compare','best'})

    def test_later_index_actual_mutation_keeps_first_snapshot_and_order(self):
        self.qualify(ORDER,'103\n99 1 1 12\n',{'select'})

    def test_repeated_function_values_restore_field_maps_and_take_fresh_values(self):
        self.qualify(REPEAT,'1331\n2442\n3553\n',{'twice'})

    def test_declared_scalar_widths_signedness_boolean_and_float_values(self):
        fields=[('i8','-128','-128'),('u8','255','255'),('i16','-32768','-32768'),
                ('u16','65535','65535'),('i32','-2147483648','-2147483648'),
                ('u32','4294967295','4294967295'),('i64','-9223372036854775808','-9223372036854775808'),
                ('u64','18446744073709551615','18446744073709551615'),
                ('bool','true','true'),('f32','-0.0','-0.0'),('f64','1.25','1.25')]
        declarations=','.join(f'v{i}:{kind}' for i,(kind,_,_) in enumerate(fields))
        values=','.join(value for _,value,_ in fields)
        output=''.join(f'print(read(row) {{ it.v{i} }});\n' for i in range(len(fields)))
        output+='print(read(row) { it.v0 as i64 }); print(read(row) { it.v9 as f64 }); print(read(row) { !it.v8 });\n'
        source=f'''struct Row {{ {declarations} }}
recursive fn read<F>(row:Row) {{ F(row) }}
fn main() {{ let row=Row {{ {values} }}; {output} }}
'''
        self.qualify(source,''.join(value+'\n' for _,_,value in fields)+'-128\n-0.0\nfalse\n',{'read'})
        self.qualify('''struct Empty {}
recursive fn invoke<F>(a:Empty,b:Empty)->i64 { F(a,b) }
fn main() { print(invoke(Empty {},Empty {}) { a,b=>7 }); }
''','7\n',{'invoke'})

    def test_full_first_record_span_traps_before_later_argument_effects(self):
        self.qualify_host(BOUNDS,'first',{
            'valid':{'trapped':False,'value':'13','calls':'1'},
            'short':{'trapped':True,'value':None,'calls':'0'},
            'wrap':{'trapped':True,'value':None,'calls':'0'},
        },'13 1\n2 2\n',{'first_call','unused_call'})

    def test_unused_record_argument_still_checks_its_complete_source_span(self):
        self.qualify_host(BOUNDS,'unused',{
            'valid':{'trapped':False,'value':'2','calls':'1'},
            'short':{'trapped':True,'value':None,'calls':'1'},
            'wrap':{'trapped':True,'value':None,'calls':'1'},
        },'13 1\n2 2\n',{'first_call','unused_call'})

    def test_checked_field_cast_runs_after_all_argument_effects(self):
        def cast_result(debug):
            if debug:return {'trapped':True,'value':None,'calls':'1'}
            return {'trapped':False,'value':'2','calls':'1'}
        self.qualify_host(CAST,'attempt',{
            'cast':cast_result,
        },'3 1\n',{'apply'})
        division=CAST.replace('Pair { 1,0 }','Pair { 1,1 }').replace(
            '(a.first as u8)+(b.first as u8)','(a.first/a.second) as u8')
        self.qualify_host(division,'attempt',{
            'division':{'trapped':True,'value':None,'calls':'1'},
        },'1 1\n',{'apply'})

    def test_unproved_bodies_references_owners_and_dynamic_layouts_keep_lowering(self):
        for label,source in NEGATIVES.items():
            expected='4\n'
            if label=='capture':expected='11\n'
            if label=='assignment':expected='5\n'
            if label=='prefix-mapping':expected='8\n4\n'
            with self.subTest(case=label):self.qualify(source,expected)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--goose',type=Path,default=strip.GOOSE)
    parser.add_argument('--reference-compiler','--reference-goose',dest='reference',type=Path)
    parser.add_argument('--node',default=strip.NODE);parser.add_argument('--cc',default=prefix.CC)
    args,remaining=parser.parse_known_args();strip.GOOSE=args.goose.resolve()
    strip.NODE=args.node;prefix.CC=args.cc
    if args.reference is not None:REFERENCE=args.reference.resolve()
    unittest.main(argv=[sys.argv[0],*remaining])
