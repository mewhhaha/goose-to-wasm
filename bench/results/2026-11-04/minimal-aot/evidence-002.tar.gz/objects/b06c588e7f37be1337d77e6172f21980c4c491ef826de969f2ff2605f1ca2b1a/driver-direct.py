#!/usr/bin/env python3
"""Complete the declared direct-only minimal scope and retain earlier evidence."""
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import traceback

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("qualification_driver", OUT / "driver.py")
HELPER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(HELPER)


def digest(path):
    return HELPER.digest(path)


def verify_pins(pins, aliases=None):
    aliases = aliases or {}
    for filename, expected in pins.items():
        assert digest(aliases.get(filename, filename)) == expected, filename


def main():
    before = json.loads((OUT / "driver-unfiltered-failure.json").read_text())
    report = {"schema": "goose-final-minimal-host-qualification-v2", "status": "running",
              "pid": os.getpid(), "started_utc": datetime.now(timezone.utc).isoformat(),
              "active": "verify-prior-phases", "commands": [],
              "reused_compiler": before["reused_compiler"],
              "measurement": "Correctness qualification only. Compiler9573 observations are prior, SHA-verified evidence. Full11484 and unit gates were freshly executed this session. Minimal supported corpus scope is every direct unit1914; no case filters or waivers. C-Wasm EH remains on the general host."}
    HELPER.checkpoint(report)
    try:
        gates = json.loads((OUT / "gates.json").read_text())
        assert gates["status"] == "passed" and gates["complete"]
        assert gates["input_sha256"] == gates["input_sha256_after"]
        verify_pins(gates["input_sha256"])
        report["commands"] = gates["commands"]
        report["fresh_gates"] = {"report": str(OUT / "gates.json"), "sha256": digest(OUT / "gates.json"),
                                 "tests": sum(row["observed_tests"] for row in gates["commands"])}
        report["host"] = HELPER.validate_replay(OUT / "host/report.json", 11484,
                              ["wasm", "wasm-no-parallel", "precompiled-no-parallel"])
        full = json.loads((OUT / "host/report.json").read_text())
        old_source = OUT / "frozen-sources/qualify_wasmtime_host-full-and-unfiltered.py"
        aliases = {str(ROOT / "bench/qualify_wasmtime_host.py"): str(old_source)}
        verify_pins(full["input_sha256"], aliases)
        verify_pins(full["aot_sha256"])
        report["host"]["phase_source_aliases"] = aliases
        report["host"]["phase_source_sha256"] = digest(old_source)
        report["commands"] += [row for row in before["commands"] if row["name"] == "host-replay"]
        boundary = OUT / "minimal-all-backends-attempt/report.json"
        failed = json.loads(boundary.read_text())
        assert failed["status"] == "fail" and not failed["results"]
        eh = [row for row in failed["preparations"] if row["status"] != "pass"]
        report["unsupported_attempt"] = {"report": str(boundary), "report_sha256": digest(boundary),
            "status": "not-qualified", "requested_units": 3828, "runtime_observations": 0,
            "collected_preparations_before_environment_abort": len(failed["preparations"]),
            "collected_refusals": len(eh), "error": failed.get("error"),
            "method": "Unfiltered direct+C-Wasm minimal attempt found actual EH parser refusals; ENOSPC interrupted collector checkpointing. Not a passing minimal corpus. Exact raw command/stdout/stderr/result evidence retained in the verified task-local log archive; all AOT files retained.",
            "raw_log_compaction": str(OUT / "raw-log-compaction.json"),
            "relocation": str(OUT / "phase-source-and-relocation.json")}
        current = ROOT / "bench/qualify_wasmtime_host.py"
        snapshot = OUT / "frozen-sources/qualify_wasmtime_host-direct.py"
        shutil.copyfile(current, snapshot)
        report["minimal_phase_source"] = {"path": str(current), "sha256": digest(current), "snapshot": str(snapshot)}
        command = [str(ROOT / ".venv/bin/python"), str(current), "--baseline-dir", str(HELPER.BASELINE),
                   "--baseline-report", str(OUT / "baseline-report.json"), "--host", str(ROOT / "build/bin/goose-wasmtime"),
                   "--aot-host", str(ROOT / "build/bin/goose-wasmtime-aot"), "--backends", "direct",
                   "--jobs", "4", "--output-dir", str(OUT / "minimal")]
        result = HELPER.run(report, "minimal-direct-replay", command)
        assert result["exit_status"] == 0
        report["minimal"] = HELPER.validate_replay(OUT / "minimal/report.json", 1914, ["precompiled-minimal"])
        minimal = json.loads((OUT / "minimal/report.json").read_text())
        assert minimal["configuration"]["backends"] == ["direct"]
        assert minimal["configuration"]["filter"] == ""
        assert {row["backend"] for row in minimal["results"]} == {"direct"}
        assert minimal["baseline_observations"] == 9573
        verify_pins(minimal["input_sha256"])
        verify_pins(minimal["aot_sha256"])
        smoke_path = ROOT / "build/functions-native-hills/benchmark-smoke/host/report.json"
        smoke = json.loads(smoke_path.read_text())
        assert smoke["status"] == "passed-smoke"
        minimal_examples = [row for row in smoke["observations"] if row["mode"] == "precompiled-minimal"]
        assert len(minimal_examples) == 20
        assert len({row["name"] for row in minimal_examples}) == 10
        assert {row["backend"] for row in minimal_examples} == {"direct", "c-wasm"}
        assert all(row["exit_code"] == 0 for row in minimal_examples)
        report["example_minimal_smoke"] = {"report": str(smoke_path), "report_sha256": digest(smoke_path),
            "examples": 10, "observations": 20, "backends": ["direct", "c-wasm"],
            "scope": "Separately collected correctness-only smoke individually compiled and ran all ten example artifacts per backend under the minimal profile. These C-Wasm examples happen not to require EH; this does not qualify the broader C-Wasm corpus under minimal."}
        report.update(status="passed", coverage_exact=True)
    except BaseException as error:
        report.update(status="failed", error=type(error).__name__ + ": " + str(error), traceback=traceback.format_exc())
    report.update(active=None, complete=True, finished_utc=datetime.now(timezone.utc).isoformat())
    HELPER.checkpoint(report)
    completion = {"status": report["status"], "complete": True, "exit_status": int(report["status"] != "passed"),
                  "pid": os.getpid(), "report_sha256": digest(OUT / "report.json"), "finished_utc": report["finished_utc"]}
    (OUT / "completion.json").write_text(json.dumps(completion, indent=2) + "\n")
    return completion["exit_status"]


if __name__ == "__main__":
    raise SystemExit(main())
