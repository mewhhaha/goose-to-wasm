from pathlib import Path
import hashlib,json,random,statistics
BASE=Path(__file__).resolve().parent
path=BASE/'final-measurement/report.json'
raw=path.read_bytes();report=json.loads(raw)
rng=random.Random(20261104)
result={'schema':'goose-minimal-aot-final-selection-v1','status':'passed','report':str(path.absolute()),
        'report_sha256':hashlib.sha256(raw).hexdigest(),'selector':'Median of within-round candidate/reference wall ratios; lower is better.',
        'confidence_method':'10000 bootstrap resamples of paired ratios; percentile95% interval of the median; seed20261104. Shared-host observations are retained without outlier removal.',
        'primary':'pool/functions','summary':{}}
for group,row in report['summary'].items():
 out={'wall_us':{k:{f:v[f] for f in ['n','median','mad']} for k,v in row['wall_us'].items()},'ratios':{}}
 for name in ['default_aa_over_default','subset_full_over_default','subset_min_over_default','subset_min_over_native','subset_min_over_subset_full']:
  item=row['paired_ratios'][name];values=item['samples']
  resampled=sorted(statistics.median(rng.choices(values,k=len(values))) for _ in range(10000))
  out['ratios'][name]={'n':len(values),'median':item['median'],'mad':item['mad'],'median_ci95':[resampled[249],resampled[9749]]}
 result['summary'][group]=out
result['decision']='Select official minimal AOT runner. Functions is closer to native, with a measurable remaining gap; no native-equivalence or universal-ceiling claim. Broader15-sample all10 cohort remains separate and all regressions/variation retained.'
result['input_sha256']={str(Path(__file__).resolve()):hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(BASE/'final-measurement/selection.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result['summary']['pool/functions'],indent=2))
