# Byte-identical executable confound

The original and rebuilt host have exactly the same SHA256 (`e303865d7661dc5d0dad1e1719753d1101bfe7f7e16d5b1eb2e174f416fbbf28`). The measured regression follows their executable inodes, and disappears after the same local file-cache repopulation protocol. It is not evidence of a code regression.

Both diagnostic matrices use the same `argv[0]`, exact same AOT path and environment, equal-length filesystem executable aliases, checked canonical outputs and `os.wait4` child CPU/fault accounting. Parent and child share affinity 0–15 in the pool and CPU 2 in the diagnostic. stdin is `/dev/null`; output is captured and checked after wait4 because these canonical outputs fit in the pipe. Thus these are attribution experiments with a different launch contract from the primary benchmark, not replacement benchmark scores.

There are 61 uninstrumented shuffled pairs per control/workload/affinity. Separate 31-pair rows preload the exact same main-timing library into both binaries. That preload times the unchanged `main`; diagnostic file writes happen after its measured interval. Primary and preloaded rows stay separate. Parent-launch-to-main includes Python launch and loader costs; main-to-wait4-return includes exit and profile I/O, so neither isolates one mechanism.

## Initial inode controls

The matrix in `inode-diagnostic/report.json` preserves the original cache state.

| Control / original, paired wall ratio | Functions pool | Functions CPU2 | Squares pool | Squares CPU2 |
|---|---:|---:|---:|---:|
| Rebuilt inode | 1.0784 | 1.0681 | 1.0784 | 1.0615 |
| Hardlink to rebuilt inode | 1.0532 | 1.0693 | 1.0513 | 1.0651 |
| Hardlink to original inode | 1.0127 | 1.0049 | 1.0041 | 1.0061 |
| Fresh copy one of original bytes | 0.9924 | 0.9615 | 0.9724 | 0.9686 |
| Fresh copy two of original bytes | 0.9858 | 0.9542 | 0.9707 | 0.9590 |

Two memfds containing the original and rebuilt bytes, with the same memfd name and same argv0, match each other: paired rebuilt-source/original-source ratios **0.9933 / 0.9955** for Functions pool/CPU2 and **0.9904 / 1.0043** for Squares. Both memfds are slower than the filesystem controls; they are controls for byte provenance, not an optimization.

CPU2 unprofiled Functions has **232 / 240 minor faults**, **997 / 1084 us total child CPU**, original/rebuilt. Squares has **221 / 229 faults**, **928 / 988 us total child CPU**. Every major-fault median is zero. The same inode through a different hardlink retains the behavior; a newly populated inode containing exactly the same bytes can be faster. Neither executable path length nor compiler-emitted bytes explains that pattern.

The same-preload samples do not put the whole difference before main. CPU2 Functions main is **388.5 / 412.6 us**, before-main **638.9 / 623.8 us**, and tail **231.3 / 258.5 us**. Squares main is **263.7 / 373.5 us**. These noisy medians are independently summarized and are not an additive causal breakdown.

## Local cache intervention

Filesystem is Btrfs. Original extents are shared and rebuilt extents exclusive; no file flags differ. `fincore` showed all **5,555 pages resident** for both before intervention, so simple warm-versus-cold residency does not explain the difference. Transparent huge pages are configured `always`; the exact folio/physical-page mechanism has not been measured.

For both original/rebuilt and both fresh-copy controls, the second diagnostic applies exactly:

1. Open the unmodified executable and `fsync` it.
2. `posix_fadvise(fd, 0, 0, POSIX_FADV_DONTNEED)`.
3. Verify `fincore` reports **zero resident pages**.
4. Read sequentially in 1 MiB chunks.
5. Verify `fincore` reports **5,555 resident pages**.

No bytes or global kernel cache settings change. This affects the actual original/rebuilt inode caches; those caches remain in the newly warmed state at handoff. Old observations and all source/binary hashes remain intact. Fresh copy one comes from the original file and fresh copy two from the rebuilt file in this second matrix.

| Rebuilt/original after intervention | Pool | CPU2 |
|---|---:|---:|
| Functions paired ratio | **1.0036** | **1.0130** |
| Bootstrap 95% interval | 0.9889–1.0366 | 0.9826–1.0214 |
| Squares paired ratio | **1.0006** | **0.9942** |
| Bootstrap 95% interval | 0.9853–1.0099 | 0.9870–1.0155 |

Intervals use 10,000 paired bootstrap resamples, seed 9011. All now include equality. CPU2 Functions minor faults converge to **225 / 226**, and total child CPU to **872 / 881 us**; Squares converges to **216 / 216** faults and **799 / 806 us**. CPU2 same-preload Functions main becomes **306.3 / 294.7 us**, before-main **589.5 / 592.2 us**; Squares main **240.7 / 244.2 us**. The stable earlier advantage is gone.

The intervention identifies executable cache-population state as a demonstrated confound. It does not prove a specific THP, folio, physical allocation or Btrfs implementation mechanism. Per-field user/system CPU accounting is too coarse for interpreting the split in these short processes; the report also preserves the per-run sum.

## Fair selector

Keep the historical results; do not reinterpret them as source-change effects. Before screening a host change, apply the same disclosed local cache repopulation protocol to every actual executable inode, preserve engine/artifact bytes, and retain a byte-identical A/A host control. Equal-length aliases and identical argv0 remain useful controls, but did not remove this confound by themselves.

Accept a compiler/runtime effect only after the A/A control has no stable bias and the candidate's paired result is distinguishable from A/A variability and repeats in an independent collection. The present normalized pool interval still spans several percent, so an isolated 2% gain would not yet be qualified. Fresh copies alone are insufficient: their behavior also changes under the cache intervention, and they retain some variation.

All **5,152 program executions** across the two matrices passed exit/canonical-output/empty-stderr checks. Every pre/post executable and input hash matched. Exact sources, targets/inodes, commands/methods, fault/CPU records, raw main timings, cache-residency proofs and summary statistics are preserved in `inode-diagnostic`, `inode-rewarm-diagnostic` and `inode-causal-summary.json`.
